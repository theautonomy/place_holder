package com.example.json;

import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DogBreedsResponse2 {
    private List<String> message;
    private String status;

    // Getters and setters
    public List<String> getMessage() {
        return message;
    }

    public void setMessage(List<String> message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static void main(String[] args) {
        // Example usage
        String jsonString =
                "{"
                        + "\"message\": ["
                        + "\"https://images.dog.ceo/breeds/terrier-westhighland/n02098286_104.jpg\","
                        + "\"https://images.dog.ceo/breeds/terrier-westhighland/n02098286_104.jpg\""
                        + "],"
                        + "\"status\": \"success\""
                        + "}";
        String jsonString2 =
                """
        {
    "message": [
        "afghan",
        "basset",
        "blood",
        "english",
        "ibizan",
        "plott",
        "walker"
    ],
    "status": "success"
}
                """;
        ObjectMapper mapper = new ObjectMapper();

        try {
            DogBreedsResponse2 response = mapper.readValue(jsonString2, DogBreedsResponse2.class);
            System.out.println("Status: " + response.getStatus());
            System.out.println("Message: " + response.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
