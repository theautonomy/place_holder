package com.example.json;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DogBreedsResponse1 {
    private String message;
    private String status;

    // Getters and setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static void main(String[] args) {
        // Example usage
        String jsonString =
                "{"
                        + "\"message\": \"https://images.dog.ceo/breeds/terrier-westhighland/n02098286_104.jpg\","
                        + "\"status\": \"success\""
                        + "}";

        ObjectMapper mapper = new ObjectMapper();

        try {
            DogBreedsResponse1 response = mapper.readValue(jsonString, DogBreedsResponse1.class);
            System.out.println("Message: " + response.getMessage());
            System.out.println("Status: " + response.getStatus());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
