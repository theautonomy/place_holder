package com.example.context;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "use-right-service", havingValue = "false", matchIfMissing = true)
public class RightService {

    private SelectServiceBeanTest.SomeThirdDependency someThirdDependency;

    public RightService(SelectServiceBeanTest.SomeThirdDependency someThirdDependency) {
        this.someThirdDependency = someThirdDependency;
    }
}
