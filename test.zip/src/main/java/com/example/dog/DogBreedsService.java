package com.example.dog;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

@Service
public class DogBreedsService {

    private final RestClient restClient;

    public DogBreedsService(RestClient.Builder builder) {
        this.restClient = builder.build();
    }

    // random image
    // https://dog.ceo/api/breeds/image/random
    // https://dog.ceo/api/breeds/image/random/3

    // by breed
    // https://dog.ceo/api/breed/hound/images

    // random image from a breed
    // https://dog.ceo/api/breed/hound/images/random
    // https://dog.ceo/api/breed/hound/images/random/3

    // list all sub breeds
    // https://dog.ceo/api/breed/hound/list

    // list all sub breed images
    // https://dog.ceo/api/breed/hound/afghan/images

    // single sub breed image
    // https://dog.ceo/api/breed/hound/afghan/images/random
    // https://dog.ceo/api/breed/hound/afghan/images/random/3

    public DogBreeds getDogBreeds() {
        String url = "https://dog.ceo/api/breeds/list/all";
        try {
            return restClient
                    .get()
                    .uri(url)
                    .retrieve()
                    .toEntity(new ParameterizedTypeReference<DogBreeds>() {})
                    .getBody();
        } catch (HttpClientErrorException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public DogImages get16RandomImages(String breed, String subBreed) {
        String url = "https://dog.ceo/api/breed/" + breed + "/images/random/16";
        if (subBreed != null && subBreed.trim().length() > 0) {
            url = "https://dog.ceo/api/breed/" + breed + "/" + subBreed + "/images/random/16";
        }

        try {
            return restClient
                    .get()
                    .uri(url)
                    .retrieve()
                    .toEntity(new ParameterizedTypeReference<DogImages>() {})
                    .getBody();
        } catch (HttpClientErrorException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public DogImage getOneRandomImage() {
        String url = "https://dog.ceo/api/breeds/image/random";
        try {
            return restClient
                    .get()
                    .uri(url)
                    .retrieve()
                    .toEntity(new ParameterizedTypeReference<DogImage>() {})
                    .getBody();
        } catch (HttpClientErrorException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public DogFact getDogFacts() {
        String url = "https://dogapi.dog/api/v2/facts?limit=1";
        try {
            return restClient
                    .get()
                    .uri(url)
                    .retrieve()
                    .toEntity(new ParameterizedTypeReference<DogFact>() {})
                    .getBody();
        } catch (HttpClientErrorException ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
