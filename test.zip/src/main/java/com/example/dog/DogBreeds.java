package com.example.dog;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnySetter;

public class DogBreeds {
    private Message message;
    private String status;

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static class Message {
        private Map<String, List<String>> breeds = new HashMap<>();

        @JsonAnySetter
        public void addBreed(String key, List<String> value) {
            this.breeds.put(key, value);
        }

        public Map<String, List<String>> getBreeds() {
            return breeds;
        }

        public void setBreeds(Map<String, List<String>> breeds) {
            this.breeds = breeds;
        }
    }
}
