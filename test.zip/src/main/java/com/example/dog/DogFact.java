package com.example.dog;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DogFact {
    private List<Fact> data;

    public List<Fact> getData() {
        return data;
    }

    public void setData(List<Fact> data) {
        this.data = data;
    }
}

class Fact {
    private String id;
    private String type;
    private Attributes attributes;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Attributes getAttributes() {
        return attributes;
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }
}

class Attributes {
    private String body;

    @JsonProperty("body")
    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
