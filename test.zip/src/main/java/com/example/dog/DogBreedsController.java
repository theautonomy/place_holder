package com.example.dog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/dog")
public class DogBreedsController {

    private final DogBreedsService dogBreedsService;

    private final List<String> names;
    private final Map<String, List<String>> breeds;

    public DogBreedsController(DogBreedsService dogBreedsService) {
        this.dogBreedsService = dogBreedsService;
        DogBreeds response = dogBreedsService.getDogBreeds();
        this.names =
                response.getMessage().getBreeds().keySet().stream()
                        .sorted()
                        .collect(Collectors.toList());
        this.breeds = response.getMessage().getBreeds();
    }

    @GetMapping("/")
    public String index() {
        return "dog";
    }

    @GetMapping("/search")
    public String search(@RequestParam String query, Model model) {
        List<String> filteredNames = new ArrayList<>();
        for (String name : names) {
            if (name.toLowerCase().contains(query.toLowerCase())) {
                filteredNames.add(name);
            }
        }
        model.addAttribute("breedNames", filteredNames);
        return "fragments/dog_fragment :: breed_names";
    }

    @GetMapping("/breed/{name}")
    public String thumbnails(@PathVariable String name, Model model) {
        model.addAttribute("breedName", name);
        model.addAttribute("subBreedNames", breeds.get(name));
        DogImages response2 = dogBreedsService.get16RandomImages(name, "");
        List<String> images = response2.getMessage();
        model.addAttribute("images", images);
        return "fragments/dog_fragment :: sub_breed";
    }

    @GetMapping("/image/{breed}/{subBreed}")
    public String image(@PathVariable String breed, @PathVariable String subBreed, Model model) {
        DogImages response2 = dogBreedsService.get16RandomImages(breed, subBreed);
        List<String> images = response2.getMessage();
        model.addAttribute("subBreedImages", images);
        return "fragments/dog_fragment :: subBreedImages";
    }

    @GetMapping("/image/{breed}")
    public String image(@PathVariable String breed, Model model) {
        DogImages response2 = dogBreedsService.get16RandomImages(breed, "");
        List<String> images = response2.getMessage();
        model.addAttribute("subBreedImages", images);
        return "fragments/dog_fragment :: subBreedImages";
    }

    @GetMapping("/largeimage")
    public String largeImage(@RequestParam(required = false) String imageUrl, Model model) {
        if (imageUrl == null || imageUrl.trim().isEmpty()) {
            imageUrl = dogBreedsService.getOneRandomImage().getMessage();
        }
        DogFact dogFact = dogBreedsService.getDogFacts();
        String fact = dogFact.getData().get(0).getAttributes().getBody();
        model.addAttribute("imageUrl", imageUrl);
        model.addAttribute("fact", fact);
        return "fragments/dog_fragment :: largeImage";
    }
}
