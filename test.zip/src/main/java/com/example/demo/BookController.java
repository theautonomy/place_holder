package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BookController {

    @Autowired private BookService bookService;

    @GetMapping("/")
    public String index(Model model) {
        List<Book> books = bookService.getAllBooks();
        model.addAttribute("books", books);
        return "index";
    }

    @PostMapping("/addBook")
    public String addBook(@RequestParam String title, @RequestParam String author, Model model) {
        bookService.addBook(title, author);
        List<Book> books = bookService.getAllBooks();
        model.addAttribute("books", books);
        return "fragments/booklist :: bookList";
    }

    @PostMapping("/search")
    public String searchBooks(@RequestParam String search, Model model) {
        List<Book> books = bookService.getAllBooks(); // Implement your search logic here
        model.addAttribute("books", books);
        return "fragments/booklist :: bookList";
    }
}
