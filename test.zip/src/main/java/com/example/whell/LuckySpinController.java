package com.example.whell;

import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LuckySpinController {

    private static final String[] PRIZES = {
        "Prize 1", "Prize 2", "Prize 3", "Prize 4", "Prize 5", "Prize 6"
    };

    @GetMapping("/wheel")
    public String home() {
        return "wheel";
    }

    @GetMapping("/spin")
    @ResponseBody
    public String spin() {
        Random random = new Random();
        int prizeIndex = random.nextInt(PRIZES.length);
        return "You won: " + PRIZES[prizeIndex] + "!";
    }
}
