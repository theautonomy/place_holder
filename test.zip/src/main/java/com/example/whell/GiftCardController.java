package com.example.whell;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GiftCardController {

    @GetMapping("/card")
    public String home() {
        return "card";
    }

    @GetMapping("/toggleCard")
    public String toggleCard(
            @RequestParam(value = "state", defaultValue = "folded") String state, Model model) {
        String newState = state.equals("folded") ? "unfolded" : "folded";
        model.addAttribute("state", newState);
        return "card :: cardFragment";
    }
}
