package com.example.whell;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ChristmasTreeController {

    @GetMapping("/tree")
    public String home() {
        return "tree";
    }

    @GetMapping("/lighten")
    @ResponseBody
    public String lighten() {
        return "✨ Christmas Tree Lightened Up ✨";
    }
}
