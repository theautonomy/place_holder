package com.example.tracker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ExpenseController {

    @Autowired private ExpenseService expenseService;

    @GetMapping("/tracker")
    public String getExpenses(Model model) {
        model.addAttribute("expenses", expenseService.getAllExpenses());
        return "tracker";
    }

    @PostMapping("/addExpense")
    public String addExpense(@ModelAttribute Expense expense, Model model) {
        expenseService.saveExpense(expense);
        model.addAttribute("expenses", expenseService.getAllExpenses());
        return "expense_fragment :: expenseList";
    }

    @PostMapping("/deleteExpense/{id}")
    public String deleteExpense(@PathVariable Long id, Model model) {
        expenseService.deleteExpense(id);
        model.addAttribute("expenses", expenseService.getAllExpenses());
        return "expense_fragment :: expenseList";
    }
}
