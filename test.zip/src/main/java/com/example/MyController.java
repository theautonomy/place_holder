package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {

    @GetMapping("/showNumber1")
    public String showNumber1(Model model) {
        return "shownumber";
    }

    @GetMapping("/showNumber")
    public String showNumber(@RequestParam String number, Model model) {
        model.addAttribute("number", "123456789");
        // int [] numbers = {1, 2, 2, 1};
        // List<String> numbers = List.of("1", "2", "3", "4", "5", "6", "7", "8", "9", "0");
        // model.addAttribute("numbers", numbers);
        return "fragments/numberIcons :: numberIcons";
    }
}
