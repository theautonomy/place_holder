package com.example.test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public ExampleBean exampleBean(DependencyBean dependencyBean) {
        return new ExampleBean(dependencyBean);
    }

    @Bean
    public DependencyBean dependencyBean() {
        return new DependencyBean();
    }
}
