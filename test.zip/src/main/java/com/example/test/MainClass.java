package com.example.test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.util.ReflectionUtils;

public class MainClass {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        printAllBeansWithDependencies(context);
    }

    private static void printAllBeansWithDependencies(ApplicationContext context) {
        String[] beanNames = context.getBeanDefinitionNames();
        for (String beanName : beanNames) {
            Object bean = context.getBean(beanName);
            List<String> dependencies = findDependencies(bean, context);
            System.out.println(beanName + " (" + bean.getClass().getName() + ")");
            if (!dependencies.isEmpty()) {
                System.out.println("  Dependencies: " + dependencies);
            }
        }
    }

    private static List<String> findDependencies(Object bean, ApplicationContext context) {
        List<String> dependencies = new ArrayList<>();
        Field[] fields = bean.getClass().getDeclaredFields();
        for (Field field : fields) {
            ReflectionUtils.makeAccessible(field);
            if (context.containsBean(field.getName())) {
                dependencies.add(field.getName() + " (" + field.getType().getName() + ")");
            }
        }
        return dependencies;
    }
}
