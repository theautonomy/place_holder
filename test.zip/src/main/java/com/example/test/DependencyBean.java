package com.example.test;

public class DependencyBean {}
