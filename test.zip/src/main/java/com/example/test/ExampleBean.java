package com.example.test;

public class ExampleBean {

    private final DependencyBean dependencyBean;

    public ExampleBean(DependencyBean dependencyBean) {
        this.dependencyBean = dependencyBean;
    }
}
