rootProject.name = "SimilaritySearchTutorial"
