plugins {
	java
	id("org.springframework.boot") version "3.4.3"
	id("io.spring.dependency-management") version "1.1.7"
}

group = "il.tutorials"
version = "0.0.1-SNAPSHOT"

java {
	toolchain {
		languageVersion = JavaLanguageVersion.of(21)
	}
}

repositories {
	mavenCentral()
}

extra["springAiVersion"] = "1.0.0"

dependencies {
	implementation("org.springframework.boot:spring-boot-starter-web")
	implementation("org.springframework.ai:spring-ai-starter-model-transformers")
	implementation("org.springframework.ai:spring-ai-advisors-vector-store")
}

dependencyManagement {
	imports {
		mavenBom("org.springframework.ai:spring-ai-bom:${property("springAiVersion")}")
	}
}

tasks.named<org.springframework.boot.gradle.tasks.bundling.BootJar>("bootJar") {
	archiveFileName.set("similarity-search.jar")
	//duplicatesStrategy = DuplicatesStrategy.INCLUDE
}

tasks.register<Exec>("dockerBuild") {
	dependsOn("bootJar")
	commandLine("docker", "build", "-t", "similarity-search", ".")
}
