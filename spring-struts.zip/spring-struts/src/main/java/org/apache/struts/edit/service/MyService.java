package org.apache.struts.edit.service;

import org.springframework.stereotype.Service;

@Service
public class MyService {

    public String greeting() {
        return "hello world from my bean";
    }
}
