package com.example.littletreasures;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.springframework.util.function.ThrowingFunction;

class ThrowingFunctionTests {

    public static String readFile(String filePath) throws IOException {
        return Files.readString(Paths.get(filePath));
    }

    @Test
    void test() {
        Stream<String> filePaths = Stream.of("file1.txt", "file2.txt", "file3.txt");

        filePaths.map(ThrowingFunction.of(ThrowingFunctionTests::readFile)).forEach(content -> {
            try {
                System.out.println("File content: " + content);
            } catch (RuntimeException e) {
                System.err.println("Error reading file: " + e.getMessage());
            }
        });
    }

}
