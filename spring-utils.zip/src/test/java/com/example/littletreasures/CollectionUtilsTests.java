package com.example.littletreasures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;

// https://github.com/spring-projects/spring-framework/blob/main/spring-core/src/test/java/org/springframework/util/CollectionUtilsTests.java

class CollectionUtilsTests {

    @Test
    void testCollectionUtils() {
        List<String> list1 = Arrays.asList("apple", "banana", "orange");
        List<String> list2 = Arrays.asList("grape", "banana", "kiwi");
        List<String> list3 = List.of(); 
        List<String> list4 = List.of(); 

        // Check if a collection is empty
        System.out.println("Is list1 empty? " + CollectionUtils.isEmpty(list1)); // Output: false
        System.out.println("Is list3 empty? " + CollectionUtils.isEmpty(list3)); // Output: true
        System.out.println("Is list4 empty? " + CollectionUtils.isEmpty(list4)); // Output: true
        System.out.println("Is an empty list empty? " + CollectionUtils.isEmpty(new ArrayList<>())); // Output: true

        // Check if a collection contains a specific element
        System.out.println("Does list1 contain 'banana'? " + CollectionUtils.containsInstance(list1, "banana")); // Output: true

        // Find the first element of a set (or null if empty)
        Set<String> set1 = new HashSet<>(Arrays.asList("apple", "banana"));
        System.out.println("First element of set1: " + CollectionUtils.firstElement(set1)); // Output: apple
        System.out.println("First element of empty set: " + CollectionUtils.firstElement(new HashSet<>())); // Output: null

        // Find the last element of a set (or null if empty)
         System.out.println("Last element of set1: " + CollectionUtils.lastElement(set1));
         // Output: banana (order may vary in HashSet)
        System.out.println("Last element of empty set: " + CollectionUtils.lastElement(new HashSet<>())); // Output: null
    }
    
}
