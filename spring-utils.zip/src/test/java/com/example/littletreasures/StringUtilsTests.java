package com.example.littletreasures;

import org.junit.jupiter.api.Test;
import org.springframework.util.StringUtils;

// https://github.com/spring-projects/spring-framework/blob/main/spring-core/src/test/java/org/springframework/util/StringUtilsTests.java
class StringUtilsTests {

    @Test
    void testStringUtils() {
        // Check if a string is empty or null
        System.out.println("Is empty: " + StringUtils.isEmpty("")); // true
        System.out.println("Is empty: " + StringUtils.isEmpty(null)); // true
        System.out.println("Is empty: " + StringUtils.isEmpty("not empty")); // false

        // Check if a string has text (not empty and not just whitespace)
        System.out.println("Has text: " + StringUtils.hasText("")); // false
        System.out.println("Has text: " + StringUtils.hasText(" ")); // false
        System.out.println("Has text: " + StringUtils.hasText("text")); // true

        // Check if a string starts with a specific prefix
        System.out.println("Starts with 'Hello': " + StringUtils.startsWithIgnoreCase("Hello World", "hello")); // true

        // Split a string into an array using a delimiter
        String[] parts = StringUtils.delimitedListToStringArray("apple,banana,orange", ",");
        System.out.println("Split array: " + String.join("-", parts)); // apple-banana-orange

        // Join an array of strings into a single string with a delimiter
        String joined = StringUtils.arrayToDelimitedString(new String[]{"apple", "banana", "orange"}, "; ");
        System.out.println("Joined string: " + joined); // apple; banana; orange

        // Replace all occurrences of a substring
         String replaced = StringUtils.replace("Hello World, Hello", "Hello", "Hi");
         System.out.println("Replaced string: " + replaced); // Hi World, Hi

        // Delete all occurrences of a substring
        String deleted = StringUtils.delete("Hello World, Hello", "Hello");
        System.out.println("Deleted string: " + deleted); // World, 

        // Trim whitespace from a string
        System.out.println("Trimmed string: " + StringUtils.trimWhitespace("  some text  ")); // some text
    }
    
}
