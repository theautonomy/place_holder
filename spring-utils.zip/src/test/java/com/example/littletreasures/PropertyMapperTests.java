package com.example.littletreasures;

    
import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.PropertyMapper;
import java.time.Duration;

// https://github.com/spring-projects/spring-boot/blob/main/spring-boot-project/spring-boot/src/test/java/org/springframework/boot/context/properties/PropertyMapperTests.java

class PropertyMapperTests {

    public static class Source {
        private String name;
        private Duration timeout;
        private boolean enabled;

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public Duration getTimeout() { return timeout; }
        public void setTimeout(Duration timeout) { this.timeout = timeout; }
        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
    }

    public static class Destination {
        private String name;
        private int timeoutSecs;
        private boolean disabled;

        public void setName(String name) { this.name = name; }
        public void setTimeoutSecs(int timeoutSecs) { this.timeoutSecs = timeoutSecs; }
        public void setDisabled(boolean disabled) { this.disabled = disabled; }
    }

    @Test
    void testPropertyMapper() {
        Source source = new Source();
        source.setName("example");
        source.setTimeout(Duration.ofSeconds(30));
        source.setEnabled(false);

        Destination destination = new Destination();

        PropertyMapper map = PropertyMapper.get();
        map.from(source::getName).to(destination::setName);
        map.from(source::getTimeout).whenNonNull().asInt(Duration::getSeconds).to(destination::setTimeoutSecs);
        map.from(source::isEnabled).whenFalse().toCall(() -> { destination.setDisabled(true);});

        System.out.println("Destination Name: " + destination.name);
        System.out.println("Destination Timeout (seconds): " + destination.timeoutSecs);
        System.out.println("Destination Disabled: " + destination.disabled);
    }
}
