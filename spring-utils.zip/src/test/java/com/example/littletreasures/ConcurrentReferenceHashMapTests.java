package com.example.littletreasures;

import org.junit.jupiter.api.Test;
import org.springframework.util.ConcurrentReferenceHashMap;
import java.lang.ref.ReferenceQueue;

import org.springframework.util.ConcurrentReferenceHashMap.ReferenceType;

// https://github.com/spring-projects/spring-framework/blob/main/spring-core/src/test/java/org/springframework/util/ConcurrentReferenceHashMapTests.java

public class ConcurrentReferenceHashMapTests {

    @Test
    void test() throws InterruptedException {
        // Create a ConcurrentReferenceHashMap with soft keys and values
        ConcurrentReferenceHashMap<String, Integer> map = new ConcurrentReferenceHashMap<>(16, ReferenceType.SOFT);

        // Add some entries
        map.put("one", 1);
        map.put("two", 2);
        map.put("three", 3);

        // Retrieve values
        System.out.println("Value for key 'one': " + map.get("one"));
        System.out.println("Value for key 'two': " + map.get("two"));

        // Simulate garbage collection to potentially clear soft references
        System.gc();
        Thread.sleep(100); // Allow time for GC to take effect

        // Check if values are still present after potential GC
        System.out.println("Value for key 'one' after GC: " + map.get("one")); 
        System.out.println("Map size after GC: " + map.size());

        // Example with a ReferenceQueue to monitor reclaimed entries
        // ReferenceQueue<String> queue = new ReferenceQueue<>();
        // ConcurrentReferenceHashMap<String, Integer> mapWithQueue = new ConcurrentReferenceHashMap<>(16, ReferenceType.SOFT, queue);
        // mapWithQueue.put("four", 4);
        // System.gc();
        // Thread.sleep(100);
        // System.out.println("poll queue: " + queue.poll());
    }
}