package com.example.littletreasures;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.util.TestPropertyValues;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;

// https://github.com/spring-projects/spring-boot/blob/ddfdc481612d2d7a662e7236b2831661541f344e/spring-boot-project/spring-boot-actuator/src/test/java/org/springframework/boot/actuate/env/EnvironmentEndpointTests.java#L96
@SpringBootTest
@ContextConfiguration(initializers = PropertyTests.MyPropertyInitializer.class)
@TestPropertySource(properties = {
      "label=name",
      "size=10"
})
@TestPropertySource("classpath:test.properties")
public class PropertyTests {

    @Autowired
    private ApplicationContext context;

    @Test
    public void test() {
        assertThat(this.context.getEnvironment().getProperty("foo")).isEqualTo("bar");
        assertThat(this.context.getEnvironment().getProperty("label")).isEqualTo("name");
        assertThat(this.context.getEnvironment().getProperty("size")).isEqualTo("10");
        assertThat(this.context.getEnvironment().getProperty("game")).isEqualTo("nfl");
    }

    static class MyPropertyInitializer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {
            TestPropertyValues.of("foo=bar").applyTo(applicationContext);
        }

    }

}
