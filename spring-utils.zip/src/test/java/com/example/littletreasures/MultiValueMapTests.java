package com.example.littletreasures;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

// https://github.com/spring-projects/spring-framework/blob/main/spring-core/src/test/java/org/springframework/util/MultiValueMapTests.java

public class MultiValueMapTests {

    @Test
    void testMultiValueMap() {
        Map<String, List<String>> map = new HashMap<>();
        map.put("rollNo", Arrays.asList("4", "2", "4","7", "2", "3"));
        map.put("name", Arrays.asList("John", "Alex", "Maria", "Jack"));
        map.put("hobbies", Arrays.asList("Badminton", "Reading novels", "Painting", "Cycling"));

        MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
        for (Map.Entry<String, List<String>> entry : map.entrySet()) {
            multiValueMap.put(entry.getKey(), entry.getValue());
        }

        multiValueMap.entrySet().stream().forEach(entry -> {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        });

        multiValueMap = CollectionUtils.toMultiValueMap(map);
        multiValueMap.entrySet().stream().forEach(entry -> {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        });

        multiValueMap = map.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey,
                Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedMultiValueMap::new));

        multiValueMap.entrySet().stream().forEach(entry -> {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        });

    }
}
