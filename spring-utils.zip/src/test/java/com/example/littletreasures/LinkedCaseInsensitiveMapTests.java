package com.example.littletreasures;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.util.LinkedCaseInsensitiveMap;

// https://github.com/spring-projects/spring-framework/blob/main/spring-core/src/test/java/org/springframework/util/LinkedCaseInsensitiveMapTests.java

class LinkedCaseInsensitiveMapTests {

    @Test
    void testLinkedCaseInsensitiveMap() {
        Map<String, Integer> linkedHashMap = new LinkedCaseInsensitiveMap<>();

        linkedHashMap.put("abc", 1);
        linkedHashMap.put("ABC", 2);
        assertEquals(1, linkedHashMap.size());
        assertEquals(2, linkedHashMap.get("aBc").intValue());
        assertEquals(2, linkedHashMap.get("ABc").intValue());
        linkedHashMap.remove("aBC");
        assertEquals(0, linkedHashMap.size());

        linkedHashMap.put("abc", 1);
        linkedHashMap.put("ABC", 2);
        assertEquals(1, linkedHashMap.size());
        assertEquals(2, linkedHashMap.get("aBc").intValue());
        assertEquals(2, linkedHashMap.get("ABc").intValue());

        // Now newMap is not a case-insensitive app anymore
        Map<String, Integer> newMap = Map.copyOf(linkedHashMap);
        // newMap.put("abc", 1);
        assertEquals(1, newMap.size());
        System.out.println(newMap);
        assertEquals(2, newMap.get("ABC").intValue());
         assertThatNullPointerException()
                .isThrownBy(() -> newMap.get("ABc").intValue());
 
    }

}

