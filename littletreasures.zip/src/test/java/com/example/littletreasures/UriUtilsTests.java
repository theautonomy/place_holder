package com.example.littletreasures;

import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.Test;
import org.springframework.web.util.UriUtils;

// https://github.com/spring-projects/spring-framework/blob/main/spring-web/src/test/java/org/springframework/web/util/UriUtilsTests.java

class UriUtilsTests {

    @Test
    void testUriUtils() {
        String pathSegment = "path with spaces and +";
        String queryParam = "query with spaces and /";

        // Encoding a path segment
        String encodedPathSegment = UriUtils.encodePathSegment(pathSegment, StandardCharsets.UTF_8);
        System.out.println("Encoded path segment: " + encodedPathSegment);
        // Output: Encoded path segment: path%20with%20spaces%20and%20+

        // Encoding a query parameter
        String encodedQueryParam = UriUtils.encodeQueryParam(queryParam, StandardCharsets.UTF_8);
        System.out.println("Encoded query parameter: " + encodedQueryParam);
        // Output: Encoded query parameter: query%20with%20spaces%20and%2F

         //Encoding a fragment
        String fragment = "fragment with spaces and #";
        String encodedFragment = UriUtils.encodeFragment(fragment, StandardCharsets.UTF_8);
        System.out.println("Encoded fragment: " + encodedFragment);
        // Output: Encoded fragment: fragment%20with%20spaces%20and%20%23


        // Decoding a URI component
        String encodedUri = "path%20with%20spaces%20and%20+%3Fquery%20with%20spaces%20and%2F";
        String decodedUri = UriUtils.decode(encodedUri, StandardCharsets.UTF_8);
         System.out.println("Decoded URI component: " + decodedUri);
        // Output: Decoded URI component: path with spaces and +?query with spaces and /
    }
    
}
