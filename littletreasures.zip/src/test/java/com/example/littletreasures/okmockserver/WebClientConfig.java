package com.example.littletreasures.okmockserver;

import java.time.Duration;

import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.netty.http.client.HttpClient;

public class WebClientConfig {

    public static WebClient createWebClientWithTimeout(int timeoutInSeconds) {
        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(timeoutInSeconds))))
                .build();
    }
}
