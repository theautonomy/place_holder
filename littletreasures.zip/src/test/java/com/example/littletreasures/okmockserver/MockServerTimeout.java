package com.example.littletreasures.okmockserver;

import okhttp3.mockwebserver.MockWebServer;

public class MockServerTimeout {

    public static void setMockServerTimeout(MockWebServer mockWebServer) {
        mockWebServer.setDispatcher(new TimeoutDispatcher());
    }
}
