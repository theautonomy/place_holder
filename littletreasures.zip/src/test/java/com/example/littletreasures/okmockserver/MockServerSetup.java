package com.example.littletreasures.okmockserver;

import java.io.IOException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;

import okhttp3.mockwebserver.MockWebServer;

public class MockServerSetup {

    private static MockWebServer mockWebServer;

    @BeforeAll
    static void setup() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    public static MockWebServer getMockWebServer() {
        return mockWebServer;
    }
}
