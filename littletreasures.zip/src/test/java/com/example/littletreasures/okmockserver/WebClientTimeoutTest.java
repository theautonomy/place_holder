package com.example.littletreasures.okmockserver;

import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import okhttp3.mockwebserver.MockWebServer;

public class WebClientTimeoutTest extends MockServerSetup {

    @Test
    void testWebClientTimeout() {
        MockWebServer mockWebServer = getMockWebServer();
        MockServerTimeout.setMockServerTimeout(mockWebServer);

        WebClient webClient = WebClientConfig.createWebClientWithTimeout(1);

        String baseUrl = String.format("http://localhost:%s", mockWebServer.getPort());

        assertThrows(WebClientResponseException.class, () -> {
            webClient.get()
                    .uri(baseUrl + "/resource")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
        });
    }
}
