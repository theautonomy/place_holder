package com.example.littletreasures.okmockserver;

import java.util.concurrent.TimeUnit;

import org.jetbrains.annotations.NotNull;

import okhttp3.Headers;
import okhttp3.mockwebserver.Dispatcher;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.RecordedRequest;

public class TimeoutDispatcher extends Dispatcher {

    @Override
    public MockResponse dispatch(@NotNull RecordedRequest request) {
        return new MockResponse()
                .setHeaders(new Headers.Builder().add("Content-Type", "application/json").build())
                .setBody("{\"message\": \"Delayed response\"}")
                .setBodyDelay(5, TimeUnit.SECONDS); // Delay response by 5 seconds
    }
}
