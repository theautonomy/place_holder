package com.example.littletreasures;

// https://github.com/spring-projects/spring-framework/blob/main/spring-core/src/test/java/org/springframework/util/FileCopyUtilsTests.java 

class FileCopyUtilsTests {
    
}
