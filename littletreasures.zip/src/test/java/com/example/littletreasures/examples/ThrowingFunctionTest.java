package com.example.littletreasures.examples;


import java.net.URI;
import java.net.URISyntaxException;
import java.util.stream.Stream;

import org.springframework.util.function.ThrowingFunction;

public class ThrowingFunctionTest {

    public static void main(String[] args) {
        Stream<String> paths = Stream.of(
                "https://www.example.com",
                "invalid URL",
                "ftp://fileserver"
        );

        // Using ThrowingFunction to handle checked exceptions in a stream
        Stream<URI> uris = paths.map(ThrowingFunction.of(ThrowingFunctionTest::checkedUri));

        uris.forEach(uri -> {
            try {
                System.out.println(uri);
            } catch (RuntimeException e) {
                System.err.println("Error processing URI: " + e.getMessage());
            }
        });

        // Using ThrowingFunction with a custom exception wrapper
        Stream<String> morePaths = Stream.of("file:///path/to/file", "another invalid URL");
        Stream<URI> moreUris = morePaths.map(ThrowingFunction.of(
                ThrowingFunctionTest::checkedUri,
                (message, exception) -> new IllegalArgumentException("Invalid URI: " + message, exception)
        ));

         moreUris.forEach(uri -> {
            try {
                System.out.println(uri);
            } catch (IllegalArgumentException e) {
                System.err.println("Custom error processing URI: " + e.getMessage());
            }
        });
    }

    // Method that throws a checked exception
    public static URI checkedUri(String path) throws URISyntaxException {
        return new URI(path);
    }
}