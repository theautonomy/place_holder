package com.example.littletreasures.examples;

import java.beans.PropertyDescriptor;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ResolvableType;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.util.*;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class JoshExample {

    private static Logger log = LoggerFactory.getLogger(JoshExample.class);

    @Component
    public static class DemoClass {

        @PostConstruct
        public void begin() {
            log.info("DemoClass begin()");
        }

        private final List<Map<String, Object>> list = new ArrayList<>();

        // private final List<Map<String, Object>> list = null;

        public List<Map<String, Object>> getList() {
            return list;
        }

        public DemoClass() {}
    }

    @Bean
    ApplicationListener<ApplicationReadyEvent> ready(DemoClass demo) {
        return event -> {
            log.info("application listener ready()");
            Assert.notNull(demo.getList(), "the list can't be null");

            beansUtils(demo);
            classUtils();
            systemPropertyUtils();
            fileCopyUtils();
            aop(demo);
            reflection();
            ensure();
            collections();
            serialize();
        };
    }

    private void ensure() {
        int counter = 2;
        Assert.state(counter == 2, () -> "the counter should be 2 or more. Was " + counter);
        Assert.hasText("Hello, world!", () -> "this string should be a non-null, non-empty String");
    }

    private void reflection() {

        ReflectionUtils.doWithFields(
                DemoClass.class, field -> log.info("field = " + field.toString()));
        ReflectionUtils.doWithMethods(
                DemoClass.class, method -> log.info("method = " + method.toString()));

        Field list = ReflectionUtils.findField(DemoClass.class, "list");
        log.info(Objects.requireNonNull(list).toString());

        ResolvableType rt = ResolvableType.forField(list);
        log.info(rt.toString());
    }

    private void aop(DemoClass demoClass) {
        Class<?> targetClass = AopUtils.getTargetClass(demoClass);
        log.info("Class<?> is " + targetClass);
        log.info("is AOP proxy? " + AopUtils.isAopProxy(demoClass));
        log.info("is CGlib proxy? " + AopUtils.isCglibProxy(demoClass));
    }

    private void collections() {
        Collection<String> names = Arrays.asList("Tammie", "Kimly", "Josh");
        boolean contains = CollectionUtils.containsAny(names, Arrays.asList("Josh"));
        Assert.state(
                contains,
                () -> "one or more of the names in " + names.toString() + " should be present");
    }

    private void serialize() {
        Customer in = new Customer(593232329, "Josh");
        byte[] bytes = SerializationUtils.serialize(in);
        Customer out = (Customer) SerializationUtils.deserialize(bytes);
        Assert.state(
                out.getId() == in.getId() && out.getName().equals(in.getName()),
                () -> "the " + Customer.class.getName() + " did not serialize correctlyy");
    }

    private void fileCopyUtils() {
        Resource cpr = new ClassPathResource("/application.properties");
        try (Reader r = new InputStreamReader(cpr.getInputStream())) {
            String contents = FileCopyUtils.copyToString(r);
            log.info("application.properties contents: " + contents);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void systemPropertyUtils() {
        String resolvedText =
                SystemPropertyUtils.resolvePlaceholders("my home directory is ${user.home}");
        log.info("resolved text: " + resolvedText);
    }

    private void classUtils() {
        Constructor<DemoClass> demoClassConstructor =
                ClassUtils.getConstructorIfAvailable(DemoClass.class);
        log.info("demoClassConstructor: " + demoClassConstructor);
        try {
            DemoClass demoClass = demoClassConstructor.newInstance();
            log.info("newInstance'd demoClass: " + demoClass);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void beansUtils(DemoClass demo) {
        PropertyDescriptor[] descriptors = BeanUtils.getPropertyDescriptors(demo.getClass());
        for (PropertyDescriptor pd : descriptors) {
            log.info("pd: " + pd.getName());
        }
    }

    public static void main(String[] args) {
        SpringApplication.run(JoshExample.class, args);
    }
}

// @Data
class Customer implements Serializable {

    static final long serialVersionUID = 1L;

    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public Customer(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
