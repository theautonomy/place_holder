package com.example.pdfsearch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
@RequestMapping("/api")
public class SearchController {

    @Autowired
    private DocumentService documentService;

    @Autowired
    private SearchService searchService;

    @PostMapping("/upload")
    @ResponseBody
    public ResponseEntity<String> uploadPdf(@RequestParam("file") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("Please select a file to upload");
            }

            if (!file.getContentType().equals("application/pdf")) {
                return ResponseEntity.badRequest().body("Please upload a PDF file");
            }

            String result = documentService.uploadAndProcessPdf(file);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error processing file: " + e.getMessage());
        }
    }

    @PostMapping("/search")
    public String search(@RequestParam("query") String query,
                        @RequestParam(value = "topK", defaultValue = "5") int topK,
                        Model model) {
        try {
            List<SearchResult> results = searchService.performSimilaritySearch(query, topK);
            model.addAttribute("results", results);
            model.addAttribute("query", query);
            return "search-results";
        } catch (Exception e) {
            model.addAttribute("error", "Error performing search: " + e.getMessage());
            return "search-results";
        }
    }
}