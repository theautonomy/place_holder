package net.springio.chatpdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatpdfSpringAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatpdfSpringAiApplication.class, args);
	}

}
