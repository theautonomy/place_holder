package net.springio.chatpdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatpdfSpringAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
