package com.example.openai.image.generator.ui;

import java.util.Map;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DiagramController {

    private final ChatClient chatClient;

    public DiagramController(ChatClient.Builder chatClientBuilder) {
        this.chatClient =
                chatClientBuilder
                        .defaultSystem(
                                """
                        You are an expert at creating Mermaid.js diagrams. When given a description,
                        you generate clean, well-structured Mermaid diagram code.

                        Rules:
                        - Only output the Mermaid code, no explanations or markdown code blocks
                        - Use clear, readable node names
                        - Keep diagrams organized and easy to understand
                        - Use appropriate diagram types based on the request
                        """)
                        .build();
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute(
                "request", new DiagramRequest("", "flowchart", "", "#ffffff", "default", "auto"));
        return "diagram";
    }

    @PostMapping("/")
    public String generate(DiagramRequest request, Model model) {
        model.addAttribute("request", request);

        if (request.description() == null || request.description().isBlank()) {
            model.addAttribute("error", "Please provide a diagram description");
            return "diagram";
        }

        try {
            long startTime = System.currentTimeMillis();

            String diagramType = request.diagramType();
            String detectedType = null;

            // Smart mode: auto-detect the best diagram type
            if ("smart".equals(diagramType)) {
                detectedType = detectDiagramType(request.description());
                diagramType = detectedType;
            }

            // Create a new request with the resolved diagram type
            DiagramRequest resolvedRequest =
                    new DiagramRequest(
                            request.description(),
                            diagramType,
                            request.title(),
                            request.bgColor(),
                            request.theme(),
                            request.size());

            String prompt = buildPrompt(resolvedRequest);
            String mermaidCode = chatClient.prompt().user(prompt).call().content();

            // Clean up the response - remove markdown code blocks if present
            mermaidCode = cleanMermaidCode(mermaidCode);

            long endTime = System.currentTimeMillis();
            double generationTime = (endTime - startTime) / 1000.0;

            model.addAttribute("mermaidCode", mermaidCode);
            model.addAttribute("generationTime", String.format("%.2f", generationTime));
            model.addAttribute("diagramType", diagramType);
            model.addAttribute("detectedType", detectedType);

        } catch (Exception e) {
            model.addAttribute("error", "Error generating diagram: " + e.getMessage());
        }

        return "diagram";
    }

    @PostMapping("/refine")
    @ResponseBody
    public Map<String, String> refine(
            @RequestParam String currentCode, @RequestParam String instructions) {
        try {
            String prompt =
                    """
                    You are an expert at improving Mermaid.js diagrams.

                    Current Mermaid diagram code:
                    ```
                    %s
                    ```

                    User's refinement request: %s

                    Improve the diagram based on the user's request. If no specific request is given,
                    add more detail and improve clarity.

                    Rules:
                    - Keep the same diagram type
                    - Maintain existing structure where appropriate
                    - Only output the improved Mermaid code, no explanations
                    """
                            .formatted(
                                    currentCode,
                                    instructions.isBlank()
                                            ? "Add more detail and improve the diagram"
                                            : instructions);

            String refined = chatClient.prompt().user(prompt).call().content();
            refined = cleanMermaidCode(refined);

            return Map.of("mermaidCode", refined);
        } catch (Exception e) {
            return Map.of("error", e.getMessage());
        }
    }

    private String detectDiagramType(String description) {
        String prompt =
                """
                Analyze this description and determine the most appropriate Mermaid diagram type.

                Description: %s

                Available diagram types:
                - flowchart: For processes, workflows, decision trees, algorithms
                - sequence: For interactions between systems/people over time, API calls, message flows
                - classDiagram: For object-oriented structures, class relationships, data models
                - stateDiagram: For state machines, status transitions, lifecycle stages
                - erDiagram: For database schemas, entity relationships, data structures
                - journey: For user journeys, customer experiences, process satisfaction
                - gantt: For project timelines, schedules, task planning
                - pie: For proportions, percentages, distribution data
                - mindmap: For brainstorming, hierarchical ideas, concept mapping
                - timeline: For historical events, chronological sequences
                - gitgraph: For version control flows, branching strategies
                - quadrantChart: For priority matrices, comparisons on two axes
                - sankey: For flow quantities, resource distribution
                - block: For system architectures, component layouts

                Respond with ONLY the diagram type name (e.g., "flowchart" or "sequence"), nothing else.
                """
                        .formatted(description);

        String response = chatClient.prompt().user(prompt).call().content();
        String detected = response.trim().toLowerCase().replaceAll("[^a-z]", "");

        // Validate and default to flowchart if invalid
        return switch (detected) {
            case "flowchart",
                    "sequence",
                    "classdiagram",
                    "statediagram",
                    "erdiagram",
                    "journey",
                    "gantt",
                    "pie",
                    "mindmap",
                    "timeline",
                    "gitgraph",
                    "quadrantchart",
                    "sankey",
                    "block" -> {
                // Normalize case for certain types
                yield switch (detected) {
                    case "classdiagram" -> "classDiagram";
                    case "statediagram" -> "stateDiagram";
                    case "erdiagram" -> "erDiagram";
                    case "quadrantchart" -> "quadrantChart";
                    default -> detected;
                };
            }
            default -> "flowchart";
        };
    }

    private String buildPrompt(DiagramRequest request) {
        String diagramTypeInstruction =
                switch (request.diagramType()) {
                    case "flowchart" -> """
                Create a flowchart. Example syntax:
                flowchart TD
                    A[Start] --> B[Process]
                    B --> C{Decision}
                    C -->|Yes| D[End]
                    C -->|No| B
                Use TD (top-down), LR (left-right), or other directions as appropriate.""";

                    case "sequence" -> """
                Create a sequence diagram. Example syntax:
                sequenceDiagram
                    participant A
                    participant B
                    A->>B: Hello B, how are you?
                    B-->>A: Great!
                Use ->> for solid arrows, -->> for dotted arrows.""";

                    case "classDiagram" -> """
                Create a class diagram. Example syntax:
                classDiagram
                    class Animal {
                        +int age
                        +String gender
                        +isMammal()
                    }
                    class Dog {
                        +String breed
                        +bark()
                    }
                    Animal <|-- Dog
                Use <|-- for inheritance, --> for association.""";

                    case "stateDiagram" -> """
                Create a state diagram. Example syntax:
                stateDiagram-v2
                    [*] --> Still
                    Still --> Moving
                    Moving --> Still
                    Moving --> Crash
                    Crash --> [*]
                Use [*] for start/end states.""";

                    case "erDiagram" -> """
                Create an entity relationship diagram. Example syntax:
                erDiagram
                    CUSTOMER ||--o{ ORDER : places
                    ORDER ||--|{ LINE-ITEM : contains
                    PRODUCT ||--o{ LINE-ITEM : "is in"
                Use ||--o{ for one-to-many, ||--|{ for one-to-many (required).""";

                    case "journey" -> """
                Create a user journey diagram. Example syntax:
                journey
                    title My Working Day
                    section Go to work
                        Make tea: 5: Me
                        Go upstairs: 3: Me
                    section Go home
                        Go downstairs: 5: Me
                Score is 1-5, higher is better.""";

                    case "gantt" -> """
                Create a Gantt chart. Example syntax:
                gantt
                    title A Gantt Diagram
                    dateFormat YYYY-MM-DD
                    section Section
                        A task: a1, 2024-01-01, 30d
                        Another task: after a1, 20d""";

                    case "pie" -> """
                Create a pie chart. Example syntax:
                pie title Pets adopted by volunteers
                    "Dogs" : 386
                    "Cats" : 85
                    "Rats" : 15""";

                    case "mindmap" -> """
                Create a mind map. Example syntax:
                mindmap
                    root((Central Topic))
                        Branch 1
                            Sub-topic 1
                            Sub-topic 2
                        Branch 2
                            Sub-topic 3""";

                    case "timeline" -> """
                Create a timeline diagram. Example syntax:
                timeline
                    title History of Events
                    2020 : Event 1
                    2021 : Event 2
                         : Event 3
                    2022 : Event 4""";

                    case "gitgraph" -> """
                Create a git graph. Example syntax:
                gitgraph
                    commit id: "Initial"
                    branch develop
                    commit id: "Feature A"
                    checkout main
                    merge develop
                    commit id: "Release v1.0"
                """;

                    case "quadrantChart" -> """
                Create a quadrant chart. Example syntax:
                quadrantChart
                    title Reach and engagement
                    x-axis Low Reach --> High Reach
                    y-axis Low Engagement --> High Engagement
                    quadrant-1 We should expand
                    quadrant-2 Need to promote
                    quadrant-3 Re-evaluate
                    quadrant-4 May be improved
                    Campaign A: [0.3, 0.6]
                    Campaign B: [0.7, 0.8]""";

                    case "sankey" -> """
                Create a sankey diagram. Example syntax:
                sankey-beta

                Agricultural 'waste',Bio-conversion,124.729
                Bio-conversion,Liquid,0.597
                Bio-conversion,Losses,26.862
                Bio-conversion,Solid,280.322
                Bio-conversion,Gas,81.144""";

                    case "block" -> """
                Create a block diagram. Example syntax:
                block-beta
                    columns 3
                    a["Block A"] b["Block B"] c["Block C"]
                    d["Block D"]:2 e["Block E"]
                Use columns to set layout width.""";

                    default -> "Create an appropriate Mermaid diagram";
                };

        String titleInstruction = "";
        if (request.title() != null && !request.title().isBlank()) {
            titleInstruction = "\nInclude this title in the diagram: " + request.title();
        }

        return """
                %s

                Based on this description:
                %s
                %s
                Generate only the Mermaid code, no explanations.
                """
                .formatted(diagramTypeInstruction, request.description(), titleInstruction);
    }

    private String cleanMermaidCode(String code) {
        if (code == null) return "";

        String cleaned = code.trim();

        // Remove markdown code blocks if present
        if (cleaned.startsWith("```mermaid")) {
            cleaned = cleaned.substring(10);
        } else if (cleaned.startsWith("```")) {
            cleaned = cleaned.substring(3);
        }

        if (cleaned.endsWith("```")) {
            cleaned = cleaned.substring(0, cleaned.length() - 3);
        }

        return cleaned.trim();
    }
}
