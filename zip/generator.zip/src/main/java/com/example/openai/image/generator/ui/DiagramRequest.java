package com.example.openai.image.generator.ui;

public record DiagramRequest(
        String description,
        String diagramType,
        String title,
        String bgColor,
        String theme,
        String size) {
    public DiagramRequest {
        if (description == null) description = "";
        if (diagramType == null || diagramType.isBlank()) diagramType = "flowchart";
        if (title == null) title = "";
        if (bgColor == null || bgColor.isBlank()) bgColor = "#ffffff";
        if (theme == null || theme.isBlank()) theme = "default";
        if (size == null || size.isBlank()) size = "auto";
    }
}
