package com.example.openai.image.generator.ui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAiImageGenApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAiImageGenApplication.class, args);
    }
}
