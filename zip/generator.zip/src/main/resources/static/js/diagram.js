// Diagram.js - Main JavaScript for AI Diagram Generator
// Configuration is passed via window.diagramConfig from the template

(function() {
    'use strict';

    // Get configuration from template
    const config = window.diagramConfig || {};
    const currentTheme = config.theme || 'default';
    const currentBgColor = config.bgColor || '#ffffff';

    // Initialize Mermaid
    mermaid.initialize({
        startOnLoad: true,
        theme: currentTheme,
        flowchart: {
            htmlLabels: true,
            curve: 'basis'
        },
        sequence: {
            diagramMarginX: 50,
            diagramMarginY: 10,
            actorMargin: 50,
            width: 150,
            height: 65
        }
    });

    // Handle generate form submission
    const generateForm = document.getElementById('generateForm');
    const generateBtn = document.getElementById('generateBtn');
    if (generateForm && generateBtn) {
        generateForm.addEventListener('submit', function() {
            generateBtn.disabled = true;
            generateBtn.textContent = 'Generating...';
        });
    }

    // Handle copy button click
    const copyBtn = document.getElementById('copyBtn');
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const codeEditor = document.getElementById('mermaidCodeEditor');
            navigator.clipboard.writeText(codeEditor.value).then(() => {
                const originalText = this.textContent;
                this.textContent = 'Copied!';
                setTimeout(() => {
                    this.textContent = originalText;
                }, 2000);
            });
        });
    }

    // Handle code editor changes - re-render diagram
    const codeEditor = document.getElementById('mermaidCodeEditor');
    const diagramContainer = document.getElementById('mermaidDiagram');

    if (codeEditor && diagramContainer) {
        let debounceTimer;

        codeEditor.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(async () => {
                const code = codeEditor.value.trim();
                if (!code) return;

                try {
                    // Clear previous diagram
                    diagramContainer.innerHTML = code;
                    diagramContainer.removeAttribute('data-processed');

                    // Re-render with mermaid
                    await mermaid.run({ nodes: [diagramContainer] });
                } catch (e) {
                    // Show error in diagram container
                    diagramContainer.innerHTML = '<div style="color: #ff6b6b; padding: 1rem;">Syntax error: ' + e.message + '</div>';
                }
            }, 500); // Debounce 500ms
        });
    }

    // Size configurations for downloads
    const sizeConfig = {
        'auto': null,  // Use natural size
        'small': 400,
        'medium': 600,
        'large': 800,
        'xlarge': 1000
    };

    function getDownloadSize() {
        const size = document.getElementById('size').value;
        return sizeConfig[size];
    }

    // Download SVG
    const downloadSvgBtn = document.getElementById('downloadSvgBtn');
    if (downloadSvgBtn) {
        downloadSvgBtn.addEventListener('click', function() {
            const svg = document.querySelector('#mermaidDiagram svg').cloneNode(true);
            if (!svg) {
                alert('No diagram to download');
                return;
            }

            const targetWidth = getDownloadSize();
            if (targetWidth) {
                const originalWidth = svg.viewBox.baseVal.width || svg.width.baseVal.value;
                const originalHeight = svg.viewBox.baseVal.height || svg.height.baseVal.value;
                const aspectRatio = originalHeight / originalWidth;
                const targetHeight = targetWidth * aspectRatio;

                svg.setAttribute('width', targetWidth);
                svg.setAttribute('height', targetHeight);
            }

            const svgData = new XMLSerializer().serializeToString(svg);
            const blob = new Blob([svgData], { type: 'image/svg+xml' });
            const url = URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.href = url;
            a.download = 'diagram.svg';
            a.click();

            URL.revokeObjectURL(url);
        });
    }

    // Download PNG
    const downloadPngBtn = document.getElementById('downloadPngBtn');
    if (downloadPngBtn) {
        downloadPngBtn.addEventListener('click', function() {
            const svg = document.querySelector('#mermaidDiagram svg');
            if (!svg) {
                alert('No diagram to download');
                return;
            }

            const svgClone = svg.cloneNode(true);
            const targetWidth = getDownloadSize();
            const scale = 2; // 2x for high DPI

            let canvasWidth, canvasHeight;

            if (targetWidth) {
                const originalWidth = svg.viewBox.baseVal.width || svg.width.baseVal.value || svg.getBoundingClientRect().width;
                const originalHeight = svg.viewBox.baseVal.height || svg.height.baseVal.value || svg.getBoundingClientRect().height;
                const aspectRatio = originalHeight / originalWidth;

                canvasWidth = targetWidth * scale;
                canvasHeight = (targetWidth * aspectRatio) * scale;

                svgClone.setAttribute('width', targetWidth);
                svgClone.setAttribute('height', targetWidth * aspectRatio);
            } else {
                const bbox = svg.getBoundingClientRect();
                canvasWidth = bbox.width * scale;
                canvasHeight = bbox.height * scale;
            }

            const svgData = new XMLSerializer().serializeToString(svgClone);
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const img = new Image();

            img.onload = function() {
                canvas.width = canvasWidth;
                canvas.height = canvasHeight;
                ctx.fillStyle = document.getElementById('bgColor').value;
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

                const a = document.createElement('a');
                a.href = canvas.toDataURL('image/png');
                a.download = 'diagram.png';
                a.click();
            };

            img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
        });
    }

    // Copy to clipboard
    const copyImageBtn = document.getElementById('copyImageBtn');
    if (copyImageBtn) {
        copyImageBtn.addEventListener('click', async function() {
            const svg = document.querySelector('#mermaidDiagram svg');
            if (!svg) {
                alert('No diagram to copy');
                return;
            }

            const originalText = copyImageBtn.textContent;
            copyImageBtn.textContent = 'Copying...';
            copyImageBtn.disabled = true;

            try {
                const svgClone = svg.cloneNode(true);
                const targetWidth = getDownloadSize();
                const scale = 2;

                let canvasWidth, canvasHeight;

                if (targetWidth) {
                    const originalWidth = svg.viewBox.baseVal.width || svg.width.baseVal.value || svg.getBoundingClientRect().width;
                    const originalHeight = svg.viewBox.baseVal.height || svg.height.baseVal.value || svg.getBoundingClientRect().height;
                    const aspectRatio = originalHeight / originalWidth;

                    canvasWidth = targetWidth * scale;
                    canvasHeight = (targetWidth * aspectRatio) * scale;

                    svgClone.setAttribute('width', targetWidth);
                    svgClone.setAttribute('height', targetWidth * aspectRatio);
                } else {
                    const bbox = svg.getBoundingClientRect();
                    canvasWidth = bbox.width * scale;
                    canvasHeight = bbox.height * scale;
                }

                const svgData = new XMLSerializer().serializeToString(svgClone);
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                const img = new Image();

                img.onload = async function() {
                    canvas.width = canvasWidth;
                    canvas.height = canvasHeight;
                    ctx.fillStyle = document.getElementById('bgColor').value;
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

                    try {
                        const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
                        await navigator.clipboard.write([
                            new ClipboardItem({ 'image/png': blob })
                        ]);
                        copyImageBtn.textContent = 'Copied!';
                        setTimeout(() => {
                            copyImageBtn.textContent = originalText;
                        }, 2000);
                    } catch (err) {
                        alert('Failed to copy: ' + err.message);
                        copyImageBtn.textContent = originalText;
                    }
                    copyImageBtn.disabled = false;
                };

                img.onerror = function() {
                    alert('Failed to load image');
                    copyImageBtn.textContent = originalText;
                    copyImageBtn.disabled = false;
                };

                img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
            } catch (e) {
                alert('Error: ' + e.message);
                copyImageBtn.textContent = originalText;
                copyImageBtn.disabled = false;
            }
        });
    }

    // Live background color update
    const bgColorInput = document.getElementById('bgColor');
    const diagramContainerEl = document.getElementById('diagramContainer');
    if (bgColorInput && diagramContainerEl) {
        bgColorInput.addEventListener('input', function() {
            diagramContainerEl.style.backgroundColor = this.value;
        });
    }

    // Live theme update
    const themeSelect = document.getElementById('theme');
    if (themeSelect && diagramContainer) {
        themeSelect.addEventListener('change', async function() {
            const codeEditor = document.getElementById('mermaidCodeEditor');
            if (!codeEditor) return;

            const code = codeEditor.value.trim();
            if (!code) return;

            try {
                mermaid.initialize({
                    startOnLoad: false,
                    theme: this.value
                });

                diagramContainer.innerHTML = code;
                diagramContainer.removeAttribute('data-processed');
                await mermaid.run({ nodes: [diagramContainer] });
            } catch (e) {
                console.error('Theme change error:', e);
            }
        });
    }

    // Live size update
    const sizeSelect = document.getElementById('size');
    if (sizeSelect && diagramContainerEl) {
        sizeSelect.addEventListener('change', function() {
            // Remove all size classes
            diagramContainerEl.classList.remove('size-auto', 'size-small', 'size-medium', 'size-large', 'size-xlarge');
            // Add selected size class
            diagramContainerEl.classList.add('size-' + this.value);
        });
    }

    // Refine diagram
    const refineBtn = document.getElementById('refineBtn');
    if (refineBtn) {
        refineBtn.addEventListener('click', async function() {
            const codeEditor = document.getElementById('mermaidCodeEditor');
            const refineInput = document.getElementById('refineInput');
            const currentCode = codeEditor.value.trim();
            const instructions = refineInput.value.trim();

            if (!currentCode) {
                alert('No diagram to refine');
                return;
            }

            refineBtn.disabled = true;
            refineBtn.textContent = 'Refining...';

            try {
                const formData = new FormData();
                formData.append('currentCode', currentCode);
                formData.append('instructions', instructions);

                const response = await fetch('/refine', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.error) {
                    alert('Error: ' + data.error);
                } else if (data.mermaidCode) {
                    // Update code editor
                    codeEditor.value = data.mermaidCode;

                    // Re-render diagram
                    diagramContainer.innerHTML = data.mermaidCode;
                    diagramContainer.removeAttribute('data-processed');
                    await mermaid.run({ nodes: [diagramContainer] });

                    // Clear refine input
                    refineInput.value = '';
                }
            } catch (e) {
                alert('Error: ' + e.message);
            } finally {
                refineBtn.disabled = false;
                refineBtn.textContent = 'Refine with AI';
            }
        });
    }

    // ===== Diagram History =====
    const HISTORY_KEY = 'diagramHistory';
    const MAX_HISTORY = 20;

    function getHistory() {
        try {
            return JSON.parse(localStorage.getItem(HISTORY_KEY)) || [];
        } catch {
            return [];
        }
    }

    function saveHistory(history) {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    }

    function addToHistory(diagram) {
        const history = getHistory();
        // Add to beginning
        history.unshift(diagram);
        // Keep only MAX_HISTORY items
        if (history.length > MAX_HISTORY) {
            history.pop();
        }
        saveHistory(history);
        renderHistory();
    }

    function deleteFromHistory(id) {
        const history = getHistory().filter(item => item.id !== id);
        saveHistory(history);
        renderHistory();
    }

    function clearHistory() {
        localStorage.removeItem(HISTORY_KEY);
        renderHistory();
    }

    function formatDate(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;

        // Less than 1 minute
        if (diff < 60000) return 'Just now';
        // Less than 1 hour
        if (diff < 3600000) return Math.floor(diff / 60000) + 'm ago';
        // Less than 24 hours
        if (diff < 86400000) return Math.floor(diff / 3600000) + 'h ago';
        // Otherwise show date
        return date.toLocaleDateString();
    }

    function renderHistory() {
        const historyList = document.getElementById('historyList');
        const historyEmpty = document.getElementById('historyEmpty');
        const history = getHistory();

        if (!historyList) return;

        // Clear existing items (except empty message)
        historyList.querySelectorAll('.history-item').forEach(el => el.remove());

        if (history.length === 0) {
            historyEmpty.style.display = 'block';
            return;
        }

        historyEmpty.style.display = 'none';

        history.forEach(item => {
            const div = document.createElement('div');
            div.className = 'history-item flex justify-between items-start p-3 bg-gray-100 dark:bg-white/5 border border-gray-300 dark:border-white/20 rounded-lg mb-2 cursor-pointer transition-all hover:border-cyan-400 hover:bg-cyan-400/10';

            const contentDiv = document.createElement('div');
            contentDiv.className = 'flex-1 min-w-0';

            const descDiv = document.createElement('div');
            descDiv.className = 'text-sm text-gray-900 dark:text-white truncate mb-1';
            descDiv.textContent = item.description || 'Untitled';

            const metaDiv = document.createElement('div');
            metaDiv.className = 'text-xs text-gray-400 flex gap-2';

            const typeSpan = document.createElement('span');
            typeSpan.className = 'bg-cyan-400/20 text-cyan-400 px-1.5 py-0.5 rounded';
            typeSpan.textContent = item.diagramType;

            const dateSpan = document.createElement('span');
            dateSpan.textContent = formatDate(item.id);

            metaDiv.appendChild(typeSpan);
            metaDiv.appendChild(dateSpan);
            contentDiv.appendChild(descDiv);
            contentDiv.appendChild(metaDiv);

            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'px-2 py-1 bg-transparent text-gray-400 border-none rounded text-sm cursor-pointer opacity-0 transition-all hover:bg-red-500/20 hover:text-red-500 group-hover:opacity-100';
            deleteBtn.setAttribute('data-id', item.id);
            deleteBtn.title = 'Delete';
            deleteBtn.textContent = 'x';

            // Show delete button on hover
            div.addEventListener('mouseenter', () => deleteBtn.style.opacity = '1');
            div.addEventListener('mouseleave', () => deleteBtn.style.opacity = '0');

            div.appendChild(contentDiv);
            div.appendChild(deleteBtn);

            // Click to load
            contentDiv.addEventListener('click', () => {
                loadDiagram(item);
            });

            // Delete button
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                deleteFromHistory(item.id);
            });

            historyList.appendChild(div);
        });
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async function loadDiagram(item) {
        // Update form fields
        document.getElementById('description').value = item.description || '';
        document.getElementById('diagramType').value = item.diagramType || 'flowchart';
        document.getElementById('title').value = item.title || '';
        document.getElementById('bgColor').value = item.bgColor || '#ffffff';
        document.getElementById('theme').value = item.theme || 'default';
        document.getElementById('size').value = item.size || 'auto';

        // Update code editor if it exists
        const codeEditor = document.getElementById('mermaidCodeEditor');
        const diagramEl = document.getElementById('mermaidDiagram');
        const diagramContainerEl = document.getElementById('diagramContainer');

        if (codeEditor && diagramEl) {
            codeEditor.value = item.mermaidCode;

            // Update background color
            if (diagramContainerEl) {
                diagramContainerEl.style.backgroundColor = item.bgColor || '#ffffff';
                // Update size class
                diagramContainerEl.className = diagramContainerEl.className.replace(/size-\w+/g, '');
                diagramContainerEl.classList.add('size-' + (item.size || 'auto'));
            }

            // Re-initialize mermaid with theme and render
            mermaid.initialize({
                startOnLoad: false,
                theme: item.theme || 'default'
            });

            diagramEl.innerHTML = item.mermaidCode;
            diagramEl.removeAttribute('data-processed');
            await mermaid.run({ nodes: [diagramEl] });
        } else {
            // No diagram area yet, submit form to generate
            document.getElementById('generateForm').submit();
        }
    }

    // Save current diagram to history on page load if we have one
    const currentMermaidCode = document.getElementById('mermaidCodeEditor')?.value;
    const currentDescription = document.getElementById('description')?.value;
    if (currentMermaidCode && currentDescription) {
        // Check if this exact diagram is already in history (avoid duplicates on refresh)
        const history = getHistory();
        const isDuplicate = history.some(item =>
            item.mermaidCode === currentMermaidCode &&
            item.description === currentDescription
        );

        if (!isDuplicate) {
            addToHistory({
                id: Date.now(),
                description: currentDescription,
                diagramType: document.getElementById('diagramType')?.value || 'flowchart',
                title: document.getElementById('title')?.value || '',
                bgColor: document.getElementById('bgColor')?.value || '#ffffff',
                theme: document.getElementById('theme')?.value || 'default',
                size: document.getElementById('size')?.value || 'auto',
                mermaidCode: currentMermaidCode
            });
        }
    }

    // Toggle history panel
    const historyHeader = document.getElementById('historyHeader');
    const historyToggle = document.getElementById('historyToggle');
    const historyList = document.getElementById('historyList');

    if (historyHeader && historyToggle && historyList) {
        // Load collapsed state from localStorage
        const isCollapsed = localStorage.getItem('historyCollapsed') === 'true';
        if (isCollapsed) {
            historyList.classList.add('collapsed');
            historyToggle.classList.add('collapsed');
        }

        historyHeader.addEventListener('click', (e) => {
            // Don't toggle if clicking clear button
            if (e.target.id === 'clearHistoryBtn') return;

            historyList.classList.toggle('collapsed');
            historyToggle.classList.toggle('collapsed');
            localStorage.setItem('historyCollapsed', historyList.classList.contains('collapsed'));
        });
    }

    // Clear history button
    const clearHistoryBtn = document.getElementById('clearHistoryBtn');
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (confirm('Clear all diagram history?')) {
                clearHistory();
            }
        });
    }

    // Initial render
    renderHistory();

    // ===== Import Modal =====
    const importModal = document.getElementById('importModal');
    const importBtn = document.getElementById('importBtn');
    const modalClose = document.getElementById('modalClose');
    const modalCancel = document.getElementById('modalCancel');
    const modalImport = document.getElementById('modalImport');
    const importCodeInput = document.getElementById('importCodeInput');

    function openModal() {
        importModal.classList.add('active');
        importCodeInput.value = '';
        importCodeInput.focus();
    }

    function closeModal() {
        importModal.classList.remove('active');
    }

    async function importCode() {
        const code = importCodeInput.value.trim();
        if (!code) {
            alert('Please paste some Mermaid code');
            return;
        }

        // Try to detect diagram type from the code
        let detectedType = 'flowchart';
        const firstLine = code.split('\n')[0].toLowerCase().trim();

        if (firstLine.startsWith('sequencediagram')) detectedType = 'sequence';
        else if (firstLine.startsWith('classdiagram')) detectedType = 'classDiagram';
        else if (firstLine.startsWith('statediagram')) detectedType = 'stateDiagram';
        else if (firstLine.startsWith('erdiagram')) detectedType = 'erDiagram';
        else if (firstLine.startsWith('journey')) detectedType = 'journey';
        else if (firstLine.startsWith('gantt')) detectedType = 'gantt';
        else if (firstLine.startsWith('pie')) detectedType = 'pie';
        else if (firstLine.startsWith('mindmap')) detectedType = 'mindmap';
        else if (firstLine.startsWith('timeline')) detectedType = 'timeline';
        else if (firstLine.startsWith('gitgraph')) detectedType = 'gitgraph';
        else if (firstLine.startsWith('quadrantchart')) detectedType = 'quadrantChart';
        else if (firstLine.startsWith('sankey')) detectedType = 'sankey';
        else if (firstLine.startsWith('block')) detectedType = 'block';
        else if (firstLine.startsWith('flowchart') || firstLine.startsWith('graph')) detectedType = 'flowchart';

        // Update form fields
        document.getElementById('diagramType').value = detectedType;
        document.getElementById('description').value = 'Imported diagram';

        const diagramEl = document.getElementById('mermaidDiagram');
        const diagramWrapper = document.getElementById('diagramWrapper');
        const placeholder = document.getElementById('placeholder');
        const downloadButtons = document.getElementById('downloadButtons');

        if (diagramEl) {
            // Show diagram wrapper first (mermaid needs visible element)
            if (placeholder) placeholder.style.display = 'none';
            if (diagramWrapper) diagramWrapper.style.display = 'block';
            if (downloadButtons) downloadButtons.style.display = 'flex';

            // Render the imported code
            diagramEl.innerHTML = code;
            diagramEl.removeAttribute('data-processed');

            try {
                await mermaid.run({ nodes: [diagramEl] });

                // Create code editor if it doesn't exist
                let codeEditor = document.getElementById('mermaidCodeEditor');
                if (!codeEditor) {
                    createCodeEditor(code);
                } else {
                    codeEditor.value = code;
                }

                // Save to history
                addToHistory({
                    id: Date.now(),
                    description: 'Imported diagram',
                    diagramType: detectedType,
                    title: '',
                    bgColor: document.getElementById('bgColor').value,
                    theme: document.getElementById('theme').value,
                    size: document.getElementById('size').value,
                    mermaidCode: code
                });

                closeModal();
            } catch (e) {
                alert('Invalid Mermaid code: ' + e.message);
            }
        }
    }

    function createCodeEditor(code) {
        const leftPanel = document.querySelector('.lg\\:sticky');
        const errorDiv = leftPanel ? leftPanel.querySelector('.bg-red-500\\/20') : null;
        const insertPoint = errorDiv || (leftPanel ? leftPanel.querySelector('.bg-white\\/10') : null);

        const codeSection = document.createElement('div');
        codeSection.className = 'mt-4';
        codeSection.innerHTML = '<div class="flex justify-between items-center mb-2"><span class="text-gray-400 text-sm font-medium">Mermaid Code (editable)</span><button type="button" class="px-3 py-1.5 bg-cyan-400/20 text-cyan-400 border border-cyan-400/30 rounded-md text-sm cursor-pointer transition-all hover:bg-cyan-400/30" id="copyBtn">Copy Code</button></div>';

        const textarea = document.createElement('textarea');
        textarea.className = 'w-full p-4 bg-black/30 border border-white/10 rounded-lg font-mono text-sm text-gray-400 resize-y min-h-[150px] focus:outline-none focus:border-blue-500';
        textarea.id = 'mermaidCodeEditor';
        textarea.rows = 10;
        textarea.value = code;

        codeSection.appendChild(textarea);

        if (errorDiv) {
            errorDiv.after(codeSection);
        } else {
            insertPoint.after(codeSection);
        }

        // Add copy button handler
        document.getElementById('copyBtn').addEventListener('click', function() {
            navigator.clipboard.writeText(textarea.value).then(() => {
                const originalText = this.textContent;
                this.textContent = 'Copied!';
                setTimeout(() => { this.textContent = originalText; }, 2000);
            });
        });

        // Add live edit handler
        textarea.addEventListener('input', function() {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = setTimeout(async () => {
                const diagramEl = document.getElementById('mermaidDiagram');
                const newCode = this.value.trim();
                if (!newCode || !diagramEl) return;

                try {
                    diagramEl.innerHTML = newCode;
                    diagramEl.removeAttribute('data-processed');
                    await mermaid.run({ nodes: [diagramEl] });
                } catch (e) {
                    diagramEl.innerHTML = '<div style="color: #ff6b6b; padding: 1rem;">Syntax error: ' + e.message + '</div>';
                }
            }, 500);
        });
    }

    if (importBtn) {
        importBtn.addEventListener('click', openModal);
    }

    if (modalClose) {
        modalClose.addEventListener('click', closeModal);
    }

    if (modalCancel) {
        modalCancel.addEventListener('click', closeModal);
    }

    if (modalImport) {
        modalImport.addEventListener('click', importCode);
    }

    // Close modal on overlay click
    if (importModal) {
        importModal.addEventListener('click', (e) => {
            if (e.target === importModal) {
                closeModal();
            }
        });
    }

    // ===== Fullscreen Mode =====
    const fullscreenOverlay = document.getElementById('fullscreenOverlay');
    const fullscreenContent = document.getElementById('fullscreenContent');
    const fullscreenBtn = document.getElementById('fullscreenBtn');
    const fullscreenClose = document.getElementById('fullscreenClose');

    function openFullscreen() {
        const svg = document.querySelector('#mermaidDiagram svg');
        if (!svg) {
            alert('No diagram to display');
            return;
        }

        // Clone the SVG for fullscreen display
        const svgClone = svg.cloneNode(true);
        svgClone.removeAttribute('style');
        svgClone.removeAttribute('width');
        svgClone.removeAttribute('height');

        fullscreenContent.innerHTML = '';
        fullscreenContent.appendChild(svgClone);
        fullscreenOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeFullscreen() {
        fullscreenOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (fullscreenBtn) {
        fullscreenBtn.addEventListener('click', openFullscreen);
    }

    if (fullscreenClose) {
        fullscreenClose.addEventListener('click', closeFullscreen);
    }

    // Close fullscreen on overlay click (outside content)
    if (fullscreenOverlay) {
        fullscreenOverlay.addEventListener('click', (e) => {
            if (e.target === fullscreenOverlay || e.target === fullscreenContent) {
                closeFullscreen();
            }
        });
    }

    // ===== Templates =====
    const templates = [
        {
            name: 'REST API Flow',
            type: 'sequence',
            desc: 'Client-server API request flow',
            code: 'sequenceDiagram\n    participant Client\n    participant API\n    participant Database\n    Client->>API: HTTP Request\n    API->>Database: Query\n    Database-->>API: Results\n    API-->>Client: JSON Response'
        },
        {
            name: 'User Authentication',
            type: 'flowchart',
            desc: 'Login flow with validation',
            code: 'flowchart TD\n    A[User] -->|Enter credentials| B[Login Form]\n    B --> C{Valid?}\n    C -->|Yes| D[Generate Token]\n    D --> E[Dashboard]\n    C -->|No| F[Show Error]\n    F --> B'
        },
        {
            name: 'Database Schema',
            type: 'erDiagram',
            desc: 'Users and orders relationship',
            code: 'erDiagram\n    USER ||--o{ ORDER : places\n    USER {\n        int id PK\n        string email\n        string name\n    }\n    ORDER ||--|{ ORDER_ITEM : contains\n    ORDER {\n        int id PK\n        date created_at\n        string status\n    }\n    PRODUCT ||--o{ ORDER_ITEM : "included in"\n    PRODUCT {\n        int id PK\n        string name\n        float price\n    }'
        },
        {
            name: 'CI/CD Pipeline',
            type: 'flowchart',
            desc: 'Build and deploy workflow',
            code: 'flowchart LR\n    A[Push Code] --> B[Build]\n    B --> C[Test]\n    C --> D{Pass?}\n    D -->|Yes| E[Deploy Staging]\n    E --> F[Integration Tests]\n    F --> G{Pass?}\n    G -->|Yes| H[Deploy Production]\n    D -->|No| I[Notify Team]\n    G -->|No| I'
        },
        {
            name: 'Microservices',
            type: 'flowchart',
            desc: 'Service architecture overview',
            code: 'flowchart TB\n    LB[Load Balancer] --> GW[API Gateway]\n    GW --> US[User Service]\n    GW --> PS[Product Service]\n    GW --> OS[Order Service]\n    US --> DB1[(User DB)]\n    PS --> DB2[(Product DB)]\n    OS --> DB3[(Order DB)]\n    OS --> MQ[Message Queue]\n    MQ --> NS[Notification Service]'
        },
        {
            name: 'Git Branching',
            type: 'gitgraph',
            desc: 'Feature branch workflow',
            code: 'gitgraph\n    commit id: "init"\n    branch develop\n    commit id: "dev setup"\n    branch feature/auth\n    commit id: "add login"\n    commit id: "add logout"\n    checkout develop\n    merge feature/auth\n    checkout main\n    merge develop tag: "v1.0"'
        },
        {
            name: 'Order State Machine',
            type: 'stateDiagram',
            desc: 'Order lifecycle states',
            code: 'stateDiagram-v2\n    [*] --> Pending\n    Pending --> Confirmed: Payment received\n    Confirmed --> Processing: Start fulfillment\n    Processing --> Shipped: Package sent\n    Shipped --> Delivered: Package received\n    Delivered --> [*]\n    Pending --> Cancelled: User cancels\n    Confirmed --> Cancelled: User cancels\n    Cancelled --> [*]'
        },
        {
            name: 'Class Hierarchy',
            type: 'classDiagram',
            desc: 'OOP inheritance example',
            code: 'classDiagram\n    class Animal {\n        +String name\n        +int age\n        +makeSound()\n    }\n    class Dog {\n        +String breed\n        +bark()\n        +fetch()\n    }\n    class Cat {\n        +String color\n        +meow()\n        +scratch()\n    }\n    Animal <|-- Dog\n    Animal <|-- Cat'
        },
        {
            name: 'User Journey',
            type: 'journey',
            desc: 'E-commerce checkout experience',
            code: 'journey\n    title Checkout Experience\n    section Browse\n        View products: 5: Customer\n        Add to cart: 4: Customer\n    section Checkout\n        Enter shipping: 3: Customer\n        Enter payment: 2: Customer\n        Confirm order: 4: Customer\n    section Post-Purchase\n        Receive confirmation: 5: Customer'
        },
        {
            name: 'Project Timeline',
            type: 'gantt',
            desc: 'Sprint planning example',
            code: 'gantt\n    title Sprint 1\n    dateFormat YYYY-MM-DD\n    section Backend\n        API Design: a1, 2024-01-01, 3d\n        Implementation: a2, after a1, 5d\n        Testing: a3, after a2, 2d\n    section Frontend\n        UI Design: b1, 2024-01-01, 4d\n        Components: b2, after b1, 4d\n        Integration: b3, after b2, 3d'
        },
        {
            name: 'Tech Stack',
            type: 'pie',
            desc: 'Language distribution',
            code: 'pie title Codebase Languages\n    "JavaScript" : 45\n    "TypeScript" : 30\n    "Python" : 15\n    "Go" : 10'
        },
        {
            name: 'Mind Map',
            type: 'mindmap',
            desc: 'Project planning brainstorm',
            code: 'mindmap\n    root((Project))\n        Frontend\n            React\n            TailwindCSS\n            TypeScript\n        Backend\n            Spring Boot\n            PostgreSQL\n            Redis\n        DevOps\n            Docker\n            Kubernetes\n            GitHub Actions'
        }
    ];

    const templatesModal = document.getElementById('templatesModal');
    const templatesBtn = document.getElementById('templatesBtn');
    const templatesClose = document.getElementById('templatesClose');
    const templatesGrid = document.getElementById('templatesGrid');

    function renderTemplates() {
        if (!templatesGrid) return;
        templatesGrid.innerHTML = '';

        templates.forEach(template => {
            const card = document.createElement('div');
            card.className = 'bg-white/5 border border-white/20 rounded-xl p-4 cursor-pointer transition-all hover:border-cyan-400 hover:bg-cyan-400/10 hover:-translate-y-0.5';

            const header = document.createElement('div');
            header.className = 'flex justify-between items-start mb-2';

            const title = document.createElement('span');
            title.className = 'font-semibold text-white text-sm';
            title.textContent = template.name;

            const type = document.createElement('span');
            type.className = 'text-xs px-2 py-0.5 bg-cyan-400/20 text-cyan-400 rounded';
            type.textContent = template.type;

            header.appendChild(title);
            header.appendChild(type);

            const desc = document.createElement('div');
            desc.className = 'text-xs text-gray-400 leading-relaxed';
            desc.textContent = template.desc;

            card.appendChild(header);
            card.appendChild(desc);

            card.addEventListener('click', () => loadTemplate(template));
            templatesGrid.appendChild(card);
        });
    }

    async function loadTemplate(template) {
        // Update form fields
        document.getElementById('diagramType').value = template.type;
        document.getElementById('description').value = template.name + ' - ' + template.desc;

        const diagramEl = document.getElementById('mermaidDiagram');
        const diagramWrapper = document.getElementById('diagramWrapper');
        const placeholder = document.getElementById('placeholder');
        const downloadButtons = document.getElementById('downloadButtons');

        if (diagramEl) {
            // Show diagram wrapper first
            if (placeholder) placeholder.style.display = 'none';
            if (diagramWrapper) diagramWrapper.style.display = 'block';
            if (downloadButtons) downloadButtons.style.display = 'flex';

            // Render the template
            diagramEl.innerHTML = template.code;
            diagramEl.removeAttribute('data-processed');

            try {
                await mermaid.run({ nodes: [diagramEl] });

                // Create or update code editor
                let codeEditor = document.getElementById('mermaidCodeEditor');
                if (!codeEditor) {
                    createCodeEditor(template.code);
                } else {
                    codeEditor.value = template.code;
                }

                // Save to history
                addToHistory({
                    id: Date.now(),
                    description: template.name,
                    diagramType: template.type,
                    title: '',
                    bgColor: document.getElementById('bgColor').value,
                    theme: document.getElementById('theme').value,
                    size: document.getElementById('size').value,
                    mermaidCode: template.code
                });

                closeTemplatesModal();
            } catch (e) {
                alert('Error loading template: ' + e.message);
            }
        }
    }

    function openTemplatesModal() {
        renderTemplates();
        templatesModal.classList.add('active');
    }

    function closeTemplatesModal() {
        templatesModal.classList.remove('active');
    }

    if (templatesBtn) {
        templatesBtn.addEventListener('click', openTemplatesModal);
    }

    if (templatesClose) {
        templatesClose.addEventListener('click', closeTemplatesModal);
    }

    if (templatesModal) {
        templatesModal.addEventListener('click', (e) => {
            if (e.target === templatesModal) {
                closeTemplatesModal();
            }
        });
    }

    // ===== Zoom/Pan Controls =====
    const zoomInBtn = document.getElementById('zoomInBtn');
    const zoomOutBtn = document.getElementById('zoomOutBtn');
    const zoomResetBtn = document.getElementById('zoomResetBtn');
    const zoomLevelDisplay = document.getElementById('zoomLevel');
    const diagramContainerZoom = document.getElementById('diagramContainer');
    const mermaidDiagramZoom = document.getElementById('mermaidDiagram');

    let currentZoom = 1;
    let panX = 0;
    let panY = 0;
    let isPanning = false;
    let startX = 0;
    let startY = 0;

    const MIN_ZOOM = 0.25;
    const MAX_ZOOM = 4;
    const ZOOM_STEP = 0.25;

    function updateTransform() {
        if (mermaidDiagramZoom) {
            mermaidDiagramZoom.style.transform = 'scale(' + currentZoom + ') translate(' + (panX / currentZoom) + 'px, ' + (panY / currentZoom) + 'px)';
        }
        if (zoomLevelDisplay) {
            zoomLevelDisplay.textContent = Math.round(currentZoom * 100) + '%';
        }
    }

    function zoomIn() {
        currentZoom = Math.min(MAX_ZOOM, currentZoom + ZOOM_STEP);
        updateTransform();
    }

    function zoomOut() {
        currentZoom = Math.max(MIN_ZOOM, currentZoom - ZOOM_STEP);
        updateTransform();
    }

    function resetZoom() {
        currentZoom = 1;
        panX = 0;
        panY = 0;
        updateTransform();
    }

    if (zoomInBtn) {
        zoomInBtn.addEventListener('click', zoomIn);
    }

    if (zoomOutBtn) {
        zoomOutBtn.addEventListener('click', zoomOut);
    }

    if (zoomResetBtn) {
        zoomResetBtn.addEventListener('click', resetZoom);
    }

    // Mouse wheel zoom
    if (diagramContainerZoom) {
        diagramContainerZoom.addEventListener('wheel', (e) => {
            e.preventDefault();
            if (e.deltaY < 0) {
                zoomIn();
            } else {
                zoomOut();
            }
        }, { passive: false });

        // Pan with mouse drag
        diagramContainerZoom.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return; // Only left click
            isPanning = true;
            startX = e.clientX - panX;
            startY = e.clientY - panY;
            diagramContainerZoom.style.cursor = 'grabbing';
        });

        document.addEventListener('mousemove', (e) => {
            if (!isPanning) return;
            panX = e.clientX - startX;
            panY = e.clientY - startY;
            updateTransform();
        });

        document.addEventListener('mouseup', () => {
            if (isPanning) {
                isPanning = false;
                if (diagramContainerZoom) {
                    diagramContainerZoom.style.cursor = 'grab';
                }
            }
        });
    }

    // ===== Embed Code =====
    const embedModal = document.getElementById('embedModal');
    const embedBtn = document.getElementById('embedBtn');
    const embedClose = document.getElementById('embedClose');
    const embedCodeOutput = document.getElementById('embedCodeOutput');
    const copyEmbedBtn = document.getElementById('copyEmbedBtn');

    function generateEmbedCode() {
        const codeEditor = document.getElementById('mermaidCodeEditor');
        const mermaidCode = codeEditor ? codeEditor.value : '';

        if (!mermaidCode.trim()) {
            return '';
        }

        const theme = document.getElementById('theme').value;
        const bgColor = document.getElementById('bgColor').value;

        // Escape the mermaid code for HTML
        const escapedCode = mermaidCode
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');

        var mermaidCdn = 'https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js';
        return '<!DOCTYPE html>\n' +
            '<html lang="en">\n' +
            '<head>\n' +
            '    <meta charset="UTF-8">\n' +
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n' +
            '    <title>Mermaid Diagram</title>\n' +
            '    <script src="' + mermaidCdn + '"><' + '/script>\n' +
            '    <style>\n' +
            '        body {\n' +
            '            display: flex;\n' +
            '            justify-content: center;\n' +
            '            padding: 20px;\n' +
            '            background: ' + bgColor + ';\n' +
            '        }\n' +
            '        .mermaid {\n' +
            '            max-width: 100%;\n' +
            '        }\n' +
            '    </style>\n' +
            '</head>\n' +
            '<body>\n' +
            '    <pre class="mermaid">\n' + escapedCode + '\n    </pre>\n' +
            '    <script>\n' +
            '        mermaid.initialize({ startOnLoad: true, theme: "' + theme + '" });\n' +
            '    <' + '/script>\n' +
            '</body>\n' +
            '</html>';
    }

    function openEmbedModal() {
        const code = generateEmbedCode();
        if (!code) {
            alert('No diagram to embed');
            return;
        }
        embedCodeOutput.value = code;
        embedModal.classList.add('active');
    }

    function closeEmbedModal() {
        embedModal.classList.remove('active');
    }

    if (embedBtn) {
        embedBtn.addEventListener('click', openEmbedModal);
    }

    if (embedClose) {
        embedClose.addEventListener('click', closeEmbedModal);
    }

    if (copyEmbedBtn) {
        copyEmbedBtn.addEventListener('click', function() {
            embedCodeOutput.select();
            navigator.clipboard.writeText(embedCodeOutput.value).then(() => {
                const originalText = this.textContent;
                this.textContent = 'Copied!';
                setTimeout(() => {
                    this.textContent = originalText;
                }, 2000);
            });
        });
    }

    if (embedModal) {
        embedModal.addEventListener('click', (e) => {
            if (e.target === embedModal) {
                closeEmbedModal();
            }
        });
    }

    // Combined Escape key handler for all modals
    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;

        if (importModal && importModal.classList.contains('active')) {
            closeModal();
        } else if (fullscreenOverlay && fullscreenOverlay.classList.contains('active')) {
            closeFullscreen();
        } else if (templatesModal && templatesModal.classList.contains('active')) {
            closeTemplatesModal();
        } else if (embedModal && embedModal.classList.contains('active')) {
            closeEmbedModal();
        }
    });
})();
