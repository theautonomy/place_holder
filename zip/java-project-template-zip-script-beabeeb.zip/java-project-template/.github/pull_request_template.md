## What and why

<!-- What does this change do, and why is it needed? Link the issue if there is one. -->

## How it was tested

<!-- Commands run, tests added, manual checks. -->

## Checklist

- [ ] `./mvnw verify` passes locally (compile, tests, Spotless, Enforcer, JaCoCo)
- [ ] Code is formatted with `./mvnw spotless:apply`
- [ ] Tests added or updated for changed behavior
- [ ] Docs updated (`README.md`, `docs/`) if conventions or setup changed
