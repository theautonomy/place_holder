package com.example.reference;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

class AppTest {

  @Test
  @DisplayName("greets the given name")
  void greetsName() {
    assertThat(App.greet("Ada")).isEqualTo("Hello, Ada!");
  }

  @Test
  @DisplayName("strips surrounding whitespace from the name")
  void stripsWhitespace() {
    assertThat(App.greet("  Ada  ")).isEqualTo("Hello, Ada!");
  }

  @ParameterizedTest
  @NullAndEmptySource
  @ValueSource(strings = {" ", "\t"})
  @DisplayName("falls back to World for null or blank names")
  void fallsBackToWorld(String name) {
    assertThat(App.greet(name)).isEqualTo("Hello, World!");
  }

  @Test
  @DisplayName("main prints the greeting for the first argument")
  void mainPrintsGreeting() {
    PrintStream original = System.out;
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    System.setOut(new PrintStream(out, true, StandardCharsets.UTF_8));
    try {
      App.main(new String[] {"Ada"});
      App.main(new String[0]);
    } finally {
      System.setOut(original);
    }
    assertThat(out.toString(StandardCharsets.UTF_8).lines())
        .containsExactly("Hello, Ada!", "Hello, World!");
  }
}
