package com.example.reference;

/** Entry point of the reference application. */
public final class App {

  private App() {}

  /**
   * Builds a greeting for the given name.
   *
   * @param name who to greet; blank or {@code null} means "World"
   * @return the greeting
   */
  public static String greet(String name) {
    if (name == null || name.isBlank()) {
      return "Hello, World!";
    }
    return "Hello, " + name.strip() + "!";
  }

  public static void main(String[] args) {
    System.out.println(greet(args.length > 0 ? args[0] : null));
  }
}
