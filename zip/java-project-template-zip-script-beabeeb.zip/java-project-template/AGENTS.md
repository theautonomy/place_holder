# AGENTS.md

Reference Java project for our coding and project conventions. `main` is a plain Java project; other branches (e.g. Spring Boot) build on it. Full conventions: [docs/conventions.md](docs/conventions.md).

## Commands

```bash
./mvnw spotless:apply    # format Java and pom.xml: run before every commit
./mvnw verify            # compile, test, Enforcer, Spotless check, JaCoCo coverage: must pass
./mvnw test -Dtest=AppTest#greetsName   # run one test
scripts/sonar-local.sh   # scan with the local SonarQube in Docker (needs .env, see docs/sonar-usage.md)
scripts/zip-project.sh   # zip the project without ignored files (target/, .env, ...) into ../
```

Always use `./mvnw` (or `mvnw.cmd` on Windows), never a system `mvn`.

## Rules

- **Java 21.** Don't use preview features or APIs newer than 21.
- **Formatting is Spotless's job.** Never hand-format to satisfy the check: run `spotless:apply`. 2-space indent, 100 columns, no wildcard imports.
- **Tests:** JUnit 6 (Jupiter API) + AssertJ (`assertThat`), same package as the class under test, named `<Class>Test`, with `@DisplayName`. New or changed behavior needs a test; line coverage must stay at 80% or more.
- **Dependencies:** versions go in `<properties>` in `pom.xml`; prefer BOMs. Don't add a dependency without a clear need.
- **Package:** `com.example.reference`.
- **Line endings:** LF everywhere except `*.cmd`/`*.bat` (`.gitattributes`). Keep files UTF-8 with a final newline (`.editorconfig`).
- **Workflows:** `compile.yml` must stay green. Don't remove the default-branch guard or `environment: production` from `deploy.yml`.
- **Keep docs in sync:** if you change a convention, update `docs/conventions.md` (and `README.md` if commands change).

## Done means

`./mvnw verify` passes with no changes left by `./mvnw spotless:apply`.
