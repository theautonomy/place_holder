#!/usr/bin/env bash
# Claude Code Stop hook: when Claude finishes a response, format changed Java files and
# pom.xml with Spotless, so the code always passes `./mvnw verify`.
#
# Skips the Maven run (a few seconds) when no .java file or pom.xml has uncommitted
# changes, or when they haven't changed since the last run.

set -euo pipefail

cd "${CLAUDE_PROJECT_DIR:-$(dirname "$0")/../..}"

# Changed or new .java files and pom.xml, relative to HEAD
files="$({
  git diff --name-only HEAD -- '*.java' pom.xml
  git ls-files --others --exclude-standard -- '*.java' pom.xml
} 2> /dev/null | sort -u)"
[[ -n "$files" ]] || exit 0

# Fingerprint of their current content; unchanged since the last run means nothing to do
stamp_file=target/.claude-format-stamp
fingerprint() { xargs cat -- <<< "$files" 2> /dev/null | git hash-object --stdin; }
before="$(fingerprint)"
[[ -f "$stamp_file" && "$(cat "$stamp_file")" == "$before" ]] && exit 0

if ! output="$(./mvnw -q -B -ntp spotless:apply 2>&1)"; then
  # Non-blocking: shown to the user, Claude's work is kept
  echo "spotless:apply failed; run ./mvnw spotless:apply to see why" >&2
  echo "$output" | tail -n 20 >&2
  exit 1
fi

mkdir -p target
fingerprint > "$stamp_file"

if [[ "$(cat "$stamp_file")" != "$before" ]]; then
  echo '{"systemMessage": "Spotless reformatted changed Java/pom.xml files."}'
fi
