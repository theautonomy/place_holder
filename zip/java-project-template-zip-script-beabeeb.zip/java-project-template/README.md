# java-project-template

Reference Java application for our coding and project conventions. The `main` branch is the starting point for a plain Java project; other branches cover other project types, such as Spring Boot.

## Stack

- Java 21
- Maven 3.9 through the Maven Wrapper (`./mvnw`)
- JUnit 6 and AssertJ
- Spotless (Palantir Java Format, 2-space indent), Maven Enforcer, JaCoCo
- GitHub Actions: `Compile` on every push and PR, a manual `Deploy` that only runs from the default branch, `Claude Code`, which answers `@claude` mentions in issues and PRs, `Claude Code Review`, which reviews every PR, and `SonarQube`, which runs SonarQube Cloud analysis

## Build

```bash
./mvnw verify            # compile, test, and check formatting, Enforcer rules and coverage
./mvnw spotless:apply    # format code and pom.xml
```

On Windows, use `mvnw.cmd` in `cmd` or PowerShell; `./mvnw` works in Git Bash.

To share a snapshot of the project, including uncommitted changes, but without ignored files such as `target/` and `.env`:

```bash
scripts/zip-project.sh              # ../java-project-template-<branch>-<commit>[-dirty].zip
scripts/zip-project.sh out.zip      # or a path of your choice
```

It needs Python 3; Git Bash has no `zip` command. Unlike `git archive`, it keeps uncommitted changes and the files marked `export-ignore` (`.github/`, `.editorconfig`, ...).

Run the sample application:

```bash
./mvnw -q package && java -cp target/classes com.example.reference.App Ada
```

## Docs

| Doc | About |
| --- | --- |
| [AGENTS.md](AGENTS.md) | Short rules and commands for coding agents (and humans); `CLAUDE.md` imports it for Claude Code |
| [docs/conventions.md](docs/conventions.md) | Every convention, what enforces it, and the GitHub settings to apply by hand |
| [docs/EDITORCONFIG.md](docs/EDITORCONFIG.md) | `.editorconfig` explained |
| [docs/GITATTRIBUTES.md](docs/GITATTRIBUTES.md) | `.gitattributes` explained |
| [docs/spotless-usage.md](docs/spotless-usage.md) | Spotless options |
| [docs/sonar-usage.md](docs/sonar-usage.md) | SonarQube Cloud in CI, local SonarQube in Docker, reading results |
| [docs/claude-code-setup.md](docs/claude-code-setup.md) | Claude Code on your machine: install, project settings, formatting hook |
| [docs/claude-github-usage.md](docs/claude-github-usage.md) | Claude Code in GitHub: `@claude` mentions, automatic PR reviews, setup |
| [docs/dependency-updates.md](docs/dependency-updates.md) | Dependabot setup, handling its PRs, Dependabot vs Renovate |
| [docs/github-actions-branch-restrictions.md](docs/github-actions-branch-restrictions.md) | Restricting a workflow (deploy) to one branch |
| [docs/project-setup-plan.md](docs/project-setup-plan.md) | The plan this setup was built from |
