# Plan: reference Java project (coding and project conventions)

## Context

`java-project-template` will be the reference Java application for our coding and project conventions. This branch (`main`) is the plain-Java starting point. Later branches will build on it, for example a Spring Boot variant. Today the folder holds only four reference docs in the root (`EDITORCONFIG.md`, `GITATTRIBUTES.md`, `github-actions-branch-restrictions.md`, `spotless-usage.md`), an empty `docs/` folder and no git repository. The result should be a small project that builds, with every convention file in place and explained.

Decisions taken: Maven with the Maven Wrapper; Java 21; JUnit 5; Spotless with Palantir Java Format at a 2-space indent; groupId and base package `com.example.reference`; code owner `@theautonomy`; extras: Dependabot, docs moved into `docs/`, a PR template, Maven Enforcer and JaCoCo.

## Step 0: save this plan into the repo

Copy this plan to `docs/project-setup-plan.md`. You asked for that, but plan mode only lets me write the plan file, so it is the first step once the plan is approved.

## Files to create

```
.editorconfig
.gitattributes
.gitignore
.mvn/wrapper/maven-wrapper.properties   + mvnw, mvnw.cmd   (Maven 3.9.x, generated with `mvn wrapper:wrapper`)
pom.xml
src/main/java/com/example/reference/App.java              (small class with one method worth testing)
src/test/java/com/example/reference/AppTest.java          (JUnit 5 tests)
.github/CODEOWNERS                                        (* @theautonomy)
.github/dependabot.yml                                    (maven + github-actions, weekly)
.github/pull_request_template.md
.github/workflows/compile.yml
.github/workflows/deploy.yml
README.md                                                 (what this repo is, how to build, index of docs/)
docs/EDITORCONFIG.md, docs/GITATTRIBUTES.md,
docs/github-actions-branch-restrictions.md, docs/spotless-usage.md   (moved from the root)
docs/conventions.md                                       (one-page summary of all conventions)
```

## Details

**pom.xml**
- `maven.compiler.release=21`, UTF-8 source encoding, and all versions held in `<properties>`.
- JUnit through `junit-bom` (5.x, test scope `junit-jupiter`), plus AssertJ for assertions.
- Plugins pinned explicitly: compiler, surefire, jar.
- **Enforcer**: `requireJavaVersion [21,)`, `requireMavenVersion [3.9,)`, `dependencyConvergence`, `banDuplicatePomDependencyVersions`.
- **Spotless**: `palantirJavaFormat` with `<style>GOOGLE</style>` (Palantir's 2-space style; it also sets the line length to 100), plus `importOrder`, `removeUnusedImports`, `formatAnnotations`, `forbidWildcardImports`, `toggleOffOn`, and `<pom><sortPom/></pom>`. The `check` goal is bound to `verify` (not `compile` as in the Feedback Hub doc), so local edit-compile loops are not blocked. I will confirm that the plugin version accepts `style`. If 2-space Palantir is not available, I will stop and ask before falling back to Google Java Format.
- **JaCoCo**: `prepare-agent` and `report`. The coverage gate (`check`) starts at a low threshold (e.g. 0.80 line coverage of this tiny sample) so it shows the pattern.

**.editorconfig / .gitattributes**: use the Java + shell templates in `EDITORCONFIG.md` (§"A template for Java + shell projects") and `GITATTRIBUTES.md` (same section) as written, with the indent changed to 2 spaces for Java to match the formatter. Everything is stored and checked out as LF, except `*.cmd`/`*.bat`, which use CRLF, so `mvnw.cmd` works.

**.gitignore**: `target/`, IDE files (`.idea/`, `*.iml`, `.vscode/`, `.classpath`, `.project`, `.settings/`), OS files (`.DS_Store`, `Thumbs.db`), logs. `.mvn/wrapper/maven-wrapper.jar` is ignored too, because the current wrapper downloads it.

**compile.yml**: runs on `push` and `pull_request` to any branch, plus `workflow_dispatch`. It uses `actions/checkout` and `actions/setup-java` (temurin 21, `cache: maven`), then `./mvnw -B -ntp verify`, which compiles, tests and runs the Spotless, Enforcer and JaCoCo checks. Permissions: `contents: read`. A `concurrency` group cancels superseded runs.

**deploy.yml**: has only a `workflow_dispatch` trigger. It follows the three layers from `github-actions-branch-restrictions.md`:
1. The trigger is manual only.
2. A job guard: `if: github.ref_name == github.event.repository.default_branch` (the default branch, not a hard-coded `main`, so future branches inherit the rule correctly).
3. `environment: production`. The environment's branch rule is a manual repository-settings step, recorded in the docs because it cannot live in code.

It builds with `./mvnw -B -ntp verify` and then runs a placeholder deploy step (`echo`), so nothing is actually deployed.

**Docs**: `docs/conventions.md` lists each convention, the file that enforces it and the command to fix violations (`./mvnw spotless:apply`). It also includes a checklist of GitHub settings to apply by hand: create the `production` environment limited to the default branch, protect `main` with a ruleset (PR required, `compile` check required, no force push, code-owner review), and keep `GITHUB_TOKEN` read-only. `spotless-usage.md` currently describes Feedback Hub, so I will add a short note at the top saying how this repo differs (2-space, check at `verify`), or rewrite its "How it is used" part for this repo.

**Git**: run `git init -b main` and use `git add --renormalize` after `.gitattributes` exists. I won't commit or push unless you ask.

## Verification

1. `./mvnw -B -ntp verify` passes: it compiles on 21, the tests pass, and the Spotless, Enforcer and JaCoCo checks pass.
2. Break the formatting on purpose (add a 4-space indent), confirm `verify` fails, then confirm `./mvnw spotless:apply` fixes it.
3. `git ls-files --eol` shows LF for everything, and CRLF for `mvnw.cmd` in the working tree.
4. Lint the workflows with `actionlint` if it is available. Otherwise check them by eye against the docs. Running them on GitHub happens after the first push.
