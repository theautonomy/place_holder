# Setting up Claude Code for this project

[Claude Code](https://code.claude.com) is Anthropic's coding agent for the terminal (with IDE extensions and a desktop app). This page covers using it on your machine with this repository. For Claude on GitHub (`@claude` and automatic PR reviews), see [claude-github-usage.md](claude-github-usage.md).

## 1. Install

You need the same tools as for the project itself (JDK 21, Git), plus a Claude subscription (Pro, Max, Team or Enterprise) or an Anthropic API key.

| OS | Command |
| --- | --- |
| macOS, Linux, WSL | `curl -fsSL https://claude.ai/install.sh \| bash` |
| Windows (PowerShell) | `irm https://claude.ai/install.ps1 \| iex` |
| Any, with Node.js 18+ | `npm install -g @anthropic-ai/claude-code` |

On Windows, also install [Git for Windows](https://git-scm.com/download/win). Claude Code runs its shell commands, and this project's hook, in Git Bash.

Check it with `claude --version`, and use `claude doctor` if something is wrong.

## 2. Log in and start

```bash
cd java-project-template
claude
```

The first start opens the browser to log in. Choose your Claude account to use a subscription, or the Anthropic Console to pay per use with an API key. Run `/login` to switch later.

The first time Claude Code opens this folder, it asks whether you trust it. The project settings below, including a hook that runs a script, only apply after you say yes.

## 3. What the repository configures for you

These files are committed, so everyone gets the same setup:

| File | What it does |
| --- | --- |
| [`CLAUDE.md`](../CLAUDE.md) | Loaded into every session. It contains only `@AGENTS.md`, which imports [AGENTS.md](../AGENTS.md): the project's rules and commands, shared with other coding agents |
| [`.claude/settings.json`](../.claude/settings.json) | Permissions and the formatting hook, below |
| [`.claude/hooks/format-java.sh`](../.claude/hooks/format-java.sh) | The script the hook runs |

### Permissions

Claude asks before running a command unless a rule allows it. `.claude/settings.json` allows these without asking:

- `./mvnw …`: build, test, format
- `scripts/sonar-local.sh`: local SonarQube scan
- read-only git commands: `git status`, `git diff`, `git log`, `git show`, `git branch`
- read-only gh commands: `gh pr view/diff/checks/list`, `gh run list/view`, `gh issue view/list`

Everything else still asks first: editing files (unless you accept edits), `git commit`, `git push`, `gh pr create`, and any other command.

It also **denies** reading `.env` with the Read tool, so tokens in it don't end up in a conversation. Scripts such as `sonar-local.sh` still read it themselves.

### Formatting hook

When Claude finishes a response, a **Stop hook** runs `.claude/hooks/format-java.sh`:

1. It lists `.java` files and `pom.xml` with uncommitted changes. If there are none, it stops.
2. If their content hasn't changed since its last run, it stops. It keeps a fingerprint in `target/.claude-format-stamp`.
3. Otherwise it runs `./mvnw spotless:apply`. That takes about 10 to 15 seconds, mostly for Maven to start, and the status line shows "Formatting Java with Spotless…". If it changed anything, you see "Spotless reformatted changed Java/pom.xml files."

So Claude's Java changes always match the formatter, and `./mvnw verify` doesn't fail on formatting. If `spotless:apply` fails, the hook shows the error, but Claude's changes stay as they are.

The hook runs once per response, not after every edit, because each Maven run takes several seconds.

## 4. Your own settings

Personal preferences go in files that git ignores:

| File | For |
| --- | --- |
| `.claude/settings.local.json` | Your own permissions or hooks for this project, for example `"defaultMode": "acceptEdits"`. These override `.claude/settings.json` |
| `CLAUDE.local.md` | Your own notes for Claude about this project |
| `~/.claude/settings.json`, `~/.claude/CLAUDE.md` | Settings and notes for all your projects |

To turn off the formatting hook for yourself, add `"disableAllHooks": true` to `.claude/settings.local.json`.

## 5. Working on this project with Claude

Useful prompts and commands:

| To | Do |
| --- | --- |
| Make a change | Describe it, e.g. "add a `farewell` method to `App` with tests". Claude follows `AGENTS.md` and runs `./mvnw verify` before calling it done |
| Plan a bigger change first | Press Shift+Tab until the status line shows plan mode; Claude explores and proposes a plan before editing anything |
| Review your branch before a PR | `/code-review` |
| Check what Claude may do | `/permissions`, `/hooks` |
| See what's loaded from `CLAUDE.md` | `/memory` |
| Run a one-off task without the interactive UI | `claude -p "explain how the deploy workflow restricts branches"` |
| Set up Claude on GitHub | `/install-github-app`, or follow [claude-github-usage.md](claude-github-usage.md) |

"Done" means the same for Claude as for people: `./mvnw verify` passes, and `./mvnw spotless:apply` leaves nothing to change.

## Gotchas

| Problem | Cause | Fix |
| --- | --- | --- |
| The hook or permissions don't apply | You haven't trusted the folder yet, or `.claude/settings.json` changed during the session | Accept the trust prompt; open `/hooks` once or restart Claude Code |
| A hook error such as `bash: command not found` on Windows | Git for Windows is missing, so hooks run in PowerShell | Install Git for Windows, then restart Claude Code |
| `gh` commands fail with "The token in GITHUB_TOKEN is invalid" | A stale `GITHUB_TOKEN` environment variable; Claude's shell inherits it | Remove the variable, or start Claude Code from a shell where you ran `unset GITHUB_TOKEN` |
| Every response ends with a 10 to 15 second pause | Java files keep changing, so the hook keeps running Spotless | Expected while editing Java. Use `"disableAllHooks": true` in `.claude/settings.local.json` to turn it off |
