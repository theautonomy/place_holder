# How Sonar is used in this project

## What is it?

Sonar runs static analysis on the Java code (bugs, code smells, security hotspots, duplication) and tracks test coverage from JaCoCo over time. There are two ways to run it:

| Where | Server | When | Results |
| --- | --- | --- | --- |
| CI (`.github/workflows/sonar.yml`) | SonarQube Cloud (`https://sonarcloud.io`) | Pushes to `main` and manual runs | https://sonarcloud.io/summary/overall?id=theautonomy_java-project-template |
| Your machine | SonarQube in Docker | When you run the scan yourself | http://localhost:9000 |

A normal build (`./mvnw verify`) never contacts a Sonar server; the scan is the separate `sonar:sonar` goal.

## How is it configured?

Everything is in `pom.xml`; there is no `sonar-project.properties` (the Maven scanner ignores that file anyway).

| Setting | Value | Meaning |
| --- | --- | --- |
| `sonar.host.url` | `https://sonarcloud.io` | SonarQube Cloud, not a self-hosted server |
| `sonar.organization` | `theautonomy` | The organization **key**, not its display name |
| `sonar.projectKey` | `theautonomy_java-project-template` | Where results are published |
| `sonar-maven-plugin` | `${sonar-maven-plugin.version}` in `pluginManagement` | Provides the `sonar:sonar` goal, at a pinned version |

The Maven scanner works the rest out from the build, so nothing else needs configuring:

- **Sources and tests:** `src/main/java` and `src/test/java`.
- **Compiled classes:** `target/classes`.
- **Coverage:** `target/site/jacoco/jacoco.xml`, written by the JaCoCo `report` goal during `verify`.
- **Test results:** `target/surefire-reports`.

Override any setting on the command line with `-Dsonar.<key>=<value>`.

## When does it run in CI?

`sonar.yml` runs on pushes to `main` and on manual runs, and executes one step. It does not run on pull requests: on the free plan, SonarQube Cloud shows only the main branch of a private project (see [Gotchas](#gotchas)).

```bash
./mvnw -B -ntp verify org.sonarsource.scanner.maven:sonar-maven-plugin:sonar
```

1. `verify` compiles, runs the tests, writes the JaCoCo report, and runs all checks (Enforcer, Spotless, JaCoCo minimum). If any check fails, nothing is uploaded.
2. `sonar` uploads the analysis and the reports, using the `SONAR_TOKEN` repository secret. `GITHUB_TOKEN` lets SonarQube Cloud comment on pull requests.

Details:
- **Full git history:** the checkout uses `fetch-depth: 0`, so Sonar can tell new code from old and show blame.
- **Dependabot is skipped:** its runs get no Actions secrets, so the scan could not authenticate. This matters only if PR analysis is turned back on.
- **Sonar does not fail the build.** The quality gate result shows on SonarQube Cloud and on the PR. To make CI fail on a failing gate, add `-Dsonar.qualitygate.wait=true`.

## One-time setup with the Sonar API and `gh`

This project was set up this way on 2026-10-11. Everything is done from Git Bash with `curl`, `jq` and the [GitHub CLI](https://cli.github.com); no clicking in SonarQube Cloud is needed.

### Prerequisites

1. **A SonarQube Cloud token.** Log in to [sonarcloud.io](https://sonarcloud.io) with GitHub, then create one under **My Account → Security**. Put it in `.env` as `SONAR_TOKEN=` (see `.env.example`). Use `_`, not `-`: GitHub secret names and shell variables don't allow hyphens.
2. **`gh` logged in** with the `repo` and `workflow` scopes: `gh auth login --web`. If a `GITHUB_TOKEN` environment variable is set, `gh` uses it instead of your login, and refuses to log in while it is set. Run `unset GITHUB_TOKEN` first in that shell.

Set up the shell. The token is read from `.env` and never printed:

```bash
T=$(grep -E '^SONAR_TOKEN=' .env | cut -d= -f2- | tr -d '\r')
S=https://sonarcloud.io
H="Authorization: Bearer $T"
ORG=theautonomy                          # sonar.organization in pom.xml
P=theautonomy_java-project-template      # sonar.projectKey in pom.xml
R=theautonomy/java-project-template      # GitHub owner/repo
```

### Steps

1. **Check the token, and find the organization key.** Use the key, not the display name, in `pom.xml`:

   ```bash
   curl -s -H "$H" $S/api/authentication/validate                                  # {"valid":true}
   curl -s -H "$H" "$S/api/organizations/search?member=true" | jq -c '[.organizations[] | {key, name}]'
   ```

2. **Create the project** (skip this if it already exists: `curl -s -H "$H" "$S/api/projects/search?organization=$ORG"`):

   ```bash
   curl -s -X POST -H "$H" $S/api/projects/create \
     --data-urlencode organization=$ORG --data-urlencode project=$P \
     --data-urlencode name=java-project-template --data-urlencode visibility=private
   ```

   A project created this way isn't bound to the GitHub repository, so **Automatic Analysis is off** and can't conflict with the CI scan.

3. **Name the main branch `main`.** New projects call it `master`. On the free plan, a private project only shows its main branch, so a scan of `main` would be rejected as a second branch:

   ```bash
   curl -s -X POST -H "$H" $S/api/project_branches/rename --data-urlencode project=$P --data-urlencode name=main
   curl -s -H "$H" "$S/api/project_branches/list?project=$P" | jq -c '[.branches[] | {name, isMain}]'   # [{"name":"main","isMain":true}]
   ```

4. **Add the token as a repository secret,** piped so it never appears on screen or in shell history:

   ```bash
   printf '%s' "$T" | gh secret set SONAR_TOKEN -R $R
   gh secret list -R $R
   ```

### Doing it in the web UI instead

1. In SonarQube Cloud, import the GitHub repository. This binds it to the repository.
2. Check that the organization and project keys match `pom.xml`.
3. Turn off **Administration → Analysis Method → Automatic Analysis**. Otherwise CI scans are rejected with "You are running CI analysis while Automatic Analysis is enabled".
4. Add the token under GitHub **Settings → Secrets and variables → Actions** as `SONAR_TOKEN`.

## Running the CI check and reading the results

`sonar.yml` runs by itself on every push to `main`. To run it by hand, and wait for the result:

```bash
gh workflow run sonar.yml -R $R --ref main
sleep 5
id=$(gh run list -R $R -w sonar.yml -L 1 --json databaseId --jq '.[0].databaseId')
gh run watch $id -R $R --exit-status                                       # exits non-zero if the run fails
gh run view $id -R $R --log | grep -E "ANALYSIS SUCCESSFUL|ERROR\]"        # why it failed, if it did
```

The scanner only uploads the report; SonarQube Cloud processes it in a background task. Wait for the queue to empty, then read the results:

```bash
until [ "$(curl -s -H "$H" "$S/api/ce/component?component=$P" | jq '.queue | length')" = 0 ]; do sleep 5; done

# Quality gate: OK, ERROR, or NONE (NONE on the first analysis, which only sets the new-code baseline)
curl -s -H "$H" "$S/api/qualitygates/project_status?projectKey=$P" | jq -r .projectStatus.status

# Metrics
curl -s -H "$H" "$S/api/measures/component?component=$P&metricKeys=coverage,bugs,vulnerabilities,code_smells,security_hotspots,duplicated_lines_density,ncloc" \
  | jq -r '.component.measures | sort_by(.metric)[] | "\(.metric): \(.value)"'

# Open issues: rule | severity | type | file:line | message
curl -s -H "$H" "$S/api/issues/search?componentKeys=$P&resolved=false&ps=100" \
  | jq -r '.issues[] | "\(.rule) | \(.severity) | \(.type) | \(.component | sub(".*:";"")):\(.line) | \(.message)"'
```

Dashboard: https://sonarcloud.io/dashboard?id=theautonomy_java-project-template

The first CI analysis, on 2026-10-11, reported 100% coverage, 0 bugs, 0 code smells, and 1 vulnerability. The vulnerability was `githubactions:S7637`: a third-party action (`anthropics/claude-code-action@v1`) referenced by tag instead of by commit SHA. SonarQube Cloud also analyzes `pom.xml` and the workflow files, not just Java.

## Can I run it locally?

Yes, in one of three ways:

| Option | Needs | Gives you |
| --- | --- | --- |
| SonarQube in Docker | Docker | The full dashboard: issues, coverage, duplication, quality gate |
| SonarQube Cloud from your machine | A SonarQube Cloud token | The same as CI, but uploads to the shared project, so prefer CI |
| SonarQube for IDE (formerly SonarLint) | IntelliJ or VS Code plugin | Issues highlighted as you type; no server, no coverage |

### SonarQube in Docker

```bash
# 1. Start the server (the first start takes about a minute)
docker run -d --name sonarqube -p 9000:9000 sonarqube:community

# 2. Open http://localhost:9000, log in as admin/admin, set a new password,
#    then create a token under My Account > Security and put it in .env
#    (cp .env.example .env, then fill in LOCAL_SONAR_ACCESS_TOKEN)

# 3. Build, scan, wait for the quality gate, and print a summary
scripts/sonar-local.sh
```

`scripts/sonar-local.sh` does the following:
- Checks that the server is up and that the token is valid.
- Runs `./mvnw verify sonar:sonar` with `-Dsonar.qualitygate.wait=true`.
- Prints the main metrics and the dashboard link.

It exits non-zero if the build or the quality gate fails. `pom.xml` points at SonarQube Cloud, so the script overrides the server URL and project key and clears the organization. Set `SONAR_LOCAL_URL` or `SONAR_LOCAL_PROJECT_KEY` to use other values.

The first scan, on 2026-10-11 against SonarQube 26.9, passed the quality gate: 100% coverage, 0 bugs, 0 vulnerabilities, and 1 code smell (`java:S106` in `App.main`; see [Gotchas](#gotchas)).

`.env` is in `.gitignore`. Never put token values in docs or anything else that is committed.

Stop the server with `docker stop sonarqube`, and start it again with `docker start sonarqube`.

### How do I read the results from the terminal?

The dashboard is at http://localhost:9000/dashboard?id=java-project-template. The same data is in the Web API, which is easier to script. For SonarQube Cloud, use `https://sonarcloud.io`, the SonarQube Cloud token, and the project key `theautonomy_java-project-template`.

```bash
TOKEN=$(grep -E '^LOCAL_SONAR_ACCESS_TOKEN=' .env | cut -d= -f2- | tr -d '\r')
S=http://localhost:9000
P=java-project-template
AUTH="Authorization: Bearer $TOKEN"
```

1. **Wait for processing.** The scanner only uploads a report; the server analyzes it in a background task. Repeat until the response contains `"queue":[]`. Or scan with `-Dsonar.qualitygate.wait=true` and skip this step.

   ```bash
   curl -s -H "$AUTH" "$S/api/ce/component?component=$P"
   ```

2. **Quality gate status:**

   ```bash
   curl -s -H "$AUTH" "$S/api/qualitygates/project_status?projectKey=$P"
   # {"projectStatus":{"status":"OK",...}}
   ```

3. **Metrics.** Ratings come back as numbers: 1.0 = A, 2.0 = B, 3.0 = C, and so on.

   ```bash
   curl -s -H "$AUTH" "$S/api/measures/component?component=$P&metricKeys=coverage,line_coverage,bugs,vulnerabilities,code_smells,security_hotspots,duplicated_lines_density,ncloc,reliability_rating,security_rating,sqale_rating"
   ```

4. **Open issues,** with counts by severity and rule:

   ```bash
   curl -s -H "$AUTH" "$S/api/issues/search?componentKeys=$P&resolved=false&ps=100&facets=severities,rules"
   ```

   - `ps` is the page size (maximum 500); page with `&p=2`, `&p=3` and so on.
   - Narrow the list with `&severities=CRITICAL,BLOCKER`, `&types=BUG` or `&rules=java:S106`.
   - Each issue has `severity`, `type`, `rule`, `component` (the file), `line` and `message`.

## Gotchas

| Problem | Cause | Fix |
| --- | --- | --- |
| "Organization not found" or similar | `sonar.organization` holds the organization's display name | Use its key (see [One-time setup](#one-time-setup-with-the-sonar-api-and-gh)) |
| CI scan rejected: "running CI analysis while Automatic Analysis is enabled" | Both analysis methods are on | Turn off Automatic Analysis |
| PR or branch results say "project does not exist" or "not allowed to access data from non main branches" | On the free plan, a **private** project only shows its main branch | Keep the repository public, or limit `sonar.yml` to pushes to `main` |
| A secret named `SONAR-TOKEN` can't be created | GitHub secret names allow only letters, digits and `_` | Use `SONAR_TOKEN` |
| New code and blame are missing | Shallow checkout | `fetch-depth: 0` (already set) |
| Coverage is 0% | Scanned without running the tests first | Run `verify` (or at least `test`) before `sonar:sonar`, in the same command |
| `App.main` flagged for `System.out` (rule `java:S106`) | Expected in a sample command-line app | Accept it, or mark the issue as "Accepted" in SonarQube |

## How does it fit with the other code-quality tools?

| Tool | What it covers | Fails the build? |
| --- | --- | --- |
| Spotless | Formatting (see [spotless-usage.md](spotless-usage.md)) | Yes, in `verify` |
| Maven Enforcer | Java and Maven versions, dependency convergence | Yes, at the start of every build |
| JaCoCo | Line coverage of at least 80% | Yes, in `verify` |
| SonarQube Cloud | Bugs, smells, security hotspots, duplication, coverage trends | No, unless `-Dsonar.qualitygate.wait=true` is added |
| Claude Code Review | Correctness and design issues in each PR | No; it comments on the PR |
