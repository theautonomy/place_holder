# Restricting a GitHub Actions workflow to one branch

## How do I make a workflow (e.g. a deployment) run only from one branch?

Use three layers. The first two prevent accidental runs; only the third, a GitHub environment with a branch rule, actually enforces it.

| Layer | Where it lives | Stops | Can be bypassed by |
| --- | --- | --- | --- |
| 1. Trigger filter | Workflow file | Automatic runs from other branches | Editing the workflow file on another branch |
| 2. Job guard (`if:`) | Workflow file | Manual runs started from other branches | Editing the workflow file on another branch |
| 3. Environment + branch rule | Repository settings | Any job using that environment from another branch, and access to its secrets | Only repository admins |

## 1. What does the trigger filter do?

It decides when the workflow starts:

```yaml
on:
  push:
    branches: [ main ]
```

For example, a release workflow with `on.push.branches: [ "release" ]` starts only on pushes to `release`. Pushes to other branches do not start it.

## 2. Why add a job guard?

If the workflow also has `workflow_dispatch` (the "Run workflow" button), GitHub lets you pick **any branch** in that dropdown. Add a condition to the job:

```yaml
on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  deploy:
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
```

Runs started from another branch are then skipped.

## Why are layers 1 and 2 not enough?

- **Each branch has its own copy of the workflow file.** Anyone who can push a branch can edit that copy, remove the `if`, and run it from their branch.
- **Repository secrets are available to workflows on every branch.** A workflow on any branch could use, for example, `DOCKERHUB_TOKEN` and push an image.

## 3. How does an environment enforce it?

1. **Create the environment:** go to **Settings → Environments → New environment**, e.g. `production`.
2. **Restrict branches:** under **Deployment branches and tags**, choose **Selected branches and tags** and add the deploy branch (`main` or `release`).
3. **Move the secrets:** add the deployment secrets (for example `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`) as **Environment secrets**, then delete them from the repository secrets.
4. **Optional approvals:** under **Deployment protection rules**, add **Required reviewers**, so a person must approve each deployment before it runs. This is not needed to restrict the branch; steps 2 and 3 do that.
5. **Use it in the workflow:**

   ```yaml
   jobs:
     deploy:
       runs-on: ubuntu-latest
       environment: production   # only allowed branches can run this job; secrets come from the environment
       steps:
         - run: echo "${{ secrets.DOCKERHUB_TOKEN }}" ...
   ```

GitHub checks the branch rule on its own servers, before the job starts and before any secret is handed out. A job on another branch that names `environment: production` is rejected; a job without it never sees the secrets.

## Which GitHub plans support this?

All of it is free on public repositories. On private repositories it depends on the plan ([GitHub docs](https://docs.github.com/en/actions/reference/workflows-and-actions/deployments-and-environments)):

| Feature | Needed for | Public repo | Private repo |
| --- | --- | --- | --- |
| Environment secrets | Restricting the branch | All plans | Pro, Team or Enterprise (not Free) |
| Deployment branches and tags | Restricting the branch | All plans | Pro, Team or Enterprise (not Free) |
| Required reviewers, wait timers | Optional approval step | All plans | Enterprise only |
| Branch protection / rulesets | Protecting the deploy branch | All plans | Pro, Team or Enterprise (not Free) |

So on GitHub Free with a private repository, only layers 1 and 2 are available. If **Required reviewers** is missing from the environment page, the plan does not include it.

## Can't someone just edit the workflow on their branch?

They can, but it does not help them. The branch rule and the secrets live in repository settings, not in the workflow file:

| Change on their branch | Result |
| --- | --- |
| Keep `environment: production` | GitHub checks the branch rule against their branch and rejects the job before it starts. |
| Remove `environment:` | The job runs, but without the environment's secrets, so it has no deploy credentials. |

This only holds if:

1. **No repository secrets.** Every deploy credential is an environment secret, with no repository-level copy.
2. **The deploy branch is protected.** Otherwise pushing directly to it satisfies the branch rule (see below).
3. **Tags are restricted.** If the environment allows tag patterns such as `v*`, limit who can create those tags with a tag ruleset.
4. **OIDC trust is tied to the environment.** If the workflow logs in to a cloud provider via OIDC, the trust policy must require the environment (for example the subject `repo:owner/repo:environment:production`), not just the repository.
5. **`GITHUB_TOKEN` is read-only by default** (Settings → Actions → General), so a branch workflow cannot push to the deploy branch with it.
6. **Admins are trusted.** Repository admins can change environments and rulesets.

## Should I also protect the branch?

Yes. The environment controls *which branch* can deploy; branch protection controls *who can change* that branch. Under **Settings → Rules → Rulesets** (or **Branches**), protect the deploy branch:

- require pull requests,
- block force pushes,
- optionally require the `Build` check to pass.

Then "deploy from main" really means "deploy reviewed code".

## What does this mean for this repo?

`.github/workflows/deploy.yml` is a sample deployment that uses all three layers. Its deploy step only prints what it would deploy.

| Layer | In this repo |
| --- | --- |
| 1. Trigger | `workflow_dispatch` only: it never runs by itself |
| 2. Job guard | `if: github.ref_name == github.event.repository.default_branch`. It names the default branch rather than `main`, so the rule stays right if the default branch is renamed |
| 3. Environment | `environment: production`. The `production` environment allows deployments only from `main` (**Settings → Environments → production → Deployment branches and tags**) |

The branch is also protected: the `protect-main` ruleset requires a PR and the `Build and test` check, and blocks force pushes and deletion. So "deploy from `main`" means "deploy reviewed code". The repository is private, and the environment's branch rule works on its plan.

### Tested on 2026-10-11

| Test | How | Result |
| --- | --- | --- |
| Deploy from `main` | `gh workflow run deploy.yml --ref main` | Ran; GitHub recorded a deployment to `production` from `main` |
| Deploy from another branch | Pushed `test/deploy-guard`, then `gh workflow run deploy.yml --ref test/deploy-guard` | Job **skipped** by the guard (layer 2); no deployment |
| Remove the guard on that branch, then deploy | Deleted the `if:` line in the branch's `deploy.yml`, committed, ran it again | Job **rejected** before any step ran: "Branch "test/deploy-guard" is not allowed to deploy to production due to environment protection rules." (layer 3) |

The third test is the one that matters: editing the workflow on a branch gets past layers 1 and 2, but not the environment.

To repeat the tests (and delete the test branch afterwards):

```bash
R=theautonomy/java-project-template
gh workflow run deploy.yml -R $R --ref main                      # expect: success
git push origin main:refs/heads/test/deploy-guard
gh workflow run deploy.yml -R $R --ref test/deploy-guard         # expect: skipped
# remove the "if:" line from deploy.yml on test/deploy-guard, commit, push, then:
gh workflow run deploy.yml -R $R --ref test/deploy-guard         # expect: failure, "not allowed to deploy to production"
gh run list -R $R -w deploy.yml -L 3
git push origin --delete test/deploy-guard
```

Before a real deployment uses this workflow, put its credentials in the `production` environment as **environment secrets**, never as repository secrets (see [layer 3](#3-how-does-an-environment-enforce-it)).
