# How Claude Code is used on GitHub

## What is it?

Two workflows run [Claude Code](https://code.claude.com) in GitHub Actions through [`anthropics/claude-code-action`](https://github.com/anthropics/claude-code-action). One answers when someone asks; the other reviews every PR on its own.

| Workflow | Runs when | Does |
| --- | --- | --- |
| `.github/workflows/claude.yml` (**Claude Code**) | Someone mentions `@claude` | Whatever the comment asks |
| `.github/workflows/claude-code-review.yml` (**Claude Code Review**) | A PR is opened or updated | Reviews the PR and posts confirmed issues |

Claude follows [AGENTS.md](../AGENTS.md) for the project's rules and commands. Claude Code reads `CLAUDE.md`, not `AGENTS.md`, so [CLAUDE.md](../CLAUDE.md) contains only `@AGENTS.md`, which imports it. Both workflows stop after 30 minutes. Runs are billed to the Claude subscription that owns `CLAUDE_CODE_OAUTH_TOKEN`, and they count toward its usage limits.

### `claude.yml`: Claude Code, on request

**Triggered by** a new `@claude` mention in:

- the title or body of an issue, when it is opened or assigned
- a comment on an issue or PR
- an inline comment on a PR's code
- the summary of a PR review

Mentions in edited comments don't trigger it, and neither do mentions from people without write access to the repository.

**Does** whatever the comment asks:

- **Questions, explanations, reviews:** Claude answers in a comment. It first posts "working…", then updates that comment with the answer and a link to the run.
- **Changes:** Claude commits on a new `claude/…` branch and posts a link to open a PR. It can't push to `main` or change files under `.github/workflows/`.
- **Tools:** it has Java 21, so it can run `./mvnw verify`, and it can read the CI results of a PR (`actions: read`).

### `claude-code-review.yml`: Claude Code Review, automatic

**Triggered by** a pull request being opened, reopened, marked ready for review, or getting new commits. Nobody needs to ask. PRs from Dependabot are skipped, because they get no Actions secrets.

**Does** run the [`code-review` plugin](https://github.com/anthropics/claude-code/blob/main/plugins/code-review/commands/code-review.md) (`/code-review:code-review <repo>/pull/<number> --comment`), which works in steps:

1. **Decide whether to review.** It stops if the PR is closed, a draft, a trivial change that is obviously correct, or **already commented on by Claude**. In practice, each PR gets one automatic review, and later pushes aren't reviewed again.
2. **Review** with several agents in parallel: two check the change against `CLAUDE.md` (and so `AGENTS.md`), and two look for bugs in the changed code.
3. **Validate** each finding with another agent, and drop the ones it can't confirm. Style, nitpicks, and anything a linter would catch are left out on purpose.
4. **Post** the result: the confirmed issues with suggested fixes and links to the lines, or "No issues found". The plugin is asked to post one inline comment per issue, but on test PR #12 it posted both issues in a single summary comment.

## How is it set up?

It needs two things, and both workflows share them:

| What | Why | Where |
| --- | --- | --- |
| The **Claude GitHub app**, installed on this repository | The action exchanges the workflow's OIDC token (`id-token: write`) for an app token, and uses it to comment, and to push branches | https://github.com/apps/claude |
| The **`CLAUDE_CODE_OAUTH_TOKEN`** repository secret | Authenticates Claude Code with your Claude subscription | Created with `claude setup-token` |

### Setting it up with `claude` and `gh`

Run these in a Bash shell: Git Bash on Windows, or any terminal on Linux or macOS. If a `GITHUB_TOKEN` environment variable is set, run `unset GITHUB_TOKEN` first, or `gh` ignores your login (see [sonar-usage.md](sonar-usage.md#prerequisites)).

```bash
R=theautonomy/java-project-template
```

1. **Install the app.** Open https://github.com/apps/claude/installations/new, pick the account, choose **Only select repositories**, and select `java-project-template`. Only a browser can do this; there is no API for installing an app.

2. **Create the token and store it as a secret.** `claude setup-token` opens the browser to log in to your Claude account, then prints a long-lived OAuth token (`sk-ant-oat01-…`, valid for one year):

   ```bash
   claude setup-token
   gh secret set CLAUDE_CODE_OAUTH_TOKEN -R $R   # paste the token at the prompt
   gh secret list -R $R
   ```

   Pasting at the prompt keeps the token out of shell history. Don't put it in `.env` or anywhere else in the repository.

3. **Test it.** Open an issue that mentions `@claude`, and wait for the run:

   ```bash
   issue=$(gh issue create -R $R --title "@claude test" --body "@claude What does App.greet return for a blank name? Answer in one sentence.")
   sleep 10
   id=$(gh run list -R $R -w claude.yml -L 1 --json databaseId --jq '.[0].databaseId')
   gh run watch $id -R $R --exit-status
   gh issue view "$issue" -R $R --comments
   gh issue close "$issue" -R $R
   ```

   Claude replies in a comment on the issue, and the last command closes the issue. The first test, on 2026-10-11 (issue #8), got the correct answer in 6 seconds.

The alternative is to run `/install-github-app` inside Claude Code. It installs the app and sets the secret in one go, and also opens a PR with its own copies of the two workflows. Close that PR: this repository already has them.

## The Claude GitHub app

### What it can do

The app gives the workflows a token that acts as `claude[bot]`. With it, Claude can:

| Can | Can't |
| --- | --- |
| Read the repository's code, issues and pull requests | Change files under `.github/workflows/`: the app lacks GitHub's `workflows` permission |
| Comment on issues and PRs, and post review comments | Push to `main`: the `protect-main` ruleset requires a PR |
| Create branches and push commits to them | Merge PRs, change settings, or read secrets |

It acts only through the workflows in this repository. Installing it does nothing until a workflow runs. The exact permissions are listed on the app's **Configure** page (below), and GitHub asks you to approve any change to them.

### Is it installed?

`gh` can't list app installations: GitHub only allows that with a token from the app itself. To check:

- **In the browser:** go to **Settings → Applications → Installed GitHub Apps** on your account (https://github.com/settings/installations), or the organization's settings for an organization repository. **Claude** should be listed. Click **Configure** to see which repositories it can access.
- **With a test:** run the test from [step 3](#setting-it-up-with-claude-and-gh). A missing app fails with "Claude Code is not installed on this repository".

### Adding or removing repositories, and uninstalling

All of these are on the app's **Configure** page (https://github.com/settings/installations → **Claude** → **Configure**):

- **Add a repository,** for example a new project created from this template. Under **Repository access**, add it to **Only select repositories** and save. The new repository also needs its own `CLAUDE_CODE_OAUTH_TOKEN` secret, or an organization-level secret.
- **Remove a repository:** remove it from the list. Its workflows then fail with the 401 error above.
- **Uninstall:** scroll to **Danger zone → Uninstall**. Also delete the `CLAUDE_CODE_OAUTH_TOKEN` secrets, and remove or disable the workflows.

Prefer **Only select repositories** over **All repositories**, so new repositories get Claude only when you add them.

### Organizations

For a repository owned by an organization, only an organization owner can install the app. A member who tries to install it sends a request that an owner must approve. Store the token as an organization secret (**Organization settings → Secrets and variables → Actions**) to share it across repositories, and limit it to the repositories that use Claude.

## How do I use it?

| You want | Do |
| --- | --- |
| A check for real bugs on every PR | Nothing: Claude Code Review runs on its own |
| Broader feedback, including wording, design and style | Comment `@claude review this PR` (runs Claude Code) |
| A review after more pushes | Comment `@claude review this again`; the automatic review doesn't run twice |
| An answer about the code or the build | Comment, e.g. `@claude why does the build fail?` |
| Claude to implement something | Describe it in an issue, then comment `@claude implement this` |
| A review before opening the PR | Run `/code-review` in Claude Code on your machine |

## How is it configured?

Both workflows:

- **Use `permissions` to limit the workflow's own `GITHUB_TOKEN` to reading.** Claude comments and pushes with the app token instead, which is limited by the app's installation (contents, issues and pull requests) and by the ruleset. The app can't change files under `.github/workflows/`.
- **Have `timeout-minutes: 30`,** which stops runaway runs.
- **Pin `anthropics/claude-code-action` to a full commit SHA,** with the version in a comment (`@1d6de8c… # v1.0.248`), so the code that runs can't change under the same name. Dependabot's weekly `github-actions` update bumps the SHA and the comment together.

Only `claude.yml`:
- grants `actions: read`, plus `additional_permissions: actions: read`, so Claude can read CI results on a PR
- sets up Java 21

Only `claude-code-review.yml`:
- skips Dependabot PRs, which get no Actions secrets
- runs `/code-review:code-review <repo>/pull/<number> --comment`

Ways to change what Claude does (inputs of `claude-code-action`, see its [usage docs](https://github.com/anthropics/claude-code-action/blob/main/docs/usage.md)):

| Input | Use |
| --- | --- |
| `prompt` | A fixed task instead of the comment's text, as `claude-code-review.yml` does with `/code-review:code-review` |
| `claude_args` | Claude Code CLI options, for example `--model`, `--max-turns`, or `--allowed-tools "Bash(./mvnw:*)"` |
| `plugins`, `plugin_marketplaces` | Extra Claude Code plugins, like the `code-review` plugin |
| `additional_permissions` | Lets Claude read more, for example `actions: read` to see CI results |

## Gotchas

| Problem | Cause | Fix |
| --- | --- | --- |
| Run fails with "App token exchange failed: 401 Unauthorized - Claude Code is not installed on this repository" | The app is missing, or installed on other repositories only | Install it on this repository (step 1), or add the repository on the app's Configure page (see [The Claude GitHub app](#the-claude-github-app)) |
| Run fails with an authentication error, and the log shows `claude_code_oauth_token: ""` | The secret is missing or misspelled | `gh secret set CLAUDE_CODE_OAUTH_TOKEN` (step 2) |
| It worked, then fails with an authentication error months later | The token expired; `setup-token` tokens last one year | Run step 2 again |
| `@claude` gets no response, and no run starts | The workflow file isn't on the default branch yet, the commenter lacks write access, or the mention is in an edited comment (only new comments trigger it) | Merge the workflow; write a new comment |
| `claude-review` fails on a PR | Same causes as the first two rows | The check isn't required by the ruleset, so it doesn't block merging |
| `claude-review` succeeds but posts nothing, on every PR | The prompt lacks `--comment`. Without it, the plugin writes its review only to the log, which is hidden. This was the case here until 2026-10-11 | Keep `--comment` at the end of the prompt |
| `claude-review` succeeds in a few seconds but posts nothing on one PR | The plugin decided not to review: the PR is closed, a draft, a trivial change, or Claude has already commented on it | Expected. Comment `@claude review this PR` for a review anyway |
| `claude-review` passes in seconds on a PR that changes `claude-code-review.yml`, and the log says "Workflow validation failed… must have identical content to the version on the repository's default branch" | A safety rule in the action: it runs only the workflow version on `main`, so a PR can't change what Claude does with the secrets | Expected. The change takes effect for PRs opened after it is merged |
| Claude says it can't change a workflow file | GitHub doesn't give the Claude app the `workflows` permission | Change files under `.github/workflows/` yourself |
| You need Claude's reasoning from a run | The action hides Claude's output by default, even with debug logging | `show_full_output: true`, temporarily: it can put file contents and secrets that Claude read into the log |
| SonarQube reports `githubactions:S7637` ("Use full commit SHA hash") | A third-party action is referenced by a tag such as `@v1`, which its owner can move | Pin it to the full commit SHA, with the version in a comment. Find the SHA with `gh api repos/<owner>/<action>/git/ref/tags/<tag>`; for an annotated tag, follow `.object.sha` with `gh api repos/<owner>/<action>/git/tags/<sha>` |
