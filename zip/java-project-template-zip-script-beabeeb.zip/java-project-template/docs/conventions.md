# Project conventions

This repository is the reference for how our Java projects are set up. The `main` branch is a plain Java project; other branches (for example a Spring Boot variant) build on it and keep these conventions.

## What is enforced, and where

| Convention | Enforced by | Fix or check locally |
| --- | --- | --- |
| Java 21 | `maven.compiler.release` and Enforcer `requireJavaVersion` in `pom.xml` | Install JDK 21 or later |
| Maven 3.9+, same version for everyone | Maven Wrapper (`.mvn/wrapper/maven-wrapper.properties`), Enforcer `requireMavenVersion` | Always use `./mvnw`, not `mvn` |
| No conflicting dependency versions | Enforcer `dependencyConvergence`, `banDuplicatePomDependencyVersions` | `./mvnw dependency:tree` |
| Code formatting | Spotless (Palantir Java Format, GOOGLE style: 2-space indent, 100 columns), `spotless:check` at `verify` | `./mvnw spotless:apply` |
| Imports: ordered, no unused, no wildcards | Spotless `importOrder`, `removeUnusedImports`, `forbidWildcardImports` | `./mvnw spotless:apply` (wildcards must be expanded by hand) |
| `pom.xml` element order | Spotless `sortPom` | `./mvnw spotless:apply` |
| Tests with JUnit 6 (Jupiter API) and AssertJ | `junit-bom` and `assertj-core` in `pom.xml` | `./mvnw test` |
| Line coverage of 80% or more | JaCoCo `check` at `verify` (`jacoco.minimum.line.coverage`) | Report: `target/site/jacoco/index.html` |
| Editor settings (charset, LF, indent, final newline) | `.editorconfig` (see [EDITORCONFIG.md](EDITORCONFIG.md)) | Most IDEs apply it automatically |
| LF line endings in git; `*.cmd`/`*.bat` committed with CRLF and never converted (`-text`) | `.gitattributes` (see [GITATTRIBUTES.md](GITATTRIBUTES.md), and [why `-text`](GITATTRIBUTES.md#files-committed-without-git-dependabot-and-the-github-api)) | `git ls-files --eol` |
| Reviews by code owners | `.github/CODEOWNERS` | |
| Every push and PR builds | `.github/workflows/compile.yml` runs `./mvnw verify` | `./mvnw verify` |
| Deploys only from the default branch | `.github/workflows/deploy.yml` (see [github-actions-branch-restrictions.md](github-actions-branch-restrictions.md)) | |
| Claude Code on your machine follows the project rules and formats its Java | `CLAUDE.md` (imports `AGENTS.md`), `.claude/settings.json` (permissions, Stop hook running Spotless); see [claude-code-setup.md](claude-code-setup.md) | `claude` in the repository root |
| `@claude` in issues and PRs runs Claude Code | `.github/workflows/claude.yml` (follows `AGENTS.md`; see [claude-github-usage.md](claude-github-usage.md)) | Needs the `CLAUDE_CODE_OAUTH_TOKEN` secret |
| Static analysis and coverage tracked over time | `.github/workflows/sonar.yml` (SonarQube Cloud; `sonar.*` properties in `pom.xml`; see [sonar-usage.md](sonar-usage.md)) | Needs the `SONAR_TOKEN` secret |
| Every PR gets an automatic Claude review | `.github/workflows/claude-code-review.yml` (code-review plugin; skips Dependabot PRs) | Same secret; `/code-review` in Claude Code locally |
| Dependency and action updates | `.github/dependabot.yml`: weekly, 3-day cooldown, minor/patch grouped, each major update a separate PR (see [dependency-updates.md](dependency-updates.md)) | Merge green minor/patch PRs; decide majors one by one |

`./mvnw verify` runs everything: compile, tests, Enforcer, Spotless and JaCoCo. If it passes locally, CI passes.

Formatting differs from [spotless-usage.md](spotless-usage.md), which describes another project. Here the indent is 2 spaces (Palantir `GOOGLE` style), and `spotless:check` is bound to `verify`, not `compile`. Edit-compile-test loops are never blocked by formatting; CI and `verify` still are.

## Code style beyond the formatter

- Base package `com.example.reference`; one top-level type per file.
- Tests live in the same package as the code they test, in `src/test/java`, and are named `<Class>Test`.
- Use `@DisplayName` to say what a test checks, and AssertJ (`assertThat`) for assertions.
- Use `// spotless:off` and `// spotless:on` only where hand alignment is clearly more readable.

## The deploy workflow

`deploy.yml` is a sample: it builds and then prints what it would deploy. It shows three layers of branch restriction:

1. **Trigger:** `workflow_dispatch` only, so it never runs automatically.
2. **Job guard:** `if: github.ref_name == github.event.repository.default_branch` skips runs started from other branches.
3. **Environment:** `environment: production`. Only this layer is actually enforced, and it must be set up in GitHub (below).

## GitHub settings to apply by hand

These live in repository settings, not in files, so apply them once per repository:

- [ ] **Settings → Environments → New environment** `production`. Under **Deployment branches and tags**, choose **Selected branches and tags** and add the default branch (`main`).
- [ ] Put any deploy secrets in the `production` environment, never in repository secrets.
- [ ] **Settings → Rules → Rulesets:** protect `main` (ruleset `protect-main`). Require a pull request, require the `Build and test` status check, require conversations to be resolved, and block force pushes and deletion. With a single maintainer, require 0 approvals: GitHub never lets you approve your own PR. With a team, require 1 approval and code-owner review.
- [ ] **Settings → Actions → General → Workflow permissions:** keep the default `GITHUB_TOKEN` read-only.
- [ ] Install the [Claude GitHub app](https://github.com/apps/claude) on this repository and add the `CLAUDE_CODE_OAUTH_TOKEN` repository secret: see [claude-github-usage.md](claude-github-usage.md#setting-it-up-with-claude-and-gh).
- [ ] In [SonarQube Cloud](https://sonarcloud.io), import the repository, check that its organization **key** (not its display name) and project key match `sonar.organization` and `sonar.projectKey` in `pom.xml`, turn off **Automatic Analysis** (it conflicts with the CI analysis), and add the generated token as the `SONAR_TOKEN` repository secret. Or do all of it from the command line: see [sonar-usage.md](sonar-usage.md#one-time-setup-with-the-sonar-api-and-gh).
- [ ] **Settings → Code security:** enable Dependabot alerts and security updates.

On a private repository, environments and rulesets need GitHub Pro, Team or Enterprise. See the plan table in [github-actions-branch-restrictions.md](github-actions-branch-restrictions.md#which-github-plans-support-this).

## Branches for other project types

Branch from `main` for each variant. Keep the convention files as they are, and change `pom.xml`, the code, and this document only where the variant needs it. When a convention changes on `main`, merge it into the variant branches.

| Branch | Variant |
| --- | --- |
| `main` | Plain Java |
| `spring-boot` | Spring Boot 4 web application; see [docs/spring-boot.md](https://github.com/theautonomy/java-project-template/blob/spring-boot/docs/spring-boot.md) on that branch |
