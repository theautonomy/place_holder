# Dependency updates

Dependencies, build plugins, the Maven Wrapper and GitHub Actions are kept up to date by [Dependabot](https://docs.github.com/en/code-security/dependabot), configured in [`.github/dependabot.yml`](../.github/dependabot.yml). This page explains that setup, how to handle its PRs, and how it compares with [Renovate](https://docs.renovatebot.com), which some projects use instead (`renovate.json`).

## What Dependabot does here

There are two kinds of updates:

| Kind | Turned on in | When | What |
| --- | --- | --- | --- |
| **Version updates** | `.github/dependabot.yml` | Weekly | Newer versions of everything in `pom.xml` (dependencies and plugins), the Maven version in `.mvn/wrapper/maven-wrapper.properties`, and the `uses:` versions in `.github/workflows/` |
| **Security updates** | **Settings → Code security** | As soon as GitHub publishes an advisory | The smallest upgrade that fixes a known vulnerability. Ignores the schedule and the cooldown |

### The configuration

| Setting | Value | Why |
| --- | --- | --- |
| `schedule` | weekly | One batch of PRs a week is easy to keep up with |
| `cooldown` | 3 days; 14 days for major versions (Maven) | A brand-new release waits a few days, so a broken release is usually fixed or withdrawn before you see it |
| `groups` | `maven-plugins`, `test-dependencies`, `github-actions` | One PR per group instead of one per dependency |
| `update-types: [minor, patch]` on each group | | Minor and patch updates are grouped. **Each major update comes as its own PR**, so it gets a deliberate decision instead of hiding in a group |

Anything not in a group gets its own PR.

**The `spring-boot` branch** has its own Maven entry (`target-branch: spring-boot`). Dependabot reads its configuration only from the default branch, so that entry lives in `main`'s `dependabot.yml`. Its groups fit that branch: `spring-boot` (the parent, which brings most versions), `maven-plugins` (only those Boot doesn't manage), and `test-dependencies` (ArchUnit). There's no GitHub Actions entry for it: its workflows must stay identical to `main`'s, so action updates reach it when `main` is merged in. The Maven Wrapper's Maven version is the main example.

Versions held in `<properties>` are fine: Dependabot updates `<junit.version>6.1.3</junit.version>` directly. For actions pinned to a commit SHA (`@1d6de8c… # v1.0.248`), it updates the SHA and the version comment together.

## Handling Dependabot PRs

1. **Check `Build and test`.** Compile runs `./mvnw verify` on every Dependabot PR: compile, tests, Spotless, Enforcer, JaCoCo. The `protect-main` ruleset won't merge a PR without it. Claude Code Review and SonarQube skip Dependabot PRs, because GitHub doesn't give those PRs the repository's Actions secrets.
2. **Minor and patch, grouped:** merge when green. Read the release notes in the PR description if something looks unusual.
3. **Major, one per PR:** decide on purpose. Read the migration notes. If you take it, update anything that names the version (e.g. "JUnit 6" in `README.md`, `AGENTS.md`, `docs/conventions.md`) in the same PR or right after. If you don't, comment `@dependabot ignore this major version`.
4. **A new Spotless or Palantir version that formats differently** fails the Spotless check. Run `./mvnw spotless:apply` on the PR branch and push.

Comment commands on a Dependabot PR:

| Comment | Effect |
| --- | --- |
| `@dependabot rebase` | Rebase the PR on `main` |
| `@dependabot recreate` | Rebuild the PR from scratch, dropping any commits you added |
| `@dependabot ignore this major version` / `minor version` / `dependency` | Stop proposing that version range or dependency. Undo with `@dependabot unignore …` |
| `@dependabot show <dependency> ignore conditions` | List the ignores in effect |

### Known issue: Maven Wrapper updates and line endings

Dependabot commits through the GitHub API, which skips `.gitattributes`. Its Maven Wrapper update stored `mvnw.cmd` with CRLF. That's why `.cmd`/`.bat` files use `-text` and are committed with CRLF here. See [GITATTRIBUTES.md](GITATTRIBUTES.md#files-committed-without-git-dependabot-and-the-github-api).

### History in this repository

| PR | Update | Note |
| --- | --- | --- |
| #2, #3, #5, #7 | Grouped plugin, test and action updates | Merged when green |
| #4 | Maven 3.9.11 → 3.10.0 (Maven Wrapper) | Stored `mvnw.cmd` with CRLF; led to the `-text` rule |
| #10 | JUnit 5.13.4 → 6.1.3 | A major update inside the `test-dependencies` group, before `update-types` was set; led to the docs update in #11 and to grouping only minor and patch updates |

## Dependabot or Renovate?

[Renovate](https://docs.renovatebot.com) is a dependency-update bot by Mend, configured with `renovate.json`. It does the same job with more options.

| | Dependabot | Renovate |
| --- | --- | --- |
| Setup | Built into GitHub; a YAML file | Install the [Mend Renovate app](https://github.com/apps/renovate) (free, also for private repositories), then `renovate.json` |
| Maven, GitHub Actions, Maven Wrapper | Yes | Yes |
| Security updates | Built in, from GitHub's vulnerability alerts | Supported, set up separately (`vulnerabilityAlerts`, OSV data) |
| Grouping | `groups` by pattern and update type | Rules by pattern, type, and ready-made presets (e.g. all non-major updates, monorepo groups) |
| Waiting for new releases | `cooldown` | `minimumReleaseAge` |
| Merging safe updates automatically | Not built in: needs a workflow running `gh pr merge --auto` | Built in (`automerge`); still waits for the ruleset's required checks |
| Overview | Only the open PRs | A "Dependency Dashboard" issue: pending, held back, ignored, errored |
| Pinning actions to SHAs | Updates existing pins | Can create the pins too (`helpers:pinGitHubActionDigests`) |
| Shared policy across repositories | Copy the file | Shareable config presets (`"extends": ["github>org/renovate-config"]`) |
| Configuration | Small | Large; powerful, and easy to over-configure |

**This repository uses Dependabot:**
- A template should have few moving parts. Dependabot needs no third-party app, and it covers everything used here.
- What Renovate adds mostly pays off at scale. With two dependencies and a handful of plugins, a few grouped PRs a week are easy to review by hand.
- Neither tool holds back major upgrades by default. Here, `update-types` keeps them out of groups, so each one is a visible, separate PR.

**Consider Renovate when:**
- a project has many dependencies (a Spring Boot service, for example) and merging patch and minor updates automatically would save real time
- several repositories should share one update policy
- you want the Dependency Dashboard's overview

**Never run both** on one repository: they open duplicate PRs for the same updates. To switch, delete `.github/dependabot.yml` (keep the security updates setting if you want GitHub's alerts) and install Renovate with a `renovate.json`.
