# How Spotless is used in Feedback Hub

> **This repository differs.** This doc describes the Feedback Hub project. In this repository Palantir Java Format uses `<style>GOOGLE</style>` (2-space indent, 100 columns), `spotless:check` is bound to `verify` instead of `compile`, and `forbidWildcardImports`, `toggleOffOn`, `formatJavadoc` and `sortPom` are turned on. See [conventions.md](conventions.md) and `pom.xml`.

## What is Spotless?

Spotless (`com.diffplug.spotless:spotless-maven-plugin`, version 3.10.3) is a code formatter plugin for Maven. It formats Java code one fixed way, so nobody argues about style and diffs only show real changes. It has two goals: `spotless:apply` rewrites files, and `spotless:check` fails the build if any file is not already formatted.

## What does it enforce?

The plugin is configured in `feedbackhub/pom.xml` for Java only. By default it covers `src/main/java` and `src/test/java`; templates, CSS, JS and SQL are not formatted.

| Step | What it does |
| --- | --- |
| `palantirJavaFormat` (2.100.0) | Formats code in Palantir Java Format style: 4-space indent, 120-column lines, lambda-friendly wrapping. |
| `importOrder` | Sorts imports in a fixed order. |
| `removeUnusedImports` | Deletes imports that nothing uses. |
| `formatAnnotations` | Puts type annotations on the same line as the type they annotate. |

## When does it run?

| How | What happens |
| --- | --- |
| `./mvnw spotless:apply` (or `task format`) | Rewrites files in place. This is the command in `AGENTS.md`. |
| Every Maven build | `spotless:check` is bound to the `compile` phase, so `compile`, `test`, `verify`, `package` and `spring-boot:run` all fail on unformatted code. |
| `task test` | Runs `task format` first, then `./mvnw clean verify`, so local test runs never fail on formatting. |
| CI (`.github/workflows/ci.yml`) | Runs `./mvnw -ntp verify`, which includes the check, so an unformatted push fails CI. |

On 2026-10-07 `./mvnw -pl feedbackhub spotless:check` passed on the current code.

## What should I do when the check fails?

Run the formatter and commit the result:

```bash
./mvnw spotless:apply
```

The failure message lists each file and the expected diff. Never hand-format to match it; let `spotless:apply` do it.

## What other Java options does Spotless offer?

From the [spotless-maven-plugin README](https://github.com/diffplug/spotless/blob/main/plugin-maven/README.md). Options marked † were not in the fetched copy of that page (it came back truncated) and are from memory; check them before relying on them.

### Which files it covers

```xml
<java>
  <includes><include>src/main/java/**/*.java</include></includes>  <!-- default: src/main/java + src/test/java -->
  <excludes><exclude>**/generated/**</exclude></excludes>         <!-- † -->
</java>
```

### Formatter (pick one)

| Step | Main options |
| --- | --- |
| `<palantirJavaFormat>` (used here) | `version`, `style` (`PALANTIR` / `AOSP` / `GOOGLE`), `formatJavadoc` |
| `<googleJavaFormat>` | `version`, `style` (`GOOGLE` 2-space / `AOSP` 4-space), `reflowLongStrings`, `formatJavadoc`, `reorderImports`, `groupArtifact` |
| `<eclipse>` | `version`, `file` (an Eclipse formatter XML), and member sorting: `sortMembersEnabled`, `sortMembersOrder`, `sortMembersVisibilityOrder` |
| `<princeOfSpace>` | `indentStyle`, `indentSize`, `lineLength`, `wrapStyle`, `trailingCommas`, `javaLanguageLevel` |
| `<prettier>` (with the Java plugin), `<idea>` | Use an external formatter |

### Imports

```xml
<importOrder>
  <order>java|javax,org,com,,\#</order>   <!-- groups; '' = everything else, '\#' = static imports -->
  <!-- or <file>eclipse.importorder</file> -->
  <wildcardsLast>false</wildcardsLast>
  <semanticSort>false</semanticSort>       <!-- sorts by package/class/member instead of by plain text -->
  <treatAsPackage>…</treatAsPackage>       <!-- tune semanticSort -->
  <treatAsClass>…</treatAsClass>
</importOrder>
<removeUnusedImports><engine>google-java-format</engine></removeUnusedImports>  <!-- or cleanthat-javaparser-unnecessaryimport -->
<forbidWildcardImports/>        <!-- fails the check on `import x.*` -->
<expandWildcardImports/>        <!-- rewrites `x.*` into explicit imports -->
<forbidModuleImports/>          <!-- Java 25 `import module …` -->
<shortenFullyQualifiedTypes/>   <!-- replaces fully qualified names with imports; put it before importOrder -->
```

This project uses `<importOrder/>` with no `<order>`. Judging by the existing code (e.g. `ArchUnitTests.java`), that puts static imports first, then all other imports in one alphabetical group.

### Code clean-up and other steps

| Step | Purpose |
| --- | --- |
| `<cleanthat>` | Rewrites code to modern idioms (`mutators`, `excludedMutators`, `sourceJdk`, `includeDraft`). Put it before the formatter. |
| `<formatAnnotations/>` | Puts type annotations on the same line as the type. Takes `addTypeAnnotation` and `removeTypeAnnotation` for custom annotations †. |
| `<licenseHeader>` | Adds a license header to every file, from `content` (supports `$YEAR`) or `file`. |
| `<toggleOffOn/>` † | Skips any code between `// spotless:off` and `// spotless:on`. |
| `<trimTrailingWhitespace/>`, `<endWithNewline/>`, `<indent>` | Basic whitespace fixes, also usable on non-Java files. |
| `<replace>`, `<replaceRegex>` † | Custom find and replace. |

### Plugin-level settings

- `<ratchetFrom>origin/main</ratchetFrom>`: only checks and formats files changed since that git ref. Useful for bringing Spotless into a codebase gradually.
- `<lineEndings>` †: defaults to `GIT_ATTRIBUTES`. It matters on Windows, where git warns about LF/CRLF conversion in this repo.
- `<formats>`, `<markdown>`, `<pom>`, `<json>`, `<yaml>`, `<sql>`: format files other than Java.

### Worth considering here

1. **`<forbidWildcardImports/>`:** one line that keeps `import x.*` out of the code.
2. **`<pom><sortPom/></pom>`:** keeps `pom.xml` in a consistent, sorted order.
3. **`<toggleOffOn/>`:** lets you keep hand-aligned code where formatting hurts readability, such as the long Taikai builder chain.
4. **`<formatJavadoc>true</formatJavadoc>`** under `palantirJavaFormat`: also formats Javadoc comments.

## How does it fit with the other code-quality tools?

| Tool | What it covers |
| --- | --- |
| Spotless | How code is formatted |
| Taikai / ArchUnit | Coding and Spring conventions (see [taikai-usage.md](taikai-usage.md)) |
| Spring Modulith (`ModularityTests`) | Which modules may depend on which |
| JaCoCo / SonarQube | Test coverage and static analysis |
