#!/usr/bin/env bash
# Builds the project and scans it with a local SonarQube server (see docs/sonar-usage.md).
#
# Usage: scripts/sonar-local.sh
#
# Reads LOCAL_SONAR_ACCESS_TOKEN from .env. Override defaults with environment variables:
#   SONAR_LOCAL_URL          server URL            (default http://localhost:9000)
#   SONAR_LOCAL_PROJECT_KEY  project key           (default java-project-template)
#
# Exits non-zero if the server is down, the build fails, or the quality gate fails.

set -euo pipefail

cd "$(dirname "$0")/.."

url="${SONAR_LOCAL_URL:-http://localhost:9000}"
project="${SONAR_LOCAL_PROJECT_KEY:-java-project-template}"

die() {
  echo "error: $*" >&2
  exit 1
}

# Token from .env, without echoing it
[[ -f .env ]] || die ".env not found; run: cp .env.example .env and set LOCAL_SONAR_ACCESS_TOKEN"
token="$(grep -E '^LOCAL_SONAR_ACCESS_TOKEN=' .env | tail -n 1 | cut -d= -f2- | tr -d '\r' || true)"
[[ -n "$token" ]] || die "LOCAL_SONAR_ACCESS_TOKEN is empty in .env"

api() {
  curl -sf -H "Authorization: Bearer $token" "$url/api/$1"
}

# Server must be up
status="$(curl -sf "$url/api/system/status" || true)"
[[ "$status" == *'"status":"UP"'* ]] \
  || die "SonarQube at $url is not up (start it with: docker start sonarqube)"
api authentication/validate | grep -q '"valid":true' \
  || die "the token in .env is not valid for $url"

echo "Scanning $project on $url"

# pom.xml points at SonarQube Cloud: override the server and project key, and clear the organization.
# qualitygate.wait makes the scan wait for processing and fail if the quality gate fails.
gate=0
./mvnw -B -ntp verify sonar:sonar \
  -Dsonar.host.url="$url" \
  -Dsonar.token="$token" \
  -Dsonar.projectKey="$project" \
  -Dsonar.organization= \
  -Dsonar.qualitygate.wait=true \
  || gate=$?

# Summary (pretty-printed when jq is installed)
metrics="alert_status,coverage,bugs,vulnerabilities,code_smells,security_hotspots,duplicated_lines_density,ncloc"
if summary="$(api "measures/component?component=$project&metricKeys=$metrics")"; then
  echo
  echo "Results: $url/dashboard?id=$project"
  if command -v jq > /dev/null; then
    jq -r '.component.measures | sort_by(.metric)[] | "  \(.metric): \(.value)"' <<< "$summary"
  else
    echo "$summary"
  fi
fi

exit "$gate"
