#!/usr/bin/env bash
# Zips the project: every file git tracks, plus new files that aren't ignored, with
# uncommitted changes included. Ignored files (target/, .env, IDE files, ...) are left out.
#
# Usage: scripts/zip-project.sh [output.zip]
#
# Default output: ../<repo>-<branch>-<commit>[-dirty].zip, next to the project folder.
# Inside the zip, files sit under a top-level <repo>/ folder. Executable bits (mvnw, scripts)
# are taken from git, so they survive on Windows too.
#
# Needs git and Python 3.8+ (for its zipfile module; Git Bash has no zip command).

set -euo pipefail

cd "$(git rev-parse --show-toplevel)"

repo="$(basename "$PWD")"
branch="$(git rev-parse --abbrev-ref HEAD | tr '/' '-')"
commit="$(git rev-parse --short HEAD)"
dirty=""
[[ -n "$(git status --porcelain)" ]] && dirty="-dirty"
out="${1:-../${repo}-${branch}-${commit}${dirty}.zip}"

python=""
for candidate in python3 python; do
  if command -v "$candidate" > /dev/null \
    && "$candidate" -c 'import sys; sys.exit(sys.version_info < (3, 8))' 2> /dev/null; then
    python="$candidate"
    break
  fi
done
[[ -n "$python" ]] || {
  echo "error: Python 3.8+ is required" >&2
  exit 1
}

"$python" - "$out" "$repo" << 'PYTHON'
import os, stat, subprocess, sys, time, zipfile

out, prefix = sys.argv[1], sys.argv[2]

def git_z(*args):
    data = subprocess.run(["git", *args, "-z"], check=True, capture_output=True).stdout
    return [p.decode("utf-8") for p in data.split(b"\0") if p]

# Tracked files with their mode from the index ("<mode> <sha> <stage>\t<path>")
files = {}
for line in git_z("ls-files", "--stage"):
    meta, path = line.split("\t", 1)
    files[path] = meta.split(" ")[0]
# New files that aren't ignored
for path in git_z("ls-files", "--others", "--exclude-standard"):
    files.setdefault(path, "100644")

out_abs = os.path.abspath(out)
count = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for path in sorted(files):
        mode = files[path]
        # Skip submodules, files deleted in the working tree, and the zip itself
        if mode == "160000" or not os.path.isfile(path) or os.path.abspath(path) == out_abs:
            continue
        info = zipfile.ZipInfo(f"{prefix}/{path}", time.localtime(os.path.getmtime(path))[:6])
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = (stat.S_IFREG | (0o755 if mode == "100755" else 0o644)) << 16
        with open(path, "rb") as f:
            zf.writestr(info, f.read())
        count += 1
print(f"{count} files")
PYTHON

echo "Created $out ($(du -h "$out" | cut -f1))"
