package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class BeanC {
    public BeanC() {
        System.out.println("###### run BeanC constructor " + this.hashCode());
    }
}
