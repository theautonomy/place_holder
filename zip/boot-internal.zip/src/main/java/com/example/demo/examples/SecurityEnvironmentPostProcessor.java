package com.example.demo.examples;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

/**
 * Real-world example: Security Environment Post Processor
 *
 * <p>USE CASE: Configure security settings based on deployment environment and load encryption keys
 * from secure sources before application starts.
 *
 * <p>SCENARIO: - Set CORS origins based on environment - Configure JWT settings dynamically - Load
 * encryption keys from environment variables or key management systems - Set security headers based
 * on environment
 */
public class SecurityEnvironmentPostProcessor implements EnvironmentPostProcessor {

    @Override
    public void postProcessEnvironment(
            ConfigurableEnvironment environment, SpringApplication application) {
        System.out.println(
                "=== SecurityEnvironmentPostProcessor: Configuring security settings ===");

        Map<String, Object> securityConfig = new HashMap<>();

        // Determine deployment environment
        boolean isProduction = isProductionEnvironment(environment);
        boolean isDevelopment = isDevelopmentEnvironment(environment);

        // Configure CORS based on environment
        configureCORS(securityConfig, environment, isProduction);

        // Configure JWT settings
        configureJWT(securityConfig, environment, isProduction);

        // Configure security headers
        configureSecurityHeaders(securityConfig, isProduction);

        // Configure SSL/TLS settings
        configureSSL(securityConfig, isProduction);

        // Load encryption keys
        loadEncryptionKeys(securityConfig, environment);

        // Add security property source
        environment
                .getPropertySources()
                .addFirst(new MapPropertySource("security-config", securityConfig));

        System.out.println("###Security configuration applied: " + securityConfig.keySet());
        System.out.println("###=== SecurityEnvironmentPostProcessor completed ===");
    }

    private boolean isProductionEnvironment(ConfigurableEnvironment environment) {
        String[] profiles = environment.getActiveProfiles();
        for (String profile : profiles) {
            if (profile.contains("prod")) {
                return true;
            }
        }
        return "production".equals(environment.getProperty("app.environment"));
    }

    private boolean isDevelopmentEnvironment(ConfigurableEnvironment environment) {
        String[] profiles = environment.getActiveProfiles();
        for (String profile : profiles) {
            if (profile.contains("dev") || profile.contains("local")) {
                return true;
            }
        }
        return profiles.length == 0; // Default to dev if no profiles
    }

    private void configureCORS(
            Map<String, Object> config, ConfigurableEnvironment environment, boolean isProduction) {
        if (isProduction) {
            // Strict CORS in production
            String allowedOrigins =
                    environment.getProperty(
                            "ALLOWED_ORIGINS", "https://app.company.com,https://admin.company.com");
            config.put("spring.web.cors.allowed-origins", allowedOrigins);
            config.put("spring.web.cors.allowed-methods", "GET,POST,PUT,DELETE");
            config.put("spring.web.cors.allowed-headers", "Content-Type,Authorization");
            config.put("spring.web.cors.allow-credentials", "true");
            config.put("spring.web.cors.max-age", "3600");
        } else {
            // Relaxed CORS for development
            config.put("spring.web.cors.allowed-origins", "*");
            config.put("spring.web.cors.allowed-methods", "*");
            config.put("spring.web.cors.allowed-headers", "*");
            config.put("spring.web.cors.allow-credentials", "false");
        }
    }

    private void configureJWT(
            Map<String, Object> config, ConfigurableEnvironment environment, boolean isProduction) {
        if (isProduction) {
            // Production JWT settings
            config.put("app.jwt.expiration", "900"); // 15 minutes
            config.put("app.jwt.refresh-expiration", "604800"); // 7 days
            config.put("app.jwt.issuer", "company-prod-api");
            config.put("app.jwt.algorithm", "RS256"); // Use RSA for production
        } else {
            // Development JWT settings
            config.put("app.jwt.expiration", "86400"); // 24 hours
            config.put("app.jwt.refresh-expiration", "604800"); // 7 days
            config.put("app.jwt.issuer", "company-dev-api");
            config.put("app.jwt.algorithm", "HS256"); // Use HMAC for simplicity in dev
        }

        // Load JWT secret from environment or generate
        String jwtSecret = environment.getProperty("JWT_SECRET");
        if (jwtSecret == null) {
            if (isProduction) {
                throw new IllegalStateException(
                        "JWT_SECRET environment variable must be set in production!");
            }
            jwtSecret = "dev-jwt-secret-key-not-for-production-use";
        }
        config.put("app.jwt.secret", jwtSecret);
    }

    private void configureSecurityHeaders(Map<String, Object> config, boolean isProduction) {
        if (isProduction) {
            // Strict security headers for production
            config.put("spring.security.headers.frame-options", "DENY");
            config.put("spring.security.headers.content-type-options", "nosniff");
            config.put("spring.security.headers.xss-protection", "1; mode=block");
            config.put("spring.security.headers.hsts.enabled", "true");
            config.put("spring.security.headers.hsts.max-age", "31536000");
            config.put("spring.security.headers.hsts.include-subdomains", "true");
            config.put("app.security.csp", "default-src 'self'; script-src 'self' 'unsafe-inline'");
        } else {
            // Relaxed headers for development
            config.put("spring.security.headers.frame-options", "SAMEORIGIN");
            config.put("spring.security.headers.content-type-options", "nosniff");
            config.put("spring.security.headers.hsts.enabled", "false");
        }
    }

    private void configureSSL(Map<String, Object> config, boolean isProduction) {
        if (isProduction) {
            // Force SSL in production
            config.put("server.ssl.enabled", "true");
            config.put("security.require-ssl", "true");
            config.put("server.forward-headers-strategy", "native");
        } else {
            // Allow HTTP in development
            config.put("server.ssl.enabled", "false");
            config.put("security.require-ssl", "false");
        }
    }

    private void loadEncryptionKeys(
            Map<String, Object> config, ConfigurableEnvironment environment) {
        // Load encryption keys for data encryption at rest
        String encryptionKey = environment.getProperty("ENCRYPTION_KEY");
        String signingKey = environment.getProperty("SIGNING_KEY");

        if (encryptionKey == null) {
            System.out.println(
                    "WARNING: ENCRYPTION_KEY not found, using default (NOT FOR PRODUCTION!)");
            encryptionKey = "default-encryption-key-change-in-production";
        }

        if (signingKey == null) {
            System.out.println(
                    "WARNING: SIGNING_KEY not found, using default (NOT FOR PRODUCTION!)");
            signingKey = "default-signing-key-change-in-production";
        }

        config.put("app.encryption.key", encryptionKey);
        config.put("app.signing.key", signingKey);

        // Additional keys for different purposes
        loadOAuth2Keys(config, environment);
        loadAPIKeys(config, environment);
    }

    private void loadOAuth2Keys(Map<String, Object> config, ConfigurableEnvironment environment) {
        // OAuth2 client credentials
        config.put(
                "spring.security.oauth2.client.registration.google.client-id",
                environment.getProperty("OAUTH2_GOOGLE_CLIENT_ID", "default-google-client-id"));
        config.put(
                "spring.security.oauth2.client.registration.google.client-secret",
                environment.getProperty("OAUTH2_GOOGLE_CLIENT_SECRET", "default-google-secret"));

        config.put(
                "spring.security.oauth2.client.registration.github.client-id",
                environment.getProperty("OAUTH2_GITHUB_CLIENT_ID", "default-github-client-id"));
        config.put(
                "spring.security.oauth2.client.registration.github.client-secret",
                environment.getProperty("OAUTH2_GITHUB_CLIENT_SECRET", "default-github-secret"));
    }

    private void loadAPIKeys(Map<String, Object> config, ConfigurableEnvironment environment) {
        // Third-party API keys
        config.put(
                "app.api.payment.stripe.key",
                environment.getProperty("STRIPE_API_KEY", "sk_test_default"));
        config.put(
                "app.api.email.sendgrid.key",
                environment.getProperty("SENDGRID_API_KEY", "SG.default"));
        config.put(
                "app.api.storage.s3.access-key",
                environment.getProperty("AWS_ACCESS_KEY_ID", "default-access-key"));
        config.put(
                "app.api.storage.s3.secret-key",
                environment.getProperty("AWS_SECRET_ACCESS_KEY", "default-secret-key"));
    }
}
