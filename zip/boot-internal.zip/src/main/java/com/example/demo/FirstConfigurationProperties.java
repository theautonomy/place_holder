package com.example.demo;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "demo.first")
public class FirstConfigurationProperties {

    private String message = "Default message from @ConfigurationProperties";
    private boolean enabled = true;
    private int timeout = 5000;

    public FirstConfigurationProperties() {
        System.out.println("###### FirstConfigurationProperties created");
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    @Override
    public String toString() {
        return "FirstConfigurationProperties{"
                + "message='"
                + message
                + '\''
                + ", enabled="
                + enabled
                + ", timeout="
                + timeout
                + '}';
    }
}
