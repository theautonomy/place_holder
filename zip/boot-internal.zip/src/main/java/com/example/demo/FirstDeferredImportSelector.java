package com.example.demo;

import org.springframework.context.annotation.DeferredImportSelector;
import org.springframework.core.type.AnnotationMetadata;

// This doesn't work. It needs to be imported - see Config.java
// @Component
public class FirstDeferredImportSelector implements DeferredImportSelector {

    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        System.out.println("###### run FirstDeferredImportSelector");
        return new String[0];
    }
}
