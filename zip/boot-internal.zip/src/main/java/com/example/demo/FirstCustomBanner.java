package com.example.demo;

import java.io.PrintStream;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.ansi.AnsiColor;
import org.springframework.boot.ansi.AnsiOutput;
import org.springframework.core.env.Environment;

public class FirstCustomBanner implements Banner {

    @Override
    public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) {
        String banner =
                "\n"
                        + AnsiOutput.toString(
                                AnsiColor.GREEN,
                                "  ____                             ____              _   \n"
                                        + " / ___| _ __  _ __(_)_ __   __ _   | __ )  ___   ___ | |_ \n"
                                        + " \\___ \\| '_ \\| '__| | '_ \\ / _` |  |  _ \\ / _ \\ / _ \\| __|\n"
                                        + "  ___) | |_) | |  | | | | | (_| |  | |_) | (_) | (_) | |_ \n"
                                        + " |____/| .__/|_|  |_|_| |_|\\__, |  |____/ \\___/ \\___/ \\__|\n"
                                        + "       |_|                 |___/                         \n")
                        + AnsiOutput.toString(AnsiColor.CYAN, " :: Spring Boot Internal Demo :: ")
                        + AnsiOutput.toString(
                                AnsiColor.DEFAULT, " (v" + SpringBootVersion.getVersion() + ")\n");

        out.println(banner);
        out.println(
                AnsiOutput.toString(
                        AnsiColor.BRIGHT_BLUE,
                        " :: Demonstrating Spring Boot Extension Points ::\n"));
    }
}
