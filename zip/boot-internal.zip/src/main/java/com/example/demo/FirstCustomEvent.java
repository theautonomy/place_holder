package com.example.demo;

import org.springframework.context.ApplicationEvent;

public class FirstCustomEvent extends ApplicationEvent {

    private final String message;

    public FirstCustomEvent(Object source, String message) {
        super(source);
        this.message = message;
        System.out.println("###### FirstCustomEvent created with message: " + message);
    }

    public String getMessage() {
        return message;
    }
}
