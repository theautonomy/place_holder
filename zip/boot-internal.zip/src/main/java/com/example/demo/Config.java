package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({
    FirstImportSelector.class,
    FirstDeferredImportSelector.class,
    FirstImportBeanDefinitionRegistrar.class
})
// @Import({FirstImportSelector.class,  FirstImportBeanDefinitionRegistrar.class})
public class Config {

    @Bean
    BeanA beanAFromConfig() {
        BeanA beanA = new BeanA();
        System.out.println("###### run Config for BeanA via @Bean " + beanA.hashCode());
        return beanA;
    }

    @Bean
    BeanB beanBFromConfig() {
        BeanB beanB = new BeanB();
        System.out.println("###### run Config for BeanB via @Bean " + beanB.hashCode());
        return beanB;
    }
}
