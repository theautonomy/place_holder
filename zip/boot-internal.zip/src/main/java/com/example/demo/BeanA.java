package com.example.demo;

import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
public class BeanA {

    public BeanA() {
        System.out.println("###### run BeanA constructor " + this.hashCode());
    }

    @PostConstruct
    void postConstruct() {
        System.out.println("###### run BeanA postConstruct " + this.hashCode());
    }
}
