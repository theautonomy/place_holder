package com.example.demo;

import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.stereotype.Component;

@Component
public class FirstSmartInitializingSingleton implements SmartInitializingSingleton {

    @Override
    public void afterSingletonsInstantiated() {
        System.out.println("### FirstSmartInitializingSingleton - afterSingletonsInstantiated()");
        System.out.println("### All singletons have been instantiated!");
        System.out.println("### This runs after all singleton beans are fully initialized");
    }
}
