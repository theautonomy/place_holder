package com.example.demo.examples;

import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.type.AnnotationMetadata;

/**
 * Real-world example: Cloud Provider Import Selector
 *
 * <p>USE CASE: Dynamically import different configuration classes based on the cloud provider where
 * the application is deployed (AWS, Azure, GCP, etc.)
 *
 * <p>SCENARIO: - Detect cloud provider from environment or system properties - Import
 * provider-specific configurations for: - Storage services (S3, Azure Blob, Google Cloud Storage) -
 * Message queues (SQS, Service Bus, Pub/Sub) - Secret management (AWS Secrets Manager, Azure Key
 * Vault, Google Secret Manager) - Monitoring and logging integrations
 */
public class CloudProviderImportSelector implements ImportSelector {

    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        System.out.println("###=== CloudProviderImportSelector: Detecting cloud provider ===");

        CloudProvider provider = detectCloudProvider();
        System.out.println("###### Detected cloud provider: " + provider);

        String[] configurations = getConfigurationsForProvider(provider);

        System.out.println("###### configurations: " + String.join(", ", configurations));
        System.out.println("###### CloudProviderImportSelector completed ===");

        return configurations;
    }

    private CloudProvider detectCloudProvider() {
        // Method 1: Check environment variables
        if (System.getenv("AWS_REGION") != null || System.getenv("AWS_DEFAULT_REGION") != null) {
            return CloudProvider.AWS;
        }

        if (System.getenv("AZURE_SUBSCRIPTION_ID") != null
                || System.getenv("AZURE_TENANT_ID") != null) {
            return CloudProvider.AZURE;
        }

        if (System.getenv("GOOGLE_CLOUD_PROJECT") != null || System.getenv("GCP_PROJECT") != null) {
            return CloudProvider.GCP;
        }

        // Method 2: Check system properties
        String cloudProvider = System.getProperty("cloud.provider");
        if (cloudProvider != null) {
            try {
                return CloudProvider.valueOf(cloudProvider.toUpperCase());
            } catch (IllegalArgumentException e) {
                System.out.println("###Unknown cloud provider in system property: " + cloudProvider);
            }
        }

        // Method 3: Check for cloud-specific metadata endpoints (simplified)
        if (isRunningOnAWS()) {
            return CloudProvider.AWS;
        }

        if (isRunningOnAzure()) {
            return CloudProvider.AZURE;
        }

        if (isRunningOnGCP()) {
            return CloudProvider.GCP;
        }

        // Method 4: Check Kubernetes environment
        if (isRunningOnKubernetes()) {
            return detectKubernetesCloudProvider();
        }

        // Default to local/on-premise
        return CloudProvider.LOCAL;
    }

    private String[] getConfigurationsForProvider(CloudProvider provider) {
        // In a real implementation, these would be actual configuration classes
        // For this demo, we'll return empty array to prevent ClassNotFoundException
        System.out.println("###### Would import " + provider + " specific configurations:");

        switch (provider) {
            case AWS:
                System.out.println(
                        "### - AWS Storage, Message Queue, Secrets, and Monitoring configurations");
                break;
            case AZURE:
                System.out.println(
                        "### - Azure Storage, Service Bus, Key Vault, and Monitoring configurations");
                break;
            case GCP:
                System.out.println(
                        "### - GCP Storage, Pub/Sub, Secret Manager, and Monitoring configurations");
                break;
            case LOCAL:
                System.out.println(
                        "### - Local Storage, Message Queue, Secrets, and Monitoring configurations");
                break;
        }

        // Return empty array for demo to prevent missing class errors
        return new String[0];
    }

    private boolean isRunningOnAWS() {
        // In real implementation, you would check AWS metadata endpoint
        // http://169.254.169.254/latest/meta-data/
        // For demo, we'll check for common AWS indicators
        return System.getenv("AWS_EXECUTION_ENV") != null
                || System.getenv("AWS_LAMBDA_FUNCTION_NAME") != null
                || System.getenv("ECS_CONTAINER_METADATA_URI") != null;
    }

    private boolean isRunningOnAzure() {
        // In real implementation, check Azure metadata endpoint
        // http://169.254.169.254/metadata/instance?api-version=2021-02-01
        return System.getenv("WEBSITE_SITE_NAME") != null
                || // Azure App Service
                System.getenv("AZURE_FUNCTIONS_ENVIRONMENT") != null; // Azure Functions
    }

    private boolean isRunningOnGCP() {
        // In real implementation, check GCP metadata endpoint
        // http://metadata.google.internal/computeMetadata/v1/
        return System.getenv("GOOGLE_CLOUD_PROJECT") != null
                || System.getenv("GAE_APPLICATION") != null
                || // App Engine
                System.getenv("K_SERVICE") != null; // Cloud Run
    }

    private boolean isRunningOnKubernetes() {
        return System.getenv("KUBERNETES_SERVICE_HOST") != null;
    }

    private CloudProvider detectKubernetesCloudProvider() {
        // Check for cloud-specific Kubernetes annotations or node labels
        String nodeProvider = System.getenv("KUBERNETES_NODE_PROVIDER");
        if (nodeProvider != null) {
            if (nodeProvider.contains("aws") || nodeProvider.contains("eks")) {
                return CloudProvider.AWS;
            }
            if (nodeProvider.contains("azure") || nodeProvider.contains("aks")) {
                return CloudProvider.AZURE;
            }
            if (nodeProvider.contains("gcp") || nodeProvider.contains("gke")) {
                return CloudProvider.GCP;
            }
        }

        // Check for cloud-specific storage classes or ingress controllers
        // This would typically involve K8s API calls in real implementation
        return CloudProvider.LOCAL; // Default for unknown K8s
    }

    private enum CloudProvider {
        AWS,
        AZURE,
        GCP,
        LOCAL
    }
}
