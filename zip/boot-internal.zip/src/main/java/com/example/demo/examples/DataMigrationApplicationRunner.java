package com.example.demo.examples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Real-world example: Data Migration Application Runner
 *
 * <p>USE CASE: Perform database migrations, data transformations, and system validations after the
 * application has fully started and all beans are initialized.
 *
 * <p>SCENARIO: - Check database schema version - Run pending migrations - Validate data integrity -
 * Update configuration caches - Send startup notifications - Perform health checks on external
 * dependencies - Initialize background data processing jobs
 */
@Component
@Order(1) // Run first among ApplicationRunners
public class DataMigrationApplicationRunner implements ApplicationRunner {

    private final DatabaseMigrationService migrationService;
    private final ExternalSystemValidator externalValidator;
    private final CacheWarmupService cacheService;
    private final NotificationService notificationService;

    public DataMigrationApplicationRunner() {
        this.migrationService = new DatabaseMigrationService();
        this.externalValidator = new ExternalSystemValidator();
        this.cacheService = new CacheWarmupService();
        this.notificationService = new NotificationService();
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        System.out.println(
                "=== DataMigrationApplicationRunner: Starting post-deployment tasks ===");
        long startTime = System.currentTimeMillis();

        try {
            // Step 1: Check if this is a fresh deployment or upgrade
            DeploymentType deploymentType = determineDeploymentType(args);
            System.out.println("###Deployment type detected: " + deploymentType);

            // Step 2: Run database migrations
            runDatabaseMigrations(deploymentType);

            // Step 3: Validate data integrity
            validateDataIntegrity();

            // Step 4: Update application caches
            warmupCaches();

            // Step 5: Validate external system connectivity
            validateExternalSystems();

            // Step 6: Initialize background jobs
            initializeBackgroundJobs(deploymentType);

            // Step 7: Send deployment notifications
            sendDeploymentNotifications(deploymentType, true);

            long executionTime = System.currentTimeMillis() - startTime;
            System.out.println(
                    "=== DataMigrationApplicationRunner completed successfully in "
                            + executionTime
                            + "ms ===");

        } catch (Exception e) {
            System.err.println("###DataMigrationApplicationRunner failed: " + e.getMessage());
            e.printStackTrace();

            // Send failure notification
            sendDeploymentNotifications(DeploymentType.UNKNOWN, false);

            // Depending on criticality, you might want to stop the application
            // System.exit(1);
            throw e;
        }
    }

    private DeploymentType determineDeploymentType(ApplicationArguments args) {
        // Check command line arguments
        if (args.containsOption("migration.mode")) {
            String mode = args.getOptionValues("migration.mode").get(0);
            if ("fresh".equals(mode)) return DeploymentType.FRESH_INSTALL;
            if ("upgrade".equals(mode)) return DeploymentType.UPGRADE;
        }

        // Check environment variable
        String deploymentMode = System.getenv("DEPLOYMENT_MODE");
        if ("fresh".equals(deploymentMode)) return DeploymentType.FRESH_INSTALL;
        if ("upgrade".equals(deploymentMode)) return DeploymentType.UPGRADE;

        // Check if database exists and has data
        try {
            if (migrationService.isDatabaseEmpty()) {
                return DeploymentType.FRESH_INSTALL;
            } else {
                return DeploymentType.UPGRADE;
            }
        } catch (Exception e) {
            System.out.println(
                    "Could not determine deployment type from database: " + e.getMessage());
            return DeploymentType.UNKNOWN;
        }
    }

    private void runDatabaseMigrations(DeploymentType deploymentType) throws Exception {
        System.out.println("###Running database migrations for deployment type: " + deploymentType);

        switch (deploymentType) {
            case FRESH_INSTALL:
                migrationService.runFreshInstallMigrations();
                break;
            case UPGRADE:
                migrationService.runUpgradeMigrations();
                break;
            case UNKNOWN:
                System.out.println("###WARNING: Unknown deployment type, skipping migrations");
                break;
        }
    }

    private void validateDataIntegrity() throws Exception {
        System.out.println("###Validating data integrity...");

        List<String> validationErrors = migrationService.validateDataIntegrity();

        if (!validationErrors.isEmpty()) {
            System.err.println("###Data integrity validation failed:");
            validationErrors.forEach(error -> System.err.println("###  - " + error));
            throw new RuntimeException("Data integrity validation failed");
        }

        System.out.println("###Data integrity validation passed");
    }

    private void warmupCaches() {
        System.out.println("###Warming up application caches...");

        try {
            // Warm up configuration cache
            cacheService.warmupConfigurationCache();

            // Warm up user permissions cache
            cacheService.warmupUserPermissionsCache();

            // Warm up reference data cache
            cacheService.warmupReferenceDataCache();

            System.out.println("###Cache warmup completed successfully");
        } catch (Exception e) {
            System.err.println("###Cache warmup failed (non-critical): " + e.getMessage());
            // Don't fail the startup for cache issues
        }
    }

    private void validateExternalSystems() {
        System.out.println("###Validating external system connectivity...");

        List<ExternalSystemStatus> statusList = new ArrayList<>();

        // Validate payment gateway
        statusList.add(externalValidator.validatePaymentGateway());

        // Validate email service
        statusList.add(externalValidator.validateEmailService());

        // Validate file storage service
        statusList.add(externalValidator.validateFileStorageService());

        // Validate third-party APIs
        statusList.add(externalValidator.validateThirdPartyAPIs());

        // Report results
        long healthyCount =
                statusList.stream().mapToLong(status -> status.isHealthy() ? 1 : 0).sum();
        System.out.println(
                "External system validation: "
                        + healthyCount
                        + "/"
                        + statusList.size()
                        + " systems healthy");

        // Log unhealthy systems
        statusList.stream()
                .filter(status -> !status.isHealthy())
                .forEach(
                        status ->
                                System.err.println(
                                        "UNHEALTHY: "
                                                + status.getSystemName()
                                                + " - "
                                                + status.getErrorMessage()));
    }

    private void initializeBackgroundJobs(DeploymentType deploymentType) {
        System.out.println("###Initializing background jobs...");

        try {
            // Start data synchronization job
            startDataSyncJob();

            // Start cleanup job
            startCleanupJob();

            // Start monitoring job
            startMonitoringJob();

            // For upgrades, start data migration background job
            if (deploymentType == DeploymentType.UPGRADE) {
                startLargeDataMigrationJob();
            }

            System.out.println("###Background jobs initialized successfully");
        } catch (Exception e) {
            System.err.println("###Failed to initialize some background jobs: " + e.getMessage());
            // Don't fail startup for background job issues
        }
    }

    private void sendDeploymentNotifications(DeploymentType deploymentType, boolean success) {
        try {
            String status = success ? "SUCCESS" : "FAILED";
            String message =
                    String.format(
                            "Application deployment %s. Type: %s, Time: %s",
                            status, deploymentType, LocalDateTime.now());

            notificationService.sendSlackNotification(message);
            notificationService.sendEmailNotification(message);
            notificationService.updateStatusDashboard(status);

            System.out.println("###Deployment notifications sent: " + status);
        } catch (Exception e) {
            System.err.println("###Failed to send deployment notifications: " + e.getMessage());
            // Don't fail for notification issues
        }
    }

    // Job initialization methods
    private void startDataSyncJob() {
        System.out.println("###Starting data synchronization background job");
        // Schedule job to run every hour
    }

    private void startCleanupJob() {
        System.out.println("###Starting cleanup background job");
        // Schedule job to run daily at 2 AM
    }

    private void startMonitoringJob() {
        System.out.println("###Starting system monitoring background job");
        // Schedule job to run every 5 minutes
    }

    private void startLargeDataMigrationJob() {
        System.out.println("###Starting large data migration background job");
        // Schedule one-time job for large data migration
    }

    // Supporting classes

    private enum DeploymentType {
        FRESH_INSTALL,
        UPGRADE,
        UNKNOWN
    }

    private static class DatabaseMigrationService {
        public boolean isDatabaseEmpty() throws Exception {
            // Simplified database check
            Connection conn = DriverManager.getConnection("jdbc:h2:mem:testdb", "sa", "");
            Statement stmt = conn.createStatement();
            ResultSet rs =
                    stmt.executeQuery(
                            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'TABLE'");
            rs.next();
            boolean isEmpty = rs.getInt(1) == 0;
            conn.close();
            return isEmpty;
        }

        public void runFreshInstallMigrations() throws Exception {
            System.out.println("###Running fresh install database migrations");
            // Create initial schema, insert reference data, create admin user, etc.

            Connection conn = DriverManager.getConnection("jdbc:h2:mem:testdb", "sa", "");
            Statement stmt = conn.createStatement();

            // Create core tables
            stmt.execute("CREATE TABLE users (id BIGINT PRIMARY KEY, username VARCHAR(255))");
            stmt.execute("CREATE TABLE roles (id BIGINT PRIMARY KEY, name VARCHAR(255))");
            stmt.execute(
                    "CREATE TABLE migration_history (version VARCHAR(50) PRIMARY KEY, applied_at TIMESTAMP)");

            // Insert initial data
            stmt.execute("INSERT INTO roles (id, name) VALUES (1, 'ADMIN'), (2, 'USER')");
            stmt.execute("INSERT INTO users (id, username) VALUES (1, 'admin')");
            stmt.execute(
                    "INSERT INTO migration_history (version, applied_at) VALUES ('1.0.0', CURRENT_TIMESTAMP)");

            conn.close();
            System.out.println("###Fresh install migrations completed");
        }

        public void runUpgradeMigrations() throws Exception {
            System.out.println("###Running upgrade database migrations");

            // Check current version and apply necessary migrations
            String currentVersion = getCurrentDatabaseVersion();
            System.out.println("###Current database version: " + currentVersion);

            List<String> pendingMigrations = getPendingMigrations(currentVersion);
            System.out.println("###Pending migrations: " + pendingMigrations);

            // Apply each pending migration
            for (String migration : pendingMigrations) {
                applyMigration(migration);
            }

            System.out.println("###Upgrade migrations completed");
        }

        public List<String> validateDataIntegrity() throws Exception {
            List<String> errors = new ArrayList<>();

            Connection conn = DriverManager.getConnection("jdbc:h2:mem:testdb", "sa", "");
            Statement stmt = conn.createStatement();

            // Check for orphaned records
            try {
                ResultSet rs =
                        stmt.executeQuery(
                                "SELECT COUNT(*) FROM users WHERE id NOT IN (SELECT DISTINCT user_id FROM user_roles WHERE user_id IS NOT NULL)");
                // This would fail if tables don't exist, but that's OK for this demo
            } catch (Exception e) {
                // Expected in demo environment
            }

            // Check for duplicate data
            // Check for invalid foreign keys
            // Check for data consistency rules

            conn.close();
            return errors;
        }

        private String getCurrentDatabaseVersion() throws Exception {
            // Query migration_history table for latest version
            return "1.0.0"; // Simplified
        }

        private List<String> getPendingMigrations(String currentVersion) {
            List<String> pending = new ArrayList<>();
            // Compare current version with available migrations
            pending.add("1.1.0_add_audit_columns");
            pending.add("1.2.0_add_user_preferences");
            return pending;
        }

        private void applyMigration(String migration) throws Exception {
            System.out.println("###Applying migration: " + migration);
            // Execute migration SQL scripts
            // Update migration_history table
        }
    }

    private static class CacheWarmupService {
        public void warmupConfigurationCache() {
            System.out.println("###Warming up configuration cache");
            // Load frequently used configuration into cache
        }

        public void warmupUserPermissionsCache() {
            System.out.println("###Warming up user permissions cache");
            // Pre-load user permissions for faster authorization
        }

        public void warmupReferenceDataCache() {
            System.out.println("###Warming up reference data cache");
            // Load reference data like countries, currencies, etc.
        }
    }

    private static class ExternalSystemValidator {
        public ExternalSystemStatus validatePaymentGateway() {
            try {
                // Make test API call to payment gateway
                System.out.println("###Validating payment gateway connectivity");
                return new ExternalSystemStatus("Payment Gateway", true, null);
            } catch (Exception e) {
                return new ExternalSystemStatus("Payment Gateway", false, e.getMessage());
            }
        }

        public ExternalSystemStatus validateEmailService() {
            try {
                System.out.println("###Validating email service connectivity");
                return new ExternalSystemStatus("Email Service", true, null);
            } catch (Exception e) {
                return new ExternalSystemStatus("Email Service", false, e.getMessage());
            }
        }

        public ExternalSystemStatus validateFileStorageService() {
            try {
                System.out.println("###Validating file storage service connectivity");
                return new ExternalSystemStatus("File Storage", true, null);
            } catch (Exception e) {
                return new ExternalSystemStatus("File Storage", false, e.getMessage());
            }
        }

        public ExternalSystemStatus validateThirdPartyAPIs() {
            try {
                System.out.println("###Validating third-party APIs");
                return new ExternalSystemStatus("Third-party APIs", true, null);
            } catch (Exception e) {
                return new ExternalSystemStatus("Third-party APIs", false, e.getMessage());
            }
        }
    }

    private static class ExternalSystemStatus {
        private final String systemName;
        private final boolean healthy;
        private final String errorMessage;

        public ExternalSystemStatus(String systemName, boolean healthy, String errorMessage) {
            this.systemName = systemName;
            this.healthy = healthy;
            this.errorMessage = errorMessage;
        }

        public String getSystemName() {
            return systemName;
        }

        public boolean isHealthy() {
            return healthy;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }

    private static class NotificationService {
        public void sendSlackNotification(String message) {
            System.out.println("###Sending Slack notification: " + message);
        }

        public void sendEmailNotification(String message) {
            System.out.println("###Sending email notification: " + message);
        }

        public void updateStatusDashboard(String status) {
            System.out.println("###Updating status dashboard: " + status);
        }
    }
}
