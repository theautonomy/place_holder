package com.example.demo.examples;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;
import org.springframework.util.ClassUtils;

/**
 * Real-world example: Custom Repository Bean Definition Registrar
 *
 * <p>USE CASE: Automatically discover and register custom repository implementations similar to how
 * Spring Data JPA repositories work, but for custom business repositories.
 *
 * <p>SCENARIO: - Scan for interfaces annotated with @CustomRepository - Generate proxy
 * implementations for these repositories - Register them as Spring beans - Handle dependency
 * injection and transaction management - Support for caching and metrics around repository methods
 */
public class RepositoryBeanDefinitionRegistrar implements ImportBeanDefinitionRegistrar {

    private static final String BASE_PACKAGE = "com.example.demo";

    @Override
    public void registerBeanDefinitions(
            AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {
        System.out.println(
                "=== RepositoryBeanDefinitionRegistrar: Scanning for custom repositories ===");

        try {
            // Scan for repository interfaces
            Set<Class<?>> repositoryInterfaces = scanForRepositoryInterfaces();

            // Register each repository
            for (Class<?> repositoryInterface : repositoryInterfaces) {
                registerRepository(registry, repositoryInterface);
            }

            // Register repository support beans
            registerRepositorySupport(registry);

            System.out.println(
                    "Registered " + repositoryInterfaces.size() + " custom repositories");
            System.out.println("###=== RepositoryBeanDefinitionRegistrar completed ===");

        } catch (Exception e) {
            System.err.println("###Error during repository scanning: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private Set<Class<?>> scanForRepositoryInterfaces() throws IOException, ClassNotFoundException {
        Set<Class<?>> repositoryInterfaces = new HashSet<>();

        ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
        MetadataReaderFactory metadataReaderFactory =
                new CachingMetadataReaderFactory(resourcePatternResolver);

        String packageSearchPath =
                "classpath*:"
                        + ClassUtils.convertClassNameToResourcePath(BASE_PACKAGE)
                        + "/**/*.class";
        Resource[] resources = resourcePatternResolver.getResources(packageSearchPath);

        for (Resource resource : resources) {
            if (!resource.isReadable()) {
                continue;
            }

            try {
                MetadataReader metadataReader = metadataReaderFactory.getMetadataReader(resource);
                String className = metadataReader.getClassMetadata().getClassName();

                // Check if it's an interface with @CustomRepository annotation
                if (metadataReader.getClassMetadata().isInterface()
                        && metadataReader
                                .getAnnotationMetadata()
                                .hasAnnotation("com.example.demo.examples.CustomRepository")) {

                    Class<?> repositoryClass = Class.forName(className);
                    repositoryInterfaces.add(repositoryClass);
                    System.out.println("###Found repository interface: " + className);
                }
            } catch (Exception e) {
                System.out.println(
                        "Could not read resource: "
                                + resource.getDescription()
                                + " - "
                                + e.getMessage());
            }
        }

        return repositoryInterfaces;
    }

    private void registerRepository(BeanDefinitionRegistry registry, Class<?> repositoryInterface) {
        System.out.println("###Registering repository: " + repositoryInterface.getSimpleName());

        // Create bean definition for repository proxy factory
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(CustomRepositoryFactoryBean.class);
        builder.addConstructorArgValue(repositoryInterface);
        builder.addPropertyValue("repositoryInterface", repositoryInterface);
        builder.addPropertyReference(
                "entityManager", "entityManager"); // Assume JPA EntityManager is available
        builder.addPropertyReference("transactionManager", "transactionManager");

        // Configure repository-specific settings
        configureRepositoryBeanDefinition(builder, repositoryInterface);

        // Generate bean name
        String beanName = generateRepositoryBeanName(repositoryInterface);

        // Register the bean definition
        registry.registerBeanDefinition(beanName, builder.getBeanDefinition());

        System.out.println("###Registered repository bean: " + beanName);
    }

    private void configureRepositoryBeanDefinition(
            BeanDefinitionBuilder builder, Class<?> repositoryInterface) {
        // Check for repository-specific annotations and configure accordingly

        // Example: Configure caching if @Cacheable is present
        if (repositoryInterface.isAnnotationPresent(
                org.springframework.cache.annotation.Cacheable.class)) {
            builder.addPropertyValue("cachingEnabled", true);
            System.out.println(
                    "Enabled caching for repository: " + repositoryInterface.getSimpleName());
        }

        // Example: Configure metrics collection
        builder.addPropertyValue("metricsEnabled", true);

        // Example: Configure custom query timeout
        CustomRepository annotation = repositoryInterface.getAnnotation(CustomRepository.class);
        if (annotation != null && annotation.queryTimeout() > 0) {
            builder.addPropertyValue("queryTimeout", annotation.queryTimeout());
        }
    }

    private String generateRepositoryBeanName(Class<?> repositoryInterface) {
        String simpleName = repositoryInterface.getSimpleName();
        return Character.toLowerCase(simpleName.charAt(0)) + simpleName.substring(1);
    }

    private void registerRepositorySupport(BeanDefinitionRegistry registry) {
        // Register repository support beans that all repositories might need

        // Repository metrics collector
        if (!registry.containsBeanDefinition("repositoryMetricsCollector")) {
            BeanDefinitionBuilder metricsBuilder =
                    BeanDefinitionBuilder.genericBeanDefinition(RepositoryMetricsCollector.class);
            registry.registerBeanDefinition(
                    "repositoryMetricsCollector", metricsBuilder.getBeanDefinition());
            System.out.println("###Registered repository metrics collector");
        }

        // Repository cache manager
        if (!registry.containsBeanDefinition("repositoryCacheManager")) {
            BeanDefinitionBuilder cacheBuilder =
                    BeanDefinitionBuilder.genericBeanDefinition(RepositoryCacheManager.class);
            registry.registerBeanDefinition(
                    "repositoryCacheManager", cacheBuilder.getBeanDefinition());
            System.out.println("###Registered repository cache manager");
        }

        // Repository audit logger
        if (!registry.containsBeanDefinition("repositoryAuditLogger")) {
            BeanDefinitionBuilder auditBuilder =
                    BeanDefinitionBuilder.genericBeanDefinition(RepositoryAuditLogger.class);
            registry.registerBeanDefinition(
                    "repositoryAuditLogger", auditBuilder.getBeanDefinition());
            System.out.println("###Registered repository audit logger");
        }
    }

    // Supporting classes - in real implementation these would be full implementations

    public static class CustomRepositoryFactoryBean {
        private Class<?> repositoryInterface;
        private Object entityManager;
        private Object transactionManager;
        private boolean cachingEnabled = false;
        private boolean metricsEnabled = false;
        private int queryTimeout = 30;

        public CustomRepositoryFactoryBean(Class<?> repositoryInterface) {
            this.repositoryInterface = repositoryInterface;
            System.out.println(
                    "Created CustomRepositoryFactoryBean for: "
                            + repositoryInterface.getSimpleName());
        }

        // Setters for dependency injection
        public void setRepositoryInterface(Class<?> repositoryInterface) {
            this.repositoryInterface = repositoryInterface;
        }

        public void setEntityManager(Object entityManager) {
            this.entityManager = entityManager;
        }

        public void setTransactionManager(Object transactionManager) {
            this.transactionManager = transactionManager;
        }

        public void setCachingEnabled(boolean cachingEnabled) {
            this.cachingEnabled = cachingEnabled;
        }

        public void setMetricsEnabled(boolean metricsEnabled) {
            this.metricsEnabled = metricsEnabled;
        }

        public void setQueryTimeout(int queryTimeout) {
            this.queryTimeout = queryTimeout;
        }

        // This would create the actual repository proxy
        public Object getRepository() {
            return createRepositoryProxy();
        }

        private Object createRepositoryProxy() {
            System.out.println(
                    "Creating repository proxy for: "
                            + repositoryInterface.getSimpleName()
                            + " (caching="
                            + cachingEnabled
                            + ", metrics="
                            + metricsEnabled
                            + ", timeout="
                            + queryTimeout
                            + ")");
            // In real implementation, this would use JDK Dynamic Proxy or CGLIB
            // to create a proxy that intercepts method calls and implements the repository logic
            return null; // Placeholder
        }
    }

    public static class RepositoryMetricsCollector {
        public RepositoryMetricsCollector() {
            System.out.println(
                    "RepositoryMetricsCollector created - will collect repository performance metrics");
        }
    }

    public static class RepositoryCacheManager {
        public RepositoryCacheManager() {
            System.out.println(
                    "RepositoryCacheManager created - will manage repository-level caching");
        }
    }

    public static class RepositoryAuditLogger {
        public RepositoryAuditLogger() {
            System.out.println("###RepositoryAuditLogger created - will audit repository operations");
        }
    }
}
