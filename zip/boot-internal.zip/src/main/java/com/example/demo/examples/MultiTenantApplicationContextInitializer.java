package com.example.demo.examples;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;

/**
 * Real-world example: Multi-Tenant Application Context Initializer
 *
 * <p>USE CASE: Configure application context for multi-tenant applications where different tenants
 * might have different configurations, database connections, or feature flags.
 *
 * <p>SCENARIO: - Detect tenant from system properties or environment - Configure tenant-specific
 * database schemas - Set tenant-specific feature flags - Configure tenant-specific external service
 * endpoints - Set up tenant-specific caching configurations
 */
public class MultiTenantApplicationContextInitializer
        implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        System.out.println(
                "=== MultiTenantApplicationContextInitializer: Setting up multi-tenant configuration ===");

        ConfigurableEnvironment environment = applicationContext.getEnvironment();

        // Detect tenant (could be from system property, environment variable, or startup parameter)
        String tenantId = detectTenant(environment);
        System.out.println("###Detected tenant: " + tenantId);

        // Configure tenant-specific settings
        Map<String, Object> tenantConfig = new HashMap<>();

        // Configure database settings for tenant
        configureTenantDatabase(tenantConfig, tenantId, environment);

        // Configure tenant-specific features
        configureTenantFeatures(tenantConfig, tenantId);

        // Configure external service endpoints
        configureExternalServices(tenantConfig, tenantId, environment);

        // Configure caching for tenant
        configureTenantCaching(tenantConfig, tenantId);

        // Configure logging for tenant
        configureTenantLogging(tenantConfig, tenantId);

        // Add tenant configuration to environment
        environment
                .getPropertySources()
                .addFirst(new MapPropertySource("tenant-config-" + tenantId, tenantConfig));

        // Set active profiles based on tenant
        setTenantProfiles(environment, tenantId);

        System.out.println("###Tenant configuration applied for: " + tenantId);
        System.out.println("###Tenant config keys: " + tenantConfig.keySet());
        System.out.println("###=== MultiTenantApplicationContextInitializer completed ===");
    }

    private String detectTenant(ConfigurableEnvironment environment) {
        // Priority order: system property > environment variable > default
        String tenant = System.getProperty("tenant.id");
        if (tenant == null) {
            tenant = environment.getProperty("TENANT_ID");
        }
        if (tenant == null) {
            tenant = environment.getProperty("tenant.id", "default");
        }
        return tenant.toLowerCase();
    }

    private void configureTenantDatabase(
            Map<String, Object> config, String tenantId, ConfigurableEnvironment environment) {
        // Base database URL from environment
        String baseDbUrl =
                environment.getProperty("DATABASE_BASE_URL", "jdbc:postgresql://localhost:5432/");

        switch (tenantId) {
            case "acme-corp":
                config.put("spring.datasource.url", baseDbUrl + "acme_corp_db");
                config.put("spring.datasource.username", "acme_user");
                config.put("spring.datasource.schema", "acme_schema");
                config.put("spring.jpa.properties.hibernate.default_schema", "acme_schema");
                config.put("app.tenant.database.pool.max-size", "50");
                break;

            case "beta-company":
                config.put("spring.datasource.url", baseDbUrl + "beta_company_db");
                config.put("spring.datasource.username", "beta_user");
                config.put("spring.datasource.schema", "beta_schema");
                config.put("spring.jpa.properties.hibernate.default_schema", "beta_schema");
                config.put("app.tenant.database.pool.max-size", "30");
                break;

            case "startup-inc":
                config.put("spring.datasource.url", baseDbUrl + "startup_inc_db");
                config.put("spring.datasource.username", "startup_user");
                config.put("spring.datasource.schema", "startup_schema");
                config.put("spring.jpa.properties.hibernate.default_schema", "startup_schema");
                config.put("app.tenant.database.pool.max-size", "10");
                break;

            default:
                config.put("spring.datasource.url", baseDbUrl + "default_tenant_db");
                config.put("spring.datasource.username", "default_user");
                config.put("spring.datasource.schema", "public");
                config.put("app.tenant.database.pool.max-size", "20");
        }

        // Common database settings
        config.put("app.tenant.id", tenantId);
        config.put("spring.jpa.properties.hibernate.multiTenancy", "SCHEMA");
    }

    private void configureTenantFeatures(Map<String, Object> config, String tenantId) {
        switch (tenantId) {
            case "acme-corp":
                // Enterprise features enabled
                config.put("app.features.advanced-analytics", "true");
                config.put("app.features.custom-branding", "true");
                config.put("app.features.api-rate-limit", "10000");
                config.put("app.features.storage-limit-gb", "1000");
                config.put("app.features.user-limit", "unlimited");
                config.put("app.features.sso-enabled", "true");
                config.put("app.features.audit-logging", "true");
                break;

            case "beta-company":
                // Premium features
                config.put("app.features.advanced-analytics", "true");
                config.put("app.features.custom-branding", "false");
                config.put("app.features.api-rate-limit", "5000");
                config.put("app.features.storage-limit-gb", "500");
                config.put("app.features.user-limit", "500");
                config.put("app.features.sso-enabled", "true");
                config.put("app.features.audit-logging", "false");
                break;

            case "startup-inc":
                // Basic features
                config.put("app.features.advanced-analytics", "false");
                config.put("app.features.custom-branding", "false");
                config.put("app.features.api-rate-limit", "1000");
                config.put("app.features.storage-limit-gb", "50");
                config.put("app.features.user-limit", "50");
                config.put("app.features.sso-enabled", "false");
                config.put("app.features.audit-logging", "false");
                break;

            default:
                // Default/trial features
                config.put("app.features.advanced-analytics", "false");
                config.put("app.features.custom-branding", "false");
                config.put("app.features.api-rate-limit", "100");
                config.put("app.features.storage-limit-gb", "1");
                config.put("app.features.user-limit", "5");
                config.put("app.features.sso-enabled", "false");
                config.put("app.features.audit-logging", "false");
        }
    }

    private void configureExternalServices(
            Map<String, Object> config, String tenantId, ConfigurableEnvironment environment) {
        // Configure tenant-specific external service endpoints
        String baseApiUrl = environment.getProperty("BASE_API_URL", "https://api.company.com");

        // Payment service configuration
        config.put("app.services.payment.base-url", baseApiUrl + "/payment");
        config.put("app.services.payment.tenant-key", "payment_" + tenantId + "_key");

        // Email service configuration
        config.put("app.services.email.base-url", baseApiUrl + "/email");
        config.put("app.services.email.tenant-key", "email_" + tenantId + "_key");
        config.put("app.services.email.from-address", "noreply@" + tenantId + ".company.com");

        // Storage service configuration
        config.put("app.services.storage.bucket-name", tenantId + "-storage-bucket");
        config.put("app.services.storage.region", getTenantRegion(tenantId));

        // Analytics service configuration
        if ("true".equals(config.get("app.features.advanced-analytics"))) {
            config.put("app.services.analytics.endpoint", baseApiUrl + "/analytics/premium");
            config.put("app.services.analytics.tenant-key", "analytics_premium_" + tenantId);
        } else {
            config.put("app.services.analytics.endpoint", baseApiUrl + "/analytics/basic");
            config.put("app.services.analytics.tenant-key", "analytics_basic_" + tenantId);
        }
    }

    private void configureTenantCaching(Map<String, Object> config, String tenantId) {
        // Redis cache configuration per tenant
        config.put("spring.cache.redis.key-prefix", tenantId + ":");
        config.put("spring.cache.redis.time-to-live", "3600000"); // 1 hour

        switch (tenantId) {
            case "acme-corp":
                config.put("spring.cache.redis.cache-null-values", "true");
                config.put("app.cache.size.user-sessions", "10000");
                config.put("app.cache.size.api-responses", "50000");
                break;
            case "beta-company":
                config.put("spring.cache.redis.cache-null-values", "true");
                config.put("app.cache.size.user-sessions", "5000");
                config.put("app.cache.size.api-responses", "25000");
                break;
            default:
                config.put("spring.cache.redis.cache-null-values", "false");
                config.put("app.cache.size.user-sessions", "100");
                config.put("app.cache.size.api-responses", "1000");
        }
    }

    private void configureTenantLogging(Map<String, Object> config, String tenantId) {
        // Tenant-specific logging configuration
        config.put(
                "logging.pattern.console",
                "[" + tenantId.toUpperCase() + "] %d{yyyy-MM-dd HH:mm:ss} - %msg%n");
        config.put(
                "logging.pattern.file",
                "["
                        + tenantId.toUpperCase()
                        + "] %d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n");

        // Log file per tenant
        config.put("logging.file.name", "logs/" + tenantId + "/application.log");
        config.put("logging.logback.rollingpolicy.max-file-size", "100MB");
        config.put("logging.logback.rollingpolicy.total-size-cap", "1GB");

        // Tenant-specific log levels
        if ("acme-corp".equals(tenantId)) {
            config.put("logging.level.com.example.demo", "INFO");
            config.put("logging.level.org.springframework.security", "DEBUG");
        } else if ("startup-inc".equals(tenantId)) {
            config.put("logging.level.com.example.demo", "DEBUG");
            config.put("logging.level.org.springframework", "INFO");
        }
    }

    private void setTenantProfiles(ConfigurableEnvironment environment, String tenantId) {
        // Add tenant-specific profile
        String tenantProfile = "tenant-" + tenantId;
        environment.addActiveProfile(tenantProfile);

        // Add tier-specific profiles based on tenant
        if ("acme-corp".equals(tenantId)) {
            environment.addActiveProfile("enterprise");
            environment.addActiveProfile("high-performance");
        } else if ("beta-company".equals(tenantId)) {
            environment.addActiveProfile("premium");
        } else if ("startup-inc".equals(tenantId)) {
            environment.addActiveProfile("basic");
        } else {
            environment.addActiveProfile("trial");
        }

        System.out.println(
                "Active profiles after tenant configuration: "
                        + String.join(", ", environment.getActiveProfiles()));
    }

    private String getTenantRegion(String tenantId) {
        // Determine AWS region based on tenant
        switch (tenantId) {
            case "acme-corp":
                return "us-east-1"; // US East Coast
            case "beta-company":
                return "eu-west-1"; // Europe
            case "startup-inc":
                return "us-west-2"; // US West Coast
            default:
                return "us-east-1";
        }
    }
}
