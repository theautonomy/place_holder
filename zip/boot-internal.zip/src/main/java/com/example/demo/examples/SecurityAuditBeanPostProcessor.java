package com.example.demo.examples;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Real-world example: Security Audit Bean Post Processor
 *
 * <p>USE CASE: Automatically wrap service beans with security and audit functionality to track who
 * accesses what services, log security events, and enforce access control.
 *
 * <p>SCENARIO: - Wrap service beans with security proxy - Log all method invocations on sensitive
 * services - Track user access patterns for security analysis - Enforce role-based access control -
 * Monitor for suspicious activity patterns - Generate security audit reports
 */
@Component
@Order(100) // Process after other BeanPostProcessors
public class SecurityAuditBeanPostProcessor implements BeanPostProcessor {

    private static final Set<String> SENSITIVE_SERVICE_PATTERNS =
            new HashSet<>(
                    Arrays.asList(".*Service$", ".*Manager$", ".*Controller$", ".*Repository$"));

    private static final Set<String> EXCLUDED_BEANS =
            new HashSet<>(
                    Arrays.asList(
                            "securityAuditBeanPostProcessor", "auditLogger", "securityService"));

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName)
            throws BeansException {
        // Nothing to do before initialization
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName)
            throws BeansException {
        if (shouldApplySecurityAudit(bean, beanName)) {
            System.out.println("###=== Applying security audit to bean: " + beanName + " ===");
            return createSecurityAuditProxy(bean, beanName);
        }
        return bean;
    }

    private boolean shouldApplySecurityAudit(Object bean, String beanName) {
        // Skip if bean is excluded
        if (EXCLUDED_BEANS.contains(beanName)) {
            return false;
        }

        // Skip if bean class is from Spring framework
        if (bean.getClass().getName().startsWith("org.springframework")) {
            return false;
        }

        // Apply to beans matching sensitive patterns
        return SENSITIVE_SERVICE_PATTERNS.stream().anyMatch(pattern -> beanName.matches(pattern))
                || hasSecurityAnnotation(bean.getClass());
    }

    private boolean hasSecurityAnnotation(Class<?> beanClass) {
        // Check for security-related annotations (simplified for demo without Spring Security
        // dependency)
        // In a real implementation with Spring Security, you would check for @Secured,
        // @PreAuthorize, etc.
        return beanClass.getName().contains("Secure")
                || beanClass.getName().contains("Admin")
                || Arrays.stream(beanClass.getMethods())
                        .anyMatch(
                                method ->
                                        method.getName().contains("secure")
                                                || method.getName().contains("admin"));
    }

    private Object createSecurityAuditProxy(Object target, String beanName) {
        Class<?> targetClass = target.getClass();

        // Get all interfaces implemented by the target
        Class<?>[] interfaces = targetClass.getInterfaces();

        if (interfaces.length == 0) {
            // If no interfaces, we can't create JDK proxy
            System.out.println(
                    "Cannot create proxy for " + beanName + " - no interfaces implemented");
            return target;
        }

        return Proxy.newProxyInstance(
                targetClass.getClassLoader(),
                interfaces,
                new SecurityAuditInvocationHandler(target, beanName));
    }

    private static class SecurityAuditInvocationHandler implements InvocationHandler {
        private final Object target;
        private final String beanName;
        private final AuditLogger auditLogger;
        private final SecurityValidator securityValidator;
        private final PerformanceMonitor performanceMonitor;

        public SecurityAuditInvocationHandler(Object target, String beanName) {
            this.target = target;
            this.beanName = beanName;
            this.auditLogger = new AuditLogger();
            this.securityValidator = new SecurityValidator();
            this.performanceMonitor = new PerformanceMonitor();
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            long startTime = System.currentTimeMillis();
            String methodName = method.getName();
            String fullMethodName = beanName + "." + methodName;

            try {
                // 1. Pre-invocation security check
                SecurityContext securityContext =
                        securityValidator.validateAccess(beanName, methodName, args);

                // 2. Log method invocation
                auditLogger.logMethodInvocation(securityContext, fullMethodName, args);

                // 3. Monitor for suspicious patterns
                checkForSuspiciousActivity(securityContext, fullMethodName, args);

                // 4. Invoke the actual method
                Object result = method.invoke(target, args);

                // 5. Post-invocation logging
                long executionTime = System.currentTimeMillis() - startTime;
                auditLogger.logMethodSuccess(securityContext, fullMethodName, executionTime);

                // 6. Monitor performance
                performanceMonitor.recordExecution(fullMethodName, executionTime);

                return result;

            } catch (Exception e) {
                // Log security incidents
                long executionTime = System.currentTimeMillis() - startTime;
                SecurityContext securityContext = securityValidator.getCurrentSecurityContext();
                auditLogger.logMethodFailure(securityContext, fullMethodName, e, executionTime);

                // Check if this might be a security attack
                if (isPotentialSecurityAttack(e, fullMethodName)) {
                    auditLogger.logSecurityIncident(securityContext, fullMethodName, e);
                }

                throw e;
            }
        }

        private void checkForSuspiciousActivity(
                SecurityContext context, String methodName, Object[] args) {
            // Rate limiting check
            if (securityValidator.isExcessiveRequestRate(context.getUserId(), methodName)) {
                auditLogger.logSuspiciousActivity(
                        context, "Excessive request rate detected", methodName);
            }

            // Unusual access pattern check
            if (securityValidator.isUnusualAccessPattern(context, methodName)) {
                auditLogger.logSuspiciousActivity(
                        context, "Unusual access pattern detected", methodName);
            }

            // Privilege escalation attempt check
            if (securityValidator.isPotentialPrivilegeEscalation(context, methodName, args)) {
                auditLogger.logSuspiciousActivity(
                        context, "Potential privilege escalation attempt", methodName);
            }
        }

        private boolean isPotentialSecurityAttack(Exception e, String methodName) {
            // Check for SQL injection patterns
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("sql")) {
                return true;
            }

            // Check for access denied exceptions (simplified without Spring Security dependency)
            if (e.getClass().getSimpleName().contains("AccessDenied")) {
                return true;
            }

            // Check for authentication failures
            if (e.getClass().getSimpleName().contains("Authentication")) {
                return true;
            }

            return false;
        }
    }

    // Supporting classes for demonstration

    private static class AuditLogger {
        public void logMethodInvocation(SecurityContext context, String method, Object[] args) {
            System.out.println(
                    "AUDIT: User "
                            + context.getUserId()
                            + " invoking "
                            + method
                            + " from IP: "
                            + context.getClientIp());
        }

        public void logMethodSuccess(SecurityContext context, String method, long executionTime) {
            System.out.println(
                    "AUDIT: Method "
                            + method
                            + " completed successfully in "
                            + executionTime
                            + "ms for user "
                            + context.getUserId());
        }

        public void logMethodFailure(
                SecurityContext context, String method, Exception e, long executionTime) {
            System.out.println(
                    "AUDIT: Method "
                            + method
                            + " failed for user "
                            + context.getUserId()
                            + " after "
                            + executionTime
                            + "ms. Error: "
                            + e.getMessage());
        }

        public void logSuspiciousActivity(SecurityContext context, String reason, String method) {
            System.out.println(
                    "SECURITY ALERT: "
                            + reason
                            + " for user "
                            + context.getUserId()
                            + " on method "
                            + method
                            + " from IP: "
                            + context.getClientIp());
        }

        public void logSecurityIncident(SecurityContext context, String method, Exception e) {
            System.out.println(
                    "SECURITY INCIDENT: Potential attack detected for user "
                            + context.getUserId()
                            + " on method "
                            + method
                            + ". Exception: "
                            + e.getClass().getSimpleName());
        }
    }

    private static class SecurityValidator {
        public SecurityContext validateAccess(String beanName, String methodName, Object[] args) {
            // In real implementation, this would integrate with Spring Security
            SecurityContext context = getCurrentSecurityContext();

            // Check if user has permission for this method
            if (!hasPermission(context, beanName, methodName)) {
                throw new RuntimeException("Access denied to " + beanName + "." + methodName);
            }

            return context;
        }

        public SecurityContext getCurrentSecurityContext() {
            // In real implementation, get from Spring Security context
            return new SecurityContext("user123", "192.168.1.100", new String[] {"USER", "ADMIN"});
        }

        private boolean hasPermission(SecurityContext context, String beanName, String methodName) {
            // Simplified permission check
            return true; // In real implementation, check actual permissions
        }

        public boolean isExcessiveRequestRate(String userId, String methodName) {
            // Check rate limiting (simplified)
            // In real implementation, use Redis or in-memory cache
            return false;
        }

        public boolean isUnusualAccessPattern(SecurityContext context, String methodName) {
            // Check for unusual access patterns (simplified)
            // In real implementation, use ML models or pattern analysis
            return false;
        }

        public boolean isPotentialPrivilegeEscalation(
                SecurityContext context, String methodName, Object[] args) {
            // Check for privilege escalation attempts (simplified)
            // In real implementation, analyze method parameters and context
            return false;
        }
    }

    private static class PerformanceMonitor {
        public void recordExecution(String methodName, long executionTime) {
            if (executionTime > 1000) { // More than 1 second
                System.out.println(
                        "PERFORMANCE WARNING: Method "
                                + methodName
                                + " took "
                                + executionTime
                                + "ms to execute");
            }
        }
    }

    private static class SecurityContext {
        private final String userId;
        private final String clientIp;
        private final String[] roles;

        public SecurityContext(String userId, String clientIp, String[] roles) {
            this.userId = userId;
            this.clientIp = clientIp;
            this.roles = roles;
        }

        public String getUserId() {
            return userId;
        }

        public String getClientIp() {
            return clientIp;
        }

        public String[] getRoles() {
            return roles;
        }
    }
}
