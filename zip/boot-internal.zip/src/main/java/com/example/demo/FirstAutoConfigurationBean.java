package com.example.demo;

public class FirstAutoConfigurationBean {
    private final String message;

    public FirstAutoConfigurationBean(String message) {
        this.message = message;
        System.out.println("###FirstAutoConfigurationBean created with message: " + message);
    }

    public String getMessage() {
        return message;
    }

    public void printMessage() {
        System.out.println("###Auto-configured bean message: " + message);
    }
}
