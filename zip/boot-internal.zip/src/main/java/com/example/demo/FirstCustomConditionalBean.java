package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FirstCustomConditionalBean {

    @Bean
    @Conditional(FirstCustomCondition.class)
    public BeanC conditionalBeanC() {
        System.out.println("###### Creating BeanC conditionally via FirstCustomCondition");
        return new BeanC();
    }
}
