package com.example.demo.examples;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** Configuration properties for microservice auto-configuration */
@ConfigurationProperties(prefix = "microservice")
public class MicroserviceProperties {

    private Discovery discovery = new Discovery();
    private CircuitBreaker circuitBreaker = new CircuitBreaker();
    private Tracing tracing = new Tracing();
    private Gateway gateway = new Gateway();
    private Monitoring monitoring = new Monitoring();
    private Config config = new Config();

    // Getters and setters
    public Discovery getDiscovery() {
        return discovery;
    }

    public void setDiscovery(Discovery discovery) {
        this.discovery = discovery;
    }

    public CircuitBreaker getCircuitBreaker() {
        return circuitBreaker;
    }

    public void setCircuitBreaker(CircuitBreaker circuitBreaker) {
        this.circuitBreaker = circuitBreaker;
    }

    public Tracing getTracing() {
        return tracing;
    }

    public void setTracing(Tracing tracing) {
        this.tracing = tracing;
    }

    public Gateway getGateway() {
        return gateway;
    }

    public void setGateway(Gateway gateway) {
        this.gateway = gateway;
    }

    public Monitoring getMonitoring() {
        return monitoring;
    }

    public void setMonitoring(Monitoring monitoring) {
        this.monitoring = monitoring;
    }

    public Config getConfig() {
        return config;
    }

    public void setConfig(Config config) {
        this.config = config;
    }

    public static class Discovery {
        private boolean enabled = true;
        private Eureka eureka = new Eureka();
        private Consul consul = new Consul();

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public Eureka getEureka() {
            return eureka;
        }

        public void setEureka(Eureka eureka) {
            this.eureka = eureka;
        }

        public Consul getConsul() {
            return consul;
        }

        public void setConsul(Consul consul) {
            this.consul = consul;
        }

        public static class Eureka {
            private String serviceUrl = "http://localhost:8761/eureka/";

            public String getServiceUrl() {
                return serviceUrl;
            }

            public void setServiceUrl(String serviceUrl) {
                this.serviceUrl = serviceUrl;
            }
        }

        public static class Consul {
            private String host = "localhost";
            private int port = 8500;

            public String getHost() {
                return host;
            }

            public void setHost(String host) {
                this.host = host;
            }

            public int getPort() {
                return port;
            }

            public void setPort(int port) {
                this.port = port;
            }
        }
    }

    public static class CircuitBreaker {
        private boolean enabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    public static class Tracing {
        private boolean enabled = true;
        private Jaeger jaeger = new Jaeger();
        private Zipkin zipkin = new Zipkin();

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public Jaeger getJaeger() {
            return jaeger;
        }

        public void setJaeger(Jaeger jaeger) {
            this.jaeger = jaeger;
        }

        public Zipkin getZipkin() {
            return zipkin;
        }

        public void setZipkin(Zipkin zipkin) {
            this.zipkin = zipkin;
        }

        public static class Jaeger {
            private String endpoint = "http://localhost:14268/api/traces";

            public String getEndpoint() {
                return endpoint;
            }

            public void setEndpoint(String endpoint) {
                this.endpoint = endpoint;
            }
        }

        public static class Zipkin {
            private String baseUrl = "http://localhost:9411/";

            public String getBaseUrl() {
                return baseUrl;
            }

            public void setBaseUrl(String baseUrl) {
                this.baseUrl = baseUrl;
            }
        }
    }

    public static class Gateway {
        private boolean enabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    public static class Monitoring {
        private boolean enabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    public static class Config {
        private boolean enabled = true;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }
}
