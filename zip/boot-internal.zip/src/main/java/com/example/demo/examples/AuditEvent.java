package com.example.demo.examples;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.context.ApplicationEvent;

/**
 * Real-world example: Audit Event
 *
 * <p>Custom event for tracking user actions and system changes for audit purposes.
 */
public class AuditEvent extends ApplicationEvent {

    private final String userId;
    private final String action;
    private final String resourceType;
    private final String resourceId;
    private final Map<String, Object> details;
    private final String clientIp;
    private final String userAgent;
    private final LocalDateTime eventTime;
    private final AuditLevel level;

    public AuditEvent(
            Object source,
            String userId,
            String action,
            String resourceType,
            String resourceId,
            Map<String, Object> details,
            String clientIp,
            String userAgent,
            AuditLevel level) {
        super(source);
        this.userId = userId;
        this.action = action;
        this.resourceType = resourceType;
        this.resourceId = resourceId;
        this.details = details;
        this.clientIp = clientIp;
        this.userAgent = userAgent;
        this.level = level;
        this.eventTime = LocalDateTime.now();
    }

    // Getters
    public String getUserId() {
        return userId;
    }

    public String getAction() {
        return action;
    }

    public String getResourceType() {
        return resourceType;
    }

    public String getResourceId() {
        return resourceId;
    }

    public Map<String, Object> getDetails() {
        return details;
    }

    public String getClientIp() {
        return clientIp;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public LocalDateTime getEventTime() {
        return eventTime;
    }

    public AuditLevel getLevel() {
        return level;
    }

    public enum AuditLevel {
        INFO,
        WARNING,
        CRITICAL
    }

    @Override
    public String toString() {
        return "AuditEvent{"
                + "userId='"
                + userId
                + '\''
                + ", action='"
                + action
                + '\''
                + ", resourceType='"
                + resourceType
                + '\''
                + ", resourceId='"
                + resourceId
                + '\''
                + ", clientIp='"
                + clientIp
                + '\''
                + ", eventTime="
                + eventTime
                + ", level="
                + level
                + '}';
    }
}
