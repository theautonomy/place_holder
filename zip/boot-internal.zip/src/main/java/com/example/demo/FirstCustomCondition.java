package com.example.demo;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class FirstCustomCondition implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        System.out.println("###### FirstCustomCondition - evaluating custom condition");

        // Custom logic - for demo, return true if Java version is 8 or higher
        String javaVersion = System.getProperty("java.version");
        System.out.println("###Java version: " + javaVersion);
        return !javaVersion.startsWith("1.7");
    }
}
