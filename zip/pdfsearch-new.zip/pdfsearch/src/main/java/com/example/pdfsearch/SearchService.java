package com.example.pdfsearch;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SearchService {

    @Autowired
    private VectorStore vectorStore;

    public List<SearchResult> performSimilaritySearch(String query, int topK) {
        SearchRequest searchRequest = SearchRequest.builder().query(query).topK(topK).build();
        List<Document> results = vectorStore.similaritySearch(searchRequest);

        return results.stream()
                .map(doc -> new SearchResult(
                        doc.getText(),
                        doc.getMetadata().getOrDefault("fileName", "Unknown").toString(),
                        0.0, // Redis doesn't return similarity scores by default
                        doc.getMetadata().toString()
                ))
                .collect(Collectors.toList());
    }
}