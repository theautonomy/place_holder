package com.example.pdfsearch;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/api")
public class SearchController {

    @Autowired
    private DocumentService documentService;

    @Autowired
    private SearchService searchService;

    @PostMapping("/upload")
    @ResponseBody
    public ResponseEntity<String> uploadPdf(@RequestParam("file") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("Please select a file to upload");
            }

            if (!file.getContentType().equals("application/pdf")) {
                return ResponseEntity.badRequest().body("Please upload a PDF file");
            }

            String result = documentService.uploadAndProcessPdf(file);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error processing file: " + e.getMessage());
        }
    }

    @PostMapping("/search")
    public String search(@RequestParam String query, 
                    @RequestParam int topK, 
                    Model model) {
    try {
        List<SearchResult> results = searchService.performSimilaritySearch(query, topK);
        model.addAttribute("query", query);
        model.addAttribute("results", results);
    } catch (Exception e) {
        model.addAttribute("error", e.getMessage());
    }
    return "search-results"; // Returns search-results.jte
}

    /*
    @PostMapping("/search")
    public String search(@RequestParam("query") String query,
                        @RequestParam(value = "topK", defaultValue = "5") int topK,
                        Model model) {
        try {
            List<SearchResult> results = searchService.performSimilaritySearch(query, topK);
            model.addAttribute("results", results);
            model.addAttribute("query", query);
            return "search-results";
        } catch (Exception e) {
            model.addAttribute("error", "Error performing search: " + e.getMessage());
            return "search-results";
        }
    }
        */
}