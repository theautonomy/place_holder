package com.example.pdfsearch;

public class SearchResult {
    private String content;
    private String fileName;
    private double similarity;
    private String metadata;

    public SearchResult() {}

    public SearchResult(String content, String fileName, double similarity, String metadata) {
        this.content = content;
        this.fileName = fileName;
        this.similarity = similarity;
        this.metadata = metadata;
    }

    // Getters and Setters
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public double getSimilarity() { return similarity; }
    public void setSimilarity(double similarity) { this.similarity = similarity; }

    public String getMetadata() { return metadata; }
    public void setMetadata(String metadata) { this.metadata = metadata; }
}