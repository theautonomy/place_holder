package gg.jte.generated.ondemand;
import com.example.pdfsearch.SearchResult;;
@SuppressWarnings("unchecked")
public final class JtesearchresultsGenerated {
	public static final String JTE_NAME = "search-results.jte";
	public static final int[] JTE_LINE_INFO = {0,0,2,2,2,2,6,6,6,12,12,12,15,15,17,17,21,21,21,23,23,23,27,27,32,32,32,34,34,34,39,39,39,42,42,45,45,53,53,53,53,2,3,4,4,4,4};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String error, String query, java.util.List<SearchResult> results) {
		jteOutput.writeContent("\r\n");
		if (error != null) {
			jteOutput.writeContent("\r\n<div class=\"bg-red-50 border border-red-200 rounded-lg p-4 mb-6\">\r\n    <div class=\"flex items-center\">\r\n        <svg class=\"w-5 h-5 text-red-500 mr-2\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\r\n            <path fill-rule=\"evenodd\" d=\"M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z\" clip-rule=\"evenodd\"/>\r\n        </svg>\r\n        <span class=\"text-red-800\">");
			jteOutput.setContext("span", null);
			jteOutput.writeUserContent(error);
			jteOutput.writeContent("</span>\r\n    </div>\r\n</div>\r\n");
		}
		jteOutput.writeContent("\r\n\r\n");
		if (results != null && !results.isEmpty()) {
			jteOutput.writeContent("\r\n<div>\r\n    <div class=\"mb-4\">\r\n        <h3 class=\"text-lg font-semibold text-gray-800\">\r\n            Search Results for: \"<span class=\"text-cyan-600\">");
			jteOutput.setContext("span", null);
			jteOutput.writeUserContent(query);
			jteOutput.writeContent("</span>\"\r\n        </h3>\r\n        <p class=\"text-gray-600 text-sm mt-1\">Found ");
			jteOutput.setContext("p", null);
			jteOutput.writeUserContent(results.size());
			jteOutput.writeContent(" relevant results</p>\r\n    </div>\r\n    \r\n    <div class=\"space-y-4\">\r\n        ");
			for (int i = 0; i < results.size(); i++) {
				jteOutput.writeContent("\r\n        <div class=\"bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100 hover:shadow-lg transition-shadow duration-200\">\r\n            <div class=\"flex items-start justify-between mb-3\">\r\n                <div class=\"flex items-center space-x-2\">\r\n                    <span class=\"bg-indigo-100 text-indigo-800 text-xs font-medium px-2.5 py-0.5 rounded-full\">\r\n                        Result ");
				jteOutput.setContext("span", null);
				jteOutput.writeUserContent(i + 1);
				jteOutput.writeContent("\r\n                    </span>\r\n                    <span class=\"text-sm text-gray-600\">From: ");
				jteOutput.setContext("span", null);
				jteOutput.writeUserContent(results.get(i).getFileName());
				jteOutput.writeContent("</span>\r\n                </div>\r\n            </div>\r\n            \r\n            <div class=\"prose prose-sm max-w-none\">\r\n                <p class=\"text-gray-800 leading-relaxed\">");
				jteOutput.setContext("p", null);
				jteOutput.writeUserContent(results.get(i).getContent());
				jteOutput.writeContent("</p>\r\n            </div>\r\n        </div>\r\n        ");
			}
			jteOutput.writeContent("\r\n    </div>\r\n</div>\r\n");
		} else if (results != null && results.isEmpty()) {
			jteOutput.writeContent("\r\n<div class=\"text-center py-12\">\r\n    <svg class=\"mx-auto h-12 w-12 text-gray-400\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">\r\n        <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0118 12M6 20.438A7.962 7.962 0 006 12m0 8.438a7.962 7.962 0 010-16.876M6 20.438A7.962 7.962 0 0018 12a7.962 7.962 0 00-12 8.438z\"/>\r\n    </svg>\r\n    <h3 class=\"mt-2 text-sm font-medium text-gray-900\">No results found</h3>\r\n    <p class=\"mt-1 text-sm text-gray-500\">Try adjusting your search query or upload more documents.</p>\r\n</div>\r\n");
		}
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String error = (String)params.get("error");
		String query = (String)params.get("query");
		java.util.List<SearchResult> results = (java.util.List<SearchResult>)params.get("results");
		render(jteOutput, jteHtmlInterceptor, error, query, results);
	}
}
