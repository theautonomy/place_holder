# Tutorials

Step-by-step guides to help you build real-world projects.

## Available Tutorials

<div class="grid cards" markdown>

-   :material-database-search:{ .lg .middle } __Building a RAG System__

    ---

    Learn how to build a Retrieval Augmented Generation system from scratch

    [:octicons-arrow-right-24: Start tutorial](building-rag.md)

-   :material-connection:{ .lg .middle } __Working with MCP__

    ---

    Connect AI assistants to external tools using Model Context Protocol

    [:octicons-arrow-right-24: Start tutorial](working-with-mcp.md)

</div>

## Prerequisites

Before starting these tutorials, you should have:

- [x] Python 3.8+ installed
- [x] Basic understanding of Python
- [x] Familiarity with command line
- [ ] OpenAI or Anthropic API key (for AI tutorials)

## Difficulty Levels

| Tutorial | Difficulty | Time |
|----------|------------|------|
| Building a RAG System | Intermediate | 45 min |
| Working with MCP | Beginner | 30 min |

!!! tip "Learning Path"

    We recommend starting with **Working with MCP** if you're new to AI integrations, then moving on to **Building a RAG System** for more advanced concepts.
