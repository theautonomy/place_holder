# Building a RAG System

Learn how to build a Retrieval Augmented Generation (RAG) system from scratch.

## Overview

In this tutorial, you'll learn how to:

- [x] Set up a vector database
- [x] Chunk and embed documents
- [x] Perform similarity search
- [x] Generate responses with context

```mermaid
flowchart LR
    A[Documents] --> B[Chunk]
    B --> C[Embed]
    C --> D[(Vector DB)]
    E[Query] --> F[Embed]
    F --> D
    D --> G[Context]
    G --> H[LLM]
    E --> H
    H --> I[Response]

    style A fill:#e3f2fd,stroke:#1565c0
    style D fill:#f3e5f5,stroke:#7b1fa2
    style H fill:#ffebee,stroke:#c62828
    style I fill:#c8e6c9,stroke:#2e7d32
```

## Prerequisites

!!! note "Requirements"

    - Python 3.8+
    - OpenAI API key
    - Basic understanding of embeddings

## Step 1: Install Dependencies

```bash
pip install openai chromadb langchain tiktoken
```

## Step 2: Set Up the Vector Database

=== "ChromaDB"

    ```python
    import chromadb
    from chromadb.config import Settings

    # Initialize client
    client = chromadb.Client(Settings(
        chroma_db_impl="duckdb+parquet",
        persist_directory="./chroma_db"
    ))

    # Create collection
    collection = client.create_collection(
        name="documents",
        metadata={"hnsw:space": "cosine"}
    )
    ```

=== "Pinecone"

    ```python
    import pinecone

    pinecone.init(
        api_key="your-api-key",
        environment="your-environment"
    )

    index = pinecone.Index("documents")
    ```

## Step 3: Document Chunking

```python
from langchain.text_splitter import RecursiveCharacterTextSplitter

def chunk_document(text: str, chunk_size: int = 1000) -> list[str]:
    """Split document into chunks."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=200,  # (1)!
        separators=["\n\n", "\n", ". ", " ", ""]
    )
    return splitter.split_text(text)
```

1.  Overlap ensures context isn't lost at chunk boundaries

## Step 4: Generate Embeddings

```python
from openai import OpenAI

client = OpenAI()

def get_embedding(text: str) -> list[float]:
    """Generate embedding for text."""
    response = client.embeddings.create(
        model="text-embedding-3-small",
        input=text
    )
    return response.data[0].embedding
```

## Step 5: Store in Vector Database

```python
def index_documents(documents: list[str]):
    """Index documents in vector database."""
    for i, doc in enumerate(documents):
        embedding = get_embedding(doc)
        collection.add(
            embeddings=[embedding],
            documents=[doc],
            ids=[f"doc_{i}"]
        )
```

## Step 6: Query and Retrieve

```python
def retrieve(query: str, n_results: int = 3) -> list[str]:
    """Retrieve relevant documents."""
    query_embedding = get_embedding(query)

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=n_results
    )

    return results["documents"][0]
```

## Step 7: Generate Response

```python
def generate_response(query: str, context: list[str]) -> str:
    """Generate response using retrieved context."""
    context_text = "\n\n".join(context)

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {
                "role": "system",
                "content": f"Answer based on this context:\n\n{context_text}"
            },
            {
                "role": "user",
                "content": query
            }
        ]
    )

    return response.choices[0].message.content
```

## Complete Example

```python
def rag_query(query: str) -> str:
    """Complete RAG pipeline."""
    # Retrieve relevant documents
    context = retrieve(query, n_results=3)

    # Generate response
    response = generate_response(query, context)

    return response

# Usage
answer = rag_query("What is machine learning?")
print(answer)
```

## Best Practices

!!! tip "Chunking Strategy"

    - Use semantic chunking when possible
    - Maintain context with overlap
    - Consider document structure (headers, paragraphs)

!!! warning "Common Pitfalls"

    - Chunks too large = less precise retrieval
    - Chunks too small = missing context
    - No overlap = broken context at boundaries

## Next Steps

- Explore [AI Architecture](../reference/ai-architecture.md) for visual diagrams
- Learn about [MCP integration](working-with-mcp.md)
