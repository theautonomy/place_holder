# Working with MCP

Learn how to use the Model Context Protocol to connect AI assistants with external tools.

## Overview

The Model Context Protocol (MCP) enables AI assistants to:

- Access local files and databases
- Call external APIs
- Execute custom tools
- Read dynamic resources

```mermaid
flowchart LR
    subgraph Host
        AI[AI Assistant]
        MC[MCP Client]
    end

    subgraph Server
        S[MCP Server]
        T[Tools]
        R[Resources]
    end

    AI <--> MC
    MC <-->|JSON-RPC| S
    S --> T
    S --> R

    style AI fill:#e3f2fd,stroke:#1565c0
    style S fill:#fff3e0,stroke:#ef6c00
    style T fill:#e8f5e9,stroke:#388e3c
    style R fill:#f3e5f5,stroke:#7b1fa2
```

## Prerequisites

!!! note "Requirements"

    - Node.js 18+ or Python 3.10+
    - Claude Desktop or compatible MCP host
    - Basic understanding of JSON-RPC

## Installing an MCP Server

### Using npx (Node.js)

```bash
# Filesystem server
npx -y @modelcontextprotocol/server-filesystem /path/to/allowed/directory

# SQLite server
npx -y @modelcontextprotocol/server-sqlite /path/to/database.db
```

### Using uvx (Python)

```bash
# Filesystem server
uvx mcp-server-filesystem /path/to/allowed/directory

# Git server
uvx mcp-server-git --repository /path/to/repo
```

## Configuring Claude Desktop

Edit your Claude Desktop configuration file:

=== "macOS"

    Location: `~/Library/Application Support/Claude/claude_desktop_config.json`

=== "Windows"

    Location: `%APPDATA%\Claude\claude_desktop_config.json`

### Example Configuration

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/Users/username/Documents"
      ]
    },
    "sqlite": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-sqlite",
        "/Users/username/data.db"
      ]
    }
  }
}
```

## Building a Custom MCP Server

### Python Example

```python title="my_server.py"
from mcp.server import Server
from mcp.types import Tool, TextContent

# Create server
server = Server("my-tools")

@server.tool()
async def get_weather(city: str) -> str:
    """Get current weather for a city."""
    # Your implementation here
    return f"Weather in {city}: Sunny, 72°F"

@server.tool()
async def calculate(expression: str) -> str:
    """Evaluate a math expression."""
    result = eval(expression)  # (1)!
    return str(result)

if __name__ == "__main__":
    server.run()
```

1.  In production, use a safe expression parser instead of `eval`

### TypeScript Example

```typescript title="server.ts"
import { Server } from "@modelcontextprotocol/sdk/server";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio";

const server = new Server({
  name: "my-tools",
  version: "1.0.0",
});

server.setRequestHandler("tools/list", async () => ({
  tools: [
    {
      name: "greet",
      description: "Generate a greeting",
      inputSchema: {
        type: "object",
        properties: {
          name: { type: "string" },
        },
        required: ["name"],
      },
    },
  ],
}));

server.setRequestHandler("tools/call", async (request) => {
  if (request.params.name === "greet") {
    const name = request.params.arguments.name;
    return { content: [{ type: "text", text: `Hello, ${name}!` }] };
  }
});

const transport = new StdioServerTransport();
server.connect(transport);
```

## MCP Concepts

### Tools

Tools are actions the AI can perform:

| Tool Type | Example |
|-----------|---------|
| Read | Get file contents |
| Write | Create or update files |
| Execute | Run shell commands |
| Query | Search databases |

### Resources

Resources are data the AI can access:

```python
@server.resource("file://{path}")
async def read_file(path: str) -> str:
    """Read a file from the filesystem."""
    with open(path) as f:
        return f.read()
```

### Prompts

Prompts are reusable templates:

```python
@server.prompt()
async def code_review() -> str:
    """Prompt for code review."""
    return """Please review this code for:
    - Security issues
    - Performance problems
    - Code style
    """
```

## Debugging

!!! tip "Enable Logging"

    Set environment variables for debugging:

    ```bash
    export MCP_DEBUG=1
    export MCP_LOG_LEVEL=debug
    ```

!!! warning "Common Issues"

    - **Server not connecting**: Check the command path
    - **Tools not appearing**: Restart Claude Desktop
    - **Permission errors**: Verify file/folder permissions

## Best Practices

1. **Security First**
    - Validate all inputs
    - Limit file system access
    - Use allowlists for commands

2. **Error Handling**
    - Return meaningful error messages
    - Handle timeouts gracefully
    - Log errors for debugging

3. **Performance**
    - Cache expensive operations
    - Use async where possible
    - Limit response sizes

## Next Steps

- See [AI Architecture](../reference/ai-architecture.md) for MCP diagrams
- Explore [Building a RAG System](building-rag.md) to combine with RAG
