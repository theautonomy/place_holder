# Test Notebook

A documentation site for learning and reference.

---

<div class="grid cards" markdown>

-   :material-clock-fast:{ .lg .middle } __Set up in 5 minutes__

    ---

    Get started quickly with our step-by-step installation guide

    [:octicons-arrow-right-24: Getting started](getting-started/index.md)

-   :material-book-open-variant:{ .lg .middle } __Comprehensive Reference__

    ---

    Explore diagrams, code blocks, admonitions, and more

    [:octicons-arrow-right-24: Reference](reference/index.md)

-   :material-school:{ .lg .middle } __Hands-on Tutorials__

    ---

    Learn by building real projects with RAG and MCP

    [:octicons-arrow-right-24: Tutorials](tutorials/index.md)

-   :material-newspaper:{ .lg .middle } __Latest from the Blog__

    ---

    Stay updated with tips, tricks, and news

    [:octicons-arrow-right-24: Blog](blog/index.md)

</div>

---

## Features

### Diagrams

Create beautiful diagrams using Mermaid.js:

```mermaid
flowchart LR
    A[Write] --> B[Build]
    B --> C[Deploy]
    C --> D[Share]

    style A fill:#e3f2fd,stroke:#1565c0
    style B fill:#fff3e0,stroke:#ef6c00
    style C fill:#e8f5e9,stroke:#388e3c
    style D fill:#f3e5f5,stroke:#7b1fa2
```

### Code Blocks

Syntax highlighting with annotations:

```python
def hello(name: str) -> str:  # (1)!
    """Return a greeting."""
    return f"Hello, {name}!"
```

1.  Type hints for better code documentation

### Admonitions

!!! tip "Pro Tip"

    Use admonitions to highlight important information in your documentation.

!!! example "Example"

    Admonitions support all markdown features including code blocks and lists.

---

## Quick Links

| Section | Description |
|---------|-------------|
| [Installation](getting-started/installation.md) | How to install and set up |
| [Diagrams](reference/diagrams.md) | All Mermaid diagram types |
| [AI Architecture](reference/ai-architecture.md) | RAG and MCP visualizations |
| [Code Blocks](reference/code-blocks.md) | Syntax highlighting features |
| [Building RAG](tutorials/building-rag.md) | RAG tutorial |
