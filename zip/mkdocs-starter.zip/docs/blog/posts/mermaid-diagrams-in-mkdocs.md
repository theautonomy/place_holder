---
date:
  created: 2025-02-10
categories:
  - Documentation
  - Tutorial
tags:
  - Mermaid
  - MkDocs
  - Diagrams
---

# Using Mermaid Diagrams in MkDocs

Learn how to create beautiful diagrams in your MkDocs documentation using Mermaid.js.

<!-- more -->

## Why Mermaid?

Mermaid allows you to create diagrams using simple text syntax. No need for external tools or image files - your diagrams live in your markdown and are rendered automatically.

## Setup

Add the superfences extension to your `mkdocs.yml`:

```yaml
markdown_extensions:
  - pymdownx.superfences:
      custom_fences:
        - name: mermaid
          class: mermaid
          format: !!python/name:pymdownx.superfences.fence_code_format
```

## Example: Flowchart

```mermaid
flowchart LR
    A[Write Docs] --> B[Add Diagrams]
    B --> C[Deploy]
    C --> D[Share Knowledge]
```

## Example: Sequence Diagram

```mermaid
sequenceDiagram
    Developer->>MkDocs: Write content
    MkDocs->>Browser: Render site
    Browser->>User: Display docs
```

## Supported Diagram Types

- Flowcharts
- Sequence diagrams
- Class diagrams
- State diagrams
- ER diagrams
- And many more!

Check out our [Diagrams page](../../../../../reference/diagrams/) for a complete showcase of all supported diagram types.
