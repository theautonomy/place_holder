# Configuration

Learn how to configure and customize your documentation site.

## Basic Configuration

The `mkdocs.yml` file controls all aspects of your site:

```yaml
site_name: My Documentation
site_url: https://example.com
site_description: A great documentation site

repo_url: https://github.com/username/repo
repo_name: username/repo
```

## Theme Configuration

### Color Schemes

=== "Light Mode"

    ```yaml
    theme:
      name: material
      palette:
        scheme: default
        primary: indigo
        accent: indigo
    ```

=== "Dark Mode"

    ```yaml
    theme:
      name: material
      palette:
        scheme: slate
        primary: black
        accent: indigo
    ```

=== "Auto Toggle"

    ```yaml
    theme:
      name: material
      palette:
        - media: "(prefers-color-scheme: light)"
          scheme: default
          toggle:
            icon: material/brightness-7
            name: Switch to dark mode
        - media: "(prefers-color-scheme: dark)"
          scheme: slate
          toggle:
            icon: material/brightness-4
            name: Switch to light mode
    ```

### Available Colors

| Primary | Accent |
|---------|--------|
| `red` | `red` |
| `pink` | `pink` |
| `purple` | `purple` |
| `deep purple` | `deep purple` |
| `indigo` | `indigo` |
| `blue` | `blue` |
| `teal` | `teal` |
| `green` | `green` |

## Navigation Features

Enable powerful navigation features:

```yaml
theme:
  features:
    - navigation.tabs          # Top-level tabs
    - navigation.tabs.sticky   # Sticky tabs
    - navigation.sections      # Section headers
    - navigation.expand        # Expand all by default
    - navigation.indexes       # Section index pages
    - navigation.top           # Back to top button
    - navigation.footer        # Footer navigation
```

## Search Configuration

```yaml
plugins:
  - search:
      separator: '[\s\-,:!=\[\]()"/]+|(?!\b)(?=[A-Z][a-z])'

theme:
  features:
    - search.suggest          # Search suggestions
    - search.highlight        # Highlight matches
    - search.share            # Share search results
```

## Code Blocks

Enable code block features:

```yaml
theme:
  features:
    - content.code.copy       # Copy button
    - content.code.annotate   # Code annotations

markdown_extensions:
  - pymdownx.highlight:
      anchor_linenums: true
  - pymdownx.superfences
```

## Social Links

Add social links to the footer:

```yaml
extra:
  social:
    - icon: fontawesome/brands/github
      link: https://github.com/username
    - icon: fontawesome/brands/twitter
      link: https://twitter.com/username
    - icon: fontawesome/brands/linkedin
      link: https://linkedin.com/in/username
```

## Environment Variables

You can use environment variables:

```yaml
site_name: !ENV [SITE_NAME, "My Site"]
```

!!! tip "Sensitive Data"

    Use environment variables for API keys and sensitive configuration.
