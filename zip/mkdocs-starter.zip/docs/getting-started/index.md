# Getting Started

Welcome to the documentation! This section will help you get up and running quickly.

## Overview

This documentation site covers:

- **Installation** - How to set up the project
- **Quick Start** - Get running in minutes
- **Configuration** - Customize to your needs

## Prerequisites

Before you begin, ensure you have:

- Python 3.8 or higher
- pip package manager
- Git (optional, for version control)

## Next Steps

<div class="grid cards" markdown>

-   :material-download:{ .lg .middle } __Installation__

    ---

    Install the project and its dependencies

    [:octicons-arrow-right-24: Installation guide](installation.md)

-   :material-clock-fast:{ .lg .middle } __Quick Start__

    ---

    Get up and running in under 5 minutes

    [:octicons-arrow-right-24: Quick start](quickstart.md)

-   :material-cog:{ .lg .middle } __Configuration__

    ---

    Learn how to configure and customize

    [:octicons-arrow-right-24: Configuration](configuration.md)

</div>
