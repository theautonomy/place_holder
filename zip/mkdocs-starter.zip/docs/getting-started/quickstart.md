# Quick Start

Get up and running in under 5 minutes.

## Create a New Project

```bash
mkdocs new my-project
cd my-project
```

This creates the following structure:

```
my-project/
├── docs/
│   └── index.md
└── mkdocs.yml
```

## Configure Material Theme

Edit `mkdocs.yml`:

```yaml
site_name: My Site
theme:
  name: material
```

## Start Development Server

```bash
mkdocs serve
```

Visit [http://127.0.0.1:8000](http://127.0.0.1:8000) to see your site.

!!! success "Hot Reload"

    The development server automatically reloads when you make changes.

## Add Your First Page

Create `docs/getting-started.md`:

```markdown
# Getting Started

Welcome to my documentation!

## Features

- Easy to use
- Fast and responsive
- Beautiful design
```

Update `mkdocs.yml` to include it in navigation:

```yaml
nav:
  - Home: index.md
  - Getting Started: getting-started.md
```

## Build for Production

When ready to deploy:

```bash
mkdocs build
```

This creates a `site/` directory with static HTML files.

## Deploy to GitHub Pages

```bash
mkdocs gh-deploy
```

!!! info "Automatic Deployment"

    You can also set up GitHub Actions for automatic deployment on push.

## Next Steps

- [Configuration](configuration.md) - Customize your site
- [Reference](../reference/index.md) - Explore all features
