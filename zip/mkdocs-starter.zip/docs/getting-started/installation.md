# Installation

This guide covers how to install and set up the project.

## Requirements

| Requirement | Version |
|-------------|---------|
| Python | 3.8+ |
| pip | Latest |
| MkDocs | 1.5+ |
| MkDocs Material | 9.0+ |

## Installation Methods

=== "pip"

    ```bash
    pip install mkdocs-material
    ```

=== "pipx"

    ```bash
    pipx install mkdocs-material
    ```

=== "Docker"

    ```bash
    docker pull squidfunk/mkdocs-material
    ```

## Verify Installation

After installation, verify it works:

```bash
mkdocs --version
```

You should see output like:

```
mkdocs, version 1.5.3 from /usr/local/lib/python3.11/site-packages/mkdocs (Python 3.11)
```

## Additional Plugins

Install recommended plugins:

```bash
pip install mkdocs-material[imaging]
pip install mkdocs-git-revision-date-plugin
```

## Troubleshooting

!!! warning "Common Issues"

    If you encounter permission errors, try:

    ```bash
    pip install --user mkdocs-material
    ```

!!! tip "Virtual Environment"

    It's recommended to use a virtual environment:

    ```bash
    python -m venv venv
    source venv/bin/activate  # Linux/macOS
    venv\Scripts\activate     # Windows
    pip install mkdocs-material
    ```

## Next Steps

Once installed, proceed to the [Quick Start](quickstart.md) guide.
