# AI Architecture Diagrams

Visual explanations of modern AI architecture patterns.

## RAG (Retrieval Augmented Generation)

RAG enhances LLM responses by retrieving relevant context from external knowledge sources.

### RAG Overview

```mermaid
flowchart LR
    subgraph Input
        Q[User Query]
    end

    subgraph Retrieval
        E1[Embed Query]
        VS[(Vector Store)]
        R[Relevant Documents]
    end

    subgraph Generation
        LLM[LLM]
        A[Answer]
    end

    Q --> E1
    E1 --> VS
    VS --> R
    Q --> LLM
    R --> LLM
    LLM --> A

    style Q fill:#e1f5fe,stroke:#01579b
    style E1 fill:#fff3e0,stroke:#e65100
    style VS fill:#f3e5f5,stroke:#7b1fa2
    style R fill:#e8f5e9,stroke:#2e7d32
    style LLM fill:#ffebee,stroke:#c62828
    style A fill:#e8f5e9,stroke:#2e7d32
```

### RAG Ingestion Pipeline

```mermaid
flowchart TB
    subgraph Sources
        D1[Documents]
        D2[PDFs]
        D3[Web Pages]
        D4[Databases]
    end

    subgraph Processing
        L[Load Documents]
        C[Chunk Text]
        E[Generate Embeddings]
    end

    subgraph Storage
        VS[(Vector Database)]
        M[(Metadata Store)]
    end

    D1 & D2 & D3 & D4 --> L
    L --> C
    C --> E
    E --> VS
    C --> M

    style D1 fill:#e3f2fd,stroke:#1565c0
    style D2 fill:#e3f2fd,stroke:#1565c0
    style D3 fill:#e3f2fd,stroke:#1565c0
    style D4 fill:#e3f2fd,stroke:#1565c0
    style L fill:#fff8e1,stroke:#f9a825
    style C fill:#fff8e1,stroke:#f9a825
    style E fill:#fff8e1,stroke:#f9a825
    style VS fill:#f3e5f5,stroke:#7b1fa2
    style M fill:#fce4ec,stroke:#c2185b
```

### RAG Query Flow

```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant App as Application
    participant Emb as Embedding Model
    participant VDB as Vector DB
    participant LLM as LLM

    U->>App: Ask question
    App->>Emb: Convert to embedding
    Emb-->>App: Query vector
    App->>VDB: Similarity search
    VDB-->>App: Top K documents
    App->>App: Build prompt with context
    App->>LLM: Send augmented prompt
    LLM-->>App: Generated response
    App-->>U: Answer with sources
```

### Advanced RAG Patterns

```mermaid
flowchart TB
    Q[Query] --> QR[Query Rewriting]
    QR --> HyDE[HyDE: Hypothetical Document]
    QR --> MQ[Multi-Query Expansion]

    HyDE --> R1[Retrieval]
    MQ --> R1

    R1 --> RR[Re-ranking]
    RR --> F[Filtering]
    F --> C[Context Compression]

    C --> LLM[LLM Generation]
    LLM --> V{Validate}

    V -->|Pass| A[Answer]
    V -->|Fail| QR

    style Q fill:#e1f5fe,stroke:#0277bd
    style QR fill:#fff3e0,stroke:#ef6c00
    style HyDE fill:#fce4ec,stroke:#c2185b
    style MQ fill:#fce4ec,stroke:#c2185b
    style R1 fill:#e8f5e9,stroke:#388e3c
    style RR fill:#f3e5f5,stroke:#7b1fa2
    style F fill:#f3e5f5,stroke:#7b1fa2
    style C fill:#f3e5f5,stroke:#7b1fa2
    style LLM fill:#ffebee,stroke:#d32f2f
    style V fill:#fff8e1,stroke:#fbc02d
    style A fill:#c8e6c9,stroke:#2e7d32
```

---

## MCP (Model Context Protocol)

MCP is an open protocol that enables AI assistants to securely connect to external data sources and tools.

### MCP Architecture Overview

```mermaid
flowchart TB
    subgraph Host["Host Application"]
        AI[AI Assistant]
        MC[MCP Client]
    end

    subgraph Servers["MCP Servers"]
        S1[File System Server]
        S2[Database Server]
        S3[API Server]
        S4[Tool Server]
    end

    subgraph Resources["External Resources"]
        FS[Local Files]
        DB[(Databases)]
        API[Web APIs]
        Tools[Custom Tools]
    end

    AI <--> MC
    MC <-->|JSON-RPC| S1
    MC <-->|JSON-RPC| S2
    MC <-->|JSON-RPC| S3
    MC <-->|JSON-RPC| S4

    S1 <--> FS
    S2 <--> DB
    S3 <--> API
    S4 <--> Tools

    style AI fill:#e3f2fd,stroke:#1565c0
    style MC fill:#e3f2fd,stroke:#1565c0
    style S1 fill:#fff3e0,stroke:#ef6c00
    style S2 fill:#fff3e0,stroke:#ef6c00
    style S3 fill:#fff3e0,stroke:#ef6c00
    style S4 fill:#fff3e0,stroke:#ef6c00
    style FS fill:#e8f5e9,stroke:#388e3c
    style DB fill:#f3e5f5,stroke:#7b1fa2
    style API fill:#ffebee,stroke:#c62828
    style Tools fill:#fce4ec,stroke:#c2185b
```

### MCP Communication Flow

```mermaid
sequenceDiagram
    autonumber
    participant User
    participant Host as Host (Claude Desktop)
    participant Client as MCP Client
    participant Server as MCP Server
    participant Resource as External Resource

    User->>Host: Request action
    Host->>Client: Forward request
    Client->>Server: Initialize connection
    Server-->>Client: Capabilities response

    Client->>Server: List available tools
    Server-->>Client: Tool definitions

    Client->>Server: Call tool
    Server->>Resource: Access data
    Resource-->>Server: Return data
    Server-->>Client: Tool result

    Client-->>Host: Processed result
    Host-->>User: Display response
```

### MCP Core Components

```mermaid
flowchart LR
    subgraph Protocol["MCP Protocol"]
        direction TB
        T[Tools]
        R[Resources]
        P[Prompts]
    end

    subgraph Tools_Detail["Tools"]
        T1[Execute Actions]
        T2[Call APIs]
        T3[Run Commands]
    end

    subgraph Resources_Detail["Resources"]
        R1[Read Files]
        R2[Query Data]
        R3[Fetch URLs]
    end

    subgraph Prompts_Detail["Prompts"]
        P1[Templates]
        P2[Instructions]
        P3[Workflows]
    end

    T --> T1 & T2 & T3
    R --> R1 & R2 & R3
    P --> P1 & P2 & P3

    style T fill:#e3f2fd,stroke:#1565c0
    style R fill:#e8f5e9,stroke:#388e3c
    style P fill:#fff3e0,stroke:#ef6c00
    style T1 fill:#bbdefb,stroke:#1976d2
    style T2 fill:#bbdefb,stroke:#1976d2
    style T3 fill:#bbdefb,stroke:#1976d2
    style R1 fill:#c8e6c9,stroke:#43a047
    style R2 fill:#c8e6c9,stroke:#43a047
    style R3 fill:#c8e6c9,stroke:#43a047
    style P1 fill:#ffe0b2,stroke:#fb8c00
    style P2 fill:#ffe0b2,stroke:#fb8c00
    style P3 fill:#ffe0b2,stroke:#fb8c00
```

### MCP Server Types

```mermaid
flowchart TB
    subgraph Local["Local Servers"]
        FS[Filesystem]
        Git[Git Repository]
        SQLite[SQLite DB]
    end

    subgraph Remote["Remote Servers"]
        Slack[Slack]
        GitHub[GitHub API]
        Postgres[PostgreSQL]
    end

    subgraph Custom["Custom Servers"]
        Int[Internal APIs]
        Legacy[Legacy Systems]
        Prop[Proprietary Tools]
    end

    MCP[MCP Client] --> Local
    MCP --> Remote
    MCP --> Custom

    style MCP fill:#e3f2fd,stroke:#1565c0
    style FS fill:#c8e6c9,stroke:#43a047
    style Git fill:#c8e6c9,stroke:#43a047
    style SQLite fill:#c8e6c9,stroke:#43a047
    style Slack fill:#fff3e0,stroke:#ef6c00
    style GitHub fill:#fff3e0,stroke:#ef6c00
    style Postgres fill:#fff3e0,stroke:#ef6c00
    style Int fill:#f3e5f5,stroke:#7b1fa2
    style Legacy fill:#f3e5f5,stroke:#7b1fa2
    style Prop fill:#f3e5f5,stroke:#7b1fa2
```

### MCP vs Traditional Integration

```mermaid
flowchart TB
    subgraph Traditional["Traditional Approach"]
        direction LR
        A1[App] --> I1[Custom Integration 1]
        A1 --> I2[Custom Integration 2]
        A1 --> I3[Custom Integration 3]
        I1 --> S1[Service 1]
        I2 --> S2[Service 2]
        I3 --> S3[Service 3]
    end

    subgraph MCP_Approach["MCP Approach"]
        direction LR
        A2[App] --> MC[MCP Client]
        MC --> MS1[MCP Server 1]
        MC --> MS2[MCP Server 2]
        MC --> MS3[MCP Server 3]
        MS1 --> SS1[Service 1]
        MS2 --> SS2[Service 2]
        MS3 --> SS3[Service 3]
    end

    style A1 fill:#ffcdd2,stroke:#c62828
    style I1 fill:#ffcdd2,stroke:#c62828
    style I2 fill:#ffcdd2,stroke:#c62828
    style I3 fill:#ffcdd2,stroke:#c62828
    style A2 fill:#c8e6c9,stroke:#2e7d32
    style MC fill:#c8e6c9,stroke:#2e7d32
    style MS1 fill:#c8e6c9,stroke:#2e7d32
    style MS2 fill:#c8e6c9,stroke:#2e7d32
    style MS3 fill:#c8e6c9,stroke:#2e7d32
```

---

## RAG + MCP Combined

Using MCP to enhance RAG with dynamic data sources.

```mermaid
flowchart TB
    U[User Query] --> AI[AI Assistant]

    AI --> MCP[MCP Client]

    subgraph MCP_Servers["MCP Servers"]
        VS_Server[Vector Store Server]
        Doc_Server[Document Server]
        Web_Server[Web Search Server]
    end

    MCP --> VS_Server
    MCP --> Doc_Server
    MCP --> Web_Server

    VS_Server --> VDB[(Vector DB)]
    Doc_Server --> Files[File System]
    Web_Server --> Web[Web APIs]

    VS_Server --> Context
    Doc_Server --> Context
    Web_Server --> Context

    Context[Retrieved Context] --> AI
    AI --> Response[Enhanced Response]
    Response --> U

    style U fill:#e1f5fe,stroke:#0277bd
    style AI fill:#e3f2fd,stroke:#1565c0
    style MCP fill:#bbdefb,stroke:#1976d2
    style VS_Server fill:#fff3e0,stroke:#ef6c00
    style Doc_Server fill:#fff3e0,stroke:#ef6c00
    style Web_Server fill:#fff3e0,stroke:#ef6c00
    style VDB fill:#f3e5f5,stroke:#7b1fa2
    style Files fill:#e8f5e9,stroke:#388e3c
    style Web fill:#ffebee,stroke:#c62828
    style Context fill:#fff8e1,stroke:#f9a825
    style Response fill:#c8e6c9,stroke:#2e7d32
```
