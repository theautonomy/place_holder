# Admonitions

Callout boxes to highlight important information.

## Basic Types

!!! note

    This is a note. Use it for additional information that's helpful but not critical.

!!! tip

    This is a tip. Use it for best practices and recommendations.

!!! info

    This is informational. Use it for general context.

!!! success

    This indicates success. Use it for positive outcomes.

!!! warning

    This is a warning. Use it for potential issues.

!!! danger

    This is dangerous. Use it for critical warnings.

!!! bug

    This indicates a bug. Use it for known issues.

!!! example

    This is an example. Use it to demonstrate concepts.

!!! quote

    This is a quote. Use it for citations and references.

## With Custom Titles

!!! note "Custom Title Here"

    You can customize the title of any admonition.

!!! warning "Deprecation Notice"

    This feature will be removed in version 2.0.

## Collapsible Admonitions

??? note "Click to expand"

    This content is hidden by default. Click the title to reveal it.

    - Point 1
    - Point 2
    - Point 3

???+ tip "Expanded by default"

    Use `???+` to make it expanded by default.

    Users can still collapse it if they want.

## Inline Admonitions

!!! info inline end "Side Note"

    This appears on the right side of the content.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla. Curabitur feugiat, tortor non consequat finibus, justo purus auctor massa, nec semper lorem quam in massa.

!!! tip inline "Left Side"

    This appears on the left side.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis.

## Nested Content

!!! example "Complex Example"

    Admonitions can contain any markdown:

    ```python
    def example():
        return "Hello from admonition!"
    ```

    | Feature | Supported |
    |---------|-----------|
    | Code | Yes |
    | Tables | Yes |
    | Lists | Yes |

    - Bullet points work
    - Nested lists too
        - Like this one

## Abstract & Summary

!!! abstract

    Use abstract for document summaries or TL;DR sections.

!!! summary

    Summary is an alias for abstract.

## Question & FAQ

!!! question "Frequently Asked Question"

    **Q: Can I customize admonition colors?**

    A: Yes! You can customize colors using CSS variables.

## Failure States

!!! failure

    This indicates a failure or error condition.

!!! missing

    This indicates something is missing or not found.
