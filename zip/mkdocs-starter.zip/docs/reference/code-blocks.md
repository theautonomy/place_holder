# Code Blocks

Showcase of code block features with syntax highlighting, annotations, and more.

## Basic Syntax Highlighting

```python
def hello_world():
    """A simple greeting function."""
    print("Hello, World!")

if __name__ == "__main__":
    hello_world()
```

## With Line Numbers

```python linenums="1"
def fibonacci(n):
    """Generate Fibonacci sequence."""
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

# Calculate first 10 numbers
for i in range(10):
    print(fibonacci(i))
```

## Highlighting Specific Lines

```python hl_lines="2 3 4"
def important_function():
    # These lines are highlighted
    critical_step_1()
    critical_step_2()
    # Back to normal
    cleanup()
```

## Code Annotations

```python
def create_user(name, email): # (1)!
    user = User(name=name) # (2)!
    user.email = email
    user.save() # (3)!
    return user
```

1.  Function accepts name and email parameters
2.  Create a new User instance
3.  Persist to database

## Multiple Languages

=== "Python"

    ```python
    def greet(name):
        return f"Hello, {name}!"
    ```

=== "JavaScript"

    ```javascript
    function greet(name) {
        return `Hello, ${name}!`;
    }
    ```

=== "Go"

    ```go
    func greet(name string) string {
        return fmt.Sprintf("Hello, %s!", name)
    }
    ```

=== "Rust"

    ```rust
    fn greet(name: &str) -> String {
        format!("Hello, {}!", name)
    }
    ```

## Inline Code

Use `inline code` for short snippets like `variable_name` or `function()`.

Reference keyboard shortcuts like ++ctrl+c++ and ++ctrl+v++.

## Code with Title

```python title="utils/helpers.py"
def format_date(date):
    """Format date for display."""
    return date.strftime("%Y-%m-%d")
```

## Diff Highlighting

```diff
- old_function()
+ new_function()

  unchanged_line()
```

## Shell Commands

```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python main.py --config config.yaml
```

## JSON Configuration

```json
{
  "name": "my-project",
  "version": "1.0.0",
  "dependencies": {
    "mkdocs": "^1.5.0",
    "mkdocs-material": "^9.0.0"
  }
}
```

## YAML Configuration

```yaml
site_name: My Documentation
theme:
  name: material
  features:
    - content.code.copy
    - content.code.annotate
```
