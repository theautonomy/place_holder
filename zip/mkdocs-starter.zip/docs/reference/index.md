# Reference

Comprehensive reference documentation for all features and components.

## Documentation Features

This reference section covers everything you need to create rich documentation:

<div class="grid cards" markdown>

-   :material-chart-box:{ .lg .middle } __Diagrams__

    ---

    Create flowcharts, sequence diagrams, and more with Mermaid

    [:octicons-arrow-right-24: Diagrams](diagrams.md)

-   :material-brain:{ .lg .middle } __AI Architecture__

    ---

    Visual explanations of RAG and MCP patterns

    [:octicons-arrow-right-24: AI Architecture](ai-architecture.md)

-   :material-code-braces:{ .lg .middle } __Code Blocks__

    ---

    Syntax highlighting, line numbers, and annotations

    [:octicons-arrow-right-24: Code Blocks](code-blocks.md)

-   :material-alert:{ .lg .middle } __Admonitions__

    ---

    Notes, warnings, tips, and custom callouts

    [:octicons-arrow-right-24: Admonitions](admonitions.md)

</div>

## Quick Reference

| Feature | Extension | Description |
|---------|-----------|-------------|
| Diagrams | `pymdownx.superfences` | Mermaid diagram support |
| Code Blocks | `pymdownx.highlight` | Syntax highlighting |
| Admonitions | `admonition` | Callout boxes |
| Tabs | `pymdownx.tabbed` | Tabbed content |
| Tasks | `pymdownx.tasklist` | Checkboxes |
| Emoji | `pymdownx.emoji` | Emoji support |
