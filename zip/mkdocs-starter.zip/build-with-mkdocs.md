## Build and deploy to gh page 
* See gh-pages.yml

## Build and deploy locally

### Using docker
* docker build -t mkdocs-test .
* docker run -p 9000:9000 mkdocs-test

### Using command line
* python -m pip install -r requirements.txt 
* python -m mkdocs build
* python -m mkdocs serve