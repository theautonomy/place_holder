# About

This is the about page for the Test Notebook documentation.

## Project Description

This MkDocs project serves as a starter template with the Material theme and useful extensions.

## Features

- Material theme for modern design
- Task list support with custom checkboxes
- Definition list support
- Clean navigation structure

## Configuration

The project uses the following markdown extensions:

def_list
:   Adds support for definition lists

pymdownx.tasklist
:   Provides enhanced task list functionality with custom and clickable checkboxes