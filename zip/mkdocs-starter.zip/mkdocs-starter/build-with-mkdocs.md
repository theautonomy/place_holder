## Using docker
* docker build -t gitbook-test .
* docker run -p 9000:9000 gitbook-test

## Command line
* python -m pip install -r requirements.txt 
* python -m mkdocs build
* python -m mkdocs serve