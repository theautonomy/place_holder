<!--
  Step — one numbered row inside <Steps>: number, description, an optional
  owner badge, and a representative command/shortcut chip.
  Usage: <Step num="1" cmd="git checkout -b feature-x" owner="You">Branch first — a clean escape hatch for fearless changes.</Step>
  If cmd needs a literal double quote, escape it as &quot; (it's a plain attribute).
-->
<script setup>
defineProps({
  num: { type: [String, Number], required: true },
  cmd: { type: String, required: true },
  owner: { type: String, default: '' },
})
</script>

<template>
  <div class="em-step-row">
    <div class="em-step-num">{{ num }}</div>
    <div class="em-step-desc"><slot /></div>
    <div class="em-step-owner" :class="owner && `em-step-owner--${owner.toLowerCase()}`">{{ owner }}</div>
    <div class="em-step-cmd">{{ cmd }}</div>
  </div>
</template>
