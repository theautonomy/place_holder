<template>
  <template v-if="$slidev.configs.globalFooter !== false">
    <div class="absolute bottom-4 left-6 text-sm opacity-50 italic">
      {{ $slidev.configs.author }} · {{ $slidev.configs.title }}
    </div>
    <div class="absolute bottom-4 right-6 text-sm opacity-50 font-mono italic">
      <SlideCurrentNo /> / <SlidesTotal />
    </div>
  </template>
</template>
