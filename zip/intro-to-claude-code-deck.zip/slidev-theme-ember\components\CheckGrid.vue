<!-- CheckGrid — two-column checklist wrapper (.em-checklist-grid) for <CheckItem>s. -->
<template>
  <div class="em-checklist-grid">
    <slot />
  </div>
</template>
