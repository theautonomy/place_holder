---
theme: ./slidev-theme-ember
title: 'Intro to Claude Code'
favicon: /favicon-intro.svg
info: |
  A guided walkthrough of Claude Code: what it is, how to set it up, the
  day-to-day commands, how to drive it well, power-user habits, and the
  practices that outlast the tool.
author: Wei Li
transition: fade
mdc: false
pageNav: false
layout: cover
subtitle: Background . Foundations . Day to Day . Get Farther . Power User . Advanced Features . Beyond
---

# Intro to Claude Code

---
layout: default
heading: Background
subtitle: Why we're evaluating Claude Code
---

<Callout icon="target">Placeholder — the motivation/context for this evaluation goes here (e.g. what prompted it, what we're comparing against, what decision this feeds).</Callout>

<Tip>TBD — content to be added before this deck ships.</Tip>

---
layout: section
icon: key
subtitle: Access, surfaces, models, and cost
---

# Foundations

---
layout: default
heading: What Claude Code Is
subtitle: An agentic system, not a chat interface
---

<CardGrid cols="4">
<Card icon="target" title="Agentic, not chat">Not a chat interface with programming knowledge — a system that acts on your codebase directly.</Card>
<Card icon="code" title="Reads, executes, modifies">Reads your codebase, executes commands, modifies files, and manages git workflows.</Card>
<Card icon="globe" title="Connects out via MCP">Reaches external services — databases, APIs, internal tools — through the Model Context Protocol.</Card>
<Card icon="users" title="Delegates to subagents">Hands complex tasks off to specialized subagents, each scoped to its own context.</Card>
</CardGrid>

<Tip>Everything flows through the CLI — it integrates into how developers actually work, not a separate window to context-switch into.</Tip>

---
layout: default
heading: Set Up
subtitle: Three things, in order
---

<Rows>
<IconRow icon="key" title="Install">Enterprise subscription, through AWS — follow the internal wiki for auth and environment variables. Don't hand-roll it.</IconRow>
<IconRow icon="checkcircle" title="Verify">Run claude doctor to confirm the environment is clean before you rely on it mid-task.</IconRow>
<IconRow icon="terminal" title="Launch">cd into a repo, run claude — you're in.</IconRow>
</Rows>

---
layout: default
heading: Interface
subtitle: Four ways in, one engine
---

<CardGrid cols="4">
<Card icon="terminal" title="CLI">The primary surface. Scriptable, fast, no context switch.</Card>
<Card icon="code" title="Extensions">VS Code, IntelliJ IDEA / JetBrains — same engine, plus inline diffs and editor file context.</Card>
<Card icon="monitor" title="Claude desktop">Claude Code in a window, if you'd rather be out of the terminal.</Card>
<Card icon="globe" title="claude.ai">Same login — good for planning and throwaway questions, not repo work.</Card>
</CardGrid>

<Rows style="margin-top:16px">
<IconRow icon="cpu" title="Same engine underneath">CLI, Extensions, Claude desktop, and claude.ai all run the identical Claude Code engine. The surface changes; the behavior doesn't.</IconRow>
</Rows>

<Rows style="margin-top:16px">
<IconRow icon="zap" title="Remote Control connects them">claude --rc, or /remote-control mid-session — your phone or browser attaches to and drives a running CLI session. It still runs locally; the other surface is just a window into it.</IconRow>
</Rows>

<Tip>By default, each surface has its own session — Remote Control is the exception.</Tip>

---
layout: default
heading: Extension
subtitle: Claude Code goes where the work already is
---

<CardGrid cols="3">
<Card icon="gitbranch" title="GitHub App">Install via /install-github-app. Tag @claude in an issue, PR, or review comment — or run it fully automated on push/schedule, no mention needed.</Card>
<Card icon="messagesquare" title="Slack app">Invoke Claude Code directly in channels and threads — bring it to where the conversation already is.</Card>
<Card icon="globe" title="Chrome extension">Page-aware assistance right in the browser.</Card>
</CardGrid>

<Tip>Local surfaces (CLI, IDE, Desktop) share your settings and CLAUDE.md. Web and integration surfaces only inherit what's committed to the repo.</Tip>

---
layout: default
heading: Models
subtitle: Pick the right one for the job
---

<CardGrid cols="3">
<Card icon="cpu" title="Opus">Hardest reasoning: gnarly refactors, architecture, subtle bugs.</Card>
<Card icon="activity" title="Sonnet">The default workhorse — fast enough, strong enough for most work.</Card>
<Card icon="zap" title="Haiku">Cheap and quick: mechanical edits, search, bulk changes.</Card>
</CardGrid>

<Tip>Switch anytime with /model. Start on Sonnet — reach for Opus when Sonnet stalls twice on the same problem, not before. Sub-agents can run a cheaper model for grunt work.</Tip>

---
layout: default
heading: Pricing
subtitle: Tokens in, tokens out
---

<Rows>
<IconRow icon="dollarsign" title="Billed per token">Both in and out — output tokens cost several times more than input tokens.</IconRow>
<IconRow icon="search" title="Watch it live" href="https://www.llm-prices.com/">/usage</IconRow>
</Rows>

<Tip>Spend input to save output — a paragraph of precise context is cheap; three wrong 200-line drafts are not.</Tip>

---
layout: section
icon: play
subtitle: Launch it, steer it, get help — the daily loop
---

# Using Claude Code Day to Day

---
layout: default
heading: Launching & Resuming Sessions
subtitle: Four ways to start, two ways to pick back up
---

<CardGrid cols="4">
<Card icon="terminal" title="claude">The front door — launches an interactive session in the current directory.</Card>
<Card icon="play" title="claude &quot;your prompt&quot;">Starts already primed with a task — no empty prompt to fill.</Card>
<Card icon="zap" title="claude -p &quot;prompt&quot;">Print mode: non-interactive, scriptable output — built for CI and shell one-liners.</Card>
<Card icon="search" title="claude -c / claude -r">Resume the latest session, or pick from past ones.</Card>
</CardGrid>

<Tip>Piping in: git diff | claude -p "write a commit message" — print mode is the one people sleep on.</Tip>

---
layout: default
heading: A Workflow
subtitle: One task, start to finish
---

<Steps>
<Step num="1" cmd="&quot;add a login page&quot;">Prompt — describe the outcome you want.</Step>
<Step num="2" cmd="(reads, edits, runs)">Wait for changes — let it work through the task without interrupting.</Step>
<Step num="3" cmd="Esc, then redirect">Adjust the prompt if the result isn't right.</Step>
<Step num="4" cmd="&quot;now add tests too&quot;">More prompts — keep going, one instruction at a time.</Step>
</Steps>

<Tip>That loop, over and over, is most of the job — everything else in this deck is about making each pass better.</Tip>

---
layout: default
heading: Steering
subtitle: Stay in control while it works
---

<Rows>
<IconRow icon="zap" title="Esc to interrupt">Stop it mid-response the moment it drifts off track, and redirect.</IconRow>
<IconRow icon="sliders" title="Shift+Tab to cycle modes">Default → Accept Edits → Plan → Default. Auto Mode slots in after Plan if enabled — the modern, recommended replacement for --dangerously-skip-permissions.</IconRow>
<IconRow icon="filetext" title="/clear and /compact">/clear wipes context and starts fresh; /compact summarizes it to free up room without losing the gist.</IconRow>
<IconRow icon="checksquare" title="/review, /code-review, /security-review">/review is the quick pass; /code-review [level] goes deeper (low/medium → high/max → ultra); /security-review is a dedicated check before anything touching auth or external input.</IconRow>
<IconRow icon="gitcommit" title="/rewind and /diff">/rewind rolls back code and conversation to a checkpoint; /diff opens an interactive viewer for uncommitted changes — a real undo, not just editing forward from a bad state.</IconRow>
</Rows>

<Tip>AskUserQuestion isn't a command you type — Claude pauses and hands you a structured choice when only you can decide.</Tip>

---
layout: default
heading: Housekeeping
subtitle: Keep the session healthy — status, memory, spend (settings live in Configuration, later)
---

<Rows>
<IconRow icon="filetext" title="/init and /memory">Create or edit CLAUDE.md — your project's always-on memory.</IconRow>
<IconRow icon="dollarsign" title="/usage">Watch spend before it surprises you.</IconRow>
<IconRow icon="terminal" title="claude update">Shell-level update of the CLI install itself.</IconRow>
<IconRow icon="checkcircle" title="claude doctor">Diagnoses a broken setup before you waste a session debugging it.</IconRow>
<IconRow icon="search" title="/status">One-glance readout inside a session: account, active model, API connectivity, and version — check it before assuming something's broken.</IconRow>
</Rows>

<Tip>Run claude doctor first whenever something feels off — half of "Claude Code is broken" turns out to be environment drift.</Tip>

---
layout: default
heading: Get Help
subtitle: Three ways to find your footing
---

<Rows>
<IconRow icon="helpcircle" title="/help">Lists every command, live and version-accurate — the fastest way to answer "wait, is there a command for that?"</IconRow>
<IconRow icon="zap" title="/powerup">An interactive, animated feature-discovery panel for self-paced onboarding — browse lessons at your own speed instead of a lecture.</IconRow>
<IconRow icon="messagesquare" title="Or just ask">Simply ask what you want to know about Claude Code in a prompt — it can answer questions about itself too.</IconRow>
</Rows>

<Tip>Reach for /help first — it's always current; a slide might not be.</Tip>

---
layout: section
icon: target
subtitle: Tools, habits, context, and prompts
---

# Get Farther

---
layout: default
heading: Configuration
subtitle: Connect tools, tune settings, from the CLI or a session
---

<CardGrid cols="5">
<Card icon="globe" title="claude mcp add">Connect an MCP server — stdio, SSE, or HTTP — scoped to user, project, or local.</Card>
<Card icon="search" title="/mcp">List and manage connected servers mid-session; toggle tools on or off without editing files.</Card>
<Card icon="sliders" title="/config">Interactive settings editor — permissions, model, and more, no raw JSON required.</Card>
<Card icon="edit3" title="Output styles">Default, Explanatory, Learning, or your own — tune how responses are formatted.</Card>
<Card icon="terminal" title="claude config">Shell-level get / set / list for the same settings — scriptable for setup automation.</Card>
</CardGrid>

<Tip>Most configuration has both a slash command for inside a session and a CLI flag for outside one — reach for whichever you're already in.</Tip>

---
layout: default
heading: Be Productive
subtitle: Slash commands, shortcuts, one glance at the status bar
---

<Rows>
<IconRow icon="messagesquare" title="Slash commands, recap">/plan, /clear, /compact, /model, /review, /rewind, /help — the ones you'll reach for hourly.</IconRow>
<IconRow icon="zap" title="Keyboard shortcuts">Shift+Tab cycles modes, Esc stops mid-response, Ctrl+R searches history, Ctrl+T toggles the task checklist.</IconRow>
<IconRow icon="sliders" title="/statusline">Configure the persistent status bar: git branch, status, working directory, custom shell output — state at a glance instead of git status on repeat.</IconRow>
<IconRow icon="filetext" title="/copy [N] and /export">/copy grabs the latest response (or the Nth-latest, or just one code block) straight to your clipboard; /export saves the full transcript as plain text to archive or hand off.</IconRow>
</Rows>

<Tip>More: Ctrl+G opens your prompt in an editor, Alt+P swaps models instantly, Ctrl+V pastes an image straight in.</Tip>

---
layout: default
heading: Editor & Shell Superpowers
subtitle: Three habits that make the prompt line do more
---

<Rows>
<IconRow icon="filetext" title="@ — refer to a file">Type @ to open a file picker; @report.md summarize this attaches it directly, no copy-paste.</IconRow>
<IconRow icon="terminal" title="! — run a command">Prefix a line with ! to run a shell command inline without leaving the session.</IconRow>
<IconRow icon="edit3" title="Vim editor mode">Full modal editing in the prompt box for anyone who thinks in hjkl — toggle it in /config.</IconRow>
</Rows>

---
layout: default
heading: Mind the Context
subtitle: Better input, better output
---

<Callout icon="target"><b>Context window</b> — working memory for one session. Everything sent and returned lives in it until it's cleared or compacted.</Callout>

<Tip>Prune MCP servers: every connected server injects its tool definitions at startup — a dozen idle ones tax every single turn. /mcp to trim what's not in use.</Tip>

---
layout: default
heading: The Context Window Accumulates
subtitle: Every prompt includes everything before it
---

```text
PROMPT 1                           PROMPT 2  (+ new turn)                       PROMPT 3  (+ another new turn)
+------------------------------+   +------------------------------+             +------------------------------+
| SYSTEM PROMPT                |   | SYSTEM PROMPT                |             | SYSTEM PROMPT                |
|  CLAUDE.md, memory, tools    |   |  CLAUDE.md, memory, tools    |             |  CLAUDE.md, memory, tools    |
|                              |   |                              |             |                              |
| CONVERSATION HISTORY         |   | CONVERSATION HISTORY         |             | CONVERSATION HISTORY         |
|  [user] add a login page     |   |  [user] add a login page     |  <- kept    |  [user] add a login page     |  <- kept
|  [asst] created Login.vue    |   |  [asst] created Login.vue    |  <- kept    |  [asst] created Login.vue    |  <- kept
|                              |   |                              |             |                              |
|                              |   |  [user] now add validation   |  <- new     |  [user] now add validation   |  <- kept
|                              |   |  [asst] added checks ...     |  <- new     |  [asst] added checks ...     |  <- kept
|                              |   |                              |             |                              |
|                              |   |                              |             |  [user] now add tests        |  <- new
|                              |   |                              |             |  [asst] added Login.spec     |  <- new
+------------------------------+   +------------------------------+             +------------------------------+
```

<Tip>Nothing is re-sent by you — the harness resends the whole growing transcript every turn. That's why the window fills up even if each message you type is short.</Tip>

---
layout: default
heading: Compaction Bounds It
subtitle: Older turns collapse into a summary so the session keeps going
---

```text
PROMPT 3                             PROMPT 4  (after compaction)
+------------------------------+     +------------------------------+
| SYSTEM PROMPT                |     | SYSTEM PROMPT                |
|  CLAUDE.md, memory, tools    |     |  CLAUDE.md, memory, tools    |
|                              |     |                              |
| CONVERSATION HISTORY         |     | CONVERSATION HISTORY         |
|  [user] add a login page     |     |  [SUMMARY] login page,       |  <- was 3 turns,
|  [asst] created Login.vue    |     |   validation, and tests      |     now 1 summary
|                              |     |   all added                  |
|  [user] now add validation   |     |                              |
|  [asst] added checks ...     |     |  [user] now add logout       |  <- new
|                              |     |  [asst] added logout         |  <- new
|  [user] now add tests        |     |   handler ...                |
|  [asst] added Login.spec     |     |                              |
+------------------------------+     +------------------------------+
```

<Tip>You never trigger this yourself — it happens automatically as the window approaches its limit (or manually via /compact). CLAUDE.md and memory files are re-read fresh, so the durable facts survive even though the fine detail of old turns doesn't.</Tip>

---
layout: default
heading: /clear Wipes It Instead
subtitle: A full reset, not a summary — but the durable layer still reloads
---

```text
PROMPT 3                             /clear
+------------------------------+     +------------------------------+
| SYSTEM PROMPT                |     | SYSTEM PROMPT                |  <- kept (reloaded)
|  CLAUDE.md, memory, tools    |     |  CLAUDE.md, memory, tools    |
|                              |     |                              |
| CONVERSATION HISTORY         |     | CONVERSATION HISTORY         |
|  [user] add a login page     |     |  (empty)                     |  <- wiped
|  [asst] created Login.vue    |     |                              |
|                              |     |                              |
|  [user] now add validation   |     |                              |
|  [asst] added checks ...     |     |                              |
|                              |     |                              |
|  [user] now add tests        |     |                              |
|  [asst] added Login.spec     |     |                              |
+------------------------------+     +------------------------------+
```

<Tip>Unlike compaction, nothing is summarized — the whole conversation is gone. Use it when the task is genuinely done and old context would only confuse the next one; use /compact when you want to keep going.</Tip>

---
layout: default
heading: Effective Prompting
subtitle: Five habits, every time
---

<CardGrid cols="5">
<Card icon="target" title="Start general, get specific">Open with the goal, then narrow — name what you mean instead of "this" or "that." "Add caching" → "add a 5-minute in-memory cache to getRates(), no new dependencies, keep the signature."</Card>
<Card icon="checksquare" title="Break it down">Sequence a complex ask into smaller steps instead of one giant prompt — each step is easier to check and correct before the next one builds on it.</Card>
<Card icon="filetext" title="Provide context">Dependencies allowed, patterns to follow, what not to touch — name the stack and versions too ("Spring Boot 3.3, Java 21, Gradle, JUnit 5") to kill a dozen wrong assumptions.</Card>
<Card icon="code" title="Include examples, don't paste">Point at an existing file rather than pasting it in — same pattern, and it doesn't sit in context for the rest of the session.</Card>
<Card icon="edit3" title="Iterate, don't restart">The first response is a draft — correct it.</Card>
</CardGrid>

<Quote>It behaves like a fast junior engineer: vague brief → plausible-looking wrong answer. Concrete brief → useful first draft.</Quote>

<p class="em-micro" style="margin-top:6px;">Adapted from GitHub's Copilot prompt-engineering guide: docs.github.com/en/copilot/concepts/prompting/prompt-engineering</p>

---
layout: default
heading: Agentic Workflow
subtitle: You drive, not the model
---

<Steps>
<Step num="1" cmd="/plan" owner="Claude">Plan — it asks me questions, then writes the plan down.</Step>
<Step num="2" cmd="approve" owner="You">Review the plan and approve it before anything changes.</Step>
<Step num="3" cmd="implement" owner="Claude">Make the change.</Step>
<Step num="4" cmd="test" owner="Claude">Verify it.</Step>
<Step num="5" cmd="review" owner="You">Check the diff.</Step>
<Step num="6" cmd="commit" owner="You">Checkpoint it.</Step>
<Step num="7" cmd="/compact or /clear" owner="You">Trim the context.</Step>
</Steps>

<Tip>Repeat steps 3–7 for each piece of work — that loop, over and over, is most of the job.</Tip>

---
layout: default
heading: Review & Security Commands
subtitle: Make "review everything" a repeatable command, not a vibe
---

<Rows>
<IconRow icon="checksquare" title="/code-review">Reviews the current diff — or a PR#, branch, or path — for correctness bugs and simplification/efficiency cleanups, at a chosen effort level. --fix applies the findings; --comment posts them inline on the PR.</IconRow>
<IconRow icon="shield" title="/security-review">A focused security pass over the pending changes on the current branch — the automated check to run before anything ships.</IconRow>
<IconRow icon="users" title="ultra mode">/code-review ultra runs a deeper, multi-agent review in the cloud, on the local branch or a PR# — slower and billed, reach for it on higher-stakes changes.</IconRow>
</Rows>

<Tip>Run both before opening a PR, not just when something feels risky — cheap insurance against "review everything" slipping under deadline pressure.</Tip>

---
layout: section
icon: sliders
subtitle: CLAUDE.md, Rules, Skills, Hooks, and Agents
---

# Become a Power User

---
layout: default
heading: Understand settings.json
subtitle: What actually lives in settings.json
---

<CardGrid cols="4">
<Card icon="shield" title="Permissions">allow / deny / ask rules for tools — lock down Bash commands or file globs, or require confirmation.</Card>
<Card icon="key" title="Environment variables">The env block injects vars into every session — API keys, feature flags, proxy settings.</Card>
<Card icon="zap" title="Hooks wiring">hooks.&lt;Event&gt; registers the lifecycle scripts — the wiring lives here, the script itself lives in .claude/hooks/.</Card>
<Card icon="sliders" title="Everything else">Default model, statusLine command, permission mode, MCP server list — one file, one source of truth.</Card>
</CardGrid>

<Tip>Loaded at startup only — change it, then restart or re-approve in /hooks or /config for the new rules to take effect.</Tip>

---
layout: default
heading: Customization
subtitle: Two layers, both file-based, checked into the repo
---

<Callout icon="filetext"><code>CLAUDE.md</code> at the repo root — always-on project memory. Conventions, build commands, gotchas. Where 90% of people should start.</Callout>

| Thing | Lives in | Triggered by |
|---|---|---|
| **Rule** | `CLAUDE.md` | always loaded — "always know this" |
| **Command** | `.claude/commands/x.md` | /x — you control when |
| **Skill** | `.claude/skills/x/SKILL.md` | /x, or when the task matches — "when this comes up" |
| **Hook** | `.claude/settings.json + script` | the harness, on an event — "no matter what" |
| **Agent** | `.claude/agents/x.md` | delegated, or you name it — "go do this elsewhere" |

---
layout: default
heading: Project Files
subtitle: Where each piece actually lives on disk
---

```text
your-repo/
├── .claude/
│   ├── commands/               your custom slash commands
│   ├── agents/                 subagent configs (YAML)
│   ├── skills/                 SKILL.md folders
│   ├── hooks/                  lifecycle shell scripts
│   ├── rules/                  topic-scoped CLAUDE.md-style files
│   ├── settings.json           project settings
│   └── settings.local.json     your overrides (gitignored)
└── CLAUDE.md                   project memory (root of repo)
```

<Callout icon="globe">Same layout at <b>project level</b> (repo root, shown above) or <b>user level</b> (<code>~/.claude/</code>, <code>~/.claude/CLAUDE.md</code>) — user level applies across every project; project level wins when both define the same thing.</Callout>

<Tip>All plain text, checked into git — except settings.local.json, which is gitignored on purpose so personal overrides don't leak into the shared config.</Tip>

---
layout: default
heading: CLAUDE.md
subtitle: What goes in, what doesn't
---

<CardGrid cols="3">
<Card icon="terminal" title="Build & run commands">The commands you'd tell a new hire on day one: build, test, lint, run.</Card>
<Card icon="edit3" title="Coding conventions">Style rules, naming, patterns — whatever isn't obvious from the code itself.</Card>
<Card icon="target" title="Architecture notes">The shape of the system: how the pieces fit together, where the boundaries are.</Card>
</CardGrid>

<Quote>It's not a project knowledge wiki. Every word costs context on every single turn — keep it short, stable, and universal. Anything long or conditional belongs in a skill instead.</Quote>

---
layout: default
heading: Rules
subtitle: Split CLAUDE.md by topic, scope it by file path
---

<CardGrid cols="3">
<Card icon="filetext" title=".claude/rules/*.md">One topic per file — testing.md, security.md, api-design.md — instead of one growing CLAUDE.md.</Card>
<Card icon="target" title="paths: frontmatter">Add a paths glob and the rule loads only when Claude opens a matching file, not every turn.</Card>
<Card icon="users" title="Share via symlink">~/.claude/rules/ applies to every project on your machine; symlink a shared folder in to reuse team rules.</Card>
</CardGrid>

```yaml
# .claude/rules/api-design.md
---
paths:
  - "src/api/**/*.ts"
---
All API endpoints must include input validation.
```

<Tip>Rules without paths: load unconditionally, same priority as CLAUDE.md. Reach for this once a project's CLAUDE.md is pushing past ~200 lines.</Tip>

---
layout: default
heading: Skill
subtitle: When this kind of task comes up, follow this recipe
---

<CardGrid cols="3">
<Card icon="target" title="Claude decides when">Reads the description in the frontmatter; when your request matches, it loads SKILL.md into the conversation. Only name + description sit in context until then.</Card>
<Card icon="terminal" title="Or call it explicitly">Type /skill-name, or just say "use the X skill" — same mechanism as a command.</Card>
<Card icon="checksquare" title="Tune the trigger">Write concrete trigger phrases into the description to improve auto-loading; add disable-model-invocation: true to make it slash-only.</Card>
</CardGrid>

<Tip>Hot-reloads — no restart needed. Good for detailed, occasional procedures you don't want costing context every turn.</Tip>

---
layout: default
heading: Hook
subtitle: No matter what, run this when X happens
---

<CardGrid cols="3">
<Card icon="zap" title="Deterministic, not a prompt">The harness runs it on a lifecycle event — PreToolUse, PostToolUse, Stop, SessionStart, and others. Can't be talked out of it.</Card>
<Card icon="filetext" title="Wired in settings.json">hooks.&lt;Event&gt; as a matcher plus a command to run. Loaded at startup only — restart, or re-approve in /hooks, after a change.</Card>
<Card icon="shield" title="Exit status is the API">0 = ok; 2 surfaces stderr to Claude and, for PreToolUse, blocks the call outright.</Card>
</CardGrid>

<Quote>Use a hook when a step must be deterministic and cannot be trusted to the model.</Quote>

---
layout: default
heading: Agent
subtitle: An agent is a file
---

<CardGrid cols="4">
<Card icon="filetext" title="Its own prompt">.claude/agents/&lt;name&gt;.md — you decide exactly how it behaves.</Card>
<Card icon="shield" title="Only these tools">Scope it down — read-only for a reviewer, for example.</Card>
<Card icon="dollarsign" title="A cheaper model">Haiku for mechanical work; spend Opus only where it's earned.</Card>
<Card icon="target" title="Its own context window">The whole reason to use one — it reads 40 files, you get back a paragraph.</Card>
</CardGrid>

<Tip>The whole file: name, description, tools, model, then a short system prompt. That's it. "Go do this elsewhere" — delegated, or you name it.</Tip>

---
layout: default
heading: When to Use What
subtitle: Six mechanisms, one decision guide
---

| Thing | Triggered by | Use it for |
|---|---|---|
| **Rule** | always loaded | Whole-project facts: build commands, conventions |
| **Path-scoped rule** | loaded when a matching file is read | Same, but only relevant to part of the codebase |
| **Command** | you type /name | A saved prompt template you run on demand |
| **Skill** | Claude decides, from the description | A detailed procedure for an occasional task |
| **Hook** | the harness, on a lifecycle event | Deterministic — can't be talked out of it |
| **Agent** | delegated, or you name it | A sub-task with its own context and tool allowlist |

<Tip>Cheapest to reason about at the top, most isolated at the bottom — reach for the simplest one that fits before building something heavier.</Tip>

---
layout: section
icon: activity
subtitle: One session to many — watching to delegating
---

# Advanced Features

---
layout: default
heading: Three Layers
subtitle: Where the work actually happens
---

```text
┌─────────────────────────────────────────────────────────┐
│                    CLAUDE CODE LAYERS                   │
├─────────────────────────────────────────────────────────┤
│  CORE LAYER                                             │
│  ┌─────────────────────────────────────────────────┐    │
│  │         Main Conversation Context               │    │
│  │   Tools: Read, Edit, Bash, Glob, Grep, etc.     │    │
│  └─────────────────────────────────────────────────┘    │
│  Your primary interaction; limited context; costs money │
├─────────────────────────────────────────────────────────┤
│  DELEGATION LAYER                                       │
│  ┌─────────────────────────────────────────────────┐    │
│  │           Subagents (20 concurrent default)     │    │
│  │   Explore | Plan | General-purpose | Custom     │    │
│  └─────────────────────────────────────────────────┘    │
│  Isolated contexts for focused work, returns summaries  │
├─────────────────────────────────────────────────────────┤
│  EXTENSION LAYER                                        │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │
│  │   MCP   │  │  Hooks  │  │ Skills  │  │ Plugins │     │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │
│  External tools, automation, and packaged extensions    │
└─────────────────────────────────────────────────────────┘
```

<Quote>Most people stay in Core. Power users push work out to Delegation and Extension.</Quote>

---
layout: default
heading: Beyond One Agent
subtitle: Parallel teams and autonomous runs
---

<CardGrid cols="3">
<Card icon="users" title="Agent Teams">Several subagents work a shared task list in parallel — best for orthogonal work (tests, security, docs) in one pass. Research preview: CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1.</Card>
<Card icon="target" title="/goal">A termination condition instead of a task — keep going, turn after turn, until it's true.</Card>
<Card icon="filetext" title="Spec-driven (the alternative)">Decisions written down first; the agent builds to a full spec. Don't reach for /goal when the task still needs those decisions made.</Card>
</CardGrid>

<Tip>Different from Dynamic Workflows: a lead agent improvises coordination in Agent Teams, vs. deterministic script-driven fan-out to tens or hundreds of agents there.</Tip>

---
layout: default
heading: Running Unattended
subtitle: Four tiers, from a one-off script to a standing cloud job
---

<CardGrid cols="4">
<Card icon="terminal" title="claude -p">Print mode — non-interactive, scriptable, exits with a real code. Built for CI and shell pipelines.</Card>
<Card icon="zap" title="/background (/bg)">Detaches the current session to keep working elsewhere; /tasks and /list-agents (/peers) show what's running.</Card>
<Card icon="activity" title="/schedule">A cron-like recurring agent — each run clones the repo fresh in the cloud, no laptop required.</Card>
<Card icon="globe" title="api / webhook">Fire a run from CI, or trigger on a GitHub event — a new issue, a failed check, a release tag.</Card>
</CardGrid>

<Tip>Escalating tiers: -p for a one-shot script, /background for a session you still have open, /schedule for everything that runs unattended long-term. Canonical CI pattern: claude -p --output-format json --allowedTools "Read,Edit,Bash" "task".</Tip>

---
layout: section
icon: users
subtitle: Practices that outlast the tool
---

# Beyond Claude Code

---
layout: default
heading: It's Not Just Claude Code
subtitle: The concepts transfer — Copilot, Codex, Cursor, whatever's next
---

<CardGrid cols="4">
<Card icon="filetext" title="Memory files">CLAUDE.md, AGENTS.md, .cursorrules, copilot-instructions.md — same idea, different filename.</Card>
<Card icon="users" title="Agentic loop">Prompt, act, verify, redirect — every agent-based coding tool runs this same cycle underneath.</Card>
<Card icon="globe" title="MCP">The Model Context Protocol is a cross-vendor standard now, not a Claude-only integration.</Card>
<Card icon="shield" title="Engineering discipline">Branch first, commit checkpoints, review everything, test thoroughly — tool-agnostic, always true.</Card>
</CardGrid>

<Tip>This repo's own CLAUDE.md imports AGENTS.md — one set of conventions, read by both tools, written once.</Tip>

---
layout: default
heading: The Real Skill Is the Workflow
subtitle: Repeatable habits outlast any specific tool
---

<CardGrid cols="3">
<Card icon="messagesquare" title="Communicate clearly">Say what you want in plain, specific language — the tool changes, the clarity requirement doesn't.</Card>
<Card icon="edit3" title="Iterate on output">Treat the first response as a draft, everywhere — correct it instead of restarting from scratch.</Card>
<Card icon="target" title="Plan before you act">Decide the approach before changes land, whether that's Plan Mode or another tool's equivalent.</Card>
<Card icon="filetext" title="Prompting strategy">Specific over vague, context over assumption, examples over pasted text — the technique is the skill, not the syntax.</Card>
<Card icon="cpu" title="Manage context">Every agent has a window that fills up — know when to prune, summarize, or start fresh.</Card>
<Card icon="checksquare" title="Document as you go">Capture decisions in memory files, commit messages, and docs — so the next session, or the next tool, doesn't start from zero.</Card>
</CardGrid>

<Quote>Master the workflow and the specific agent becomes an implementation detail — swap tools without relearning how to work.</Quote>

---
layout: default
heading: Other Thoughts
subtitle: On owning what you ship
---

<Rows>
<IconRow icon="users" title="Comprehension is on you">Don't commit a change you can't explain or understand. Accepting code you don't follow is a loan against future you.</IconRow>
<IconRow icon="shield" title="The kernel's position">After months of debate: yes to AI as an assistant (Copilot), no to unreviewed "AI slop" — and the human takes the fall for mistakes.</IconRow>
<IconRow icon="alerttriangle" title="Comprehension debt">The hidden cost of AI-generated code: every bug, review, and change on code nobody understands costs interest.</IconRow>
</Rows>

<p class="em-micro" style="margin-top:6px;">Comprehension Debt — oreilly.com/radar &nbsp;&middot;&nbsp; Linux lays down the law on AI-generated code — tomshardware.com</p>
