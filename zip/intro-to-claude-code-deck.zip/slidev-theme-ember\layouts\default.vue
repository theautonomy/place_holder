<!--
  layout: default
  ───────────────
  The workhorse content slide. Frontmatter:
    heading  : big serif terracotta heading (plain text — NOT `title`,
               which Slidev reserves for the per-page outline/head title
               and won't forward to the layout as a prop)
    subtitle : muted line under it
  Body = whatever content blocks you need (`.em-rows`, `.em-card-grid`,
  `.em-split`, `.em-steps`, `.em-checklist-grid`, a `.em-table`, a
  `.em-callout`) followed optionally by a single `.em-tip` or `.em-quote` —
  its `margin-top: auto` pins it to the bottom of the slide, exactly as in
  the source deck. Don't wrap these in extra containers; they must be
  direct children so the flex column sizing works.
-->
<script setup>
defineOptions({ inheritAttrs: false })
defineProps({
  heading: { type: String, default: '' },
  subtitle: { type: String, default: '' },
})
</script>

<template>
  <div class="slidev-layout em-slide">
    <EmberIconSprite />
    <div class="em-decor em-decor-tr" /><div class="em-decor em-decor-bl" />
    <h2 v-if="heading" class="em-title">{{ heading }}</h2>
    <p v-if="subtitle" class="em-subtitle">{{ subtitle }}</p>
    <slot />
  </div>
</template>
