<!-- Tip — the italic terracotta footer note (.em-tip), pinned to the slide bottom. -->
<template>
  <div class="em-tip">
    <slot />
  </div>
</template>
