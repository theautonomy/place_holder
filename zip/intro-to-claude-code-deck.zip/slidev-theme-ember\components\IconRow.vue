<!--
  IconRow — one row inside <Rows>. Click-reveals like the source
  em-icon-row markup did (v-click on the root element).
  Usage:
    <IconRow icon="key" title="Install">Body text.</IconRow>
-->
<script setup>
defineProps({
  icon: { type: String, required: true },
  title: { type: String, required: true },
  href: { type: String, default: '' },
})
</script>

<template>
  <div v-click class="em-icon-row">
    <EmberIcon :name="icon" />
    <div class="em-body">
      <h3><a v-if="href" :href="href" target="_blank" rel="noopener">{{ title }}</a><template v-else>{{ title }}</template></h3>
      <p><slot /></p>
    </div>
  </div>
</template>
