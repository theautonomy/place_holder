<!--
  EmberIcon — the terracotta icon-circle badge. Requires <EmberIconSprite/>
  to be present somewhere on the page (each layout includes it once).

  Props:
    name : string  — icon id, e.g. "terminal" (maps to symbol #i-terminal)
    lg   : boolean — the larger 88px variant used on section/closing slides
-->
<script setup>
defineProps({
  name: { type: String, required: true },
  lg: { type: Boolean, default: false },
})
</script>

<template>
  <span class="em-icon-circle" :class="{ lg }">
    <svg><use :href="`#i-${name}`" /></svg>
  </span>
</template>
