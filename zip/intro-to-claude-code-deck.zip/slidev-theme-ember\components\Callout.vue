<!--
  Callout — icon + text banner (.em-callout).
  Usage: <Callout icon="globe">Body text, incl. <code>inline html</code>.</Callout>
-->
<script setup>
defineProps({
  icon: { type: String, required: true },
})
</script>

<template>
  <div class="em-callout">
    <EmberIcon :name="icon" />
    <p><slot /></p>
  </div>
</template>
