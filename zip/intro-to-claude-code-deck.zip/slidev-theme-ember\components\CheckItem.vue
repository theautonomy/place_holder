<!--
  CheckItem — one row inside <CheckGrid>. Click-reveals like the source
  em-check-item markup did (v-click on the root element).
  Usage: <CheckItem icon="checkcircle">Start from a clean git state</CheckItem>
-->
<script setup>
defineProps({
  icon: { type: String, required: true },
})
</script>

<template>
  <div v-click class="em-check-item">
    <EmberIcon :name="icon" />
    <span><slot /></span>
  </div>
</template>
