<!--
  layout: closing
  ───────────────
  Same shape as `section`, but the subtitle is muted instead of terracotta,
  and there's room below for extra content (a big code chip, footer links)
  plus an absolutely-positioned byline. Frontmatter:
    icon      : icon name for the 88px badge
    subtitle  : muted line under the title
    presenterName : byline name, bottom-left — deliberately does NOT fall
               back to head-matter `author` (that field drives the global
               footer instead; falling back here would duplicate it on
               this slide). Set presenterName explicitly per-slide if a
               closing byline is wanted. NOT `presenter`, which Slidev
               core reserves for the presenter-mode feature flag and
               won't forward to the layout as a prop.
  Body = `# Title`. Anything after the title in the body renders below the
  subtitle (use it for a `.em-code-chip.lg` and `.em-micro` links, as in the
  source deck's closing slide).
-->
<script setup>
defineOptions({ inheritAttrs: false })
const props = defineProps({
  icon: { type: String, default: '' },
  subtitle: { type: String, default: '' },
  presenterName: { type: String, default: '' },
})
</script>

<template>
  <div class="slidev-layout em-slide em-section em-closing">
    <EmberIconSprite />
    <div class="em-decor em-decor-tr" /><div class="em-decor em-decor-bl" />
    <div class="em-section-inner">
      <EmberIcon v-if="icon" :name="icon" lg />
      <slot />
      <p v-if="subtitle" class="em-section-sub" style="margin-bottom:28px;">{{ subtitle }}</p>
      <slot name="foot" />
    </div>
    <p v-if="props.presenterName" class="em-byline em-byline-abs">{{ props.presenterName }}</p>
  </div>
</template>
