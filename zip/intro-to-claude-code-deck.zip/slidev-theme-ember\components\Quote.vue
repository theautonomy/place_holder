<!-- Quote — the serif italic pull-quote footer (.em-quote), pinned to the slide bottom. -->
<template>
  <div class="em-quote">
    <slot />
  </div>
</template>
