<!--
  Rows — wraps a column of <IconRow> components in the .em-rows layout.
  Pass through a plain `style` attr (e.g. style="margin-top:16px") when you
  need a second stacked group on the same slide — it lands on the root div.
-->
<template>
  <div class="em-rows">
    <slot />
  </div>
</template>
