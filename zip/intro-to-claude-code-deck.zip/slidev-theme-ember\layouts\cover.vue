<!--
  layout: cover
  ─────────────
  Frontmatter:
    eyebrow   : small tracked-caps line, e.g. "LIGHTNING TALK · 30 MINUTES"
    subtitle  : paragraph under the title (use <br/> for a manual line break)
    presenterName : byline name — deliberately does NOT fall back to
               head-matter `author` (that field drives the global footer
               instead; falling back here would duplicate it on the cover).
               Set presenterName explicitly per-slide if a cover byline is
               wanted. NOT `presenter`, which Slidev core reserves for the
               presenter-mode feature flag and won't forward to the layout
               as a prop.
  Body = `# Title`
-->
<script setup>
defineOptions({ inheritAttrs: false })
const props = defineProps({
  eyebrow: { type: String, default: '' },
  subtitle: { type: String, default: '' },
  presenterName: { type: String, default: '' },
})
</script>

<template>
  <div class="slidev-layout em-slide em-cover">
    <EmberIconSprite />
    <div class="em-decor em-decor-tr" /><div class="em-decor em-decor-bl" />
    <div class="em-cover-inner">
      <p v-if="eyebrow" class="em-eyebrow" v-html="eyebrow" />
      <slot />
      <p v-if="subtitle" class="em-cover-sub" v-html="subtitle" />
      <p v-if="props.presenterName" class="em-byline">{{ props.presenterName }}</p>
    </div>
  </div>
</template>
