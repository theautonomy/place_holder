<!--
  layout: section
  ───────────────
  Centered divider slide with a large icon badge. Frontmatter:
    icon    : icon name for the 88px badge, e.g. "play"
    subtitle: terracotta line under the title
  Body = `# Title`
-->
<script setup>
defineOptions({ inheritAttrs: false })
defineProps({
  icon: { type: String, default: '' },
  subtitle: { type: String, default: '' },
})
</script>

<template>
  <div class="slidev-layout em-slide em-section">
    <EmberIconSprite />
    <div class="em-decor em-decor-tr" /><div class="em-decor em-decor-bl" />
    <div class="em-section-inner">
      <EmberIcon v-if="icon" :name="icon" lg />
      <slot />
      <p v-if="subtitle" class="em-section-sub">{{ subtitle }}</p>
    </div>
  </div>
</template>
