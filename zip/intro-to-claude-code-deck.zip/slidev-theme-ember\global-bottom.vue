<!--
  Theme-scoped global-bottom layer (ember only — lives at the theme root,
  not the project root, so it doesn't affect other decks).
  Ports the floating pill nav from the source HTML deck 1:1: prev/next
  buttons + a "current / total" counter, centered at the bottom of the
  slide. Uses Slidev's real navigation state instead of the source's
  hand-rolled JS.

  Set `pageNav: false` in a deck's top-level frontmatter to hide it for
  that deck (shown by default).
-->
<script setup>
import { useNav, useSlideContext } from '@slidev/client'

const { next, prev, hasNext, hasPrev, currentPage, total, isPrintMode } = useNav()
const { $slidev } = useSlideContext()
</script>

<template>
  <div v-if="!isPrintMode && $slidev.configs.pageNav !== false" id="em-nav">
    <button
      type="button"
      aria-label="Previous slide"
      :disabled="!hasPrev"
      @pointerdown.stop
      @click.stop="prev"
    >&#8592;</button>
    <span class="em-nav-counter">{{ currentPage }} / {{ total }}</span>
    <button
      type="button"
      aria-label="Next slide"
      :disabled="!hasNext"
      @pointerdown.stop
      @click.stop="next"
    >&#8594;</button>
  </div>
</template>

<style scoped>
#em-nav {
  position: absolute;
  /* slide-content is scale()'d to fit its container, so a plain px offset
     here gets multiplied by that scale too — on most windows the scale is
     >1, which pushed this past the 48px real-pixel gutter and clipped it.
     Dividing by --slidev-slide-scale (set inline by Slidev core) cancels
     that out, keeping this a constant ~46 real px below the card. */
  bottom: calc(-54px / var(--slidev-slide-scale, 1));
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 14px;
  background: rgba(18, 21, 27, 0.72);
  backdrop-filter: blur(6px);
  padding: 6px 14px;
  border-radius: 999px;
  z-index: 10;
  font-family: var(--em-font-sans);
}
#em-nav button {
  background: var(--em-terracotta);
  border: none;
  color: var(--em-bg);
  width: 32px;
  height: 32px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  font-weight: 700;
  padding: 0;
}
#em-nav button:disabled {
  opacity: 0.35;
  cursor: default;
}
@media (hover: hover) {
  #em-nav button:not(:disabled):hover { filter: brightness(1.1); }
}
.em-nav-counter {
  color: var(--em-cream);
  font-size: 12.5px;
  min-width: 52px;
  text-align: center;
}
</style>
