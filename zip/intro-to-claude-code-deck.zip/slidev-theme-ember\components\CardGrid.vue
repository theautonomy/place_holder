<!--
  CardGrid — wraps a row of <Card> components in the .em-card-grid layout.
  Usage:
    <CardGrid cols="3">
      <Card icon="target" title="Be specific">...</Card>
      ...
    </CardGrid>
-->
<script setup>
defineProps({
  cols: { type: [String, Number], default: 4 },
})
</script>

<template>
  <div class="em-card-grid" :style="{ '--cols': cols }">
    <slot />
  </div>
</template>
