<!-- Steps — a vertical numbered-workflow list (.em-steps) for <Step> rows. -->
<template>
  <div class="em-steps">
    <slot />
  </div>
</template>
