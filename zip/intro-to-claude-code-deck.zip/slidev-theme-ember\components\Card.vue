<!--
  Card — one tile inside a <CardGrid>. Click-reveals like the source em-card
  markup did (v-click on the root element).
  Usage:
    <Card icon="target" title="Be specific">Body text, incl. <code>inline html</code>.</Card>
  If the title itself needs a literal double quote, escape it as &quot; since
  title is a plain HTML attribute.
-->
<script setup>
defineProps({
  icon: { type: String, required: true },
  title: { type: String, required: true },
})
</script>

<template>
  <div v-click class="em-card">
    <EmberIcon :name="icon" />
    <h3>{{ title }}</h3>
    <p><slot /></p>
  </div>
</template>
