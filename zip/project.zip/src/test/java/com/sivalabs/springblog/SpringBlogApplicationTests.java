package com.sivalabs.springblog;

import org.junit.jupiter.api.Test;

class SpringBlogApplicationTests extends AbstractIT {

    @Test
    void contextLoads() {}
}
