package com.sivalabs.springblog.domain.models;

public enum PostStatus {
    DRAFT,
    PUBLISHED
}
