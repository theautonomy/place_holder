-- Schema for Spring Data JDBC entities
-- JPA entities are managed by Hibernate DDL auto
-- Column names in uppercase to match Spring Data JDBC's default naming

CREATE TABLE IF NOT EXISTS "category" (
    "ID" BIGINT AUTO_INCREMENT PRIMARY KEY,
    "NAME" VARCHAR(255) NOT NULL,
    "DESCRIPTION" VARCHAR(1000),
    "CREATED" TIMESTAMP,
    "INSERTED" BIGINT
);
