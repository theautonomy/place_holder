package com.example.spring.data.aot;

import java.util.List;

import com.example.spring.data.aot.jdbc.Category;
import com.example.spring.data.aot.jdbc.CategoryProjection;
import com.example.spring.data.aot.jdbc.CategoryRepository;
import com.example.spring.data.aot.jpa.User;
import com.example.spring.data.aot.jpa.UserProjection;
import com.example.spring.data.aot.jpa.UserRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * Spring Data AOT Demo Application.
 *
 * This application demonstrates AOT (Ahead of Time) optimizations for both 
 * Spring Data JPA and Spring Data JDBC.
 *
 * Run with AOT enabled: 
 *   java -Dspring.aot.enabled=true -jar target/aot-0.0.1-SNAPSHOT.jar
 *
 * Note: Spring Boot 4.0+ auto-configures the JDBC Dialect based on the 
 * datasource, so no manual Dialect bean is required.
 */
@SpringBootApplication
public class AotDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AotDemoApplication.class, args);
    }

    @Bean
    CommandLineRunner demo(UserRepository userRepository, CategoryRepository categoryRepository) {
        return args -> {
            System.out.println();
            System.out.println("=".repeat(60));
            System.out.println("  Spring Data AOT Demo");
            System.out.println("=".repeat(60));

            // Initialize sample data
            initializeData(userRepository, categoryRepository);

            // Demo JPA AOT features
            demoJpaAot(userRepository);

            // Demo JDBC AOT features
            demoJdbcAot(categoryRepository);

            System.out.println();
            System.out.println("=".repeat(60));
            System.out.println("  Demo Complete!");
            System.out.println("=".repeat(60));
        };
    }

    private void initializeData(UserRepository userRepository, CategoryRepository categoryRepository) {
        System.out.println();
        System.out.println("-".repeat(60));
        System.out.println("Initializing sample data...");
        System.out.println("-".repeat(60));

        // JPA Users
        userRepository.save(new User("John", "Doe", "john.doe@example.com"));
        userRepository.save(new User("Jane", "Doe", "jane.doe@example.com"));
        userRepository.save(new User("Bob", "Smith", "bob.smith@company.com"));
        userRepository.save(new User("Alice", "Johnson", "alice@example.com"));
        System.out.println("Created 4 JPA User entities");

        // JDBC Categories
        categoryRepository.save(new Category("Electronics", "Electronic gadgets and devices"));
        categoryRepository.save(new Category("Books", "Physical and digital books"));
        categoryRepository.save(new Category("Clothing", "Apparel and accessories"));
        categoryRepository.save(new Category("Coding Books", "Programming and software books"));
        System.out.println("Created 4 JDBC Category entities");
    }

    private void demoJpaAot(UserRepository userRepository) {
        System.out.println();
        System.out.println("-".repeat(60));
        System.out.println("JPA AOT Demo - Derived Query Methods");
        System.out.println("-".repeat(60));

        // Derived query: findByLastnameContaining
        System.out.println();
        System.out.println(">> userRepository.findByLastnameContaining(\"Doe\")");
        List<User> doeUsers = userRepository.findByLastnameContaining("Doe");
        doeUsers.forEach(u -> System.out.println("   " + u));

        // Derived query with multiple conditions
        System.out.println();
        System.out.println(">> userRepository.findByFirstnameAndLastname(\"John\", \"Doe\")");
        List<User> johnDoe = userRepository.findByFirstnameAndLastname("John", "Doe");
        johnDoe.forEach(u -> System.out.println("   " + u));

        // Custom JPQL query
        System.out.println();
        System.out.println(">> userRepository.findByEmailDomain(\"example.com\")");
        List<User> exampleUsers = userRepository.findByEmailDomain("example.com");
        exampleUsers.forEach(u -> System.out.println("   " + u));

        // Projection query
        System.out.println();
        System.out.println(">> userRepository.findProjectedByLastnameContaining(\"Doe\")");
        List<UserProjection> projections = userRepository.findProjectedByLastnameContaining("Doe");
        projections.forEach(p -> System.out.println("   Full Name: " + p.getFullName()));
    }

    private void demoJdbcAot(CategoryRepository categoryRepository) {
        System.out.println();
        System.out.println("-".repeat(60));
        System.out.println("JDBC AOT Demo - Derived Query Methods");
        System.out.println("-".repeat(60));

        // Derived query: findAllByNameContaining
        System.out.println();
        System.out.println(">> categoryRepository.findAllByNameContaining(\"Books\")");
        List<Category> bookCategories = categoryRepository.findAllByNameContaining("Books");
        bookCategories.forEach(c -> System.out.println("   " + c));

        // Custom SQL query
        System.out.println();
        System.out.println(">> categoryRepository.findWithDeclaredQuery(\"Electronics\")");
        List<Category> electronics = categoryRepository.findWithDeclaredQuery("Electronics");
        electronics.forEach(c -> System.out.println("   " + c));

        // Projection query
        System.out.println();
        System.out.println(">> categoryRepository.findProjectedByNameContaining(\"Books\")");
        List<CategoryProjection> catProjections = categoryRepository.findProjectedByNameContaining("Books");
        catProjections.forEach(p -> System.out.println("   Combined: " + p.getNameAndDescription()));

        // Derived query with ordering
        System.out.println();
        System.out.println(">> categoryRepository.findByDescriptionContainingOrderByNameAsc(\"books\")");
        List<Category> orderedCategories = categoryRepository.findByDescriptionContainingOrderByNameAsc("books");
        orderedCategories.forEach(c -> System.out.println("   " + c));
    }
}
