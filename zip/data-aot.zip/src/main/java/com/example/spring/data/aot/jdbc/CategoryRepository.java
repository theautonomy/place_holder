package com.example.spring.data.aot.jdbc;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Spring Data JDBC Repository for Category entity.
 *
 * <p>AOT processing generates implementations at build time: - Generated class:
 * CategoryRepositoryImpl__Aot - Generated metadata: CategoryRepository.json
 *
 * <p>Important: Provide a JdbcDialect bean to avoid early database access caused by dialect
 * detection during AOT processing.
 */
public interface CategoryRepository extends CrudRepository<Category, Long> {

    /** Derived query method - AOT generates SQL at build time. */
    List<Category> findAllByNameContaining(String name);

    /** Interface projection query. */
    List<CategoryProjection> findProjectedByNameContaining(String name);

    /**
     * Custom SQL query - pre-parsed during AOT processing. Note: Use quoted identifiers for H2
     * compatibility.
     */
    @Query("SELECT * FROM \"category\" WHERE \"NAME\" = :name")
    List<Category> findWithDeclaredQuery(String name);

    /** Derived query with ordering. */
    List<Category> findByDescriptionContainingOrderByNameAsc(String description);
}
