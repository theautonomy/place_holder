package com.example.spring.data.aot.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Spring Data JPA Repository for User entity.
 *
 * <p>AOT processing will generate implementations for these query methods at build time, moving
 * query analysis from runtime to compile time.
 *
 * <p>Generated class: UserRepositoryImpl__Aot Generated metadata: UserRepository.json
 */
public interface UserRepository extends CrudRepository<User, Long> {

    /** Derived query method - AOT will generate JPQL at build time. */
    List<User> findByLastnameContaining(String lastname);

    /** Derived query method with multiple conditions. */
    List<User> findByFirstnameAndLastname(String firstname, String lastname);

    /** Custom JPQL query - AOT will pre-parse and optimize. */
    @Query("SELECT u FROM User u WHERE u.email LIKE %:domain")
    List<User> findByEmailDomain(String domain);

    /** Projection query returning only specific fields. */
    List<UserProjection> findProjectedByLastnameContaining(String lastname);
}
