package com.example.spring.data.aot.jdbc;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceCreator;
import org.springframework.data.relational.core.mapping.Table;

/**
 * Spring Data JDBC entity representing a Category. The @Table annotation aids entity scanning
 * during AOT processing and ensures proper registration with ManagedTypes.
 */
@Table("category")
public class Category {

    @Id private Long id;

    private String name;
    private String description;
    private LocalDateTime created;
    private Long inserted;

    public Category(String name, String description) {
        this.name = name;
        this.description = description;
        this.created = LocalDateTime.now();
    }

    @PersistenceCreator
    public Category(
            Long id, String name, String description, LocalDateTime created, Long inserted) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.created = created;
        this.inserted = inserted;
    }

    public void timeStamp() {
        if (this.inserted == null) {
            this.inserted = System.currentTimeMillis();
        }
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public Long getInserted() {
        return inserted;
    }

    public Category withId(Long id) {
        return new Category(id, this.name, this.description, this.created, this.inserted);
    }

    @Override
    public String toString() {
        return "Category{id=%d, name='%s', description='%s', created=%s}"
                .formatted(id, name, description, created);
    }
}
