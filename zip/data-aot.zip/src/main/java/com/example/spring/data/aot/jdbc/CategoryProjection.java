package com.example.spring.data.aot.jdbc;

/**
 * Interface-based projection for Category entity. AOT generates appropriate runtime hints for
 * projections.
 */
public interface CategoryProjection {

    String getName();

    String getDescription();

    default String getNameAndDescription() {
        return getName() + " - " + getDescription();
    }
}
