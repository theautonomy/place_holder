package com.example.spring.data.aot.jpa;

/**
 * Interface-based projection for User entity. AOT will generate appropriate hints for projection
 * handling.
 */
public interface UserProjection {

    String getFirstname();

    String getLastname();

    default String getFullName() {
        return getFirstname() + " " + getLastname();
    }
}
