package com.example.demo.config.restclient;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;
import org.springframework.web.service.annotation.GetExchange;

/** Tests for {@link DefaultRestClientContainer}. */
class DefaultRestClientContainerTests {

    private DefaultRestClientContainer container;

    @BeforeEach
    void setUp() {
        container = new DefaultRestClientContainer();
    }

    @Test
    void registerAndGetRestClient() {
        RestClient client = RestClient.builder().baseUrl("https://api.example.com").build();

        container.register("test", client);

        assertThat(container.get("test")).isSameAs(client);
    }

    @Test
    void getThrowsExceptionForUnknownClient() {
        assertThatThrownBy(() -> container.get("unknown"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("No RestClient found with name: unknown");
    }

    @Test
    void containsReturnsTrueForRegisteredClient() {
        RestClient client = RestClient.builder().build();
        container.register("test", client);

        assertThat(container.contains("test")).isTrue();
    }

    @Test
    void containsReturnsFalseForUnknownClient() {
        assertThat(container.contains("unknown")).isFalse();
    }

    @Test
    void getNamesReturnsAllRegisteredClientNames() {
        container.register("client1", RestClient.builder().build());
        container.register("client2", RestClient.builder().build());
        container.register("client3", RestClient.builder().build());

        assertThat(container.getNames()).containsExactlyInAnyOrder("client1", "client2", "client3");
    }

    @Test
    void getNamesReturnsEmptySetWhenNoClientsRegistered() {
        assertThat(container.getNames()).isEmpty();
    }

    @Test
    void getNamesReturnsUnmodifiableSet() {
        container.register("test", RestClient.builder().build());

        assertThatThrownBy(() -> container.getNames().add("another"))
                .isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void registerBuilderSupplierAndGetBuilder() {
        container.registerBuilderSupplier(
                "test", () -> RestClient.builder().baseUrl("https://api.example.com"));

        RestClient.Builder builder = container.getBuilder("test");

        assertThat(builder).isNotNull();
    }

    @Test
    void getBuilderThrowsExceptionForUnknownClient() {
        assertThatThrownBy(() -> container.getBuilder("unknown"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("No RestClient.Builder found with name: unknown");
    }

    @Test
    void getBuilderReturnsNewInstanceEachTime() {
        container.registerBuilderSupplier(
                "test", () -> RestClient.builder().baseUrl("https://api.example.com"));

        RestClient.Builder builder1 = container.getBuilder("test");
        RestClient.Builder builder2 = container.getBuilder("test");

        assertThat(builder1).isNotSameAs(builder2);
    }

    @Test
    void registerOverwritesExistingClient() {
        RestClient client1 = RestClient.builder().baseUrl("https://api1.example.com").build();
        RestClient client2 = RestClient.builder().baseUrl("https://api2.example.com").build();

        container.register("test", client1);
        container.register("test", client2);

        assertThat(container.get("test")).isSameAs(client2);
    }

    @Test
    void getHttpExchangeClientCreatesProxyClient() {
        RestClient restClient = RestClient.builder().baseUrl("https://api.example.com").build();
        container.register("test", restClient);

        TestHttpExchangeClient exchangeClient =
                container.getHttpExchangeClient("test", TestHttpExchangeClient.class);

        assertThat(exchangeClient).isNotNull();
    }

    @Test
    void multipleClientsCanBeRegisteredAndRetrieved() {
        RestClient client1 = RestClient.builder().baseUrl("https://api1.example.com").build();
        RestClient client2 = RestClient.builder().baseUrl("https://api2.example.com").build();
        RestClient client3 = RestClient.builder().baseUrl("https://api3.example.com").build();

        container.register("api1", client1);
        container.register("api2", client2);
        container.register("api3", client3);

        assertThat(container.get("api1")).isSameAs(client1);
        assertThat(container.get("api2")).isSameAs(client2);
        assertThat(container.get("api3")).isSameAs(client3);
        assertThat(container.getNames()).hasSize(3);
    }

    @Test
    void builderSupplierIsInvokedEachTimeGetBuilderIsCalled() {
        int[] callCount = {0};
        container.registerBuilderSupplier(
                "test",
                () -> {
                    callCount[0]++;
                    return RestClient.builder().baseUrl("https://api.example.com");
                });

        container.getBuilder("test");
        container.getBuilder("test");
        container.getBuilder("test");

        assertThat(callCount[0]).isEqualTo(3);
    }

    /** Test interface for HTTP exchange client creation. */
    interface TestHttpExchangeClient {
        @GetExchange("/test")
        String test();
    }
}
