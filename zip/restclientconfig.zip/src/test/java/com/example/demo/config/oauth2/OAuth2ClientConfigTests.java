package com.example.demo.config.oauth2;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.security.oauth2.client.autoconfigure.OAuth2ClientAutoConfiguration;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;

/** Tests for {@link OAuth2ClientConfig}. */
class OAuth2ClientConfigTests {

    private final ApplicationContextRunner contextRunner =
            new ApplicationContextRunner()
                    .withConfiguration(AutoConfigurations.of(OAuth2ClientAutoConfiguration.class))
                    .withUserConfiguration(OAuth2ClientConfig.class);

    @Test
    void autoConfigurationRegistersOAuth2AuthorizedClientManager() {
        this.contextRunner
                .withPropertyValues(
                        "spring.security.oauth2.client.registration.test.client-id=test-client",
                        "spring.security.oauth2.client.registration.test.client-secret=test-secret",
                        "spring.security.oauth2.client.registration.test.authorization-grant-type=client_credentials",
                        "spring.security.oauth2.client.provider.test.token-uri=https://auth.example.com/token")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(OAuth2AuthorizedClientManager.class);
                        });
    }

    @Test
    void autoConfigurationNotAppliedWhenOAuth2ClassesNotOnClasspath() {
        this.contextRunner
                .withClassLoader(new FilteredClassLoader(ClientRegistrationRepository.class))
                .run(
                        context -> {
                            assertThat(context)
                                    .doesNotHaveBean(OAuth2AuthorizedClientManager.class);
                        });
    }

    @Test
    void autoConfigurationNotAppliedWhenNoRegistrationsConfigured() {
        new ApplicationContextRunner()
                .withUserConfiguration(OAuth2ClientConfig.class)
                .run(
                        context -> {
                            assertThat(context)
                                    .doesNotHaveBean(OAuth2AuthorizedClientManager.class);
                        });
    }

    @Test
    void customOAuth2AuthorizedClientManagerTakesPrecedence() {
        OAuth2AuthorizedClientManager customManager =
                new OAuth2AuthorizedClientManager() {
                    @Override
                    public org.springframework.security.oauth2.client.OAuth2AuthorizedClient
                            authorize(
                                    org.springframework.security.oauth2.client
                                                    .OAuth2AuthorizeRequest
                                            authorizeRequest) {
                        return null;
                    }
                };

        this.contextRunner
                .withPropertyValues(
                        "spring.security.oauth2.client.registration.test.client-id=test-client",
                        "spring.security.oauth2.client.registration.test.client-secret=test-secret",
                        "spring.security.oauth2.client.registration.test.authorization-grant-type=client_credentials",
                        "spring.security.oauth2.client.provider.test.token-uri=https://auth.example.com/token")
                .withBean(OAuth2AuthorizedClientManager.class, () -> customManager)
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(OAuth2AuthorizedClientManager.class);
                            assertThat(context.getBean(OAuth2AuthorizedClientManager.class))
                                    .isSameAs(customManager);
                        });
    }

    @Test
    void multipleOAuth2RegistrationsCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.security.oauth2.client.registration.github.client-id=github-client",
                        "spring.security.oauth2.client.registration.github.client-secret=github-secret",
                        "spring.security.oauth2.client.registration.github.authorization-grant-type=authorization_code",
                        "spring.security.oauth2.client.registration.github.redirect-uri={baseUrl}/login/oauth2/code/{registrationId}",
                        "spring.security.oauth2.client.provider.github.authorization-uri=https://github.com/login/oauth/authorize",
                        "spring.security.oauth2.client.provider.github.token-uri=https://github.com/login/oauth/access_token",
                        "spring.security.oauth2.client.registration.google.client-id=google-client",
                        "spring.security.oauth2.client.registration.google.client-secret=google-secret",
                        "spring.security.oauth2.client.registration.google.authorization-grant-type=authorization_code",
                        "spring.security.oauth2.client.registration.google.redirect-uri={baseUrl}/login/oauth2/code/{registrationId}",
                        "spring.security.oauth2.client.registration.google.scope=openid,profile,email",
                        "spring.security.oauth2.client.provider.google.authorization-uri=https://accounts.google.com/o/oauth2/v2/auth",
                        "spring.security.oauth2.client.provider.google.token-uri=https://www.googleapis.com/oauth2/v4/token")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(OAuth2AuthorizedClientManager.class);
                            assertThat(context).hasSingleBean(ClientRegistrationRepository.class);
                        });
    }

    @Test
    void clientCredentialsGrantTypeIsSupported() {
        this.contextRunner
                .withPropertyValues(
                        "spring.security.oauth2.client.registration.api.client-id=api-client",
                        "spring.security.oauth2.client.registration.api.client-secret=api-secret",
                        "spring.security.oauth2.client.registration.api.authorization-grant-type=client_credentials",
                        "spring.security.oauth2.client.registration.api.scope=read,write",
                        "spring.security.oauth2.client.provider.api.token-uri=https://auth.example.com/oauth/token")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(OAuth2AuthorizedClientManager.class);
                        });
    }
}
