package com.example.demo.config.restclient;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.TestPropertySource;

/** Tests for {@link CustomRestClientConfig} and {@link CustomRestClientProperties} binding. */
class CustomRestClientConfigTests {

    @SpringBootTest(classes = BasicAuthPropertiesTest.TestConfig.class)
    @TestPropertySource(
            properties = {
                "restclient.config.httpbin.authentication.type=basic",
                "restclient.config.httpbin.authentication.basic.username=testuser",
                "restclient.config.httpbin.authentication.basic.password=testpass"
            })
    static class BasicAuthPropertiesTest {

        @Autowired private CustomRestClientProperties properties;

        @Test
        void basicAuthPropertiesAreBound() {
            assertThat(properties.containsKey("httpbin")).isTrue();

            CustomRestClientConfig httpbin = properties.get("httpbin");
            assertThat(httpbin.getAuthentication()).isNotNull();
            assertThat(httpbin.getAuthentication().getType()).isEqualTo("basic");
            assertThat(httpbin.getAuthentication().getBasic()).isNotNull();
            assertThat(httpbin.getAuthentication().getBasic().getUsername()).isEqualTo("testuser");
            assertThat(httpbin.getAuthentication().getBasic().getPassword()).isEqualTo("testpass");
        }

        @Configuration
        @EnableConfigurationProperties(CustomRestClientProperties.class)
        static class TestConfig {}
    }

    @SpringBootTest(classes = BearerAuthPropertiesTest.TestConfig.class)
    @TestPropertySource(
            properties = {
                "restclient.config.api.authentication.type=bearer",
                "restclient.config.api.authentication.bearer.token=my-secret-token"
            })
    static class BearerAuthPropertiesTest {

        @Autowired private CustomRestClientProperties properties;

        @Test
        void bearerAuthPropertiesAreBound() {
            assertThat(properties.containsKey("api")).isTrue();

            CustomRestClientConfig api = properties.get("api");
            assertThat(api.getAuthentication()).isNotNull();
            assertThat(api.getAuthentication().getType()).isEqualTo("bearer");
            assertThat(api.getAuthentication().getBearer()).isNotNull();
            assertThat(api.getAuthentication().getBearer().getToken()).isEqualTo("my-secret-token");
        }

        @Configuration
        @EnableConfigurationProperties(CustomRestClientProperties.class)
        static class TestConfig {}
    }

    @SpringBootTest(classes = OAuth2AuthPropertiesTest.TestConfig.class)
    @TestPropertySource(
            properties = {
                "restclient.config.github.authentication.type=oauth2",
                "restclient.config.github.authentication.oauth2.registration-id=github-registration"
            })
    static class OAuth2AuthPropertiesTest {

        @Autowired private CustomRestClientProperties properties;

        @Test
        void oauth2AuthPropertiesAreBound() {
            assertThat(properties.containsKey("github")).isTrue();

            CustomRestClientConfig github = properties.get("github");
            assertThat(github.getAuthentication()).isNotNull();
            assertThat(github.getAuthentication().getType()).isEqualTo("oauth2");
            assertThat(github.getAuthentication().getOauth2()).isNotNull();
            assertThat(github.getAuthentication().getOauth2().getRegistrationId())
                    .isEqualTo("github-registration");
        }

        @Configuration
        @EnableConfigurationProperties(CustomRestClientProperties.class)
        static class TestConfig {}
    }

    @SpringBootTest(classes = ApiVersionPropertiesTest.TestConfig.class)
    @TestPropertySource(properties = {"restclient.config.versioned-api.api-version-default=2.0"})
    static class ApiVersionPropertiesTest {

        @Autowired private CustomRestClientProperties properties;

        @Test
        void apiVersionPropertiesAreBound() {
            assertThat(properties.containsKey("versioned-api")).isTrue();

            CustomRestClientConfig api = properties.get("versioned-api");
            assertThat(api.getApiVersionDefault()).isEqualTo("2.0");
        }

        @Configuration
        @EnableConfigurationProperties(CustomRestClientProperties.class)
        static class TestConfig {}
    }

    @SpringBootTest(classes = MultipleClientsPropertiesTest.TestConfig.class)
    @TestPropertySource(
            properties = {
                "restclient.config.client1.authentication.type=basic",
                "restclient.config.client1.authentication.basic.username=user1",
                "restclient.config.client1.authentication.basic.password=pass1",
                "restclient.config.client2.authentication.type=bearer",
                "restclient.config.client2.authentication.bearer.token=token2",
                "restclient.config.client3.api-version-default=v3"
            })
    static class MultipleClientsPropertiesTest {

        @Autowired private CustomRestClientProperties properties;

        @Test
        void multipleClientPropertiesAreBound() {
            assertThat(properties.getConfig()).hasSize(3);
            assertThat(properties.getConfig()).containsKeys("client1", "client2", "client3");

            // Client 1 - Basic Auth
            CustomRestClientConfig client1 = properties.get("client1");
            assertThat(client1.getAuthentication().getType()).isEqualTo("basic");
            assertThat(client1.getAuthentication().getBasic().getUsername()).isEqualTo("user1");

            // Client 2 - Bearer Auth
            CustomRestClientConfig client2 = properties.get("client2");
            assertThat(client2.getAuthentication().getType()).isEqualTo("bearer");
            assertThat(client2.getAuthentication().getBearer().getToken()).isEqualTo("token2");

            // Client 3 - API Version
            CustomRestClientConfig client3 = properties.get("client3");
            assertThat(client3.getApiVersionDefault()).isEqualTo("v3");
        }

        @Configuration
        @EnableConfigurationProperties(CustomRestClientProperties.class)
        static class TestConfig {}
    }

    @Test
    void clientAuthPropertiesDefaultValues() {
        CustomRestClientConfig props = new CustomRestClientConfig();

        assertThat(props.getAuthentication()).isNull();
        assertThat(props.getApiVersionDefault()).isNull();
    }

    @Test
    void authenticationDefaultValues() {
        CustomRestClientConfig.Authentication auth = new CustomRestClientConfig.Authentication();

        assertThat(auth.getType()).isNull();
        assertThat(auth.getBasic()).isNull();
        assertThat(auth.getOauth2()).isNull();
        assertThat(auth.getBearer()).isNull();
    }

    @Test
    void basicAuthSettersAndGetters() {
        CustomRestClientConfig.BasicAuth basic = new CustomRestClientConfig.BasicAuth();
        basic.setUsername("user");
        basic.setPassword("pass");

        assertThat(basic.getUsername()).isEqualTo("user");
        assertThat(basic.getPassword()).isEqualTo("pass");
    }

    @Test
    void oauth2AuthSettersAndGetters() {
        CustomRestClientConfig.OAuth2Auth oauth2 = new CustomRestClientConfig.OAuth2Auth();
        oauth2.setRegistrationId("my-registration");

        assertThat(oauth2.getRegistrationId()).isEqualTo("my-registration");
    }

    @Test
    void bearerAuthSettersAndGetters() {
        CustomRestClientConfig.BearerAuth bearer = new CustomRestClientConfig.BearerAuth();
        bearer.setToken("my-token");

        assertThat(bearer.getToken()).isEqualTo("my-token");
    }

    @Test
    void authenticationSettersAndGetters() {
        CustomRestClientConfig.Authentication auth = new CustomRestClientConfig.Authentication();
        CustomRestClientConfig.BasicAuth basic = new CustomRestClientConfig.BasicAuth();
        CustomRestClientConfig.OAuth2Auth oauth2 = new CustomRestClientConfig.OAuth2Auth();
        CustomRestClientConfig.BearerAuth bearer = new CustomRestClientConfig.BearerAuth();

        auth.setType("basic");
        auth.setBasic(basic);
        auth.setOauth2(oauth2);
        auth.setBearer(bearer);

        assertThat(auth.getType()).isEqualTo("basic");
        assertThat(auth.getBasic()).isSameAs(basic);
        assertThat(auth.getOauth2()).isSameAs(oauth2);
        assertThat(auth.getBearer()).isSameAs(bearer);
    }

    @Test
    void clientAuthPropertiesSettersAndGetters() {
        CustomRestClientConfig props = new CustomRestClientConfig();
        CustomRestClientConfig.Authentication auth = new CustomRestClientConfig.Authentication();

        props.setAuthentication(auth);
        props.setApiVersionDefault("1.0");

        assertThat(props.getAuthentication()).isSameAs(auth);
        assertThat(props.getApiVersionDefault()).isEqualTo("1.0");
    }
}
