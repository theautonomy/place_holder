package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.demo.config.restclient.RestClientContainer;
import com.example.demo.config.restclient.RestClientContainerAutoConfiguration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.http.client.autoconfigure.HttpClientAutoConfiguration;
import org.springframework.boot.http.client.autoconfigure.imperative.ImperativeHttpClientAutoConfiguration;
import org.springframework.boot.restclient.autoconfigure.RestClientAutoConfiguration;
import org.springframework.boot.restclient.autoconfigure.service.HttpServiceClientAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.TestPropertySource;

/** Integration test for RestClient Container auto-configuration. */
@SpringBootTest(classes = DemoApplicationTests.TestConfiguration.class)
@TestPropertySource(
        properties = {
            "spring.http.serviceclient.example.base-url=https://jsonplaceholder.typicode.com"
        })
class DemoApplicationTests {

    @Autowired private RestClientContainer restClientContainer;

    @Test
    void contextLoads() {
        assertThat(restClientContainer).isNotNull();
        assertThat(restClientContainer.contains("example")).isTrue();
    }

    @Configuration
    @ImportAutoConfiguration({
        HttpClientAutoConfiguration.class,
        ImperativeHttpClientAutoConfiguration.class,
        RestClientAutoConfiguration.class,
        HttpServiceClientAutoConfiguration.class,
        RestClientContainerAutoConfiguration.class
    })
    static class TestConfiguration {}
}
