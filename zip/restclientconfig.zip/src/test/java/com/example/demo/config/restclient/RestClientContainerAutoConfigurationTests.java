package com.example.demo.config.restclient;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.http.client.autoconfigure.HttpClientAutoConfiguration;
import org.springframework.boot.http.client.autoconfigure.imperative.ImperativeHttpClientAutoConfiguration;
import org.springframework.boot.restclient.autoconfigure.RestClientAutoConfiguration;
import org.springframework.boot.restclient.autoconfigure.service.HttpServiceClientAutoConfiguration;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.web.client.RestClient;

/** Tests for {@link RestClientContainerAutoConfiguration}. */
class RestClientContainerAutoConfigurationTests {

    private final ApplicationContextRunner contextRunner =
            new ApplicationContextRunner()
                    .withConfiguration(
                            AutoConfigurations.of(
                                    HttpClientAutoConfiguration.class,
                                    ImperativeHttpClientAutoConfiguration.class,
                                    RestClientAutoConfiguration.class,
                                    HttpServiceClientAutoConfiguration.class,
                                    RestClientContainerAutoConfiguration.class));

    @Test
    void autoConfigurationRegistersRestClientContainer() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("test")).isTrue();
                            assertThat(container.getNames()).contains("test");
                        });
    }

    @Test
    void autoConfigurationNotAppliedWhenRestClientNotOnClasspath() {
        this.contextRunner
                .withClassLoader(new FilteredClassLoader(RestClient.class))
                .run(
                        context -> {
                            assertThat(context).doesNotHaveBean(RestClientContainer.class);
                        });
    }

    @Test
    void autoConfigurationBacksOffWhenBeanAlreadyExists() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com")
                .withBean(RestClientContainer.class, DefaultRestClientContainer::new)
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                        });
    }

    @Test
    void multipleServiceClientsCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.api1.base-url=https://api1.example.com",
                        "spring.http.serviceclient.api2.base-url=https://api2.example.com",
                        "spring.http.serviceclient.api3.base-url=https://api3.example.com")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.getNames())
                                    .containsExactlyInAnyOrder("api1", "api2", "api3");
                        });
    }

    @Test
    void basicAuthenticationCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.secured.base-url=https://api.example.com",
                        "restclient.config.secured.authentication.type=basic",
                        "restclient.config.secured.authentication.basic.username=testuser",
                        "restclient.config.secured.authentication.basic.password=testpass")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("secured")).isTrue();
                            RestClient client = container.get("secured");
                            assertThat(client).isNotNull();
                        });
    }

    @Test
    void bearerAuthenticationCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.secured.base-url=https://api.example.com",
                        "restclient.config.secured.authentication.type=bearer",
                        "restclient.config.secured.authentication.bearer.token=my-jwt-token")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("secured")).isTrue();
                            RestClient client = container.get("secured");
                            assertThat(client).isNotNull();
                        });
    }

    @Test
    void builderCanBeRetrieved() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com")
                .run(
                        context -> {
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            RestClient.Builder builder = container.getBuilder("test");
                            assertThat(builder).isNotNull();
                            RestClient client = builder.build();
                            assertThat(client).isNotNull();
                        });
    }

    @Test
    void defaultHeadersCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com",
                        "spring.http.serviceclient.test.default-header.Accept=application/json",
                        "spring.http.serviceclient.test.default-header.X-Custom=custom-value")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("test")).isTrue();
                            RestClient client = container.get("test");
                            assertThat(client).isNotNull();
                        });
    }

    @Test
    void timeoutsCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com",
                        "spring.http.serviceclient.test.connect-timeout=5s",
                        "spring.http.serviceclient.test.read-timeout=30s")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("test")).isTrue();
                            RestClient client = container.get("test");
                            assertThat(client).isNotNull();
                        });
    }

    @Test
    void apiVersionHeaderCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com",
                        "spring.http.serviceclient.test.apiversion.insert.header=X-API-Version",
                        "restclient.config.test.api-version-default=2.0")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("test")).isTrue();
                            RestClient client = container.get("test");
                            assertThat(client).isNotNull();
                        });
    }

    @Test
    void apiVersionQueryParameterCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com",
                        "spring.http.serviceclient.test.apiversion.insert.query-parameter=api-version",
                        "restclient.config.test.api-version-default=1.0")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("test")).isTrue();
                        });
    }

    @Test
    void apiVersionPathSegmentCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com",
                        "spring.http.serviceclient.test.apiversion.insert.path-segment=0",
                        "restclient.config.test.api-version-default=v1")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("test")).isTrue();
                        });
    }

    @Test
    void apiVersionMediaTypeParameterCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.test.base-url=https://api.example.com",
                        "spring.http.serviceclient.test.apiversion.insert.media-type-parameter=version",
                        "restclient.config.test.api-version-default=1.0")
                .run(
                        context -> {
                            assertThat(context).hasSingleBean(RestClientContainer.class);
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("test")).isTrue();
                        });
    }

    @Test
    void noServiceClientsConfiguredResultsInEmptyContainer() {
        this.contextRunner.run(
                context -> {
                    assertThat(context).hasSingleBean(RestClientContainer.class);
                    RestClientContainer container = context.getBean(RestClientContainer.class);
                    assertThat(container.getNames()).isEmpty();
                });
    }

    @Test
    void clientWithNoAuthenticationCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.public-api.base-url=https://api.example.com")
                .run(
                        context -> {
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.contains("public-api")).isTrue();
                            RestClient client = container.get("public-api");
                            assertThat(client).isNotNull();
                        });
    }

    @Test
    void mixedAuthenticationTypesCanBeConfigured() {
        this.contextRunner
                .withPropertyValues(
                        "spring.http.serviceclient.basic-api.base-url=https://basic.example.com",
                        "restclient.config.basic-api.authentication.type=basic",
                        "restclient.config.basic-api.authentication.basic.username=user",
                        "restclient.config.basic-api.authentication.basic.password=pass",
                        "spring.http.serviceclient.bearer-api.base-url=https://bearer.example.com",
                        "restclient.config.bearer-api.authentication.type=bearer",
                        "restclient.config.bearer-api.authentication.bearer.token=token123",
                        "spring.http.serviceclient.public-api.base-url=https://public.example.com")
                .run(
                        context -> {
                            RestClientContainer container =
                                    context.getBean(RestClientContainer.class);
                            assertThat(container.getNames())
                                    .containsExactlyInAnyOrder(
                                            "basic-api", "bearer-api", "public-api");
                            assertThat(container.get("basic-api")).isNotNull();
                            assertThat(container.get("bearer-api")).isNotNull();
                            assertThat(container.get("public-api")).isNotNull();
                        });
    }
}
