package com.example.demo.config.restclient;

/**
 * Authentication and API version configuration for a RestClient.
 *
 * @author Spring Boot RestClient Container
 * @since 1.0.0
 */
public class CustomRestClientConfig {

    /** Authentication configuration for this service client. */
    private Authentication authentication;

    /**
     * Default API version to use for requests. This is a workaround for Spring Boot binding issues
     * with nested apiversion.defaultVersion property.
     */
    private String apiVersionDefault;

    public String getApiVersionDefault() {
        return apiVersionDefault;
    }

    public void setApiVersionDefault(String apiVersionDefault) {
        this.apiVersionDefault = apiVersionDefault;
    }

    public Authentication getAuthentication() {
        return authentication;
    }

    public void setAuthentication(Authentication authentication) {
        this.authentication = authentication;
    }

    /** Authentication settings for a service client. */
    public static class Authentication {
        /**
         * Authentication type. Supported values: "basic", "oauth2", "bearer". Leave unset for no
         * authentication.
         */
        private String type;

        /** Basic authentication configuration. */
        private BasicAuth basic;

        /** OAuth2 authentication configuration. */
        private OAuth2Auth oauth2;

        /** Bearer token authentication configuration. */
        private BearerAuth bearer;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public BasicAuth getBasic() {
            return basic;
        }

        public void setBasic(BasicAuth basic) {
            this.basic = basic;
        }

        public OAuth2Auth getOauth2() {
            return oauth2;
        }

        public void setOauth2(OAuth2Auth oauth2) {
            this.oauth2 = oauth2;
        }

        public BearerAuth getBearer() {
            return bearer;
        }

        public void setBearer(BearerAuth bearer) {
            this.bearer = bearer;
        }
    }

    public static class BasicAuth {
        private String username;
        private String password;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }

    public static class OAuth2Auth {
        private String registrationId;

        public String getRegistrationId() {
            return registrationId;
        }

        public void setRegistrationId(String registrationId) {
            this.registrationId = registrationId;
        }
    }

    public static class BearerAuth {
        private String token;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }
    }
}
