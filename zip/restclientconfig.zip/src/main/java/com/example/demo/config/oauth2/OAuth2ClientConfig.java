package com.example.demo.config.oauth2;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.security.oauth2.client.autoconfigure.ConditionalOnOAuth2ClientRegistrationProperties;
import org.springframework.boot.security.oauth2.client.autoconfigure.OAuth2ClientAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.client.AuthorizedClientServiceOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;

/**
 * {@link AutoConfiguration Auto-configuration} for OAuth2 client support in RestClient Container.
 *
 * <p>Provides an {@link OAuth2AuthorizedClientManager} bean that supports:
 *
 * <ul>
 *   <li>Authorization Code grant type
 *   <li>Refresh Token grant type
 *   <li>Client Credentials grant type
 * </ul>
 *
 * <p>This auto-configuration is only active when OAuth2 client classes are on the classpath and
 * OAuth2 client registration properties are configured.
 *
 * @author Spring Boot RestClient Container
 * @since 1.0.0
 */
@AutoConfiguration(after = OAuth2ClientAutoConfiguration.class)
@ConditionalOnClass({OAuth2AuthorizedClientManager.class, ClientRegistrationRepository.class})
@ConditionalOnOAuth2ClientRegistrationProperties
public class OAuth2ClientConfig {

    @Bean
    @ConditionalOnMissingBean
    OAuth2AuthorizedClientManager oAuth2AuthorizedClientManager(
            ClientRegistrationRepository clientRegistrationRepository,
            OAuth2AuthorizedClientService authorizedClientService) {

        var authorizedClientProvider =
                OAuth2AuthorizedClientProviderBuilder.builder()
                        .authorizationCode()
                        .refreshToken()
                        .clientCredentials()
                        .build();

        var authorizedClientManager =
                new AuthorizedClientServiceOAuth2AuthorizedClientManager(
                        clientRegistrationRepository, authorizedClientService);
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

        return authorizedClientManager;
    }
}
