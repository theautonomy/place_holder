package com.example.demo.config.restclient;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration properties for RestClient authentication settings.
 *
 * <p>Properties are bound under the {@code restclient} prefix. Each entry in the map represents a
 * named RestClient with its authentication configuration.
 *
 * <p>Example configuration:
 *
 * <pre>
 * restclient.config.github.authentication.type=oauth2
 * restclient.config.github.authentication.oauth2.registration-id=github
 * restclient.config.httpbin.authentication.type=basic
 * restclient.config.httpbin.authentication.basic.username=user
 * restclient.config.httpbin.authentication.basic.password=pass
 * </pre>
 *
 * @author Spring Boot RestClient Container
 * @since 1.0.0
 * @see CustomRestClientConfig
 */
@ConfigurationProperties(prefix = "restclient")
public class CustomRestClientProperties {

    /** Map of RestClient config names to their configuration. */
    private Map<String, CustomRestClientConfig> config = new LinkedHashMap<>();

    public Map<String, CustomRestClientConfig> getConfig() {
        return config;
    }

    public void setConfig(Map<String, CustomRestClientConfig> config) {
        this.config = config;
    }

    /**
     * Get configuration for a specific config by name.
     *
     * @param name the config name
     * @return the configuration, or null if not found
     */
    public CustomRestClientConfig get(String name) {
        return config.get(name);
    }

    /**
     * Check if a config exists.
     *
     * @param name the config name
     * @return true if config exists
     */
    public boolean containsKey(String name) {
        return config.containsKey(name);
    }
}
