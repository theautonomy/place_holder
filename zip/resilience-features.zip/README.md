# Spring Framework 7 Resilience Features Demo

A command-line application demonstrating the new resilience features introduced in Spring Framework 7.

## Overview

This application showcases three major resilience patterns built into Spring Framework 7:

1. **@Retryable** - Automatic retry of failed method invocations
2. **@ConcurrencyLimit** - Restrict concurrent access to methods
3. **RetryTemplate** - Programmatic retry control

## Requirements

- Java 17 or higher
- Maven 3.6+
- Spring Boot 4.0.0 (includes Spring Framework 7)

## Features Demonstrated

### 1. @Retryable Annotation

Automatically retries failed method invocations with configurable retry policies.

**Basic Usage:**
```java
@Retryable
public void sendNotification() {
    // Will retry up to 3 times with 1-second delays
}
```

**Exponential Backoff:**
```java
@Retryable(
    maxRetries = 4,
    delay = 100,
    jitter = 10,
    multiplier = 2,
    maxDelay = 1000
)
public void sendWithExponentialBackoff() {
    // Exponential backoff with jitter
}
```

**Retry on Specific Exception:**
```java
@Retryable(
    includes = TransientNetworkException.class,
    maxRetries = 3,
    delay = 200
)
public void connectToExternalApi() {
    // Only retries when TransientNetworkException is thrown
    // Other exceptions will propagate immediately
}
```

See: `RetryableDemo.java`

### 2. @ConcurrencyLimit Annotation

Restricts the number of concurrent threads that can execute a method, protecting resources from overload.

**Usage:**
```java
@ConcurrencyLimit(2)
public void processOrder(int orderId) {
    // Only 2 threads can execute this method concurrently
}
```

See: `ConcurrencyLimitDemo.java`

### 3. RetryTemplate (Programmatic API)

Provides fine-grained programmatic control over retry behavior for any code block.

**Usage:**
```java
RetryPolicy retryPolicy = RetryPolicy.builder()
    .includes(RuntimeException.class)
    .maxRetries(4)
    .delay(Duration.ofMillis(100))
    .jitter(Duration.ofMillis(10))
    .multiplier(2)
    .maxDelay(Duration.ofSeconds(1))
    .build();

RetryTemplate retryTemplate = new RetryTemplate(retryPolicy);
retryTemplate.execute(() -> {
    // Your code here
    return result;
});
```

See: `RetryTemplateDemo.java`

### 4. RetryListener (Observability)

Provides observability into retry operations by logging and tracking retry metrics.

**Implementation:**
```java
@Component
public class NotificationRetryListener implements RetryListener {
    @Override
    public void beforeRetry(RetryPolicy policy, Retryable<?> retryable) {
        // Log retry attempts
    }

    @Override
    public void onRetrySuccess(RetryPolicy policy, Retryable<?> retryable, Object result) {
        // Log successful recoveries
    }

    @Override
    public void onRetryFailure(RetryPolicy policy, Retryable<?> retryable, Throwable throwable) {
        // Log final failures
    }
}
```

**Usage with RetryTemplate:**
```java
RetryTemplate retryTemplate = new RetryTemplate(retryPolicy);
retryTemplate.setRetryListener(retryListener);
```

The listener tracks:
- Total number of retry attempts
- Successful recoveries (operations that succeeded after retrying)
- Final failures (operations that failed after all retries exhausted)

See: `NotificationRetryListener.java`, `RetryTemplateDemo.java`

## Project Structure

```
resilience-features/
├── src/
│   └── main/
│       ├── java/com/example/resilience_features/
│       │   ├── ResilienceFeaturesApplication.java  # Main app with @EnableResilientMethods
│       │   ├── config/
│       │   │   └── RetryConfig.java                # Retry listener configuration
│       │   ├── exception/
│       │   │   └── TransientNetworkException.java  # Custom exception for demo
│       │   ├── listener/
│       │   │   └── NotificationRetryListener.java  # Retry observability listener
│       │   └── service/
│       │       ├── RetryableDemo.java              # @Retryable examples
│       │       ├── ConcurrencyLimitDemo.java       # @ConcurrencyLimit examples
│       │       └── RetryTemplateDemo.java          # RetryTemplate examples
│       └── resources/
│           └── application.properties
└── pom.xml
```

## Running the Application

### Using Maven Wrapper (Recommended)

```bash
# On Windows
mvnw.cmd spring-boot:run

# On Linux/Mac
./mvnw spring-boot:run
```

### Using Maven

```bash
mvn spring-boot:run
```

## Expected Output

When you run the application, you'll see:

1. **Retry Demo**: Method fails twice, succeeds on third attempt, showing basic retry behavior
2. **Exponential Backoff**: Demonstrates increasing delays between retry attempts (100ms, 200ms, etc.)
3. **Specific Exception Retry**: Only retries on `TransientNetworkException`, other exceptions propagate immediately
4. **Concurrency Limit**: 5 operations submitted, but only 2 execute concurrently
5. **RetryTemplate**: Programmatic retry with custom policy
6. **RetryListener**: Shows retry observability with 🔁 retry attempts, ❌ failures, ✅ successes, and statistics

## Key Configuration

The main application class uses `@EnableResilientMethods` to activate resilience features:

```java
@SpringBootApplication
@EnableResilientMethods
public class ResilienceFeaturesApplication {
    // ...
}
```

## Learn More

- [Spring Framework Resilience Documentation](https://docs.spring.io/spring-framework/reference/core/resilience.html)
- [Spring Blog: Core Spring Resilience Features](https://spring.io/blog/2025/09/09/core-spring-resilience-features)

## Notes

- No additional dependencies required beyond `spring-boot-starter`
- All resilience features are built into Spring Framework 7
- Resilience features work with both synchronous and reactive (Mono/Flux) methods
