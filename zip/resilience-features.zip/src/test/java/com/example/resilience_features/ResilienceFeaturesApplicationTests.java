package com.example.resilience_features;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResilienceFeaturesApplicationTests {

    @Test
    void contextLoads() {}
}
