package com.example.resilience_features.config;

import com.example.resilience_features.listener.NotificationRetryListener;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.retry.support.CompositeRetryListener;

@Configuration
public class RetryConfig {

    @Bean
    public CompositeRetryListener retryListener(
            NotificationRetryListener notificationRetryListener) {
        CompositeRetryListener compositeRetryListener = new CompositeRetryListener();
        compositeRetryListener.addListener(notificationRetryListener);
        return compositeRetryListener;
    }
}
