package com.example.resilience_features.service;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.retry.RetryListener;
import org.springframework.core.retry.RetryPolicy;
import org.springframework.core.retry.RetryTemplate;
import org.springframework.stereotype.Service;

@Service
public class RetryTemplateDemo {

    private static final Logger log = LoggerFactory.getLogger(RetryTemplateDemo.class);
    private final AtomicInteger attemptCounter = new AtomicInteger(0);
    private final RetryListener retryListener;

    public RetryTemplateDemo(RetryListener retryListener) {
        this.retryListener = retryListener;
    }

    public void executeWithRetry() {
        RetryPolicy retryPolicy =
                RetryPolicy.builder()
                        .includes(RuntimeException.class)
                        .maxRetries(4)
                        .delay(Duration.ofMillis(100))
                        .jitter(Duration.ofMillis(10))
                        .multiplier(2)
                        .maxDelay(Duration.ofSeconds(1))
                        .build();

        RetryTemplate retryTemplate = new RetryTemplate(retryPolicy);
        retryTemplate.setRetryListener(retryListener);

        try {
            retryTemplate.execute(
                    () -> {
                        int attempt = attemptCounter.incrementAndGet();
                        log.info("RetryTemplate attempt #{}", attempt);

                        if (attempt < 3) {
                            log.warn("Simulating failure on attempt #{}", attempt);
                            throw new RuntimeException("Simulated failure for RetryTemplate");
                        }

                        log.info("Success! Operation completed on attempt #{}", attempt);
                        attemptCounter.set(0);
                        return null;
                    });
        } catch (Exception e) {
            log.error("RetryTemplate execution failed after all retries", e);
            attemptCounter.set(0);
        }
    }
}
