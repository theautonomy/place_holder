package com.example.resilience_features.service;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.resilience.annotation.ConcurrencyLimit;
import org.springframework.stereotype.Service;

@Service
public class ConcurrencyLimitDemo {

    private static final Logger log = LoggerFactory.getLogger(ConcurrencyLimitDemo.class);
    private final AtomicInteger currentConcurrency = new AtomicInteger(0);
    private final AtomicInteger maxObservedConcurrency = new AtomicInteger(0);
    private final ConcurrencyLimitDemo self;

    public ConcurrencyLimitDemo(@Lazy ConcurrencyLimitDemo self) {
        this.self = self;
    }

    @ConcurrencyLimit(2)
    public void processOrder(int orderId) {
        int current = currentConcurrency.incrementAndGet();
        maxObservedConcurrency.updateAndGet(max -> Math.max(max, current));

        try {
            log.info("Processing order #{} (current concurrency: {})", orderId, current);
            Thread.sleep(500);
            log.info("Order #{} processed", orderId);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Order processing interrupted", e);
        } finally {
            currentConcurrency.decrementAndGet();
        }
    }

    public void runConcurrentOperations() {
        maxObservedConcurrency.set(0);
        currentConcurrency.set(0);
        log.info("Note: @ConcurrencyLimit enforces at most 2 concurrent executions");
        log.info("Submitting 5 tasks to a pool of 5 threads...");

        ExecutorService executor = Executors.newFixedThreadPool(5);
        CountDownLatch latch = new CountDownLatch(5);

        for (int i = 1; i <= 5; i++) {
            final int orderId = i;
            executor.submit(
                    () -> {
                        try {
                            self.processOrder(orderId);
                        } finally {
                            latch.countDown();
                        }
                    });
        }

        try {
            latch.await(15, TimeUnit.SECONDS);
            log.info(
                    "All tasks completed. The @ConcurrencyLimit(2) annotation throttled concurrent executions.");
            log.info(
                    "Max observed concurrency inside the method: {} (without proxy, would be 5)",
                    maxObservedConcurrency.get());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Concurrent operations interrupted", e);
        } finally {
            executor.shutdown();
        }
    }
}
