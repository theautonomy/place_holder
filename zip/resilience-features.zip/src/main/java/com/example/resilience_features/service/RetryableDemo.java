package com.example.resilience_features.service;

import java.util.concurrent.atomic.AtomicInteger;

import com.example.resilience_features.exception.TransientNetworkException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.resilience.annotation.Retryable;
import org.springframework.stereotype.Service;

@Service
public class RetryableDemo {

    private static final Logger log = LoggerFactory.getLogger(RetryableDemo.class);
    private final AtomicInteger attemptCounter = new AtomicInteger(0);
    private final AtomicInteger exponentialCounter = new AtomicInteger(0);
    private final AtomicInteger specificExceptionCounter = new AtomicInteger(0);

    @Retryable
    public void sendNotification() {
        int attempt = attemptCounter.incrementAndGet();
        log.info("Attempt #{} to send notification...", attempt);

        if (attempt < 3) {
            log.warn("Simulating transient failure on attempt #{}", attempt);
            throw new RuntimeException("Simulated notification failure");
        }

        log.info("Success! Notification sent on attempt #{}", attempt);
        attemptCounter.set(0);
    }

    @Retryable(maxRetries = 4, delay = 100, jitter = 10, multiplier = 2, maxDelay = 1000)
    public void sendWithExponentialBackoff() {
        int attempt = exponentialCounter.incrementAndGet();
        log.info("Exponential backoff attempt #{}", attempt);

        if (attempt < 3) {
            log.warn(
                    "Simulating transient failure with exponential backoff on attempt #{}",
                    attempt);
            throw new RuntimeException("Simulated exponential backoff failure");
        }

        log.info("Success! Exponential backoff completed on attempt #{}", attempt);
        exponentialCounter.set(0);
    }

    @Retryable(includes = TransientNetworkException.class, maxRetries = 3, delay = 200)
    public void connectToExternalApi() {
        int attempt = specificExceptionCounter.incrementAndGet();
        log.info("API connection attempt #{}", attempt);

        if (attempt < 3) {
            log.warn("Network connection failed on attempt #{}", attempt);
            throw new TransientNetworkException("Connection timeout");
        }

        log.info("Success! Connected to API on attempt #{}", attempt);
        specificExceptionCounter.set(0);
    }
}
