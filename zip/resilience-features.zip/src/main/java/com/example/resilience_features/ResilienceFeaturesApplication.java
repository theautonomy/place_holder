package com.example.resilience_features;

import com.example.resilience_features.listener.NotificationRetryListener;
import com.example.resilience_features.service.ConcurrencyLimitDemo;
import com.example.resilience_features.service.RetryTemplateDemo;
import com.example.resilience_features.service.RetryableDemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.resilience.annotation.EnableResilientMethods;

@SpringBootApplication
@EnableResilientMethods
public class ResilienceFeaturesApplication {

    private static final Logger log = LoggerFactory.getLogger(ResilienceFeaturesApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(ResilienceFeaturesApplication.class, args);
    }

    @Bean
    CommandLineRunner runner(
            RetryableDemo retryableDemo,
            ConcurrencyLimitDemo concurrencyLimitDemo,
            RetryTemplateDemo retryTemplateDemo,
            NotificationRetryListener retryListener) {
        return args -> {
            log.info("=".repeat(80));
            log.info("Spring Framework 7 Resilience Features Demo");
            log.info("=".repeat(80));

            retryListener.reset();
            demonstrateRetryable(retryableDemo);
            demonstrateConcurrencyLimit(concurrencyLimitDemo);
            demonstrateRetryTemplate(retryTemplateDemo);

            log.info("\n");
            retryListener.logStatistics();

            log.info("=".repeat(80));
            log.info("Demo completed successfully!");
            log.info("=".repeat(80));
        };
    }

    private void demonstrateRetryable(RetryableDemo demo) {
        log.info("\n--- 1. @Retryable Annotation Demo ---");
        log.info("Attempting to send notification (will fail 2 times, succeed on 3rd attempt)...");
        demo.sendNotification();
        log.info("Notification sent successfully!");

        log.info("\nAttempting exponential backoff retry...");
        demo.sendWithExponentialBackoff();
        log.info("Exponential backoff completed!");

        log.info("\nAttempting retry on specific exception (TransientNetworkException only)...");
        demo.connectToExternalApi();
        log.info("API connection successful!");
    }

    private void demonstrateConcurrencyLimit(ConcurrencyLimitDemo demo) {
        log.info("\n--- 2. @ConcurrencyLimit Annotation Demo ---");
        log.info("Starting 5 concurrent operations (limit = 2)...");
        demo.runConcurrentOperations();
        log.info("All concurrent operations completed!");
    }

    private void demonstrateRetryTemplate(RetryTemplateDemo demo) {
        log.info("\n--- 3. RetryTemplate Programmatic API Demo ---");
        log.info("Using RetryTemplate with custom retry policy...");
        demo.executeWithRetry();
        log.info("RetryTemplate execution completed!");
    }
}
