package com.example.resilience_features.exception;

public class TransientNetworkException extends RuntimeException {

    public TransientNetworkException(String message) {
        super(message);
    }
}
