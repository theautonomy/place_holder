package com.example.resilience_features.listener;

import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.retry.RetryListener;
import org.springframework.core.retry.RetryPolicy;
import org.springframework.core.retry.Retryable;
import org.springframework.stereotype.Component;

@Component
public class NotificationRetryListener implements RetryListener {

    private static final Logger log = LoggerFactory.getLogger(NotificationRetryListener.class);

    private final AtomicInteger totalRetries = new AtomicInteger(0);
    private final AtomicInteger successfulRecoveries = new AtomicInteger(0);
    private final AtomicInteger finalFailures = new AtomicInteger(0);
    private final ThreadLocal<Integer> attemptCount = ThreadLocal.withInitial(() -> 0);

    @Override
    public void beforeRetry(RetryPolicy policy, Retryable<?> retryable) {
        int currentAttempt = attemptCount.get() + 1;
        attemptCount.set(currentAttempt);
        totalRetries.incrementAndGet();

        log.info(
                "🔁 Retry Listener: Attempt #{} for operation '{}'",
                currentAttempt,
                retryable.getName() != null ? retryable.getName() : "unnamed");
    }

    @Override
    public void onRetrySuccess(RetryPolicy policy, Retryable<?> retryable, Object result) {
        int attempts = attemptCount.get();
        attemptCount.remove();

        if (attempts > 1) {
            successfulRecoveries.incrementAndGet();
            log.info(
                    "✅ Retry Listener: Operation '{}' recovered after {} attempts",
                    retryable.getName() != null ? retryable.getName() : "unnamed",
                    attempts);
        } else {
            log.info(
                    "✅ Retry Listener: Operation '{}' succeeded on first attempt",
                    retryable.getName() != null ? retryable.getName() : "unnamed");
        }
    }

    @Override
    public void onRetryFailure(RetryPolicy policy, Retryable<?> retryable, Throwable throwable) {
        int attempts = attemptCount.get();
        attemptCount.remove();
        finalFailures.incrementAndGet();

        log.error(
                "❌ Retry Listener: Operation '{}' failed after {} attempts - Final error: {}",
                retryable.getName() != null ? retryable.getName() : "unnamed",
                attempts,
                throwable != null ? throwable.getMessage() : "Unknown");
    }

    public void logStatistics() {
        log.info("=".repeat(60));
        log.info("Retry Statistics:");
        log.info("  Total Retries: {}", totalRetries.get());
        log.info("  Successful Recoveries: {}", successfulRecoveries.get());
        log.info("  Final Failures: {}", finalFailures.get());
        log.info("=".repeat(60));
    }

    public void reset() {
        totalRetries.set(0);
        successfulRecoveries.set(0);
        finalFailures.set(0);
        attemptCount.remove();
    }
}
