---
theme: seriph
background: https://cover.sli.dev
title: Slidev Animations Demo
author: Your Name
info: Demonstrates all animation features in Slidev.
routerMode: hash
colorSchema: light
transition: slide-left
---

# Slidev Animations

A live demo of every animation feature

<div class="pt-8 text-gray-400">
  <a href="https://sli.dev/guide/animations" class="underline">sli.dev/guide/animations</a>
</div>


---
layout: intro
---

<AuthorCard />

---
layout: section
---

# Part 1 — Click Animations

`v-click` · `v-after` · `v-clicks` · `.hide` · ranges · presets

---

# v-click

Reveals an element on the next click. Use as a **directive** or **component**.

````md
<div v-click>Revealed on click</div>
<v-click><div>Also revealed on click</div></v-click>
````

<div class="mt-8 space-y-3 text-xl">
  <div class="p-3 bg-gray-100 rounded">Always visible</div>
  <div v-click class="p-3 bg-blue-100 rounded">Revealed on click 1</div>
  <div v-click class="p-3 bg-green-100 rounded">Revealed on click 2</div>
  <div v-click class="p-3 bg-yellow-100 rounded">Revealed on click 3</div>
</div>

---

# v-after

Revealed at the **same click step** as the previous `v-click` — does not add an extra click.

````md
<div v-click>Main point</div>
<div v-after>Revealed together with main point</div>
````

<div class="mt-8 space-y-3 text-xl">
  <div class="p-3 bg-gray-100 rounded">Always visible</div>
  <div v-click class="p-3 bg-blue-100 rounded">Main point (click 1)</div>
  <div v-after class="p-3 bg-blue-50 rounded text-base">↑ Revealed at the same time (v-after)</div>
  <div v-click class="p-3 bg-green-100 rounded">Next point (click 2)</div>
  <div v-after class="p-3 bg-green-50 rounded text-base">↑ Also v-after</div>
</div>

---

# v-clicks

Applies `v-click` to every **direct child** automatically.

````md
<v-clicks>
  <div>Item A</div>
  <div>Item B</div>
  <div>Item C</div>
</v-clicks>
````

<v-clicks class="mt-8 space-y-3 text-xl">
  <div class="p-3 bg-purple-100 rounded">Item A — click 1</div>
  <div class="p-3 bg-purple-100 rounded">Item B — click 2</div>
  <div class="p-3 bg-purple-100 rounded">Item C — click 3</div>
</v-clicks>

---

# v-clicks depth

Use the `depth` prop to reveal **nested list items** level by level.

````md
<v-clicks depth="2">

- Level 1 item
  - Level 2 item
  - Level 2 item

</v-clicks>
````

<v-clicks depth="2" class="mt-6 text-xl">

- First top-level item
  - Nested item A
  - Nested item B
- Second top-level item
  - Nested item C

</v-clicks>

---

# v-clicks every

Use `every` to reveal children in **groups** of N.

````md
<v-clicks :every="2">
  <div>A</div><div>B</div>  <!-- revealed together -->
  <div>C</div><div>D</div>  <!-- revealed together -->
</v-clicks>
````

<v-clicks :every="2" class="mt-8 grid grid-cols-2 gap-3 text-xl">
  <div class="p-3 bg-orange-100 rounded">A — click 1</div>
  <div class="p-3 bg-orange-100 rounded">B — click 1</div>
  <div class="p-3 bg-teal-100 rounded">C — click 2</div>
  <div class="p-3 bg-teal-100 rounded">D — click 2</div>
</v-clicks>

---

# .hide modifier

Element is **visible by default** and disappears on click.

````md
<div v-click.hide>Visible, then disappears on click</div>
````

<div class="mt-8 space-y-3 text-xl">
  <div v-click.hide class="p-3 bg-red-100 rounded">I disappear on click 1</div>
  <div v-click.hide class="p-3 bg-orange-100 rounded">I disappear on click 2</div>
  <div class="p-3 bg-gray-100 rounded">I am always visible</div>
</div>

---

# Enter & Leave ranges

Show an element **only between** two click steps using `[enter, leave]`.

````md
<div v-click="[2, 4]">Visible on clicks 2 and 3, gone on click 4</div>
````

<div class="mt-8 space-y-4 text-xl">
  <div class="p-3 bg-gray-100 rounded">Always visible</div>
  <div v-click="[1, 3]" class="p-3 bg-blue-100 rounded">Visible on clicks 1–2, hidden on click 3</div>
  <div v-click="[2, 4]" class="p-3 bg-green-100 rounded">Visible on clicks 2–3, hidden on click 4</div>
  <div v-click="[3, 5]" class="p-3 bg-yellow-100 rounded">Visible on clicks 3–4, hidden on click 5</div>
  <div class="text-sm opacity-50 mt-2">Keep clicking to watch elements appear and disappear</div>
</div>

---

# Absolute positioning with `at`

Override the click step with an explicit number using the `at` prop.

````md
<div v-click="3">Appears on click 3 regardless of order</div>
````

<div class="mt-8 space-y-3 text-xl">
  <div v-click="3" class="p-3 bg-red-100 rounded">at=3 — appears third</div>
  <div v-click="1" class="p-3 bg-blue-100 rounded">at=1 — appears first</div>
  <div v-click="2" class="p-3 bg-green-100 rounded">at=2 — appears second</div>
</div>

<div class="mt-4 text-sm opacity-50">Note: order in markup doesn't matter — click step is explicit</div>

---

# Relative positioning with `at="+N"`

Trigger N clicks **after the previous** animation.

````md
<div v-click>First</div>
<div v-click at="+2">Two clicks after First</div>
````

<div class="mt-8 space-y-3 text-xl">
  <div v-click class="p-3 bg-blue-100 rounded">First (click 1)</div>
  <div v-click at="+2" class="p-3 bg-green-100 rounded">+2 after First → click 3</div>
  <div v-click at="+1" class="p-3 bg-yellow-100 rounded">+1 after above → click 4</div>
</div>

---

# Click animation presets

Built-in animation styles applied as **modifiers**.

````md
<div v-click.fade>fade</div>
<div v-click.scale>scale</div>
<div v-click.up>up</div>
<div v-click.right>right</div>
````

<div class="mt-6 grid grid-cols-2 gap-4 text-lg">
  <div v-click.fade class="p-3 bg-blue-100 rounded text-center">fade</div>
  <div v-click.scale class="p-3 bg-green-100 rounded text-center">scale</div>
  <div v-click.up class="p-3 bg-yellow-100 rounded text-center">up</div>
  <div v-click.down class="p-3 bg-orange-100 rounded text-center">down</div>
  <div v-click.left class="p-3 bg-purple-100 rounded text-center">left</div>
  <div v-click.right class="p-3 bg-red-100 rounded text-center">right</div>
</div>

---
layout: section
---

# Part 2 — Motion Animations

`v-motion` powered by [@vueuse/motion](https://motion.vueuse.org)

---

# v-motion — basic

Animate element properties on **enter** from an **initial** state.

````md
<div
  v-motion
  :initial="{ x: -100, opacity: 0 }"
  :enter="{ x: 0, opacity: 1 }">
  Slides in from the left
</div>
````

<div class="mt-10 space-y-4">
  <div
    v-motion
    :initial="{ x: -100, opacity: 0 }"
    :enter="{ x: 0, opacity: 1, transition: { duration: 600 } }"
    class="p-4 bg-blue-100 rounded text-xl"
  >
    Slides in from the left
  </div>
  <div
    v-motion
    :initial="{ x: 100, opacity: 0 }"
    :enter="{ x: 0, opacity: 1, transition: { duration: 600, delay: 300 } }"
    class="p-4 bg-green-100 rounded text-xl"
  >
    Slides in from the right (delayed)
  </div>
  <div
    v-motion
    :initial="{ y: 50, opacity: 0, scale: 0.8 }"
    :enter="{ y: 0, opacity: 1, scale: 1, transition: { duration: 600, delay: 600 } }"
    class="p-4 bg-yellow-100 rounded text-xl"
  >
    Fades up and scales in
  </div>
</div>

---

# v-motion — click triggered

Combine `v-motion` with **click states** to animate on demand.

````md
<div
  v-motion
  :initial="{ opacity: 0 }"
  :enter="{ opacity: 1 }"
  :click-1="{ x: 100 }"
  :click-2="{ x: 0, rotate: 360 }">
  Move me with clicks
</div>
````

<div class="mt-12 flex justify-center">
  <div
    v-motion
    :initial="{ opacity: 0, scale: 0.5 }"
    :enter="{ opacity: 1, scale: 1 }"
    :click-1="{ x: 150, transition: { duration: 400 } }"
    :click-2="{ x: -150, transition: { duration: 400 } }"
    :click-3="{ x: 0, rotate: 360, transition: { duration: 600 } }"
    class="p-6 bg-blue-200 rounded-xl text-xl font-bold w-40 text-center cursor-pointer"
  >
    Click me!
  </div>
</div>
<div class="text-center text-sm opacity-50 mt-4">Click to move → click again → click to spin back</div>

---

# v-motion — spring physics

Use **spring** transitions for natural-feeling movement.

````md
:enter="{
  x: 0,
  transition: {
    type: 'spring',
    stiffness: 100,
    damping: 10,
    mass: 1,
  }
}"
````

<div class="mt-8 flex gap-6 justify-center">
  <div class="text-center">
    <div class="text-sm opacity-50 mb-3">stiff spring</div>
    <div
      v-motion
      :initial="{ y: -80, opacity: 0 }"
      :enter="{ y: 0, opacity: 1, transition: { type: 'spring', stiffness: 300, damping: 10 } }"
      class="p-5 bg-blue-200 rounded-xl text-lg w-32 text-center"
    >Bouncy</div>
  </div>
  <div class="text-center">
    <div class="text-sm opacity-50 mb-3">soft spring</div>
    <div
      v-motion
      :initial="{ y: -80, opacity: 0 }"
      :enter="{ y: 0, opacity: 1, transition: { type: 'spring', stiffness: 50, damping: 20, delay: 300 } }"
      class="p-5 bg-green-200 rounded-xl text-lg w-32 text-center"
    >Smooth</div>
  </div>
  <div class="text-center">
    <div class="text-sm opacity-50 mb-3">heavy mass</div>
    <div
      v-motion
      :initial="{ y: -80, opacity: 0 }"
      :enter="{ y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100, damping: 5, mass: 5, delay: 600 } }"
      class="p-5 bg-yellow-200 rounded-xl text-lg w-32 text-center"
    >Heavy</div>
  </div>
</div>

---
layout: section
---

# Part 3 — Slide Transitions

Applied via `transition:` in frontmatter

---
transition: fade
---

# transition: fade

The slide fades in and out between navigation.

```yaml
---
transition: fade
---
```

<div class="mt-8 p-6 bg-blue-50 rounded text-center text-xl">
  Navigate away and back — this slide fades
</div>

---
transition: slide-up
---

# transition: slide-up

The slide enters from the bottom.

```yaml
---
transition: slide-up
---
```

<div class="mt-8 p-6 bg-green-50 rounded text-center text-xl">
  This slide slid up into view
</div>

---
transition: slide-down
---

# transition: slide-down

The slide enters from the top.

```yaml
---
transition: slide-down
---
```

<div class="mt-8 p-6 bg-yellow-50 rounded text-center text-xl">
  This slide slid down into view
</div>

---
transition: slide-left
---

# transition: slide-left

The default — enters from the right, exits to the left.

```yaml
---
transition: slide-left
---
```

<div class="mt-8 p-6 bg-purple-50 rounded text-center text-xl">
  This slide slid in from the right
</div>

---
transition: slide-right
---

# transition: slide-right

Enters from the left — natural for going backwards.

```yaml
---
transition: slide-right
---
```

<div class="mt-8 p-6 bg-red-50 rounded text-center text-xl">
  This slide slid in from the left
</div>

---
transition: fade-out
---

# transition: fade-out

The previous slide fades out; the new one appears instantly.

```yaml
---
transition: fade-out
---
```

<div class="mt-8 p-6 bg-orange-50 rounded text-center text-xl">
  Previous slide faded out to reveal this one
</div>

---

# Directional transitions

Apply **different** transitions for forward vs backward navigation.

```yaml
---
transition: go-forward | go-backward
---
```

Example — slide-left going forward, slide-right going back:

```yaml
---
transition: slide-left | slide-right
---
```

This makes navigation feel natural in both directions.

---

# Custom transitions

Define your own with CSS using Vue's transition class naming convention.

```css
/* slides.css */
.my-transition-enter-active,
.my-transition-leave-active {
  transition: all 0.5s ease;
}
.my-transition-enter-from {
  transform: rotate(-10deg) scale(0.8);
  opacity: 0;
}
.my-transition-leave-to {
  transform: rotate(10deg) scale(0.8);
  opacity: 0;
}
```

```yaml
---
transition: my-transition
---
```

---
layout: cover
background: https://cover.sli.dev
---

# Animation Summary

| Feature | Syntax | Purpose |
|---------|--------|---------|
| `v-click` | `v-click` / `<v-click>` | Reveal on next click |
| `v-after` | `v-after` / `<v-after>` | Reveal with previous click |
| `v-clicks` | `<v-clicks>` | Reveal all children sequentially |
| `.hide` | `v-click.hide` | Disappear on click |
| range | `v-click="[2,4]"` | Show only between two clicks |
| `at` | `v-click="3"` / `at="+2"` | Absolute / relative timing |
| presets | `v-click.scale` | Built-in animation styles |
| `v-motion` | `:initial` `:enter` `:click-N` | Motion animations |
| `transition:` | frontmatter | Slide-level transitions |
| custom | CSS classes | Your own transitions |

---
src: ./pages/author.md
---
