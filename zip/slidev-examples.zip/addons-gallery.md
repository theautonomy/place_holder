---
theme: seriph
background: https://cover.sli.dev
title: Slidev Addon Gallery
author: Your Name
info: A curated tour of the Slidev addon ecosystem.
transition: slide-left
colorSchema: light
routerMode: hash
addons:
  - slidev-addon-excalidraw
  - slidev-addon-qrcode
  - slidev-addon-typed
  - slidev-addon-rabbit
  - slidev-addon-graph
  - "@/slidev-addon-callout"
---

# Slidev Addon Gallery

Live demos of community addons

<div class="pt-8 text-gray-400">
  <a href="https://sli.dev/resources/addon-gallery" class="underline">sli.dev/resources/addon-gallery</a>
</div>


---
layout: intro
---

<AuthorCard />

---

# Installing Addons

Declare them in the frontmatter — Slidev auto-installs on first run.

```yaml
---
addons:
  - slidev-addon-excalidraw
  - slidev-addon-qrcode
  - slidev-addon-typed
  - slidev-addon-rabbit
  - slidev-addon-graph
  - "@/slidev-addon-callout"   # local custom addon
---
```

This deck has **6 addons** installed and running live on the following slides.

---
layout: section
---

# slidev-addon-excalidraw

Draw diagrams with [Excalidraw](https://excalidraw.com) embedded in your slide

---
layout: center
---

# Excalidraw — Live

```html
<Excalidraw drawFilePath="./t.excalidraw" :darkMode="false" :background="false" />
```

<Excalidraw
  drawFilePath="./t.excalidraw"
  class="w-[640px]"
  :darkMode="false"
  :background="false"
/>

---
layout: section
---

# slidev-addon-qrcode

Generate QR codes pointing to any URL

---
layout: two-cols
---

# QRCode — Live

```html
<QRCode data="https://sli.dev" :width="180" :height="180" type="svg" />
```

Point your phone at any of these:

<div class="mt-6 flex gap-8 items-end">
  <div class="text-center">
    <QRCode data="https://sli.dev" :width="150" :height="150" type="svg" />
    <div class="text-xs mt-2 opacity-60">sli.dev</div>
  </div>
  <div class="text-center">
    <QRCode data="https://github.com/slidevjs/slidev" :width="150" :height="150" type="svg" />
    <div class="text-xs mt-2 opacity-60">GitHub</div>
  </div>
</div>

::right::

### Props

| Prop | Default | Description |
|------|---------|-------------|
| `data` | — | URL or text to encode |
| `width` | `200` | Width in px |
| `height` | `200` | Height in px |
| `color` | `#000` | Foreground colour |
| `background` | `#fff` | Background colour |

Drop a QR on your last slide so the audience can follow a link instantly.

---
layout: section
---

# slidev-addon-typed

Typewriter text animations powered by [Typed.js](https://mattboldt.com/demos/typed-js/)

---

# Typed — Live

```html
<Typed :strings="['Hello, World!', 'Hello, Slidev!']" :typeSpeed="60" :loop="true" />
```

<div class="mt-12 text-center text-4xl font-mono">
  <Typed
    :strings="[
      'Hello, World!',
      'Hello, Slidev!',
      'Hello, developers!',
      'Build slides with code.',
    ]"
    :typeSpeed="60"
    :backSpeed="30"
    :loop="true"
  />
</div>

<div class="mt-16 text-center text-2xl text-gray-400 font-mono">
  Framework:&nbsp;
  <Typed
    :strings="['Vue', 'Vite', 'UnoCSS', 'Markdown']"
    :typeSpeed="80"
    :backSpeed="40"
    :loop="true"
  />
</div>

---
layout: section
---

# slidev-addon-rabbit

Presentation timer inspired by [Rabbit](https://rabbit.slide.show) — turns red when time runs out

---

# Rabbit — How it works

No component to place — the addon injects a **rabbit vs turtle** race bar automatically via its own `global-bottom.vue`.

### Activate by adding `?time=N` to the URL

```
http://localhost:3030/?time=30
```

`N` is your presentation duration in **minutes**.

- 🐇 **Rabbit** — tracks your current slide (where you should be)
- 🐢 **Turtle** — tracks elapsed time (where you actually are)
- Keep the rabbit ahead of the turtle to finish on time!

### Optional config in frontmatter

```yaml
---
addons:
  - slidev-addon-rabbit
rabbit:
  slideNum: true   # show current/total slide numbers next to the rabbit
---
```

Try it now: append `?time=1` to your dev URL to see the bar in action.

---
layout: section
---

# slidev-addon-graph

Draggable, interactive node graphs

---

# Graph — Live

```html
<Graph :nodes="nodes" :edges="edges" />
```

<Graph
  :nodes="[
    { id: 'vue',    label: 'Vue 3' },
    { id: 'vite',   label: 'Vite' },
    { id: 'uno',    label: 'UnoCSS' },
    { id: 'md',     label: 'Markdown' },
    { id: 'slidev', label: 'Slidev' },
  ]"
  :edges="[
    { source: 'vue',  target: 'slidev' },
    { source: 'vite', target: 'slidev' },
    { source: 'uno',  target: 'slidev' },
    { source: 'md',   target: 'slidev' },
  ]"
  class="h-72"
/>

<div class="text-sm opacity-60 text-center mt-2">Drag nodes to rearrange</div>

---
layout: section
---

# More Addons
Require installation — shown as code previews

---
layout: two-cols
---

# slidev-addon-asciinema

Embed recorded terminal sessions.

```yaml
addons:
  - slidev-addon-asciinema
```

```html
<Asciinema
  src="./demo.cast"
  :autoPlay="true"
  :loop="true"
  :speed="1.5"
/>
```

Record with `asciinema rec demo.cast`, then drop the file next to your slides.

::right::

# slidev-addon-citations

Academic citations & bibliography.

```yaml
addons:
  - slidev-addon-citations
bibliography: ./references.bib
```

```html
<!-- Inline citation -->
Vue is reactive <Cite key="you2014" />.

<!-- Full bibliography slide -->
<Bibliography />
```

Powered by [citation.js](https://citation.js.org) — supports BibTeX, DOI, and more.

---
layout: two-cols
---

# slidev-addon-p5

Embed interactive [p5.js](https://p5js.org) sketches.

```html
<P5 :sketch="(p) => {
  p.setup = () => p.createCanvas(400, 300)
  p.draw = () => {
    p.background(220)
    p.ellipse(p.mouseX, p.mouseY, 50)
  }
}" />
```

Live generative art — reacts to mouse movement.

::right::

# slidev-addon-tldraw

Embed [tldraw](https://tldraw.com) whiteboards.

```html
<Tldraw
  drawFilePath="./whiteboard.tldr"
  class="w-full h-80"
/>
```

Full tldraw editor embedded — draw live during your talk.

---
layout: section
---

# Custom Addon

Build your own reusable components as a local addon

---
layout: two-cols
---

# Callout — Structure

A local addon lives in a folder next to your slides:

```
slidev-addon-callout/
├── package.json
└── components/
    └── Callout.vue
```

```json
{
  "name": "slidev-addon-callout",
  "keywords": ["slidev-addon", "slidev"]
}
```

Reference it with a relative path:

```yaml
addons:
  - "@/slidev-addon-callout"
```

::right::

# Callout — Live

<Callout type="info" title="What is backpressure?">
  A stream signals upstream to slow down when its internal queue is full.
</Callout>

<Callout type="tip">
  Use <code>pipeThrough()</code> to chain transforms without managing readers manually.
</Callout>

<Callout type="warning">
  <code>getReader()</code> locks the stream — always call <code>releaseLock()</code> in a <code>finally</code> block.
</Callout>

<Callout type="danger" title="Never do this">
  Calling <code>await res.json()</code> on a 500 MB response buffers the entire body in memory.
</Callout>

---
layout: cover
background: https://cover.sli.dev
---

# Addon Summary

| Addon | Live? | What it does |
|-------|-------|-------------|
| `excalidraw` | ✅ | Embed Excalidraw diagrams |
| `qrcode` | ✅ | Generate QR codes |
| `typed` | ✅ | Typewriter animations |
| `rabbit` | ✅ | Rabbit/turtle race bar via `?time=N` URL param |
| `graph` | ✅ | Draggable node graphs |
| `@/slidev-addon-callout` | ✅ | Custom local callout boxes |
| `asciinema` | code | Terminal session replay |
| `citations` | code | Academic bibliography |
| `p5` | code | Generative art / p5.js |
| `tldraw` | code | Whiteboard diagrams |

<div class="mt-4 text-sm text-gray-300">
  <a href="https://sli.dev/resources/addon-gallery" class="underline">sli.dev/resources/addon-gallery</a>
  ·
  <a href="https://www.npmjs.com/search?q=keywords:slidev-addon" class="underline">All addons on NPM</a>
</div>

---
src: ./pages/author.md
---
