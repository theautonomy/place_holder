---
theme: ./slidev-theme-codelab
title: Building a Scalable API
repo: api-service
author: dev@example.com
date: 2024-04-16
branch: feat/rate-limiting
version: 2.4.0
lang: TypeScript
tags:
  - TypeScript
  - Node.js
  - Architecture
routerMode: hash
---

# Building a *Scalable* API

A deep dive into rate limiting, caching and observability


---
layout: intro
---

<AuthorCard />

---
layout: section
sectionNumber: "01"
---

# *Architecture* Overview

## Layers, contracts and data flow

---
layout: full
---

# *System* Architecture

```mermaid {theme: 'dark'}
graph TB
  subgraph Client
    A[Browser / Mobile]
    B[Third-party SDK]
  end

  subgraph Edge
    C[CDN / WAF]
    D[Rate Limiter]
  end

  subgraph API Gateway
    E[Auth Middleware]
    F[Router]
  end

  subgraph Services
    G[User Service]
    H[Order Service]
    I[Notification Service]
  end

  subgraph Data
    J[(PostgreSQL)]
    K[(Redis Cache)]
    L[(Message Queue)]
  end

  A --> C
  B --> C
  C --> D
  D --> E
  E --> F
  F --> G & H & I
  G & H --> J
  G & H --> K
  I --> L
```

---
layout: full
---

# *Request* Lifecycle

```mermaid {theme: 'dark'}
sequenceDiagram
  participant C as Client
  participant R as Rate Limiter
  participant A as Auth
  participant S as Service
  participant DB as Database
  participant Cache as Redis

  C->>R: POST /api/orders
  R->>R: Check token bucket
  alt Over limit
    R-->>C: 429 Too Many Requests
  else Within limit
    R->>A: Forward request
    A->>A: Verify JWT
    A->>S: Authenticated request
    S->>Cache: GET order:userId
    alt Cache hit
      Cache-->>S: Cached data
    else Cache miss
      S->>DB: SELECT * FROM orders
      DB-->>S: Result rows
      S->>Cache: SET order:userId TTL 60s
    end
    S-->>C: 200 OK
  end
```

---
layout: section
sectionNumber: "02"
---

# *Rate* Limiting

## Token bucket · Sliding window · Redis Lua scripts

---
layout: code-demo
paneLabel: How it works
---

# Token Bucket Implementation

```ts {all|1-8|10-20|22-30}
interface BucketConfig {
  capacity: number      // max tokens
  refillRate: number    // tokens per second
  refillInterval: number // ms between refills
}

const BUCKET_KEY = (userId: string) =>
  `rate:bucket:${userId}`

async function consumeToken(
  redis: Redis,
  userId: string,
  config: BucketConfig,
): Promise<{ allowed: boolean; remaining: number }> {
  const key = BUCKET_KEY(userId)
  const now = Date.now()

  // Atomic Lua script — no race conditions
  const result = await redis.eval(
    LUA_CONSUME_TOKEN, 1, key,
    config.capacity, config.refillRate,
    config.refillInterval, now,
  ) as [number, number]

  return {
    allowed:   result[0] === 1,
    remaining: result[1],
  }
}
```

::right::

## Why token bucket?

Allows short **bursts** above average rate — natural for real usage patterns.

## Properties

- **Capacity** — max burst size
- **Refill rate** — sustained throughput
- **Atomic** — Lua script runs as single Redis command

## Response headers

```http
HTTP/1.1 200 OK
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 43
X-RateLimit-Reset: 1713312000
Retry-After: 12
```

## Error response

```json
{
  "error": "rate_limit_exceeded",
  "retryAfter": 12
}
```

---
layout: comparison
beforeLabel: Naive — race condition
afterLabel: Fixed — Lua atomic script
---

# Race Condition in Rate Limiting

::right::

```lua
-- rate_limit.lua
-- Runs atomically in Redis — no race conditions

local key      = KEYS[1]
local capacity = tonumber(ARGV[1])
local rate     = tonumber(ARGV[2])
local interval = tonumber(ARGV[3])
local now      = tonumber(ARGV[4])

local bucket = redis.call('HMGET', key,
  'tokens', 'lastRefill')

local tokens    = tonumber(bucket[1]) or capacity
local lastRefill = tonumber(bucket[2]) or now

-- Refill tokens based on elapsed time
local elapsed = math.max(0, now - lastRefill)
local refilled = math.floor(elapsed / interval) * rate
tokens = math.min(capacity, tokens + refilled)

-- Try to consume one token
if tokens >= 1 then
  tokens = tokens - 1
  redis.call('HMSET', key,
    'tokens', tokens, 'lastRefill', now)
  redis.call('EXPIRE', key, 3600)
  return {1, tokens}
end
return {0, 0}
```

```ts
// ❌ GET then SET — two round trips
const tokens = await redis.get(key)
if (tokens > 0) {
  // another request sneaks in here!
  await redis.set(key, tokens - 1)
  return { allowed: true }
}
return { allowed: false }
```

---
layout: section
sectionNumber: "03"
---

# *Caching* Strategy

## Cache-aside · Write-through · TTL design

---
layout: two-cols
---

# Cache-Aside Pattern

```ts
async function getUser(id: string) {
  // 1. Check cache first
  const cached = await redis.get(
    `user:${id}`
  )
  if (cached) {
    return JSON.parse(cached)
  }

  // 2. Fetch from DB on miss
  const user = await db.users.findById(id)

  // 3. Populate cache
  await redis.setex(
    `user:${id}`,
    300,             // TTL: 5 minutes
    JSON.stringify(user),
  )
  return user
}
```

::right::

# Cache Invalidation

```ts
async function updateUser(
  id: string,
  patch: Partial<User>,
) {
  // Update DB first (source of truth)
  const updated = await db.users.update(
    { where: { id } },
    { data: patch },
  )

  // Invalidate — next read re-fetches
  await redis.del(`user:${id}`)

  // Also invalidate list caches
  await redis.del(`users:list:*`)

  return updated
}
```

## TTL Strategy

| Data type | TTL | Reason |
|-----------|-----|--------|
| User profile | 5 min | Low churn |
| Session token | 24 hr | Auth lifetime |
| Product catalog | 1 hr | Infrequent updates |
| Feed / timeline | 30 sec | High velocity |

---
layout: terminal
title: api-service — zsh
user: deploy
host: prod-01
path: ~/api-service
prompt: npm run benchmark
---

## Benchmark results

> ✓  Rate limiter: **42,000 req/s** (p99: 1.2ms)

> ✓  Cache hit path: **18,000 req/s** (p99: 3.1ms)

> ✓  Cache miss path: **4,200 req/s** (p99: 24ms)

> ✓  Memory usage: **128 MB** RSS

Running load test against staging...

- Concurrency: **500 connections**
- Duration: **60 seconds**
- Target: **GET /api/users/:id**

> ✓  0 errors · 0 timeouts

---
layout: section
sectionNumber: "04"
---

# *Observability*

## Structured logging · Metrics · Distributed tracing

---
layout: code-demo
paneLabel: What you get
---

# Structured Logging with Pino

```ts {all|3-12|14-24}
import pino from 'pino'

const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  formatters: {
    level: (label) => ({ level: label }),
  },
  serializers: {
    req:  pino.stdSerializers.req,
    err:  pino.stdSerializers.err,
  },
})

// Middleware — add request context
app.use((req, _res, next) => {
  req.log = logger.child({
    requestId: req.headers['x-request-id'],
    userId:    req.user?.id,
    path:      req.path,
    method:    req.method,
  })
  next()
})

// Usage
req.log.info({ orderId }, 'order.created')
req.log.error({ err }, 'db.query.failed')
```

::right::

## Log output (JSON)

```json
{
  "level": "info",
  "time": 1713312000000,
  "requestId": "req_abc123",
  "userId": "usr_xyz",
  "path": "/api/orders",
  "method": "POST",
  "msg": "order.created",
  "orderId": "ord_001"
}
```

## Why structured logs?

- Machine-readable → easy to query
- `requestId` ties a full trace together
- Ship to **Datadog / Loki / CloudWatch** with zero parsing

## Log levels

| Level | When |
|-------|------|
| `error` | Requires action |
| `warn` | Unexpected but handled |
| `info` | Business events |
| `debug` | Dev / troubleshooting |

---
layout: full
---

# *Metrics* Dashboard

```mermaid {theme: 'dark'}
graph LR
  subgraph Application
    A[Express app]
    B[prom-client]
    A -->|instrument| B
  end

  subgraph Scrape
    C[Prometheus]
    B -->|/metrics every 15s| C
  end

  subgraph Visualise
    D[Grafana]
    C -->|query| D
  end

  subgraph Alert
    E[Alertmanager]
    F[PagerDuty]
    C -->|rules| E
    E --> F
  end

  subgraph Key Metrics
    G["http_request_duration_seconds (histogram)"]
    H["rate_limit_rejected_total (counter)"]
    I["cache_hit_ratio (gauge)"]
    J["db_query_duration_seconds (histogram)"]
  end
```

---
layout: comparison
beforeLabel: No error boundaries
afterLabel: Resilient error handling
---

# Production-Grade Error Handling

```ts
// ❌ Unhandled promise rejection
// crashes the whole process

app.get('/users/:id', async (req, res) => {
  const user = await db.find(req.params.id)
  res.json(user)
})

// ❌ No distinction between
// client errors and server errors

app.use((err, req, res, next) => {
  res.status(500).json({
    error: err.message
  })
})
```

::right::

```ts
// ✅ Typed error classes
class AppError extends Error {
  constructor(
    public statusCode: number,
    public code: string,
    message: string,
  ) { super(message) }
}

// ✅ Async wrapper — never leaks
const asyncHandler = (fn: Handler) =>
  (req: Request, res: Response, next: NextFn) =>
    Promise.resolve(fn(req, res, next))
      .catch(next)

app.get('/users/:id',
  asyncHandler(async (req, res) => {
    const user = await db.find(req.params.id)
    if (!user) throw new AppError(
      404, 'user_not_found', 'User not found',
    )
    res.json(user)
  }))

// ✅ Global handler classifies errors
app.use((err, _req, res, _next) => {
  const status = err instanceof AppError
    ? err.statusCode : 500
  res.status(status).json({
    error: err.code ?? 'internal_error',
    message: err.message,
  })
})
```

---
layout: terminal
title: ci/cd pipeline — GitHub Actions
user: github-actions
host: runner
path: ~/workspace
prompt: pnpm test && pnpm build
---

## Test suite

> ✓  Unit tests          **312 passed** (4.2s)

> ✓  Integration tests   **84 passed**  (18.1s)

> ✓  E2E tests           **26 passed**  (42s)

> ✓  Coverage            **94.2%** lines

## Build

> ✓  Type check          **0 errors**

> ✓  Lint                **0 warnings**

> ✓  Bundle              **dist/** (1.4 MB)

## Deploy

> ✓  Image built         **api-service:2.4.0**

> ✓  Pushed to registry  **ghcr.io/org/api-service**

> ✓  Deployed to         **prod-01, prod-02, prod-03**

---
layout: section
sectionNumber: "fin"
---

# *Summary*

## Rate limit → Cache → Log → Measure

---

# Key Takeaways

## Rate Limiting
- Token bucket for burst-tolerant limits
- Lua scripts for atomicity — no race conditions
- Return `Retry-After` header on 429

## Caching
- Cache-aside keeps DB as source of truth
- Always invalidate on write
- Design TTLs per data volatility

## Observability
- Structured JSON logs — ship to any backend
- Instrument with `prom-client` — scrape with Prometheus
- Tie everything with a `requestId`

## Error Handling
- Typed `AppError` to distinguish 4xx vs 5xx
- Async wrapper to prevent unhandled rejections
- Never leak internal details to clients

---
layout: terminal
title: Thank you
user: dev
host: localhost
path: ~
prompt: ""
---

## Resources

- **Source code** — `github.com/example/api-service`
- **Docs** — `docs.example.com`
- **Slides** — built with [Slidev](https://sli.dev) + `slidev-theme-codelab`

## Questions?

- Reach out: `dev@example.com`
- Twitter / X: `@example_dev`

---
src: ./pages/author.md
---
