---
theme: ./slidev-theme-devshow
title: Web Streams API
author: Wei
date: 2026-04-16
repo: web-streams-demo
routerMode: hash
addons:
  - slidev-addon-excalidraw
---

::badges::
<span class="badge badge-blue">Web Platform</span>
<span class="badge badge-teal">Stage: Baseline</span>
<span class="badge badge-mauve">TypeScript Ready</span>

# *Web Streams* API

::subtitle::

Process data as it arrives — no waiting for the full payload.

::code::

```typescript
const res = await fetch('/api/large-dataset')
const reader = res.body!.getReader()
const decoder = new TextDecoder()

while (true) {
  const { done, value } = await reader.read()
  if (done) break
  process(decoder.decode(value))
}
```


---
layout: intro
---

<AuthorCard />

---
layout: section
number: "01"
label: The Problem
---

# *Loading* Everything At Once

::description::

Why buffering a 500 MB JSON response before processing it is the wrong default.

---
layout: changelog
title: Fetching a large dataset
beforeLabel: "❌  Buffer-then-parse"
afterLabel: "✅  Stream-then-parse"
---

::before::

```typescript
// Entire response must arrive before
// we can read a single row
async function loadUsers() {
  const res = await fetch('/api/users')

  // Waits for all 500 MB to download
  const data = await res.json()

  // Now we can iterate — but we've been
  // blocking the UI the whole time
  for (const user of data.users) {
    renderRow(user)
  }
}
```

::after::

```typescript
// Rows appear on screen as chunks arrive
async function streamUsers() {
  const res = await fetch('/api/users')
  const stream = res.body!
    .pipeThrough(new TextDecoderStream())
    .pipeThrough(new JSONLinesStream())

  // Process each row the moment it lands
  for await (const user of stream) {
    renderRow(user)
  }
}
```

---
layout: section
number: "02"
label: Core Concepts
---

# The *Three* Stream Types

::description::

ReadableStream · WritableStream · TransformStream — a composable pipeline.

---
layout: diagram
---

::title::

# Stream *Pipeline*

```mermaid {theme: 'dark'}
flowchart LR
  SRC["📡 Source\n(fetch / file / socket)"]
  RS["ReadableStream\ngetReader()"]
  TS1["TransformStream\nTextDecoder"]
  TS2["TransformStream\nJSONLines parser"]
  WS["WritableStream\nUI renderer"]

  SRC -->|bytes| RS
  RS  -->|Uint8Array chunks| TS1
  TS1 -->|string chunks| TS2
  TS2 -->|parsed rows| WS

  style RS  fill:#313244,stroke:#cba6f7,color:#cdd6f4
  style TS1 fill:#313244,stroke:#94e2d5,color:#cdd6f4
  style TS2 fill:#313244,stroke:#94e2d5,color:#cdd6f4
  style WS  fill:#313244,stroke:#a6e3a1,color:#cdd6f4
```

::caption::

Each stage is independently composable — swap any transform without touching the rest of the pipeline.

---
layout: feature
---

::badges::
<span class="badge badge-mauve">ReadableStream</span>

::name::

# `ReadableStream`

::desc::

The source of a pipeline. Pull chunks on demand via `getReader()`, or pipe directly into a transform or writer.

::extra::

- `getReader()` — manual chunk-by-chunk pull
- `pipeTo(writable)` — connect to a sink
- `pipeThrough(transform)` — chain a transform
- `tee()` — split into two independent streams

::right::

```typescript
const stream = new ReadableStream<string>({
  start(controller) {
    controller.enqueue('hello')
    controller.enqueue(' world')
    controller.close()
  }
})

const reader = stream.getReader()
let result = ''

while (true) {
  const { done, value } = await reader.read()
  if (done) break
  result += value     // 'hello world'
}
```

---
layout: feature
---

::badges::
<span class="badge badge-teal">TransformStream</span>
<span class="badge badge-blue">Duplex</span>

::name::

# `TransformStream`

::desc::

A readable/writable pair. Reads from the writable side, transforms each chunk, and emits to the readable side.

::extra::

- `writable` — the input side (sink)
- `readable` — the output side (source)
- Chainable via `.pipeThrough()`
- Built-ins: `TextEncoderStream`, `TextDecoderStream`

::right::

```typescript
class UpperCaseStream extends TransformStream<string, string> {
  constructor() {
    super({
      transform(chunk, controller) {
        controller.enqueue(chunk.toUpperCase())
      }
    })
  }
}

const result = await new Response(
  readable
    .pipeThrough(new TextDecoderStream())
    .pipeThrough(new UpperCaseStream())
).text()
```

---
layout: split
leftW: "1fr"
rightW: "1fr"
---

::title::

# Real-World: *Streaming JSON Lines*

::left::

```typescript
// Transform: split chunks on newlines
class JSONLinesStream
  extends TransformStream<string, unknown>
{
  constructor() {
    let buf = ''
    super({
      transform(chunk, ctrl) {
        buf += chunk
        const lines = buf.split('\n')
        buf = lines.pop()!       // keep partial line
        for (const line of lines) {
          if (line.trim())
            ctrl.enqueue(JSON.parse(line))
        }
      },
      flush(ctrl) {
        if (buf.trim())
          ctrl.enqueue(JSON.parse(buf))
      }
    })
  }
}
```

::right::

```typescript
// Usage: stream a newline-delimited JSON endpoint
async function* streamRows<T>(url: string) {
  const res = await fetch(url)
  if (!res.body) throw new Error('No body')

  const stream = res.body
    .pipeThrough(new TextDecoderStream())
    .pipeThrough(new JSONLinesStream())

  const reader = stream.getReader()
  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) return
      yield value as T
    }
  } finally {
    reader.releaseLock()
  }
}

// Consumer
for await (const row of streamRows<User>('/api/users')) {
  appendRow(row)   // UI updates live
}
```

---
layout: diagram
---

::title::

# Backpressure & *Error Propagation*

```mermaid {theme: 'dark', scale: 0.75}
sequenceDiagram
  participant Src  as ReadableStream
  participant Trx  as TransformStream
  participant Snk  as WritableStream

  Src  ->> Trx : enqueue(chunk)
  Trx  ->> Snk : enqueue(transformed)
  Note over Snk: consumer slow → queue fills
  Snk  -->> Trx : desiredSize < 0  (backpressure)
  Trx  -->> Src : desiredSize < 0  (backpressure)
  Note over Src: source pauses pull

  Note over Trx: error in transform
  Trx  -x  Snk : error(reason)
  Snk  -->> Src : cancel(reason)
```

::caption::

Backpressure flows upstream automatically — the source only produces as fast as the consumer can handle.

---
layout: default
---

# Browser & Runtime *Support*

| API | Chrome | Firefox | Safari | Node.js |
|-----|--------|---------|--------|---------|
| `ReadableStream` | 43 | 65 | 10.1 | 16.5 |
| `WritableStream` | 59 | 100 | 14.1 | 16.5 |
| `TransformStream` | 67 | 102 | 14.1 | 16.5 |
| `ReadableStream` async iterator | 124 | 110 | 16 | 16.5 |
| `pipeThrough` / `pipeTo` | 59 | 100 | 14.1 | 16.5 |
| `TextDecoderStream` | 71 | 105 | 14.1 | 16.5 |

## TypeScript

The DOM typings ship `ReadableStream<R>` as a generic — no extra `@types` needed. For Node.js, use `node:stream/web` or the global exposed since Node 18.

---

# *Key Takeaways*

## When to use Streams

- Response bodies larger than ~1 MB that can be processed incrementally
- Server-Sent Events / chunked transfer endpoints
- File reading (`File.stream()`, `Blob.stream()`)
- Service Worker response synthesis

## The one-liner mental model

> `fetch().body` is already a `ReadableStream` — you've always had it, now you can use it.

## Further reading

- `ReadableStream` + `for await…of` is the cleanest consumer pattern (Chrome 124+, Node 16+)
- For Node.js: `Readable.toWeb()` / `Writable.toWeb()` bridge native streams
- `CompressionStream` / `DecompressionStream` are free transform stages

---
layout: cover
---

::badges::
<span class="badge badge-blue">Web Platform</span>
<span class="badge badge-teal">Baseline 2024</span>

# *Web Streams* API

::subtitle::

Composable, backpressure-aware, already in your browser — go stream something.

::code::

```typescript
// The full pipeline in four lines
const res = await fetch('/api/data.ndjson')
for await (const row of res.body!
  .pipeThrough(new TextDecoderStream())
  .pipeThrough(new JSONLinesStream())) {
  render(row)
}
```

---
src: ./pages/author.md
---
