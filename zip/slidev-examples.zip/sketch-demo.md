---
theme: ./slidev-theme-sketch
title: Team Retrospective
author: Wei
date: 2026-04-16
routerMode: hash
addons:
  - slidev-addon-excalidraw
---

# Our *Sprint 12* Retro

::subtitle::

What went well · what didn't · what's next


---
layout: intro
---

<AuthorCard />

---
layout: section
sectionNumber: "01"
---

# *What* Went Well

## High-fives all around ✦

---

# Wins This Sprint

## Shipped 🚀
- Launched the new **onboarding flow** — conversion up 18%
- Search is *3× faster* after the index rewrite
- Zero P1 incidents for 14 days straight

## Team ✦
- New retro format → better discussion
- Pair-programming sessions helped unblock *3 critical PRs*

## Delivery
- Sprint goal met on time for the **second** sprint in a row
- All acceptance tests passing before Friday demo

---
layout: image-right
image: https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=900&q=80
---

# What Went Well

## Engineering
- *Feature flags* let us ship safely
- Automated deploys saved ~4 hrs per week
- Code review turnaround < **24 hours**

## Collaboration
- Daily standups shorter and more focused
- Design ↔ Dev handoff improved with **Figma tokens**
- Docs actually got written this time!

---
layout: two-cols
---

# Metrics

| Metric | Target | Actual |
|--------|--------|--------|
| Velocity | 48 pts | **52 pts** |
| Bug rate | < 3 | **2** |
| Test coverage | 80% | **84%** |
| Deploy freq | 3/wk | **5/wk** |

## Highlights

> "The new CI pipeline is a game-changer — builds went from 12 min to 4 min."
> — Team feedback

::right::

# Sprint Velocity

<Excalidraw
  drawFilePath="./velocity-chart.excalidraw"
  class="w-full"
  :darkMode="false"
  :background="false"
/>

---
layout: section
sectionNumber: "02"
---

# *What* Could Improve

## Honest feedback ✶

---
layout: image-right
image: https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=900&q=80
---

# Pain Points

## Process
- Sprint planning overruns by ~30 min each time
- *Too many context switches* — need focus blocks
- Ticket descriptions still lack acceptance criteria

## Technical Debt
- Auth module is getting unwieldy → needs a **refactor spike**
- Mobile performance regressions slipping through
- 3 flaky tests that keep breaking CI

---
layout: two-cols
---

# Root Causes

## Context switching
- 6+ Slack channels for one feature
- Unplanned interruptions **4 per person/day**
- No dedicated *deep work* time blocked

## Planning gaps
- Acceptance criteria added *after* coding starts
- Estimates not revisited mid-sprint
- Tech debt backlog not sized or prioritised

::right::

# Proposed Fixes

## Quick wins (this sprint)
- → Block 10–12 as **no-meeting focus time**
- → Acceptance criteria template in Jira
- → On-call doc updated by Friday

## Bigger changes (next quarter)
- → Auth module refactor — 2-week spike
- → Mobile perf budget added to CI
- → Async-first communication guidelines

---
layout: section
sectionNumber: "03"
---

# *Action* Items

## Who does what by when ✦

---

# Sprint 13 Commitments

## Immediate

| Action | Owner | Due |
|--------|-------|-----|
| Focus time blocks on calendar | *All* | Mon |
| AC template in Jira | Wei | Tue |
| On-call rotation doc | Li | Wed |
| Fix 3 flaky tests | Dev team | Fri |

## Ongoing

- **Weekly:** 5-min retro health check at standup
- **Monthly:** Tech-debt grooming session (1 hr)
- **Async first:** Decisions documented in Notion within 24 hrs

---
layout: whiteboard
---

::title::

# *Retrospective* Board

<Excalidraw
  drawFilePath="./retro-board.excalidraw"
  class="w-[600px]"
  :darkMode="false"
  :background="false"
/>

---
layout: whiteboard
---

::title::

# *Process* Flow

```mermaid {theme: 'default'}
graph LR
  A[Sprint Planning] --> B[Daily Standups]
  B --> C[Development]
  C --> D[Code Review]
  D --> E{CI passes?}
  E -- ✓ --> F[Deploy to Staging]
  E -- ✗ --> C
  F --> G[Demo & Retro]
  G --> A

  style A fill:#dbe4ff,stroke:#3b5bdb
  style G fill:#d3f9d8,stroke:#2f9e44
  style E fill:#fff9db,stroke:#ffd43b
```

---
layout: cover
image: https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1200&q=80
---

# *Thanks!* See you next sprint ✦

::subtitle::

Retro facilitated with ✏ · Built with Slidev + sketch theme

---
src: ./pages/author.md
---
