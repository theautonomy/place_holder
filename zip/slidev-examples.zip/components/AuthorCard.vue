<script setup lang="ts">
import { parse } from 'yaml'
import raw from '../pages/me.md?raw'

const fm = raw.match(/^---\r?\n([\s\S]+?)\r?\n---/)
const data = fm ? parse(fm[1]) : {}

const tagColors = [
  { bg: '#dbeafe', color: '#1d4ed8', border: '#bfdbfe' },
  { bg: '#dcfce7', color: '#15803d', border: '#bbf7d0' },
  { bg: '#ede9fe', color: '#6d28d9', border: '#ddd6fe' },
  { bg: '#fef9c3', color: '#854d0e', border: '#fef08a' },
  { bg: '#fee2e2', color: '#b91c1c', border: '#fecaca' },
]
</script>

<template>
  <div style="display:grid;grid-template-columns:auto 1fr;gap:2.5rem;align-items:center;max-width:780px">

    <!-- Avatar + links -->
    <div style="display:flex;flex-direction:column;align-items:center;gap:1rem">
      <div :style="{
        width: '96px', height: '96px', borderRadius: '50%',
        background: `linear-gradient(${data.avatarGradient ?? '135deg, #3b82f6, #8b5cf6'})`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: '2.6rem', fontWeight: '700', color: '#fff',
        boxShadow: '0 4px 20px rgba(139,92,246,0.35)',
      }">{{ data.avatar ?? data.name?.[0] ?? '?' }}</div>

      <div style="display:flex;flex-direction:column;align-items:center;gap:0.4rem;font-size:0.82rem;opacity:0.6">
        <a v-if="data.email" :href="`mailto:${data.email}`"
           style="display:flex;align-items:center;gap:0.3rem;text-decoration:none;color:inherit">
          <span>✉</span> {{ data.email }}
        </a>
        <a v-if="data.github" :href="`https://github.com/${data.github}`" target="_blank"
           style="display:flex;align-items:center;gap:0.3rem;text-decoration:none;color:inherit">
          <span>⟐</span> github.com/{{ data.github }}
        </a>
      </div>
    </div>

    <!-- Bio -->
    <div>
      <div style="font-size:2rem;font-weight:700;line-height:1.15;margin-bottom:0.2rem">
        {{ data.name }}
      </div>
      <div style="font-size:1.05rem;opacity:0.55;margin-bottom:1rem;letter-spacing:0.02em">
        {{ data.title }}
      </div>
      <div style="font-size:0.95rem;line-height:1.65;opacity:0.75;margin-bottom:1.2rem">
        {{ data.bio }}
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:0.45rem">
        <span v-for="(tag, i) in (data.tags ?? [])" :key="tag" :style="{
          padding: '0.2em 0.7em',
          borderRadius: '4px',
          fontSize: '0.78rem',
          fontWeight: '600',
          background: tagColors[i % tagColors.length].bg,
          color: tagColors[i % tagColors.length].color,
          border: `1px solid ${tagColors[i % tagColors.length].border}`,
        }">{{ tag }}</span>
      </div>
    </div>

  </div>
</template>
