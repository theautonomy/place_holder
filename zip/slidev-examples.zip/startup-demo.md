---
theme: ./slidev-theme-launchpad
title: Launchpad — The Next Big Thing
company: LAUNCHPAD
author: Alex Rivera
role: Co-founder & CEO
date: 2024
background: https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1920&q=80
routerMode: hash
---

# The Next Big Thing

Transforming how teams build products


---
layout: intro
---

<AuthorCard />

---
layout: intro
---

## About Alex

Alex is a second-time founder with 10 years of experience building developer tools used by over 500,000 engineers globally.

Previously:
- VP Engineering at Stripe
- Co-founder of DevFlow (acquired 2021)
- Open source contributor · 12k GitHub stars

**Reach out:** alex@launchpad.io

---
layout: image-right
image: https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=900&q=80
---

# The Problem

Every team we interviewed said the same thing:

- **Too many tools** — Jira, Notion, Linear, GitHub, Slack, Figma... all disconnected
- **Context switching** kills deep work — engineers lose 2.5 hrs/day switching apps
- **No single source of truth** — PMs, engineers and designers always out of sync
- **Onboarding takes weeks** — new hires can't find anything

> "We spend more time managing our tools than building the product."
>
> — Engineering Manager, Series B startup

---
layout: fact
---

## $47B
Wasted annually on productivity lost to disconnected tooling

---
layout: section
---

# Our Solution

## One workspace. Every context. Zero friction.

---
layout: image-left
image: https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80
---

# Introducing Launchpad

A unified workspace that connects your entire build cycle — from idea to deploy.

```
Idea → Spec → Design → Build → Ship → Measure
  ↑_______________________________________|
```

- **Unified context** — every PR, design, and decision in one thread
- **AI-native** — surfaces the right context at the right moment
- **Zero setup** — connects to your existing tools in minutes
- **Real-time sync** — everyone always sees the latest state

---
layout: two-cols
---

## Before Launchpad

- Open Slack to find context
- Switch to Notion for the spec
- Open Jira for the ticket
- Check Figma for the design
- Read 3 PRs to understand the change
- Still not sure what the decision was

**Result:** 2.5 hours lost. Every day. Per engineer.

::right::

## After Launchpad

- Open one thread
- See: spec, design, decisions, code, metrics
- Understand in 30 seconds
- Start building

**Result:** Ship 40% faster. Onboard in hours, not weeks.

---
layout: statement
---

## Ship ideas, not *status updates*.

---
layout: section
---

# Traction

## Early numbers speak for themselves

---
layout: fact
---

## 3,200+
Teams on the waitlist

---
layout: fact
---

## 40%
Faster time-to-ship reported by beta users

---
layout: fact
---

## $2.4M
Pre-seed raised · Accel & YC-backed

---
layout: image-right
image: https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=900&q=80
---

# Who's Already Building With Us

<div style="display:flex;flex-direction:column;gap:1rem;margin-top:1rem">
  <div style="background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.2);border-radius:12px;padding:1rem 1.2rem">
    <div style="font-weight:700;color:#a5b4fc;font-size:1rem">Vercel</div>
    <div style="font-size:0.85rem;color:#6b7280;margin-top:0.2rem">"Onboarding time cut from 3 weeks to 3 days"</div>
  </div>
  <div style="background:rgba(139,92,246,0.1);border:1px solid rgba(139,92,246,0.2);border-radius:12px;padding:1rem 1.2rem">
    <div style="font-weight:700;color:#c084fc;font-size:1rem">Linear</div>
    <div style="font-size:0.85rem;color:#6b7280;margin-top:0.2rem">"Finally, a tool engineers actually use"</div>
  </div>
  <div style="background:rgba(236,72,153,0.1);border:1px solid rgba(236,72,153,0.2);border-radius:12px;padding:1rem 1.2rem">
    <div style="font-weight:700;color:#f9a8d4;font-size:1rem">Loom</div>
    <div style="font-size:0.85rem;color:#6b7280;margin-top:0.2rem">"Replaced 4 tools. Saved $180k/yr"</div>
  </div>
</div>

---
layout: section
---

# Business Model

## Simple pricing. Obvious ROI.

---
layout: image-left
image: https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80
---

# Unit Economics

| Plan | Price | For |
|------|-------|-----|
| **Starter** | Free | Up to 5 engineers |
| **Team** | $18/seat/mo | Growing teams |
| **Enterprise** | Custom | 200+ seats |

- **CAC:** $210 — product-led, low sales touch
- **LTV:** $4,800 — 24-month avg contract
- **LTV:CAC:** 22×
- **Net revenue retention:** 142%

Expansion revenue from seats makes this a compounding business.

---
layout: section
---

# The Ask

---
layout: image-right
image: https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=900&q=80
---

# Raising $8M Series A

**Use of funds over 18 months:**

- **50% — Engineering** — 12 engineers, ship the roadmap
- **25% — Go-to-Market** — 4 AEs, 2 CSMs, demand gen
- **15% — Infrastructure** — scale to 100k teams
- **10% — Operations** — legal, finance, recruiting

**Milestones we'll hit:**
- 10,000 paying teams
- $3M ARR
- Series B ready

---
layout: quote
---

The best time to build the future of work was 10 years ago.

The second best time is now.

— Alex Rivera, Co-founder

---
layout: end
---

# Let's Build Together

alex@launchpad.io · launchpad.io · @alexrivera

---
src: ./pages/author.md
---
