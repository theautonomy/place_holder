---
name: Wei Li
title: Senior Developer · Web Platform
bio: Building developer tools, open-source libraries, and Slidev presentations. Passionate about web standards, TypeScript, and great developer experience.
avatar: W
avatarGradient: "135deg, #3b82f6 0%, #8b5cf6 100%"
email: weili.mail@gmail.com
github: wei
tags:
  - TypeScript
  - Vue 3
  - Web APIs
  - Slidev
  - Open Source
---
