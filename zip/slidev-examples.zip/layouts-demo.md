---
theme: seriph
background: https://cover.sli.dev
title: Slidev Built-in Layouts Demo
info: |
  Demonstrates every built-in layout available in Slidev.
  See https://sli.dev/builtin/layouts
transition: slide-left
routerMode: hash
---

# Slidev Built-in Layouts

A tour of all 19 built-in layouts + 1 custom

<div class="pt-8 text-gray-400">
  Press <kbd>Space</kbd> or <kbd>→</kbd> to advance
</div>


---
layout: intro
---

<AuthorCard />

---
layout: section
---

# Part 1
## Structural Layouts

`cover` · `intro` · `section` · `end`

---

# 1. `cover`

The **cover** layout is the default for the very first slide.  
It renders an optional background image and centres the title/subtitle.

```yaml
---
layout: cover
background: https://cover.sli.dev
---

# My Presentation
A subtitle goes here
```

> The opening slide of this deck already uses `cover`.

---
layout: cover
background: https://cover.sli.dev
---

# `cover` — Live Example

A full-bleed background with centred title & subtitle

---

# 2. `intro`

Use **intro** to introduce yourself or the topic at the start of a talk.  
It provides dedicated areas for a title, description, and author.

```yaml
---
layout: intro
---

# Jane Doe
Software Engineer · Acme Corp

<div class="leading-8 opacity-80">
  Building developer tools since 2010.<br>
  Passionate about DX and open source.
</div>
```

---
layout: intro
---

# Jane Doe
Software Engineer · Acme Corp

<div class="leading-8 opacity-80 mt-4">
  Building developer tools since 2010.<br>
  Passionate about DX and open source.
</div>

---

# 3. `section`

Use **section** between major parts of a talk to signal a topic change.  
Clean, minimal slide — just a title and an optional subtitle.

```yaml
---
layout: section
---

# Part 2
## Going Deeper
```

---
layout: section
---

# Part 2
## Going Deeper

---

# 4. `end`

**end** marks the closing slide of a presentation.  
Typically used for "Thank You" or contact details.

```yaml
---
layout: end
---

Thank you!

hello@example.com
```

---
layout: end
---

Thank you!

hello@example.com

---
layout: section
---

# Part 2
## Content Layouts

`default` · `center` · `full` · `statement` · `fact` · `quote`

---

# 5. `default`

The **default** layout is used for every slide that doesn't specify one.  
It provides a title at the top and a content area below.

```yaml
---
layout: default
---

# My Slide Title

Regular prose, bullet lists, code blocks — anything goes here.
```

---
layout: default
---

# `default` — Live Example

- Bullet point A
- Bullet point B
- Bullet point C

Regular prose lives here alongside **bold**, *italic*, and `inline code`.

---

# 6. `center`

**center** places all content in the exact middle of the slide.  
Great for short, punchy statements or a single diagram.

```yaml
---
layout: center
---

## This text is perfectly centred
```

---
layout: center
---

## This text is perfectly centred

Use me for short, impactful content.

---

# 7. `full`

**full** removes all padding and margins so your content fills the entire viewport.  
Useful for large images, diagrams, or embedded components.

```yaml
---
layout: full
---

<img src="https://sli.dev/logo-square.png" class="h-full mx-auto" />
```

---
layout: full
---

<div class="h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600">
  <div class="text-white text-center">
    <div class="text-6xl font-bold mb-4">full</div>
    <div class="text-2xl opacity-80">Content fills the entire slide — zero padding</div>
  </div>
</div>

---

# 8. `statement`

**statement** treats the main content as a large affirmative statement.  
Text is enlarged and centred for maximum impact.

```yaml
---
layout: statement
---

## Simplicity is the ultimate sophistication.
```

---
layout: statement
---

## Simplicity is the ultimate sophistication.

---

# 9. `fact`

**fact** highlights a key statistic or fact with a large number/word and a caption below.

```yaml
---
layout: fact
---

## 2.3 Million
Downloads per month
```

---
layout: fact
---

## 2.3 Million
Downloads per month

---

# 10. `quote`

**quote** displays a pull-quote prominently, with the citation below.

```yaml
---
layout: quote
---

"Programs must be written for people to read,  
and only incidentally for machines to execute."

— Harold Abelson
```

---
layout: quote
---

"Programs must be written for people to read,  
and only incidentally for machines to execute."

— Harold Abelson

---
layout: section
---

# Part 3
## Column Layouts

`two-cols` · `two-cols-header`

---

# 11. `two-cols`

**two-cols** splits the slide into two columns.  
Use the `::right::` named slot to populate the right column.

```yaml
---
layout: two-cols
---

# Left Column
Content on the left side.

::right::

# Right Column
Content on the right side.
```

---
layout: two-cols
---

# Left Column

- Item A
- Item B
- Item C

```ts
const greet = (name: string) =>
  `Hello, ${name}!`
```

::right::

# Right Column

Use `::right::` to fill the right pane.

- Item D
- Item E
- Item F

```ts
console.log(greet('Slidev'))
// Hello, Slidev!
```

---

# 12. `two-cols-header`

**two-cols-header** adds a full-width header row above two columns.  
Use `::left::` and `::right::` slots for the columns.

```yaml
---
layout: two-cols-header
---

## Full-width Header

::left::
Left content

::right::
Right content
```

---
layout: two-cols-header
---

## Full-width Header Spanning Both Columns

::left::

### Left Pane

- Design decisions
- Architecture overview
- Trade-offs

::right::

### Right Pane

- Implementation details
- Code snippets
- Performance numbers

---
layout: section
---

# Part 4
## Image Layouts

`image` · `image-left` · `image-right`

---

# 13. `image`

**image** uses a single image as the primary content of the slide.  
Set `image` in the frontmatter; use `backgroundSize` to control fitting.

```yaml
---
layout: image
image: https://cover.sli.dev
backgroundSize: cover
---
```

---
layout: image
image: https://cover.sli.dev
backgroundSize: cover
---

---

# 14. `image-left`

**image-left** places an image on the left half, content on the right.  
Props: `image`, `backgroundSize`, `class`.

```yaml
---
layout: image-left
image: https://cover.sli.dev
---

# Content on the Right
Text and code live here.
```

---
layout: image-left
image: https://cover.sli.dev
---

# `image-left`

The image occupies the left half of the slide.

- Use `backgroundSize: contain` to avoid cropping
- The right pane accepts any Markdown content
- Great for showing a screenshot alongside an explanation

---

# 15. `image-right`

**image-right** is the mirror of `image-left` — image on the right, content on the left.

```yaml
---
layout: image-right
image: https://cover.sli.dev
---

# Content on the Left
Text and code live here.
```

---
layout: image-right
image: https://cover.sli.dev
---

# `image-right`

Content lives on the **left** when the image is on the right.

- Mirrors `image-left`
- Same props: `image`, `backgroundSize`, `class`
- Useful for alternating layouts to keep the deck dynamic

---
layout: section
---

# Part 5
## iFrame Layouts

`iframe` · `iframe-left` · `iframe-right`

---

# 16. `iframe`

**iframe** embeds a live web page as the entire slide content.  
Set the `url` prop in the frontmatter.

```yaml
---
layout: iframe
url: https://sli.dev
---
```

---
layout: iframe
url: https://sli.dev
---

---

# 17. `iframe-left`

**iframe-left** embeds a page on the left half with content on the right.  
Props: `url`, `class`.

```yaml
---
layout: iframe-left
url: https://sli.dev
---

# Notes on the Right
Annotate the embedded page here.
```

---
layout: iframe-left
url: https://sli.dev
---

# `iframe-left`

The live site is embedded on the left.

- Useful for live demos alongside speaker notes
- The `class` prop applies to the iframe wrapper
- Right pane supports full Markdown & Vue components

---

# 18. `iframe-right`

**iframe-right** is the mirror of `iframe-left` — embed on the right, content on the left.

```yaml
---
layout: iframe-right
url: https://sli.dev
---

# Notes on the Left
```

---
layout: iframe-right
url: https://sli.dev
---

# `iframe-right`

Content lives on the **left**, embed on the **right**.

- Same props as `iframe-left`: `url`, `class`
- Handy for showing a live reference while you talk through concepts

---
layout: section
---

# Part 6
## Utility Layouts

`none`

---

# 19. `none`

**none** strips all theming, padding, and styles.  
You get a raw blank canvas — every pixel is yours to control.

```yaml
---
layout: none
---

<div style="...">
  Build from scratch
</div>
```

---
layout: none
---

<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#0f172a;color:#f8fafc;font-family:monospace;">
  <div style="text-align:center;">
    <div style="font-size:4rem;font-weight:700;letter-spacing:.1em;">none</div>
    <div style="font-size:1.25rem;opacity:.6;margin-top:1rem;">Zero theming · Zero padding · Pure canvas</div>
  </div>
</div>

---
layout: section
---

# Part 7
## Custom Layouts

`side-note`

---

# 20. `side-note` (custom)

A custom layout defined in `layouts/side-note.vue`.  
Main content fills the left pane; a warm annotation panel sits on the right.

```yaml
---
layout: side-note
noteTitle: Key point
noteColor: "#fef9c3"   # optional, defaults to yellow
---

Main content here.

::note::

Annotation text here.
```

Named slots: **default** (main) · **`note`** (side panel)

---
layout: side-note
noteTitle: Why streams?
---

# Streaming vs Buffering

```ts
// Buffered — entire 500 MB arrives before first byte is processed
const data = await fetch('/api/dump').then(r => r.json())

// Streamed — rows appear as chunks land
for await (const row of streamRows('/api/dump')) {
  render(row)
}
```

Both fetch the same endpoint. Only one keeps the UI responsive.

::note::

**Memory**

Buffered response holds the full payload in RAM until parsing finishes.

Streamed response holds at most one chunk (~64 KB) at a time.

---

**Latency**

First row appears in milliseconds with streaming — after the full download with buffering.

---
layout: cover
background: https://cover.sli.dev
---

# All 20 Layouts Covered

| Category | Layouts |
|----------|---------|
| Structural | `cover` `intro` `section` `end` |
| Content | `default` `center` `full` `statement` `fact` `quote` |
| Columns | `two-cols` `two-cols-header` |
| Image | `image` `image-left` `image-right` |
| iFrame | `iframe` `iframe-left` `iframe-right` |
| Utility | `none` |
| Custom | `side-note` |

<div class="mt-4 text-gray-300 text-sm">
  See the full reference at <a href="https://sli.dev/builtin/layouts" class="underline">sli.dev/builtin/layouts</a>
</div>

---
src: ./pages/author.md
---
