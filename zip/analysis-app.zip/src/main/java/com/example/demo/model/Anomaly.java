package com.example.demo.model;

import java.time.LocalDateTime;

public class Anomaly {

    public enum AnomalyType {
        SPIKE, // Sudden increase in error rate
        NEW_ERROR_TYPE, // Previously unseen error type
        UNUSUAL_TIME, // Errors during unusual hours
        GROUP_GROWTH, // Sudden growth in error group
        RATE_CHANGE // Significant change in error velocity
    }

    public enum Severity {
        LOW, // 2-3x normal
        MEDIUM, // 3-5x normal
        HIGH, // 5-10x normal
        CRITICAL // >10x normal
    }

    private String id;
    private AnomalyType type;
    private Severity severity;
    private String title;
    private String description;
    private LocalDateTime detectedAt;
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    // Metrics
    private double currentValue;
    private double baselineValue;
    private double deviationFactor; // How many times above baseline

    // Context
    private String errorType;
    private String applicationName;
    private String environment;
    private int affectedErrorCount;

    // Constructors
    public Anomaly() {
        this.detectedAt = LocalDateTime.now();
    }

    public Anomaly(AnomalyType type, Severity severity, String title, String description) {
        this.type = type;
        this.severity = severity;
        this.title = title;
        this.description = description;
        this.detectedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public AnomalyType getType() {
        return type;
    }

    public void setType(AnomalyType type) {
        this.type = type;
    }

    public Severity getSeverity() {
        return severity;
    }

    public void setSeverity(Severity severity) {
        this.severity = severity;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getDetectedAt() {
        return detectedAt;
    }

    public void setDetectedAt(LocalDateTime detectedAt) {
        this.detectedAt = detectedAt;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public double getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(double currentValue) {
        this.currentValue = currentValue;
    }

    public double getBaselineValue() {
        return baselineValue;
    }

    public void setBaselineValue(double baselineValue) {
        this.baselineValue = baselineValue;
    }

    public double getDeviationFactor() {
        return deviationFactor;
    }

    public void setDeviationFactor(double deviationFactor) {
        this.deviationFactor = deviationFactor;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public int getAffectedErrorCount() {
        return affectedErrorCount;
    }

    public void setAffectedErrorCount(int affectedErrorCount) {
        this.affectedErrorCount = affectedErrorCount;
    }
}
