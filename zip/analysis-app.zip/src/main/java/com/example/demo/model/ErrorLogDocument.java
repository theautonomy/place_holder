package com.example.demo.model;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "error_logs")
public class ErrorLogDocument {

    @Id private String id;

    @Field("application_name")
    private String applicationName = "demo-app";

    @Field("environment")
    private String environment = "production";

    @Field("error_type")
    private String errorType;

    @Field("error_message")
    private String errorMessage;

    @Field("stack_trace")
    private String stackTrace;

    @Field("severity")
    private String severity = "ERROR";

    @Field("status")
    private String status = "OPEN";

    @Field("occurred_at")
    private LocalDateTime occurredAt = LocalDateTime.now();

    // Constructors
    public ErrorLogDocument() {}

    public ErrorLogDocument(
            String applicationName,
            String environment,
            String errorType,
            String errorMessage,
            String stackTrace,
            String severity,
            String status) {
        this.applicationName = applicationName;
        this.environment = environment;
        this.errorType = errorType;
        this.errorMessage = errorMessage;
        this.stackTrace = stackTrace;
        this.severity = severity;
        this.status = status;
        this.occurredAt = LocalDateTime.now();
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getStackTrace() {
        return stackTrace;
    }

    public void setStackTrace(String stackTrace) {
        this.stackTrace = stackTrace;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getOccurredAt() {
        return occurredAt;
    }

    public void setOccurredAt(LocalDateTime occurredAt) {
        this.occurredAt = occurredAt;
    }
}
