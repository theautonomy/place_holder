package com.example.demo.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import com.example.demo.model.ErrorLog;
import com.example.demo.repository.ErrorLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ErrorAnalyticsService {

    private static final Logger logger = LoggerFactory.getLogger(ErrorAnalyticsService.class);
    private final ErrorLogRepository errorLogRepository;

    public ErrorAnalyticsService(ErrorLogRepository errorLogRepository) {
        this.errorLogRepository = errorLogRepository;
    }

    /** Get error trends over time */
    public Map<String, Object> getErrorTrends(int hours) {
        LocalDateTime since = LocalDateTime.now().minusHours(hours);
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(since);

        Map<String, Object> trends = new HashMap<>();
        trends.put("totalErrors", errors.size());
        trends.put("timeRange", hours + " hours");
        trends.put("startTime", since.toString());
        trends.put("endTime", LocalDateTime.now().toString());

        // Group by hour
        Map<String, Long> errorsByHour =
                errors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        error ->
                                                error.getOccurredAt()
                                                        .format(
                                                                DateTimeFormatter.ofPattern(
                                                                        "yyyy-MM-dd HH:00")),
                                        Collectors.counting()));

        trends.put("errorsByHour", errorsByHour);

        // Calculate rate
        if (hours > 0) {
            double errorsPerHour = (double) errors.size() / hours;
            trends.put("averageErrorsPerHour", String.format("%.2f", errorsPerHour));
        }

        return trends;
    }

    /** Get error trends by day */
    public Map<String, Object> getErrorTrendsByDay(int days) {
        LocalDateTime since = LocalDateTime.now().minusDays(days);
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(since);

        Map<String, Object> trends = new HashMap<>();
        trends.put("totalErrors", errors.size());
        trends.put("timeRange", days + " days");

        // Group by day
        Map<String, Long> errorsByDay =
                errors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        error ->
                                                error.getOccurredAt()
                                                        .format(
                                                                DateTimeFormatter.ofPattern(
                                                                        "yyyy-MM-dd")),
                                        Collectors.counting()));

        trends.put("errorsByDay", errorsByDay);

        // Calculate daily average
        if (days > 0) {
            double errorsPerDay = (double) errors.size() / days;
            trends.put("averageErrorsPerDay", String.format("%.2f", errorsPerDay));
        }

        return trends;
    }

    /** Detect error spikes (hours with significantly more errors than average) */
    public Map<String, Object> detectSpikes(int hours) {
        LocalDateTime since = LocalDateTime.now().minusHours(hours);
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(since);

        Map<String, Long> errorsByHour =
                errors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        error ->
                                                error.getOccurredAt()
                                                        .format(
                                                                DateTimeFormatter.ofPattern(
                                                                        "yyyy-MM-dd HH:00")),
                                        Collectors.counting()));

        // Calculate average
        double average =
                errorsByHour.values().stream().mapToLong(Long::longValue).average().orElse(0.0);

        // Find spikes (2x average or more)
        double spikeThreshold = average * 2;
        List<Map<String, Object>> spikes =
                errorsByHour.entrySet().stream()
                        .filter(entry -> entry.getValue() > spikeThreshold)
                        .map(
                                entry -> {
                                    Map<String, Object> spike = new HashMap<>();
                                    spike.put("hour", entry.getKey());
                                    spike.put("count", entry.getValue());
                                    spike.put("average", String.format("%.2f", average));
                                    spike.put(
                                            "factor",
                                            String.format("%.2fx", entry.getValue() / average));
                                    return spike;
                                })
                        .sorted((a, b) -> ((Long) b.get("count")).compareTo((Long) a.get("count")))
                        .collect(Collectors.toList());

        Map<String, Object> result = new HashMap<>();
        result.put("averageErrorsPerHour", String.format("%.2f", average));
        result.put("spikeThreshold", String.format("%.2f", spikeThreshold));
        result.put("spikesDetected", spikes.size());
        result.put("spikes", spikes);

        return result;
    }

    /** Get error statistics */
    public Map<String, Object> getStatistics(int hours) {
        LocalDateTime since = LocalDateTime.now().minusHours(hours);
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(since);

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalErrors", errors.size());
        stats.put("timeRange", hours + " hours");

        if (!errors.isEmpty()) {
            // First and last error times
            stats.put("firstError", errors.get(errors.size() - 1).getOccurredAt().toString());
            stats.put("lastError", errors.get(0).getOccurredAt().toString());

            // Extract simple error types from stack traces (first line usually)
            Map<String, Long> errorTypeDistribution =
                    errors.stream()
                            .map(this::extractErrorType)
                            .filter(type -> type != null && !type.isEmpty())
                            .collect(Collectors.groupingBy(type -> type, Collectors.counting()));

            stats.put("errorTypeDistribution", errorTypeDistribution);

            // Top error types
            List<Map<String, Object>> topErrors =
                    errorTypeDistribution.entrySet().stream()
                            .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                            .limit(10)
                            .map(
                                    entry -> {
                                        Map<String, Object> item = new HashMap<>();
                                        item.put("type", entry.getKey());
                                        item.put("count", entry.getValue());
                                        item.put(
                                                "percentage",
                                                String.format(
                                                        "%.1f%%",
                                                        (entry.getValue() * 100.0)
                                                                / errors.size()));
                                        return item;
                                    })
                            .collect(Collectors.toList());

            stats.put("topErrorTypes", topErrors);
        }

        return stats;
    }

    /** Extract error type from stack trace (first line) */
    private String extractErrorType(ErrorLog error) {
        String stackTrace = error.getStackTrace();
        if (stackTrace == null || stackTrace.isEmpty()) {
            return "Unknown";
        }

        // Get first line
        String[] lines = stackTrace.split("\\n");
        if (lines.length > 0) {
            String firstLine = lines[0].trim();
            // Extract exception class name (before the colon if there is one)
            int colonIndex = firstLine.indexOf(':');
            if (colonIndex > 0) {
                return firstLine.substring(0, colonIndex).trim();
            }
            return firstLine;
        }

        return "Unknown";
    }

    /** Get recent errors for display */
    public List<Map<String, Object>> getRecentErrorsSummary(int limit) {
        List<ErrorLog> errors = errorLogRepository.findAllByOccurredAtDesc();

        return errors.stream()
                .limit(limit)
                .map(
                        error -> {
                            Map<String, Object> summary = new HashMap<>();
                            summary.put("id", error.getId());
                            summary.put("occurredAt", error.getOccurredAt().toString());
                            summary.put("errorType", extractErrorType(error));

                            // Truncate stack trace for summary
                            String stackTrace = error.getStackTrace();
                            if (stackTrace.length() > 200) {
                                summary.put("preview", stackTrace.substring(0, 200) + "...");
                            } else {
                                summary.put("preview", stackTrace);
                            }

                            return summary;
                        })
                .collect(Collectors.toList());
    }

    /** Compare time periods */
    public Map<String, Object> compareTimePeriods(int currentHours, int previousHours) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime currentStart = now.minusHours(currentHours);
        LocalDateTime previousStart = currentStart.minusHours(previousHours);

        List<ErrorLog> currentErrors = errorLogRepository.findRecentErrors(currentStart);
        List<ErrorLog> previousErrors =
                errorLogRepository.findAll().stream()
                        .filter(
                                e ->
                                        e.getOccurredAt().isAfter(previousStart)
                                                && e.getOccurredAt().isBefore(currentStart))
                        .collect(Collectors.toList());

        Map<String, Object> comparison = new HashMap<>();
        comparison.put(
                "currentPeriod",
                Map.of(
                        "hours", currentHours,
                        "errorCount", currentErrors.size(),
                        "startTime", currentStart.toString()));

        comparison.put(
                "previousPeriod",
                Map.of(
                        "hours", previousHours,
                        "errorCount", previousErrors.size(),
                        "startTime", previousStart.toString(),
                        "endTime", currentStart.toString()));

        // Calculate change
        int change = currentErrors.size() - previousErrors.size();
        double percentChange =
                previousErrors.size() > 0 ? (change * 100.0) / previousErrors.size() : 0;

        comparison.put("change", change);
        comparison.put("percentChange", String.format("%.1f%%", percentChange));
        comparison.put("trend", change > 0 ? "increasing" : change < 0 ? "decreasing" : "stable");

        return comparison;
    }

    /** Get error statistics for dashboard */
    public Map<String, Object> getErrorStatistics(String applicationName, int hours, int limit) {
        long methodStart = System.currentTimeMillis();
        logger.debug(
                "getErrorStatistics: Starting for app='{}', hours={}, limit={}",
                applicationName,
                hours,
                limit);

        LocalDateTime since = LocalDateTime.now().minusHours(hours);

        // Get errors - either for specific app or all apps
        long t1 = System.currentTimeMillis();
        List<ErrorLog> errors;
        if ("all".equals(applicationName)) {
            errors = errorLogRepository.findRecentErrors(since);
        } else {
            errors =
                    errorLogRepository.findByApplicationNameAndOccurredAtAfter(
                            applicationName, since);
        }
        logger.debug(
                "  - findErrors query: {} ms, {} errors found",
                System.currentTimeMillis() - t1,
                errors.size());

        long t2 = System.currentTimeMillis();
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalErrors", (long) errors.size());

        // Errors by severity
        Map<String, Long> errorsBySeverity =
                errors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        ErrorLog::getSeverity, Collectors.counting()));
        stats.put("errorsBySeverity", errorsBySeverity);
        logger.debug("  - group by severity: {} ms", System.currentTimeMillis() - t2);

        // Group errors by type only to count occurrences
        long t3 = System.currentTimeMillis();
        Map<String, List<ErrorLog>> groupedErrors =
                errors.stream().collect(Collectors.groupingBy(ErrorLog::getErrorType));

        // Top errors by occurrence count (number of times each error type occurred)
        List<Map<String, Object>> topErrors =
                groupedErrors.entrySet().stream()
                        .sorted((a, b) -> Integer.compare(b.getValue().size(), a.getValue().size()))
                        .limit(limit)
                        .map(
                                entry -> {
                                    ErrorLog firstError = entry.getValue().get(0);
                                    Map<String, Object> errorMap = new HashMap<>();
                                    errorMap.put("id", firstError.getId());
                                    errorMap.put("errorType", firstError.getErrorType());
                                    errorMap.put("errorMessage", firstError.getErrorMessage());
                                    errorMap.put("occurrenceCount", entry.getValue().size());
                                    errorMap.put("severity", firstError.getSeverity());
                                    return errorMap;
                                })
                        .collect(Collectors.toList());
        stats.put("topErrors", topErrors);
        logger.debug(
                "  - group by type and build top errors: {} ms", System.currentTimeMillis() - t3);

        logger.debug("getErrorStatistics: Total {} ms", System.currentTimeMillis() - methodStart);
        return stats;
    }

    /** Detect trends over time */
    public Map<String, Object> detectTrends(String applicationName, int days) {
        long methodStart = System.currentTimeMillis();
        logger.debug("detectTrends: Starting for app='{}', days={}", applicationName, days);

        LocalDateTime since = LocalDateTime.now().minusDays(days);

        // Get errors - either for specific app or all apps
        long t1 = System.currentTimeMillis();
        List<ErrorLog> errors;
        if ("all".equals(applicationName)) {
            errors = errorLogRepository.findRecentErrors(since);
        } else {
            errors =
                    errorLogRepository.findByApplicationNameAndOccurredAtAfter(
                            applicationName, since);
        }
        logger.debug(
                "  - findErrors query: {} ms, {} errors found",
                System.currentTimeMillis() - t1,
                errors.size());

        long t2 = System.currentTimeMillis();
        Map<String, Object> trends = new HashMap<>();

        // Average errors per day
        double avgErrorsPerDay = errors.size() / (double) days;
        trends.put("averageErrorsPerDay", avgErrorsPerDay);
        trends.put("totalErrors", errors.size());

        // Group errors by day
        Map<String, Long> dailyErrorCount =
                errors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        error -> error.getOccurredAt().toLocalDate().toString(),
                                        Collectors.counting()));
        trends.put("dailyErrorCount", dailyErrorCount);
        logger.debug("  - group by day: {} ms", System.currentTimeMillis() - t2);

        // Detect spike days (days with > 2x average)
        long t3 = System.currentTimeMillis();
        double spikeThreshold = avgErrorsPerDay * 2;
        List<String> spikeDays =
                dailyErrorCount.entrySet().stream()
                        .filter(entry -> entry.getValue() > spikeThreshold)
                        .map(Map.Entry::getKey)
                        .collect(Collectors.toList());
        trends.put("spikeDays", spikeDays);
        logger.debug(
                "  - detect spike days: {} ms, {} spike days found",
                System.currentTimeMillis() - t3,
                spikeDays.size());

        // New error types in last 24 hours
        long t4 = System.currentTimeMillis();
        LocalDateTime yesterday = LocalDateTime.now().minusDays(1);
        Set<String> recentErrorTypes =
                errors.stream()
                        .filter(e -> e.getOccurredAt().isAfter(yesterday))
                        .map(ErrorLog::getErrorType)
                        .collect(Collectors.toSet());
        trends.put("newErrorTypes", new ArrayList<>(recentErrorTypes));
        logger.debug(
                "  - detect new error types: {} ms, {} new types found",
                System.currentTimeMillis() - t4,
                recentErrorTypes.size());

        logger.debug("detectTrends: Total {} ms", System.currentTimeMillis() - methodStart);
        return trends;
    }

    /** Compare environments */
    public Map<String, Object> compareEnvironments(String applicationName) {
        long methodStart = System.currentTimeMillis();
        logger.debug("compareEnvironments: Starting for app='{}'", applicationName);

        // Get errors - either for specific app or all apps
        long t1 = System.currentTimeMillis();
        List<ErrorLog> allErrors;
        if ("all".equals(applicationName)) {
            allErrors = errorLogRepository.findAll();
        } else {
            allErrors = errorLogRepository.findByApplicationName(applicationName);
        }
        logger.debug(
                "  - findErrors query: {} ms, {} errors found",
                System.currentTimeMillis() - t1,
                allErrors.size());

        long t2 = System.currentTimeMillis();
        Map<String, Object> comparison = new HashMap<>();

        // Group by environment
        Map<String, List<ErrorLog>> errorsByEnvironment =
                allErrors.stream().collect(Collectors.groupingBy(ErrorLog::getEnvironment));
        logger.debug(
                "  - group by environment: {} ms, {} environments found",
                System.currentTimeMillis() - t2,
                errorsByEnvironment.size());

        long t3 = System.currentTimeMillis();
        for (Map.Entry<String, List<ErrorLog>> entry : errorsByEnvironment.entrySet()) {
            String environment = entry.getKey();
            List<ErrorLog> envErrors = entry.getValue();

            Map<String, Object> envStats = new HashMap<>();
            envStats.put("totalErrors", (long) envErrors.size());
            envStats.put(
                    "openErrors",
                    envErrors.stream().filter(e -> "OPEN".equals(e.getStatus())).count());
            envStats.put(
                    "criticalErrors",
                    envErrors.stream().filter(e -> "CRITICAL".equals(e.getSeverity())).count());

            comparison.put(environment, envStats);
        }
        logger.debug("  - build environment stats: {} ms", System.currentTimeMillis() - t3);

        logger.debug("compareEnvironments: Total {} ms", System.currentTimeMillis() - methodStart);
        return comparison;
    }

    /** Detect if a specific error type has spiked */
    public Map<String, Object> detectErrorSpike(Long errorId) {
        long methodStart = System.currentTimeMillis();
        logger.debug("detectErrorSpike: Starting for error ID {}", errorId);

        long t1 = System.currentTimeMillis();
        ErrorLog targetError =
                errorLogRepository
                        .findById(errorId)
                        .orElseThrow(() -> new RuntimeException("Error not found: " + errorId));
        logger.debug("  - findById: {} ms", System.currentTimeMillis() - t1);

        String errorType = targetError.getErrorType();
        String applicationName = targetError.getApplicationName();

        // Get baseline (last 7 days before the error)
        LocalDateTime errorTime = targetError.getOccurredAt();
        LocalDateTime baselineStart = errorTime.minusDays(7);
        LocalDateTime baselineEnd = errorTime.minusHours(1); // 1 hour before the error

        // Get spike window (±1 hour around the error)
        LocalDateTime spikeStart = errorTime.minusHours(1);
        LocalDateTime spikeEnd = errorTime.plusHours(1);

        // Count errors in baseline period
        long t2 = System.currentTimeMillis();
        List<ErrorLog> baselineErrors =
                errorLogRepository.findByApplicationNameAndOccurredAtBetween(
                        applicationName, baselineStart, baselineEnd);
        logger.debug(
                "  - baseline query (7 days): {} ms, {} errors",
                System.currentTimeMillis() - t2,
                baselineErrors.size());

        long baselineCount =
                baselineErrors.stream().filter(e -> errorType.equals(e.getErrorType())).count();
        double baselineRate =
                baselineCount
                        / ((double) java.time.Duration.between(baselineStart, baselineEnd).toHours()
                                + 1);

        // Count errors in spike window
        long t3 = System.currentTimeMillis();
        List<ErrorLog> spikeErrors =
                errorLogRepository.findByApplicationNameAndOccurredAtBetween(
                        applicationName, spikeStart, spikeEnd);
        logger.debug(
                "  - spike query (2 hours): {} ms, {} errors",
                System.currentTimeMillis() - t3,
                spikeErrors.size());

        long spikeCount =
                spikeErrors.stream().filter(e -> errorType.equals(e.getErrorType())).count();
        double spikeRate = spikeCount / 2.0; // 2 hour window

        // Calculate spike ratio
        double spikeRatio =
                baselineRate > 0
                        ? spikeRate / baselineRate
                        : (spikeCount > 0 ? Double.POSITIVE_INFINITY : 0);

        boolean isSpike =
                spikeRatio >= 2.0 && spikeCount >= 5; // At least 2x baseline and 5+ errors

        Map<String, Object> result = new HashMap<>();
        result.put("isSpike", isSpike);
        result.put("errorType", errorType);
        result.put("applicationName", applicationName);
        result.put("errorTime", errorTime);
        result.put("baselineRate", String.format("%.2f errors/hour", baselineRate));
        result.put("spikeRate", String.format("%.2f errors/hour", spikeRate));
        result.put("spikeRatio", String.format("%.1fx", spikeRatio));
        result.put("baselineCount", baselineCount);
        result.put("spikeCount", spikeCount);
        result.put("spikeWindow", spikeStart + " to " + spikeEnd);

        logger.debug("detectErrorSpike: Total {} ms", System.currentTimeMillis() - methodStart);
        return result;
    }

    /** Find errors that occurred around the same time (±30 minutes) */
    public List<ErrorLog> findCorrelatedErrors(Long errorId) {
        ErrorLog targetError =
                errorLogRepository
                        .findById(errorId)
                        .orElseThrow(() -> new RuntimeException("Error not found: " + errorId));

        LocalDateTime errorTime = targetError.getOccurredAt();
        LocalDateTime correlationStart = errorTime.minusMinutes(30);
        LocalDateTime correlationEnd = errorTime.plusMinutes(30);

        // Find all errors in the correlation window
        List<ErrorLog> correlatedErrors =
                errorLogRepository.findByApplicationNameAndOccurredAtBetween(
                        targetError.getApplicationName(), correlationStart, correlationEnd);

        // Group by error type and count
        Map<String, Long> errorTypeCounts =
                correlatedErrors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        ErrorLog::getErrorType, Collectors.counting()));

        // Filter to only error types with significant occurrences (more than 2)
        // and exclude the target error type
        return correlatedErrors.stream()
                .filter(
                        e ->
                                !e.getErrorType().equals(targetError.getErrorType())
                                        && errorTypeCounts.get(e.getErrorType()) > 2)
                .sorted(
                        (a, b) ->
                                Long.compare(
                                        errorTypeCounts.get(b.getErrorType()),
                                        errorTypeCounts.get(a.getErrorType())))
                .limit(10)
                .collect(Collectors.toList());
    }

    /** Analyze stack trace patterns for similar errors */
    public Map<String, Object> analyzeStackTracePatterns(String errorType, int hours) {
        long methodStart = System.currentTimeMillis();
        logger.debug(
                "analyzeStackTracePatterns: Starting for errorType={}, hours={}", errorType, hours);

        long t1 = System.currentTimeMillis();
        LocalDateTime since = LocalDateTime.now().minusHours(hours);
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(since);
        logger.debug(
                "  - findRecentErrors: {} ms, {} errors",
                System.currentTimeMillis() - t1,
                errors.size());

        long t2 = System.currentTimeMillis();
        List<ErrorLog> matchingErrors =
                errors.stream()
                        .filter(e -> errorType.equals(e.getErrorType()))
                        .collect(Collectors.toList());
        logger.debug(
                "  - filter matching: {} ms, {} matching",
                System.currentTimeMillis() - t2,
                matchingErrors.size());

        Map<String, Object> analysis = new HashMap<>();
        analysis.put("totalMatches", matchingErrors.size());
        analysis.put("errorType", errorType);

        if (matchingErrors.isEmpty()) {
            logger.debug(
                    "analyzeStackTracePatterns: Total {} ms (no matches)",
                    System.currentTimeMillis() - methodStart);
            return analysis;
        }

        // Analyze common stack trace patterns
        long t3 = System.currentTimeMillis();
        Map<String, Integer> methodCounts = new HashMap<>();
        Map<String, Integer> classCounts = new HashMap<>();

        for (ErrorLog error : matchingErrors) {
            String stackTrace = error.getStackTrace();
            if (stackTrace != null) {
                // Extract class and method names from stack trace
                String[] lines = stackTrace.split("\n");
                for (String line : lines) {
                    if (line.contains("at ")) {
                        String methodInfo = line.trim().replaceFirst("at ", "");
                        int parenIndex = methodInfo.indexOf('(');
                        if (parenIndex > 0) {
                            String fullMethod = methodInfo.substring(0, parenIndex);
                            methodCounts.put(
                                    fullMethod, methodCounts.getOrDefault(fullMethod, 0) + 1);

                            int lastDotIndex = fullMethod.lastIndexOf('.');
                            if (lastDotIndex > 0) {
                                String className = fullMethod.substring(0, lastDotIndex);
                                classCounts.put(
                                        className, classCounts.getOrDefault(className, 0) + 1);
                            }
                        }
                    }
                }
            }
        }
        logger.debug("  - parse stack traces: {} ms", System.currentTimeMillis() - t3);

        // Get top methods and classes
        long t4 = System.currentTimeMillis();
        List<Map.Entry<String, Integer>> topMethods =
                methodCounts.entrySet().stream()
                        .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                        .limit(5)
                        .collect(Collectors.toList());

        List<Map.Entry<String, Integer>> topClasses =
                classCounts.entrySet().stream()
                        .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                        .limit(5)
                        .collect(Collectors.toList());

        analysis.put("topMethods", topMethods);
        analysis.put("topClasses", topClasses);
        logger.debug("  - sort and collect: {} ms", System.currentTimeMillis() - t4);

        logger.debug(
                "analyzeStackTracePatterns: Total {} ms", System.currentTimeMillis() - methodStart);
        return analysis;
    }

    /** Get time-series data for monitoring dashboard */
    public Map<String, Object> getTimeSeriesData(int hours, String interval) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime since = now.minusHours(hours);
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(since);

        Map<String, Object> result = new HashMap<>();
        result.put("totalErrors", errors.size());
        result.put("timeRange", hours + " hours");
        result.put("interval", interval);

        // Determine time format and grouping based on interval
        DateTimeFormatter formatter;
        List<String> labels = new ArrayList<>();
        List<Integer> data = new ArrayList<>();

        if ("hour".equals(interval)) {
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:00");

            // Group errors by hour
            Map<String, Long> errorsByHour =
                    errors.stream()
                            .collect(
                                    Collectors.groupingBy(
                                            error -> error.getOccurredAt().format(formatter),
                                            Collectors.counting()));

            // Generate all hours in range (even if no errors)
            LocalDateTime current = since.withMinute(0).withSecond(0).withNano(0);
            while (current.isBefore(now) || current.isEqual(now)) {
                String hourLabel = current.format(formatter);
                labels.add(current.format(DateTimeFormatter.ofPattern("MMM dd, HH:00")));
                data.add(errorsByHour.getOrDefault(hourLabel, 0L).intValue());
                current = current.plusHours(1);
            }

        } else if ("minute".equals(interval)) {
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            // Group errors by minute
            Map<String, Long> errorsByMinute =
                    errors.stream()
                            .collect(
                                    Collectors.groupingBy(
                                            error -> error.getOccurredAt().format(formatter),
                                            Collectors.counting()));

            // Generate all minutes in range for last hour only (to avoid too many data points)
            LocalDateTime lastHour = now.minusHours(1);
            LocalDateTime current = lastHour.withSecond(0).withNano(0);
            while (current.isBefore(now) || current.isEqual(now)) {
                String minuteLabel = current.format(formatter);
                labels.add(current.format(DateTimeFormatter.ofPattern("HH:mm")));
                data.add(errorsByMinute.getOrDefault(minuteLabel, 0L).intValue());
                current = current.plusMinutes(1);
            }

        } else {
            // Default to day interval
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            // Group errors by day
            Map<String, Long> errorsByDay =
                    errors.stream()
                            .collect(
                                    Collectors.groupingBy(
                                            error -> error.getOccurredAt().format(formatter),
                                            Collectors.counting()));

            // Generate all days in range
            int days = hours / 24;
            LocalDateTime dayStart = now.minusDays(days).withHour(0).withMinute(0).withSecond(0);
            LocalDateTime current = dayStart;
            while (current.isBefore(now) || current.isEqual(now)) {
                String dayLabel = current.format(formatter);
                labels.add(current.format(DateTimeFormatter.ofPattern("MMM dd")));
                data.add(errorsByDay.getOrDefault(dayLabel, 0L).intValue());
                current = current.plusDays(1);
            }
        }

        result.put("labels", labels);
        result.put("data", data);

        // Calculate statistics
        double average = data.stream().mapToInt(Integer::intValue).average().orElse(0.0);
        int max = data.stream().mapToInt(Integer::intValue).max().orElse(0);
        int min = data.stream().mapToInt(Integer::intValue).min().orElse(0);

        result.put("average", String.format("%.2f", average));
        result.put("max", max);
        result.put("min", min);

        return result;
    }
}
