package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.demo.model.ErrorLogDocument;
import com.example.demo.service.MongoErrorService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/mongo/errors")
@CrossOrigin(origins = "*")
public class MongoErrorController {

    private final MongoErrorService mongoErrorService;

    public MongoErrorController(MongoErrorService mongoErrorService) {
        this.mongoErrorService = mongoErrorService;
    }

    // ========== Error Retrieval ==========

    @GetMapping
    public ResponseEntity<List<ErrorLogDocument>> getAllErrors() {
        List<ErrorLogDocument> errors = mongoErrorService.getAllErrors();
        return ResponseEntity.ok(errors);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ErrorLogDocument> getError(@PathVariable String id) {
        return mongoErrorService
                .getErrorById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/recent")
    public ResponseEntity<List<ErrorLogDocument>> getRecentErrors(
            @RequestParam(defaultValue = "24") int hours) {
        List<ErrorLogDocument> errors = mongoErrorService.getRecentErrors(hours);
        return ResponseEntity.ok(errors);
    }

    @GetMapping("/count")
    public ResponseEntity<Map<String, Object>> getErrorCount() {
        long count = mongoErrorService.getErrorCount();
        Map<String, Object> response = new HashMap<>();
        response.put("count", count);
        response.put("database", "mongodb");
        return ResponseEntity.ok(response);
    }

    // ========== Testing Endpoints ==========

    @PostMapping("/test/random")
    public ResponseEntity<Map<String, Object>> generateRandomError() {
        try {
            ErrorLogDocument errorLog = mongoErrorService.generateRandomTestError();

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("errorId", errorLog.getId());
            response.put("errorType", errorLog.getErrorType());
            response.put("occurredAt", errorLog.getOccurredAt().toString());
            response.put("message", "Random test error generated successfully in MongoDB");

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ========== Health Check ==========

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> healthCheck() {
        Map<String, String> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "MongoDB Error Analysis System");
        health.put("database", "mongodb");
        health.put("totalErrors", String.valueOf(mongoErrorService.getErrorCount()));
        return ResponseEntity.ok(health);
    }
}
