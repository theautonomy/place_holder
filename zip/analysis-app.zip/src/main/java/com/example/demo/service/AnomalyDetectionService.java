package com.example.demo.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

import com.example.demo.model.Anomaly;
import com.example.demo.model.Anomaly.AnomalyType;
import com.example.demo.model.Anomaly.Severity;
import com.example.demo.model.ErrorLog;
import com.example.demo.repository.ErrorLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class AnomalyDetectionService {

    private static final Logger logger = LoggerFactory.getLogger(AnomalyDetectionService.class);

    private final ErrorLogRepository errorLogRepository;

    // Configuration
    private static final double SPIKE_THRESHOLD_FACTOR = 3.0; // 3x baseline = anomaly
    private static final int BASELINE_HOURS = 24; // Calculate baseline from last 24 hours
    private static final int DETECTION_WINDOW_HOURS = 1; // Check last 1 hour for anomalies
    private static final LocalTime NORMAL_START_HOUR = LocalTime.of(6, 0); // 6 AM
    private static final LocalTime NORMAL_END_HOUR = LocalTime.of(22, 0); // 10 PM

    public AnomalyDetectionService(ErrorLogRepository errorLogRepository) {
        this.errorLogRepository = errorLogRepository;
    }

    /** Detect all anomalies in the system */
    public List<Anomaly> detectAnomalies() {
        logger.info("Starting anomaly detection");
        List<Anomaly> anomalies = new ArrayList<>();

        // Detect different types of anomalies
        anomalies.addAll(detectErrorRateSpikes());
        anomalies.addAll(detectNewErrorTypes());
        anomalies.addAll(detectUnusualTimePatterns());

        // Sort by severity and detection time
        anomalies.sort(
                Comparator.comparing(Anomaly::getSeverity)
                        .reversed()
                        .thenComparing(Anomaly::getDetectedAt)
                        .reversed());

        logger.info("Detected {} anomalies", anomalies.size());
        return anomalies;
    }

    /** Detect sudden spikes in error rate */
    public List<Anomaly> detectErrorRateSpikes() {
        logger.info("Detecting error rate spikes");
        List<Anomaly> anomalies = new ArrayList<>();

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime recentStart = now.minusHours(DETECTION_WINDOW_HOURS);
        LocalDateTime baselineStart = now.minusHours(BASELINE_HOURS);

        // Get recent errors
        List<ErrorLog> recentErrors = errorLogRepository.findRecentErrors(recentStart);
        List<ErrorLog> baselineErrors = errorLogRepository.findRecentErrors(baselineStart);

        // Calculate rates
        double recentRate = recentErrors.size() / (double) DETECTION_WINDOW_HOURS;
        double baselineRate =
                (baselineErrors.size() - recentErrors.size())
                        / (double) (BASELINE_HOURS - DETECTION_WINDOW_HOURS);

        logger.info(
                "Spike detection: recentCount={}, baselineCount={}, recentRate={}, baselineRate={}",
                recentErrors.size(),
                baselineErrors.size(),
                recentRate,
                baselineRate);

        // Handle case where baseline is zero but we have recent errors
        if (baselineRate == 0 && recentRate >= 5) {
            Anomaly anomaly = new Anomaly();
            anomaly.setType(AnomalyType.SPIKE);
            anomaly.setSeverity(Severity.CRITICAL);
            anomaly.setTitle("Sudden Error Burst Detected");
            anomaly.setDescription(
                    String.format(
                            "Sudden burst of %.0f errors in the last hour with no baseline activity",
                            recentRate));
            anomaly.setCurrentValue(recentRate);
            anomaly.setBaselineValue(0);
            anomaly.setDeviationFactor(0);
            anomaly.setStartTime(recentStart);
            anomaly.setEndTime(now);
            anomaly.setAffectedErrorCount(recentErrors.size());

            anomalies.add(anomaly);
            logger.warn("Error burst detected: {} errors with zero baseline", recentRate);
        } else if (baselineRate > 0) {
            double factor = recentRate / baselineRate;
            logger.info("Factor: {}, Threshold: {}", factor, SPIKE_THRESHOLD_FACTOR);

            if (factor >= SPIKE_THRESHOLD_FACTOR) {
                Anomaly anomaly = new Anomaly();
                anomaly.setType(AnomalyType.SPIKE);
                anomaly.setSeverity(calculateSeverity(factor));
                anomaly.setTitle("Error Rate Spike Detected");
                anomaly.setDescription(
                        String.format(
                                "Error rate is %.1fx higher than baseline. Current: %.1f errors/hour, Baseline: %.1f errors/hour",
                                factor, recentRate, baselineRate));
                anomaly.setCurrentValue(recentRate);
                anomaly.setBaselineValue(baselineRate);
                anomaly.setDeviationFactor(factor);
                anomaly.setStartTime(recentStart);
                anomaly.setEndTime(now);
                anomaly.setAffectedErrorCount(recentErrors.size());

                anomalies.add(anomaly);
                logger.warn(
                        "Spike detected: current={}, baseline={}, factor={}",
                        recentRate,
                        baselineRate,
                        factor);
            }
        }

        // Check for spikes by error type
        anomalies.addAll(detectErrorTypeSpikes(recentErrors, baselineErrors, recentStart, now));

        return anomalies;
    }

    /** Detect spikes in specific error types */
    private List<Anomaly> detectErrorTypeSpikes(
            List<ErrorLog> recentErrors,
            List<ErrorLog> baselineErrors,
            LocalDateTime recentStart,
            LocalDateTime now) {

        List<Anomaly> anomalies = new ArrayList<>();

        // Group by error type
        Map<String, Long> recentCounts =
                recentErrors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        ErrorLog::getErrorType, Collectors.counting()));

        Map<String, Long> baselineCounts =
                baselineErrors.stream()
                        .filter(e -> e.getOccurredAt().isBefore(recentStart))
                        .collect(
                                Collectors.groupingBy(
                                        ErrorLog::getErrorType, Collectors.counting()));

        for (Map.Entry<String, Long> entry : recentCounts.entrySet()) {
            String errorType = entry.getKey();
            long recentCount = entry.getValue();
            long baselineCount = baselineCounts.getOrDefault(errorType, 0L);

            double recentRate = recentCount / (double) DETECTION_WINDOW_HOURS;
            double baselineRate =
                    baselineCount / (double) (BASELINE_HOURS - DETECTION_WINDOW_HOURS);

            if (baselineRate > 0) {
                double factor = recentRate / baselineRate;

                if (factor >= SPIKE_THRESHOLD_FACTOR && recentCount >= 5) {
                    Anomaly anomaly = new Anomaly();
                    anomaly.setType(AnomalyType.SPIKE);
                    anomaly.setSeverity(calculateSeverity(factor));
                    anomaly.setTitle("Spike in " + errorType);
                    anomaly.setDescription(
                            String.format(
                                    "%s errors increased %.1fx. Current: %d in last hour, Baseline: %.1f/hour",
                                    errorType, factor, recentCount, baselineRate));
                    anomaly.setCurrentValue(recentRate);
                    anomaly.setBaselineValue(baselineRate);
                    anomaly.setDeviationFactor(factor);
                    anomaly.setErrorType(errorType);
                    anomaly.setStartTime(recentStart);
                    anomaly.setEndTime(now);
                    anomaly.setAffectedErrorCount((int) recentCount);

                    anomalies.add(anomaly);
                }
            }
        }

        return anomalies;
    }

    /** Detect new error types that haven't been seen before */
    public List<Anomaly> detectNewErrorTypes() {
        logger.info("Detecting new error types");
        List<Anomaly> anomalies = new ArrayList<>();

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime recentStart = now.minusHours(DETECTION_WINDOW_HOURS);
        LocalDateTime historicalStart = now.minusDays(7);

        // Get recent and historical error types
        List<ErrorLog> recentErrors = errorLogRepository.findRecentErrors(recentStart);
        List<ErrorLog> historicalErrors = errorLogRepository.findRecentErrors(historicalStart);

        Set<String> recentTypes =
                recentErrors.stream().map(ErrorLog::getErrorType).collect(Collectors.toSet());

        Set<String> historicalTypes =
                historicalErrors.stream()
                        .filter(e -> e.getOccurredAt().isBefore(recentStart))
                        .map(ErrorLog::getErrorType)
                        .collect(Collectors.toSet());

        // Find new error types
        Set<String> newTypes = new HashSet<>(recentTypes);
        newTypes.removeAll(historicalTypes);

        for (String errorType : newTypes) {
            long count =
                    recentErrors.stream().filter(e -> e.getErrorType().equals(errorType)).count();

            Anomaly anomaly = new Anomaly();
            anomaly.setType(AnomalyType.NEW_ERROR_TYPE);
            anomaly.setSeverity(count >= 10 ? Severity.HIGH : Severity.MEDIUM);
            anomaly.setTitle("New Error Type: " + errorType);
            anomaly.setDescription(
                    String.format(
                            "Previously unseen error type '%s' appeared %d times in the last hour",
                            errorType, count));
            anomaly.setErrorType(errorType);
            anomaly.setStartTime(recentStart);
            anomaly.setEndTime(now);
            anomaly.setAffectedErrorCount((int) count);

            anomalies.add(anomaly);
            logger.warn("New error type detected: {} ({} occurrences)", errorType, count);
        }

        return anomalies;
    }

    /** Detect errors occurring during unusual times (off-hours) */
    public List<Anomaly> detectUnusualTimePatterns() {
        logger.info("Detecting unusual time patterns");
        List<Anomaly> anomalies = new ArrayList<>();

        LocalDateTime now = LocalDateTime.now();
        LocalDateTime recentStart = now.minusHours(DETECTION_WINDOW_HOURS);

        // Get recent errors
        List<ErrorLog> recentErrors = errorLogRepository.findRecentErrors(recentStart);

        // Filter errors during off-hours (before 6 AM or after 10 PM)
        List<ErrorLog> offHoursErrors =
                recentErrors.stream()
                        .filter(
                                e -> {
                                    LocalTime time = e.getOccurredAt().toLocalTime();
                                    return time.isBefore(NORMAL_START_HOUR)
                                            || time.isAfter(NORMAL_END_HOUR);
                                })
                        .collect(Collectors.toList());

        if (!offHoursErrors.isEmpty() && offHoursErrors.size() >= 5) {
            double offHoursPercentage = (offHoursErrors.size() * 100.0) / recentErrors.size();

            if (offHoursPercentage > 30) { // More than 30% during off-hours
                Anomaly anomaly = new Anomaly();
                anomaly.setType(AnomalyType.UNUSUAL_TIME);
                anomaly.setSeverity(offHoursPercentage > 50 ? Severity.HIGH : Severity.MEDIUM);
                anomaly.setTitle("Unusual Error Pattern During Off-Hours");
                anomaly.setDescription(
                        String.format(
                                "%d errors (%.1f%%) occurred during off-hours (before 6 AM or after 10 PM)",
                                offHoursErrors.size(), offHoursPercentage));
                anomaly.setStartTime(recentStart);
                anomaly.setEndTime(now);
                anomaly.setAffectedErrorCount(offHoursErrors.size());

                anomalies.add(anomaly);
                logger.warn(
                        "Off-hours errors detected: {} errors ({}%)",
                        offHoursErrors.size(), String.format("%.1f", offHoursPercentage));
            }
        }

        return anomalies;
    }

    /** Calculate severity based on deviation factor */
    private Severity calculateSeverity(double factor) {
        if (factor >= 10) {
            return Severity.CRITICAL;
        } else if (factor >= 5) {
            return Severity.HIGH;
        } else if (factor >= 3) {
            return Severity.MEDIUM;
        } else {
            return Severity.LOW;
        }
    }

    /** Get anomaly detection statistics */
    public Map<String, Object> getAnomalyStatistics() {
        List<Anomaly> anomalies = detectAnomalies();

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalAnomalies", anomalies.size());
        stats.put(
                "critical",
                anomalies.stream().filter(a -> a.getSeverity() == Severity.CRITICAL).count());
        stats.put("high", anomalies.stream().filter(a -> a.getSeverity() == Severity.HIGH).count());
        stats.put(
                "medium",
                anomalies.stream().filter(a -> a.getSeverity() == Severity.MEDIUM).count());
        stats.put("low", anomalies.stream().filter(a -> a.getSeverity() == Severity.LOW).count());

        Map<String, Long> byType =
                anomalies.stream()
                        .collect(
                                Collectors.groupingBy(
                                        a -> a.getType().toString(), Collectors.counting()));
        stats.put("byType", byType);

        return stats;
    }
}
