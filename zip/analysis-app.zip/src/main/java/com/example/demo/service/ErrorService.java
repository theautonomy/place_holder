package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import com.example.demo.model.ErrorLog;
import com.example.demo.model.ErrorSubmissionRequest;
import com.example.demo.repository.ErrorLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ErrorService {

    private static final Logger logger = LoggerFactory.getLogger(ErrorService.class);

    private final ErrorLogRepository errorLogRepository;
    private final EmbeddingModel embeddingModel;

    public ErrorService(ErrorLogRepository errorLogRepository, EmbeddingModel embeddingModel) {
        this.errorLogRepository = errorLogRepository;
        this.embeddingModel = embeddingModel;
    }

    @Transactional
    public ErrorLog ingestError(ErrorSubmissionRequest request) {
        logger.info(
                "Ingesting error with stack trace length: {}",
                request.getStackTrace() != null ? request.getStackTrace().length() : 0);

        // Create new error log - ALWAYS create a new row for every occurrence
        ErrorLog errorLog = new ErrorLog();
        errorLog.setStackTrace(request.getStackTrace());

        // Extract error type and message from stack trace
        extractErrorInfo(errorLog, request.getStackTrace());

        // Set additional fields if provided
        if (request.getApplicationName() != null) {
            errorLog.setApplicationName(request.getApplicationName());
        }
        if (request.getEnvironment() != null) {
            errorLog.setEnvironment(request.getEnvironment());
        }

        // Generate and store embedding
        generateAndStoreEmbedding(errorLog);

        // Save to database - each error occurrence is a separate row
        errorLog = errorLogRepository.save(errorLog);
        logger.info("Created new error log with ID: {}", errorLog.getId());

        return errorLog;
    }

    private void extractErrorInfo(ErrorLog errorLog, String stackTrace) {
        if (stackTrace == null || stackTrace.isEmpty()) {
            errorLog.setErrorType("Unknown");
            errorLog.setErrorMessage("No stack trace provided");
            return;
        }

        String[] lines = stackTrace.split("\n");
        if (lines.length > 0) {
            String firstLine = lines[0].trim();

            // Try to extract exception type and message
            int colonIndex = firstLine.indexOf(':');
            if (colonIndex > 0) {
                String exceptionType = firstLine.substring(0, colonIndex).trim();
                String message = firstLine.substring(colonIndex + 1).trim();

                // Extract simple class name from fully qualified name
                int lastDotIndex = exceptionType.lastIndexOf('.');
                if (lastDotIndex > 0) {
                    exceptionType = exceptionType.substring(lastDotIndex + 1);
                }

                errorLog.setErrorType(exceptionType);
                errorLog.setErrorMessage(message);
            } else {
                errorLog.setErrorType("Unknown");
                errorLog.setErrorMessage(firstLine);
            }
        } else {
            errorLog.setErrorType("Unknown");
            errorLog.setErrorMessage("Empty stack trace");
        }
    }

    public List<ErrorLog> getErrorsByStatus(String status) {
        return errorLogRepository.findByStatus(status);
    }

    private void generateAndStoreEmbedding(ErrorLog errorLog) {
        try {
            // Generate embedding using the embedding model
            float[] embedding = embeddingModel.embed(errorLog.getStackTrace());

            // Store embedding in the error log
            errorLog.setEmbedding(embedding);
            logger.info("Generated embedding for error");

        } catch (Exception e) {
            logger.error("Failed to generate embedding", e);
            // Don't fail the entire operation if embedding generation fails
        }
    }

    public List<ErrorLog> getRecentErrors(int hours) {
        LocalDateTime since = LocalDateTime.now().minusHours(hours);
        return errorLogRepository.findRecentErrors(since);
    }

    public List<ErrorLog> getRecentErrors(int hours, int limit) {
        LocalDateTime since = LocalDateTime.now().minusHours(hours);
        List<ErrorLog> allErrors = errorLogRepository.findRecentErrors(since);
        return allErrors.stream().limit(limit).collect(java.util.stream.Collectors.toList());
    }

    public Optional<ErrorLog> getErrorById(Long id) {
        return errorLogRepository.findById(id);
    }

    public List<ErrorLog> getAllErrors() {
        return errorLogRepository.findAll();
    }

    /**
     * Get occurrence statistics for a specific error Returns total count, first occurrence, and
     * last occurrence for errors matching the type and message
     */
    public Map<String, Object> getErrorOccurrenceStats(Long errorId) {
        Map<String, Object> stats = new HashMap<>();

        Optional<ErrorLog> errorOpt = errorLogRepository.findById(errorId);
        if (errorOpt.isEmpty()) {
            return stats;
        }

        ErrorLog error = errorOpt.get();

        logger.info("Finding occurrences for error: type={}", error.getErrorType());

        // Find all occurrences of this error (same error type)
        List<ErrorLog> occurrences = errorLogRepository.findByErrorType(error.getErrorType());

        logger.info("Found {} occurrences", occurrences.size());
        stats.put("totalOccurrences", occurrences.size());

        if (!occurrences.isEmpty()) {
            // Find first and last occurrence
            LocalDateTime firstOccurrence =
                    occurrences.stream()
                            .map(ErrorLog::getOccurredAt)
                            .min(LocalDateTime::compareTo)
                            .orElse(null);

            LocalDateTime lastOccurrence =
                    occurrences.stream()
                            .map(ErrorLog::getOccurredAt)
                            .max(LocalDateTime::compareTo)
                            .orElse(null);

            stats.put("firstOccurrence", firstOccurrence);
            stats.put("lastOccurrence", lastOccurrence);

            logger.info("First: {}, Last: {}", firstOccurrence, lastOccurrence);
        }

        return stats;
    }

    /** Generate a random test error with timestamp in the past 30 days */
    @Transactional
    public ErrorLog generateRecentTestError() {
        Random random = new Random();

        // Random application names
        String[] apps = new String[] {"demo-app", "user-service", "payment-service", "api-gateway"};
        String applicationName = apps[random.nextInt(apps.length)];

        // Random environments
        String[] envs = new String[] {"production", "staging", "development"};
        String environment = envs[random.nextInt(envs.length)];

        // Random error types
        String[] errorTypes =
                new String[] {
                    "NullPointerException",
                    "SQLException",
                    "TimeoutException",
                    "IllegalArgumentException",
                    "IOException",
                    "AuthenticationException",
                    "OutOfMemoryError"
                };
        String errorType = errorTypes[random.nextInt(errorTypes.length)];

        // Random error messages
        String[] messages =
                new String[] {
                    "Cannot invoke method on null object",
                    "Connection timeout to database",
                    "Request timeout",
                    "Invalid user input",
                    "File not found",
                    "Invalid credentials",
                    "Java heap space",
                    "Deadlock detected in transaction",
                    "API call timed out after 30 seconds",
                    "Email format is invalid",
                    "Unable to write to disk",
                    "Session expired",
                    "GC overhead limit exceeded"
                };
        String errorMessage = messages[random.nextInt(messages.length)];

        // Random severities
        String[] severities = new String[] {"CRITICAL", "ERROR", "WARNING"};
        String severity = severities[random.nextInt(severities.length)];

        // Random statuses
        String[] statuses = new String[] {"OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"};
        String status = statuses[random.nextInt(statuses.length)];

        // Generate stack trace
        String stackTrace =
                errorType
                        + ": "
                        + errorMessage
                        + "\n\tat com.example.demo.service.UserService.processUser(UserService.java:"
                        + (10 + random.nextInt(200))
                        + ")\n\tat com.example.demo.controller.UserController.handleRequest(UserController.java:"
                        + (10 + random.nextInt(100))
                        + ")\n\tat org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:123)";

        // Create error log
        ErrorLog errorLog = new ErrorLog();
        errorLog.setApplicationName(applicationName);
        errorLog.setEnvironment(environment);
        errorLog.setErrorType(errorType);
        errorLog.setErrorMessage(errorMessage);
        errorLog.setStackTrace(stackTrace);
        errorLog.setSeverity(severity);
        errorLog.setStatus(status);

        // Set timestamp to NOW for anomaly detection testing
        errorLog.setOccurredAt(LocalDateTime.now());

        // Generate and store embedding
        generateAndStoreEmbedding(errorLog);

        return errorLogRepository.save(errorLog);
    }

    public ErrorLog generateRandomTestError() {
        Random random = new Random();

        // Random application names
        String[] apps = new String[] {"demo-app", "user-service", "payment-service", "api-gateway"};
        String applicationName = apps[random.nextInt(apps.length)];

        // Random environments
        String[] envs = new String[] {"production", "staging", "development"};
        String environment = envs[random.nextInt(envs.length)];

        // Random error types
        String[] errorTypes =
                new String[] {
                    "NullPointerException",
                    "SQLException",
                    "TimeoutException",
                    "IllegalArgumentException",
                    "IOException",
                    "AuthenticationException",
                    "OutOfMemoryError"
                };
        String errorType = errorTypes[random.nextInt(errorTypes.length)];

        // Random error messages
        String[] messages =
                new String[] {
                    "Cannot invoke method on null object",
                    "Connection timeout to database",
                    "Request timeout",
                    "Invalid user input",
                    "File not found",
                    "Invalid credentials",
                    "Java heap space",
                    "Deadlock detected in transaction",
                    "API call timed out after 30 seconds",
                    "Email format is invalid",
                    "Unable to write to disk",
                    "Session expired",
                    "GC overhead limit exceeded"
                };
        String errorMessage = messages[random.nextInt(messages.length)];

        // Random severities
        String[] severities = new String[] {"CRITICAL", "ERROR", "WARNING"};
        String severity = severities[random.nextInt(severities.length)];

        // Random statuses
        String[] statuses = new String[] {"OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"};
        String status = statuses[random.nextInt(statuses.length)];

        // Generate stack trace
        String stackTrace =
                errorType
                        + ": "
                        + errorMessage
                        + "\n\tat com.example.demo.service.UserService.processUser(UserService.java:"
                        + (10 + random.nextInt(200))
                        + ")\n\tat com.example.demo.controller.UserController.handleRequest(UserController.java:"
                        + (10 + random.nextInt(100))
                        + ")\n\tat org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:123)";

        // Create error log
        ErrorLog errorLog = new ErrorLog();
        errorLog.setApplicationName(applicationName);
        errorLog.setEnvironment(environment);
        errorLog.setErrorType(errorType);
        errorLog.setErrorMessage(errorMessage);
        errorLog.setStackTrace(stackTrace);
        errorLog.setSeverity(severity);
        errorLog.setStatus(status);

        // Generate random timestamp in the past 30 days
        long thirtyDaysInSeconds = 30L * 24 * 60 * 60;
        long randomSeconds = (long) (random.nextDouble() * thirtyDaysInSeconds);
        LocalDateTime randomTimestamp = LocalDateTime.now().minusSeconds(randomSeconds);
        errorLog.setOccurredAt(randomTimestamp);

        // Generate and store embedding
        generateAndStoreEmbedding(errorLog);

        // Save
        errorLog = errorLogRepository.save(errorLog);

        logger.info(
                "Generated random test error: id={}, type={}, occurredAt={}",
                errorLog.getId(),
                errorLog.getErrorType(),
                errorLog.getOccurredAt());

        return errorLog;
    }
}
