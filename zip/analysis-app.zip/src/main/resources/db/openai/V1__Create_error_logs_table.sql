-- Error Analysis System - Schema with UI support
-- Stores error occurrences with metadata for analysis and tracking

-- Enable pgvector extension for semantic search
CREATE EXTENSION IF NOT EXISTS vector;

-- Create error_logs table
CREATE TABLE error_logs (
    id BIGSERIAL PRIMARY KEY,
    application_name VARCHAR(255) NOT NULL DEFAULT 'demo-app',
    environment VARCHAR(50) NOT NULL DEFAULT 'production',
    error_type VARCHAR(255) NOT NULL,
    error_message TEXT NOT NULL,
    stack_trace TEXT NOT NULL,
    embedding vector(1536),
    severity VARCHAR(20) NOT NULL DEFAULT 'ERROR',
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    occurrence_count INTEGER NOT NULL DEFAULT 1,
    first_occurrence TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_occurrence TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    occurred_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for efficient querying
CREATE INDEX idx_error_logs_occurred_at ON error_logs(occurred_at DESC);
CREATE INDEX idx_error_logs_status ON error_logs(status);
CREATE INDEX idx_error_logs_severity ON error_logs(severity);
CREATE INDEX idx_error_logs_application ON error_logs(application_name, environment);
CREATE INDEX idx_error_logs_error_type ON error_logs(error_type);
CREATE INDEX idx_error_logs_last_occurrence ON error_logs(last_occurrence DESC);

-- Vector index for semantic similarity search using HNSW
CREATE INDEX idx_error_logs_embedding ON error_logs USING hnsw (embedding vector_cosine_ops);

-- Comments for documentation
COMMENT ON TABLE error_logs IS 'Stores error occurrences with metadata for tracking and analysis';
COMMENT ON COLUMN error_logs.id IS 'Unique identifier for each error';
COMMENT ON COLUMN error_logs.application_name IS 'Name of the application that generated the error';
COMMENT ON COLUMN error_logs.environment IS 'Environment where error occurred (production, staging, etc.)';
COMMENT ON COLUMN error_logs.error_type IS 'Type/class of the error';
COMMENT ON COLUMN error_logs.error_message IS 'Error message';
COMMENT ON COLUMN error_logs.stack_trace IS 'Full exception stack trace';
COMMENT ON COLUMN error_logs.embedding IS 'Vector embedding for semantic similarity search';
COMMENT ON COLUMN error_logs.severity IS 'Error severity level (INFO, WARNING, ERROR, CRITICAL)';
COMMENT ON COLUMN error_logs.status IS 'Current status (OPEN, IN_PROGRESS, RESOLVED, IGNORED)';
COMMENT ON COLUMN error_logs.occurrence_count IS 'Number of times this error has occurred';
COMMENT ON COLUMN error_logs.first_occurrence IS 'When this error was first seen';
COMMENT ON COLUMN error_logs.last_occurrence IS 'When this error was last seen';
COMMENT ON COLUMN error_logs.occurred_at IS 'Timestamp when the error occurred';
