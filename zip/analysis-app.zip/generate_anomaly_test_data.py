import requests
import time
import random

# Generate errors to trigger anomalies - using the NEW /test/recent endpoint
BASE_URL = "http://localhost:8080/api/errors/test/recent"

def generate_spike():
    """Generate a spike of errors with CURRENT timestamps"""
    print("Generating spike of 50 errors with current timestamps...")
    for i in range(50):
        try:
            response = requests.post(BASE_URL)
            if response.status_code == 200:
                print(f"Generated error {i+1}/50")
            else:
                print(f"Failed to generate error: {response.status_code}")
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(0.1)  # Small delay to avoid overwhelming the server

if __name__ == "__main__":
    print("Generating test data to trigger anomaly detection...")
    generate_spike()
    print("\nDone! Refresh the anomalies page at http://localhost:8080/anomalies")
