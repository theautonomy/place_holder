package com.example.springutilsoverview.demos;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.util.UriUtils;

@Component
public class WebToolsDemo {

    public Map<String, Object> demonstrateUriUtils() {
        Map<String, Object> results = new HashMap<>();

        // Encode and decode URI components
        String original = "path with spaces & special chars";
        String encoded = UriUtils.encodePathSegment(original, StandardCharsets.UTF_8);
        String decoded = UriUtils.decode(encoded, StandardCharsets.UTF_8);

        // Encode query parameter
        String queryParam = "search term with spaces";
        String encodedQuery = UriUtils.encodeQueryParam(queryParam, StandardCharsets.UTF_8);

        results.put("original_text", original);
        results.put("encoded_path", encoded);
        results.put("decoded_path", decoded);
        results.put("original_query", queryParam);
        results.put("encoded_query", encodedQuery);

        return results;
    }

    public Map<String, Object> demonstrateUriComponentsBuilder() {
        Map<String, Object> results = new HashMap<>();

        // Build complex URIs
        URI uri1 =
                UriComponentsBuilder.fromHttpUrl("http://example.com")
                        .path("/products/{id}")
                        .queryParam("category", "books")
                        .queryParam("sort", "price")
                        .build("123");

        URI uri2 =
                UriComponentsBuilder.newInstance()
                        .scheme("https")
                        .host("api.example.com")
                        .port(8080)
                        .path("/users/{userId}/orders/{orderId}")
                        .build("456", "789");

        // Build with query params from map
        Map<String, Object> params = new HashMap<>();
        params.put("page", 1);
        params.put("size", 20);
        params.put("filter", "active");

        URI uri3 =
                UriComponentsBuilder.fromHttpUrl("http://example.com/search")
                        .queryParam("page", "{page}")
                        .queryParam("size", "{size}")
                        .queryParam("filter", "{filter}")
                        .build(params);

        results.put("product_uri", uri1.toString());
        results.put("user_order_uri", uri2.toString());
        results.put("search_uri", uri3.toString());
        results.put("query_params", params);

        return results;
    }

    public Map<String, Object> demonstrateHtmlUtils() {
        Map<String, Object> results = new HashMap<>();

        // HTML escaping and unescaping
        String dangerousHtml = "<script>alert('XSS Attack!')</script>";
        String userInput = "User said: <b>Hello World!</b>";

        String escapedScript = HtmlUtils.htmlEscape(dangerousHtml);
        String escapedInput = HtmlUtils.htmlEscape(userInput);

        String htmlEntities = "&lt;b&gt;Bold Text&lt;/b&gt; &amp; more";
        String unescapedEntities = HtmlUtils.htmlUnescape(htmlEntities);

        results.put("dangerous_html", dangerousHtml);
        results.put("escaped_script", escapedScript);
        results.put("user_input", userInput);
        results.put("escaped_input", escapedInput);
        results.put("html_entities", htmlEntities);
        results.put("unescaped_entities", unescapedEntities);

        return results;
    }

    public Map<String, Object> demonstrateCacheControl() {
        Map<String, Object> results = new HashMap<>();

        // Build various cache control headers
        CacheControl noCache = CacheControl.noCache();
        CacheControl maxAge = CacheControl.maxAge(1, TimeUnit.HOURS);
        CacheControl complex =
                CacheControl.maxAge(30, TimeUnit.MINUTES)
                        .noTransform()
                        .mustRevalidate()
                        .cachePrivate();

        results.put("no_cache", noCache.getHeaderValue());
        results.put("max_age_1hour", maxAge.getHeaderValue());
        results.put("complex_cache", complex.getHeaderValue());

        return results;
    }

    public Map<String, Object> demonstrateHttpHeaders() {
        Map<String, Object> results = new HashMap<>();

        // Build HTTP headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setContentLength(1024);
        headers.setCacheControl(CacheControl.maxAge(1, TimeUnit.HOURS));
        headers.add("X-Custom-Header", "Custom Value");
        headers.setAccept(
                java.util.Arrays.asList(MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN));

        results.put("content_type", headers.getContentType());
        results.put("content_length", headers.getContentLength());
        results.put("cache_control", headers.getCacheControl());
        results.put("custom_header", headers.getFirst("X-Custom-Header"));
        results.put("accept_headers", headers.getAccept());
        results.put("all_headers", headers.toSingleValueMap());

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("UriUtils", demonstrateUriUtils());
        allResults.put("UriComponentsBuilder", demonstrateUriComponentsBuilder());
        allResults.put("HtmlUtils", demonstrateHtmlUtils());
        allResults.put("CacheControl", demonstrateCacheControl());
        allResults.put("HttpHeaders", demonstrateHttpHeaders());

        return allResults;
    }
}
