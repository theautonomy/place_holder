package com.example.springutilsoverview.demos;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

@Component
public class SecurityToolsDemo {

    public Map<String, Object> demonstrateDigestUtils() {
        Map<String, Object> results = new HashMap<>();

        String password = "mySecretPassword";
        String data = "Hello, World!";

        // Create MD5 hash
        String md5Hash = DigestUtils.md5DigestAsHex(password.getBytes());
        String dataMd5 = DigestUtils.md5DigestAsHex(data.getBytes());

        results.put("original_password", password);
        results.put("md5_password_hash", md5Hash);
        results.put("original_data", data);
        results.put("md5_data_hash", dataMd5);
        results.put("hash_algorithm", "MD5");

        return results;
    }

    public Map<String, Object> demonstrateBase64Utils() {
        Map<String, Object> results = new HashMap<>();

        String originalText = "Hello, World! This is a test message.";
        byte[] originalBytes = originalText.getBytes();

        // Encode to Base64
        String encoded = Base64.getEncoder().encodeToString(originalBytes);

        // Decode from Base64
        byte[] decodedBytes = Base64.getDecoder().decode(encoded);
        String decodedText = new String(decodedBytes);

        // URL-safe encoding
        String urlSafeEncoded = Base64.getUrlEncoder().encodeToString(originalBytes);
        byte[] urlSafeDecoded = Base64.getUrlDecoder().decode(urlSafeEncoded);
        String urlSafeDecodedText = new String(urlSafeDecoded);

        results.put("original_text", originalText);
        results.put("encoded_base64", encoded);
        results.put("decoded_text", decodedText);
        results.put("url_safe_encoded", urlSafeEncoded);
        results.put("url_safe_decoded_text", urlSafeDecodedText);
        results.put("encoding_successful", originalText.equals(decodedText));

        return results;
    }

    public Map<String, Object> demonstrateTextEncryptor() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create a TextEncryptor
            String password = "myEncryptionPassword";
            String salt = "deadbeef"; // hex-encoded salt

            TextEncryptor encryptor = Encryptors.text(password, salt);

            String originalMessage = "This is a secret message that needs encryption!";

            // Encrypt the message
            String encryptedText = encryptor.encrypt(originalMessage);

            // Decrypt the message
            String decryptedText = encryptor.decrypt(encryptedText);

            results.put("original_message", originalMessage);
            results.put("encrypted_text", encryptedText);
            results.put("decrypted_text", decryptedText);
            results.put("encryption_successful", originalMessage.equals(decryptedText));
            results.put("salt_used", salt);

        } catch (Exception e) {
            results.put("error", e.getMessage());
            results.put("note", "TextEncryptor requires spring-security-crypto dependency");
        }

        return results;
    }

    public Map<String, Object> demonstratePasswordHashing() {
        Map<String, Object> results = new HashMap<>();

        // Demonstrate secure password hashing techniques
        String[] passwords = {"password123", "admin", "mySecurePassword!@#"};

        Map<String, String> hashedPasswords = new HashMap<>();
        for (String password : passwords) {
            String hash = DigestUtils.md5DigestAsHex(password.getBytes());
            hashedPasswords.put(password, hash);
        }

        results.put("original_passwords", passwords);
        results.put("hashed_passwords", hashedPasswords);
        results.put("note", "In production, use BCrypt or SCrypt instead of MD5");

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("DigestUtils", demonstrateDigestUtils());
        allResults.put("Base64Utils", demonstrateBase64Utils());
        allResults.put("TextEncryptor", demonstrateTextEncryptor());
        allResults.put("PasswordHashing", demonstratePasswordHashing());

        return allResults;
    }
}
