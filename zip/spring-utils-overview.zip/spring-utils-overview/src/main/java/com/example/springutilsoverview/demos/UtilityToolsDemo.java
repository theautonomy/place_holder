package com.example.springutilsoverview.demos;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.NumberUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StopWatch;

@Component
public class UtilityToolsDemo {

    @Autowired(required = false)
    private ApplicationEventPublisher eventPublisher;

    public Map<String, Object> demonstrateAssert() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Successful assertions
            Assert.notNull("not null", "Value should not be null");
            Assert.hasText("hello", "Text should not be empty");
            Assert.isTrue(5 > 3, "Five should be greater than three");
            Assert.notEmpty(Arrays.asList("item1", "item2"), "Collection should not be empty");

            results.put("assertions_passed", true);
            results.put(
                    "tested_conditions",
                    Arrays.asList(
                            "notNull with valid string",
                            "hasText with 'hello'",
                            "isTrue with 5 > 3",
                            "notEmpty with list of items"));

        } catch (IllegalArgumentException e) {
            results.put("assertion_failed", e.getMessage());
        }

        // Demonstrate assertion failure (commented out to avoid breaking the demo)
        /*
        try {
            Assert.notNull(null, "This will fail");
        } catch (IllegalArgumentException e) {
            results.put("example_failure", e.getMessage());
        }
        */

        return results;
    }

    public Map<String, Object> demonstrateObjectUtils() {
        Map<String, Object> results = new HashMap<>();

        // Check if objects are empty
        boolean isEmpty1 = ObjectUtils.isEmpty(null);
        boolean isEmpty2 = ObjectUtils.isEmpty("");
        boolean isEmpty3 = ObjectUtils.isEmpty(new int[0]);
        boolean isEmpty4 = ObjectUtils.isEmpty(Collections.emptyList());
        boolean isEmpty5 = ObjectUtils.isEmpty("hello");

        // Null-safe equals comparison
        boolean equals1 = ObjectUtils.nullSafeEquals("hello", "hello");
        boolean equals2 = ObjectUtils.nullSafeEquals(null, null);
        boolean equals3 = ObjectUtils.nullSafeEquals("hello", null);

        // Get display string
        String display1 = ObjectUtils.getDisplayString(null);
        String display2 = ObjectUtils.getDisplayString("hello");
        String display3 = ObjectUtils.getDisplayString(Arrays.asList("a", "b", "c"));

        results.put("isEmpty_null", isEmpty1);
        results.put("isEmpty_empty_string", isEmpty2);
        results.put("isEmpty_empty_array", isEmpty3);
        results.put("isEmpty_empty_list", isEmpty4);
        results.put("isEmpty_hello", isEmpty5);
        results.put("equals_same_strings", equals1);
        results.put("equals_both_null", equals2);
        results.put("equals_one_null", equals3);
        results.put("display_null", display1);
        results.put("display_string", display2);
        results.put("display_list", display3);

        return results;
    }

    public Map<String, Object> demonstrateNumberUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Parse strings to numbers
            Integer parsedInt = NumberUtils.parseNumber("42", Integer.class);
            Double parsedDouble = NumberUtils.parseNumber("3.14159", Double.class);
            Float parsedFloat = NumberUtils.parseNumber("2.71", Float.class);

            // Convert between number types
            Double intToDouble = NumberUtils.convertNumberToTargetClass(42, Double.class);
            Integer doubleToInt = NumberUtils.convertNumberToTargetClass(3.14159, Integer.class);

            results.put("parsed_int", parsedInt);
            results.put("parsed_double", parsedDouble);
            results.put("parsed_float", parsedFloat);
            results.put("int_to_double", intToDouble);
            results.put("double_to_int", doubleToInt);

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateStopWatch() {
        Map<String, Object> results = new HashMap<>();

        StopWatch stopWatch = new StopWatch("Performance Demo");

        try {
            // Time different operations
            stopWatch.start("Fast Operation");
            Thread.sleep(100); // Simulate work
            stopWatch.stop();

            stopWatch.start("Medium Operation");
            Thread.sleep(250); // Simulate more work
            stopWatch.stop();

            stopWatch.start("Slow Operation");
            Thread.sleep(500); // Simulate heavy work
            stopWatch.stop();

            results.put("total_time_seconds", stopWatch.getTotalTimeSeconds());
            results.put("total_time_millis", stopWatch.getTotalTimeMillis());
            results.put("task_count", stopWatch.getTaskCount());
            results.put("pretty_print", stopWatch.prettyPrint());
            results.put("short_summary", stopWatch.shortSummary());

        } catch (InterruptedException e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateJsonParser() {
        Map<String, Object> results = new HashMap<>();

        try {
            JsonParser parser = JsonParserFactory.getJsonParser();

            // Parse JSON object
            String jsonObject = "{\"name\":\"John\", \"age\":30, \"city\":\"New York\"}";
            Map<String, Object> parsedObject = parser.parseMap(jsonObject);

            // Parse JSON array
            String jsonArray = "[{\"id\":1, \"name\":\"Alice\"}, {\"id\":2, \"name\":\"Bob\"}]";
            List<Object> parsedArray = parser.parseList(jsonArray);

            results.put("original_json_object", jsonObject);
            results.put("parsed_object", parsedObject);
            results.put("original_json_array", jsonArray);
            results.put("parsed_array", parsedArray);
            results.put("parser_type", parser.getClass().getSimpleName());

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateCompletableFuture() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create some async tasks
            CompletableFuture<String> future1 =
                    CompletableFuture.supplyAsync(
                            () -> {
                                try {
                                    Thread.sleep(100);
                                } catch (InterruptedException e) {
                                }
                                return "Result from Task 1";
                            });

            CompletableFuture<String> future2 =
                    CompletableFuture.supplyAsync(
                            () -> {
                                try {
                                    Thread.sleep(150);
                                } catch (InterruptedException e) {
                                }
                                return "Result from Task 2";
                            });

            CompletableFuture<String> future3 =
                    CompletableFuture.supplyAsync(
                            () -> {
                                try {
                                    Thread.sleep(200);
                                } catch (InterruptedException e) {
                                }
                                return "Result from Task 3";
                            });

            // Combine all futures
            List<CompletableFuture<String>> futures = Arrays.asList(future1, future2, future3);
            CompletableFuture<Void> allOf =
                    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));

            CompletableFuture<List<String>> allResults =
                    allOf.thenApply(v -> futures.stream().map(CompletableFuture::join).toList());

            // Wait for results (with timeout)
            List<String> combinedResults = allResults.get(1, TimeUnit.SECONDS);

            results.put("individual_results", combinedResults);
            results.put("task_count", futures.size());
            results.put("completion_successful", true);

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAnnotationUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Find annotations on this class
            Component componentAnnotation =
                    AnnotationUtils.findAnnotation(this.getClass(), Component.class);

            if (componentAnnotation != null) {
                String value = AnnotationUtils.getValue(componentAnnotation, "value").toString();
                results.put("component_annotation_found", true);
                results.put("component_value", value);
            } else {
                results.put("component_annotation_found", false);
            }

            results.put("class_name", this.getClass().getSimpleName());
            results.put("annotation_search_target", Component.class.getSimpleName());

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("Assert", demonstrateAssert());
        allResults.put("ObjectUtils", demonstrateObjectUtils());
        allResults.put("NumberUtils", demonstrateNumberUtils());
        allResults.put("StopWatch", demonstrateStopWatch());
        allResults.put("JsonParser", demonstrateJsonParser());
        allResults.put("CompletableFuture", demonstrateCompletableFuture());
        allResults.put("AnnotationUtils", demonstrateAnnotationUtils());

        return allResults;
    }
}
