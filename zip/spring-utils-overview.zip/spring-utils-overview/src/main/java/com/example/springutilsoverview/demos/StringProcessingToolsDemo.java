package com.example.springutilsoverview.demos;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PatternMatchUtils;
import org.springframework.util.PropertyPlaceholderHelper;
import org.springframework.util.StringUtils;

@Component
public class StringProcessingToolsDemo {

    public Map<String, Object> demonstrateStringUtils() {
        Map<String, Object> results = new HashMap<>();

        // StringUtils demonstrations
        boolean isEmpty1 = StringUtils.isEmpty(null);
        boolean isEmpty2 = StringUtils.isEmpty("");
        boolean hasText1 = StringUtils.hasText("   ");
        boolean hasText2 = StringUtils.hasText("hello");
        String[] tokens = StringUtils.tokenizeToStringArray("a,b,c", ",");
        String trimmed = StringUtils.trimWhitespace("  hello world  ");
        String capitalized = StringUtils.capitalize("hello");

        results.put("isEmpty_null", isEmpty1);
        results.put("isEmpty_empty", isEmpty2);
        results.put("hasText_whitespace", hasText1);
        results.put("hasText_hello", hasText2);
        results.put("tokenized", tokens);
        results.put("trimmed", trimmed);
        results.put("capitalized", capitalized);

        return results;
    }

    public Map<String, Object> demonstrateAntPathMatcher() {
        Map<String, Object> results = new HashMap<>();
        AntPathMatcher matcher = new AntPathMatcher();

        boolean match1 = matcher.match("/users/*", "/users/123");
        boolean match2 = matcher.match("/users/**", "/users/123/orders");
        boolean match3 = matcher.match("/user?", "/user1");

        Map<String, String> vars = matcher.extractUriTemplateVariables("/users/{id}", "/users/42");

        results.put("wildcard_match", match1);
        results.put("recursive_match", match2);
        results.put("single_char_match", match3);
        results.put("extracted_variables", vars);

        return results;
    }

    public Map<String, Object> demonstratePatternMatchUtils() {
        Map<String, Object> results = new HashMap<>();

        boolean matches1 = PatternMatchUtils.simpleMatch("user*", "username");
        boolean matches2 = PatternMatchUtils.simpleMatch("user?", "user1");
        boolean matches3 =
                PatternMatchUtils.simpleMatch(new String[] {"user*", "admin*"}, "adminuser");

        results.put("pattern_match_1", matches1);
        results.put("pattern_match_2", matches2);
        results.put("pattern_match_3", matches3);

        return results;
    }

    public Map<String, Object> demonstratePropertyPlaceholderHelper() {
        Map<String, Object> results = new HashMap<>();
        PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper("${", "}");

        Properties props = new Properties();
        props.setProperty("name", "World");
        props.setProperty("greeting", "Hello ${name}!");

        String result1 = helper.replacePlaceholders("${greeting}", props::getProperty);
        String result2 = helper.replacePlaceholders("Welcome ${name}!", props::getProperty);

        results.put("placeholder_result_1", result1);
        results.put("placeholder_result_2", result2);
        results.put("properties", props);

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("StringUtils", demonstrateStringUtils());
        allResults.put("AntPathMatcher", demonstrateAntPathMatcher());
        allResults.put("PatternMatchUtils", demonstratePatternMatchUtils());
        allResults.put("PropertyPlaceholderHelper", demonstratePropertyPlaceholderHelper());

        return allResults;
    }
}
