package com.example.springutilsoverview.demos;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.springframework.format.datetime.DateFormatter;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Component
public class DateTimeToolsDemo {

    public Map<String, Object> demonstrateDateFormatter() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create DateFormatter with different patterns
            DateFormatter formatter1 = new DateFormatter("yyyy-MM-dd HH:mm:ss");
            DateFormatter formatter2 = new DateFormatter("dd/MM/yyyy");
            DateFormatter formatter3 = new DateFormatter("MMM dd, yyyy");

            Date now = new Date();
            Locale defaultLocale = Locale.getDefault();

            // Format dates using different patterns
            String formatted1 = formatter1.print(now, defaultLocale);
            String formatted2 = formatter2.print(now, defaultLocale);
            String formatted3 = formatter3.print(now, defaultLocale);

            results.put("current_date", now.toString());
            results.put("format_yyyy_MM_dd_HH_mm_ss", formatted1);
            results.put("format_dd_MM_yyyy", formatted2);
            results.put("format_MMM_dd_yyyy", formatted3);
            results.put("default_locale", defaultLocale.toString());

            // Parse dates back from strings
            try {
                Date parsed1 = formatter1.parse(formatted1, defaultLocale);
                results.put("parsed_date_successful", true);
                results.put("parsed_date", parsed1.toString());
                results.put(
                        "dates_match",
                        Math.abs(now.getTime() - parsed1.getTime()) < 1000); // Within 1 second
            } catch (Exception e) {
                results.put("parsing_error", e.getMessage());
            }

            // Demonstrate with different locales
            Locale frenchLocale = Locale.FRENCH;
            String frenchFormatted = formatter3.print(now, frenchLocale);
            results.put("french_formatted", frenchFormatted);
            results.put("french_locale", frenchLocale.toString());

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAdvancedStopWatch() {
        Map<String, Object> results = new HashMap<>();

        try {
            StopWatch stopWatch = new StopWatch("Advanced Performance Demo");

            // Simulate different types of operations
            stopWatch.start("Database Query Simulation");
            Thread.sleep(150); // Simulate database query
            stopWatch.stop();

            stopWatch.start("Cache Operation");
            Thread.sleep(50); // Simulate cache operation
            stopWatch.stop();

            stopWatch.start("API Call Simulation");
            Thread.sleep(300); // Simulate external API call
            stopWatch.stop();

            stopWatch.start("Data Processing");
            Thread.sleep(100); // Simulate data processing
            stopWatch.stop();

            stopWatch.start("Response Generation");
            Thread.sleep(75); // Simulate response generation
            stopWatch.stop();

            // Collect detailed timing information
            results.put("task_name", stopWatch.getId());
            results.put("total_time_seconds", stopWatch.getTotalTimeSeconds());
            results.put("total_time_millis", stopWatch.getTotalTimeMillis());
            results.put("total_time_nanos", stopWatch.getTotalTimeNanos());
            results.put("task_count", stopWatch.getTaskCount());

            // Get information about individual tasks
            StopWatch.TaskInfo[] taskInfos = stopWatch.getTaskInfo();
            List<Map<String, Object>> taskDetails = new ArrayList<>();

            for (StopWatch.TaskInfo taskInfo : taskInfos) {
                Map<String, Object> taskDetail = new HashMap<>();
                taskDetail.put("task_name", taskInfo.getTaskName());
                taskDetail.put("time_millis", taskInfo.getTimeMillis());
                taskDetail.put("time_seconds", taskInfo.getTimeSeconds());
                taskDetail.put(
                        "percentage",
                        String.format(
                                "%.2f%%",
                                (double) taskInfo.getTimeMillis()
                                        / stopWatch.getTotalTimeMillis()
                                        * 100));
                taskDetails.add(taskDetail);
            }

            results.put("task_details", taskDetails);
            results.put("pretty_print", stopWatch.prettyPrint());
            results.put("short_summary", stopWatch.shortSummary());

            // Find slowest and fastest tasks
            StopWatch.TaskInfo slowest =
                    Arrays.stream(taskInfos)
                            .max(Comparator.comparingLong(StopWatch.TaskInfo::getTimeMillis))
                            .orElse(null);

            StopWatch.TaskInfo fastest =
                    Arrays.stream(taskInfos)
                            .min(Comparator.comparingLong(StopWatch.TaskInfo::getTimeMillis))
                            .orElse(null);

            if (slowest != null) {
                results.put("slowest_task", slowest.getTaskName());
                results.put("slowest_time", slowest.getTimeMillis());
            }

            if (fastest != null) {
                results.put("fastest_task", fastest.getTaskName());
                results.put("fastest_time", fastest.getTimeMillis());
            }

        } catch (InterruptedException e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateModernDateTimeAlternatives() {
        Map<String, Object> results = new HashMap<>();

        // Show modern Java 8+ alternatives to DateFormatter
        LocalDateTime now = LocalDateTime.now();

        // Modern DateTimeFormatter examples
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("MMM dd, yyyy");
        DateTimeFormatter formatter4 = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        String modern1 = now.format(formatter1);
        String modern2 = now.format(formatter2);
        String modern3 = now.format(formatter3);
        String modern4 = now.format(formatter4);

        results.put("note", "Modern Java 8+ alternatives to Spring's DateFormatter");
        results.put("current_datetime", now.toString());
        results.put("modern_format_1", modern1);
        results.put("modern_format_2", modern2);
        results.put("modern_format_3", modern3);
        results.put("iso_format", modern4);

        // Performance comparison example
        StopWatch comparison = new StopWatch("Date Formatting Comparison");

        Date legacyDate = new Date();
        DateFormatter springFormatter = new DateFormatter("yyyy-MM-dd HH:mm:ss");

        // Time Spring DateFormatter
        comparison.start("Spring DateFormatter");
        for (int i = 0; i < 1000; i++) {
            springFormatter.print(legacyDate, Locale.getDefault());
        }
        comparison.stop();

        // Time modern DateTimeFormatter
        comparison.start("Modern DateTimeFormatter");
        for (int i = 0; i < 1000; i++) {
            now.format(formatter1);
        }
        comparison.stop();

        results.put("performance_comparison", comparison.prettyPrint());

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("DateFormatter", demonstrateDateFormatter());
        allResults.put("AdvancedStopWatch", demonstrateAdvancedStopWatch());
        allResults.put("ModernAlternatives", demonstrateModernDateTimeAlternatives());

        return allResults;
    }
}
