package com.example.springutilsoverview.demos;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.stereotype.Component;

@Component
public class SpringContextToolsDemo {

    @Autowired(required = false)
    private ApplicationEventPublisher eventPublisher;

    @Autowired(required = false)
    private ConfigurableEnvironment environment;

    @Autowired(required = false)
    private ApplicationContext applicationContext;

    // Store published events for demonstration
    private final List<CustomEvent> publishedEvents = new ArrayList<>();

    public Map<String, Object> demonstrateApplicationEventPublisher() {
        Map<String, Object> results = new HashMap<>();

        try {
            if (eventPublisher != null) {
                // Clear previous events
                publishedEvents.clear();

                // Publish different types of events
                CustomEvent userLoginEvent =
                        new CustomEvent("user.login", "User John logged in", new HashMap<>());
                CustomEvent dataProcessedEvent =
                        new CustomEvent(
                                "data.processed",
                                "Batch job completed",
                                Map.of("recordCount", 1000));
                CustomEvent systemNotificationEvent =
                        new CustomEvent(
                                "system.notification",
                                "System maintenance scheduled",
                                Map.of("maintenanceTime", LocalDateTime.now().plusHours(2)));

                eventPublisher.publishEvent(userLoginEvent);
                eventPublisher.publishEvent(dataProcessedEvent);
                eventPublisher.publishEvent(systemNotificationEvent);

                // Give a moment for async processing
                Thread.sleep(100);

                results.put("events_published", 3);
                results.put("events_received", publishedEvents.size());
                results.put(
                        "event_details",
                        publishedEvents.stream()
                                .map(
                                        event ->
                                                Map.of(
                                                        "type", event.getEventType(),
                                                        "message", event.getMessage(),
                                                        "timestamp", event.getTimestamp(),
                                                        "metadata_keys",
                                                                event.getMetadata().keySet()))
                                .toList());

                results.put("publisher_available", true);
                results.put(
                        "use_cases",
                        Arrays.asList(
                                "Decoupled component communication",
                                "Audit logging and monitoring",
                                "Real-time notifications",
                                "Workflow orchestration",
                                "Cache invalidation",
                                "Event-driven architecture"));

            } else {
                results.put("publisher_available", false);
                results.put("note", "ApplicationEventPublisher not available in current context");
            }

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateLocaleContextHolder() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Get current locale
            Locale currentLocale = LocaleContextHolder.getLocale();

            results.put("current_locale", currentLocale.toString());
            results.put("language", currentLocale.getLanguage());
            results.put("country", currentLocale.getCountry());
            results.put("display_name", currentLocale.getDisplayName());
            results.put("display_language", currentLocale.getDisplayLanguage());
            results.put("display_country", currentLocale.getDisplayCountry());

            // Store original locale
            Locale originalLocale = currentLocale;

            // Test different locales
            List<Map<String, Object>> localeTests = new ArrayList<>();

            Locale[] testLocales = {
                Locale.FRENCH,
                Locale.GERMAN,
                Locale.JAPANESE,
                Locale.forLanguageTag("es-ES"),
                Locale.forLanguageTag("pt-BR")
            };

            for (Locale testLocale : testLocales) {
                // Temporarily set locale
                LocaleContextHolder.setLocale(testLocale);

                Map<String, Object> localeInfo = new HashMap<>();
                localeInfo.put("locale", testLocale.toString());
                localeInfo.put("language", testLocale.getLanguage());
                localeInfo.put("country", testLocale.getCountry());
                localeInfo.put("display_name", testLocale.getDisplayName(Locale.ENGLISH));
                localeInfo.put("current_from_holder", LocaleContextHolder.getLocale().toString());

                localeTests.add(localeInfo);
            }

            results.put("locale_tests", localeTests);

            // Restore original locale
            LocaleContextHolder.setLocale(originalLocale);
            results.put("locale_restored", LocaleContextHolder.getLocale().toString());

            // Demonstrate use cases
            results.put(
                    "use_cases",
                    Arrays.asList(
                            "Internationalization (i18n)",
                            "Date/time formatting per locale",
                            "Number formatting",
                            "Currency formatting",
                            "Message localization",
                            "Cultural-specific sorting"));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateDefaultConversionService() {
        Map<String, Object> results = new HashMap<>();

        try {
            DefaultConversionService conversionService = new DefaultConversionService();

            // Test various type conversions
            Map<String, Object> conversions = new HashMap<>();

            // String to numbers
            Integer stringToInt = conversionService.convert("42", Integer.class);
            Double stringToDouble = conversionService.convert("3.14159", Double.class);
            BigDecimal stringToBigDecimal =
                    conversionService.convert("12345.6789", BigDecimal.class);

            conversions.put("string_42_to_integer", stringToInt);
            conversions.put("string_3.14159_to_double", stringToDouble);
            conversions.put("string_to_bigdecimal", stringToBigDecimal);

            // Boolean conversions
            Boolean stringToBoolean1 = conversionService.convert("true", Boolean.class);
            Boolean stringToBoolean2 = conversionService.convert("false", Boolean.class);
            Boolean stringToBoolean3 = conversionService.convert("yes", Boolean.class);
            Boolean stringToBoolean4 = conversionService.convert("1", Boolean.class);

            conversions.put("string_true_to_boolean", stringToBoolean1);
            conversions.put("string_false_to_boolean", stringToBoolean2);
            conversions.put("string_yes_to_boolean", stringToBoolean3);
            conversions.put("string_1_to_boolean", stringToBoolean4);

            // Number to number conversions
            Double intToDouble = conversionService.convert(42, Double.class);
            Integer doubleToInt = conversionService.convert(42.7, Integer.class);

            conversions.put("int_42_to_double", intToDouble);
            conversions.put("double_42.7_to_int", doubleToInt);

            // Collection conversions
            String[] stringArray = {"apple", "banana", "cherry"};
            List<String> arrayToList = conversionService.convert(stringArray, List.class);

            conversions.put("string_array_to_list", arrayToList);
            conversions.put("converted_list_size", arrayToList != null ? arrayToList.size() : 0);

            results.put("conversions", conversions);

            // Test conversion capabilities
            boolean canConvertStringToInt =
                    conversionService.canConvert(String.class, Integer.class);
            boolean canConvertIntToString =
                    conversionService.canConvert(Integer.class, String.class);
            boolean canConvertListToArray =
                    conversionService.canConvert(List.class, String[].class);
            boolean canConvertDateToString = conversionService.canConvert(Date.class, String.class);

            Map<String, Boolean> capabilities = new HashMap<>();
            capabilities.put("string_to_integer", canConvertStringToInt);
            capabilities.put("integer_to_string", canConvertIntToString);
            capabilities.put("list_to_array", canConvertListToArray);
            capabilities.put("date_to_string", canConvertDateToString);

            results.put("conversion_capabilities", capabilities);

            // Count available converters (approximately)
            results.put("note", "DefaultConversionService provides 100+ built-in converters");
            results.put(
                    "converter_types",
                    Arrays.asList(
                            "String to Number converters",
                            "Number to String converters",
                            "Collection to Array converters",
                            "Array to Collection converters",
                            "Enum converters",
                            "Date/Time converters",
                            "Boolean converters"));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstratePropertySourceUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            if (environment != null) {
                // Add a custom property source for demonstration
                Map<String, Object> customProps = new HashMap<>();
                customProps.put("demo.application.name", "Spring Utils Demo");
                customProps.put("demo.version", "1.0.0");
                customProps.put("demo.author", "Spring Framework");
                customProps.put("demo.features.count", "49");

                MapPropertySource customPropertySource =
                        new MapPropertySource("demo-properties", customProps);
                environment.getPropertySources().addFirst(customPropertySource);

                // Get property sources information
                results.put("property_sources_added", true);
                results.put("total_property_sources", environment.getPropertySources().size());

                // List property source names
                List<String> propertySourceNames = new ArrayList<>();
                environment
                        .getPropertySources()
                        .forEach(ps -> propertySourceNames.add(ps.getName()));
                results.put("property_source_names", propertySourceNames);

                // Get properties from different sources
                Map<String, Object> resolvedProperties = new HashMap<>();
                resolvedProperties.put(
                        "demo.application.name", environment.getProperty("demo.application.name"));
                resolvedProperties.put("demo.version", environment.getProperty("demo.version"));
                resolvedProperties.put("java.version", environment.getProperty("java.version"));
                resolvedProperties.put(
                        "spring.application.name",
                        environment.getProperty("spring.application.name"));

                results.put("resolved_properties", resolvedProperties);

                // Property resolution with defaults
                String unknownProperty =
                        environment.getProperty("unknown.property", "default-value");
                results.put("unknown_property_with_default", unknownProperty);

                // Active profiles
                String[] activeProfiles = environment.getActiveProfiles();
                String[] defaultProfiles = environment.getDefaultProfiles();

                results.put("active_profiles", Arrays.asList(activeProfiles));
                results.put("default_profiles", Arrays.asList(defaultProfiles));

                // Property source precedence demo
                results.put(
                        "precedence_note",
                        "Properties are resolved in order: Custom -> Application -> System -> Environment");

            } else {
                results.put("environment_available", false);
                results.put("note", "ConfigurableEnvironment not available");
            }

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("ApplicationEventPublisher", demonstrateApplicationEventPublisher());
        allResults.put("LocaleContextHolder", demonstrateLocaleContextHolder());
        allResults.put("DefaultConversionService", demonstrateDefaultConversionService());
        allResults.put("PropertySourceUtils", demonstratePropertySourceUtils());

        return allResults;
    }

    // Event listener for demonstration
    @EventListener
    public void handleCustomEvent(CustomEvent event) {
        publishedEvents.add(event);
    }

    // Custom event class for demonstration
    public static class CustomEvent {
        private final String eventType;
        private final String message;
        private final Map<String, Object> metadata;
        private final Date timestamp;

        public CustomEvent(String eventType, String message, Map<String, Object> metadata) {
            this.eventType = eventType;
            this.message = message;
            this.metadata = metadata;
            this.timestamp = new Date();
        }

        // Getters
        public String getEventType() {
            return eventType;
        }

        public String getMessage() {
            return message;
        }

        public Map<String, Object> getMetadata() {
            return metadata;
        }

        public Date getTimestamp() {
            return timestamp;
        }
    }
}
