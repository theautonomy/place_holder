package com.example.springutilsoverview.controller;

import java.util.*;

import com.example.springutilsoverview.demos.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/demos")
@CrossOrigin(origins = "*")
public class DemoController {

    @Autowired private StringProcessingToolsDemo stringProcessingToolsDemo;

    @Autowired private CollectionToolsDemo collectionToolsDemo;

    @Autowired private ReflectionToolsDemo reflectionToolsDemo;

    @Autowired private WebToolsDemo webToolsDemo;

    @Autowired private SecurityToolsDemo securityToolsDemo;

    @Autowired private UtilityToolsDemo utilityToolsDemo;

    @Autowired private IOResourceToolsDemo ioResourceToolsDemo;

    @Autowired private DateTimeToolsDemo dateTimeToolsDemo;

    @Autowired private DataConversionToolsDemo dataConversionToolsDemo;

    @Autowired private AdvancedWebToolsDemo advancedWebToolsDemo;

    @Autowired private SpringContextToolsDemo springContextToolsDemo;

    @Autowired private AOPToolsDemo aopToolsDemo;

    @Autowired private ConfigurationToolsDemo configurationToolsDemo;

    @GetMapping
    public ResponseEntity<Map<String, Object>> listAllDemos() {
        Map<String, Object> response = new HashMap<>();

        List<Map<String, String>> demos =
                Arrays.asList(
                        createDemoInfo(
                                "string",
                                "String Processing Tools",
                                "StringUtils, AntPathMatcher, PatternMatchUtils, PropertyPlaceholderHelper"),
                        createDemoInfo(
                                "collection",
                                "Collection and Array Tools",
                                "CollectionUtils, MultiValueMap, ConcurrentReferenceHashMap, SystemPropertyUtils"),
                        createDemoInfo(
                                "reflection",
                                "Reflection and Class Manipulation Tools",
                                "ReflectionUtils, ClassUtils, MethodInvoker, BeanUtils"),
                        createDemoInfo(
                                "web",
                                "Web-Related Tools",
                                "UriUtils, UriComponentsBuilder, HtmlUtils, CacheControl, HttpHeaders"),
                        createDemoInfo(
                                "security",
                                "Security-Related Tools",
                                "DigestUtils, Base64Utils, TextEncryptor"),
                        createDemoInfo(
                                "utility",
                                "Utility Tools",
                                "Assert, ObjectUtils, NumberUtils, StopWatch, JsonParser, CompletableFuture, AnnotationUtils"),
                        createDemoInfo(
                                "io-resource",
                                "I/O and Resource Tools",
                                "FileCopyUtils, ResourceUtils, StreamUtils, FileSystemUtils, ResourcePatternUtils"),
                        createDemoInfo(
                                "datetime",
                                "Date and Time Tools",
                                "DateFormatter, StopWatch (Advanced), Modern Alternatives"),
                        createDemoInfo(
                                "data-conversion",
                                "Data Conversion Tools",
                                "ResolvableType, MappingJackson2HttpMessageConverter, MediaTypeFactory, MimeTypeUtils"),
                        createDemoInfo(
                                "advanced-web",
                                "Advanced Web Tools",
                                "WebClient.Builder, ContentCachingRequestWrapper, WebUtils Concepts"),
                        createDemoInfo(
                                "spring-context",
                                "Spring Context Tools",
                                "ApplicationEventPublisher, LocaleContextHolder, DefaultConversionService, PropertySourceUtils"),
                        createDemoInfo(
                                "aop",
                                "AOP Tools",
                                "AopUtils, ProxyFactory, ClassPathScanningCandidateComponentProvider"),
                        createDemoInfo(
                                "configuration",
                                "Configuration Tools",
                                "YamlPropertiesFactoryBean, RandomStringUtils, Additional Utilities"),
                        createDemoInfo(
                                "all",
                                "All Demonstrations",
                                "Complete demonstration of all 49+ utility categories"));

        response.put("title", "Spring Framework - 49 Essential Utility Classes Demo");
        response.put(
                "description",
                "Interactive demonstrations of Spring Boot's most useful utility classes");
        response.put("totalDemos", demos.size());
        response.put("totalUtilities", "49+ Essential Spring Utilities Covered");
        response.put("demos", demos);
        response.put("usage", "Access each demo by appending the demo ID to /api/demos/");

        return ResponseEntity.ok(response);
    }

    @GetMapping("/string")
    public ResponseEntity<Map<String, Object>> demonstrateStringTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "String Processing Tools");
        response.put("description", "Demonstrations of Spring's string manipulation utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "StringUtils",
                        "AntPathMatcher",
                        "PatternMatchUtils",
                        "PropertyPlaceholderHelper"));
        response.put("results", stringProcessingToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/collection")
    public ResponseEntity<Map<String, Object>> demonstrateCollectionTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Collection and Array Tools");
        response.put("description", "Demonstrations of Spring's collection manipulation utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "CollectionUtils",
                        "MultiValueMap",
                        "ConcurrentReferenceHashMap",
                        "SystemPropertyUtils"));
        response.put("results", collectionToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/reflection")
    public ResponseEntity<Map<String, Object>> demonstrateReflectionTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Reflection and Class Manipulation Tools");
        response.put("description", "Demonstrations of Spring's reflection and bean utilities");
        response.put(
                "utilities",
                Arrays.asList("ReflectionUtils", "ClassUtils", "MethodInvoker", "BeanUtils"));
        response.put("results", reflectionToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/web")
    public ResponseEntity<Map<String, Object>> demonstrateWebTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Web-Related Tools");
        response.put("description", "Demonstrations of Spring's web development utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "UriUtils",
                        "UriComponentsBuilder",
                        "HtmlUtils",
                        "CacheControl",
                        "HttpHeaders"));
        response.put("results", webToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/security")
    public ResponseEntity<Map<String, Object>> demonstrateSecurityTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Security-Related Tools");
        response.put("description", "Demonstrations of Spring's security utilities");
        response.put("utilities", Arrays.asList("DigestUtils", "Base64Utils", "TextEncryptor"));
        response.put("results", securityToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/utility")
    public ResponseEntity<Map<String, Object>> demonstrateUtilityTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Utility Tools");
        response.put("description", "Demonstrations of Spring's general purpose utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "Assert",
                        "ObjectUtils",
                        "NumberUtils",
                        "StopWatch",
                        "JsonParser",
                        "CompletableFuture",
                        "AnnotationUtils"));
        response.put("results", utilityToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/io-resource")
    public ResponseEntity<Map<String, Object>> demonstrateIOResourceTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "I/O and Resource Tools");
        response.put("description", "Demonstrations of Spring's I/O and resource utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "FileCopyUtils",
                        "ResourceUtils",
                        "StreamUtils",
                        "FileSystemUtils",
                        "ResourcePatternUtils"));
        response.put("results", ioResourceToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/datetime")
    public ResponseEntity<Map<String, Object>> demonstrateDateTimeTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Date and Time Tools");
        response.put(
                "description",
                "Demonstrations of Spring's date/time utilities and modern alternatives");
        response.put(
                "utilities",
                Arrays.asList(
                        "DateFormatter", "StopWatch (Advanced)", "Modern Java 8+ Alternatives"));
        response.put("results", dateTimeToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/data-conversion")
    public ResponseEntity<Map<String, Object>> demonstrateDataConversionTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Data Conversion Tools");
        response.put(
                "description", "Demonstrations of Spring's data conversion and type utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "ResolvableType",
                        "MappingJackson2HttpMessageConverter",
                        "MediaTypeFactory",
                        "MimeTypeUtils"));
        response.put("results", dataConversionToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/advanced-web")
    public ResponseEntity<Map<String, Object>> demonstrateAdvancedWebTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Advanced Web Tools");
        response.put(
                "description", "Demonstrations of Spring's advanced web development utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "WebClient.Builder", "ContentCachingRequestWrapper", "WebUtils Concepts"));
        response.put("results", advancedWebToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/spring-context")
    public ResponseEntity<Map<String, Object>> demonstrateSpringContextTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Spring Context Tools");
        response.put("description", "Demonstrations of Spring's context and environment utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "ApplicationEventPublisher",
                        "LocaleContextHolder",
                        "DefaultConversionService",
                        "PropertySourceUtils"));
        response.put("results", springContextToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/aop")
    public ResponseEntity<Map<String, Object>> demonstrateAOPTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "AOP Tools");
        response.put(
                "description", "Demonstrations of Spring's Aspect-Oriented Programming utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "AopUtils", "ProxyFactory", "ClassPathScanningCandidateComponentProvider"));
        response.put("results", aopToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/configuration")
    public ResponseEntity<Map<String, Object>> demonstrateConfigurationTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("category", "Configuration Tools");
        response.put(
                "description", "Demonstrations of Spring's configuration and additional utilities");
        response.put(
                "utilities",
                Arrays.asList(
                        "YamlPropertiesFactoryBean",
                        "RandomStringUtils",
                        "Additional Utilities Summary"));
        response.put("results", configurationToolsDemo.demonstrateAll());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> demonstrateAllTools() {
        Map<String, Object> response = new HashMap<>();
        response.put("title", "Complete Spring Utilities Demonstration - 49+ Essential Utilities");
        response.put(
                "description", "All utility class demonstrations in one comprehensive response");

        Map<String, Object> allDemos = new HashMap<>();
        allDemos.put("StringProcessing", stringProcessingToolsDemo.demonstrateAll());
        allDemos.put("Collections", collectionToolsDemo.demonstrateAll());
        allDemos.put("Reflection", reflectionToolsDemo.demonstrateAll());
        allDemos.put("Web", webToolsDemo.demonstrateAll());
        allDemos.put("Security", securityToolsDemo.demonstrateAll());
        allDemos.put("Utilities", utilityToolsDemo.demonstrateAll());
        allDemos.put("IOResource", ioResourceToolsDemo.demonstrateAll());
        allDemos.put("DateTime", dateTimeToolsDemo.demonstrateAll());
        allDemos.put("DataConversion", dataConversionToolsDemo.demonstrateAll());
        allDemos.put("AdvancedWeb", advancedWebToolsDemo.demonstrateAll());
        allDemos.put("SpringContext", springContextToolsDemo.demonstrateAll());
        allDemos.put("AOP", aopToolsDemo.demonstrateAll());
        allDemos.put("Configuration", configurationToolsDemo.demonstrateAll());

        response.put("demonstrations", allDemos);
        response.put("totalCategories", allDemos.size());
        response.put("utilityCount", "49+ Essential Spring Framework Utilities");

        return ResponseEntity.ok(response);
    }

    private Map<String, String> createDemoInfo(String id, String name, String description) {
        Map<String, String> demo = new HashMap<>();
        demo.put("id", id);
        demo.put("name", name);
        demo.put("description", description);
        demo.put("endpoint", "/api/demos/" + id);
        return demo;
    }
}
