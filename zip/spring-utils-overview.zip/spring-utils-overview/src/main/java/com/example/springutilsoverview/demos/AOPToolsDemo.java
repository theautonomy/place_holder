package com.example.springutilsoverview.demos;

import java.util.*;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Component
public class AOPToolsDemo {

    public Map<String, Object> demonstrateAopUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create a target object
            SampleService sampleService = new SampleService();

            // Create a proxy using ProxyFactory
            ProxyFactory proxyFactory = new ProxyFactory(sampleService);
            proxyFactory.addAdvice(new LoggingInterceptor());
            Object proxy = proxyFactory.getProxy();

            // Use AopUtils to analyze the objects
            boolean isAopProxy = AopUtils.isAopProxy(proxy);
            boolean isJdkProxy = AopUtils.isJdkDynamicProxy(proxy);
            boolean isCglibProxy = AopUtils.isCglibProxy(proxy);

            results.put("original_is_proxy", AopUtils.isAopProxy(sampleService));
            results.put("proxy_is_aop_proxy", isAopProxy);
            results.put("proxy_is_jdk_proxy", isJdkProxy);
            results.put("proxy_is_cglib_proxy", isCglibProxy);

            // Get target class information
            Class<?> originalClass = AopUtils.getTargetClass(sampleService);
            Class<?> proxyTargetClass = AopUtils.getTargetClass(proxy);

            results.put("original_class", originalClass.getSimpleName());
            results.put("proxy_target_class", proxyTargetClass.getSimpleName());
            results.put("classes_match", originalClass.equals(proxyTargetClass));

            // Test method invocation
            String originalResult = sampleService.processData("test");
            String proxyResult = ((SampleServiceInterface) proxy).processData("test");

            results.put("original_result", originalResult);
            results.put("proxy_result", proxyResult);
            results.put("results_match", originalResult.equals(proxyResult));

            // Demonstrate target class resolution (ultimateTargetClass removed in newer versions)
            results.put("target_class_from_proxy", AopUtils.getTargetClass(proxy).getSimpleName());

            // AopUtils capabilities
            results.put(
                    "aop_utils_capabilities",
                    Arrays.asList(
                            "Detect if object is AOP proxy",
                            "Distinguish between JDK and CGLIB proxies",
                            "Get target class from proxy",
                            "Resolve ultimate target class",
                            "Check proxy type compatibility"));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateProxyFactory() {
        Map<String, Object> results = new HashMap<>();

        try {
            SampleService target = new SampleService();

            // Create proxy with interface
            ProxyFactory factory1 = new ProxyFactory();
            factory1.setTarget(target);
            factory1.addInterface(SampleServiceInterface.class);
            factory1.addAdvice(new LoggingInterceptor());
            Object interfaceProxy = factory1.getProxy();

            // Create CGLIB proxy
            ProxyFactory factory2 = new ProxyFactory();
            factory2.setTarget(target);
            factory2.setProxyTargetClass(true); // Force CGLIB
            factory2.addAdvice(new PerformanceInterceptor());
            Object cglibProxy = factory2.getProxy();

            // Multiple advice example
            ProxyFactory factory3 = new ProxyFactory();
            factory3.setTarget(target);
            factory3.addAdvice(new LoggingInterceptor());
            factory3.addAdvice(new PerformanceInterceptor());
            factory3.addAdvice(new SecurityInterceptor());
            Object multiAdviceProxy = factory3.getProxy();

            results.put("interface_proxy_created", interfaceProxy != null);
            results.put("interface_proxy_type", interfaceProxy.getClass().getSimpleName());
            results.put("interface_proxy_is_jdk", AopUtils.isJdkDynamicProxy(interfaceProxy));

            results.put("cglib_proxy_created", cglibProxy != null);
            results.put("cglib_proxy_type", cglibProxy.getClass().getSimpleName());
            results.put("cglib_proxy_is_cglib", AopUtils.isCglibProxy(cglibProxy));

            results.put("multi_advice_proxy_created", multiAdviceProxy != null);
            results.put("multi_advice_proxy_type", multiAdviceProxy.getClass().getSimpleName());

            // Test method invocation on different proxies
            String interfaceResult =
                    ((SampleServiceInterface) interfaceProxy).processData("interface");
            String cglibResult = ((SampleService) cglibProxy).processData("cglib");
            String multiResult = ((SampleServiceInterface) multiAdviceProxy).processData("multi");

            results.put("interface_proxy_result", interfaceResult);
            results.put("cglib_proxy_result", cglibResult);
            results.put("multi_advice_proxy_result", multiResult);

            // ProxyFactory configuration options
            results.put(
                    "proxy_factory_features",
                    Arrays.asList(
                            "Interface-based JDK proxies",
                            "Class-based CGLIB proxies",
                            "Multiple advice/interceptor support",
                            "Method-level interception",
                            "Around, before, after advice",
                            "Pointcut-based advice application"));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateClassPathScanningCandidateComponentProvider() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create scanner with default filters (finds @Component and its derivatives)
            ClassPathScanningCandidateComponentProvider scanner =
                    new ClassPathScanningCandidateComponentProvider(true);

            // Scan for components in this package
            String basePackage = "com.example.springutilsoverview";
            Set<BeanDefinition> components = scanner.findCandidateComponents(basePackage);

            results.put("base_package", basePackage);
            results.put("components_found", components.size());

            // Categorize found components
            Map<String, List<String>> componentsByType = new HashMap<>();
            componentsByType.put("Component", new ArrayList<>());
            componentsByType.put("Service", new ArrayList<>());
            componentsByType.put("Repository", new ArrayList<>());
            componentsByType.put("Controller", new ArrayList<>());
            componentsByType.put("Other", new ArrayList<>());

            for (BeanDefinition bd : components) {
                String className = bd.getBeanClassName();
                if (className != null) {
                    try {
                        Class<?> clazz = Class.forName(className);
                        if (clazz.isAnnotationPresent(Component.class)
                                && !clazz.isAnnotationPresent(Service.class)
                                && !clazz.isAnnotationPresent(Repository.class)
                                && !clazz.isAnnotationPresent(Controller.class)) {
                            componentsByType.get("Component").add(clazz.getSimpleName());
                        } else if (clazz.isAnnotationPresent(Service.class)) {
                            componentsByType.get("Service").add(clazz.getSimpleName());
                        } else if (clazz.isAnnotationPresent(Repository.class)) {
                            componentsByType.get("Repository").add(clazz.getSimpleName());
                        } else if (clazz.isAnnotationPresent(Controller.class)) {
                            componentsByType.get("Controller").add(clazz.getSimpleName());
                        } else {
                            componentsByType.get("Other").add(clazz.getSimpleName());
                        }
                    } catch (ClassNotFoundException e) {
                        componentsByType.get("Other").add("Unknown class: " + className);
                    }
                }
            }

            results.put("components_by_type", componentsByType);

            // Custom scanner with specific annotation filter
            ClassPathScanningCandidateComponentProvider customScanner =
                    new ClassPathScanningCandidateComponentProvider(false);
            customScanner.addIncludeFilter(new AnnotationTypeFilter(Component.class));

            Set<BeanDefinition> customComponents =
                    customScanner.findCandidateComponents(basePackage);
            results.put("custom_scanner_components", customComponents.size());

            // Scanner for specific annotation only
            ClassPathScanningCandidateComponentProvider serviceScanner =
                    new ClassPathScanningCandidateComponentProvider(false);
            serviceScanner.addIncludeFilter(new AnnotationTypeFilter(Service.class));

            Set<BeanDefinition> services = serviceScanner.findCandidateComponents(basePackage);
            results.put("service_components_found", services.size());

            // Use cases
            results.put(
                    "use_cases",
                    Arrays.asList(
                            "Dynamic component discovery",
                            "Plugin architecture implementation",
                            "Custom annotation processing",
                            "Bean definition generation",
                            "Classpath scanning for modules",
                            "Custom component registration"));

            // Scanner capabilities
            results.put(
                    "scanner_capabilities",
                    Arrays.asList(
                            "Annotation-based filtering",
                            "Regex pattern matching",
                            "Custom type filters",
                            "Include/exclude filter combinations",
                            "Resource pattern matching",
                            "Bean metadata extraction"));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("AopUtils", demonstrateAopUtils());
        allResults.put("ProxyFactory", demonstrateProxyFactory());
        allResults.put(
                "ClassPathScanningCandidateComponentProvider",
                demonstrateClassPathScanningCandidateComponentProvider());

        return allResults;
    }

    // Sample classes and interfaces for AOP demonstrations
    public interface SampleServiceInterface {
        String processData(String data);
    }

    public static class SampleService implements SampleServiceInterface {
        @Override
        public String processData(String data) {
            return "Processed: " + data;
        }

        public String additionalMethod(String input) {
            return "Additional: " + input;
        }
    }

    // Sample interceptors for AOP demonstrations
    public static class LoggingInterceptor implements MethodInterceptor {
        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            String methodName = invocation.getMethod().getName();
            Object[] args = invocation.getArguments();

            // Before advice
            System.out.println(
                    "LOG: Calling method " + methodName + " with args: " + Arrays.toString(args));

            try {
                Object result = invocation.proceed();
                // After returning advice
                System.out.println("LOG: Method " + methodName + " returned: " + result);
                return result;
            } catch (Exception e) {
                // After throwing advice
                System.out.println(
                        "LOG: Method " + methodName + " threw exception: " + e.getMessage());
                throw e;
            }
        }
    }

    public static class PerformanceInterceptor implements MethodInterceptor {
        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            long startTime = System.currentTimeMillis();
            try {
                Object result = invocation.proceed();
                long endTime = System.currentTimeMillis();
                System.out.println(
                        "PERF: Method "
                                + invocation.getMethod().getName()
                                + " took "
                                + (endTime - startTime)
                                + "ms");
                return result;
            } catch (Exception e) {
                long endTime = System.currentTimeMillis();
                System.out.println(
                        "PERF: Method "
                                + invocation.getMethod().getName()
                                + " failed after "
                                + (endTime - startTime)
                                + "ms");
                throw e;
            }
        }
    }

    public static class SecurityInterceptor implements MethodInterceptor {
        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            // Simulate security check
            String methodName = invocation.getMethod().getName();
            System.out.println("SECURITY: Checking permissions for method: " + methodName);

            // Proceed with method execution
            return invocation.proceed();
        }
    }
}
