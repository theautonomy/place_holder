package com.example.springutilsoverview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringUtilsOverviewApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringUtilsOverviewApplication.class, args);
        System.out.println(
                "\n"
                        + "=================================================\n"
                        + "🚀 Spring Utils Overview Application Started! \n"
                        + "=================================================\n"
                        + "📖 Demonstrating 49 Essential Spring Utility Classes\n"
                        + "🌐 Access the demos at: http://localhost:8080\n"
                        + "📚 API Endpoints:\n"
                        + "   • GET /api/demos - List all available demos\n"
                        + "   • GET /api/demos/string - String processing tools\n"
                        + "   • GET /api/demos/collection - Collection and array tools\n"
                        + "   • GET /api/demos/reflection - Reflection tools\n"
                        + "   • GET /api/demos/web - Web-related tools\n"
                        + "   • GET /api/demos/security - Security tools\n"
                        + "   • GET /api/demos/utility - Utility tools\n"
                        + "   • GET /api/demos/all - All demonstrations\n"
                        + "=================================================\n");
    }
}
