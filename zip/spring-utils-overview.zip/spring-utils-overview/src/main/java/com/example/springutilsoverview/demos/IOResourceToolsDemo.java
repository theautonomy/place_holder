package com.example.springutilsoverview.demos;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.FileSystemUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StreamUtils;

@Component
public class IOResourceToolsDemo {

    public Map<String, Object> demonstrateFileCopyUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create temporary files for demonstration
            Path tempDir = Files.createTempDirectory("spring-demo");
            Path inputFile = tempDir.resolve("input.txt");
            Path outputFile = tempDir.resolve("output.txt");

            // Create test content
            String testContent =
                    "Hello, Spring FileCopyUtils!\nThis is a test file.\nLine 3 content.";
            Files.write(inputFile, testContent.getBytes(StandardCharsets.UTF_8));

            // Copy file content into a byte array
            byte[] bytes = FileCopyUtils.copyToByteArray(inputFile.toFile());

            // Copy bytes to another file
            FileCopyUtils.copy(bytes, outputFile.toFile());

            // Copy content from a Reader to a String
            String content = FileCopyUtils.copyToString(new FileReader(inputFile.toFile()));

            // Copy between streams
            try (FileInputStream fis = new FileInputStream(inputFile.toFile());
                    ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

                FileCopyUtils.copy(fis, baos);
                String streamContent = baos.toString(StandardCharsets.UTF_8);

                results.put("original_content", testContent);
                results.put("bytes_length", bytes.length);
                results.put("copied_content", content);
                results.put("stream_content", streamContent);
                results.put("files_match", content.equals(streamContent));
            }

            // Cleanup
            FileSystemUtils.deleteRecursively(tempDir);

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateResourceUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Check if strings are URLs
            boolean isUrl1 = ResourceUtils.isUrl("http://example.com");
            boolean isUrl2 = ResourceUtils.isUrl("classpath:application.yml");
            boolean isUrl3 = ResourceUtils.isUrl("file:/tmp/test.txt");
            boolean isUrl4 = ResourceUtils.isUrl("just-a-string");

            // Get URLs from location strings
            URL classpathUrl = ResourceUtils.getURL("classpath:application.yml");

            results.put("isUrl_http", isUrl1);
            results.put("isUrl_classpath", isUrl2);
            results.put("isUrl_file", isUrl3);
            results.put("isUrl_string", isUrl4);
            results.put("classpath_url", classpathUrl.toString());
            results.put("url_protocol", classpathUrl.getProtocol());

            // Try to get a file from classpath (if it exists)
            try {
                File configFile = ResourceUtils.getFile("classpath:application.yml");
                results.put("config_file_found", true);
                results.put("config_file_path", configFile.getAbsolutePath());
                results.put("config_file_exists", configFile.exists());
            } catch (Exception e) {
                results.put("config_file_found", false);
                results.put("config_file_error", "File not accessible as File (likely in JAR)");
            }

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateStreamUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            String testString =
                    "Hello, StreamUtils demonstration!\nMultiple lines\nWith various content.";

            // Create input stream from string
            try (InputStream inputStream =
                            new ByteArrayInputStream(testString.getBytes(StandardCharsets.UTF_8));
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

                // Copy stream to byte array
                byte[] data = StreamUtils.copyToByteArray(inputStream);

                // Reset input stream
                inputStream.reset();

                // Copy stream to string
                String text = StreamUtils.copyToString(inputStream, StandardCharsets.UTF_8);

                // Copy string to output stream
                StreamUtils.copy(
                        "Additional content via StreamUtils", StandardCharsets.UTF_8, outputStream);
                String outputContent = outputStream.toString(StandardCharsets.UTF_8);

                results.put("original_string", testString);
                results.put("data_length", data.length);
                results.put("copied_text", text);
                results.put("output_content", outputContent);
                results.put("strings_match", testString.equals(text));
            }

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateFileSystemUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create temporary directory structure for demonstration
            Path tempDir = Files.createTempDirectory("spring-filesystem-demo");
            Path subDir1 = tempDir.resolve("subdir1");
            Path subDir2 = tempDir.resolve("subdir2");

            Files.createDirectories(subDir1);
            Files.createDirectories(subDir2);

            // Create some test files
            Path file1 = subDir1.resolve("file1.txt");
            Path file2 = subDir2.resolve("file2.txt");

            Files.write(file1, "Content of file 1".getBytes());
            Files.write(file2, "Content of file 2".getBytes());

            results.put("temp_dir_created", tempDir.toString());
            results.put("files_created", Arrays.asList(file1.toString(), file2.toString()));

            // Copy directory recursively
            Path copyDir = Files.createTempDirectory("spring-filesystem-copy");
            FileSystemUtils.copyRecursively(tempDir, copyDir);

            results.put("copy_successful", Files.exists(copyDir.resolve("subdir1/file1.txt")));
            results.put("copy_dir", copyDir.toString());

            // Delete directories recursively
            boolean deleted1 = FileSystemUtils.deleteRecursively(tempDir);
            boolean deleted2 = FileSystemUtils.deleteRecursively(copyDir);

            results.put("original_deleted", deleted1);
            results.put("copy_deleted", deleted2);
            results.put("cleanup_successful", deleted1 && deleted2);

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateResourcePatternUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

            // Find all property files in classpath
            Resource[] propertyResources = resolver.getResources("classpath*:**/*.properties");
            Resource[] yamlResources = resolver.getResources("classpath*:**/*.yml");

            // Find all XML files in META-INF
            Resource[] metaInfXmlResources = resolver.getResources("classpath*:META-INF/*.xml");

            results.put("property_files_found", propertyResources.length);
            results.put("yaml_files_found", yamlResources.length);
            results.put("meta_inf_xml_files", metaInfXmlResources.length);

            // Get details of found resources
            if (propertyResources.length > 0) {
                results.put("first_property_file", propertyResources[0].getDescription());
            }

            if (yamlResources.length > 0) {
                results.put("first_yaml_file", yamlResources[0].getDescription());
                results.put("yaml_file_exists", yamlResources[0].exists());
            }

            // Try to find application configuration files
            Resource[] appConfigs = resolver.getResources("classpath*:application.*");
            results.put("app_config_files", appConfigs.length);

            for (int i = 0; i < Math.min(appConfigs.length, 3); i++) {
                results.put("app_config_" + i, appConfigs[i].getDescription());
            }

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("FileCopyUtils", demonstrateFileCopyUtils());
        allResults.put("ResourceUtils", demonstrateResourceUtils());
        allResults.put("StreamUtils", demonstrateStreamUtils());
        allResults.put("FileSystemUtils", demonstrateFileSystemUtils());
        allResults.put("ResourcePatternUtils", demonstrateResourcePatternUtils());

        return allResults;
    }
}
