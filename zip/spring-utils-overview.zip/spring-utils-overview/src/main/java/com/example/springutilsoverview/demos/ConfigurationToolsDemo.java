package com.example.springutilsoverview.demos;

import java.util.*;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
public class ConfigurationToolsDemo {

    public Map<String, Object> demonstrateYamlPropertiesFactoryBean() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create YAML factory bean
            YamlPropertiesFactoryBean yamlFactory = new YamlPropertiesFactoryBean();
            yamlFactory.setResources(new ClassPathResource("application.yml"));

            // Get properties from YAML
            Properties properties = yamlFactory.getObject();

            if (properties != null) {
                results.put("yaml_loaded_successfully", true);
                results.put("total_properties", properties.size());

                // Convert to map for better display
                Map<String, String> propertyMap = new HashMap<>();
                for (String key : properties.stringPropertyNames()) {
                    propertyMap.put(key, properties.getProperty(key));
                }

                results.put("loaded_properties", propertyMap);

                // Extract specific properties
                results.put("app_name", properties.getProperty("spring.application.name"));
                results.put("server_port", properties.getProperty("server.port"));
                results.put("logging_level", properties.getProperty("logging.level.com.example"));

            } else {
                results.put("yaml_loaded_successfully", false);
                results.put("error", "Could not load YAML properties");
            }

            // Demonstrate creating YAML factory with multiple resources
            YamlPropertiesFactoryBean multiResourceFactory = new YamlPropertiesFactoryBean();

            // Note: These resources might not exist, but shows the pattern
            multiResourceFactory.setResources(
                    new ClassPathResource("application.yml"),
                    new ClassPathResource("application-dev.yml"),
                    new ClassPathResource("application-prod.yml"));

            results.put("multi_resource_factory_created", true);
            results.put(
                    "use_cases",
                    Arrays.asList(
                            "Loading YAML configuration files",
                            "Converting YAML to Properties objects",
                            "Multi-profile configuration loading",
                            "Environment-specific settings",
                            "Configuration file merging",
                            "Spring Boot external configuration"));

            results.put(
                    "benefits_over_properties",
                    Arrays.asList(
                            "Hierarchical structure support",
                            "Better readability for complex configs",
                            "List and map support",
                            "Multi-document support",
                            "Type-safe value representation",
                            "Comments and documentation support"));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateRandomStringUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Note: This is from Apache Commons Lang3, commonly used with Spring
            results.put("note", "Apache Commons Lang3 utility - commonly used in Spring projects");

            // Generate different types of random strings
            String randomAlphabetic = RandomStringUtils.randomAlphabetic(10);
            String randomAlphanumeric = RandomStringUtils.randomAlphanumeric(12);
            String randomNumeric = RandomStringUtils.randomNumeric(6);
            String randomAscii = RandomStringUtils.randomAscii(8);

            results.put("random_alphabetic_10", randomAlphabetic);
            results.put("random_alphanumeric_12", randomAlphanumeric);
            results.put("random_numeric_6", randomNumeric);
            results.put("random_ascii_8", randomAscii);

            // Generate with specific character sets
            String customRandom1 =
                    RandomStringUtils.random(8, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
            String customRandom2 = RandomStringUtils.random(10, true, true); // letters and numbers
            String customRandom3 = RandomStringUtils.random(6, false, true); // numbers only

            results.put("custom_uppercase_alphanumeric", customRandom1);
            results.put("custom_letters_and_numbers", customRandom2);
            results.put("custom_numbers_only", customRandom3);

            // Generate multiple random strings for testing uniqueness
            Set<String> uniqueIds = new HashSet<>();
            for (int i = 0; i < 100; i++) {
                uniqueIds.add(RandomStringUtils.randomAlphanumeric(8));
            }

            results.put("uniqueness_test_generated", 100);
            results.put("uniqueness_test_unique", uniqueIds.size());
            results.put(
                    "uniqueness_rate",
                    String.format("%.1f%%", (double) uniqueIds.size() / 100 * 100));

            // Common use cases in Spring applications
            results.put(
                    "spring_use_cases",
                    Arrays.asList(
                            "Session ID generation",
                            "API key generation",
                            "Temporary password creation",
                            "File name generation",
                            "Cache key generation",
                            "Transaction ID creation",
                            "Test data generation"));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAdditionalUtilities() {
        Map<String, Object> results = new HashMap<>();

        // These are utilities mentioned in the original article that we haven't fully implemented
        Map<String, String> additionalUtilities = new HashMap<>();

        // Configuration and Environment utilities
        additionalUtilities.put("Environment", "Access to application environment and profiles");
        additionalUtilities.put("PropertySource", "Abstraction for property sources");
        additionalUtilities.put(
                "ConfigurationProperties", "Type-safe configuration properties binding");
        additionalUtilities.put(
                "ConditionalOnProperty", "Conditional bean creation based on properties");

        // Additional Web utilities
        additionalUtilities.put("ResponseEntity", "HTTP response wrapper with status and headers");
        additionalUtilities.put(
                "RequestEntity", "HTTP request wrapper with method, URL, headers and body");
        additionalUtilities.put("HttpEntity", "Base class for HTTP request and response entities");

        // Additional Security utilities
        additionalUtilities.put("PasswordEncoder", "Password encoding and verification");
        additionalUtilities.put("BCryptPasswordEncoder", "BCrypt password encoder implementation");
        additionalUtilities.put("SecurityContextHolder", "Access to security context");

        // Additional Data utilities
        additionalUtilities.put("JdbcTemplate", "JDBC operations template");
        additionalUtilities.put("RedisTemplate", "Redis operations template");
        additionalUtilities.put("RestTemplate", "REST client template (legacy)");

        // Additional Testing utilities
        additionalUtilities.put("TestRestTemplate", "REST client for testing");
        additionalUtilities.put("MockMvc", "Spring MVC testing framework");
        additionalUtilities.put("TestPropertySource", "Test-specific property sources");

        results.put("additional_utilities", additionalUtilities);

        // Summary of all categories
        Map<String, Integer> categorySummary = new HashMap<>();
        categorySummary.put("String Processing", 4);
        categorySummary.put("Collection and Array", 4);
        categorySummary.put("Reflection and Class", 4);
        categorySummary.put("I/O and Resources", 5);
        categorySummary.put("Web-Related", 8);
        categorySummary.put("Security-Related", 3);
        categorySummary.put("Verification and Assertion", 3);
        categorySummary.put("Date and Time", 2);
        categorySummary.put("JSON and Data Conversion", 4);
        categorySummary.put("Spring Context", 4);
        categorySummary.put("AOP Tools", 3);
        categorySummary.put("Configuration", 2);
        categorySummary.put("Additional Commons", 8);

        results.put("category_summary", categorySummary);
        results.put(
                "total_utilities_covered",
                categorySummary.values().stream().mapToInt(Integer::intValue).sum());

        // Best practices summary
        results.put(
                "best_practices",
                Arrays.asList(
                        "Prefer Spring utilities over external libraries when available",
                        "Consider version compatibility when using Spring internals",
                        "Use utilities judiciously to avoid tight coupling",
                        "Leverage type-safe utilities for better code quality",
                        "Consider performance implications of utility usage",
                        "Keep up with Spring Framework updates and deprecations"));

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("YamlPropertiesFactoryBean", demonstrateYamlPropertiesFactoryBean());
        allResults.put("RandomStringUtils", demonstrateRandomStringUtils());
        allResults.put("AdditionalUtilities", demonstrateAdditionalUtilities());

        return allResults;
    }
}
