package com.example.springutilsoverview.demos;

import java.util.*;

import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.ContentCachingRequestWrapper;

import jakarta.servlet.http.HttpServletRequest;

@Component
public class AdvancedWebToolsDemo {

    public Map<String, Object> demonstrateWebClientBuilder() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create WebClient with various configurations
            WebClient webClient1 =
                    WebClient.builder()
                            .baseUrl("https://api.github.com")
                            .defaultHeader("User-Agent", "Spring-Utils-Demo/1.0")
                            .defaultHeader("Accept", "application/json")
                            .build();

            WebClient webClient2 =
                    WebClient.builder()
                            .baseUrl("https://jsonplaceholder.typicode.com")
                            .defaultHeader("Content-Type", "application/json")
                            .codecs(
                                    configurer ->
                                            configurer.defaultCodecs().maxInMemorySize(1024 * 1024))
                            .build();

            WebClient webClient3 =
                    WebClient.builder()
                            .baseUrl("https://httpbin.org")
                            .defaultHeaders(
                                    headers -> {
                                        headers.add("X-Custom-Header", "Demo-Value");
                                        headers.add("X-Request-ID", UUID.randomUUID().toString());
                                    })
                            .build();

            // WebClient with timeout configuration
            WebClient webClient4 =
                    WebClient.builder()
                            .baseUrl("https://api.example.com")
                            .codecs(
                                    configurer -> {
                                        configurer.defaultCodecs().maxInMemorySize(512 * 1024);
                                    })
                            .build();

            results.put("webclient_1_base_url", "https://api.github.com");
            results.put("webclient_1_description", "GitHub API client with custom headers");

            results.put("webclient_2_base_url", "https://jsonplaceholder.typicode.com");
            results.put("webclient_2_description", "JSON placeholder with memory limit");

            results.put("webclient_3_base_url", "https://httpbin.org");
            results.put("webclient_3_description", "HTTP testing service with custom headers");

            results.put("webclient_4_base_url", "https://api.example.com");
            results.put("webclient_4_description", "Example API with memory configuration");

            // Demonstrate builder pattern benefits
            results.put(
                    "builder_benefits",
                    Arrays.asList(
                            "Immutable WebClient instances",
                            "Reusable configuration",
                            "Fluent API for setup",
                            "Support for custom codecs",
                            "Built-in timeout support",
                            "Header and filter customization"));

            // Configuration examples
            Map<String, Object> configurations = new HashMap<>();
            configurations.put("base_url", "Set common base URL for all requests");
            configurations.put("default_headers", "Add headers to all requests");
            configurations.put("codecs", "Configure request/response processing");
            configurations.put("filters", "Add request/response filters");
            configurations.put("error_handling", "Custom error handling strategies");

            results.put("configuration_options", configurations);

            // Example usage patterns
            results.put(
                    "usage_example_get",
                    "webClient.get().uri(\"/users/{id}\", 123).retrieve().bodyToMono(User.class)");
            results.put(
                    "usage_example_post",
                    "webClient.post().uri(\"/users\").bodyValue(user).retrieve().bodyToMono(User.class)");
            results.put(
                    "usage_example_exchange",
                    "webClient.get().uri(\"/api/data\").exchange().flatMap(response -> {...})");

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateContentCachingRequestWrapper() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Get current request if available (this will work when called from a web request)
            ServletRequestAttributes requestAttributes =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();

            if (requestAttributes != null) {
                HttpServletRequest request = requestAttributes.getRequest();

                // Create ContentCachingRequestWrapper
                ContentCachingRequestWrapper wrapper = new ContentCachingRequestWrapper(request);

                results.put("wrapper_created", true);
                results.put("original_method", request.getMethod());
                results.put("original_uri", request.getRequestURI());
                results.put("content_type", request.getContentType());

                // Get cached content (this would be populated after request processing)
                byte[] cachedContent = wrapper.getContentAsByteArray();
                results.put("cached_content_length", cachedContent.length);

                // Character encoding
                String characterEncoding = wrapper.getCharacterEncoding();
                results.put(
                        "character_encoding",
                        characterEncoding != null ? characterEncoding : "default");

                // Request parameters
                Map<String, String[]> parameterMap = wrapper.getParameterMap();
                results.put("parameter_count", parameterMap.size());

                // Headers information
                Enumeration<String> headerNames = wrapper.getHeaderNames();
                List<String> headers = new ArrayList<>();
                while (headerNames.hasMoreElements()) {
                    headers.add(headerNames.nextElement());
                }
                results.put("header_names", headers);

                results.put(
                        "use_cases",
                        Arrays.asList(
                                "Logging request bodies for debugging",
                                "Audit trails for API calls",
                                "Request transformation in filters",
                                "Content validation and sanitization",
                                "Rate limiting based on content",
                                "Request replay for testing"));

            } else {
                results.put("wrapper_created", false);
                results.put(
                        "note", "ContentCachingRequestWrapper demo requires web request context");
                results.put("typical_usage", "Used in servlet filters to cache request body");
                results.put(
                        "benefits",
                        Arrays.asList(
                                "Allows multiple reads of request body",
                                "Preserves original request stream",
                                "Useful for logging and auditing",
                                "Enables request transformation",
                                "Thread-safe implementation"));
            }

            // Demonstrate filter usage pattern
            results.put(
                    "filter_example",
                    "public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) {\n"
                            + "    ContentCachingRequestWrapper wrapper = new ContentCachingRequestWrapper((HttpServletRequest) request);\n"
                            + "    chain.doFilter(wrapper, response);\n"
                            + "    byte[] content = wrapper.getContentAsByteArray();\n"
                            + "    // Process cached content...\n"
                            + "}");

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateWebUtilsConcepts() {
        Map<String, Object> results = new HashMap<>();

        // Note: WebUtils requires servlet context, so we'll demonstrate concepts
        results.put("note", "WebUtils requires servlet request context - showing concepts");

        // Common WebUtils methods and their purposes
        Map<String, String> methods = new HashMap<>();
        methods.put("getCookie(request, name)", "Get specific cookie from request");
        methods.put(
                "getIntParameter(request, name, defaultValue)",
                "Get integer parameter with default");
        methods.put(
                "getStringParameter(request, name, defaultValue)",
                "Get string parameter with default");
        methods.put("getParametersStartingWith(request, prefix)", "Get all parameters with prefix");
        methods.put("hasSubmitParameter(request, name)", "Check if submit parameter exists");
        methods.put("getSessionAttribute(request, name)", "Get session attribute safely");
        methods.put("setSessionAttribute(request, name, value)", "Set session attribute safely");

        results.put("common_methods", methods);

        // Use cases for WebUtils
        results.put(
                "use_cases",
                Arrays.asList(
                        "Safe parameter extraction with defaults",
                        "Cookie management in controllers",
                        "Session attribute handling",
                        "Form parameter processing",
                        "Request validation and sanitization",
                        "Cross-request data sharing"));

        // Example usage patterns
        results.put(
                "example_cookie_usage",
                "Cookie sessionCookie = WebUtils.getCookie(request, \"JSESSIONID\");");
        results.put(
                "example_parameter_usage",
                "int pageSize = WebUtils.getIntParameter(request, \"pageSize\", 10);");
        results.put(
                "example_session_usage",
                "WebUtils.setSessionAttribute(request, \"user\", currentUser);");

        // Benefits over direct servlet API
        results.put(
                "benefits_over_servlet_api",
                Arrays.asList(
                        "Null-safe operations",
                        "Built-in default value support",
                        "Type conversion utilities",
                        "Simplified session management",
                        "Exception handling",
                        "Consistent API patterns"));

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("WebClientBuilder", demonstrateWebClientBuilder());
        allResults.put("ContentCachingRequestWrapper", demonstrateContentCachingRequestWrapper());
        allResults.put("WebUtilsConcepts", demonstrateWebUtilsConcepts());

        return allResults;
    }
}
