package com.example.springutilsoverview.demos;

import java.lang.reflect.Field;
import java.util.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import org.springframework.core.ResolvableType;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;

@Component
public class DataConversionToolsDemo {

    public Map<String, Object> demonstrateResolvableType() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create ResolvableType for various generic scenarios

            // Simple generic type: List<String>
            ResolvableType listType = ResolvableType.forClassWithGenerics(List.class, String.class);

            // Nested generic type: Map<String, List<Integer>>
            ResolvableType listOfIntegerType =
                    ResolvableType.forClassWithGenerics(List.class, Integer.class);
            ResolvableType mapType =
                    ResolvableType.forClassWithGenerics(
                            Map.class, ResolvableType.forClass(String.class), listOfIntegerType);

            // Array type: String[]
            ResolvableType arrayType =
                    ResolvableType.forArrayComponent(ResolvableType.forClass(String.class));

            results.put("list_type", listType.toString());
            results.put("list_raw_class", listType.getRawClass().getSimpleName());
            results.put("list_generic_0", listType.getGeneric(0).toString());

            results.put("map_type", mapType.toString());
            results.put("map_raw_class", mapType.getRawClass().getSimpleName());
            results.put("map_key_type", mapType.getGeneric(0).toString());
            results.put("map_value_type", mapType.getGeneric(1).toString());

            results.put("array_type", arrayType.toString());
            results.put("array_component_type", arrayType.getComponentType().toString());

            // Demonstrate field-based ResolvableType
            Field testField = TestClass.class.getDeclaredField("complexMap");
            ResolvableType fieldType = ResolvableType.forField(testField);

            results.put("field_type", fieldType.toString());
            results.put("field_generic_count", fieldType.getGenerics().length);

            // Check type relationships
            results.put(
                    "list_is_collection",
                    ResolvableType.forClass(Collection.class).isAssignableFrom(listType));
            results.put(
                    "map_is_collection",
                    ResolvableType.forClass(Collection.class).isAssignableFrom(mapType));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateMappingJackson2HttpMessageConverter() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create and customize ObjectMapper
            ObjectMapper customMapper = new ObjectMapper();
            customMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
            customMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

            // Create converter with custom mapper
            MappingJackson2HttpMessageConverter converter =
                    new MappingJackson2HttpMessageConverter(customMapper);

            // Get supported media types
            List<MediaType> supportedTypes = converter.getSupportedMediaTypes();

            results.put("converter_class", converter.getClass().getSimpleName());
            results.put("supported_media_types", supportedTypes.toString());
            results.put("supports_json", supportedTypes.contains(MediaType.APPLICATION_JSON));

            // Test object for conversion
            TestObject testObj =
                    new TestObject("John Doe", 30, Arrays.asList("reading", "coding", "music"));

            // Check if converter can write the object
            boolean canWrite = converter.canWrite(TestObject.class, MediaType.APPLICATION_JSON);
            results.put("can_write_test_object", canWrite);

            // Get the ObjectMapper being used
            ObjectMapper usedMapper = converter.getObjectMapper();
            results.put(
                    "indent_output_enabled",
                    usedMapper.isEnabled(SerializationFeature.INDENT_OUTPUT));
            results.put(
                    "dates_as_timestamps",
                    usedMapper.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS));

            // Demonstrate JSON serialization capability
            try {
                String json = usedMapper.writeValueAsString(testObj);
                results.put("sample_json_output", json);

                TestObject deserialized = usedMapper.readValue(json, TestObject.class);
                results.put(
                        "deserialization_successful",
                        testObj.getName().equals(deserialized.getName()));
            } catch (Exception e) {
                results.put("serialization_error", e.getMessage());
            }

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateMediaTypeFactory() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Test various file extensions
            String[] testFiles = {
                "document.pdf",
                "image.jpg",
                "image.png",
                "data.json",
                "style.css",
                "script.js",
                "archive.zip",
                "video.mp4",
                "audio.mp3",
                "text.txt",
                "unknown.xyz"
            };

            Map<String, String> mediaTypes = new HashMap<>();

            for (String filename : testFiles) {
                Optional<MediaType> mediaType = MediaTypeFactory.getMediaType(filename);
                if (mediaType.isPresent()) {
                    mediaTypes.put(filename, mediaType.get().toString());
                } else {
                    mediaTypes.put(filename, "unknown/unknown");
                }
            }

            results.put("file_media_types", mediaTypes);

            // Test with resources
            Optional<MediaType> pdfType = MediaTypeFactory.getMediaType("application.pdf");
            Optional<MediaType> jsonType = MediaTypeFactory.getMediaType("config.json");
            Optional<MediaType> ymlType = MediaTypeFactory.getMediaType("application.yml");

            results.put(
                    "pdf_detected",
                    pdfType.isPresent() ? pdfType.get().toString() : "not detected");
            results.put(
                    "json_detected",
                    jsonType.isPresent() ? jsonType.get().toString() : "not detected");
            results.put(
                    "yml_detected",
                    ymlType.isPresent() ? ymlType.get().toString() : "not detected");

            // Count detected vs unknown
            long detectedCount =
                    mediaTypes.values().stream()
                            .filter(type -> !type.equals("unknown/unknown"))
                            .count();

            results.put("total_tested", testFiles.length);
            results.put("detected_count", detectedCount);
            results.put(
                    "detection_rate",
                    String.format("%.1f%%", (double) detectedCount / testFiles.length * 100));

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateMimeTypeUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Common MIME type constants
            MimeType jsonType = MimeTypeUtils.APPLICATION_JSON;
            MimeType xmlType = MimeTypeUtils.APPLICATION_XML;
            MimeType textType = MimeTypeUtils.TEXT_PLAIN;
            MimeType htmlType = MimeTypeUtils.TEXT_HTML;
            MimeType formType = MimeType.valueOf("application/x-www-form-urlencoded");
            MimeType allType = MimeTypeUtils.ALL;

            results.put("json_mime_type", jsonType.toString());
            results.put("xml_mime_type", xmlType.toString());
            results.put("text_mime_type", textType.toString());
            results.put("html_mime_type", htmlType.toString());
            results.put("form_mime_type", formType.toString());
            results.put("all_mime_type", allType.toString());

            // Create custom MIME types
            MimeType customType1 = MimeType.valueOf("application/custom");
            MimeType customType2 = new MimeType("text", "custom");

            results.put("custom_type_1", customType1.toString());
            results.put("custom_type_2", customType2.toString());

            // Test MIME type compatibility
            MimeType applicationWildcard = MimeType.valueOf("application/*");
            MimeType textWildcard = MimeType.valueOf("text/*");

            boolean jsonCompatibleWithApp = jsonType.isCompatibleWith(applicationWildcard);
            boolean textCompatibleWithApp = textType.isCompatibleWith(applicationWildcard);
            boolean htmlCompatibleWithText = htmlType.isCompatibleWith(textWildcard);
            boolean allCompatible = allType.isCompatibleWith(jsonType);

            results.put("json_compatible_with_application_wildcard", jsonCompatibleWithApp);
            results.put("text_compatible_with_application_wildcard", textCompatibleWithApp);
            results.put("html_compatible_with_text_wildcard", htmlCompatibleWithText);
            results.put("all_compatible_with_json", allCompatible);

            // Parse MIME types from strings
            List<String> mimeTypeStrings =
                    Arrays.asList("text/plain", "application/json;charset=UTF-8", "image/*", "*/*");

            Map<String, Map<String, Object>> parsedTypes = new HashMap<>();
            for (String typeString : mimeTypeStrings) {
                MimeType parsed = MimeType.valueOf(typeString);
                Map<String, Object> typeInfo = new HashMap<>();
                typeInfo.put("type", parsed.getType());
                typeInfo.put("subtype", parsed.getSubtype());
                typeInfo.put("parameters", parsed.getParameters());
                typeInfo.put("charset", parsed.getParameter("charset"));
                parsedTypes.put(typeString, typeInfo);
            }

            results.put("parsed_mime_types", parsedTypes);

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("ResolvableType", demonstrateResolvableType());
        allResults.put(
                "MappingJackson2HttpMessageConverter",
                demonstrateMappingJackson2HttpMessageConverter());
        allResults.put("MediaTypeFactory", demonstrateMediaTypeFactory());
        allResults.put("MimeTypeUtils", demonstrateMimeTypeUtils());

        return allResults;
    }

    // Test classes for demonstrations
    public static class TestClass {
        private Map<String, List<Integer>> complexMap;
        private List<String> stringList;
        private String[] stringArray;
    }

    public static class TestObject {
        private String name;
        private int age;
        private List<String> hobbies;
        private Date createdAt;

        public TestObject() {
            this.createdAt = new Date();
        }

        public TestObject(String name, int age, List<String> hobbies) {
            this.name = name;
            this.age = age;
            this.hobbies = hobbies;
            this.createdAt = new Date();
        }

        // Getters and setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public List<String> getHobbies() {
            return hobbies;
        }

        public void setHobbies(List<String> hobbies) {
            this.hobbies = hobbies;
        }

        public Date getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(Date createdAt) {
            this.createdAt = createdAt;
        }
    }
}
