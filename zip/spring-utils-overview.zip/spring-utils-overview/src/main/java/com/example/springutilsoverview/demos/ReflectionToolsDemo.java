package com.example.springutilsoverview.demos;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;
import org.springframework.util.MethodInvoker;
import org.springframework.util.ReflectionUtils;

@Component
public class ReflectionToolsDemo {

    public Map<String, Object> demonstrateReflectionUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create a sample object to work with
            SampleBean sample = new SampleBean("Initial Name", 25);

            // Find and modify a field
            Field nameField = ReflectionUtils.findField(SampleBean.class, "name");
            if (nameField != null) {
                ReflectionUtils.makeAccessible(nameField);
                String originalName = (String) ReflectionUtils.getField(nameField, sample);
                ReflectionUtils.setField(nameField, sample, "Modified Name");
                String modifiedName = (String) ReflectionUtils.getField(nameField, sample);

                results.put("field_original_name", originalName);
                results.put("field_modified_name", modifiedName);
            }

            // Find and invoke a method
            Method setAgeMethod = ReflectionUtils.findMethod(SampleBean.class, "setAge", int.class);
            if (setAgeMethod != null) {
                int originalAge = sample.getAge();
                ReflectionUtils.invokeMethod(setAgeMethod, sample, 30);
                int modifiedAge = sample.getAge();

                results.put("method_original_age", originalAge);
                results.put("method_modified_age", modifiedAge);
            }

            results.put("sample_object_final_state", sample.toString());

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateClassUtils() {
        Map<String, Object> results = new HashMap<>();

        // Get short class name
        String shortName = ClassUtils.getShortName(SampleBean.class);
        String shortNameFromString = ClassUtils.getShortName("java.lang.String");

        // Check if class is present
        boolean stringExists = ClassUtils.isPresent("java.lang.String", null);
        boolean fakeClassExists = ClassUtils.isPresent("com.fake.NonExistentClass", null);

        // Get default class loader
        ClassLoader classLoader = ClassUtils.getDefaultClassLoader();

        // Get package name
        String packageName = ClassUtils.getPackageName(SampleBean.class);

        results.put("short_name", shortName);
        results.put("short_name_from_string", shortNameFromString);
        results.put("string_exists", stringExists);
        results.put("fake_class_exists", fakeClassExists);
        results.put("class_loader", classLoader.getClass().getSimpleName());
        results.put("package_name", packageName);

        return results;
    }

    public Map<String, Object> demonstrateMethodInvoker() {
        Map<String, Object> results = new HashMap<>();

        try {
            CalculatorService calculator = new CalculatorService();

            // Use MethodInvoker to call a method
            MethodInvoker invoker = new MethodInvoker();
            invoker.setTargetObject(calculator);
            invoker.setTargetMethod("add");
            invoker.setArguments(10, 20);
            invoker.prepare();

            Object result = invoker.invoke();

            results.put("calculation_result", result);
            results.put("method_name", "add");
            results.put("arguments", new int[] {10, 20});

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateBeanUtils() {
        Map<String, Object> results = new HashMap<>();

        try {
            // Create source and target objects
            SampleBean source = new SampleBean("John Doe", 28);
            SampleBeanDTO target = new SampleBeanDTO();

            // Copy properties
            BeanUtils.copyProperties(source, target);

            // Instantiate a class
            SampleBean newInstance = BeanUtils.instantiateClass(SampleBean.class);

            results.put("source_object", source.toString());
            results.put("target_object_after_copy", target.toString());
            results.put("new_instance", newInstance.toString());
            results.put("properties_copied", target.getName() != null && target.getAge() > 0);

        } catch (Exception e) {
            results.put("error", e.getMessage());
        }

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("ReflectionUtils", demonstrateReflectionUtils());
        allResults.put("ClassUtils", demonstrateClassUtils());
        allResults.put("MethodInvoker", demonstrateMethodInvoker());
        allResults.put("BeanUtils", demonstrateBeanUtils());

        return allResults;
    }

    // Sample classes for demonstration
    public static class SampleBean {
        private String name;
        private int age;

        public SampleBean() {}

        public SampleBean(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        @Override
        public String toString() {
            return "SampleBean{name='" + name + "', age=" + age + "}";
        }
    }

    public static class SampleBeanDTO {
        private String name;
        private int age;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        @Override
        public String toString() {
            return "SampleBeanDTO{name='" + name + "', age=" + age + "}";
        }
    }

    public static class CalculatorService {
        public int add(int a, int b) {
            return a + b;
        }

        public int multiply(int a, int b) {
            return a * b;
        }
    }
}
