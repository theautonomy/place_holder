package com.example.springutilsoverview.demos;

import java.util.*;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ConcurrentReferenceHashMap;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.SystemPropertyUtils;

@Component
public class CollectionToolsDemo {

    public Map<String, Object> demonstrateCollectionUtils() {
        Map<String, Object> results = new HashMap<>();

        // Check if collections are empty
        Collection<String> nullCollection = null;
        List<String> emptyList = Collections.emptyList();
        List<String> filledList = Arrays.asList("item");

        boolean isEmpty1 = CollectionUtils.isEmpty(nullCollection);
        boolean isEmpty2 = CollectionUtils.isEmpty(emptyList);
        boolean isEmpty3 = CollectionUtils.isEmpty(filledList);

        // Find common elements between collections
        List<String> list1 = Arrays.asList("a", "b", "c");
        List<String> list2 = Arrays.asList("b", "c", "d");
        Set<String> intersection = new HashSet<>(list1);
        intersection.retainAll(list2);

        // Check if collection contains any element
        boolean containsAny = CollectionUtils.containsAny(list1, list2);

        results.put("isEmpty_null", isEmpty1);
        results.put("isEmpty_empty", isEmpty2);
        results.put("isEmpty_withItems", isEmpty3);
        results.put("list1", list1);
        results.put("list2", list2);
        results.put("intersection", intersection);
        results.put("containsAny", containsAny);

        return results;
    }

    public Map<String, Object> demonstrateMultiValueMap() {
        Map<String, Object> results = new HashMap<>();

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("colors", "red");
        map.add("colors", "blue");
        map.add("colors", "green");
        map.add("sizes", "large");
        map.add("sizes", "medium");

        List<String> colors = map.get("colors");
        List<String> sizes = map.get("sizes");
        String firstColor = map.getFirst("colors");

        results.put("all_colors", colors);
        results.put("all_sizes", sizes);
        results.put("first_color", firstColor);
        results.put("map_structure", map);

        return results;
    }

    public Map<String, Object> demonstrateConcurrentReferenceHashMap() {
        Map<String, Object> results = new HashMap<>();

        // Create a thread-safe cache with soft references
        Map<String, Object> cache = new ConcurrentReferenceHashMap<>();

        // Add some items to the cache
        cache.put("user:123", createUser("John", "john@example.com"));
        cache.put("user:456", createUser("Jane", "jane@example.com"));
        cache.put("config:timeout", 5000);

        results.put("cache_size", cache.size());
        results.put("user_123", cache.get("user:123"));
        results.put("config_timeout", cache.get("config:timeout"));
        results.put("cache_type", cache.getClass().getSimpleName());

        return results;
    }

    public Map<String, Object> demonstrateSystemPropertyUtils() {
        Map<String, Object> results = new HashMap<>();

        // Resolve system properties
        String javaHome = SystemPropertyUtils.resolvePlaceholders("${java.home}");
        String javaVersion = SystemPropertyUtils.resolvePlaceholders("${java.version}");
        String osName = SystemPropertyUtils.resolvePlaceholders("${os.name}");

        // With default values
        String unknownProperty =
                SystemPropertyUtils.resolvePlaceholders("${unknown.property:default_value}");
        String appName = SystemPropertyUtils.resolvePlaceholders("${app.name:Spring Utils Demo}");

        results.put("java_home", javaHome);
        results.put("java_version", javaVersion);
        results.put("os_name", osName);
        results.put("unknown_with_default", unknownProperty);
        results.put("app_name", appName);

        return results;
    }

    public Map<String, Object> demonstrateAll() {
        Map<String, Object> allResults = new HashMap<>();

        allResults.put("CollectionUtils", demonstrateCollectionUtils());
        allResults.put("MultiValueMap", demonstrateMultiValueMap());
        allResults.put("ConcurrentReferenceHashMap", demonstrateConcurrentReferenceHashMap());
        allResults.put("SystemPropertyUtils", demonstrateSystemPropertyUtils());

        return allResults;
    }

    private Map<String, String> createUser(String name, String email) {
        Map<String, String> user = new HashMap<>();
        user.put("name", name);
        user.put("email", email);
        return user;
    }
}
