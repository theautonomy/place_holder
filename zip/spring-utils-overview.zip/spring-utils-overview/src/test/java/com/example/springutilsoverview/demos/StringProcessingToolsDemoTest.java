package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.util.Map;
import java.util.Properties;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PatternMatchUtils;
import org.springframework.util.PropertyPlaceholderHelper;
import org.springframework.util.StringUtils;

/**
 * Unit tests demonstrating usage of Spring's String Processing utilities. These tests show
 * practical examples of how to use: - StringUtils: String manipulation and validation -
 * AntPathMatcher: URL/path pattern matching - PatternMatchUtils: Simple wildcard matching -
 * PropertyPlaceholderHelper: Property placeholder resolution
 */
class StringProcessingToolsDemoTest {

    private StringProcessingToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new StringProcessingToolsDemo();
    }

    @Test
    void testStringUtils_BasicOperations() {
        // Test isEmpty functionality
        assertThat(StringUtils.isEmpty(null)).as("null should be empty").isTrue();
        assertThat(StringUtils.isEmpty("")).as("empty string should be empty").isTrue();
        assertThat(StringUtils.isEmpty("hello"))
                .as("non-empty string should not be empty")
                .isFalse();

        // Test hasText functionality
        assertThat(StringUtils.hasText(null)).as("null should not have text").isFalse();
        assertThat(StringUtils.hasText("")).as("empty string should not have text").isFalse();
        assertThat(StringUtils.hasText("   ")).as("whitespace-only should not have text").isFalse();
        assertThat(StringUtils.hasText("hello")).as("text string should have text").isTrue();
    }

    @Test
    void testStringUtils_TokenizeOperations() {
        // Test tokenization
        String[] tokens = StringUtils.tokenizeToStringArray("a,b,c", ",");
        assertThat(tokens).as("Should tokenize into 3 parts").hasSize(3);
        assertThat(tokens[0]).isEqualTo("a");
        assertThat(tokens[1]).isEqualTo("b");
        assertThat(tokens[2]).isEqualTo("c");

        // Test with different delimiters
        String[] spaceTokens = StringUtils.tokenizeToStringArray("one two three", " ");
        assertThat(spaceTokens).hasSize(3);
        assertThat(spaceTokens[0]).isEqualTo("one");
    }

    @Test
    void testStringUtils_TextProcessing() {
        // Test trimming
        assertThat(StringUtils.trimWhitespace("  hello world  ")).isEqualTo("hello world");
        assertThat(StringUtils.trimWhitespace("   ")).isEqualTo("");

        // Test capitalization
        assertThat(StringUtils.capitalize("hello")).isEqualTo("Hello");
        assertThat(StringUtils.capitalize("hELLO")).isEqualTo("HELLO");
        assertThat(StringUtils.capitalize("")).isEqualTo("");
    }

    @Test
    void testAntPathMatcher_PatternMatching() {
        AntPathMatcher matcher = new AntPathMatcher();

        // Test wildcard matching
        assertThat(matcher.match("/users/*", "/users/123"))
                .as("Should match wildcard pattern")
                .isTrue();
        assertThat(matcher.match("/users/*", "/admin/123"))
                .as("Should not match different path")
                .isFalse();

        // Test recursive matching
        assertThat(matcher.match("/api/**", "/api/v1/users"))
                .as("Should match recursive pattern")
                .isTrue();
        assertThat(matcher.match("/api/**", "/api/v1/users/123"))
                .as("Should match deeper recursive pattern")
                .isTrue();

        // Test single character matching
        assertThat(matcher.match("/user?", "/users"))
                .as("Should match single character pattern")
                .isTrue();
        assertThat(matcher.match("/user?", "/user"))
                .as("Should not match without character")
                .isFalse();
    }

    @Test
    void testAntPathMatcher_VariableExtraction() {
        AntPathMatcher matcher = new AntPathMatcher();

        // Extract path variables
        Map<String, String> variables =
                matcher.extractUriTemplateVariables("/users/{id}", "/users/42");

        assertThat(variables).as("Should extract one variable").hasSize(1);
        assertThat(variables.get("id")).as("Should extract correct ID value").isEqualTo("42");

        // Multiple variables
        Map<String, String> multiVars =
                matcher.extractUriTemplateVariables(
                        "/users/{userId}/posts/{postId}", "/users/123/posts/456");

        assertThat(multiVars).as("Should extract two variables").hasSize(2);
        assertThat(multiVars.get("userId")).isEqualTo("123");
        assertThat(multiVars.get("postId")).isEqualTo("456");
    }

    @Test
    void testPatternMatchUtils_SimpleMatching() {
        // Test simple pattern matching
        assertThat(PatternMatchUtils.simpleMatch("*.txt", "document.txt"))
                .as("Should match file extension pattern")
                .isTrue();
        assertThat(PatternMatchUtils.simpleMatch("*.txt", "document.pdf"))
                .as("Should not match different extension")
                .isFalse();

        // Test with question mark (note: ? in PatternMatchUtils matches exactly one character)
        assertThat(PatternMatchUtils.simpleMatch("file*.txt", "filex.txt"))
                .as("Should match single character pattern")
                .isTrue();
        assertThat(PatternMatchUtils.simpleMatch("file?.txt", "file.txt"))
                .as("Should not match when character is missing")
                .isFalse();
    }

    @Test
    void testPatternMatchUtils_MultiplePatterns() {
        String[] patterns = {"*.java", "*.class", "*.jar"};

        assertThat(PatternMatchUtils.simpleMatch(patterns, "MyClass.java"))
                .as("Should match one of multiple patterns")
                .isTrue();
        assertThat(PatternMatchUtils.simpleMatch(patterns, "library.jar"))
                .as("Should match jar pattern")
                .isTrue();
        assertThat(PatternMatchUtils.simpleMatch(patterns, "readme.txt"))
                .as("Should not match any pattern")
                .isFalse();
    }

    @Test
    void testPropertyPlaceholderHelper_BasicReplacement() {
        PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper("${", "}");
        Properties properties = new Properties();
        properties.setProperty("name", "World");
        properties.setProperty("greeting", "Hello");

        // Test basic placeholder replacement
        String result = helper.replacePlaceholders("Hello ${name}!", properties);
        assertThat(result)
                .as("Should replace placeholder with property value")
                .isEqualTo("Hello World!");

        // Test multiple placeholders
        String multiResult = helper.replacePlaceholders("${greeting} ${name}!", properties);
        assertThat(multiResult)
                .as("Should replace multiple placeholders")
                .isEqualTo("Hello World!");
    }

    @Test
    void testPropertyPlaceholderHelper_DefaultValues() {
        PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper("${", "}", ":", true);
        Properties properties = new Properties();
        properties.setProperty("existing", "value");

        // Test with default value for missing property
        String result = helper.replacePlaceholders("${missing:default}", properties);
        assertThat(result).as("Should use default value for missing property").isEqualTo("default");

        // Test existing property ignores default
        String existingResult = helper.replacePlaceholders("${existing:default}", properties);
        assertThat(existingResult).as("Should use actual value, not default").isEqualTo("value");
    }

    @Test
    void testPropertyPlaceholderHelper_NestedPlaceholders() {
        PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper("${", "}", ":", true);
        Properties properties = new Properties();
        properties.setProperty("env", "prod");
        properties.setProperty("db.prod", "production-db");
        properties.setProperty("db.dev", "development-db");

        // Test nested placeholder resolution
        String result = helper.replacePlaceholders("${db.${env}}", properties);
        assertThat(result).as("Should resolve nested placeholders").isEqualTo("production-db");
    }

    @Test
    void testStringProcessingToolsDemo_Integration() {
        // Test the complete demonstration
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results).as("Should contain StringUtils results").containsKey("StringUtils");
        assertThat(results)
                .as("Should contain AntPathMatcher results")
                .containsKey("AntPathMatcher");
        assertThat(results)
                .as("Should contain PatternMatchUtils results")
                .containsKey("PatternMatchUtils");
        assertThat(results)
                .as("Should contain PropertyPlaceholderHelper results")
                .containsKey("PropertyPlaceholderHelper");

        // Verify StringUtils results
        @SuppressWarnings("unchecked")
        Map<String, Object> stringUtilsResults = (Map<String, Object>) results.get("StringUtils");
        assertThat((Boolean) stringUtilsResults.get("isEmpty_null")).isTrue();
        assertThat((Boolean) stringUtilsResults.get("hasText_hello")).isTrue();

        // Verify tokenization results
        String[] tokens = (String[]) stringUtilsResults.get("tokenized");
        assertThat(tokens).hasSize(3);
        assertThat(tokens[0]).isEqualTo("a");
    }

    @Test
    void testRealWorldUseCases() {
        // Email validation using StringUtils
        String email = "  user@example.com  ";
        String cleanEmail = StringUtils.trimWhitespace(email);
        assertThat(StringUtils.hasText(cleanEmail)).as("Cleaned email should have text").isTrue();
        assertThat(cleanEmail).isEqualTo("user@example.com");

        // URL path matching for REST APIs
        AntPathMatcher matcher = new AntPathMatcher();
        assertThat(matcher.match("/api/users/{id}/profile", "/api/users/123/profile")).isTrue();

        Map<String, String> pathVars =
                matcher.extractUriTemplateVariables(
                        "/api/users/{id}/profile", "/api/users/123/profile");
        assertThat(pathVars.get("id")).isEqualTo("123");

        // Configuration property resolution
        PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper("${", "}", ":", true);
        Properties config = new Properties();
        config.setProperty("server.host", "localhost");
        config.setProperty("server.port", "8080");

        String url = helper.replacePlaceholders("http://${server.host}:${server.port}/api", config);
        assertThat(url).isEqualTo("http://localhost:8080/api");
    }
}
