package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.core.env.ConfigurableEnvironment;

/**
 * Unit tests demonstrating usage of Spring's Context utilities. These tests show practical examples
 * of how to use: - ApplicationEventPublisher: Event publishing and handling - LocaleContextHolder:
 * Locale management for internationalization - DefaultConversionService: Type conversion utilities
 * - PropertySource utilities: Environment and configuration management
 */
@SpringBootTest
class SpringContextToolsDemoTest {

    @Autowired private SpringContextToolsDemo demo;

    @Autowired(required = false)
    private ApplicationContext applicationContext;

    @Autowired(required = false)
    private ApplicationEventPublisher eventPublisher;

    @Autowired(required = false)
    private ConfigurableEnvironment environment;

    @BeforeEach
    void setUp() {
        // Reset locale to default for consistent testing
        LocaleContextHolder.setLocale(Locale.getDefault());
    }

    @Test
    void testLocaleContextHolder_BasicOperations() {
        // Get current locale
        Locale originalLocale = LocaleContextHolder.getLocale();
        assertThat(originalLocale).isNotNull();

        // Test setting different locales
        LocaleContextHolder.setLocale(Locale.FRENCH);
        assertThat(LocaleContextHolder.getLocale()).isEqualTo(Locale.FRENCH);

        LocaleContextHolder.setLocale(Locale.GERMAN);
        assertThat(LocaleContextHolder.getLocale()).isEqualTo(Locale.GERMAN);

        // Restore original locale
        LocaleContextHolder.setLocale(originalLocale);
        assertThat(LocaleContextHolder.getLocale()).isEqualTo(originalLocale);
    }

    @Test
    void testLocaleContextHolder_LocaleInformation() {
        // Test with US locale
        LocaleContextHolder.setLocale(Locale.US);
        Locale currentLocale = LocaleContextHolder.getLocale();

        assertThat(currentLocale.getLanguage()).isEqualTo("en");
        assertThat(currentLocale.getCountry()).isEqualTo("US");

        // Test with French locale
        LocaleContextHolder.setLocale(Locale.FRANCE);
        currentLocale = LocaleContextHolder.getLocale();

        assertThat(currentLocale.getLanguage()).isEqualTo("fr");
        assertThat(currentLocale.getCountry()).isEqualTo("FR");

        // Clean up
        LocaleContextHolder.setLocale(Locale.getDefault());
    }

    @Test
    void testDefaultConversionService_StringToNumberConversions() {
        DefaultConversionService service = new DefaultConversionService();

        // String to Integer
        Integer intValue = service.convert("42", Integer.class);
        assertThat(intValue).isEqualTo(42);

        // String to Double
        Double doubleValue = service.convert("3.14159", Double.class);
        assertThat(doubleValue).isCloseTo(3.14159, within(0.00001));

        // String to BigDecimal
        BigDecimal bigDecimalValue = service.convert("12345.6789", BigDecimal.class);
        assertThat(bigDecimalValue).isEqualTo(new BigDecimal("12345.6789"));
    }

    @Test
    void testDefaultConversionService_BooleanConversions() {
        DefaultConversionService service = new DefaultConversionService();

        // Standard boolean strings
        assertThat(service.convert("true", Boolean.class)).isTrue();
        assertThat(service.convert("false", Boolean.class)).isFalse();

        // Case insensitive
        assertThat(service.convert("TRUE", Boolean.class)).isTrue();
        assertThat(service.convert("FALSE", Boolean.class)).isFalse();

        // Alternative boolean representations
        assertThat(service.convert("yes", Boolean.class)).isTrue();
        assertThat(service.convert("on", Boolean.class)).isTrue();
        assertThat(service.convert("1", Boolean.class)).isTrue();

        assertThat(service.convert("no", Boolean.class)).isFalse();
        assertThat(service.convert("off", Boolean.class)).isFalse();
        assertThat(service.convert("0", Boolean.class)).isFalse();
    }

    @Test
    void testDefaultConversionService_NumberConversions() {
        DefaultConversionService service = new DefaultConversionService();

        // Integer to Double
        Double intToDouble = service.convert(42, Double.class);
        assertThat(intToDouble).isEqualTo(42.0);

        // Double to Integer (truncation)
        Integer doubleToInt = service.convert(42.7, Integer.class);
        assertThat(doubleToInt).isEqualTo(42);

        // Long to Integer
        Integer longToInt = service.convert(123L, Integer.class);
        assertThat(longToInt).isEqualTo(123);
    }

    @Test
    void testDefaultConversionService_CollectionConversions() {
        DefaultConversionService service = new DefaultConversionService();

        // Array to List
        String[] array = {"apple", "banana", "cherry"};
        @SuppressWarnings("unchecked")
        List<String> list = service.convert(array, List.class);

        assertThat(list).isNotNull();
        assertThat(list).hasSize(3);
        assertThat(list.get(0)).isEqualTo("apple");
        assertThat(list.get(1)).isEqualTo("banana");
        assertThat(list.get(2)).isEqualTo("cherry");
    }

    @Test
    void testDefaultConversionService_ConversionCapabilities() {
        DefaultConversionService service = new DefaultConversionService();

        // Test capability checks
        assertThat(service.canConvert(String.class, Integer.class)).isTrue();
        assertThat(service.canConvert(Integer.class, String.class))
                .as("Should support Integer to String")
                .isTrue();
        assertThat(service.canConvert(String.class, Boolean.class))
                .as("Should support String to Boolean")
                .isTrue();
        assertThat(service.canConvert(String[].class, List.class))
                .as("Should support Array to List")
                .isTrue();

        // Test unsupported conversions (example)
        assertThat(service.canConvert(StringBuilder.class, Integer.class))
                .as("Should not support StringBuilder to Integer")
                .isFalse();
    }

    @Test
    void testSpringContextToolsDemo_LocaleContextHolderDemo() {
        Map<String, Object> results = demo.demonstrateLocaleContextHolder();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify basic locale information
        assertThat(results.get("current_locale")).as("Should have current locale").isNotNull();
        assertThat(results.get("language")).as("Should have language").isNotNull();
        assertThat(results.get("display_name")).as("Should have display name").isNotNull();

        // Verify locale tests
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> localeTests =
                (List<Map<String, Object>>) results.get("locale_tests");
        assertThat(localeTests).as("Should have locale tests").isNotNull();
        assertThat(localeTests.size()).as("Should test multiple locales").isPositive();

        // Verify each locale test has required information
        for (Map<String, Object> localeTest : localeTests) {
            assertThat(localeTest.get("locale")).as("Each test should have locale").isNotNull();
            assertThat(localeTest.get("language")).as("Each test should have language").isNotNull();
            assertThat(localeTest.get("display_name"))
                    .as("Each test should have display name")
                    .isNotNull();
        }

        // Verify locale was restored
        assertThat(results.get("locale_restored")).as("Should restore locale").isNotNull();

        // Verify use cases
        @SuppressWarnings("unchecked")
        List<String> useCases = (List<String>) results.get("use_cases");
        assertThat(useCases).as("Should have use cases").isNotNull();
        assertThat(useCases).as("Should mention i18n").contains("Internationalization (i18n)");
    }

    @Test
    void testSpringContextToolsDemo_DefaultConversionServiceDemo() {
        Map<String, Object> results = demo.demonstrateDefaultConversionService();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify conversions
        @SuppressWarnings("unchecked")
        Map<String, Object> conversions = (Map<String, Object>) results.get("conversions");
        assertThat(conversions).as("Should have conversions").isNotNull();

        assertThat(conversions.get("string_42_to_integer"))
                .as("Should convert string to integer")
                .isEqualTo(42);
        assertThat((Double) conversions.get("string_3.14159_to_double"))
                .as("Should convert string to double")
                .isCloseTo(3.14159, within(0.00001));
        assertThat(conversions.get("string_true_to_boolean"))
                .as("Should convert string to boolean")
                .isEqualTo(true);
        assertThat((Double) conversions.get("int_42_to_double"))
                .as("Should convert int to double")
                .isCloseTo(42.0, within(0.001));

        // Verify capabilities
        @SuppressWarnings("unchecked")
        Map<String, Boolean> capabilities =
                (Map<String, Boolean>) results.get("conversion_capabilities");
        assertThat(capabilities).as("Should have capabilities").isNotNull();
        assertThat(capabilities.get("string_to_integer"))
                .as("Should support string to integer")
                .isEqualTo(true);
        assertThat(capabilities.get("integer_to_string"))
                .as("Should support integer to string")
                .isEqualTo(true);

        // Verify information
        assertThat(results.get("note")).as("Should have informational note").isNotNull();
        @SuppressWarnings("unchecked")
        List<String> converterTypes = (List<String>) results.get("converter_types");
        assertThat(converterTypes).as("Should have converter types").isNotNull();
        assertThat(converterTypes)
                .as("Should mention string to number converters")
                .contains("String to Number converters");
    }

    @Test
    void testSpringContextToolsDemo_ApplicationEventPublisherDemo() {
        Map<String, Object> results = demo.demonstrateApplicationEventPublisher();

        assertThat(results).as("Results should not be null").isNotNull();

        if (eventPublisher != null) {
            // If we have event publisher, verify it worked
            assertThat(results.containsKey("error")).as("Should not have errors").isFalse();
            assertThat(results.get("publisher_available"))
                    .as("Publisher should be available")
                    .isEqualTo(true);
            assertThat(results.get("events_published")).as("Should publish 3 events").isEqualTo(3);

            // Note: events_received might be 0, 1, 2, or 3 depending on timing and Spring context
            // setup
            assertThat((Integer) results.get("events_received"))
                    .as("Should receive some events")
                    .isNotNegative();

            // Verify use cases
            @SuppressWarnings("unchecked")
            List<String> useCases = (List<String>) results.get("use_cases");
            assertThat(useCases).as("Should have use cases").isNotNull();
            assertThat(useCases)
                    .as("Should mention decoupled communication")
                    .contains("Decoupled component communication");
        } else {
            // If no event publisher, should handle gracefully
            assertThat(results.get("publisher_available"))
                    .as("Should indicate publisher not available")
                    .isEqualTo(false);
            assertThat(results.get("note")).as("Should have explanatory note").isNotNull();
        }
    }

    @Test
    void testSpringContextToolsDemo_PropertySourceUtilsDemo() {
        Map<String, Object> results = demo.demonstratePropertySourceUtils();

        assertThat(results).as("Results should not be null").isNotNull();

        if (environment != null) {
            // If we have environment, verify it worked
            assertThat(results.containsKey("error")).as("Should not have errors").isFalse();
            assertThat((Integer) results.get("total_property_sources"))
                    .as("Should have property sources")
                    .isPositive();

            @SuppressWarnings("unchecked")
            List<String> propertySourceNames = (List<String>) results.get("property_source_names");
            assertThat(propertySourceNames).as("Should have property source names").isNotNull();
            assertThat(propertySourceNames.size())
                    .as("Should have at least one property source")
                    .isPositive();

            // Check if custom properties were added
            @SuppressWarnings("unchecked")
            Map<String, Object> resolvedProperties =
                    (Map<String, Object>) results.get("resolved_properties");
            assertThat(resolvedProperties).as("Should have resolved properties").isNotNull();
            assertThat(resolvedProperties.get("demo.application.name"))
                    .as("Should resolve custom property")
                    .isEqualTo("Spring Utils Demo");

            // Verify default value handling
            assertThat(results.get("unknown_property_with_default"))
                    .as("Should use default for unknown property")
                    .isEqualTo("default-value");

            // Verify profiles information
            assertThat(results.get("active_profiles"))
                    .as("Should have active profiles")
                    .isNotNull();
            assertThat(results.get("default_profiles"))
                    .as("Should have default profiles")
                    .isNotNull();

            assertThat(results.get("precedence_note")).as("Should explain precedence").isNotNull();
        } else {
            assertThat(results.get("environment_available"))
                    .as("Should indicate environment not available")
                    .isEqualTo(false);
        }
    }

    @Test
    void testSpringContextToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results)
                .as("Should contain event publisher results")
                .containsKey("ApplicationEventPublisher");
        assertThat(results)
                .as("Should contain locale holder results")
                .containsKey("LocaleContextHolder");
        assertThat(results)
                .as("Should contain conversion service results")
                .containsKey("DefaultConversionService");
        assertThat(results)
                .as("Should contain property source results")
                .containsKey("PropertySourceUtils");

        // Verify each section has expected content
        @SuppressWarnings("unchecked")
        Map<String, Object> localeResults =
                (Map<String, Object>) results.get("LocaleContextHolder");
        assertThat(localeResults.get("current_locale")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> conversionResults =
                (Map<String, Object>) results.get("DefaultConversionService");
        assertThat(conversionResults.get("conversions")).isNotNull();
    }

    @Test
    void testCustomEvent_Creation() {
        SpringContextToolsDemo.CustomEvent event =
                new SpringContextToolsDemo.CustomEvent(
                        "test.event", "Test message", Map.of("key1", "value1", "key2", 42));

        assertThat(event.getEventType())
                .as("Should have correct event type")
                .isEqualTo("test.event");
        assertThat(event.getMessage()).as("Should have correct message").isEqualTo("Test message");
        assertThat(event.getTimestamp()).as("Should have timestamp").isNotNull();
        assertThat(event.getMetadata()).as("Should have metadata").isNotNull();
        assertThat(event.getMetadata().get("key1"))
                .as("Should have metadata value 1")
                .isEqualTo("value1");
        assertThat(event.getMetadata().get("key2"))
                .as("Should have metadata value 2")
                .isEqualTo(42);
    }

    @Test
    void testRealWorldContextUseCases() {
        // Internationalization scenario
        Locale originalLocale = LocaleContextHolder.getLocale();

        // Simulate different user locales
        Locale[] userLocales = {Locale.US, Locale.FRANCE, Locale.GERMANY, Locale.JAPAN};

        for (Locale userLocale : userLocales) {
            LocaleContextHolder.setLocale(userLocale);
            Locale currentLocale = LocaleContextHolder.getLocale();

            assertThat(currentLocale).as("Should set user locale correctly").isEqualTo(userLocale);

            // In real app, you would format dates, numbers, messages based on this locale
            assertThat(currentLocale.getLanguage())
                    .as("Should have language for formatting")
                    .isNotNull();
        }

        // Restore original locale
        LocaleContextHolder.setLocale(originalLocale);

        // Type conversion for form processing
        DefaultConversionService converter = new DefaultConversionService();

        // Simulate form input conversion
        Map<String, String> formData =
                Map.of(
                        "age", "25",
                        "salary", "75000.50",
                        "isActive", "true",
                        "tags", "java,spring,testing");

        // Convert form values to appropriate types
        Integer age = converter.convert(formData.get("age"), Integer.class);
        BigDecimal salary = converter.convert(formData.get("salary"), BigDecimal.class);
        Boolean isActive = converter.convert(formData.get("isActive"), Boolean.class);

        assertThat(age).as("Should convert age string to integer").isEqualTo(25);
        assertThat(salary)
                .as("Should convert salary to BigDecimal")
                .isEqualTo(new BigDecimal("75000.50"));
        assertThat(isActive).as("Should convert active flag to boolean").isTrue();

        // Event publishing for audit logging
        if (eventPublisher != null) {
            SpringContextToolsDemo.CustomEvent auditEvent =
                    new SpringContextToolsDemo.CustomEvent(
                            "user.action",
                            "User performed action",
                            Map.of("userId", "user123", "action", "profile.update"));

            assertThat(auditEvent).as("Should create audit event").isNotNull();
            assertThat(auditEvent.getEventType())
                    .as("Should have correct audit event type")
                    .isEqualTo("user.action");

            // In real scenario, this would be published to the event system
            // eventPublisher.publishEvent(auditEvent);
        }
    }
}
