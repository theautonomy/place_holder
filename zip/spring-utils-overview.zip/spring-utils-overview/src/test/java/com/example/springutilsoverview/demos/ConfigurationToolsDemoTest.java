package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.io.ByteArrayResource;

/**
 * Unit tests demonstrating usage of Spring's Configuration utilities. These tests show practical
 * examples of how to use: - YamlPropertiesFactoryBean: YAML configuration loading -
 * RandomStringUtils: Random string generation (Apache Commons Lang3) - Additional configuration
 * utilities overview
 */
class ConfigurationToolsDemoTest {

    private ConfigurationToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new ConfigurationToolsDemo();
    }

    @Test
    void testYamlPropertiesFactoryBean_BasicFunctionality() {
        // Test YamlPropertiesFactoryBean with in-memory YAML
        YamlPropertiesFactoryBean yamlFactory = new YamlPropertiesFactoryBean();

        // Create test YAML content
        String yamlContent =
                """
            spring:
              application:
                name: test-app
            server:
              port: 8080
            logging:
              level:
                com.example: DEBUG
            """;

        yamlFactory.setResources(new ByteArrayResource(yamlContent.getBytes()));
        Properties properties = yamlFactory.getObject();

        assertThat(properties).as("Properties should not be null").isNotNull();
        assertThat(properties.getProperty("spring.application.name")).isEqualTo("test-app");
        assertThat(properties.getProperty("server.port")).isEqualTo("8080");
        assertThat(properties.getProperty("logging.level.com.example")).isEqualTo("DEBUG");
    }

    @Test
    void testYamlPropertiesFactoryBean_MultipleResources() {
        YamlPropertiesFactoryBean yamlFactory = new YamlPropertiesFactoryBean();

        // Create multiple YAML sources
        String yaml1 =
                """
            app:
              name: base-app
              version: 1.0
            """;

        String yaml2 =
                """
            app:
              name: overridden-app
              environment: test
            """;

        yamlFactory.setResources(
                new ByteArrayResource(yaml1.getBytes()), new ByteArrayResource(yaml2.getBytes()));

        Properties properties = yamlFactory.getObject();

        assertThat(properties).as("Properties should not be null").isNotNull();
        // Later resource should override earlier ones
        assertThat(properties.getProperty("app.name")).isEqualTo("overridden-app");
        assertThat(properties.getProperty("app.version")).isEqualTo("1.0");
        assertThat(properties.getProperty("app.environment")).isEqualTo("test");
    }

    @Test
    void testYamlPropertiesFactoryBean_ComplexStructures() {
        YamlPropertiesFactoryBean yamlFactory = new YamlPropertiesFactoryBean();

        String complexYaml =
                """
            database:
              url: jdbc:postgresql://localhost:5432/testdb
              username: testuser
              password: testpass
              pool:
                min-size: 5
                max-size: 20
            features:
              - authentication
              - authorization
              - caching
            """;

        yamlFactory.setResources(new ByteArrayResource(complexYaml.getBytes()));
        Properties properties = yamlFactory.getObject();

        assertThat(properties).as("Properties should not be null").isNotNull();
        assertThat(properties.getProperty("database.url"))
                .isEqualTo("jdbc:postgresql://localhost:5432/testdb");
        assertThat(properties.getProperty("database.username")).isEqualTo("testuser");
        assertThat(properties.getProperty("database.pool.min-size")).isEqualTo("5");
        assertThat(properties.getProperty("database.pool.max-size")).isEqualTo("20");

        // Arrays are converted to comma-separated values
        assertThat(properties.getProperty("features[0]")).isEqualTo("authentication");
        assertThat(properties.getProperty("features[1]")).isEqualTo("authorization");
        assertThat(properties.getProperty("features[2]")).isEqualTo("caching");
    }

    @Test
    void testRandomStringUtils_BasicGeneration() {
        // Test alphabetic generation
        String alphabetic = RandomStringUtils.randomAlphabetic(10);
        assertThat(alphabetic).as("Alphabetic string should not be null").isNotNull();
        assertThat(alphabetic.length())
                .as("Should generate string of correct length")
                .isEqualTo(10);
        assertThat(alphabetic).as("Should contain only letters").matches("[a-zA-Z]+");

        // Test alphanumeric generation
        String alphanumeric = RandomStringUtils.randomAlphanumeric(12);
        assertThat(alphanumeric).as("Alphanumeric string should not be null").isNotNull();
        assertThat(alphanumeric.length())
                .as("Should generate string of correct length")
                .isEqualTo(12);
        assertThat(alphanumeric)
                .as("Should contain only letters and numbers")
                .matches("[a-zA-Z0-9]+");

        // Test numeric generation
        String numeric = RandomStringUtils.randomNumeric(6);
        assertThat(numeric).as("Numeric string should not be null").isNotNull();
        assertThat(numeric.length()).as("Should generate string of correct length").isEqualTo(6);
        assertThat(numeric).as("Should contain only numbers").matches("[0-9]+");

        // Test ASCII generation
        String ascii = RandomStringUtils.randomAscii(8);
        assertThat(ascii).as("ASCII string should not be null").isNotNull();
        assertThat(ascii.length()).as("Should generate string of correct length").isEqualTo(8);
    }

    @Test
    void testRandomStringUtils_CustomGeneration() {
        // Test custom character set
        String custom = RandomStringUtils.random(8, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
        assertThat(custom).as("Custom string should not be null").isNotNull();
        assertThat(custom.length()).as("Should generate string of correct length").isEqualTo(8);
        assertThat(custom)
                .as("Should contain only uppercase letters and numbers")
                .matches("[A-Z0-9]+");

        // Test with boolean parameters
        String lettersAndNumbers = RandomStringUtils.random(10, true, true);
        assertThat(lettersAndNumbers)
                .as("Letters and numbers string should not be null")
                .isNotNull();
        assertThat(lettersAndNumbers.length())
                .as("Should generate string of correct length")
                .isEqualTo(10);

        String numbersOnly = RandomStringUtils.random(6, false, true);
        assertThat(numbersOnly).as("Numbers only string should not be null").isNotNull();
        assertThat(numbersOnly.length())
                .as("Should generate string of correct length")
                .isEqualTo(6);
        assertThat(numbersOnly).as("Should contain only numbers").matches("[0-9]+");
    }

    @Test
    void testRandomStringUtils_Uniqueness() {
        // Generate multiple strings and test uniqueness
        Set<String> uniqueStrings = new HashSet<>();
        int iterations = 1000;

        for (int i = 0; i < iterations; i++) {
            uniqueStrings.add(RandomStringUtils.randomAlphanumeric(12));
        }

        // Should have high uniqueness (allow for small collision rate)
        assertThat(uniqueStrings.size())
                .as("Should have very high uniqueness rate")
                .isGreaterThan((int) (iterations * 0.99));
    }

    @Test
    void testRandomStringUtils_UseCases() {
        // Session ID simulation
        String sessionId = RandomStringUtils.randomAlphanumeric(32);
        assertThat(sessionId.length()).as("Session ID should be 32 characters").isEqualTo(32);
        assertThat(sessionId).as("Session ID should be alphanumeric").matches("[a-zA-Z0-9]+");

        // API key simulation
        String apiKey = RandomStringUtils.randomAlphanumeric(40);
        assertThat(apiKey.length()).as("API key should be 40 characters").isEqualTo(40);

        // Temporary password simulation
        String tempPassword = RandomStringUtils.random(8, true, true);
        assertThat(tempPassword.length())
                .as("Temporary password should be 8 characters")
                .isEqualTo(8);

        // File name generation
        String fileName = "temp_" + RandomStringUtils.randomAlphanumeric(8) + ".tmp";
        assertThat(fileName).as("Should have correct prefix").startsWith("temp_");
        assertThat(fileName).as("Should have correct suffix").endsWith(".tmp");
    }

    @Test
    void testConfigurationToolsDemo_YamlDemo() {
        // Note: This test may fail if application.yml doesn't exist in test classpath
        Map<String, Object> results = demo.demonstrateYamlPropertiesFactoryBean();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results)
                .as("Should show multi-resource factory creation")
                .containsKey("multi_resource_factory_created");

        // Verify use cases are provided
        @SuppressWarnings("unchecked")
        List<String> useCases = (List<String>) results.get("use_cases");
        assertThat(useCases).as("Use cases should be provided").isNotNull();
        assertThat(useCases).contains("Loading YAML configuration files");
        assertThat(useCases).contains("Multi-profile configuration loading");

        // Verify benefits over properties
        @SuppressWarnings("unchecked")
        List<String> benefits = (List<String>) results.get("benefits_over_properties");
        assertThat(benefits).as("Benefits should be provided").isNotNull();
        assertThat(benefits).contains("Hierarchical structure support");
        assertThat(benefits).contains("Better readability for complex configs");
    }

    @Test
    void testConfigurationToolsDemo_RandomStringDemo() {
        Map<String, Object> results = demo.demonstrateRandomStringUtils();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify generated strings
        assertThat(results.get("random_alphabetic_10"))
                .as("Should have alphabetic string")
                .isNotNull();
        assertThat(results.get("random_alphanumeric_12"))
                .as("Should have alphanumeric string")
                .isNotNull();
        assertThat(results.get("random_numeric_6")).as("Should have numeric string").isNotNull();
        assertThat(results.get("random_ascii_8")).as("Should have ASCII string").isNotNull();

        // Verify custom generation
        assertThat(results.get("custom_uppercase_alphanumeric"))
                .as("Should have custom string")
                .isNotNull();
        assertThat(results.get("custom_letters_and_numbers"))
                .as("Should have letters and numbers")
                .isNotNull();
        assertThat(results.get("custom_numbers_only")).as("Should have numbers only").isNotNull();

        // Verify uniqueness test
        assertThat(results.get("uniqueness_test_generated"))
                .as("Should generate 100 strings")
                .isEqualTo(100);
        assertThat((Integer) results.get("uniqueness_test_unique"))
                .as("Should have high uniqueness rate")
                .isGreaterThan(95);

        // Verify use cases
        @SuppressWarnings("unchecked")
        List<String> useCases = (List<String>) results.get("spring_use_cases");
        assertThat(useCases).as("Use cases should be provided").isNotNull();
        assertThat(useCases).contains("Session ID generation");
        assertThat(useCases).contains("API key generation");
    }

    @Test
    void testConfigurationToolsDemo_AdditionalUtilities() {
        Map<String, Object> results = demo.demonstrateAdditionalUtilities();

        assertThat(results).as("Results should not be null").isNotNull();

        // Verify additional utilities are documented
        @SuppressWarnings("unchecked")
        Map<String, String> additionalUtils =
                (Map<String, String>) results.get("additional_utilities");
        assertThat(additionalUtils).as("Additional utilities should be documented").isNotNull();
        assertThat(additionalUtils).containsKey("Environment");
        assertThat(additionalUtils).containsKey("PropertySource");
        assertThat(additionalUtils).containsKey("PasswordEncoder");

        // Verify category summary
        @SuppressWarnings("unchecked")
        Map<String, Integer> categorySummary =
                (Map<String, Integer>) results.get("category_summary");
        assertThat(categorySummary).as("Category summary should be provided").isNotNull();
        assertThat(categorySummary).containsKey("String Processing");
        assertThat(categorySummary).containsKey("Configuration");

        // Verify total count
        Integer totalUtilities = (Integer) results.get("total_utilities_covered");
        assertThat(totalUtilities).as("Total utilities count should be provided").isNotNull();
        assertThat(totalUtilities)
                .as("Should cover significant number of utilities")
                .isGreaterThan(40);

        // Verify best practices
        @SuppressWarnings("unchecked")
        List<String> bestPractices = (List<String>) results.get("best_practices");
        assertThat(bestPractices).as("Best practices should be provided").isNotNull();
        assertThat(bestPractices)
                .contains("Prefer Spring utilities over external libraries when available");
    }

    @Test
    void testConfigurationToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results)
                .as("Should contain YamlPropertiesFactoryBean results")
                .containsKey("YamlPropertiesFactoryBean");
        assertThat(results)
                .as("Should contain RandomStringUtils results")
                .containsKey("RandomStringUtils");
        assertThat(results)
                .as("Should contain AdditionalUtilities results")
                .containsKey("AdditionalUtilities");

        // Verify each component has expected structure
        @SuppressWarnings("unchecked")
        Map<String, Object> yamlResults =
                (Map<String, Object>) results.get("YamlPropertiesFactoryBean");
        assertThat(yamlResults.get("multi_resource_factory_created")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> randomResults = (Map<String, Object>) results.get("RandomStringUtils");
        assertThat(randomResults.get("random_alphabetic_10")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> additionalResults =
                (Map<String, Object>) results.get("AdditionalUtilities");
        assertThat(additionalResults.get("additional_utilities")).isNotNull();
    }

    @Test
    void testRealWorldConfigurationUseCases() {
        // Test YAML configuration for different environments
        YamlPropertiesFactoryBean factory = new YamlPropertiesFactoryBean();

        String productionConfig =
                """
            server:
              port: 8080
            database:
              url: jdbc:postgresql://prod-db:5432/myapp
              pool:
                max-size: 50
            logging:
              level:
                com.mycompany: INFO
            """;

        factory.setResources(new ByteArrayResource(productionConfig.getBytes()));
        Properties props = factory.getObject();

        assertThat(props).as("Production config should load").isNotNull();
        assertThat(props.getProperty("server.port")).isEqualTo("8080");
        assertThat(props.getProperty("database.pool.max-size")).isEqualTo("50");
        assertThat(props.getProperty("logging.level.com.mycompany")).isEqualTo("INFO");

        // Test random string generation for various security purposes
        String sessionToken = RandomStringUtils.randomAlphanumeric(64);
        String csrfToken = RandomStringUtils.randomAlphanumeric(32);
        String resetCode = RandomStringUtils.randomNumeric(6);

        assertThat(sessionToken.length())
                .as("Session token should be correct length")
                .isEqualTo(64);
        assertThat(csrfToken.length()).as("CSRF token should be correct length").isEqualTo(32);
        assertThat(resetCode.length()).as("Reset code should be correct length").isEqualTo(6);
        assertThat(resetCode).as("Reset code should be numeric").matches("[0-9]+");
    }
}
