package com.example.springutilsoverview.demos;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.ResolvableType;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Unit tests demonstrating usage of Spring's Data Conversion utilities. These tests show practical
 * examples of how to use: - ResolvableType: Generic type resolution and inspection -
 * MappingJackson2HttpMessageConverter: JSON HTTP message conversion - MediaTypeFactory: Media type
 * detection from file extensions - MimeTypeUtils: MIME type utilities and constants
 */
class DataConversionToolsDemoTest {

    private DataConversionToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new DataConversionToolsDemo();
    }

    @Test
    void testResolvableType_SimpleGenericTypes() throws Exception {
        // Test List<String>
        ResolvableType listType = ResolvableType.forClassWithGenerics(List.class, String.class);

        assertThat(listType.getRawClass()).as("Raw class should be List").isEqualTo(List.class);
        assertThat(listType.getGeneric(0).getRawClass())
                .as("Generic should be String")
                .isEqualTo(String.class);
        assertThat(listType.hasGenerics()).as("Should have generics").isTrue();
        assertThat(listType.getGenerics().length)
                .as("Should have one generic parameter")
                .isEqualTo(1);

        // Test Map<String, Integer>
        ResolvableType mapType =
                ResolvableType.forClassWithGenerics(
                        Map.class,
                        ResolvableType.forClass(String.class),
                        ResolvableType.forClass(Integer.class));

        assertThat(mapType.getRawClass()).as("Raw class should be Map").isEqualTo(Map.class);
        assertThat(mapType.getGeneric(0).getRawClass())
                .as("Key type should be String")
                .isEqualTo(String.class);
        assertThat(mapType.getGeneric(1).getRawClass())
                .as("Value type should be Integer")
                .isEqualTo(Integer.class);
        assertThat(mapType.getGenerics().length)
                .as("Should have two generic parameters")
                .isEqualTo(2);
    }

    @Test
    void testResolvableType_ArrayTypes() {
        // Test String[]
        ResolvableType arrayType =
                ResolvableType.forArrayComponent(ResolvableType.forClass(String.class));

        assertThat(arrayType.isArray()).as("Should be array type").isTrue();
        assertThat(arrayType.getComponentType().getRawClass())
                .as("Component type should be String")
                .isEqualTo(String.class);
        assertThat(arrayType.getRawClass())
                .as("Raw class should be String[]")
                .isEqualTo(String[].class);
    }

    @Test
    void testResolvableType_ComplexNestedTypes() {
        // Test Map<String, List<Integer>>
        ResolvableType listOfIntegerType =
                ResolvableType.forClassWithGenerics(List.class, Integer.class);
        ResolvableType complexMapType =
                ResolvableType.forClassWithGenerics(
                        Map.class, ResolvableType.forClass(String.class), listOfIntegerType);

        assertThat(complexMapType.getRawClass()).as("Root should be Map").isEqualTo(Map.class);
        assertThat(complexMapType.getGeneric(0).getRawClass())
                .as("Key should be String")
                .isEqualTo(String.class);
        assertThat(complexMapType.getGeneric(1).getRawClass())
                .as("Value should be List")
                .isEqualTo(List.class);
        assertThat(complexMapType.getGeneric(1).getGeneric(0).getRawClass())
                .as("Nested generic should be Integer")
                .isEqualTo(Integer.class);
    }

    @Test
    void testResolvableType_FieldBasedResolution() throws Exception {
        Field complexMapField =
                DataConversionToolsDemo.TestClass.class.getDeclaredField("complexMap");
        ResolvableType fieldType = ResolvableType.forField(complexMapField);

        assertThat(fieldType.getRawClass()).as("Field type should be Map").isEqualTo(Map.class);
        assertThat(fieldType.getGenerics().length).as("Should have two generics").isEqualTo(2);
        assertThat(fieldType.getGeneric(0).getRawClass())
                .as("Key type from field")
                .isEqualTo(String.class);
        assertThat(fieldType.getGeneric(1).getRawClass())
                .as("Value type from field")
                .isEqualTo(List.class);
        assertThat(fieldType.getGeneric(1).getGeneric(0).getRawClass())
                .as("Nested generic from field")
                .isEqualTo(Integer.class);
    }

    @Test
    void testResolvableType_TypeRelationships() {
        ResolvableType listType = ResolvableType.forClassWithGenerics(List.class, String.class);
        ResolvableType collectionType = ResolvableType.forClass(Collection.class);
        ResolvableType mapType =
                ResolvableType.forClassWithGenerics(Map.class, String.class, Object.class);

        // List extends Collection
        assertThat(collectionType.isAssignableFrom(listType))
                .as("Collection should be assignable from List")
                .isTrue();
        assertThat(collectionType.isAssignableFrom(mapType))
                .as("Collection should not be assignable from Map")
                .isFalse();

        // Self-assignment
        assertThat(listType.isAssignableFrom(listType))
                .as("Type should be assignable from itself")
                .isTrue();
    }

    @Test
    void testMappingJackson2HttpMessageConverter_BasicConfiguration() {
        ObjectMapper customMapper = new ObjectMapper();
        customMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        customMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

        MappingJackson2HttpMessageConverter converter =
                new MappingJackson2HttpMessageConverter(customMapper);

        List<MediaType> supportedTypes = converter.getSupportedMediaTypes();
        assertThat(supportedTypes).as("Supported types should not be null").isNotNull();
        assertThat(supportedTypes.contains(MediaType.APPLICATION_JSON))
                .as("Should support JSON")
                .isTrue();

        ObjectMapper usedMapper = converter.getObjectMapper();
        assertThat(usedMapper.isEnabled(SerializationFeature.INDENT_OUTPUT))
                .as("Should have indent output enabled")
                .isTrue();
        assertThat(usedMapper.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS))
                .as("Should not write dates as timestamps")
                .isFalse();
    }

    @Test
    void testMappingJackson2HttpMessageConverter_ObjectSerialization() throws Exception {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();

        // Test if converter can write custom objects
        assertThat(
                        converter.canWrite(
                                DataConversionToolsDemo.TestObject.class,
                                MediaType.APPLICATION_JSON))
                .as("Should be able to write TestObject as JSON")
                .isTrue();
        assertThat(converter.canWrite(Map.class, MediaType.APPLICATION_JSON))
                .as("Should be able to write Map as JSON")
                .isTrue();
        assertThat(converter.canWrite(List.class, MediaType.APPLICATION_JSON))
                .as("Should be able to write List as JSON")
                .isTrue();

        // Test serialization
        DataConversionToolsDemo.TestObject testObj =
                new DataConversionToolsDemo.TestObject(
                        "Alice", 25, Arrays.asList("reading", "swimming"));

        ObjectMapper mapper = converter.getObjectMapper();
        String json = mapper.writeValueAsString(testObj);

        assertThat(json).as("JSON should not be null").isNotNull();
        assertThat(json.contains("Alice")).as("JSON should contain name").isTrue();
        assertThat(json.contains("25")).as("JSON should contain age").isTrue();
        assertThat(json.contains("reading")).as("JSON should contain hobbies").isTrue();

        // Test deserialization
        DataConversionToolsDemo.TestObject deserialized =
                mapper.readValue(json, DataConversionToolsDemo.TestObject.class);

        assertThat(deserialized.getName()).as("Name should be preserved").isEqualTo("Alice");
        assertThat(deserialized.getAge()).as("Age should be preserved").isEqualTo(25);
        assertThat(deserialized.getHobbies())
                .as("Hobbies should be preserved")
                .isEqualTo(Arrays.asList("reading", "swimming"));
    }

    @Test
    void testMediaTypeFactory_CommonFileTypes() {
        String[] testCases = {
            "document.pdf", "application/pdf",
            "image.jpg", "image/jpeg",
            "image.png", "image/png",
            "data.json", "application/json",
            "style.css", "text/css",
        //     "script.js", "application/javascript",
            "video.mp4", "video/mp4",
            "audio.mp3", "audio/mpeg",
            "text.txt", "text/plain"
        };

        for (int i = 0; i < testCases.length; i += 2) {
            String filename = testCases[i];
            String expectedType = testCases[i + 1];

            Optional<MediaType> mediaType = MediaTypeFactory.getMediaType(filename);
            assertThat(mediaType).as("Should detect media type for " + filename).isPresent();
            assertThat(mediaType.get().toString())
                    .as("Should detect correct type for " + filename)
                    .isEqualTo(expectedType);
        }
    }

    @Test
    void testMediaTypeFactory_UnknownExtensions() {
        String[] unknownFiles = {"document.unknown", "data.custom"};

        for (String filename : unknownFiles) {
            Optional<MediaType> mediaType = MediaTypeFactory.getMediaType(filename);
            assertThat(mediaType)
                    .as("Should not detect type for unknown extension: " + filename)
                    .isEmpty();
        }
    }

    @Test
    void testMediaTypeFactory_EdgeCases() {
        // File without extension
        Optional<MediaType> noExtension = MediaTypeFactory.getMediaType("filename");
        assertThat(noExtension).as("Should not detect type for file without extension").isEmpty();

        // Empty filename
        Optional<MediaType> empty = MediaTypeFactory.getMediaType("");
        assertThat(empty).as("Should not detect type for empty filename").isEmpty();

        // Multiple extensions
        Optional<MediaType> multiExtension = MediaTypeFactory.getMediaType("archive.tar.gz");
        // This may or may not be detected depending on implementation
        // Just ensure it doesn't throw an exception
        assertThat(multiExtension).as("Should handle multiple extensions gracefully").isNotNull();
    }

    @Test
    void testMimeTypeUtils_Constants() {
        // Test common MIME type constants
        assertThat(MimeTypeUtils.APPLICATION_JSON.toString()).isEqualTo("application/json");
        assertThat(MimeTypeUtils.APPLICATION_XML.toString()).isEqualTo("application/xml");
        assertThat(MimeTypeUtils.TEXT_PLAIN.toString()).isEqualTo("text/plain");
        assertThat(MimeTypeUtils.TEXT_HTML.toString()).isEqualTo("text/html");
        assertThat(MimeTypeUtils.ALL.toString()).isEqualTo("*/*");
    }

    @Test
    void testMimeTypeUtils_CustomTypes() {
        // Create custom MIME types
        MimeType customType1 = MimeType.valueOf("application/custom");
        assertThat(customType1.getType()).isEqualTo("application");
        assertThat(customType1.getSubtype()).isEqualTo("custom");

        MimeType customType2 = new MimeType("text", "custom");
        assertThat(customType2.getType()).isEqualTo("text");
        assertThat(customType2.getSubtype()).isEqualTo("custom");

        // Create type with parameters
        MimeType typeWithCharset = MimeType.valueOf("application/json;charset=UTF-8");
        assertThat(typeWithCharset.getType()).isEqualTo("application");
        assertThat(typeWithCharset.getSubtype()).isEqualTo("json");
        assertThat(typeWithCharset.getParameter("charset")).isEqualTo("UTF-8");
    }

    @Test
    void testMimeTypeUtils_Compatibility() {
        MimeType jsonType = MimeTypeUtils.APPLICATION_JSON;
        MimeType textType = MimeTypeUtils.TEXT_PLAIN;
        MimeType allType = MimeTypeUtils.ALL;

        // Wildcard compatibility
        MimeType applicationWildcard = MimeType.valueOf("application/*");
        MimeType textWildcard = MimeType.valueOf("text/*");

        assertThat(jsonType.isCompatibleWith(applicationWildcard))
                .as("JSON should be compatible with application/*")
                .isTrue();
        assertThat(textType.isCompatibleWith(applicationWildcard))
                .as("Text should not be compatible with application/*")
                .isFalse();
        assertThat(textType.isCompatibleWith(textWildcard))
                .as("Text should be compatible with text/*")
                .isTrue();

        // All type compatibility
        assertThat(allType.isCompatibleWith(jsonType))
                .as("*/* should be compatible with any type")
                .isTrue();
        assertThat(jsonType.isCompatibleWith(allType))
                .as("Any type should be compatible with */*")
                .isTrue();
    }

    @Test
    void testMimeTypeUtils_Parsing() {
        // Test parsing various MIME type strings
        String[] testStrings = {"text/plain", "application/json;charset=UTF-8", "image/*", "*/*"};

        for (String typeString : testStrings) {
            MimeType parsed = MimeType.valueOf(typeString);
            assertThat(parsed).as("Should parse: " + typeString).isNotNull();
            assertThat(parsed.toString()).as("Should round-trip correctly").isEqualTo(typeString);
        }

        // Test with complex parameters
        MimeType complex = MimeType.valueOf("multipart/form-data;boundary=something;charset=UTF-8");
        assertThat(complex.getType()).isEqualTo("multipart");
        assertThat(complex.getSubtype()).isEqualTo("form-data");
        assertThat(complex.getParameter("boundary")).isEqualTo("something");
        assertThat(complex.getParameter("charset")).isEqualTo("UTF-8");
    }

    @Test
    void testDataConversionToolsDemo_ResolvableTypeDemo() {
        Map<String, Object> results = demo.demonstrateResolvableType();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify list type results
        assertThat(results.get("list_type")).as("Should have list type").isNotNull();
        assertThat(results.get("list_raw_class"))
                .as("Should show List as raw class")
                .isEqualTo("List");
        assertThat(results.get("list_generic_0"))
                .as("Should have first generic parameter")
                .isNotNull();

        // Verify map type results
        assertThat(results.get("map_type")).as("Should have map type").isNotNull();
        assertThat(results.get("map_raw_class"))
                .as("Should show Map as raw class")
                .isEqualTo("Map");
        assertThat(results.get("map_key_type")).as("Should have key type").isNotNull();
        assertThat(results.get("map_value_type")).as("Should have value type").isNotNull();

        // Verify array type results
        assertThat(results.get("array_type")).as("Should have array type").isNotNull();
        assertThat(results.get("array_component_type"))
                .as("Should have component type")
                .isNotNull();

        // Verify field type results
        assertThat(results.get("field_type")).as("Should have field type").isNotNull();
        assertThat((Integer) results.get("field_generic_count"))
                .as("Should have generics")
                .isGreaterThan(0);

        // Verify type relationships
        assertThat(results.get("list_is_collection"))
                .as("List should be Collection")
                .isEqualTo(true);
        assertThat(results.get("map_is_collection"))
                .as("Map should not be Collection")
                .isEqualTo(false);
    }

    @Test
    void testDataConversionToolsDemo_JacksonConverterDemo() {
        Map<String, Object> results = demo.demonstrateMappingJackson2HttpMessageConverter();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify converter properties
        assertThat(results.get("converter_class")).isEqualTo("MappingJackson2HttpMessageConverter");
        assertThat(results.get("supported_media_types"))
                .as("Should list supported types")
                .isNotNull();
        assertThat(results.get("supports_json")).as("Should support JSON").isEqualTo(true);
        assertThat(results.get("can_write_test_object"))
                .as("Should be able to write test object")
                .isEqualTo(true);

        // Verify ObjectMapper configuration
        assertThat(results.get("indent_output_enabled"))
                .as("Should have indent enabled")
                .isEqualTo(true);
        assertThat(results.get("dates_as_timestamps"))
                .as("Should not write dates as timestamps")
                .isEqualTo(false);

        // Verify serialization
        assertThat(results.get("sample_json_output")).as("Should have JSON output").isNotNull();
        assertThat(results.get("deserialization_successful"))
                .as("Should deserialize successfully")
                .isEqualTo(true);
    }

    @Test
    void testDataConversionToolsDemo_MediaTypeFactoryDemo() {
        Map<String, Object> results = demo.demonstrateMediaTypeFactory();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify file media type detection
        @SuppressWarnings("unchecked")
        Map<String, String> mediaTypes = (Map<String, String>) results.get("file_media_types");
        assertThat(mediaTypes).as("Should have media type mappings").isNotNull();
        assertThat(mediaTypes.containsKey("document.pdf")).as("Should test PDF files").isTrue();
        assertThat(mediaTypes.containsKey("data.json")).as("Should test JSON files").isTrue();

        // Verify detection statistics
        assertThat(results.get("total_tested")).as("Should show total tested").isNotNull();
        assertThat(results.get("detected_count")).as("Should show detection count").isNotNull();
        assertThat(results.get("detection_rate")).as("Should show detection rate").isNotNull();

        // Verify specific detections
        assertThat(results.get("pdf_detected")).as("Should detect PDF").isNotNull();
        assertThat(results.get("json_detected")).as("Should detect JSON").isNotNull();
    }

    @Test
    void testDataConversionToolsDemo_MimeTypeUtilsDemo() {
        Map<String, Object> results = demo.demonstrateMimeTypeUtils();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify standard MIME types
        assertThat(results.get("json_mime_type")).isEqualTo("application/json");
        assertThat(results.get("xml_mime_type")).isEqualTo("application/xml");
        assertThat(results.get("text_mime_type")).isEqualTo("text/plain");
        assertThat(results.get("html_mime_type")).isEqualTo("text/html");
        assertThat(results.get("all_mime_type")).isEqualTo("*/*");

        // Verify custom types
        assertThat(results.get("custom_type_1")).as("Should have custom type 1").isNotNull();
        assertThat(results.get("custom_type_2")).as("Should have custom type 2").isNotNull();

        // Verify compatibility checks
        assertThat(results.get("json_compatible_with_application_wildcard")).isEqualTo(true);
        assertThat(results.get("text_compatible_with_application_wildcard")).isEqualTo(false);
        assertThat(results.get("html_compatible_with_text_wildcard")).isEqualTo(true);
        assertThat(results.get("all_compatible_with_json")).isEqualTo(true);

        // Verify parsed types
        @SuppressWarnings("unchecked")
        Map<String, Map<String, Object>> parsedTypes =
                (Map<String, Map<String, Object>>) results.get("parsed_mime_types");
        assertThat(parsedTypes).as("Should have parsed types").isNotNull();
        assertThat(parsedTypes.containsKey("text/plain")).as("Should parse text/plain").isTrue();
        assertThat(parsedTypes.containsKey("application/json;charset=UTF-8"))
                .as("Should parse with charset")
                .isTrue();
    }

    @Test
    void testDataConversionToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("ResolvableType"))
                .as("Should contain ResolvableType results")
                .isTrue();
        assertThat(results.containsKey("MappingJackson2HttpMessageConverter"))
                .as("Should contain converter results")
                .isTrue();
        assertThat(results.containsKey("MediaTypeFactory"))
                .as("Should contain MediaTypeFactory results")
                .isTrue();
        assertThat(results.containsKey("MimeTypeUtils"))
                .as("Should contain MimeTypeUtils results")
                .isTrue();

        // Verify each section has meaningful content
        @SuppressWarnings("unchecked")
        Map<String, Object> resolvableResults = (Map<String, Object>) results.get("ResolvableType");
        assertThat(resolvableResults.get("list_type")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> converterResults =
                (Map<String, Object>) results.get("MappingJackson2HttpMessageConverter");
        assertThat(converterResults.get("converter_class")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> factoryResults = (Map<String, Object>) results.get("MediaTypeFactory");
        assertThat(factoryResults.get("file_media_types")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> utilsResults = (Map<String, Object>) results.get("MimeTypeUtils");
        assertThat(utilsResults.get("json_mime_type")).isNotNull();
    }

    @Test
    void testRealWorldDataConversionUseCases() throws Exception {
        // REST API content negotiation
        MediaType acceptJson = MediaType.APPLICATION_JSON;
        MediaType acceptXml = MediaType.APPLICATION_XML;

        assertThat(acceptJson.isCompatibleWith(MediaType.valueOf("application/*"))).isTrue();
        assertThat(acceptXml.isCompatibleWith(MediaType.valueOf("application/*"))).isTrue();

        // File upload handling
        Optional<MediaType> imageType = MediaTypeFactory.getMediaType("profile.jpg");
        assertThat(imageType).isPresent();
        assertThat(imageType.get().toString()).isEqualTo("image/jpeg");

        // Generic type safety in repositories
        ResolvableType userListType = ResolvableType.forClassWithGenerics(List.class, String.class);
        assertThat(userListType.getRawClass()).isEqualTo(List.class);
        assertThat(userListType.getGeneric(0).getRawClass()).isEqualTo(String.class);

        // JSON serialization configuration
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.INDENT_OUTPUT, true);

        MappingJackson2HttpMessageConverter converter =
                new MappingJackson2HttpMessageConverter(mapper);
        assertThat(converter.canWrite(Map.class, MediaType.APPLICATION_JSON)).isTrue();

        Map<String, Object> testData = Map.of("key", "value", "number", 42);
        String json = converter.getObjectMapper().writeValueAsString(testData);
        assertThat(json.contains("key")).isTrue();
        assertThat(json.contains("value")).isTrue();
    }
}
