package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.util.DigestUtils;

/**
 * Unit tests demonstrating usage of Spring's Security utilities. These tests show practical
 * examples of how to use: - DigestUtils: Message digest (hashing) utilities - Base64: Base64
 * encoding/decoding (Java standard) - TextEncryptor: Text encryption/decryption utilities
 */
class SecurityToolsDemoTest {

    private SecurityToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new SecurityToolsDemo();
    }

    @Test
    void testDigestUtils_MD5Hashing() {
        String input = "Hello, World!";

        // Test MD5 hashing
        String md5Hash = DigestUtils.md5DigestAsHex(input.getBytes(StandardCharsets.UTF_8));

        assertThat(md5Hash).isNotNull();
        assertThat(md5Hash).hasSize(32);
        assertThat(md5Hash).matches("[a-f0-9]+");

        // Same input should produce same hash
        String secondHash = DigestUtils.md5DigestAsHex(input.getBytes(StandardCharsets.UTF_8));
        assertThat(secondHash).isEqualTo(md5Hash);

        // Different input should produce different hash
        String differentHash =
                DigestUtils.md5DigestAsHex("Different input".getBytes(StandardCharsets.UTF_8));
        assertThat(differentHash).isNotEqualTo(md5Hash);
    }

    @Test
    void testDigestUtils_PasswordHashing() {
        String password = "mySecurePassword123!";

        // Hash the password
        String hashedPassword =
                DigestUtils.md5DigestAsHex(password.getBytes(StandardCharsets.UTF_8));

        assertThat(hashedPassword).isNotNull();
        assertThat(hashedPassword).isNotEqualTo(password);

        // Verify password by hashing again
        String verificationHash =
                DigestUtils.md5DigestAsHex(password.getBytes(StandardCharsets.UTF_8));
        assertThat(verificationHash).isEqualTo(hashedPassword);
    }

    @Test
    void testDigestUtils_DataIntegrity() {
        String data = "Important data that needs integrity checking";

        // Create checksum
        String checksum = DigestUtils.md5DigestAsHex(data.getBytes(StandardCharsets.UTF_8));

        // Simulate data transmission/storage
        String receivedData =
                new String(data); // In real scenario, this might come from network/file
        String receivedChecksum =
                DigestUtils.md5DigestAsHex(receivedData.getBytes(StandardCharsets.UTF_8));

        assertThat(receivedChecksum).isEqualTo(checksum);

        // Test with corrupted data
        String corruptedData = data + "corrupted";
        String corruptedChecksum =
                DigestUtils.md5DigestAsHex(corruptedData.getBytes(StandardCharsets.UTF_8));

        assertThat(corruptedChecksum).isNotEqualTo(checksum);
    }

    @Test
    void testBase64_BasicEncoding() {
        String originalText = "Hello, World! This is a test message.";

        // Encode to Base64
        String encoded =
                Base64.getEncoder().encodeToString(originalText.getBytes(StandardCharsets.UTF_8));

        assertThat(encoded).isNotNull();
        assertThat(encoded).isNotEqualTo(originalText);
        assertThat(encoded).matches("[A-Za-z0-9+/=]+");

        // Decode from Base64
        byte[] decodedBytes = Base64.getDecoder().decode(encoded);
        String decodedText = new String(decodedBytes, StandardCharsets.UTF_8);

        assertThat(decodedText).isEqualTo(originalText);
    }

    @Test
    void testBase64_URLSafeEncoding() {
        String originalText = "URL safe encoding test with special characters: +/=";

        // URL-safe encoding
        String urlSafeEncoded =
                Base64.getUrlEncoder()
                        .encodeToString(originalText.getBytes(StandardCharsets.UTF_8));

        assertThat(urlSafeEncoded).isNotNull();
        assertThat(urlSafeEncoded).doesNotContain("+");
        assertThat(urlSafeEncoded).doesNotContain("/");

        // Decode URL-safe encoding
        byte[] urlSafeDecoded = Base64.getUrlDecoder().decode(urlSafeEncoded);
        String urlSafeDecodedText = new String(urlSafeDecoded, StandardCharsets.UTF_8);

        assertThat(urlSafeDecodedText).isEqualTo(originalText);
    }

    @Test
    void testBase64_BinaryData() {
        // Test with binary data
        byte[] binaryData = {0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x00, 0x57, 0x6F, 0x72, 0x6C, 0x64};

        // Encode binary data
        String encoded = Base64.getEncoder().encodeToString(binaryData);
        assertThat(encoded).isNotNull();

        // Decode and verify
        byte[] decoded = Base64.getDecoder().decode(encoded);
        assertThat(decoded).isEqualTo(binaryData);
    }

    @Test
    void testTextEncryptor_BasicEncryption() {
        String password = "myEncryptionPassword";
        String salt = "deadbeef";
        String originalMessage = "This is a secret message!";

        // Create TextEncryptor
        TextEncryptor encryptor = Encryptors.text(password, salt);

        // Encrypt the message
        String encryptedText = encryptor.encrypt(originalMessage);

        assertThat(encryptedText).isNotNull();
        assertThat(encryptedText).isNotEqualTo(originalMessage);

        // Decrypt the message
        String decryptedText = encryptor.decrypt(encryptedText);

        assertThat(decryptedText).isEqualTo(originalMessage);
    }

    @Test
    void testTextEncryptor_DifferentMessages() {
        String password = "encryptionKey";
        String salt = "12345678";

        TextEncryptor encryptor = Encryptors.text(password, salt);

        String message1 = "First secret message";
        String message2 = "Second secret message";

        String encrypted1 = encryptor.encrypt(message1);
        String encrypted2 = encryptor.encrypt(message2);

        // Different messages should produce different encrypted text
        assertThat(encrypted2).isNotEqualTo(encrypted1);

        // Decrypt and verify
        assertThat(encryptor.decrypt(encrypted1)).isEqualTo(message1);
        assertThat(encryptor.decrypt(encrypted2)).isEqualTo(message2);
    }

    @Test
    void testTextEncryptor_WrongPassword() {
        String correctPassword = "correct_password";
        String wrongPassword = "wrong_password";
        String salt = "abcdef12";
        String message = "Secret message";

        TextEncryptor correctEncryptor = Encryptors.text(correctPassword, salt);
        TextEncryptor wrongEncryptor = Encryptors.text(wrongPassword, salt);

        // Encrypt with correct password
        String encrypted = correctEncryptor.encrypt(message);

        // Try to decrypt with wrong password should fail
        assertThatThrownBy(() -> wrongEncryptor.decrypt(encrypted)).isInstanceOf(Exception.class);
    }

    @Test
    void testTextEncryptor_EmptyAndSpecialMessages() {
        String password = "testPassword";
        String salt = "deadbeef";

        TextEncryptor encryptor = Encryptors.text(password, salt);

        // Test empty string
        String emptyMessage = "";
        String encryptedEmpty = encryptor.encrypt(emptyMessage);
        String decryptedEmpty = encryptor.decrypt(encryptedEmpty);
        assertThat(decryptedEmpty).isEqualTo(emptyMessage);

        // Test special characters
        String specialMessage = "Special chars: !@#$%^&*()_+{}|:<>?[];'\".,/~`";
        String encryptedSpecial = encryptor.encrypt(specialMessage);
        String decryptedSpecial = encryptor.decrypt(encryptedSpecial);
        assertThat(decryptedSpecial).isEqualTo(specialMessage);

        // Test unicode
        String unicodeMessage = "Unicode test: 你好世界 🌍 ñoño";
        String encryptedUnicode = encryptor.encrypt(unicodeMessage);
        String decryptedUnicode = encryptor.decrypt(encryptedUnicode);
        assertThat(decryptedUnicode).isEqualTo(unicodeMessage);
    }

    @Test
    void testSecurityToolsDemo_Integration() {
        // Test the complete demonstration
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).isNotNull();
        assertThat(results).containsKey("DigestUtils");
        assertThat(results).containsKey("Base64Utils");
        assertThat(results).containsKey("TextEncryptor");
        assertThat(results).containsKey("PasswordHashing");

        // Verify DigestUtils results
        @SuppressWarnings("unchecked")
        Map<String, Object> digestResults = (Map<String, Object>) results.get("DigestUtils");
        assertThat(digestResults.get("md5_password_hash")).isNotNull();
        assertThat(digestResults.get("hash_algorithm")).isEqualTo("MD5");

        // Verify Base64 results
        @SuppressWarnings("unchecked")
        Map<String, Object> base64Results = (Map<String, Object>) results.get("Base64Utils");
        assertThat((Boolean) base64Results.get("encoding_successful")).isTrue();

        // Verify TextEncryptor results
        @SuppressWarnings("unchecked")
        Map<String, Object> encryptorResults = (Map<String, Object>) results.get("TextEncryptor");
        assertThat((Boolean) encryptorResults.get("encryption_successful")).isTrue();
    }

    @Test
    void testRealWorldSecurityUseCases() {
        // Password storage scenario
        String userPassword = "user123password!";
        String hashedPassword =
                DigestUtils.md5DigestAsHex(userPassword.getBytes(StandardCharsets.UTF_8));

        // Store hashedPassword in database instead of plain text
        assertThat(hashedPassword).isNotEqualTo(userPassword);

        // Password verification
        String loginAttempt = "user123password!";
        String loginHash =
                DigestUtils.md5DigestAsHex(loginAttempt.getBytes(StandardCharsets.UTF_8));
        assertThat(loginHash).isEqualTo(hashedPassword);

        // API token encoding/decoding
        String apiToken = "api_key_12345_secret_token";
        String encodedToken =
                Base64.getEncoder().encodeToString(apiToken.getBytes(StandardCharsets.UTF_8));

        // Token can be safely transmitted
        assertThat(encodedToken).doesNotContain("secret");

        // Token can be decoded when needed
        String decodedToken =
                new String(Base64.getDecoder().decode(encodedToken), StandardCharsets.UTF_8);
        assertThat(decodedToken).isEqualTo(apiToken);

        // Sensitive data encryption
        String sensitiveData = "Credit Card: 1234-5678-9012-3456";
        TextEncryptor dataEncryptor = Encryptors.text("dataEncryptionKey", "deadbeef");

        String encryptedData = dataEncryptor.encrypt(sensitiveData);
        assertThat(encryptedData).doesNotContain("1234-5678");

        String decryptedData = dataEncryptor.decrypt(encryptedData);
        assertThat(decryptedData).isEqualTo(sensitiveData);
    }

    @Test
    void testSecurityBestPractices() {
        // Demonstrate why MD5 is not recommended for passwords in production
        String commonPassword = "password123";
        String md5Hash =
                DigestUtils.md5DigestAsHex(commonPassword.getBytes(StandardCharsets.UTF_8));

        // MD5 is fast, which makes it vulnerable to rainbow table attacks
        assertThat(md5Hash).isNotNull();

        // Note: In production, use BCrypt, SCrypt, or Argon2
        // Example: BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        // String secureHash = encoder.encode(commonPassword);

        // Demonstrate salt importance
        String password = "samepassword";
        String salt1 = "deadbeef";
        String salt2 = "feedface";

        TextEncryptor encryptor1 = Encryptors.text(password, salt1);
        TextEncryptor encryptor2 = Encryptors.text(password, salt2);

        String message = "same message";
        String encrypted1 = encryptor1.encrypt(message);
        String encrypted2 = encryptor2.encrypt(message);

        // Different salts produce different encrypted results even with same password and message
        assertThat(encrypted2).isNotEqualTo(encrypted1);

        // Each can only decrypt its own encryption
        assertThat(encryptor1.decrypt(encrypted1)).isEqualTo(message);
        assertThat(encryptor2.decrypt(encrypted2)).isEqualTo(message);

        assertThatThrownBy(() -> encryptor1.decrypt(encrypted2)).isInstanceOf(Exception.class);
    }
}
