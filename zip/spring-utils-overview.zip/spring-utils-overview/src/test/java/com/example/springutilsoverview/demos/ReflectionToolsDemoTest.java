package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.util.ClassUtils;
import org.springframework.util.MethodInvoker;
import org.springframework.util.ReflectionUtils;

/**
 * Unit tests demonstrating usage of Spring's Reflection utilities. These tests show practical
 * examples of how to use: - ReflectionUtils: Field and method reflection operations - ClassUtils:
 * Class-related utility functions - MethodInvoker: Dynamic method invocation utility - BeanUtils:
 * Bean property copying and instantiation
 */
class ReflectionToolsDemoTest {

    private ReflectionToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new ReflectionToolsDemo();
    }

    @Test
    void testReflectionUtils_FieldOperations() throws Exception {
        ReflectionToolsDemo.SampleBean sample = new ReflectionToolsDemo.SampleBean("Test Name", 30);

        // Find field
        Field nameField = ReflectionUtils.findField(ReflectionToolsDemo.SampleBean.class, "name");
        assertThat(nameField).isNotNull();
        assertThat(nameField.getName()).isEqualTo("name");

        // Make accessible and get value
        ReflectionUtils.makeAccessible(nameField);
        String originalValue = (String) ReflectionUtils.getField(nameField, sample);
        assertThat(originalValue).isEqualTo("Test Name");

        // Set new value
        ReflectionUtils.setField(nameField, sample, "New Name");
        String newValue = (String) ReflectionUtils.getField(nameField, sample);
        assertThat(newValue).isEqualTo("New Name");

        // Test non-existent field
        Field nonExistent =
                ReflectionUtils.findField(ReflectionToolsDemo.SampleBean.class, "nonExistentField");
        assertThat(nonExistent).isNull();
    }

    @Test
    void testReflectionUtils_MethodOperations() throws Exception {
        ReflectionToolsDemo.SampleBean sample = new ReflectionToolsDemo.SampleBean("Test", 25);

        // Find method
        Method setAgeMethod =
                ReflectionUtils.findMethod(
                        ReflectionToolsDemo.SampleBean.class, "setAge", int.class);
        assertThat(setAgeMethod).isNotNull();
        assertThat(setAgeMethod.getName()).isEqualTo("setAge");

        // Invoke method
        int originalAge = sample.getAge();
        ReflectionUtils.invokeMethod(setAgeMethod, sample, 35);
        int newAge = sample.getAge();

        assertThat(originalAge).isEqualTo(25);
        assertThat(newAge).isEqualTo(35);

        // Test method without parameters
        Method getNameMethod =
                ReflectionUtils.findMethod(ReflectionToolsDemo.SampleBean.class, "getName");
        assertThat(getNameMethod).isNotNull();
        String name = (String) ReflectionUtils.invokeMethod(getNameMethod, sample);
        assertThat(name).isEqualTo("Test");

        // Test non-existent method
        Method nonExistent =
                ReflectionUtils.findMethod(
                        ReflectionToolsDemo.SampleBean.class, "nonExistentMethod");
        assertThat(nonExistent).isNull();
    }

    @Test
    void testReflectionUtils_CallbackOperations() {
        ReflectionToolsDemo.SampleBean sample = new ReflectionToolsDemo.SampleBean("Test", 30);

        // Test field callback
        final int[] fieldCount = {0};
        ReflectionUtils.doWithFields(
                ReflectionToolsDemo.SampleBean.class,
                field -> {
                    fieldCount[0]++;
                    assertThat(field.getName()).isNotNull();
                });

        assertThat(fieldCount[0]).isGreaterThanOrEqualTo(2);

        // Test method callback
        final int[] methodCount = {0};
        ReflectionUtils.doWithMethods(
                ReflectionToolsDemo.SampleBean.class,
                method -> {
                    methodCount[0]++;
                    assertThat(method.getName()).isNotNull();
                });

        assertThat(methodCount[0]).isPositive();
    }

    @Test
    void testClassUtils_BasicOperations() {
        // Test short name extraction for inner class (includes outer class name)
        String shortName = ClassUtils.getShortName(ReflectionToolsDemo.SampleBean.class);
        assertThat(shortName).isEqualTo("ReflectionToolsDemo.SampleBean");

        String shortNameFromString = ClassUtils.getShortName("java.lang.String");
        assertThat(shortNameFromString).isEqualTo("String");

        // Test with top-level class
        String topLevelShortName = ClassUtils.getShortName(ReflectionToolsDemo.class);
        assertThat(topLevelShortName).isEqualTo("ReflectionToolsDemo");

        // Test with array (the actual output format may vary)
        String arrayShortName = ClassUtils.getShortName("[Ljava.lang.String;");
        assertThat(arrayShortName).contains("String");
    }

    @Test
    void testClassUtils_ClassPresenceChecking() {
        // Test existing classes
        assertThat(ClassUtils.isPresent("java.lang.String", null)).isTrue();
        assertThat(ClassUtils.isPresent("java.util.HashMap", null)).isTrue();
        assertThat(ClassUtils.isPresent("org.springframework.util.ClassUtils", null)).isTrue();

        // Test non-existent classes
        assertThat(ClassUtils.isPresent("com.fake.NonExistentClass", null)).isFalse();
        assertThat(ClassUtils.isPresent("com.example.MissingClass", null)).isFalse();
    }

    @Test
    void testClassUtils_PackageOperations() {
        // Test package name extraction
        String packageName = ClassUtils.getPackageName(ReflectionToolsDemo.SampleBean.class);
        assertThat(packageName).isEqualTo("com.example.springutilsoverview.demos");

        String stringPackage = ClassUtils.getPackageName(String.class);
        assertThat(stringPackage).isEqualTo("java.lang");

        // Test with qualified name
        String qualifiedName = ClassUtils.getQualifiedName(ReflectionToolsDemo.SampleBean.class);
        assertThat(qualifiedName).contains("com.example.springutilsoverview.demos");
        assertThat(qualifiedName).contains("SampleBean");
    }

    @Test
    void testClassUtils_ClassLoader() {
        ClassLoader classLoader = ClassUtils.getDefaultClassLoader();
        assertThat(classLoader).isNotNull();

        // Test class loading
        try {
            Class<?> stringClass = ClassUtils.forName("java.lang.String", classLoader);
            assertThat(stringClass).isEqualTo(String.class);
        } catch (Exception e) {
            fail("Should be able to load String class: " + e.getMessage());
        }
    }

    @Test
    void testMethodInvoker_BasicInvocation() throws Exception {
        ReflectionToolsDemo.CalculatorService calculator =
                new ReflectionToolsDemo.CalculatorService();

        MethodInvoker invoker = new MethodInvoker();
        invoker.setTargetObject(calculator);
        invoker.setTargetMethod("add");
        invoker.setArguments(10, 20);
        invoker.prepare();

        Object result = invoker.invoke();
        assertThat(result).isEqualTo(30);

        // Test multiplication
        MethodInvoker multiplyInvoker = new MethodInvoker();
        multiplyInvoker.setTargetObject(calculator);
        multiplyInvoker.setTargetMethod("multiply");
        multiplyInvoker.setArguments(5, 6);
        multiplyInvoker.prepare();

        Object multiplyResult = multiplyInvoker.invoke();
        assertThat(multiplyResult).isEqualTo(30);
    }

    @Test
    void testMethodInvoker_StaticMethod() throws Exception {
        // Test invoking static method
        MethodInvoker invoker = new MethodInvoker();
        invoker.setTargetClass(String.class);
        invoker.setTargetMethod("valueOf");
        invoker.setArguments(42);
        invoker.prepare();

        Object result = invoker.invoke();
        assertThat(result).isEqualTo("42");
    }

    @Test
    void testMethodInvoker_ErrorHandling() {
        // Test with non-existent method
        MethodInvoker invoker = new MethodInvoker();
        invoker.setTargetClass(String.class);
        invoker.setTargetMethod("nonExistentMethod");

        assertThatThrownBy(invoker::prepare).isInstanceOf(Exception.class);
    }

    @Test
    void testBeanUtils_PropertyCopying() {
        ReflectionToolsDemo.SampleBean source = new ReflectionToolsDemo.SampleBean("John Doe", 25);
        ReflectionToolsDemo.SampleBeanDTO target = new ReflectionToolsDemo.SampleBeanDTO();

        // Initially target should be empty
        assertThat(target.getName()).isNull();
        assertThat(target.getAge()).isZero();

        // Copy properties
        BeanUtils.copyProperties(source, target);

        // Verify copy
        assertThat(target.getName()).isEqualTo("John Doe");
        assertThat(target.getAge()).isEqualTo(25);
    }

    @Test
    void testBeanUtils_ClassInstantiation() {
        // Test instantiation with default constructor
        ReflectionToolsDemo.SampleBean instance =
                BeanUtils.instantiateClass(ReflectionToolsDemo.SampleBean.class);
        assertThat(instance).isNotNull();
        assertThat(instance.getName()).isNull();
        assertThat(instance.getAge()).isZero();

        // Test with DTO class
        ReflectionToolsDemo.SampleBeanDTO dtoInstance =
                BeanUtils.instantiateClass(ReflectionToolsDemo.SampleBeanDTO.class);
        assertThat(dtoInstance).isNotNull();
    }

    @Test
    void testBeanUtils_ConstructorWithArgs() throws Exception {
        // Test instantiation with constructor arguments
        ReflectionToolsDemo.SampleBean instance =
                BeanUtils.instantiateClass(
                        ReflectionToolsDemo.SampleBean.class.getConstructor(
                                String.class, int.class),
                        "Test Name",
                        30);

        assertThat(instance).isNotNull();
        assertThat(instance.getName()).isEqualTo("Test Name");
        assertThat(instance.getAge()).isEqualTo(30);
    }

    @Test
    void testReflectionToolsDemo_ReflectionUtilsDemo() {
        Map<String, Object> results = demo.demonstrateReflectionUtils();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify field operations
        assertThat(results.get("field_original_name")).isEqualTo("Initial Name");
        assertThat(results.get("field_modified_name")).isEqualTo("Modified Name");

        // Verify method operations
        assertThat(results.get("method_original_age")).isEqualTo(25);
        assertThat(results.get("method_modified_age")).isEqualTo(30);

        // Verify final state
        assertThat(results.get("sample_object_final_state")).isNotNull();
        String finalState = (String) results.get("sample_object_final_state");
        assertThat(finalState).contains("Modified Name");
        assertThat(finalState).contains("30");
    }

    @Test
    void testReflectionToolsDemo_ClassUtilsDemo() {
        Map<String, Object> results = demo.demonstrateClassUtils();

        assertThat(results).isNotNull();

        // Verify class name operations
        assertThat(results.get("short_name")).isEqualTo("ReflectionToolsDemo.SampleBean");
        assertThat(results.get("short_name_from_string")).isEqualTo("String");

        // Verify class existence checks
        assertThat(results.get("string_exists")).isEqualTo(true);
        assertThat(results.get("fake_class_exists")).isEqualTo(false);

        // Verify package information
        assertThat(results.get("class_loader")).isNotNull();
        assertThat(results.get("package_name")).isEqualTo("com.example.springutilsoverview.demos");
    }

    @Test
    void testReflectionToolsDemo_MethodInvokerDemo() {
        Map<String, Object> results = demo.demonstrateMethodInvoker();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify method invocation results
        assertThat(results.get("calculation_result")).isEqualTo(30);
        assertThat(results.get("method_name")).isEqualTo("add");
        assertThat(results.get("arguments")).isNotNull();
    }

    @Test
    void testReflectionToolsDemo_BeanUtilsDemo() {
        Map<String, Object> results = demo.demonstrateBeanUtils();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify bean operations
        assertThat(results.get("source_object")).isNotNull();
        assertThat(results.get("target_object_after_copy")).isNotNull();
        assertThat(results.get("new_instance")).isNotNull();
        assertThat(results.get("properties_copied")).isEqualTo(true);

        // Verify object states
        String sourceObject = (String) results.get("source_object");
        String targetObject = (String) results.get("target_object_after_copy");
        String newInstance = (String) results.get("new_instance");

        assertThat(sourceObject).contains("John Doe");
        assertThat(targetObject).contains("John Doe");
        assertThat(newInstance).contains("null");
    }

    @Test
    void testReflectionToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).isNotNull();
        assertThat(results).containsKey("ReflectionUtils");
        assertThat(results).containsKey("ClassUtils");
        assertThat(results).containsKey("MethodInvoker");
        assertThat(results).containsKey("BeanUtils");

        // Verify each section has expected content
        @SuppressWarnings("unchecked")
        Map<String, Object> reflectionResults =
                (Map<String, Object>) results.get("ReflectionUtils");
        assertThat(reflectionResults.get("field_original_name")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> classResults = (Map<String, Object>) results.get("ClassUtils");
        assertThat(classResults.get("short_name")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> invokerResults = (Map<String, Object>) results.get("MethodInvoker");
        assertThat(invokerResults.get("calculation_result")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> beanResults = (Map<String, Object>) results.get("BeanUtils");
        assertThat(beanResults.get("source_object")).isNotNull();
    }

    @Test
    void testRealWorldReflectionUseCases() throws Exception {
        // Framework-style property injection
        ReflectionToolsDemo.SampleBean bean = new ReflectionToolsDemo.SampleBean();
        Field nameField = ReflectionUtils.findField(ReflectionToolsDemo.SampleBean.class, "name");
        assertThat(nameField).isNotNull();

        ReflectionUtils.makeAccessible(nameField);
        ReflectionUtils.setField(nameField, bean, "Injected Value");
        assertThat(bean.getName()).isEqualTo("Injected Value");

        // Dynamic method calling for REST endpoints
        ReflectionToolsDemo.CalculatorService service = new ReflectionToolsDemo.CalculatorService();
        Method addMethod =
                ReflectionUtils.findMethod(
                        ReflectionToolsDemo.CalculatorService.class, "add", int.class, int.class);
        assertThat(addMethod).isNotNull();

        Object result = ReflectionUtils.invokeMethod(addMethod, service, 15, 25);
        assertThat(result).isEqualTo(40);

        // Bean mapping for DTOs
        ReflectionToolsDemo.SampleBean source = new ReflectionToolsDemo.SampleBean("API User", 28);
        ReflectionToolsDemo.SampleBeanDTO dto = new ReflectionToolsDemo.SampleBeanDTO();

        BeanUtils.copyProperties(source, dto);
        assertThat(dto.getName()).isEqualTo("API User");
        assertThat(dto.getAge()).isEqualTo(28);

        // Class loading and instantiation
        assertThat(ClassUtils.isPresent("java.util.ArrayList", null)).isTrue();

        ReflectionToolsDemo.SampleBean dynamicInstance =
                BeanUtils.instantiateClass(ReflectionToolsDemo.SampleBean.class);
        assertThat(dynamicInstance).isNotNull();

        // Package scanning simulation
        String packageName = ClassUtils.getPackageName(ReflectionToolsDemo.SampleBean.class);
        assertThat(packageName).isEqualTo("com.example.springutilsoverview.demos");
    }
}
