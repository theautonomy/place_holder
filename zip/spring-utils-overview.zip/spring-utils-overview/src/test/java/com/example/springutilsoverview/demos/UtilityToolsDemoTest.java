package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.Assert;
import org.springframework.util.NumberUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Unit tests demonstrating usage of Spring's general utility tools. These tests show practical
 * examples of how to use: - Assert: Design by contract assertions - ObjectUtils: Object
 * manipulation utilities - NumberUtils: Number parsing and conversion - StopWatch: Performance
 * timing utilities - AnnotationUtils: Annotation introspection utilities - CompletableFuture:
 * Asynchronous programming utilities
 */
class UtilityToolsDemoTest {

    private UtilityToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new UtilityToolsDemo();
    }

    @Test
    void testAssert_NotNull() {
        // Test successful assertions
        assertThatCode(() -> Assert.notNull("not null", "Should not throw"))
                .doesNotThrowAnyException();
        assertThatCode(() -> Assert.notNull(new Object(), "Should not throw"))
                .doesNotThrowAnyException();

        // Test assertion failures
        assertThatThrownBy(() -> Assert.notNull(null, "Object must not be null"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Object must not be null");
    }

    @Test
    void testAssert_HasText() {
        // Test successful assertions
        assertThatCode(() -> Assert.hasText("hello", "Should not throw"))
                .doesNotThrowAnyException();
        assertThatCode(() -> Assert.hasText("  hello  ", "Should not throw"))
                .doesNotThrowAnyException();

        // Test assertion failures
        assertThatThrownBy(() -> Assert.hasText(null, "Text must not be null"))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Assert.hasText("", "Text must not be empty"))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Assert.hasText("   ", "Text must not be whitespace only"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testAssert_IsTrue() {
        // Test successful assertions
        assertThatCode(() -> Assert.isTrue(true, "Should not throw")).doesNotThrowAnyException();
        assertThatCode(() -> Assert.isTrue(5 > 3, "Should not throw")).doesNotThrowAnyException();

        // Test assertion failures
        assertThatThrownBy(() -> Assert.isTrue(false, "Condition must be true"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("Condition must be true");
    }

    @Test
    void testAssert_NotEmpty() {
        // Test with collections
        assertThatCode(() -> Assert.notEmpty(Arrays.asList("item"), "Should not throw"))
                .doesNotThrowAnyException();

        assertThatThrownBy(
                        () -> Assert.notEmpty((Collection<?>) null, "Collection must not be null"))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(
                        () ->
                                Assert.notEmpty(
                                        Collections.emptyList(), "Collection must not be empty"))
                .isInstanceOf(IllegalArgumentException.class);

        // Test with arrays
        assertThatCode(() -> Assert.notEmpty(new String[] {"item"}, "Should not throw"))
                .doesNotThrowAnyException();

        assertThatThrownBy(() -> Assert.notEmpty((Object[]) null, "Array must not be null"))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Assert.notEmpty(new String[0], "Array must not be empty"))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testObjectUtils_NullSafeOperations() {
        // Test null-safe equals
        assertThat(ObjectUtils.nullSafeEquals(null, null)).as("null should equal null").isTrue();
        assertThat(ObjectUtils.nullSafeEquals(null, "not null"))
                .as("null should not equal non-null")
                .isFalse();
        assertThat(ObjectUtils.nullSafeEquals("not null", null))
                .as("non-null should not equal null")
                .isFalse();
        assertThat(ObjectUtils.nullSafeEquals("same", "same"))
                .as("same strings should be equal")
                .isTrue();

        // Test null-safe hashCode
        assertThat(ObjectUtils.nullSafeHashCode((Object) null))
                .as("null should have hashCode 0")
                .isEqualTo(0);
        assertThat(ObjectUtils.nullSafeHashCode("test"))
                .as("non-null should have normal hashCode")
                .isEqualTo("test".hashCode());

        // Test null-safe toString
        assertThat(ObjectUtils.nullSafeToString((Object) null))
                .as("null should toString to 'null'")
                .isEqualTo("null");
        assertThat(ObjectUtils.nullSafeToString("test"))
                .as("non-null should toString normally")
                .isEqualTo("test");
    }

    @Test
    void testObjectUtils_ArrayOperations() {
        // Test array isEmpty
        assertThat(ObjectUtils.isEmpty((Object[]) null)).as("null array should be empty").isTrue();
        assertThat(ObjectUtils.isEmpty(new Object[0]))
                .as("zero-length array should be empty")
                .isTrue();
        assertThat(ObjectUtils.isEmpty(new Object[] {"item"}))
                .as("array with items should not be empty")
                .isFalse();

        // Test array contains
        Object[] array = {"apple", "banana", "cherry"};
        assertThat(ObjectUtils.containsElement(array, "banana"))
                .as("Should contain banana")
                .isTrue();
        assertThat(ObjectUtils.containsElement(array, "grape"))
                .as("Should not contain grape")
                .isFalse();
        assertThat(ObjectUtils.containsElement(null, "anything"))
                .as("null array contains nothing")
                .isFalse();
    }

    @Test
    void testObjectUtils_IdentityOperations() {
        String str1 = new String("test");
        String str2 = new String("test");
        String str3 = str1;

        // Test identity toString (shows object identity, not content)
        String identity1 = ObjectUtils.identityToString(str1);
        String identity2 = ObjectUtils.identityToString(str2);
        String identity3 = ObjectUtils.identityToString(str3);

        assertThat(identity1).as("Identity string should not be null").isNotNull();
        assertThat(identity1).as("Identity string should contain class name").contains("String@");
        assertThat(identity1)
                .as("Different objects should have different identity strings")
                .isNotEqualTo(identity2);
        assertThat(identity1)
                .as("Same object should have same identity string")
                .isEqualTo(identity3);
    }

    @Test
    void testNumberUtils_ParseOperations() {
        // Test parseNumber with different types
        Integer intValue = NumberUtils.parseNumber("42", Integer.class);
        assertThat(intValue).as("Should parse integer correctly").isEqualTo(42);

        Long longValue = NumberUtils.parseNumber("1234567890", Long.class);
        assertThat(longValue).as("Should parse long correctly").isEqualTo(1234567890L);

        Double doubleValue = NumberUtils.parseNumber("3.14159", Double.class);
        assertThat(doubleValue)
                .as("Should parse double correctly")
                .isCloseTo(3.14159, within(0.00001));

        Float floatValue = NumberUtils.parseNumber("2.718", Float.class);
        assertThat(floatValue).as("Should parse float correctly").isCloseTo(2.718f, within(0.001f));
    }

    @Test
    void testNumberUtils_ParseErrors() {
        // Test invalid number formats
        assertThatThrownBy(() -> NumberUtils.parseNumber("not a number", Integer.class))
                .isInstanceOf(NumberFormatException.class);

        assertThatThrownBy(() -> NumberUtils.parseNumber("3.14", Integer.class))
                .as("Should fail parsing float as int")
                .isInstanceOf(NumberFormatException.class);

        // Note: NumberUtils.parseNumber only works with Number subclasses
        assertThatThrownBy(() -> NumberUtils.parseNumber("invalid", Integer.class))
                .as("Should fail with invalid number")
                .isInstanceOf(NumberFormatException.class);
    }

    @Test
    void testNumberUtils_ConversionOperations() {
        // Test convertNumberToTargetClass
        Integer intValue = 42;

        Long longResult = NumberUtils.convertNumberToTargetClass(intValue, Long.class);
        assertThat(longResult).as("Should convert int to long").isEqualTo(42L);

        Double doubleResult = NumberUtils.convertNumberToTargetClass(intValue, Double.class);
        assertThat(doubleResult).as("Should convert int to double").isCloseTo(42.0, within(0.001));

        // Note: NumberUtils.convertNumberToTargetClass only works with Number subclasses
        Float floatResult = NumberUtils.convertNumberToTargetClass(intValue, Float.class);
        assertThat(floatResult).as("Should convert int to float").isCloseTo(42.0f, within(0.001f));
    }

    @Test
    void testStopWatch_BasicTiming() throws InterruptedException {
        StopWatch stopWatch = new StopWatch("Test Timer");

        assertThat(stopWatch.isRunning()).as("StopWatch should not be running initially").isFalse();
        assertThat(stopWatch.getTotalTimeMillis()).as("Initial time should be 0").isEqualTo(0);

        // Start timing
        stopWatch.start("Task 1");
        assertThat(stopWatch.isRunning()).as("StopWatch should be running after start").isTrue();

        // Simulate work
        Thread.sleep(10);

        // Stop timing
        stopWatch.stop();
        assertThat(stopWatch.isRunning())
                .as("StopWatch should not be running after stop")
                .isFalse();

        long totalTime = stopWatch.getTotalTimeMillis();
        assertThat(totalTime).as("Total time should be at least 10ms").isGreaterThanOrEqualTo(10);

        assertThat(stopWatch.getTaskCount()).as("Should have 1 task").isEqualTo(1);
    }

    @Test
    void testStopWatch_MultipleTasks() throws InterruptedException {
        StopWatch stopWatch = new StopWatch("Multi-Task Timer");

        // First task
        stopWatch.start("Database Query");
        Thread.sleep(5);
        stopWatch.stop();

        // Second task
        stopWatch.start("Data Processing");
        Thread.sleep(10);
        stopWatch.stop();

        // Third task
        stopWatch.start("Response Generation");
        Thread.sleep(3);
        stopWatch.stop();

        assertThat(stopWatch.getTaskCount()).as("Should have 3 tasks").isEqualTo(3);
        assertThat(stopWatch.getTotalTimeMillis())
                .as("Total time should be at least 18ms")
                .isGreaterThanOrEqualTo(18);

        // Test task info
        StopWatch.TaskInfo[] taskInfos = stopWatch.getTaskInfo();
        assertThat(taskInfos).as("Should have 3 task infos").hasSize(3);
        assertThat(taskInfos[0].getTaskName()).isEqualTo("Database Query");
        assertThat(taskInfos[1].getTaskName()).isEqualTo("Data Processing");
        assertThat(taskInfos[2].getTaskName()).isEqualTo("Response Generation");

        // Test pretty print (should not throw exception)
        String prettyPrint = stopWatch.prettyPrint();
        assertThat(prettyPrint).as("Pretty print should not be null").isNotNull();
        assertThat(prettyPrint)
                .as("Pretty print should contain task names")
                .contains("Database Query");
    }

    @Test
    void testAnnotationUtils_FindAnnotation() {
        // Test finding annotation on class
        RequestMapping classAnnotation =
                AnnotationUtils.findAnnotation(TestController.class, RequestMapping.class);

        assertThat(classAnnotation).as("Should find RequestMapping on TestController").isNotNull();
        assertThat(classAnnotation.value()[0])
                .as("Should have correct mapping value")
                .isEqualTo("/test");

        // Test finding annotation on method
        try {
            var method = TestController.class.getMethod("testMethod");
            RequestMapping methodAnnotation =
                    AnnotationUtils.findAnnotation(method, RequestMapping.class);

            assertThat(methodAnnotation).as("Should find RequestMapping on testMethod").isNotNull();
            assertThat(methodAnnotation.value()[0])
                    .as("Should have correct method mapping")
                    .isEqualTo("/method");
        } catch (NoSuchMethodException e) {
            fail("Test method should exist");
        }
    }

    @Test
    void testAnnotationUtils_AnnotationAttributes() {
        RequestMapping annotation =
                AnnotationUtils.findAnnotation(TestController.class, RequestMapping.class);

        assertThat(annotation).as("Should find annotation").isNotNull();

        // Get annotation attributes as map
        Map<String, Object> attributes = AnnotationUtils.getAnnotationAttributes(annotation);

        assertThat(attributes).as("Attributes map should not be null").isNotNull();
        assertThat(attributes).as("Should contain 'value' attribute").containsKey("value");

        String[] values = (String[]) attributes.get("value");
        assertThat(values[0]).as("Should have correct value").isEqualTo("/test");
    }

    @Test
    void testCompletableFuture_AsyncOperations() throws ExecutionException, InterruptedException {
        // Test simple async computation
        CompletableFuture<String> future =
                CompletableFuture.supplyAsync(
                        () -> {
                            return "Hello, Async World!";
                        });

        String result = future.get();
        assertThat(result)
                .as("Should complete with correct result")
                .isEqualTo("Hello, Async World!");
        assertThat(future.isDone()).as("Future should be done").isTrue();
        assertThat(future.isCancelled()).as("Future should not be cancelled").isFalse();
    }

    @Test
    void testCompletableFuture_ChainedOperations() throws ExecutionException, InterruptedException {
        CompletableFuture<String> future =
                CompletableFuture.supplyAsync(() -> "hello")
                        .thenApply(String::toUpperCase)
                        .thenApply(s -> s + " WORLD!")
                        .thenCompose(s -> CompletableFuture.supplyAsync(() -> s + " ASYNC"));

        String result = future.get();
        assertThat(result).as("Should chain operations correctly").isEqualTo("HELLO WORLD! ASYNC");
    }

    @Test
    void testCompletableFuture_CombineResults() throws ExecutionException, InterruptedException {
        CompletableFuture<Integer> future1 = CompletableFuture.supplyAsync(() -> 10);
        CompletableFuture<Integer> future2 = CompletableFuture.supplyAsync(() -> 20);

        CompletableFuture<Integer> combined = future1.thenCombine(future2, Integer::sum);

        Integer result = combined.get();
        assertThat(result).as("Should combine results correctly").isEqualTo(30);
    }

    @Test
    void testCompletableFuture_ExceptionHandling() throws InterruptedException {
        CompletableFuture<String> future =
                CompletableFuture.<String>supplyAsync(
                                () -> {
                                    throw new RuntimeException("Simulated error");
                                })
                        .exceptionally(throwable -> "Error handled: " + throwable.getMessage());

        try {
            String result = future.get();
            assertThat(result)
                    .as("Should handle exception correctly")
                    .isEqualTo("Error handled: java.lang.RuntimeException: Simulated error");
        } catch (ExecutionException e) {
            fail("Exception should have been handled");
        }
    }

    @Test
    void testUtilityToolsDemo_Integration() {
        // Test the complete demonstration
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results).as("Should contain Assert results").containsKey("Assert");
        assertThat(results).as("Should contain ObjectUtils results").containsKey("ObjectUtils");
        assertThat(results).as("Should contain NumberUtils results").containsKey("NumberUtils");
        assertThat(results).as("Should contain StopWatch results").containsKey("StopWatch");
        assertThat(results)
                .as("Should contain AnnotationUtils results")
                .containsKey("AnnotationUtils");
        assertThat(results)
                .as("Should contain CompletableFuture results")
                .containsKey("CompletableFuture");

        // Verify some specific results
        @SuppressWarnings("unchecked")
        Map<String, Object> assertResults = (Map<String, Object>) results.get("Assert");
        assertThat(assertResults)
                .as("Should show validation results")
                .containsKey("assertions_passed");

        @SuppressWarnings("unchecked")
        Map<String, Object> stopWatchResults = (Map<String, Object>) results.get("StopWatch");
        assertThat((Integer) stopWatchResults.get("task_count"))
                .as("Should have completed tasks")
                .isGreaterThan(0);
    }

    @Test
    void testRealWorldUseCases() throws InterruptedException, ExecutionException {
        // Input validation use case
        String userInput = "user@example.com";
        assertThatCode(
                        () -> {
                            Assert.hasText(userInput, "Email must not be empty");
                            Assert.isTrue(userInput.contains("@"), "Email must contain @ symbol");
                        })
                .as("Valid email should pass validation")
                .doesNotThrowAnyException();

        // Performance monitoring use case
        StopWatch performanceMonitor = new StopWatch("API Request");
        performanceMonitor.start("Authentication");
        Thread.sleep(5); // Simulate auth
        performanceMonitor.stop();

        performanceMonitor.start("Database Query");
        Thread.sleep(10); // Simulate DB query
        performanceMonitor.stop();

        performanceMonitor.start("Response Serialization");
        Thread.sleep(3); // Simulate serialization
        performanceMonitor.stop();

        assertThat(performanceMonitor.getTotalTimeMillis())
                .as("Should track total request time")
                .isGreaterThanOrEqualTo(18);

        // Async processing use case
        CompletableFuture<String> dataProcessing =
                CompletableFuture.supplyAsync(
                                () -> {
                                    // Simulate data fetching
                                    return "raw_data";
                                })
                        .thenApplyAsync(
                                data -> {
                                    // Simulate data processing
                                    return data.toUpperCase() + "_PROCESSED";
                                })
                        .thenApplyAsync(
                                data -> {
                                    // Simulate data formatting
                                    return "FORMATTED_" + data;
                                });

        String finalResult = dataProcessing.get();
        assertThat(finalResult)
                .as("Should process data through async pipeline")
                .isEqualTo("FORMATTED_RAW_DATA_PROCESSED");

        // Safe object comparison use case
        String nullableValue1 = null;
        String nullableValue2 = null;
        String nullableValue3 = "value";

        assertThat(ObjectUtils.nullSafeEquals(nullableValue1, nullableValue2))
                .as("Should safely compare null values")
                .isTrue();
        assertThat(ObjectUtils.nullSafeEquals(nullableValue1, nullableValue3))
                .as("Should safely compare null with non-null")
                .isFalse();

        // Number parsing use case
        String userAge = "25";
        String userSalary = "50000.50";

        Integer age = NumberUtils.parseNumber(userAge, Integer.class);
        Double salary = NumberUtils.parseNumber(userSalary, Double.class);

        assertThat(age).as("Should parse age correctly").isEqualTo(25);
        assertThat(salary).as("Should parse salary correctly").isCloseTo(50000.50, within(0.01));
    }

    // Test helper class
    @RequestMapping("/test")
    public static class TestController {

        @RequestMapping("/method")
        public String testMethod() {
            return "test";
        }
    }
}
