package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.FileSystemUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StreamUtils;

/**
 * Unit tests demonstrating usage of Spring's I/O and Resource utilities. These tests show practical
 * examples of how to use: - FileCopyUtils: File copying and content operations - ResourceUtils:
 * Resource location and URL utilities - StreamUtils: Stream copying and conversion utilities -
 * FileSystemUtils: File system operations - ResourcePatternResolver: Pattern-based resource
 * discovery
 */
class IOResourceToolsDemoTest {

    private IOResourceToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new IOResourceToolsDemo();
    }

    @Test
    void testFileCopyUtils_ByteArrayOperations() throws IOException {
        // Create test content
        String testContent = "Hello, FileCopyUtils test!";
        Path tempFile = Files.createTempFile("test", ".txt");

        try {
            // Write content to file
            Files.write(tempFile, testContent.getBytes(StandardCharsets.UTF_8));

            // Copy file to byte array
            byte[] bytes = FileCopyUtils.copyToByteArray(tempFile.toFile());

            assertThat(bytes).hasSize(testContent.length());
            assertThat(new String(bytes, StandardCharsets.UTF_8)).isEqualTo(testContent);
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testFileCopyUtils_FileCopying() throws IOException {
        String testContent = "File copying test content\nWith multiple lines\nAnd more content";
        Path sourceFile = Files.createTempFile("source", ".txt");
        Path targetFile = Files.createTempFile("target", ".txt");

        try {
            // Write test content
            Files.write(sourceFile, testContent.getBytes(StandardCharsets.UTF_8));

            // Copy file to file
            FileCopyUtils.copy(sourceFile.toFile(), targetFile.toFile());

            // Verify copy
            String copiedContent = Files.readString(targetFile, StandardCharsets.UTF_8);
            assertThat(copiedContent).isEqualTo(testContent);

        } finally {
            Files.deleteIfExists(sourceFile);
            Files.deleteIfExists(targetFile);
        }
    }

    @Test
    void testFileCopyUtils_StreamOperations() throws IOException {
        String testContent = "Stream operations test";

        try (ByteArrayInputStream input =
                        new ByteArrayInputStream(testContent.getBytes(StandardCharsets.UTF_8));
                ByteArrayOutputStream output = new ByteArrayOutputStream()) {

            // Copy stream to stream
            FileCopyUtils.copy(input, output);

            String result = output.toString(StandardCharsets.UTF_8);
            assertThat(result).isEqualTo(testContent);
        }
    }

    @Test
    void testFileCopyUtils_StringOperations() throws IOException {
        String testContent = "String operations test content";
        Path tempFile = Files.createTempFile("string-test", ".txt");

        try {
            Files.write(tempFile, testContent.getBytes(StandardCharsets.UTF_8));

            // Copy file to string
            String content = FileCopyUtils.copyToString(new FileReader(tempFile.toFile()));
            assertThat(content).isEqualTo(testContent);

            // Copy string to writer
            StringWriter writer = new StringWriter();
            FileCopyUtils.copy(testContent, writer);
            assertThat(writer.toString()).isEqualTo(testContent);

        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    void testResourceUtils_UrlDetection() {
        // Test URL detection
        assertThat(ResourceUtils.isUrl("http://example.com")).isTrue();
        assertThat(ResourceUtils.isUrl("https://example.com")).isTrue();
        assertThat(ResourceUtils.isUrl("file:/path/to/file")).isTrue();
        assertThat(ResourceUtils.isUrl("classpath:config.properties")).isTrue();
        assertThat(ResourceUtils.isUrl("just-a-string")).isFalse();
        assertThat(ResourceUtils.isUrl("/absolute/path")).isFalse();
        assertThat(ResourceUtils.isUrl("relative/path")).isFalse();
    }

    @Test
    void testResourceUtils_UrlCreation() throws Exception {
        // Test URL creation for existing resources
        try {
            URL classpathUrl = ResourceUtils.getURL("classpath:application.properties");
            assertThat(classpathUrl).isNotNull();
        } catch (FileNotFoundException e) {
            // Expected if application.properties doesn't exist
            assertThat(e.getMessage()).contains("cannot be resolved to URL");
        }

        // Test with known existing resource (Spring's own classes)
        URL springUrl =
                ResourceUtils.getURL("classpath:org/springframework/util/StringUtils.class");
        assertThat(springUrl).isNotNull();

        URL fileUrl = ResourceUtils.getURL("file:/tmp/test.txt");
        assertThat(fileUrl.getProtocol()).isEqualTo("file");

        URL httpUrl = ResourceUtils.getURL("http://example.com/test");
        assertThat(httpUrl.getProtocol()).isEqualTo("http");
        assertThat(httpUrl.getHost()).isEqualTo("example.com");
    }

    @Test
    void testResourceUtils_FileAccess() {
        // Test file access (this may not always work in test environment)
        try {
            File file = ResourceUtils.getFile("classpath:application.properties");
            // If we get here, the file is accessible as a File
            assertThat(file.getName()).endsWith(".properties");
        } catch (Exception e) {
            // This is expected if the file is in a JAR or not accessible as File
            assertThat(e.getMessage())
                    .satisfiesAnyOf(
                            msg ->
                                    assertThat(msg)
                                            .contains("cannot be resolved to absolute file path"),
                            msg -> assertThat(msg).contains("class path resource"));
        }
    }

    @Test
    void testStreamUtils_ByteArrayOperations() throws IOException {
        String testContent = "StreamUtils byte array test content";

        try (InputStream input =
                new ByteArrayInputStream(testContent.getBytes(StandardCharsets.UTF_8))) {
            byte[] data = StreamUtils.copyToByteArray(input);

            assertThat(data).hasSize(testContent.length());
            assertThat(new String(data, StandardCharsets.UTF_8)).isEqualTo(testContent);
        }
    }

    @Test
    void testStreamUtils_StringOperations() throws IOException {
        String testContent = "StreamUtils string test content\nwith newlines";

        try (InputStream input =
                new ByteArrayInputStream(testContent.getBytes(StandardCharsets.UTF_8))) {
            String result = StreamUtils.copyToString(input, StandardCharsets.UTF_8);
            assertThat(result).isEqualTo(testContent);
        }
    }

    @Test
    void testStreamUtils_CopyOperations() throws IOException {
        String testContent = "StreamUtils copy operations test";

        try (ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            // Copy string to output stream
            StreamUtils.copy(testContent, StandardCharsets.UTF_8, output);

            String result = output.toString(StandardCharsets.UTF_8);
            assertThat(result).isEqualTo(testContent);
        }
    }

    @Test
    void testFileSystemUtils_DirectoryOperations() throws IOException {
        // Create temporary directory structure
        Path tempDir = Files.createTempDirectory("filesystem-test");
        Path subDir = tempDir.resolve("subdir");
        Files.createDirectories(subDir);

        // Create test files
        Path file1 = tempDir.resolve("file1.txt");
        Path file2 = subDir.resolve("file2.txt");
        Files.write(file1, "Content 1".getBytes());
        Files.write(file2, "Content 2".getBytes());

        try {
            // Copy directory recursively
            Path copyDir = Files.createTempDirectory("filesystem-copy");
            FileSystemUtils.copyRecursively(tempDir, copyDir);

            // Verify copy
            assertThat(Files.exists(copyDir.resolve("file1.txt"))).isTrue();
            assertThat(Files.exists(copyDir.resolve("subdir/file2.txt"))).isTrue();

            // Cleanup copy
            assertThat(FileSystemUtils.deleteRecursively(copyDir)).isTrue();
            assertThat(Files.exists(copyDir)).isFalse();

        } finally {
            // Cleanup original
            FileSystemUtils.deleteRecursively(tempDir);
        }
    }

    @Test
    void testFileSystemUtils_SingleFileOperations() throws IOException {
        Path tempFile = Files.createTempFile("single-file", ".txt");
        Files.write(tempFile, "Test content".getBytes());

        try {
            assertThat(Files.exists(tempFile)).isTrue();
            assertThat(FileSystemUtils.deleteRecursively(tempFile)).isTrue();
            assertThat(Files.exists(tempFile)).isFalse();
        } finally {
            Files.deleteIfExists(tempFile); // Cleanup in case test failed
        }
    }

    @Test
    void testResourcePatternResolver_BasicPatterns() throws IOException {
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        // Find all class files (should find many in test classpath)
        Resource[] classResources = resolver.getResources("classpath*:**/*.class");
        assertThat(classResources).hasSizeGreaterThan(0);

        // Find all Java files in test source (if present)
        Resource[] javaResources = resolver.getResources("classpath*:**/*.java");
        // Java files may or may not be present in test classpath
        assertThat(javaResources).isNotNull();

        // Find all properties files
        Resource[] propResources = resolver.getResources("classpath*:**/*.properties");
        assertThat(propResources).isNotNull();
    }

    @Test
    void testResourcePatternResolver_SpecificPatterns() throws IOException {
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();

        // Look for Spring Boot configuration files
        Resource[] configResources = resolver.getResources("classpath*:application.*");
        assertThat(configResources).isNotNull();

        // Look for META-INF files
        Resource[] metaInfResources = resolver.getResources("classpath*:META-INF/*");
        assertThat(metaInfResources).isNotNull();

        // Each found resource should be valid
        for (Resource resource : configResources) {
            assertThat(resource.getDescription()).isNotNull();
        }
    }

    @Test
    void testIOResourceToolsDemo_FileCopyUtilsDemo() {
        Map<String, Object> results = demo.demonstrateFileCopyUtils();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify file operations
        assertThat(results.get("original_content")).isNotNull();
        assertThat(results.get("copied_content")).isNotNull();
        assertThat(results.get("stream_content")).isNotNull();

        assertThat((Integer) results.get("bytes_length")).isPositive();
        assertThat(results.get("files_match")).isEqualTo(true);

        // Verify content consistency
        String original = (String) results.get("original_content");
        String copied = (String) results.get("copied_content");
        String streamed = (String) results.get("stream_content");

        assertThat(copied).isEqualTo(original);
        assertThat(streamed).isEqualTo(original);
    }

    @Test
    void testIOResourceToolsDemo_ResourceUtilsDemo() {
        Map<String, Object> results = demo.demonstrateResourceUtils();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify URL detection results
        assertThat(results.get("isUrl_http")).isEqualTo(true);
        assertThat(results.get("isUrl_classpath")).isEqualTo(true);
        assertThat(results.get("isUrl_file")).isEqualTo(true);
        assertThat(results.get("isUrl_string")).isEqualTo(false);

        // Verify URL creation
        assertThat(results.get("classpath_url")).isNotNull();
        assertThat(results.get("url_protocol")).isNotNull();

        // Config file access may or may not work depending on environment
        assertThat(results.get("config_file_found")).isNotNull();
    }

    @Test
    void testIOResourceToolsDemo_StreamUtilsDemo() {
        Map<String, Object> results = demo.demonstrateStreamUtils();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify stream operations
        assertThat(results.get("original_string")).isNotNull();
        assertThat(results.get("copied_text")).isNotNull();
        assertThat(results.get("output_content")).isNotNull();

        assertThat((Integer) results.get("data_length")).isPositive();
        assertThat(results.get("strings_match")).isEqualTo(true);

        // Verify content consistency
        String original = (String) results.get("original_string");
        String copied = (String) results.get("copied_text");
        assertThat(copied).isEqualTo(original);
    }

    @Test
    void testIOResourceToolsDemo_FileSystemUtilsDemo() {
        Map<String, Object> results = demo.demonstrateFileSystemUtils();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify directory operations
        assertThat(results.get("temp_dir_created")).isNotNull();
        assertThat(results.get("files_created")).isNotNull();
        assertThat(results.get("copy_dir")).isNotNull();

        assertThat(results.get("copy_successful")).isEqualTo(true);
        assertThat(results.get("original_deleted")).isEqualTo(true);
        assertThat(results.get("copy_deleted")).isEqualTo(true);
        assertThat(results.get("cleanup_successful")).isEqualTo(true);

        // Verify files list
        @SuppressWarnings("unchecked")
        List<String> filesCreated = (List<String>) results.get("files_created");
        assertThat(filesCreated).hasSize(2);
    }

    @Test
    void testIOResourceToolsDemo_ResourcePatternUtilsDemo() {
        Map<String, Object> results = demo.demonstrateResourcePatternUtils();

        assertThat(results).isNotNull();
        assertThat(results).doesNotContainKey("error");

        // Verify resource counts (should be non-negative)
        assertThat((Integer) results.get("property_files_found")).isNotNegative();
        assertThat((Integer) results.get("yaml_files_found")).isNotNegative();
        assertThat((Integer) results.get("meta_inf_xml_files")).isNotNegative();
        assertThat((Integer) results.get("app_config_files")).isNotNegative();

        // If files are found, verify their descriptions exist
        if ((Integer) results.get("property_files_found") > 0) {
            assertThat(results.get("first_property_file")).isNotNull();
        }

        if ((Integer) results.get("yaml_files_found") > 0) {
            assertThat(results.get("first_yaml_file")).isNotNull();
            assertThat(results.get("yaml_file_exists")).isNotNull();
        }
    }

    @Test
    void testIOResourceToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).isNotNull();
        assertThat(results).containsKey("FileCopyUtils");
        assertThat(results).containsKey("ResourceUtils");
        assertThat(results).containsKey("StreamUtils");
        assertThat(results).containsKey("FileSystemUtils");
        assertThat(results).containsKey("ResourcePatternUtils");

        // Verify each section has meaningful content
        @SuppressWarnings("unchecked")
        Map<String, Object> fileCopyResults = (Map<String, Object>) results.get("FileCopyUtils");
        assertThat(fileCopyResults.get("original_content")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> resourceResults = (Map<String, Object>) results.get("ResourceUtils");
        assertThat(resourceResults.get("isUrl_http")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> streamResults = (Map<String, Object>) results.get("StreamUtils");
        assertThat(streamResults.get("original_string")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> fileSystemResults =
                (Map<String, Object>) results.get("FileSystemUtils");
        assertThat(fileSystemResults.get("temp_dir_created")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> patternResults =
                (Map<String, Object>) results.get("ResourcePatternUtils");
        assertThat(patternResults.get("property_files_found")).isNotNull();
    }

    @Test
    void testRealWorldIOUseCases() throws IOException {
        // Configuration file loading
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        Resource[] configs = resolver.getResources("classpath*:application.*");

        for (Resource config : configs) {
            if (config.exists()) {
                // Read configuration content
                String content =
                        StreamUtils.copyToString(config.getInputStream(), StandardCharsets.UTF_8);
                assertThat(content).isNotNull();
            }
        }

        // Temporary file processing
        Path tempFile = Files.createTempFile("processing", ".txt");
        String data = "Processing data content\nWith multiple lines\nFor testing";

        try {
            // Write data
            FileCopyUtils.copy(data.getBytes(StandardCharsets.UTF_8), tempFile.toFile());

            // Read and verify
            String readData = FileCopyUtils.copyToString(new FileReader(tempFile.toFile()));
            assertThat(readData).isEqualTo(data);

        } finally {
            Files.deleteIfExists(tempFile);
        }

        // Resource URL handling
        assertThat(ResourceUtils.isUrl("classpath:config.properties")).isTrue();
        assertThat(ResourceUtils.isUrl("plain-filename.txt")).isFalse();

        URL classpathUrl =
                ResourceUtils.getURL("classpath:org/springframework/core/SpringVersion.class");
        assertThat(classpathUrl).isNotNull();

        // Stream processing
        String streamData = "Stream processing test data";
        try (ByteArrayInputStream input = new ByteArrayInputStream(streamData.getBytes());
                ByteArrayOutputStream output = new ByteArrayOutputStream()) {

            byte[] buffer = StreamUtils.copyToByteArray(input);
            assertThat(new String(buffer)).isEqualTo(streamData);

            StreamUtils.copy(streamData, StandardCharsets.UTF_8, output);
            assertThat(output.toString(StandardCharsets.UTF_8)).isEqualTo(streamData);
        }
    }
}
