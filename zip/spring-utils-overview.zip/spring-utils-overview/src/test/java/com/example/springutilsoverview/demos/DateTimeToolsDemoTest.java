package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.format.datetime.DateFormatter;
import org.springframework.util.StopWatch;

/**
 * Unit tests demonstrating usage of Spring's Date and Time utilities. These tests show practical
 * examples of how to use: - DateFormatter: Spring's date formatting utility - StopWatch:
 * Performance monitoring and timing utility - Modern alternatives: Java 8+ date/time API
 * comparisons
 */
class DateTimeToolsDemoTest {

    private DateTimeToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new DateTimeToolsDemo();
    }

    @Test
    void testDateFormatter_BasicFormatting() {
        DateFormatter formatter = new DateFormatter("yyyy-MM-dd HH:mm:ss");
        Date testDate = new Date();
        Locale locale = Locale.getDefault();

        String formatted = formatter.print(testDate, locale);

        assertThat(formatted).as("Formatted date should not be null").isNotNull();
        assertThat(formatted)
                .as("Should match expected pattern")
                .matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}");
    }

    @Test
    void testDateFormatter_DifferentPatterns() {
        Date testDate = new Date();
        Locale locale = Locale.getDefault();

        // Test different patterns
        DateFormatter formatter1 = new DateFormatter("dd/MM/yyyy");
        DateFormatter formatter2 = new DateFormatter("MMM dd, yyyy");
        DateFormatter formatter3 = new DateFormatter("yyyy-MM-dd");

        String formatted1 = formatter1.print(testDate, locale);
        String formatted2 = formatter2.print(testDate, locale);
        String formatted3 = formatter3.print(testDate, locale);

        assertThat(formatted1)
                .as("Should match dd/MM/yyyy pattern")
                .matches("\\d{2}/\\d{2}/\\d{4}");
        assertThat(formatted2)
                .as("Should match MMM dd, yyyy pattern")
                .matches("\\w{3} \\d{2}, \\d{4}");
        assertThat(formatted3)
                .as("Should match yyyy-MM-dd pattern")
                .matches("\\d{4}-\\d{2}-\\d{2}");
    }

    @Test
    void testDateFormatter_ParsingRoundTrip() throws Exception {
        DateFormatter formatter = new DateFormatter("yyyy-MM-dd HH:mm:ss");
        Date originalDate = new Date();
        Locale locale = Locale.getDefault();

        // Format and then parse back
        String formatted = formatter.print(originalDate, locale);
        Date parsedDate = formatter.parse(formatted, locale);

        assertThat(parsedDate).as("Parsed date should not be null").isNotNull();
        // Allow for small time differences (within 1 second)
        assertThat(Math.abs(originalDate.getTime() - parsedDate.getTime()))
                .as("Dates should be approximately equal")
                .isLessThan(1000L);
    }

    @Test
    void testDateFormatter_DifferentLocales() {
        DateFormatter formatter = new DateFormatter("MMM dd, yyyy");
        Date testDate = new Date();

        String englishFormat = formatter.print(testDate, Locale.ENGLISH);
        String frenchFormat = formatter.print(testDate, Locale.FRENCH);

        assertThat(englishFormat).as("English format should not be null").isNotNull();
        assertThat(frenchFormat).as("French format should not be null").isNotNull();
        // Different locales should produce different month names (in most cases)
        // We can't guarantee they're different for all dates, but we can verify they're valid
        assertThat(englishFormat).matches("\\w{3} \\d{2}, \\d{4}");
        assertThat(frenchFormat).matches("\\w{3,4}\\.?\\s+\\d{1,2},\\s+\\d{4}");
    }

    @Test
    void testStopWatch_BasicTiming() throws InterruptedException {
        StopWatch stopWatch = new StopWatch("Test Timing");

        stopWatch.start("Task 1");
        Thread.sleep(10); // Short sleep
        stopWatch.stop();

        stopWatch.start("Task 2");
        Thread.sleep(20); // Slightly longer sleep
        stopWatch.stop();

        assertThat(stopWatch.getTotalTimeMillis())
                .as("Total time should be at least 30ms")
                .isGreaterThanOrEqualTo(30L);
        assertThat(stopWatch.getTaskCount()).as("Should have 2 tasks").isEqualTo(2);
        assertThat(stopWatch.getTotalTimeSeconds()).as("Should have positive seconds").isPositive();
        assertThat(stopWatch.shortSummary()).as("Should have short summary").isNotNull();
        assertThat(stopWatch.prettyPrint()).as("Should have pretty print").isNotNull();
    }

    @Test
    void testStopWatch_TaskDetails() throws InterruptedException {
        StopWatch stopWatch = new StopWatch("Detailed Test");

        stopWatch.start("Fast Task");
        Thread.sleep(5);
        stopWatch.stop();

        stopWatch.start("Slow Task");
        Thread.sleep(15);
        stopWatch.stop();

        StopWatch.TaskInfo[] taskInfos = stopWatch.getTaskInfo();
        assertThat(taskInfos).as("Should have 2 task infos").hasSize(2);

        StopWatch.TaskInfo task1 = taskInfos[0];
        StopWatch.TaskInfo task2 = taskInfos[1];

        assertThat(task1.getTaskName()).isEqualTo("Fast Task");
        assertThat(task2.getTaskName()).isEqualTo("Slow Task");
        assertThat(task2.getTimeMillis())
                .as("Slow task should take longer")
                .isGreaterThan(task1.getTimeMillis());

        // Test task info properties
        assertThat(task1.getTimeSeconds()).as("Should have positive seconds").isPositive();
        assertThat(task1.getTimeMillis()).as("Should be at least 5ms").isGreaterThanOrEqualTo(5L);
    }

    @Test
    void testStopWatch_EdgeCases() {
        StopWatch stopWatch = new StopWatch();

        // Test with no tasks
        assertThat(stopWatch.getTaskCount()).as("Empty stopwatch should have 0 tasks").isEqualTo(0);
        assertThat(stopWatch.getTotalTimeMillis())
                .as("Empty stopwatch should have 0 total time")
                .isEqualTo(0L);

        // Test with ID
        StopWatch namedStopWatch = new StopWatch("Named Test");
        assertThat(namedStopWatch.getId()).as("Should have correct ID").isEqualTo("Named Test");

        // Test task without timing (edge case)
        assertThatThrownBy(
                        () -> {
                            StopWatch badWatch = new StopWatch();
                            badWatch.stop(); // Stopping without starting should throw
                        })
                .as("Should throw exception when stopping without starting")
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void testStopWatch_ConcurrentUsage() throws InterruptedException {
        StopWatch stopWatch = new StopWatch("Concurrent Test");

        // Test that multiple sequential operations work correctly
        for (int i = 0; i < 5; i++) {
            stopWatch.start("Task " + (i + 1));
            Thread.sleep(5); // Small delay
            stopWatch.stop();
        }

        assertThat(stopWatch.getTaskCount()).as("Should have 5 tasks").isEqualTo(5);
        assertThat(stopWatch.getTotalTimeMillis())
                .as("Should have at least 25ms total")
                .isGreaterThanOrEqualTo(25L);

        StopWatch.TaskInfo[] tasks = stopWatch.getTaskInfo();
        for (int i = 0; i < 5; i++) {
            assertThat(tasks[i].getTaskName()).isEqualTo("Task " + (i + 1));
            assertThat(tasks[i].getTimeMillis())
                    .as("Each task should have positive time")
                    .isPositive();
        }
    }

    @Test
    void testModernDateTimeComparison() {
        // Test modern Java 8+ alternatives
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter modernFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        String modernFormatted = now.format(modernFormatter);
        assertThat(modernFormatted).as("Modern formatting should work").isNotNull();
        assertThat(modernFormatted).matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}");

        // Test parsing round trip
        LocalDateTime parsed = LocalDateTime.parse(modernFormatted, modernFormatter);
        assertThat(parsed.getYear()).isEqualTo(now.getYear());
        assertThat(parsed.getMonth()).isEqualTo(now.getMonth());
        assertThat(parsed.getDayOfMonth()).isEqualTo(now.getDayOfMonth());
        assertThat(parsed.getHour()).isEqualTo(now.getHour());
        assertThat(parsed.getMinute()).isEqualTo(now.getMinute());
        assertThat(parsed.getSecond()).isEqualTo(now.getSecond());
    }

    @Test
    void testDateTimeToolsDemo_DateFormatterDemo() {
        Map<String, Object> results = demo.demonstrateDateFormatter();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify formatted outputs
        assertThat(results.get("current_date")).as("Should have current date").isNotNull();
        assertThat(results.get("format_yyyy_MM_dd_HH_mm_ss"))
                .as("Should have formatted date")
                .isNotNull();
        assertThat(results.get("format_dd_MM_yyyy"))
                .as("Should have dd/MM/yyyy format")
                .isNotNull();
        assertThat(results.get("format_MMM_dd_yyyy"))
                .as("Should have MMM dd, yyyy format")
                .isNotNull();

        // Verify locale information
        assertThat(results.get("default_locale")).as("Should have default locale").isNotNull();

        // Verify parsing results
        assertThat(results.get("parsed_date_successful"))
                .as("Should parse successfully")
                .isEqualTo(true);
        assertThat(results.get("parsed_date")).as("Should have parsed date").isNotNull();
        assertThat(results.get("dates_match")).as("Dates should match").isEqualTo(true);

        // Verify French formatting
        assertThat(results.get("french_formatted"))
                .as("Should have French formatted date")
                .isNotNull();
        assertThat(results.get("french_locale")).as("Should have French locale info").isNotNull();
    }

    @Test
    void testDateTimeToolsDemo_StopWatchDemo() {
        Map<String, Object> results = demo.demonstrateAdvancedStopWatch();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify timing results
        assertThat(results.get("task_name")).isEqualTo("Advanced Performance Demo");
        assertThat((Double) results.get("total_time_seconds"))
                .as("Should have positive total time")
                .isPositive();
        assertThat((Long) results.get("total_time_millis"))
                .as("Should have at least 675ms total time")
                .isGreaterThanOrEqualTo(675L);
        assertThat(results.get("task_count")).as("Should have 5 tasks").isEqualTo(5);

        // Verify task details
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> taskDetails =
                (List<Map<String, Object>>) results.get("task_details");
        assertThat(taskDetails).as("Should have task details").isNotNull();
        assertThat(taskDetails).as("Should have 5 task details").hasSize(5);

        // Verify task names
        String[] expectedTasks = {
            "Database Query Simulation",
            "Cache Operation",
            "API Call Simulation",
            "Data Processing",
            "Response Generation"
        };

        for (int i = 0; i < expectedTasks.length; i++) {
            assertThat(taskDetails.get(i).get("task_name")).isEqualTo(expectedTasks[i]);
            assertThat(taskDetails.get(i).get("time_millis"))
                    .as("Should have task time")
                    .isNotNull();
            assertThat(taskDetails.get(i).get("percentage"))
                    .as("Should have percentage")
                    .isNotNull();
        }

        // Verify summaries
        assertThat(results.get("pretty_print")).as("Should have pretty print").isNotNull();
        assertThat(results.get("short_summary")).as("Should have short summary").isNotNull();

        // Verify slowest/fastest tasks
        assertThat(results.get("slowest_task"))
                .as("API Call should be slowest")
                .isEqualTo("API Call Simulation");
        assertThat(results.get("fastest_task"))
                .as("Cache Operation should be fastest")
                .isEqualTo("Cache Operation");
    }

    @Test
    void testDateTimeToolsDemo_ModernAlternatives() {
        Map<String, Object> results = demo.demonstrateModernDateTimeAlternatives();

        assertThat(results).as("Results should not be null").isNotNull();

        // Verify modern formatting results
        assertThat(results.get("current_datetime")).as("Should have current datetime").isNotNull();
        assertThat(results.get("modern_format_1")).as("Should have modern format 1").isNotNull();
        assertThat(results.get("modern_format_2")).as("Should have modern format 2").isNotNull();
        assertThat(results.get("modern_format_3")).as("Should have modern format 3").isNotNull();
        assertThat(results.get("iso_format")).as("Should have ISO format").isNotNull();

        // Verify note about alternatives
        String note = (String) results.get("note");
        assertThat(note).as("Should mention modern alternatives").contains("Modern Java 8+");

        // Verify performance comparison
        assertThat(results.get("performance_comparison"))
                .as("Should have performance comparison")
                .isNotNull();
        String comparison = (String) results.get("performance_comparison");
        assertThat(comparison)
                .as("Should mention Spring formatter")
                .contains("Spring DateFormatter");
        assertThat(comparison)
                .as("Should mention modern formatter")
                .contains("Modern DateTimeFormatter");
    }

    @Test
    void testDateTimeToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("DateFormatter"))
                .as("Should contain DateFormatter results")
                .isTrue();
        assertThat(results.containsKey("AdvancedStopWatch"))
                .as("Should contain StopWatch results")
                .isTrue();
        assertThat(results.containsKey("ModernAlternatives"))
                .as("Should contain modern alternatives")
                .isTrue();

        // Verify each section has expected content
        @SuppressWarnings("unchecked")
        Map<String, Object> dateResults = (Map<String, Object>) results.get("DateFormatter");
        assertThat(dateResults.get("current_date")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> stopWatchResults =
                (Map<String, Object>) results.get("AdvancedStopWatch");
        assertThat(stopWatchResults.get("task_name")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> modernResults = (Map<String, Object>) results.get("ModernAlternatives");
        assertThat(modernResults.get("current_datetime")).isNotNull();
    }

    @Test
    void testRealWorldDateTimeUseCases() throws Exception {
        // Performance monitoring in service layers
        StopWatch serviceTimer = new StopWatch("Service Performance");

        serviceTimer.start("Input Validation");
        Thread.sleep(2); // Simulate validation
        serviceTimer.stop();

        serviceTimer.start("Business Logic");
        Thread.sleep(10); // Simulate processing
        serviceTimer.stop();

        serviceTimer.start("Data Persistence");
        Thread.sleep(5); // Simulate database save
        serviceTimer.stop();

        assertThat(serviceTimer.getTotalTimeMillis())
                .as("Should track total time")
                .isGreaterThanOrEqualTo(17L);
        assertThat(serviceTimer.getTaskCount()).as("Should track all operations").isEqualTo(3);

        // API response formatting
        DateFormatter apiFormatter = new DateFormatter("yyyy-MM-dd'T'HH:mm:ss");
        Date timestamp = new Date();
        String apiTimestamp = apiFormatter.print(timestamp, Locale.getDefault());

        assertThat(apiTimestamp)
                .as("Should format for API response")
                .matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}");

        // Log formatting
        DateFormatter logFormatter = new DateFormatter("yyyy-MM-dd HH:mm:ss.SSS");
        String logTimestamp = logFormatter.print(timestamp, Locale.getDefault());

        assertThat(logTimestamp)
                .as("Should format for logging")
                .matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}");

        // Modern alternative comparison
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter modernFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String modernFormatted = now.format(modernFormatter);

        assertThat(modernFormatted)
                .as("Modern formatting should work consistently")
                .matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}");
    }
}
