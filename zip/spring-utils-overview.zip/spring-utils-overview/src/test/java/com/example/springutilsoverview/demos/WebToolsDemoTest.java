package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.util.UriUtils;

/**
 * Unit tests demonstrating usage of Spring's Web utilities. These tests show practical examples of
 * how to use: - UriUtils: URI encoding and decoding utilities - UriComponentsBuilder: Fluent URI
 * building - HtmlUtils: HTML escaping and unescaping utilities - CacheControl: HTTP cache control
 * header building - HttpHeaders: HTTP header management utilities
 */
class WebToolsDemoTest {

    private WebToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new WebToolsDemo();
    }

    @Test
    void testUriUtils_PathEncoding() {
        String originalPath = "path with spaces & special chars";
        String encoded = UriUtils.encodePathSegment(originalPath, StandardCharsets.UTF_8);
        String decoded = UriUtils.decode(encoded, StandardCharsets.UTF_8);

        assertThat(encoded).as("Encoded path should not be null").isNotNull();
        assertThat(encoded)
                .as("Encoded should be different from original")
                .isNotEqualTo(originalPath);
        assertThat(decoded).as("Decoded should match original").isEqualTo(originalPath);
        assertThat(encoded).as("Encoded should contain URL encoded spaces").contains("%20");
    }

    @Test
    void testUriUtils_QueryParameterEncoding() {
        String queryParam = "search term with spaces & symbols";
        String encoded = UriUtils.encodeQueryParam(queryParam, StandardCharsets.UTF_8);
        String decoded = UriUtils.decode(encoded, StandardCharsets.UTF_8);

        assertThat(encoded).as("Encoded query should not be null").isNotNull();
        assertThat(encoded)
                .as("Encoded should be different from original")
                .isNotEqualTo(queryParam);
        assertThat(decoded).as("Decoded should match original").isEqualTo(queryParam);
    }

    @Test
    void testUriUtils_SpecialCharacters() {
        // Test various special characters
        String[] testStrings = {
            "hello world",
            "user@example.com",
            "price=$100",
            "query=value&other=test",
            "file.txt",
            "path/to/resource"
        };

        for (String testString : testStrings) {
            String encoded = UriUtils.encodePathSegment(testString, StandardCharsets.UTF_8);
            String decoded = UriUtils.decode(encoded, StandardCharsets.UTF_8);

            assertThat(decoded)
                    .as("Should properly encode/decode: " + testString)
                    .isEqualTo(testString);
        }
    }

    @Test
    void testUriComponentsBuilder_BasicUriBuilding() {
        URI uri =
                UriComponentsBuilder.fromHttpUrl("http://example.com")
                        .path("/products/{id}")
                        .queryParam("category", "books")
                        .queryParam("sort", "price")
                        .build("123");

        assertThat(uri).as("URI should not be null").isNotNull();
        assertThat(uri.getScheme()).as("Should have correct scheme").isEqualTo("http");
        assertThat(uri.getHost()).as("Should have correct host").isEqualTo("example.com");
        assertThat(uri.getPath())
                .as("Should have correct path with substitution")
                .isEqualTo("/products/123");
        assertThat(uri.getQuery())
                .as("Should contain category parameter")
                .contains("category=books");
        assertThat(uri.getQuery()).as("Should contain sort parameter").contains("sort=price");
    }

    @Test
    void testUriComponentsBuilder_ComplexUriBuilding() {
        URI uri =
                UriComponentsBuilder.newInstance()
                        .scheme("https")
                        .host("api.example.com")
                        .port(8080)
                        .path("/users/{userId}/orders/{orderId}")
                        .build("456", "789");

        assertThat(uri.getScheme()).as("Should have HTTPS scheme").isEqualTo("https");
        assertThat(uri.getHost()).as("Should have correct host").isEqualTo("api.example.com");
        assertThat(uri.getPort()).as("Should have correct port").isEqualTo(8080);
        assertThat(uri.getPath())
                .as("Should substitute multiple variables")
                .isEqualTo("/users/456/orders/789");
    }

    @Test
    void testUriComponentsBuilder_QueryParameters() {
        URI uri =
                UriComponentsBuilder.fromHttpUrl("http://example.com/search")
                        .queryParam("page", "1")
                        .queryParam("size", "20")
                        .queryParam("filter", "active")
                        .queryParam("tags", "java", "spring")
                        .build()
                        .toUri();

        String query = uri.getQuery();
        assertThat(query).as("Should contain page parameter").contains("page=1");
        assertThat(query).as("Should contain size parameter").contains("size=20");
        assertThat(query).as("Should contain filter parameter").contains("filter=active");
        assertThat(query)
                .as("Should contain multiple tag values")
                .contains("tags=java")
                .contains("tags=spring");
    }

    @Test
    void testUriComponentsBuilder_PathSegments() {
        URI uri =
                UriComponentsBuilder.fromHttpUrl("http://example.com")
                        .pathSegment("api", "v1", "users", "{userId}")
                        .build("123");

        assertThat(uri.getPath())
                .as("Should build path from segments")
                .isEqualTo("/api/v1/users/123");
    }

    @Test
    void testHtmlUtils_BasicEscaping() {
        String dangerousHtml = "<script>alert('XSS')</script>";
        String escaped = HtmlUtils.htmlEscape(dangerousHtml);

        assertThat(escaped).as("Escaped HTML should not be null").isNotNull();
        assertThat(escaped).as("Should not contain raw script tags").doesNotContain("<script>");
        assertThat(escaped).as("Should contain escaped script tags").contains("&lt;script&gt;");
        assertThat(escaped).as("Should contain escaped closing tags").contains("&lt;/script&gt;");
        assertThat(escaped).as("Should escape single quotes").doesNotContain("'");
    }

    @Test
    void testHtmlUtils_BasicUnescaping() {
        String htmlEntities = "&lt;b&gt;Bold&lt;/b&gt; &amp; more";
        String unescaped = HtmlUtils.htmlUnescape(htmlEntities);

        assertThat(unescaped).as("Should unescape HTML entities").isEqualTo("<b>Bold</b> & more");
    }

    @Test
    void testHtmlUtils_RoundTripEscaping() {
        String original = "User said: <b>Hello & welcome!</b>";
        String escaped = HtmlUtils.htmlEscape(original);
        String unescaped = HtmlUtils.htmlUnescape(escaped);

        assertThat(unescaped).as("Should round-trip correctly").isEqualTo(original);
    }

    @Test
    void testHtmlUtils_SpecialCharacters() {
        // Test various HTML special characters
        Map<String, String> testCases =
                Map.of(
                        "<", "&lt;",
                        ">", "&gt;",
                        "&", "&amp;",
                        "\"", "&quot;",
                        "'", "&#39;");

        for (Map.Entry<String, String> testCase : testCases.entrySet()) {
            String original = testCase.getKey();
            String expectedEscaped = testCase.getValue();

            String escaped = HtmlUtils.htmlEscape(original);
            assertThat(escaped)
                    .as("Should escape " + original + " to " + expectedEscaped)
                    .contains(expectedEscaped);

            String unescaped = HtmlUtils.htmlUnescape(expectedEscaped);
            assertThat(unescaped)
                    .as("Should unescape " + expectedEscaped + " to " + original)
                    .isEqualTo(original);
        }
    }

    @Test
    void testCacheControl_NoCache() {
        CacheControl noCache = CacheControl.noCache();
        String headerValue = noCache.getHeaderValue();

        assertThat(headerValue).as("No-cache header should not be null").isNotNull();
        assertThat(headerValue).as("Should contain no-cache directive").contains("no-cache");
    }

    @Test
    void testCacheControl_MaxAge() {
        CacheControl maxAge = CacheControl.maxAge(1, TimeUnit.HOURS);
        String headerValue = maxAge.getHeaderValue();

        assertThat(headerValue).as("Max-age header should not be null").isNotNull();
        assertThat(headerValue)
                .as("Should contain max-age=3600 (1 hour in seconds)")
                .contains("max-age=3600");
    }

    @Test
    void testCacheControl_ComplexConfiguration() {
        CacheControl complex =
                CacheControl.maxAge(30, TimeUnit.MINUTES)
                        .noTransform()
                        .mustRevalidate()
                        .cachePrivate();

        String headerValue = complex.getHeaderValue();

        assertThat(headerValue).as("Complex cache control should not be null").isNotNull();
        assertThat(headerValue)
                .as("Should contain max-age for 30 minutes")
                .contains("max-age=1800");
        assertThat(headerValue).as("Should contain no-transform").contains("no-transform");
        assertThat(headerValue).as("Should contain must-revalidate").contains("must-revalidate");
        assertThat(headerValue).as("Should contain private directive").contains("private");
    }

    @Test
    void testCacheControl_AdditionalDirectives() {
        CacheControl publicCache = CacheControl.maxAge(1, TimeUnit.DAYS).cachePublic();
        assertThat(publicCache.getHeaderValue())
                .as("Should support public cache")
                .contains("public");

        CacheControl noStore = CacheControl.noStore();
        assertThat(noStore.getHeaderValue()).as("Should support no-store").contains("no-store");

        CacheControl sMaxAge = CacheControl.maxAge(1, TimeUnit.HOURS).sMaxAge(30, TimeUnit.MINUTES);
        String sMaxAgeHeader = sMaxAge.getHeaderValue();
        assertThat(sMaxAgeHeader).as("Should support s-maxage").contains("s-maxage=1800");
    }

    @Test
    void testHttpHeaders_BasicOperations() {
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setContentLength(1024);
        headers.add("X-Custom-Header", "Custom Value");

        assertThat(headers.getContentType())
                .as("Should set content type")
                .isEqualTo(MediaType.APPLICATION_JSON);
        assertThat(headers.getContentLength()).as("Should set content length").isEqualTo(1024);
        assertThat(headers.getFirst("X-Custom-Header"))
                .as("Should set custom header")
                .isEqualTo("Custom Value");
    }

    @Test
    void testHttpHeaders_AcceptHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(
                List.of(
                        MediaType.APPLICATION_JSON,
                        MediaType.TEXT_PLAIN,
                        MediaType.APPLICATION_XML));

        List<MediaType> acceptHeaders = headers.getAccept();
        assertThat(acceptHeaders).as("Should have 3 accept headers").hasSize(3);
        assertThat(acceptHeaders).as("Should accept JSON").contains(MediaType.APPLICATION_JSON);
        assertThat(acceptHeaders).as("Should accept text").contains(MediaType.TEXT_PLAIN);
        assertThat(acceptHeaders).as("Should accept XML").contains(MediaType.APPLICATION_XML);
    }

    @Test
    void testHttpHeaders_CacheControlIntegration() {
        HttpHeaders headers = new HttpHeaders();
        CacheControl cacheControl = CacheControl.maxAge(1, TimeUnit.HOURS);

        headers.setCacheControl(cacheControl);

        assertThat(headers.getCacheControl())
                .as("Should set cache control header")
                .isEqualTo(cacheControl.getHeaderValue());
    }

    @Test
    void testHttpHeaders_HeaderManipulation() {
        HttpHeaders headers = new HttpHeaders();

        // Add multiple values for same header
        headers.add("X-Multi-Header", "value1");
        headers.add("X-Multi-Header", "value2");

        List<String> multiValues = headers.get("X-Multi-Header");
        assertThat(multiValues).as("Should have multiple values").hasSize(2);
        assertThat(multiValues).as("Should contain first value").contains("value1");
        assertThat(multiValues).as("Should contain second value").contains("value2");

        // Test first value retrieval
        assertThat(headers.getFirst("X-Multi-Header"))
                .as("Should get first value")
                .isEqualTo("value1");

        // Test single value map
        Map<String, String> singleValueMap = headers.toSingleValueMap();
        assertThat(singleValueMap.get("X-Multi-Header"))
                .as("Single value map should contain first value")
                .isEqualTo("value1");
    }

    @Test
    void testWebToolsDemo_UriUtilsDemo() {
        Map<String, Object> results = demo.demonstrateUriUtils();

        assertThat(results).as("Results should not be null").isNotNull();

        // Verify path encoding/decoding
        assertThat(results.get("original_text")).isEqualTo("path with spaces & special chars");
        assertThat(results.get("encoded_path")).as("Should have encoded path").isNotNull();
        assertThat(results.get("decoded_path")).isEqualTo("path with spaces & special chars");

        // Verify query encoding
        assertThat(results.get("original_query")).isEqualTo("search term with spaces");
        assertThat(results.get("encoded_query")).as("Should have encoded query").isNotNull();

        // Verify encoding actually changed the string
        String encoded = (String) results.get("encoded_path");
        String original = (String) results.get("original_text");
        assertThat(encoded).as("Encoded should be different from original").isNotEqualTo(original);
    }

    @Test
    void testWebToolsDemo_UriComponentsBuilderDemo() {
        Map<String, Object> results = demo.demonstrateUriComponentsBuilder();

        assertThat(results).as("Results should not be null").isNotNull();

        // Verify product URI
        String productUri = (String) results.get("product_uri");
        assertThat(productUri)
                .as("Should contain product path with ID")
                .contains("example.com/products/123");
        assertThat(productUri).as("Should contain category parameter").contains("category=books");
        assertThat(productUri).as("Should contain sort parameter").contains("sort=price");

        // Verify user order URI
        String userOrderUri = (String) results.get("user_order_uri");
        assertThat(userOrderUri)
                .as("Should contain HTTPS scheme, host, and port")
                .contains("https://api.example.com:8080");
        assertThat(userOrderUri)
                .as("Should contain path with substituted variables")
                .contains("users/456/orders/789");

        // Verify search URI
        String searchUri = (String) results.get("search_uri");
        assertThat(searchUri).as("Should contain page parameter").contains("page=1");
        assertThat(searchUri).as("Should contain size parameter").contains("size=20");
        assertThat(searchUri).as("Should contain filter parameter").contains("filter=active");

        // Verify query params
        @SuppressWarnings("unchecked")
        Map<String, Object> queryParams = (Map<String, Object>) results.get("query_params");
        assertThat(queryParams.get("page")).as("Should have page parameter").isEqualTo(1);
        assertThat(queryParams.get("size")).as("Should have size parameter").isEqualTo(20);
        assertThat(queryParams.get("filter"))
                .as("Should have filter parameter")
                .isEqualTo("active");
    }

    @Test
    void testWebToolsDemo_HtmlUtilsDemo() {
        Map<String, Object> results = demo.demonstrateHtmlUtils();

        assertThat(results).as("Results should not be null").isNotNull();

        // Verify dangerous HTML escaping
        String dangerousHtml = (String) results.get("dangerous_html");
        String escapedScript = (String) results.get("escaped_script");
        assertThat(dangerousHtml).as("Original should contain script tags").contains("<script>");
        assertThat(escapedScript)
                .as("Escaped should not contain raw script tags")
                .doesNotContain("<script>");
        assertThat(escapedScript)
                .as("Escaped should contain escaped script tags")
                .contains("&lt;script&gt;");

        // Verify user input escaping
        String userInput = (String) results.get("user_input");
        String escapedInput = (String) results.get("escaped_input");
        assertThat(userInput).as("Original should contain bold tags").contains("<b>");
        assertThat(escapedInput)
                .as("Escaped should contain escaped bold tags")
                .contains("&lt;b&gt;");

        // Verify unescaping
        String htmlEntities = (String) results.get("html_entities");
        String unescapedEntities = (String) results.get("unescaped_entities");
        assertThat(htmlEntities).as("Should contain HTML entities").contains("&lt;");
        assertThat(unescapedEntities).as("Should contain unescaped characters").contains("<");
    }

    @Test
    void testWebToolsDemo_CacheControlDemo() {
        Map<String, Object> results = demo.demonstrateCacheControl();

        assertThat(results).as("Results should not be null").isNotNull();

        // Verify no-cache
        String noCache = (String) results.get("no_cache");
        assertThat(noCache).as("Should contain no-cache directive").contains("no-cache");

        // Verify max-age
        String maxAge = (String) results.get("max_age_1hour");
        assertThat(maxAge).as("Should contain 1 hour max-age").contains("max-age=3600");

        // Verify complex cache control
        String complex = (String) results.get("complex_cache");
        assertThat(complex).as("Should contain 30 minute max-age").contains("max-age=1800");
        assertThat(complex).as("Should contain no-transform").contains("no-transform");
        assertThat(complex).as("Should contain must-revalidate").contains("must-revalidate");
        assertThat(complex).as("Should contain private").contains("private");
    }

    @Test
    void testWebToolsDemo_HttpHeadersDemo() {
        Map<String, Object> results = demo.demonstrateHttpHeaders();

        assertThat(results).as("Results should not be null").isNotNull();

        // Verify headers
        assertThat(results.get("content_type")).isEqualTo(MediaType.APPLICATION_JSON);
        assertThat(results.get("content_length")).isEqualTo(1024L);
        assertThat(results.get("custom_header")).isEqualTo("Custom Value");
        assertThat(results.get("cache_control")).as("Should have cache control").isNotNull();

        @SuppressWarnings("unchecked")
        List<MediaType> acceptHeaders = (List<MediaType>) results.get("accept_headers");
        assertThat(acceptHeaders).as("Should accept JSON").contains(MediaType.APPLICATION_JSON);
        assertThat(acceptHeaders).as("Should accept text").contains(MediaType.TEXT_PLAIN);

        @SuppressWarnings("unchecked")
        Map<String, String> allHeaders = (Map<String, String>) results.get("all_headers");
        assertThat(allHeaders).as("Should have all headers map").isNotNull();
        assertThat(allHeaders).as("Should contain content type header").containsKey("Content-Type");
    }

    @Test
    void testWebToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results).as("Should contain UriUtils results").containsKey("UriUtils");
        assertThat(results)
                .as("Should contain UriComponentsBuilder results")
                .containsKey("UriComponentsBuilder");
        assertThat(results).as("Should contain HtmlUtils results").containsKey("HtmlUtils");
        assertThat(results).as("Should contain CacheControl results").containsKey("CacheControl");
        assertThat(results).as("Should contain HttpHeaders results").containsKey("HttpHeaders");

        // Verify each section has expected content
        @SuppressWarnings("unchecked")
        Map<String, Object> uriResults = (Map<String, Object>) results.get("UriUtils");
        assertThat(uriResults.get("original_text")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> builderResults =
                (Map<String, Object>) results.get("UriComponentsBuilder");
        assertThat(builderResults.get("product_uri")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> htmlResults = (Map<String, Object>) results.get("HtmlUtils");
        assertThat(htmlResults.get("dangerous_html")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> cacheResults = (Map<String, Object>) results.get("CacheControl");
        assertThat(cacheResults.get("no_cache")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> headerResults = (Map<String, Object>) results.get("HttpHeaders");
        assertThat(headerResults.get("content_type")).isNotNull();
    }

    @Test
    void testRealWorldWebUseCases() {
        // REST API URL building
        URI apiUrl =
                UriComponentsBuilder.fromHttpUrl("https://api.example.com")
                        .path("/v1/users/{userId}")
                        .queryParam("include", "profile", "preferences")
                        .queryParam("format", "json")
                        .build("12345");

        assertThat(apiUrl.getScheme()).as("Should build HTTPS API URL").isEqualTo("https");
        assertThat(apiUrl.getPath()).as("Should substitute user ID").contains("users/12345");
        assertThat(apiUrl.getQuery())
                .as("Should include profile parameter")
                .contains("include=profile");

        // Security: HTML escaping user content
        String userComment = "<script>alert('hack')</script>Safe content here";
        String safeComment = HtmlUtils.htmlEscape(userComment);

        assertThat(safeComment).as("Should remove dangerous scripts").doesNotContain("<script>");
        assertThat(safeComment).as("Should preserve safe content").contains("Safe content here");

        // HTTP response headers for API
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.setContentType(MediaType.APPLICATION_JSON);
        responseHeaders.setCacheControl(CacheControl.maxAge(5, TimeUnit.MINUTES));
        responseHeaders.add("X-API-Version", "1.0");
        responseHeaders.add("X-Rate-Limit", "1000");

        assertThat(responseHeaders.getContentType()).isEqualTo(MediaType.APPLICATION_JSON);
        assertThat(responseHeaders.getCacheControl()).contains("max-age=300");
        assertThat(responseHeaders.getFirst("X-API-Version")).isEqualTo("1.0");

        // URL encoding for search parameters
        String searchQuery = "search term with spaces & symbols";
        String encodedQuery = UriUtils.encodeQueryParam(searchQuery, StandardCharsets.UTF_8);

        URI searchUrl =
                UriComponentsBuilder.fromHttpUrl("https://search.example.com")
                        .path("/search")
                        .queryParam("q", "{query}")
                        .build(encodedQuery);

        assertThat(searchUrl).as("Should build search URL").isNotNull();
        assertThat(searchUrl.getQuery()).as("Should contain query parameter").contains("q=");
    }
}
