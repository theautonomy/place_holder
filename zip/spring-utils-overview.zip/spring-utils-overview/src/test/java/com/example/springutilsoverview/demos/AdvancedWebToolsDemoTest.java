package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.ContentCachingRequestWrapper;

/**
 * Unit tests demonstrating usage of Spring's Advanced Web utilities. These tests show practical
 * examples of how to use: - WebClient.Builder: Reactive HTTP client configuration -
 * ContentCachingRequestWrapper: Request body caching for filters - WebUtils concepts: Servlet
 * utility functions
 */
class AdvancedWebToolsDemoTest {

    private AdvancedWebToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new AdvancedWebToolsDemo();
    }

    @Test
    void testWebClientBuilder_BasicConfiguration() {
        Map<String, Object> results = demo.demonstrateWebClientBuilder();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.containsKey("error")).as("Should not have errors").isFalse();

        // Verify WebClient configurations
        assertThat(results.get("webclient_1_base_url")).isEqualTo("https://api.github.com");
        assertThat(results.get("webclient_1_description"))
                .isEqualTo("GitHub API client with custom headers");

        assertThat(results.get("webclient_2_base_url"))
                .isEqualTo("https://jsonplaceholder.typicode.com");
        assertThat(results.get("webclient_2_description"))
                .isEqualTo("JSON placeholder with memory limit");

        assertThat(results.get("webclient_3_base_url")).isEqualTo("https://httpbin.org");
        assertThat(results.get("webclient_3_description"))
                .isEqualTo("HTTP testing service with custom headers");

        assertThat(results.get("webclient_4_base_url")).isEqualTo("https://api.example.com");
        assertThat(results.get("webclient_4_description"))
                .isEqualTo("Example API with memory configuration");
    }

    @Test
    void testWebClientBuilder_ConfigurationOptions() {
        Map<String, Object> results = demo.demonstrateWebClientBuilder();

        // Verify builder benefits
        @SuppressWarnings("unchecked")
        List<String> benefits = (List<String>) results.get("builder_benefits");
        assertThat(benefits).as("Builder benefits should not be null").isNotNull();
        assertThat(benefits).contains("Immutable WebClient instances");
        assertThat(benefits).contains("Reusable configuration");
        assertThat(benefits).contains("Fluent API for setup");

        // Verify configuration options
        @SuppressWarnings("unchecked")
        Map<String, Object> configurations =
                (Map<String, Object>) results.get("configuration_options");
        assertThat(configurations).as("Configuration options should not be null").isNotNull();
        assertThat(configurations).containsKey("base_url");
        assertThat(configurations).containsKey("default_headers");
        assertThat(configurations).containsKey("codecs");
    }

    @Test
    void testWebClientBuilder_UsageExamples() {
        Map<String, Object> results = demo.demonstrateWebClientBuilder();

        // Verify usage examples are present
        assertThat(results.get("usage_example_get"))
                .as("GET example should be present")
                .isNotNull();
        assertThat(results.get("usage_example_post"))
                .as("POST example should be present")
                .isNotNull();
        assertThat(results.get("usage_example_exchange"))
                .as("Exchange example should be present")
                .isNotNull();

        // Verify example content
        String getExample = (String) results.get("usage_example_get");
        assertThat(getExample)
                .as("GET example should show correct method")
                .contains("webClient.get()");
        assertThat(getExample).as("GET example should show retrieve method").contains("retrieve()");

        String postExample = (String) results.get("usage_example_post");
        assertThat(postExample)
                .as("POST example should show correct method")
                .contains("webClient.post()");
        assertThat(postExample).as("POST example should show body method").contains("bodyValue");
    }

    @Test
    void testContentCachingRequestWrapper_WithoutRequestContext() {
        // Clear any existing request context
        RequestContextHolder.resetRequestAttributes();

        Map<String, Object> results = demo.demonstrateContentCachingRequestWrapper();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.get("wrapper_created"))
                .as("Wrapper should not be created without context")
                .isEqualTo(false);
        assertThat(results.get("note")).as("Should have explanatory note").isNotNull();
        assertThat(results.get("typical_usage")).as("Should explain typical usage").isNotNull();

        // Verify benefits are listed
        @SuppressWarnings("unchecked")
        List<String> benefits = (List<String>) results.get("benefits");
        assertThat(benefits).as("Benefits should be listed").isNotNull();
        assertThat(benefits).contains("Allows multiple reads of request body");
        assertThat(benefits).contains("Thread-safe implementation");
    }

    @Test
    void testContentCachingRequestWrapper_WithMockRequest() {
        // Create mock request and set up request context
        MockHttpServletRequest mockRequest = new MockHttpServletRequest();
        mockRequest.setMethod("POST");
        mockRequest.setRequestURI("/api/test");
        mockRequest.setContentType("application/json");
        mockRequest.addHeader("Authorization", "Bearer token");
        mockRequest.addParameter("param1", "value1");

        ServletRequestAttributes attributes = new ServletRequestAttributes(mockRequest);
        RequestContextHolder.setRequestAttributes(attributes);

        try {
            Map<String, Object> results = demo.demonstrateContentCachingRequestWrapper();

            assertThat(results).as("Results should not be null").isNotNull();
            assertThat(results.get("wrapper_created"))
                    .as("Wrapper should be created with context")
                    .isEqualTo(true);
            assertThat(results.get("original_method"))
                    .as("Should capture original method")
                    .isEqualTo("POST");
            assertThat(results.get("original_uri"))
                    .as("Should capture original URI")
                    .isEqualTo("/api/test");
            assertThat(results.get("content_type"))
                    .as("Should capture content type")
                    .isEqualTo("application/json");

            // Verify use cases are provided
            @SuppressWarnings("unchecked")
            List<String> useCases = (List<String>) results.get("use_cases");
            assertThat(useCases).as("Use cases should be provided").isNotNull();
            assertThat(useCases).contains("Logging request bodies for debugging");
            assertThat(useCases).contains("Audit trails for API calls");

        } finally {
            RequestContextHolder.resetRequestAttributes();
        }
    }

    @Test
    void testContentCachingRequestWrapper_FilterExample() {
        Map<String, Object> results = demo.demonstrateContentCachingRequestWrapper();

        // Verify filter example is provided
        String filterExample = (String) results.get("filter_example");
        assertThat(filterExample).as("Filter example should be provided").isNotNull();
        assertThat(filterExample)
                .as("Should show wrapper usage")
                .contains("ContentCachingRequestWrapper");
        assertThat(filterExample).as("Should show filter method").contains("doFilter");
        assertThat(filterExample)
                .as("Should show content extraction")
                .contains("getContentAsByteArray");
    }

    @Test
    void testWebUtilsConcepts_CommonMethods() {
        Map<String, Object> results = demo.demonstrateWebUtilsConcepts();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results.get("note"))
                .as("Should have explanatory note about context requirement")
                .isNotNull();

        // Verify common methods are documented
        @SuppressWarnings("unchecked")
        Map<String, String> methods = (Map<String, String>) results.get("common_methods");
        assertThat(methods).as("Common methods should be documented").isNotNull();
        assertThat(methods).containsKey("getCookie(request, name)");
        assertThat(methods).containsKey("getIntParameter(request, name, defaultValue)");
        assertThat(methods).containsKey("getStringParameter(request, name, defaultValue)");
        assertThat(methods).containsKey("getSessionAttribute(request, name)");
    }

    @Test
    void testWebUtilsConcepts_UseCases() {
        Map<String, Object> results = demo.demonstrateWebUtilsConcepts();

        // Verify use cases are provided
        @SuppressWarnings("unchecked")
        List<String> useCases = (List<String>) results.get("use_cases");
        assertThat(useCases).as("Use cases should be provided").isNotNull();
        assertThat(useCases).contains("Safe parameter extraction with defaults");
        assertThat(useCases).contains("Cookie management in controllers");
        assertThat(useCases).contains("Session attribute handling");
    }

    @Test
    void testWebUtilsConcepts_ExampleUsage() {
        Map<String, Object> results = demo.demonstrateWebUtilsConcepts();

        // Verify example usage patterns
        assertThat(results.get("example_cookie_usage"))
                .as("Cookie usage example should be provided")
                .isNotNull();
        assertThat(results.get("example_parameter_usage"))
                .as("Parameter usage example should be provided")
                .isNotNull();
        assertThat(results.get("example_session_usage"))
                .as("Session usage example should be provided")
                .isNotNull();

        // Verify example content
        String cookieExample = (String) results.get("example_cookie_usage");
        assertThat(cookieExample)
                .as("Should show WebUtils cookie method")
                .contains("WebUtils.getCookie");
        assertThat(cookieExample).as("Should show session cookie example").contains("JSESSIONID");

        String paramExample = (String) results.get("example_parameter_usage");
        assertThat(paramExample)
                .as("Should show parameter extraction")
                .contains("WebUtils.getIntParameter");
        assertThat(paramExample).as("Should show parameter name").contains("pageSize");
    }

    @Test
    void testWebUtilsConcepts_BenefitsOverServletAPI() {
        Map<String, Object> results = demo.demonstrateWebUtilsConcepts();

        // Verify benefits over direct servlet API
        @SuppressWarnings("unchecked")
        List<String> benefits = (List<String>) results.get("benefits_over_servlet_api");
        assertThat(benefits).as("Benefits should be listed").isNotNull();
        assertThat(benefits).contains("Null-safe operations");
        assertThat(benefits).contains("Built-in default value support");
        assertThat(benefits).contains("Type conversion utilities");
        assertThat(benefits).contains("Consistent API patterns");
    }

    @Test
    void testAdvancedWebToolsDemo_Integration() {
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results)
                .as("Should contain WebClientBuilder results")
                .containsKey("WebClientBuilder");
        assertThat(results)
                .as("Should contain ContentCachingRequestWrapper results")
                .containsKey("ContentCachingRequestWrapper");
        assertThat(results)
                .as("Should contain WebUtilsConcepts results")
                .containsKey("WebUtilsConcepts");

        // Verify each component has expected data
        @SuppressWarnings("unchecked")
        Map<String, Object> webClientResults =
                (Map<String, Object>) results.get("WebClientBuilder");
        assertThat(webClientResults.get("webclient_1_base_url")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> wrapperResults =
                (Map<String, Object>) results.get("ContentCachingRequestWrapper");
        assertThat(wrapperResults.get("note")).isNotNull();

        @SuppressWarnings("unchecked")
        Map<String, Object> utilsResults = (Map<String, Object>) results.get("WebUtilsConcepts");
        assertThat(utilsResults.get("common_methods")).isNotNull();
    }

    @Test
    void testRealWorldUseCases() {
        // Test WebClient builder pattern for different scenarios
        WebClient githubClient =
                WebClient.builder()
                        .baseUrl("https://api.github.com")
                        .defaultHeader("User-Agent", "MyApp/1.0")
                        .build();

        assertThat(githubClient).as("GitHub client should be created").isNotNull();

        WebClient apiClient =
                WebClient.builder()
                        .baseUrl("https://api.example.com")
                        .defaultHeader("Content-Type", "application/json")
                        .codecs(
                                configurer ->
                                        configurer.defaultCodecs().maxInMemorySize(1024 * 1024))
                        .build();

        assertThat(apiClient).as("API client should be created").isNotNull();

        // Test ContentCachingRequestWrapper functionality with mock
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setMethod("POST");
        request.setContent("{\"key\":\"value\"}".getBytes());
        request.setContentType("application/json");

        ContentCachingRequestWrapper wrapper = new ContentCachingRequestWrapper(request);
        assertThat(wrapper).as("Wrapper should be created").isNotNull();
        assertThat(wrapper.getMethod()).as("Should preserve request method").isEqualTo("POST");
        assertThat(wrapper.getContentType())
                .as("Should preserve content type")
                .isEqualTo("application/json");
    }
}
