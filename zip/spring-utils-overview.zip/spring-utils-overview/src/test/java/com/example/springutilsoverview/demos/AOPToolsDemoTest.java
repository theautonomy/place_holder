package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;

/**
 * Unit tests demonstrating usage of Spring's AOP utilities. These tests show practical examples of
 * how to use: - AopUtils: AOP proxy detection and analysis - ProxyFactory: Programmatic proxy
 * creation - ClassPathScanningCandidateComponentProvider: Component scanning
 */
class AOPToolsDemoTest {

    private AOPToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new AOPToolsDemo();
    }

    @Test
    void testAopUtils_ProxyDetection() {
        // Create a regular object
        AOPToolsDemo.SampleService regularService = new AOPToolsDemo.SampleService();

        // Verify it's not a proxy
        assertThat(AopUtils.isAopProxy(regularService))
                .as("Regular object should not be AOP proxy")
                .isFalse();
        assertThat(AopUtils.isJdkDynamicProxy(regularService))
                .as("Regular object should not be JDK proxy")
                .isFalse();
        assertThat(AopUtils.isCglibProxy(regularService))
                .as("Regular object should not be CGLIB proxy")
                .isFalse();

        // Create a proxy
        ProxyFactory proxyFactory = new ProxyFactory(regularService);
        proxyFactory.addAdvice(new TestLoggingInterceptor());
        Object proxy = proxyFactory.getProxy();

        // Verify it is a proxy
        assertThat(AopUtils.isAopProxy(proxy)).as("Proxied object should be AOP proxy").isTrue();
        // Note: The specific proxy type (JDK vs CGLIB) depends on whether interfaces are used
    }

    @Test
    void testAopUtils_TargetClassResolution() {
        AOPToolsDemo.SampleService service = new AOPToolsDemo.SampleService();

        // Get target class from regular object
        Class<?> regularTargetClass = AopUtils.getTargetClass(service);
        assertThat(regularTargetClass)
                .as("Target class of regular object should be itself")
                .isEqualTo(AOPToolsDemo.SampleService.class);

        // Create proxy and get target class
        ProxyFactory proxyFactory = new ProxyFactory(service);
        proxyFactory.addAdvice(new TestLoggingInterceptor());
        Object proxy = proxyFactory.getProxy();

        Class<?> proxyTargetClass = AopUtils.getTargetClass(proxy);
        assertThat(proxyTargetClass)
                .as("Target class of proxy should be the original class")
                .isEqualTo(AOPToolsDemo.SampleService.class);

        // Both should be the same
        assertThat(regularTargetClass)
                .as("Target class should be consistent")
                .isEqualTo(proxyTargetClass);
    }

    @Test
    void testProxyFactory_InterfaceBasedProxy() {
        AOPToolsDemo.SampleService target = new AOPToolsDemo.SampleService();
        TestLoggingInterceptor interceptor = new TestLoggingInterceptor();

        // Create interface-based proxy
        ProxyFactory factory = new ProxyFactory();
        factory.setTarget(target);
        factory.addInterface(AOPToolsDemo.SampleServiceInterface.class);
        factory.addAdvice(interceptor);

        AOPToolsDemo.SampleServiceInterface proxy =
                (AOPToolsDemo.SampleServiceInterface) factory.getProxy();

        // Test proxy functionality
        String result = proxy.processData("test");
        assertThat(result).as("Proxy should delegate to target").isEqualTo("Processed: test");

        // Verify interception occurred
        assertThat(interceptor.getInvocationCount())
                .as("Interceptor should have been called")
                .isEqualTo(1);
        assertThat(interceptor.getLastMethodName())
                .as("Should have intercepted processData")
                .isEqualTo("processData");
    }

    @Test
    void testProxyFactory_ClassBasedProxy() {
        AOPToolsDemo.SampleService target = new AOPToolsDemo.SampleService();
        TestLoggingInterceptor interceptor = new TestLoggingInterceptor();

        // Create class-based (CGLIB) proxy
        ProxyFactory factory = new ProxyFactory();
        factory.setTarget(target);
        factory.setProxyTargetClass(true); // Force CGLIB
        factory.addAdvice(interceptor);

        AOPToolsDemo.SampleService proxy = (AOPToolsDemo.SampleService) factory.getProxy();

        // Test proxy functionality
        String result = proxy.processData("cglib-test");
        assertThat(result)
                .as("CGLIB proxy should delegate to target")
                .isEqualTo("Processed: cglib-test");

        // Test additional method
        String additionalResult = proxy.additionalMethod("extra");
        assertThat(additionalResult)
                .as("CGLIB proxy should support all methods")
                .isEqualTo("Additional: extra");

        // Verify interception
        assertThat(interceptor.getInvocationCount())
                .as("Both methods should have been intercepted")
                .isEqualTo(2);
    }

    @Test
    void testProxyFactory_MultipleAdvice() {
        AOPToolsDemo.SampleService target = new AOPToolsDemo.SampleService();
        TestLoggingInterceptor logger = new TestLoggingInterceptor();
        TestPerformanceInterceptor performance = new TestPerformanceInterceptor();

        // Create proxy with multiple interceptors
        ProxyFactory factory = new ProxyFactory();
        factory.setTarget(target);
        factory.addAdvice(logger);
        factory.addAdvice(performance);

        AOPToolsDemo.SampleServiceInterface proxy =
                (AOPToolsDemo.SampleServiceInterface) factory.getProxy();

        // Invoke method
        String result = proxy.processData("multi-advice");
        assertThat(result)
                .as("Multi-advice proxy should work correctly")
                .isEqualTo("Processed: multi-advice");

        // Verify all interceptors were called
        assertThat(logger.getInvocationCount()).as("Logger should have been called").isEqualTo(1);
        assertThat(performance.getInvocationCount())
                .as("Performance interceptor should have been called")
                .isEqualTo(1);
    }

    @Test
    void testProxyFactory_AdviceChainOrder() {
        AOPToolsDemo.SampleService target = new AOPToolsDemo.SampleService();
        TestOrderedInterceptor first = new TestOrderedInterceptor("FIRST");
        TestOrderedInterceptor second = new TestOrderedInterceptor("SECOND");

        ProxyFactory factory = new ProxyFactory();
        factory.setTarget(target);
        factory.addAdvice(first);
        factory.addAdvice(second);

        AOPToolsDemo.SampleServiceInterface proxy =
                (AOPToolsDemo.SampleServiceInterface) factory.getProxy();

        proxy.processData("order-test");

        // Verify execution order
        List<String> executionOrder = TestOrderedInterceptor.getExecutionOrder();
        assertThat(executionOrder)
                .as("Should have before/after for both interceptors")
                .hasSizeGreaterThanOrEqualTo(4);

        // First interceptor should be called first (outer)
        assertThat(executionOrder.get(0))
                .as("First interceptor should execute first")
                .contains("FIRST");
        assertThat(executionOrder.get(1))
                .as("Second interceptor should execute second")
                .contains("SECOND");

        TestOrderedInterceptor.clearExecutionOrder();
    }

    @Test
    void testClassPathScanningCandidateComponentProvider_DefaultScanning() {
        ClassPathScanningCandidateComponentProvider scanner =
                new ClassPathScanningCandidateComponentProvider(true);

        // Scan the current package
        Set<BeanDefinition> components =
                scanner.findCandidateComponents("com.example.springutilsoverview.demos");

        assertThat(components).as("Should find components in the demos package").isNotEmpty();

        // Verify we find our demo classes (they are annotated with @Component)
        boolean foundAOPDemo =
                components.stream()
                        .anyMatch(
                                bd ->
                                        bd.getBeanClassName() != null
                                                && bd.getBeanClassName().contains("AOPToolsDemo"));

        assertThat(foundAOPDemo).as("Should find AOPToolsDemo component").isTrue();
    }

    @Test
    void testClassPathScanningCandidateComponentProvider_CustomFiltering() {
        // Scanner with no default filters
        ClassPathScanningCandidateComponentProvider scanner =
                new ClassPathScanningCandidateComponentProvider(false);

        // Add custom filter for @Component classes only
        scanner.addIncludeFilter(new AnnotationTypeFilter(Component.class));

        Set<BeanDefinition> components =
                scanner.findCandidateComponents("com.example.springutilsoverview.demos");

        assertThat(components).as("Should find @Component annotated classes").isNotEmpty();

        // All found components should be @Component annotated
        for (BeanDefinition bd : components) {
            String className = bd.getBeanClassName();
            if (className != null) {
                try {
                    Class<?> clazz = Class.forName(className);
                    assertThat(
                                    clazz.isAnnotationPresent(Component.class)
                                            || clazz.isAnnotationPresent(
                                                    org.springframework.stereotype.Service.class)
                                            || clazz.isAnnotationPresent(
                                                    org.springframework.stereotype.Repository.class)
                                            || clazz.isAnnotationPresent(
                                                    org.springframework.stereotype.Controller
                                                            .class))
                            .as("Found class should have Spring stereotype annotation")
                            .isTrue();
                } catch (ClassNotFoundException e) {
                    // Skip if class cannot be loaded
                }
            }
        }
    }

    @Test
    void testClassPathScanningCandidateComponentProvider_SpecificAnnotation() {
        // Scanner for @Component only (not its derivatives)
        ClassPathScanningCandidateComponentProvider scanner =
                new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(
                new AnnotationTypeFilter(Component.class, false)); // false = exact match

        Set<BeanDefinition> components =
                scanner.findCandidateComponents("com.example.springutilsoverview.demos");

        // Should find components (our demo classes are annotated with @Component)
        assertThat(components).as("Should find @Component classes").isNotEmpty();
    }

    @Test
    void testAOPToolsDemo_Integration() {
        // Test the complete demonstration
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results).as("Should contain AopUtils results").containsKey("AopUtils");
        assertThat(results).as("Should contain ProxyFactory results").containsKey("ProxyFactory");
        assertThat(results)
                .as("Should contain ClassPathScanningCandidateComponentProvider results")
                .containsKey("ClassPathScanningCandidateComponentProvider");

        // Verify AopUtils results
        @SuppressWarnings("unchecked")
        Map<String, Object> aopUtilsResults = (Map<String, Object>) results.get("AopUtils");
        assertThat((Boolean) aopUtilsResults.get("original_is_proxy"))
                .as("Original object should not be proxy")
                .isFalse();
        assertThat((Boolean) aopUtilsResults.get("proxy_is_aop_proxy"))
                .as("Proxy should be AOP proxy")
                .isTrue();
        assertThat((Boolean) aopUtilsResults.get("results_match"))
                .as("Proxy and original should produce same results")
                .isTrue();

        // Verify ProxyFactory results
        @SuppressWarnings("unchecked")
        Map<String, Object> proxyFactoryResults = (Map<String, Object>) results.get("ProxyFactory");
        assertThat((Boolean) proxyFactoryResults.get("interface_proxy_created"))
                .as("Interface proxy should be created")
                .isTrue();
        assertThat((Boolean) proxyFactoryResults.get("cglib_proxy_created"))
                .as("CGLIB proxy should be created")
                .isTrue();
        assertThat((Boolean) proxyFactoryResults.get("multi_advice_proxy_created"))
                .as("Multi-advice proxy should be created")
                .isTrue();
    }

    @Test
    void testRealWorldAOPUseCases() {
        // Transaction management simulation
        AOPToolsDemo.SampleService service = new AOPToolsDemo.SampleService();
        TestTransactionInterceptor txInterceptor = new TestTransactionInterceptor();

        ProxyFactory factory = new ProxyFactory();
        factory.setTarget(service);
        factory.addAdvice(txInterceptor);

        AOPToolsDemo.SampleServiceInterface proxy =
                (AOPToolsDemo.SampleServiceInterface) factory.getProxy();

        // Simulate transactional method call
        proxy.processData("transaction-test");

        assertThat(txInterceptor.wasTransactionStarted())
                .as("Transaction should have been started")
                .isTrue();
        assertThat(txInterceptor.wasTransactionCommitted())
                .as("Transaction should have been committed")
                .isTrue();

        // Security check simulation
        TestSecurityInterceptor securityInterceptor = new TestSecurityInterceptor();
        ProxyFactory secureFactory = new ProxyFactory();
        secureFactory.setTarget(service);
        secureFactory.addAdvice(securityInterceptor);

        AOPToolsDemo.SampleServiceInterface secureProxy =
                (AOPToolsDemo.SampleServiceInterface) secureFactory.getProxy();

        secureProxy.processData("security-test");
        assertThat(securityInterceptor.wasSecurityCheckPerformed())
                .as("Security check should have been performed")
                .isTrue();

        // Caching simulation
        TestCacheInterceptor cacheInterceptor = new TestCacheInterceptor();
        ProxyFactory cacheFactory = new ProxyFactory();
        cacheFactory.setTarget(service);
        cacheFactory.addAdvice(cacheInterceptor);

        AOPToolsDemo.SampleServiceInterface cacheProxy =
                (AOPToolsDemo.SampleServiceInterface) cacheFactory.getProxy();

        // First call should miss cache
        String result1 = cacheProxy.processData("cache-test");
        assertThat(result1).isEqualTo("Processed: cache-test");
        assertThat(cacheInterceptor.wasCacheMiss()).as("First call should be cache miss").isTrue();

        // Second call should hit cache
        String result2 = cacheProxy.processData("cache-test");
        assertThat(result2).isEqualTo("Processed: cache-test");
        assertThat(cacheInterceptor.wasCacheHit()).as("Second call should be cache hit").isTrue();
    }

    // Test helper classes
    private static class TestLoggingInterceptor implements MethodInterceptor {
        private int invocationCount = 0;
        private String lastMethodName;

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            invocationCount++;
            lastMethodName = invocation.getMethod().getName();
            return invocation.proceed();
        }

        public int getInvocationCount() {
            return invocationCount;
        }

        public String getLastMethodName() {
            return lastMethodName;
        }
    }

    private static class TestPerformanceInterceptor implements MethodInterceptor {
        private int invocationCount = 0;

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            invocationCount++;
            long start = System.nanoTime();
            try {
                return invocation.proceed();
            } finally {
                long duration = System.nanoTime() - start;
                // In real scenario, you might log this
            }
        }

        public int getInvocationCount() {
            return invocationCount;
        }
    }

    private static class TestOrderedInterceptor implements MethodInterceptor {
        private static final List<String> executionOrder = new ArrayList<>();
        private final String name;

        public TestOrderedInterceptor(String name) {
            this.name = name;
        }

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            executionOrder.add(name + "_BEFORE");
            try {
                Object result = invocation.proceed();
                executionOrder.add(name + "_AFTER_SUCCESS");
                return result;
            } catch (Exception e) {
                executionOrder.add(name + "_AFTER_EXCEPTION");
                throw e;
            }
        }

        public static List<String> getExecutionOrder() {
            return new ArrayList<>(executionOrder);
        }

        public static void clearExecutionOrder() {
            executionOrder.clear();
        }
    }

    private static class TestTransactionInterceptor implements MethodInterceptor {
        private boolean transactionStarted = false;
        private boolean transactionCommitted = false;

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            transactionStarted = true;
            try {
                Object result = invocation.proceed();
                transactionCommitted = true;
                return result;
            } catch (Exception e) {
                // In real scenario, rollback would happen here
                throw e;
            }
        }

        public boolean wasTransactionStarted() {
            return transactionStarted;
        }

        public boolean wasTransactionCommitted() {
            return transactionCommitted;
        }
    }

    private static class TestSecurityInterceptor implements MethodInterceptor {
        private boolean securityCheckPerformed = false;

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            securityCheckPerformed = true;
            // In real scenario, security checks would happen here
            return invocation.proceed();
        }

        public boolean wasSecurityCheckPerformed() {
            return securityCheckPerformed;
        }
    }

    private static class TestCacheInterceptor implements MethodInterceptor {
        private final Map<String, Object> cache = new java.util.HashMap<>();
        private boolean cacheMiss = false;
        private boolean cacheHit = false;

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            String key =
                    invocation.getMethod().getName()
                            + "_"
                            + java.util.Arrays.toString(invocation.getArguments());

            if (cache.containsKey(key)) {
                cacheHit = true;
                return cache.get(key);
            } else {
                cacheMiss = true;
                Object result = invocation.proceed();
                cache.put(key, result);
                return result;
            }
        }

        public boolean wasCacheMiss() {
            return cacheMiss;
        }

        public boolean wasCacheHit() {
            return cacheHit;
        }
    }
}
