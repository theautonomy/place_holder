package com.example.springutilsoverview.demos;

import static org.assertj.core.api.Assertions.*;

import java.util.*;
import java.util.concurrent.ConcurrentMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ConcurrentReferenceHashMap;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.SystemPropertyUtils;

/**
 * Unit tests demonstrating usage of Spring's Collection and Array utilities. These tests show
 * practical examples of how to use: - CollectionUtils: Safe collection operations - MultiValueMap:
 * Maps with multiple values per key - ConcurrentReferenceHashMap: Thread-safe cache with soft
 * references - SystemPropertyUtils: System property resolution
 */
class CollectionToolsDemoTest {

    private CollectionToolsDemo demo;

    @BeforeEach
    void setUp() {
        demo = new CollectionToolsDemo();
    }

    @Test
    void testCollectionUtils_EmptyChecks() {
        // Test null collections
        assertThat(CollectionUtils.isEmpty((Collection<?>) null))
                .as("Null collection should be empty")
                .isTrue();

        // Test empty collections
        assertThat(CollectionUtils.isEmpty(Collections.emptyList()))
                .as("Empty list should be empty")
                .isTrue();
        assertThat(CollectionUtils.isEmpty(Collections.emptySet()))
                .as("Empty set should be empty")
                .isTrue();

        // Test non-empty collections
        assertThat(CollectionUtils.isEmpty(Arrays.asList("item")))
                .as("Non-empty list should not be empty")
                .isFalse();
        assertThat(CollectionUtils.isEmpty(Set.of("item")))
                .as("Non-empty set should not be empty")
                .isFalse();
    }

    @Test
    void testCollectionUtils_MapChecks() {
        // Test null maps
        assertThat(CollectionUtils.isEmpty((Map<?, ?>) null))
                .as("Null map should be empty")
                .isTrue();

        // Test empty maps
        assertThat(CollectionUtils.isEmpty(Collections.emptyMap()))
                .as("Empty map should be empty")
                .isTrue();

        // Test non-empty maps
        Map<String, String> map = Map.of("key", "value");
        assertThat(CollectionUtils.isEmpty(map)).as("Non-empty map should not be empty").isFalse();
    }

    @Test
    void testCollectionUtils_ContainsOperations() {
        List<String> list1 = Arrays.asList("a", "b", "c");
        List<String> list2 = Arrays.asList("b", "c", "d");
        List<String> list3 = Arrays.asList("x", "y", "z");

        // Test containsAny
        assertThat(CollectionUtils.containsAny(list1, list2))
                .as("Should find common elements between list1 and list2")
                .isTrue();
        assertThat(CollectionUtils.containsAny(list1, list3))
                .as("Should not find common elements between list1 and list3")
                .isFalse();

        // Test with empty collections
        assertThat(CollectionUtils.containsAny(list1, Collections.emptyList()))
                .as("Should not contain any elements from empty list")
                .isFalse();
        assertThat(CollectionUtils.containsAny(Collections.emptyList(), list1))
                .as("Empty list should not contain any elements")
                .isFalse();
    }

    @Test
    void testCollectionUtils_FindCommonElements() {
        List<String> list1 = Arrays.asList("a", "b", "c", "d");
        List<String> list2 = Arrays.asList("c", "d", "e", "f");

        // Manual intersection (since CollectionUtils.intersection doesn't exist in newer versions)
        Set<String> intersection = new HashSet<>(list1);
        intersection.retainAll(list2);

        assertThat(intersection).as("Should find 2 common elements").hasSize(2);
        assertThat(intersection).as("Should contain 'c'").contains("c");
        assertThat(intersection).as("Should contain 'd'").contains("d");
    }

    @Test
    void testMultiValueMap_BasicOperations() {
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        // Add multiple values for same key
        map.add("colors", "red");
        map.add("colors", "blue");
        map.add("colors", "green");
        map.add("sizes", "large");
        map.add("sizes", "medium");

        // Test getting all values
        List<String> colors = map.get("colors");
        assertThat(colors).as("Should have 3 colors").hasSize(3);
        assertThat(colors).contains("red");
        assertThat(colors).contains("blue");
        assertThat(colors).contains("green");

        // Test getting first value
        assertThat(map.getFirst("colors")).as("First color should be red").isEqualTo("red");
        assertThat(map.getFirst("sizes")).as("First size should be large").isEqualTo("large");
    }

    @Test
    void testMultiValueMap_SetOperations() {
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        // Test set operation (replaces all values)
        map.set("fruits", "apple");
        assertThat(map.get("fruits")).as("Should have 1 fruit after set").hasSize(1);
        assertThat(map.getFirst("fruits")).as("Should be apple").isEqualTo("apple");

        // Add more values
        map.add("fruits", "banana");
        assertThat(map.get("fruits")).as("Should have 2 fruits after add").hasSize(2);

        // Set replaces all
        map.set("fruits", "orange");
        assertThat(map.get("fruits")).as("Should have 1 fruit after second set").hasSize(1);
        assertThat(map.getFirst("fruits")).as("Should be orange").isEqualTo("orange");
    }

    @Test
    void testMultiValueMap_HttpHeadersUseCase() {
        // Simulate HTTP headers which commonly have multiple values
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        headers.add("Accept", "application/json");
        headers.add("Accept", "application/xml");
        headers.add("Cache-Control", "no-cache");
        headers.add("Cache-Control", "no-store");

        // Test HTTP header retrieval
        List<String> acceptHeaders = headers.get("Accept");
        assertThat(acceptHeaders).as("Should have 2 Accept headers").hasSize(2);
        assertThat(acceptHeaders).contains("application/json");
        assertThat(acceptHeaders).contains("application/xml");

        // Get first accept type
        assertThat(headers.getFirst("Accept"))
                .as("First Accept header should be JSON")
                .isEqualTo("application/json");
    }

    @Test
    void testConcurrentReferenceHashMap_BasicOperations() {
        ConcurrentMap<String, Object> cache = new ConcurrentReferenceHashMap<>();

        // Test basic put/get operations
        cache.put("key1", "value1");
        cache.put("key2", 42);
        cache.put("key3", Arrays.asList("a", "b", "c"));

        assertThat(cache.get("key1")).as("Should retrieve string value").isEqualTo("value1");
        assertThat(cache.get("key2")).as("Should retrieve integer value").isEqualTo(42);

        @SuppressWarnings("unchecked")
        List<String> list = (List<String>) cache.get("key3");
        assertThat(list).as("Should retrieve list with 3 elements").hasSize(3);
    }

    @Test
    void testConcurrentReferenceHashMap_ConcurrentAccess() {
        ConcurrentMap<String, Integer> cache = new ConcurrentReferenceHashMap<>();

        // Test thread-safe operations
        cache.put("counter", 0);

        // Simulate concurrent increment (atomic operation)
        Integer oldValue = cache.replace("counter", 1);
        assertThat(oldValue).as("Should return old value").isEqualTo(0);
        assertThat(cache.get("counter")).as("Should have new value").isEqualTo(1);

        // Test putIfAbsent
        Integer existing = cache.putIfAbsent("counter", 999);
        assertThat(existing).as("Should return existing value").isEqualTo(1);
        assertThat(cache.get("counter")).as("Value should not change").isEqualTo(1);

        Integer newValue = cache.putIfAbsent("new-key", 42);
        assertThat(newValue).as("Should return null for new key").isNull();
        assertThat(cache.get("new-key")).as("Should have new value").isEqualTo(42);
    }

    @Test
    void testConcurrentReferenceHashMap_CacheUseCase() {
        ConcurrentMap<String, String> userCache = new ConcurrentReferenceHashMap<>();

        // Simulate user data caching
        String userId = "user123";
        String userData = "John Doe - john@example.com";

        // Cache miss - compute and cache
        String cachedData =
                userCache.computeIfAbsent(
                        userId,
                        key -> {
                            // Simulate expensive database lookup
                            return userData;
                        });

        assertThat(cachedData).as("Should return computed data").isEqualTo(userData);
        assertThat(userCache.get(userId)).as("Should be cached").isEqualTo(userData);

        // Cache hit - return cached value
        String hitData =
                userCache.computeIfAbsent(
                        userId,
                        key -> {
                            fail("Should not compute again - cache hit expected");
                            return null;
                        });

        assertThat(hitData).as("Should return cached data").isEqualTo(userData);
    }

    @Test
    void testSystemPropertyUtils_BasicResolution() {
        // Test resolving existing system properties
        String javaHome = SystemPropertyUtils.resolvePlaceholders("${java.home}");
        assertThat(javaHome).as("Java home should be resolved").isNotNull();
        assertThat(javaHome).as("Should not contain placeholder syntax").doesNotContain("${");

        String javaVersion = SystemPropertyUtils.resolvePlaceholders("${java.version}");
        assertThat(javaVersion).as("Java version should be resolved").isNotNull();
        assertThat(javaVersion).as("Should start with version number").matches("\\d+.*");
    }

    @Test
    void testSystemPropertyUtils_DefaultValues() {
        // Test with default values for missing properties
        String unknown =
                SystemPropertyUtils.resolvePlaceholders("${unknown.property:default_value}");
        assertThat(unknown)
                .as("Should use default value for unknown property")
                .isEqualTo("default_value");

        String appName = SystemPropertyUtils.resolvePlaceholders("${app.name:Spring Utils Demo}");
        assertThat(appName).as("Should use default app name").isEqualTo("Spring Utils Demo");

        // Test without default (should throw exception)
        assertThatThrownBy(() -> SystemPropertyUtils.resolvePlaceholders("${missing.property}"))
                .as("Should throw exception for missing property without default")
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testSystemPropertyUtils_NestedResolution() {
        // Set a temporary system property for testing
        System.setProperty("test.env", "development");
        System.setProperty("test.db.development", "dev-database");

        try {
            String resolved = SystemPropertyUtils.resolvePlaceholders("${test.db.${test.env}}");
            assertThat(resolved).as("Should resolve nested placeholders").isEqualTo("dev-database");
        } finally {
            // Clean up test properties
            System.clearProperty("test.env");
            System.clearProperty("test.db.development");
        }
    }

    @Test
    void testSystemPropertyUtils_ConfigurationUseCase() {
        // Simulate application configuration
        System.setProperty("server.port", "8080");
        System.setProperty("server.host", "localhost");

        try {
            String serverUrl =
                    SystemPropertyUtils.resolvePlaceholders(
                            "http://${server.host}:${server.port}/api");
            assertThat(serverUrl)
                    .as("Should resolve server URL from system properties")
                    .isEqualTo("http://localhost:8080/api");

            // With defaults for missing properties
            String dbUrl =
                    SystemPropertyUtils.resolvePlaceholders(
                            "${db.host:localhost}:${db.port:5432}/${db.name:myapp}");
            assertThat(dbUrl)
                    .as("Should use default values for missing DB properties")
                    .isEqualTo("localhost:5432/myapp");
        } finally {
            System.clearProperty("server.port");
            System.clearProperty("server.host");
        }
    }

    @Test
    void testCollectionToolsDemo_Integration() {
        // Test the complete demonstration
        Map<String, Object> results = demo.demonstrateAll();

        assertThat(results).as("Results should not be null").isNotNull();
        assertThat(results)
                .as("Should contain CollectionUtils results")
                .containsKey("CollectionUtils");
        assertThat(results).as("Should contain MultiValueMap results").containsKey("MultiValueMap");
        assertThat(results)
                .as("Should contain ConcurrentReferenceHashMap results")
                .containsKey("ConcurrentReferenceHashMap");
        assertThat(results)
                .as("Should contain SystemPropertyUtils results")
                .containsKey("SystemPropertyUtils");

        // Verify CollectionUtils results
        @SuppressWarnings("unchecked")
        Map<String, Object> collectionResults =
                (Map<String, Object>) results.get("CollectionUtils");
        assertThat((Boolean) collectionResults.get("isEmpty_null")).isTrue();
        assertThat((Boolean) collectionResults.get("containsAny")).isTrue();

        // Verify MultiValueMap results
        @SuppressWarnings("unchecked")
        Map<String, Object> multiValueResults = (Map<String, Object>) results.get("MultiValueMap");
        assertThat(multiValueResults.get("first_color")).isEqualTo("red");

        @SuppressWarnings("unchecked")
        List<String> allColors = (List<String>) multiValueResults.get("all_colors");
        assertThat(allColors).hasSize(3);
    }

    @Test
    void testRealWorldUseCases() {
        // Form data processing with MultiValueMap
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("interests", "programming");
        formData.add("interests", "music");
        formData.add("interests", "sports");
        formData.add("email", "user@example.com");

        List<String> interests = formData.get("interests");
        assertThat(interests).as("Should handle multiple form values").hasSize(3);

        // Safe collection operations
        List<String> potentiallyNull = null;
        if (!CollectionUtils.isEmpty(potentiallyNull)) {
            fail("Should handle null collections safely");
        }

        // Caching expensive operations
        ConcurrentMap<String, String> cache = new ConcurrentReferenceHashMap<>();
        String expensiveResult =
                cache.computeIfAbsent(
                        "computation",
                        key -> {
                            // Simulate expensive computation
                            return "computed_result_" + System.currentTimeMillis();
                        });

        assertThat(expensiveResult).as("Should cache computation result").isNotNull();
        assertThat(expensiveResult).startsWith("computed_result_");
    }
}
