# Spring Framework - 49+ Essential Utility Classes Demo

This comprehensive Spring Boot application demonstrates the usage of **49+ essential utility classes** mentioned in the Medium article "Mastering Spring Boot: 49 Essential Utility Classes You Should Know" by Umesh Kumar Yadav.

## 🚀 Overview

The Spring Framework provides numerous utility classes that can dramatically simplify daily development. This project showcases practical examples of these utilities organized into **13 logical categories** with working code examples, best practices, and real-world use cases.

## 📚 Complete Utility Categories Covered

### 1. String Processing Tools (4 utilities)
- **StringUtils** - Comprehensive string manipulation utilities
- **AntPathMatcher** - Ant-style path pattern matching
- **PatternMatchUtils** - Simple wildcard pattern matching
- **PropertyPlaceholderHelper** - Property placeholder resolution

### 2. Collection and Array Tools (4 utilities)
- **CollectionUtils** - Collection manipulation utilities
- **MultiValueMap** - Map allowing multiple values per key
- **ConcurrentReferenceHashMap** - Thread-safe cache with soft references
- **SystemPropertyUtils** - System property resolution

### 3. Reflection and Class Manipulation Tools (4 utilities)
- **ReflectionUtils** - Low-level reflection utilities
- **ClassUtils** - Class inspection utilities
- **MethodInvoker** - Method invocation utilities
- **BeanUtils** - Bean property manipulation

### 4. Web-Related Tools (5 utilities)
- **UriUtils** - URI encoding/decoding utilities
- **UriComponentsBuilder** - URI construction utilities
- **HtmlUtils** - HTML escaping utilities for XSS prevention
- **CacheControl** - HTTP Cache-Control header builder
- **HttpHeaders** - HTTP header manipulation

### 5. Security-Related Tools (3 utilities)
- **DigestUtils** - Message digest (hashing) utilities
- **Base64Utils** - Base64 encoding/decoding
- **TextEncryptor** - Text encryption/decryption (requires spring-security-crypto)

### 6. Utility Tools (7 utilities)
- **Assert** - Assertion utilities for validation
- **ObjectUtils** - Object manipulation utilities
- **NumberUtils** - Number parsing and conversion
- **StopWatch** - Performance timing utilities
- **JsonParser** - Simple JSON parsing
- **CompletableFuture** - Asynchronous programming utilities
- **AnnotationUtils** - Annotation introspection utilities

### 7. I/O and Resource Tools (5 utilities)
- **FileCopyUtils** - File and stream copying utilities
- **ResourceUtils** - Resource location resolution
- **StreamUtils** - Stream manipulation utilities
- **FileSystemUtils** - File system operations
- **ResourcePatternUtils** - Resource pattern matching

### 8. Date and Time Tools (2 utilities + alternatives)
- **DateFormatter** - Date formatting utilities
- **StopWatch** - Advanced performance timing
- **Modern Java 8+ Alternatives** - LocalDateTime, DateTimeFormatter

### 9. Data Conversion Tools (4 utilities)
- **ResolvableType** - Generic type resolution
- **MappingJackson2HttpMessageConverter** - JSON message conversion
- **MediaTypeFactory** - MIME type detection
- **MimeTypeUtils** - MIME type utilities

### 10. Advanced Web Tools (3 utilities)
- **WebClient.Builder** - Modern HTTP client builder
- **ContentCachingRequestWrapper** - Request body caching
- **WebUtils** - Web utility concepts

### 11. Spring Context Tools (4 utilities)
- **ApplicationEventPublisher** - Event publishing
- **LocaleContextHolder** - Locale management
- **DefaultConversionService** - Type conversion
- **PropertySourceUtils** - Property source management

### 12. AOP Tools (3 utilities)
- **AopUtils** - AOP proxy utilities
- **ProxyFactory** - Programmatic proxy creation
- **ClassPathScanningCandidateComponentProvider** - Component scanning

### 13. Configuration Tools (3+ utilities)
- **YamlPropertiesFactoryBean** - YAML configuration loading
- **RandomStringUtils** - Random string generation (Apache Commons)
- **Additional Spring Utilities** - Environment, PropertySource, etc.

## 🛠 Getting Started

### Prerequisites
- Java 17 or higher
- Maven 3.6 or higher

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd spring-utils-overview
```

2. Build the project:
```bash
mvn clean install
```

3. Run the application:
```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

## 🌐 API Endpoints

### Main Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/demos` | List all available demonstrations |
| `GET /api/demos/all` | Run all 49+ utility demonstrations |

### Category-Specific Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/demos/string` | String processing utilities demo |
| `GET /api/demos/collection` | Collection and array utilities demo |
| `GET /api/demos/reflection` | Reflection utilities demo |
| `GET /api/demos/web` | Web-related utilities demo |
| `GET /api/demos/security` | Security utilities demo |
| `GET /api/demos/utility` | General utility tools demo |
| `GET /api/demos/io-resource` | I/O and resource utilities demo |
| `GET /api/demos/datetime` | Date and time utilities demo |
| `GET /api/demos/data-conversion` | Data conversion utilities demo |
| `GET /api/demos/advanced-web` | Advanced web utilities demo |
| `GET /api/demos/spring-context` | Spring context utilities demo |
| `GET /api/demos/aop` | AOP utilities demo |
| `GET /api/demos/configuration` | Configuration utilities demo |

## 🔧 Usage Examples

### Using curl to test endpoints:

```bash
# List all available demos
curl http://localhost:8080/api/demos

# Test string processing utilities
curl http://localhost:8080/api/demos/string

# Test all utilities
curl http://localhost:8080/api/demos/all
```

### Example Response Structure:

```json
{
  "category": "String Processing Tools",
  "description": "Demonstrations of Spring's string manipulation utilities",
  "utilities": ["StringUtils", "AntPathMatcher", "PatternMatchUtils", "PropertyPlaceholderHelper"],
  "results": {
    "StringUtils": {
      "isEmpty_null": true,
      "isEmpty_empty": true,
      "hasText_whitespace": false,
      "hasText_hello": true,
      "tokenized": ["a", "b", "c"],
      "trimmed": "hello world",
      "capitalized": "Hello"
    }
    // ... more results
  }
}
```

## 📖 Key Learning Points & Examples

### String Processing
```java
// StringUtils - Comprehensive string operations
boolean isEmpty = StringUtils.isEmpty(text);
boolean hasText = StringUtils.hasText(text);
String[] tokens = StringUtils.tokenizeToStringArray("a,b,c", ",");

// AntPathMatcher - URL/path pattern matching
AntPathMatcher matcher = new AntPathMatcher();
boolean match = matcher.match("/users/*", "/users/123"); // true
Map<String, String> vars = matcher.extractUriTemplateVariables("/users/{id}", "/users/42");
```

### Collection Operations
```java
// CollectionUtils - Safe collection operations
boolean isEmpty = CollectionUtils.isEmpty(collection);
Collection<String> intersection = CollectionUtils.intersection(list1, list2);

// MultiValueMap - Multiple values per key
MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
map.add("colors", "red");
map.add("colors", "blue");
```

### Reflection & Bean Manipulation
```java
// ReflectionUtils - Safe reflection operations
Field field = ReflectionUtils.findField(MyClass.class, "fieldName");
ReflectionUtils.makeAccessible(field);
ReflectionUtils.setField(field, object, value);

// BeanUtils - Bean property operations
BeanUtils.copyProperties(source, target);
MyClass instance = BeanUtils.instantiateClass(MyClass.class);
```

### Web Development
```java
// UriComponentsBuilder - Fluent URI building
URI uri = UriComponentsBuilder.fromHttpUrl("http://api.example.com")
    .path("/users/{id}")
    .queryParam("fields", "name,email")
    .build("123");

// HtmlUtils - XSS prevention
String safe = HtmlUtils.htmlEscape("<script>alert('xss')</script>");
```

### Data Conversion & Validation
```java
// Assert - Design by contract
Assert.notNull(object, "Object must not be null");
Assert.hasText(text, "Text must not be empty");
Assert.isTrue(condition, "Condition must be true");

// NumberUtils - Safe number conversion
Integer num = NumberUtils.parseNumber("42", Integer.class);
Double converted = NumberUtils.convertNumberToTargetClass(42, Double.class);
```

### I/O Operations
```java
// FileCopyUtils - File operations
byte[] content = FileCopyUtils.copyToByteArray(inputFile);
String text = FileCopyUtils.copyToString(reader);

// ResourceUtils - Resource location
File file = ResourceUtils.getFile("classpath:application.yml");
boolean isUrl = ResourceUtils.isUrl("http://example.com");
```

### Performance & Monitoring
```java
// StopWatch - Performance timing
StopWatch watch = new StopWatch("Performance Test");
watch.start("Database Query");
// ... database operation
watch.stop();
System.out.println(watch.prettyPrint());
```

## 🏗 Project Structure

```
src/
├── main/
│   ├── java/
│   │   └── com/example/springutilsoverview/
│   │       ├── SpringUtilsOverviewApplication.java
│   │       ├── config/
│   │       │   └── SecurityConfig.java
│   │       ├── controller/
│   │       │   └── DemoController.java (13 endpoints)
│   │       └── demos/
│   │           ├── StringProcessingToolsDemo.java
│   │           ├── CollectionToolsDemo.java
│   │           ├── ReflectionToolsDemo.java
│   │           ├── WebToolsDemo.java
│   │           ├── SecurityToolsDemo.java
│   │           ├── UtilityToolsDemo.java
│   │           ├── IOResourceToolsDemo.java
│   │           ├── DateTimeToolsDemo.java
│   │           ├── DataConversionToolsDemo.java
│   │           ├── AdvancedWebToolsDemo.java
│   │           ├── SpringContextToolsDemo.java
│   │           ├── AOPToolsDemo.java
│   │           └── ConfigurationToolsDemo.java
│   └── resources/
│       └── application.yml
└── test/
    └── java/
```

## 📝 Dependencies

The project uses the following key dependencies:

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-security</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.security</groupId>
        <artifactId>spring-security-crypto</artifactId>
    </dependency>
    <!-- Other dependencies... -->
</dependencies>
```

## 🎯 Benefits of Using Spring Utilities

1. **Reduced Dependencies** - Avoid external libraries like Apache Commons or Guava
2. **Consistency** - Use utilities that are part of your existing Spring ecosystem
3. **Performance** - Optimized implementations tested in production environments
4. **Maintainability** - Well-documented and actively maintained by the Spring team
5. **Integration** - Seamless integration with other Spring components
6. **Null Safety** - Built-in null checks and safe operations
7. **Thread Safety** - Many utilities are designed for concurrent use
8. **Modern API** - Updated with modern Java features and patterns

## ⚠️ Important Notes & Best Practices

1. **Rod Johnson's Advice**: The creator of Spring Framework advised staying away from using Spring framework APIs in application code to avoid tight coupling. Use these utilities judiciously and prefer interfaces over implementations.

2. **Version Compatibility**: Some utilities may be deprecated in newer versions. Always check the latest Spring documentation and migration guides.

3. **Security Considerations**:
   - Use BCrypt or SCrypt for password hashing instead of MD5 in production
   - The TextEncryptor examples are for demonstration; use proper encryption in production
   - Always validate and sanitize user input using utilities like HtmlUtils

4. **Modern Alternatives**: Some utilities have modern Java equivalents:
   - Use `java.time` instead of DateFormatter for new projects
   - Prefer `java.util.stream` over CollectionUtils where applicable
   - Use modern HTTP clients like WebClient over RestTemplate

5. **Performance Considerations**:
   - Use StopWatch for development/debugging, not production monitoring
   - ConcurrentReferenceHashMap is suitable for caching but consider dedicated cache solutions
   - Be aware of reflection performance costs with ReflectionUtils

6. **Testing**: Most utilities work well in unit tests, but some (like ApplicationEventPublisher) require Spring context

## 📚 References & Further Reading

- [Original Medium Article](https://medium.com/@umeshcapg/mastering-spring-boot-49-essential-utility-classes-you-should-know-0ed3373a4972) by Umesh Kumar Yadav
- [Spring Framework Documentation](https://docs.spring.io/spring-framework/docs/current/reference/html/)
- [Spring Boot Documentation](https://docs.spring.io/spring-boot/docs/current/reference/html/)
- [Spring Framework API Documentation](https://docs.spring.io/spring-framework/docs/current/javadoc-api/)
- [Spring Boot Utilities Guide](https://docs.spring.io/spring-boot/docs/current/reference/html/features.html#features.spring-application)
- [Apache Commons Lang3](https://commons.apache.org/proper/commons-lang/) (for RandomStringUtils)
- [Spring AOP Documentation](https://docs.spring.io/spring-framework/docs/current/reference/html/core.html#aop)

## 🤝 Contributing

Contributions are welcome! This project serves as a comprehensive reference for Spring utilities:

- Add more utility demonstrations
- Improve existing examples
- Add test cases
- Update documentation
- Report issues or suggest enhancements

## 📄 License

This project is for educational purposes and demonstrates Spring Framework utilities based on the referenced Medium article. The code examples follow Spring Framework best practices and coding standards.

## 🏷️ Tags

`spring-boot` `spring-framework` `java` `utilities` `best-practices` `educational` `demo` `rest-api` `comprehensive`

## 📊 Utility Summary

| Category | Utilities Count | Key Features |
|----------|-----------------|-------------|
| String Processing | 4 | Pattern matching, placeholder resolution |
| Collections | 4 | Safe operations, multi-value maps |
| Reflection | 4 | Bean manipulation, method invocation |
| Web Tools | 5 | URI building, HTML escaping, caching |
| Security | 3 | Hashing, encoding, encryption |
| General Utilities | 7 | Assertions, conversions, JSON parsing |
| I/O & Resources | 5 | File operations, stream handling |
| Date & Time | 2+ | Formatting, performance timing |
| Data Conversion | 4 | Type resolution, message conversion |
| Advanced Web | 3 | Modern HTTP, request caching |
| Spring Context | 4 | Events, locales, property management |
| AOP | 3 | Proxy creation, component scanning |
| Configuration | 3+ | YAML loading, random generation |
| **Total** | **49+** | **Complete Spring utility ecosystem** |

## 🚀 Quick Start Commands

```bash
# Clone and run
git clone <repository-url>
cd spring-utils-overview
mvn spring-boot:run

# Test specific categories
curl http://localhost:8080/api/demos/string
curl http://localhost:8080/api/demos/security
curl http://localhost:8080/api/demos/all
```

---

**🎉 Master Spring Framework's 49+ Essential Utilities!**

*This comprehensive demo covers everything from basic string operations to advanced AOP techniques, giving you practical examples of Spring's most powerful utility classes.*
