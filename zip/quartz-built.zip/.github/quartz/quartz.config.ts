import { QuartzConfig } from "./quartz/cfg"
import * as Plugin from "./quartz/plugins"

const config: QuartzConfig = {
  configuration: {
    pageTitle: "__TITLE__",
    pageTitleSuffix: " | __TITLE__",
    enableSPA: true,
    enablePopovers: true,
    analytics: null,
    locale: "en-US",
    baseUrl: "__BASEURL__",
    ignorePatterns: ["Templates", "Attachments", ".obsidian", ".claude"],
    defaultDateType: "modified",
    generateSocialImages: false,
    theme: {
      fontOrigin: "googleFonts",
      cdnCaching: true,
      typography: {
        header: "Lora",
        body: "Lora",
        code: "JetBrains Mono",
      },
      colors: {
        lightMode: {
          light: "#f5f4ed",
          lightgray: "#e8e6dc",
          gray: "#6b6a64",
          darkgray: "#3d3d3a",
          dark: "#141413",
          secondary: "#1B5E20",
          tertiary: "#2E7D32",
          highlight: "rgba(27, 94, 32, 0.08)",
          textHighlight: "#c8e6c988",
        },
        darkMode: {
          light: "#16213e",
          lightgray: "#24304f",
          gray: "#8e97ab",
          darkgray: "#e2e6ee",
          dark: "#ffffff",
          secondary: "#e4a940",
          tertiary: "#f2c579",
          highlight: "rgba(228, 169, 64, 0.10)",
          textHighlight: "#e4a94055",
        },
      },
    },
  },
  plugins: {
    transformers: [
      Plugin.FrontMatter(),
      Plugin.CreatedModifiedDate({
        priority: ["frontmatter", "filesystem"],
      }),
      Plugin.SyntaxHighlighting({
        theme: {
          light: "catppuccin-latte",
          dark: "catppuccin-mocha",
        },
        keepBackground: false,
      }),
      Plugin.ObsidianFlavoredMarkdown({ enableInHtmlEmbed: false }),
      Plugin.GitHubFlavoredMarkdown(),
      Plugin.TableOfContents(),
      Plugin.CrawlLinks({ markdownLinkResolution: "shortest" }),
      Plugin.Description(),
      Plugin.Latex({ renderEngine: "katex" }),
    ],
    filters: [Plugin.RemoveDrafts()],
    emitters: [
      Plugin.AliasRedirects(),
      Plugin.ComponentResources(),
      Plugin.ContentPage(),
      Plugin.FolderPage(),
      Plugin.TagPage(),
      Plugin.ContentIndex({
        enableSiteMap: true,
        enableRSS: true,
      }),
      Plugin.Assets(),
      Plugin.Static(),
      Plugin.NotFoundPage(),
    ],
  },
}

export default config
