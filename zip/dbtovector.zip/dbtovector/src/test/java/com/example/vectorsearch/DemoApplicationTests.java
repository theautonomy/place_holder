package com.example.vectorsearch;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.Filter;
import org.springframework.ai.vectorstore.filter.Filter.Expression;
import org.springframework.ai.vectorstore.filter.Filter.Key;
import org.springframework.ai.vectorstore.filter.Filter.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = VectorSearchApplication.class)
class DemoApplicationTests {

    @Autowired private VectorSearchService vectorSearchService;

    @Autowired private VectorStore vectorStore;

    @Test
    void test1() {
        // vectorSearchService.addDocumentsWithMetadata();
        List<Document> documents = vectorSearchService.basicSimilaritySearch("Java framework", 5);
        documents.forEach(
                doc -> {
                    System.out.println("=====");
                    System.out.println("Document ID: " + doc.getId());
                    System.out.println("Content: " + doc.getText());
                });
    }

    @Test
    void test() {
        // vectorSearchService.addDocumentsWithMetadata();
        List<Document> documents = vectorSearchService.searchWithSingleFilter("framework", 5);
        documents.forEach(
                doc -> {
                    System.out.println("=====");
                    System.out.println("Document ID: " + doc.getId());
                    System.out.println("Content: " + doc.getText());
                });
    }

    @Test
    void test2() {
        // Sample document with metadata
        Document document1 =
                new Document(
                        "This is a document about Spring AI",
                        Map.of("category", "technology", "year", "2024"));
        Document document2 =
                new Document(
                        "This document is about Java",
                        Map.of("category", "technology", "year", "2023"));
        Document document3 =
                new Document(
                        "This is a document about finance",
                        Map.of("category", "finance", "year", "2024"));

        // Add documents to the vector store
        vectorStore.add(List.of(document1, document2, document3));

        // Create a filter for documents in the "technology" category and from 2024
        Filter.Expression filter =
                new Expression(
                        Filter.ExpressionType.EQ, new Key("category"), new Value("technology"));

        // WHY this does not work?
        // WHY this does not work?
        // WHY this does not work?
        SearchRequest request =
                SearchRequest.builder()
                        .query("A document about")
                        .topK(5)
                        .similarityThresholdAll()
                        .filterExpression("category == 'technology' && year == '2024'")
                        // .filterExpression(filter)
                        .build();

        // Perform similarity search with the filter
        List<Document> results = vectorStore.similaritySearch(request);

        // Process the results
        for (Document doc : results) {
            System.out.println("=====");
            System.out.println("Document ID: " + doc.getId());
            System.out.println("Content: " + doc.getText());
        }
    }

    @Test
    void test3() {
        var bgDocument =
                new Document(
                        "The World is Big and Salvation Lurks Around the Corner",
                        Map.of("country", "BG", "year", 2020));
        var nlDocument =
                new Document(
                        "The World is Big and Salvation Lurks Around the Corner",
                        Map.of("country", "NL"));
        var bgDocument2 =
                new Document(
                        "The World is Big and Salvation Lurks Around the Corner",
                        Map.of("country", "BG", "year", 2023));

        vectorStore.add(List.of(bgDocument, nlDocument, bgDocument2));

        List<Document> results =
                vectorStore.similaritySearch(
                        SearchRequest.builder().query("The World").topK(5).build());
        assertThat(results).hasSize(3);

        results =
                vectorStore.similaritySearch(
                        SearchRequest.builder()
                                .query("The World")
                                .topK(5)
                                .similarityThresholdAll()
                                .filterExpression("country == 'NL'")
                                .build());

        // assertThat(results).hasSize(1);
        // assertThat(results.get(0).getId()).isEqualTo(nlDocument.getId());

        results =
                vectorStore.similaritySearch(
                        SearchRequest.builder()
                                .query("The World")
                                .topK(5)
                                .similarityThresholdAll()
                                .filterExpression("country == 'BG'")
                                .build());

        assertThat(results).hasSize(2);
        // assertThat(results.get(0).getId()).isIn(bgDocument.getId(), bgDocument2.getId());
        // assertThat(results.get(1).getId()).isIn(bgDocument.getId(), bgDocument2.getId());

        results =
                vectorStore.similaritySearch(
                        SearchRequest.builder()
                                .query("The World")
                                .topK(5)
                                .similarityThresholdAll()
                                .filterExpression("country == 'BG' && year == 2020")
                                .build());

        assertThat(results).hasSize(1);
        // assertThat(results.get(0).getId()).isEqualTo(bgDocument.getId());

        results =
                vectorStore.similaritySearch(
                        SearchRequest.builder()
                                .query("The World")
                                .topK(5)
                                .similarityThresholdAll()
                                .filterExpression("NOT(country == 'BG' && year == 2020)")
                                .build());

        assertThat(results).hasSize(2);
        // assertThat(results.get(0).getId()).isIn(nlDocument.getId(), bgDocument2.getId());
        // assertThat(results.get(1).getId()).isIn(nlDocument.getId(), bgDocument2.getId());
    }
}
