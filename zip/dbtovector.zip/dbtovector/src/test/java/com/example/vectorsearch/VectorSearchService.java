package com.example.vectorsearch;

import java.util.List;

import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.Filter;
import org.springframework.ai.vectorstore.filter.FilterExpressionBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VectorSearchService {

    @Autowired private VectorStore vectorStore;

    public List<Document> basicSimilaritySearch(String query, int topK) {
        SearchRequest request = SearchRequest.builder().query(query).topK(topK).build();

        return vectorStore.similaritySearch(request);
    }

    /** Similarity search with single filter condition */
    public List<Document> searchWithSingleFilter(String query, int topK) {
        Filter.Expression filterExpr =
                new FilterExpressionBuilder().eq("category", "technology").build();

        SearchRequest request =
                SearchRequest.builder()
                        .query(query)
                        .topK(topK)
                        .filterExpression(filterExpr)
                        .build();

        return vectorStore.similaritySearch(request);
    }

    /*
    public List<Document> searchWithMultipleAndFilters(String query, int topK) {
        Filter.Expression filterExpr = new FilterExpressionBuilder()
                .eq("category", "technology")
                .and()
                .gt("rating", 4.0)
                .and()
                .eq("status", "published")
                .build();

        Filter.Expression categoryFilter = new FilterExpressionBuilder().eq("category", "technology").build();
        Filter.Expression ratingFilter = new FilterExpressionBuilder().gt("rating", 4.0).build();
        Filter.Expression statusFilter = new FilterExpressionBuilder().eq("status", "published").build();

        Filter.Expression filterExpr = new Filter.Expression(categoryFilter, ratingFilter, statusFilter);

        SearchRequest request = SearchRequest.builder().query(query)
                .topK(topK)
                .filterExpression(filterExpr).build();

        return vectorStore.similaritySearch(request);
    }

    public List<Document> searchWithOrFilters(String query, int topK) {
        Filter.Expression filterExpr = new FilterExpressionBuilder()
                .eq("category", "technology")
                .or()
                .eq("category", "science")
                .build();
        SearchRequest request = SearchRequest.builder().query(query)
                .topK(topK)
                .filterExpression(filterExpr).build();
        return vectorStore.similaritySearch(request);
    }

    public List<Document> searchWithComplexFilters(String query, int topK) {
        Filter.Expression filterExpr = new FilterExpressionBuilder()
                .group(
                    new FilterExpressionBuilder()
                        .eq("category", "technology")
                        .or()
                        .eq("category", "science")
                )
                .and()
                .gt("rating", 3.5)
                .and()
                .in("language", "en", "es")
                .build();


        SearchRequest request = SearchRequest.builder().query(query)
                .topK(topK)
                .filterExpression(filterExpr).build();
        return vectorStore.similaritySearch(request);
    }

    public List<Document> searchWithRangeFilters(String query, int topK) {
        Filter.Expression filterExpr = new FilterExpressionBuilder()
                .gte("created_date", "2024-01-01")
                .and()
                .lte("created_date", "2024-12-31")
                .and()
                .between("price", 10.0, 100.0)
                .build();

        SearchRequest request = SearchRequest.builder().query(query)
                .topK(topK)
                .filterExpression(filterExpr).build();
        return vectorStore.similaritySearch(request);
    }

    public List<Document> searchWithSimilarityThreshold(String query, double threshold) {
        SearchRequest request = SearchRequest.builder().query(query)
                .topK(50)
                .similarityThreshold(threshold).build();
        return vectorStore.similaritySearch(request);
    }

    public List<Document> searchWithThresholdAndFilters(String query, double threshold) {

        String filterExpression = "category == 'technology' && rating > 4.0 && status == 'published'";
        FilterExpressionBuilder builder = new FilterExpressionBuilder();
        var operation = builder.eq("category", "technology");
        operation = builder.and(builder.gte("rating", 4.0), builder.eq("status", "published"));

        Filter.Expression filterExpr = operation.build();

        SearchRequest request = SearchRequest.builder().query(query)
                .topK(20)
                .similarityThreshold(threshold)
                .filterExpression(filterExpr).build();
        return vectorStore.similaritySearch(request);
    }
        */

    public void addDocumentsWithMetadata() {
        // Document 1
        Document doc1 = new Document("Spring Boot is a powerful framework for Java development");
        doc1.getMetadata().put("category", "technology");
        doc1.getMetadata().put("rating", 4.5);
        doc1.getMetadata().put("status", "published");
        doc1.getMetadata().put("language", "en");
        doc1.getMetadata().put("created_date", "2024-06-15");
        doc1.getMetadata().put("price", 29.99);

        // Document 2
        Document doc2 = new Document("Machine learning algorithms are transforming industries");
        doc2.getMetadata().put("category", "science");
        doc2.getMetadata().put("rating", 4.8);
        doc2.getMetadata().put("status", "published");
        doc2.getMetadata().put("language", "en");
        doc2.getMetadata().put("created_date", "2024-05-20");
        doc2.getMetadata().put("price", 45.00);

        // Document 3
        Document doc3 = new Document("React components make UI development easier");
        doc3.getMetadata().put("category", "technology");
        doc3.getMetadata().put("rating", 4.2);
        doc3.getMetadata().put("status", "draft");
        doc3.getMetadata().put("language", "es");
        doc3.getMetadata().put("created_date", "2024-07-01");
        doc3.getMetadata().put("price", 19.99);

        vectorStore.add(List.of(doc1, doc2, doc3));
    }
}
