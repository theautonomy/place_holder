-- H2 Database Schema for MyDocument Entity
-- Drop table if exists (useful for testing/development)
DROP TABLE IF EXISTS documents;

-- Create documents table
CREATE TABLE documents (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    source_table VARCHAR(255),
    source_id VARCHAR(255),
    metadata TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- Create indexes for better query performance
CREATE INDEX idx_documents_source ON documents(source_table, source_id);
CREATE INDEX idx_documents_created_at ON documents(created_at);
CREATE INDEX idx_documents_title ON documents(title);