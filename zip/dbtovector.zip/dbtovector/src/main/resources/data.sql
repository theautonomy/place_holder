-- Sample data for documents table
INSERT INTO documents (title, content, source_table, source_id, metadata, created_at, updated_at) VALUES
(
    'User Manual - Getting Started',
    'This comprehensive guide will help you get started with our application. Begin by creating your first account and exploring the dashboard features. The interface is designed to be intuitive and user-friendly.',
    'manuals',
    'MAN-001',
    '{"category": "documentation", "version": "1.0", "author": "Tech Team", "tags": ["beginner", "setup"]}',
    '2024-01-15 10:30:00',
    '2024-01-15 10:30:00'
),
(
    'API Reference Documentation',
    'Complete API reference for developers. Includes authentication methods, endpoint descriptions, request/response examples, and error handling guidelines. All endpoints support JSON format.',
    'documentation',
    'DOC-API-001',
    '{"category": "api", "version": "2.1", "author": "Development Team", "tags": ["api", "reference", "developer"]}',
    '2024-01-20 14:45:00',
    '2024-02-10 09:15:00'
),
(
    'Quarterly Sales Report Q1 2024',
    'Sales performance exceeded expectations in Q1 2024 with a 25% increase compared to the previous quarter. Key growth areas include enterprise sales and subscription renewals.',
    'reports',
    'RPT-Q1-2024',
    '{"category": "business", "quarter": "Q1", "year": "2024", "confidential": true}',
    '2024-04-01 16:20:00',
    '2024-04-01 16:20:00'
),
(
    'Employee Onboarding Checklist',
    'Complete checklist for new employee onboarding process. Includes HR documentation, IT setup, workspace allocation, and training schedule. Should be completed within first week.',
    'hr_documents',
    'HR-ONBOARD-001',
    '{"category": "hr", "department": "Human Resources", "template": true, "tags": ["onboarding", "checklist"]}',
    '2024-02-05 11:00:00',
    '2024-03-12 08:30:00'
),
(
    'Security Policy Update',
    'Updated security policies effective immediately. New requirements include multi-factor authentication for all accounts, regular password updates, and VPN usage for remote work.',
    'policies',
    'POL-SEC-2024-001',
    '{"category": "security", "effective_date": "2024-03-01", "mandatory": true, "author": "Security Team"}',
    '2024-02-28 17:00:00',
    '2024-02-28 17:00:00'
),
(
    'Project Alpha Status Update',
    'Project Alpha is currently 75% complete and on track for the scheduled delivery date. Recent milestones include completion of the backend API and initial user testing phase.',
    'project_updates',
    'PROJ-ALPHA-UPD-003',
    '{"category": "project", "project_code": "ALPHA", "status": "in_progress", "completion": 75}',
    '2024-03-15 13:25:00',
    '2024-03-15 13:25:00'
),
(
    'Customer Feedback Summary',
    'Analysis of customer feedback from the past month shows high satisfaction rates with our new features. Main requests include mobile app improvements and faster load times.',
    'feedback',
    'FB-SUMMARY-202403',
    '{"category": "feedback", "period": "2024-03", "rating_average": 4.2, "total_responses": 156}',
    '2024-03-31 19:45:00',
    '2024-03-31 19:45:00'
),
(
    'Database Backup Procedures',
    'Step-by-step procedures for database backup and recovery operations. Includes automated backup schedules, manual backup processes, and disaster recovery protocols.',
    'procedures',
    'PROC-DB-BACKUP-001',
    '{"category": "technical", "criticality": "high", "last_reviewed": "2024-01-30", "tags": ["database", "backup", "recovery"]}',
    '2024-01-30 12:00:00',
    '2024-01-30 12:00:00'
),
(
    'Marketing Campaign Analysis',
    'Detailed analysis of Q1 marketing campaigns across all channels. Digital campaigns showed 15% higher engagement compared to traditional media, with social media leading conversion rates.',
    'marketing',
    'MKT-ANALYSIS-Q1-2024',
    '{"category": "marketing", "quarter": "Q1", "year": "2024", "channels": ["digital", "social", "traditional"]}',
    '2024-04-05 10:15:00',
    '2024-04-05 10:15:00'
),
(
    'Software License Inventory',
    'Current inventory of all software licenses across the organization. Includes renewal dates, license types, and cost analysis. Several licenses require renewal within next 60 days.',
    'inventory',
    'INV-SOFTWARE-2024',
    '{"category": "inventory", "type": "software", "total_licenses": 245, "expiring_soon": 12}',
    '2024-03-01 14:30:00',
    '2024-03-20 16:45:00'
),
(
    'Marketing Campaign Analysis - 1',
    '1 - Detailed analysis of Q1 marketing campaigns across all channels. Digital campaigns showed 15% higher engagement compared to traditional media, with social media leading conversion rates.',
    'marketing',
    'MKT-ANALYSIS-Q1-2024',
    '{"category": "marketing", "quarter": "Q1", "year": "2024", "channels": ["digital", "social", "traditional"]}',
    '2024-04-05 10:15:00',
    '2024-04-05 10:15:00'
),
(
    'Software License Inventory - 1',
    '1 - Current inventory of all software licenses across the organization. Includes renewal dates, license types, and cost analysis. Several licenses require renewal within next 60 days.',
    'inventory',
    'INV-SOFTWARE-2024',
    '{"category": "inventory", "type": "software", "total_licenses": 245, "expiring_soon": 12}',
    '2024-03-01 14:30:00',
    '2024-03-20 16:45:00'
);