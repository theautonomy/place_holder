package com.example.vectorsearch;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MyDocumentRepository extends JpaRepository<MyDocument, Long> {

    List<MyDocument> findBySourceTable(String sourceTable);

    Optional<MyDocument> findBySourceTableAndSourceId(String sourceTable, String sourceId);

    Page<MyDocument> findBySourceTable(String sourceTable, Pageable pageable);

    @Query("SELECT DISTINCT d.sourceTable FROM MyDocument d")
    List<String> findDistinctSourceTables();

    @Query("SELECT COUNT(d) FROM MyDocument d WHERE d.sourceTable = :sourceTable")
    long countBySourceTable(@Param("sourceTable") String sourceTable);

    @Query("SELECT d FROM MyDocument d WHERE d.title LIKE %:keyword% OR d.content LIKE %:keyword%")
    List<MyDocument> findByKeyword(@Param("keyword") String keyword);
}
