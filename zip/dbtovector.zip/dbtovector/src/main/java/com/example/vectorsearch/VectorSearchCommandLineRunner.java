package com.example.vectorsearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

// Comment out for unit test
@Component
public class VectorSearchCommandLineRunner implements CommandLineRunner {

    private static final Logger logger =
            LoggerFactory.getLogger(VectorSearchCommandLineRunner.class);

    @Autowired private DataIngestionService dataIngestionService;

    @Autowired private SearchService searchService;

    private final Scanner scanner = new Scanner(System.in);

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n=== Vector Search Application ===");
        System.out.println(
                "This application allows you to ingest relational data and perform semantic search.");
        System.out.println("Make sure Redis Stack is running on localhost:6379");
        System.out.println("Set your OPENAI_API_KEY environment variable");

        // Create sample data first
        createSampleData();

        while (true) {
            printMenu();
            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1":
                        ingestSampleData();
                        break;
                    case "2":
                        performSearch();
                        break;
                    case "3":
                        searchInTable();
                        break;
                    case "4":
                        performHybridSearch();
                        break;
                    case "5":
                        findSimilarDocuments();
                        break;
                    case "6":
                        showStatistics();
                        break;
                    case "7":
                        customTableIngestion();
                        break;
                    case "8":
                        clearData();
                        break;
                    case "9":
                        System.out.println("Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                logger.error("Error executing command: {}", e.getMessage(), e);
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void printMenu() {
        System.out.println("\n=== Menu ===");
        System.out.println("1. Ingest Sample Data");
        System.out.println("2. Semantic Search");
        System.out.println("3. Search in Specific Table");
        System.out.println("4. Hybrid Search");
        System.out.println("5. Find Similar Documents");
        System.out.println("6. Show Statistics");
        System.out.println("7. Custom Table Ingestion");
        System.out.println("8. Clear Data");
        System.out.println("9. Exit");
        System.out.print("Choose an option: ");
    }

    private void createSampleData() {
        System.out.println("Creating sample data tables...");

        // This would typically be done via database migrations
        // For demonstration, we'll assume the tables exist
        logger.info("Sample data tables should be created via database migrations");
    }

    private void ingestSampleData() {
        System.out.println("Starting sample data ingestion...");

        List<TableIngestionConfig> configs = new ArrayList<>();

        // Sample configuration for a products table
        /*
        TableIngestionConfig productsConfig = new TableIngestionConfig();
        productsConfig.setTableName("products");
        productsConfig.setPrimaryKeyColumn("id");
        productsConfig.setTitleColumn("name");
        productsConfig.setTextColumns(Arrays.asList("name", "description", "features"));
        */

        // Sample configuration for an articles table
        TableIngestionConfig articlesConfig = new TableIngestionConfig();
        articlesConfig.setTableName("documents");
        articlesConfig.setPrimaryKeyColumn("id");
        articlesConfig.setTitleColumn("title");
        articlesConfig.setTextColumns(Arrays.asList("content"));
        // articlesConfig.setAdditionalMetadata(Map.of("source_table", "documents"));

        // configs.add(productsConfig);
        configs.add(articlesConfig);

        try {
            Map<String, Integer> results = dataIngestionService.ingestTables(configs);

            System.out.println("Ingestion completed:");
            for (Map.Entry<String, Integer> entry : results.entrySet()) {
                System.out.println("  " + entry.getKey() + ": " + entry.getValue() + " records");
            }
        } catch (Exception e) {
            System.out.println("Error during ingestion: " + e.getMessage());
            logger.error("Ingestion error", e);
        }
    }

    private void performSearch() {
        System.out.print("Enter your search query: ");
        String query = scanner.nextLine().trim();

        if (query.isEmpty()) {
            System.out.println("Query cannot be empty.");
            return;
        }

        System.out.print("Number of results (default 5): ");
        String topKStr = scanner.nextLine().trim();
        int topK = topKStr.isEmpty() ? 5 : Integer.parseInt(topKStr);

        List<SearchResult> results = searchService.semanticSearch(query, topK);
        displaySearchResults(results, "Semantic Search Results");
    }

    private void searchInTable() {
        System.out.print("Enter table name: ");
        String tableName = scanner.nextLine().trim();

        System.out.print("Enter your search query: ");
        String query = scanner.nextLine().trim();

        System.out.print("Number of results (default 5): ");
        String topKStr = scanner.nextLine().trim();
        int topK = topKStr.isEmpty() ? 5 : Integer.parseInt(topKStr);

        List<SearchResult> results = searchService.searchInTable(query, tableName, topK);
        displaySearchResults(results, "Table Search Results for: " + tableName);
    }

    private void performHybridSearch() {
        System.out.print("Enter your search query: ");
        String query = scanner.nextLine().trim();

        System.out.print("Number of results (default 5): ");
        String topKStr = scanner.nextLine().trim();
        int topK = topKStr.isEmpty() ? 5 : Integer.parseInt(topKStr);

        List<SearchResult> results = searchService.hybridSearch(query, topK);
        displaySearchResults(results, "Hybrid Search Results");
    }

    private void findSimilarDocuments() {
        System.out.print("Enter document ID: ");
        String idStr = scanner.nextLine().trim();

        try {
            Long documentId = Long.parseLong(idStr);

            System.out.print("Number of similar documents (default 5): ");
            String topKStr = scanner.nextLine().trim();
            int topK = topKStr.isEmpty() ? 5 : Integer.parseInt(topKStr);

            List<SearchResult> results = searchService.findSimilarDocuments(documentId, topK);
            displaySearchResults(results, "Similar Documents");

        } catch (NumberFormatException e) {
            System.out.println("Invalid document ID format.");
        }
    }

    private void showStatistics() {
        System.out.println("\n=== Search Statistics ===");

        Map<String, Object> stats = searchService.getSearchStats();

        System.out.println("Total Documents: " + stats.get("total_documents"));
        System.out.println("Total Tables: " + stats.get("total_tables"));

        @SuppressWarnings("unchecked")
        Map<String, Long> tableCounts = (Map<String, Long>) stats.get("tables");

        System.out.println("\nDocuments by Table:");
        for (Map.Entry<String, Long> entry : tableCounts.entrySet()) {
            System.out.println("  " + entry.getKey() + ": " + entry.getValue());
        }

        // Additional ingestion stats
        Map<String, Long> ingestionStats = dataIngestionService.getIngestionStats();
        System.out.println("\nIngestion Statistics:");
        for (Map.Entry<String, Long> entry : ingestionStats.entrySet()) {
            System.out.println("  " + entry.getKey() + ": " + entry.getValue() + " ingested");
        }
    }

    private void customTableIngestion() {
        System.out.println("\n=== Custom Table Ingestion ===");

        TableIngestionConfig config = new TableIngestionConfig();

        System.out.print("Table name: ");
        config.setTableName(scanner.nextLine().trim());

        System.out.print("Primary key column: ");
        config.setPrimaryKeyColumn(scanner.nextLine().trim());

        System.out.print("Title column (optional): ");
        String titleColumn = scanner.nextLine().trim();
        if (!titleColumn.isEmpty()) {
            config.setTitleColumn(titleColumn);
        }

        System.out.print("Text columns (comma-separated): ");
        String textColumnsStr = scanner.nextLine().trim();
        List<String> textColumns = Arrays.asList(textColumnsStr.split(","));
        textColumns =
                textColumns.stream()
                        .map(String::trim)
                        .filter(s -> !s.isEmpty())
                        .collect(ArrayList::new, (list, item) -> list.add(item), ArrayList::addAll);
        config.setTextColumns(textColumns);

        System.out.print("WHERE clause (optional): ");
        String whereClause = scanner.nextLine().trim();
        if (!whereClause.isEmpty()) {
            config.setWhereClause(whereClause);
        }

        try {
            int result = dataIngestionService.ingestTable(config).get();
            System.out.println(
                    "Successfully ingested " + result + " records from " + config.getTableName());
        } catch (Exception e) {
            System.out.println("Error during ingestion: " + e.getMessage());
        }
    }

    private void clearData() {
        System.out.print("Enter table name to clear (or 'ALL' for all tables): ");
        String tableName = scanner.nextLine().trim();

        System.out.print("Are you sure? (yes/no): ");
        String confirmation = scanner.nextLine().trim().toLowerCase();

        if (!confirmation.equals("yes")) {
            System.out.println("Operation cancelled.");
            return;
        }

        try {
            if ("ALL".equalsIgnoreCase(tableName)) {
                // Clear all data - this would need to be implemented
                System.out.println("Clearing all data is not implemented yet.");
            } else {
                dataIngestionService.clearTableData(tableName);
                System.out.println("Cleared data for table: " + tableName);
            }
        } catch (Exception e) {
            System.out.println("Error clearing data: " + e.getMessage());
        }
    }

    private void displaySearchResults(List<SearchResult> results, String title) {
        System.out.println("\n=== " + title + " ===");

        if (results.isEmpty()) {
            System.out.println("No results found.");
            return;
        }

        for (int i = 0; i < results.size(); i++) {
            SearchResult result = results.get(i);
            System.out.println("\n" + (i + 1) + ". " + result.getTitle());
            System.out.println(
                    "   Source: "
                            + result.getSourceTable()
                            + " (ID: "
                            + result.getSourceId()
                            + ")");
            System.out.println("   Similarity: " + result.getSimilarityPercentage());
            System.out.println("   Content: " + result.getContentPreview(200));

            if (result.getMetadata() != null && !result.getMetadata().isEmpty()) {
                System.out.println("   Metadata: " + result.getMetadata());
            }
        }
    }
}
