package com.example.vectorsearch;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SearchService {

    private static final Logger logger = LoggerFactory.getLogger(SearchService.class);

    @Autowired private VectorStore vectorStore;

    @Autowired private MyDocumentRepository documentRepository;

    @Autowired private TextProcessingService textProcessingService;

    /** Perform semantic search across all documents */
    public List<SearchResult> semanticSearch(String query, int topK) {
        return semanticSearch(query, topK, null, 0.7);
    }

    /** Perform semantic search with filtering and similarity threshold */
    public List<SearchResult> semanticSearch(
            String query, int topK, Map<String, Object> filters, double similarityThreshold) {
        logger.info("Performing semantic search for query: '{}' with topK: {}", query, topK);

        try {
            // Process the query
            String processedQuery = textProcessingService.processText(query);

            // Build search request
            SearchRequest.Builder requestBuilder =
                    SearchRequest.builder()
                            .query(processedQuery)
                            .topK(topK)
                            .similarityThreshold(similarityThreshold);

            // Add filters if provided
            // CHECK -
            /*
            if (filters != null && !filters.isEmpty()) {
                Filter filter = buildFilter(filters);
                requestBuilder.filterExpression(filter);
            }
                */

            SearchRequest searchRequest = requestBuilder.build();

            // Perform vector search
            List<Document> results = vectorStore.similaritySearch(searchRequest);

            logger.info("Found {} results for query: '{}'", results.size(), query);

            // Convert to SearchResult objects
            return results.stream().map(this::convertToSearchResult).collect(Collectors.toList());

        } catch (Exception e) {
            logger.error("Error performing semantic search: {}", e.getMessage(), e);
            throw new RuntimeException("Semantic search failed", e);
        }
    }

    /** Search within a specific table */
    public List<SearchResult> searchInTable(String query, String tableName, int topK) {
        Map<String, Object> filters = new HashMap<>();
        filters.put("source_table", tableName);
        return semanticSearch(query, topK, filters, 0.7);
    }

    /** Hybrid search combining semantic and keyword search */
    public List<SearchResult> hybridSearch(String query, int topK) {
        logger.info("Performing hybrid search for query: '{}'", query);

        // Perform semantic search
        List<SearchResult> semanticResults = semanticSearch(query, topK);

        // Perform keyword search in database
        List<MyDocument> keywordResults = documentRepository.findByKeyword(query);

        // Combine and deduplicate results
        Map<String, SearchResult> combinedResults = new HashMap<>();

        // Add semantic results
        for (SearchResult result : semanticResults) {
            String key = result.getSourceTable() + "_" + result.getSourceId();
            combinedResults.put(key, result);
        }

        // Add keyword results (if not already present)
        for (MyDocument doc : keywordResults) {
            String key = doc.getSourceTable() + "_" + doc.getSourceId();
            if (!combinedResults.containsKey(key)) {
                SearchResult result = new SearchResult();
                result.setId(doc.getId());
                result.setTitle(doc.getTitle());
                result.setContent(doc.getContent());
                result.setSourceTable(doc.getSourceTable());
                result.setSourceId(doc.getSourceId());
                result.setSimilarityScore(0.5); // Lower score for keyword-only matches
                result.setMetadata(parseMetadata(doc.getMetadata()));

                combinedResults.put(key, result);
            }
        }

        // Sort by similarity score and return top results
        return combinedResults.values().stream()
                .sorted((a, b) -> Double.compare(b.getSimilarityScore(), a.getSimilarityScore()))
                .limit(topK)
                .collect(Collectors.toList());
    }

    /** Find similar documents to a given document ID */
    public List<SearchResult> findSimilarDocuments(Long documentId, int topK) {
        logger.info("Finding similar documents for document ID: {}", documentId);

        Optional<MyDocument> docOpt = documentRepository.findById(documentId);
        if (!docOpt.isPresent()) {
            logger.warn("Document not found with ID: {}", documentId);
            return Collections.emptyList();
        }

        MyDocument document = docOpt.get();

        // Use the document's content as the search query
        return semanticSearch(document.getContent(), topK + 1) // +1 to exclude self
                .stream()
                .filter(
                        result ->
                                !result.getId().equals(documentId)) // Exclude the original document
                .limit(topK)
                .collect(Collectors.toList());
    }

    /** Get search statistics */
    public Map<String, Object> getSearchStats() {
        Map<String, Object> stats = new HashMap<>();

        // Get document counts by table
        List<String> tables = documentRepository.findDistinctSourceTables();
        Map<String, Long> tableCounts = new HashMap<>();

        for (String table : tables) {
            long count = documentRepository.countBySourceTable(table);
            tableCounts.put(table, count);
        }

        stats.put("tables", tableCounts);
        stats.put("total_documents", documentRepository.count());
        stats.put("total_tables", tables.size());

        return stats;
    }

    /*
    // CHECK -
    private Filter buildFilter(Map<String, Object> filters) {
        FilterExpressionBuilder builder = new FilterExpressionBuilder();

        boolean first = true;
        for (Map.Entry<String, Object> entry : filters.entrySet()) {
            if (!first) {
                // builder = builder.and(null, null)
            }
            // builder = builder.eq(entry.getKey(), entry.getValue());
            first = false;
        }

        return builder.build();
    }
        */

    private SearchResult convertToSearchResult(Document aiDocument) {
        SearchResult result = new SearchResult();

        Map<String, Object> metadata = aiDocument.getMetadata();

        result.setContent(aiDocument.getText());
        result.setMetadata(metadata);

        // Extract standard fields from metadata
        if (metadata.containsKey("id")) {
            result.setId(Long.valueOf(metadata.get("id").toString()));
        }
        if (metadata.containsKey("title")) {
            result.setTitle(metadata.get("title").toString());
        }
        if (metadata.containsKey("source_table")) {
            result.setSourceTable(metadata.get("source_table").toString());
        }
        if (metadata.containsKey("source_id")) {
            result.setSourceId(metadata.get("source_id").toString());
        }
        if (metadata.containsKey("distance")) {
            // Convert distance to similarity score (assuming cosine distance)
            double distance = Double.parseDouble(metadata.get("distance").toString());
            result.setSimilarityScore(1.0 - distance);
        }

        return result;
    }

    private Map<String, Object> parseMetadata(String metadataJson) {
        try {
            if (metadataJson != null && !metadataJson.trim().isEmpty()) {
                return new com.fasterxml.jackson.databind.ObjectMapper()
                        .readValue(metadataJson, Map.class);
            }
        } catch (Exception e) {
            logger.warn("Error parsing metadata JSON: {}", e.getMessage());
        }
        return new HashMap<>();
    }
}
