package com.example.vectorsearch;

import java.util.List;
import java.util.Map;

public class TableIngestionConfig {

    private String tableName;
    private String primaryKeyColumn;
    private List<String> textColumns;
    private String titleColumn;
    private Map<String, String> additionalMetadata;
    private String whereClause;
    private boolean enabled;

    public TableIngestionConfig() {
        this.enabled = true;
    }

    public TableIngestionConfig(
            String tableName,
            String primaryKeyColumn,
            List<String> textColumns,
            String titleColumn) {
        this.tableName = tableName;
        this.primaryKeyColumn = primaryKeyColumn;
        this.textColumns = textColumns;
        this.titleColumn = titleColumn;
        this.enabled = true;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getPrimaryKeyColumn() {
        return primaryKeyColumn;
    }

    public void setPrimaryKeyColumn(String primaryKeyColumn) {
        this.primaryKeyColumn = primaryKeyColumn;
    }

    public List<String> getTextColumns() {
        return textColumns;
    }

    public void setTextColumns(List<String> textColumns) {
        this.textColumns = textColumns;
    }

    public String getTitleColumn() {
        return titleColumn;
    }

    public void setTitleColumn(String titleColumn) {
        this.titleColumn = titleColumn;
    }

    public Map<String, String> getAdditionalMetadata() {
        return additionalMetadata;
    }

    public void setAdditionalMetadata(Map<String, String> additionalMetadata) {
        this.additionalMetadata = additionalMetadata;
    }

    public String getWhereClause() {
        return whereClause;
    }

    public void setWhereClause(String whereClause) {
        this.whereClause = whereClause;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    @Override
    public String toString() {
        return "TableIngestionConfig{"
                + "tableName='"
                + tableName
                + '\''
                + ", primaryKeyColumn='"
                + primaryKeyColumn
                + '\''
                + ", textColumns="
                + textColumns
                + ", titleColumn='"
                + titleColumn
                + '\''
                + ", enabled="
                + enabled
                + '}';
    }
}
