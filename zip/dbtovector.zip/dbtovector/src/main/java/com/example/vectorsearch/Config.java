package com.example.vectorsearch;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.redis.RedisVectorStore;
import org.springframework.ai.vectorstore.redis.RedisVectorStore.MetadataField;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;

import redis.clients.jedis.JedisPooled;

@Configuration
public class Config {

    @Bean
    // public RedisVectorStore vectorStore(EmbeddingModel embeddingModel,
    public VectorStore vectorStore(
            EmbeddingModel embeddingModel, JedisConnectionFactory jedisConnectionFactory) {
        return RedisVectorStore
                // .builder(new JedisPooled(jedisConnectionFactory.getHostName(),
                // jedisConnectionFactory.getPort()),
                // .builder(new JedisPooled("localhost", 6379, "default", "mypassword"),
                // embeddingModel)
                .builder(new JedisPooled("localhost", 16379), embeddingModel)
                .metadataFields(
                        MetadataField.tag("meta1"),
                        MetadataField.tag("meta2"),
                        MetadataField.tag("country"),
                        MetadataField.tag("category"),
                        MetadataField.numeric("year"),
                        MetadataField.numeric("priority"), // Add
                        // priority
                        // as
                        // numeric
                        MetadataField.tag("type") // Add type as tag
                        )
                .initializeSchema(true)
                .build();
    }
}
