package com.example.vectorsearch;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class TextProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(TextProcessingService.class);

    @Value("${app.ingestion.chunk-size:1000}")
    private int chunkSize;

    @Value("${app.ingestion.chunk-overlap:200}")
    private int chunkOverlap;

    private static final Pattern HTML_TAG_PATTERN = Pattern.compile("<[^>]+>");
    private static final Pattern MULTIPLE_SPACES_PATTERN = Pattern.compile("\\s+");
    private static final Pattern SPECIAL_CHARS_PATTERN = Pattern.compile("[\\x00-\\x1F\\x7F]");

    /** Process text for better semantic search */
    public String processText(String text) {
        if (!StringUtils.hasText(text)) {
            return "";
        }

        try {
            // Remove HTML tags if present
            String cleaned = HTML_TAG_PATTERN.matcher(text).replaceAll(" ");

            // Remove control characters
            cleaned = SPECIAL_CHARS_PATTERN.matcher(cleaned).replaceAll("");

            // Normalize whitespace
            cleaned = MULTIPLE_SPACES_PATTERN.matcher(cleaned).replaceAll(" ");

            // Trim
            cleaned = cleaned.trim();

            return cleaned;

        } catch (Exception e) {
            logger.error("Error processing text: {}", e.getMessage());
            return text; // Return original text if processing fails
        }
    }

    /** Split text into chunks for better processing */
    public List<String> chunkText(String text) {
        List<String> chunks = new ArrayList<>();

        if (!StringUtils.hasText(text)) {
            return chunks;
        }

        if (text.length() <= chunkSize) {
            chunks.add(processText(text));
            return chunks;
        }

        int start = 0;
        while (start < text.length()) {
            int end = Math.min(start + chunkSize, text.length());

            // Try to break at word boundaries
            if (end < text.length()) {
                int lastSpace = text.lastIndexOf(' ', end);
                if (lastSpace > start + chunkSize / 2) {
                    end = lastSpace;
                }
            }

            String chunk = text.substring(start, end);
            chunks.add(processText(chunk));

            // Move start position with overlap
            start = Math.max(start + chunkSize - chunkOverlap, end);
        }

        return chunks;
    }

    /** Extract key phrases from text for better searchability */
    public String extractKeyPhrases(String text) {
        if (!StringUtils.hasText(text)) {
            return "";
        }

        // Simple key phrase extraction - can be enhanced with NLP libraries
        String processed = processText(text);

        // Extract sentences that might contain key information
        String[] sentences = processed.split("[.!?]+");
        StringBuilder keyPhrases = new StringBuilder();

        for (String sentence : sentences) {
            sentence = sentence.trim();
            if (sentence.length() > 20 && sentence.length() < 200) {
                // Look for sentences with important keywords
                if (containsImportantKeywords(sentence)) {
                    if (keyPhrases.length() > 0) {
                        keyPhrases.append(" ");
                    }
                    keyPhrases.append(sentence);
                }
            }
        }

        return keyPhrases.toString();
    }

    private boolean containsImportantKeywords(String sentence) {
        String lower = sentence.toLowerCase();
        String[] importantWords = {
            "important",
            "key",
            "main",
            "primary",
            "significant",
            "critical",
            "essential",
            "major",
            "core",
            "fundamental"
        };

        for (String word : importantWords) {
            if (lower.contains(word)) {
                return true;
            }
        }

        return false;
    }

    /** Clean and normalize text for consistent processing */
    public String normalizeText(String text) {
        if (!StringUtils.hasText(text)) {
            return "";
        }

        return processText(text).toLowerCase();
    }
}
