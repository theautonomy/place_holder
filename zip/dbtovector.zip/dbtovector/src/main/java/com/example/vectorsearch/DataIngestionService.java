package com.example.vectorsearch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class DataIngestionService {

    private static final Logger logger = LoggerFactory.getLogger(DataIngestionService.class);

    @Autowired private JdbcTemplate jdbcTemplate;

    @Autowired private MyDocumentRepository documentRepository;

    @Autowired private VectorStore vectorStore;

    @Autowired private TextProcessingService textProcessingService;

    @Value("${app.vector-store.batch-size:100}")
    private int batchSize;

    private final ObjectMapper objectMapper = new ObjectMapper();

    /** Ingest data from a single table based on configuration */
    @Async
    @Transactional
    public CompletableFuture<Integer> ingestTable(TableIngestionConfig config) {
        logger.info("Starting ingestion for table: {}", config.getTableName());

        try {
            if (!config.isEnabled()) {
                logger.info("Skipping disabled table: {}", config.getTableName());
                return CompletableFuture.completedFuture(0);
            }

            Filter.Expression typeFilter =
                    new Filter.Expression(
                            Filter.ExpressionType.EQ,
                            new Filter.Key("category"),
                            new Filter.Value("table"));

            vectorStore.delete(typeFilter);

            List<Map<String, Object>> rows = fetchTableData(config);
            logger.info("Fetched {} rows from table: {}", rows.size(), config.getTableName());

            List<MyDocument> documents = new ArrayList<>();
            List<Document> aiDocuments = new ArrayList<>();

            for (Map<String, Object> row : rows) {
                try {
                    MyDocument document = createDocumentFromRow(row, config);
                    Document aiDocument = createAiDocumentFromDocument(document);

                    documents.add(document);
                    aiDocuments.add(aiDocument);

                    // Process in batches
                    if (documents.size() >= batchSize) {
                        processBatch(documents, aiDocuments);
                        documents.clear();
                        aiDocuments.clear();
                    }
                } catch (Exception e) {
                    logger.error(
                            "Error processing row from table {}: {}",
                            config.getTableName(),
                            e.getMessage());
                }
            }

            // Process remaining documents
            if (!documents.isEmpty()) {
                processBatch(documents, aiDocuments);
            }

            int totalProcessed = rows.size();
            logger.info(
                    "Completed ingestion for table: {}. Processed {} records",
                    config.getTableName(),
                    totalProcessed);

            return CompletableFuture.completedFuture(totalProcessed);

        } catch (Exception e) {
            logger.error("Error ingesting table {}: {}", config.getTableName(), e.getMessage(), e);
            throw new RuntimeException("Failed to ingest table: " + config.getTableName(), e);
        }
    }

    /** Ingest multiple tables */
    public Map<String, Integer> ingestTables(List<TableIngestionConfig> configs) {
        Map<String, Integer> results = new HashMap<>();

        List<CompletableFuture<Integer>> futures =
                configs.stream()
                        .map(
                                config ->
                                        ingestTable(config)
                                                .whenComplete(
                                                        (count, throwable) -> {
                                                            if (throwable != null) {
                                                                logger.error(
                                                                        "Failed to ingest table: {}",
                                                                        config.getTableName());
                                                                results.put(
                                                                        config.getTableName(), 0);
                                                            } else {
                                                                results.put(
                                                                        config.getTableName(),
                                                                        count);
                                                            }
                                                        }))
                        .collect(Collectors.toList());

        // Wait for all to complete
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

        return results;
    }

    private List<Map<String, Object>> fetchTableData(TableIngestionConfig config) {
        StringBuilder sql = new StringBuilder("SELECT ");

        // Add primary key
        sql.append(config.getPrimaryKeyColumn()).append(", ");

        // Add title column if different from primary key
        if (config.getTitleColumn() != null
                && !config.getTitleColumn().equals(config.getPrimaryKeyColumn())) {
            sql.append(config.getTitleColumn()).append(", ");
        }

        // Add text columns
        sql.append(String.join(", ", config.getTextColumns()));

        // Add additional metadata columns if specified
        if (config.getAdditionalMetadata() != null) {
            for (String column : config.getAdditionalMetadata().keySet()) {
                sql.append(", ").append(column);
            }
        }

        sql.append(" FROM ").append(config.getTableName());

        // Add WHERE clause if specified
        if (config.getWhereClause() != null && !config.getWhereClause().trim().isEmpty()) {
            sql.append(" WHERE ").append(config.getWhereClause());
        }

        logger.debug("Executing SQL: {}", sql.toString());
        return jdbcTemplate.queryForList(sql.toString());
    }

    private MyDocument createDocumentFromRow(Map<String, Object> row, TableIngestionConfig config) {
        String primaryKey = String.valueOf(row.get(config.getPrimaryKeyColumn()));

        // Create title
        String title =
                config.getTitleColumn() != null
                        ? String.valueOf(row.get(config.getTitleColumn()))
                        : config.getTableName() + "_" + primaryKey;

        // Combine text from all specified columns
        StringBuilder contentBuilder = new StringBuilder();
        for (String column : config.getTextColumns()) {
            Object value = row.get(column);
            if (value != null) {
                if (contentBuilder.length() > 0) {
                    contentBuilder.append("\n\n");
                }
                contentBuilder.append(column).append(": ").append(value.toString());
            }
        }

        // Create metadata
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("source_table", config.getTableName());
        metadata.put("primary_key", primaryKey);
        metadata.put("category", "table");

        if (config.getAdditionalMetadata() != null) {
            for (Map.Entry<String, String> entry : config.getAdditionalMetadata().entrySet()) {
                Object value = row.get(entry.getKey());
                if (value != null) {
                    metadata.put(entry.getValue(), value);
                }
            }
        }

        // CHECK -
        // Should just use jpa to select the records including all columsn
        MyDocument document =
                new MyDocument(title, contentBuilder.toString(), config.getTableName(), primaryKey);
        document.setId((Long) row.get("ID"));
        // ADD - create_timestamp
        // ADD - update_timestamp

        try {
            document.setMetadata(objectMapper.writeValueAsString(metadata));
        } catch (Exception e) {
            logger.error("Error serializing metadata: {}", e.getMessage());
            document.setMetadata("{}");
        }

        return document;
    }

    private Document createAiDocumentFromDocument(MyDocument document) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("id", document.getId());
        metadata.put("title", document.getTitle());
        metadata.put("source_table", document.getSourceTable());
        metadata.put("source_id", document.getSourceId());

        // CHECK -
        // metadata.put("created_at", document.getCreatedAt());

        // Parse stored metadata
        // CHECK -
        try {
            if (document.getMetadata() != null) {
                Map<String, Object> storedMetadata =
                        objectMapper.readValue(document.getMetadata(), Map.class);
                metadata.putAll(storedMetadata);
            }
        } catch (Exception e) {
            logger.warn("Error parsing stored metadata: {}", e.getMessage());
        }

        // Process content for better semantic search
        String processedContent = textProcessingService.processText(document.getContent());

        return new Document(processedContent, metadata);
    }

    private void processBatch(List<MyDocument> documents, List<Document> aiDocuments) {
        try {
            // Save to relational database
            logger.info("Before saving documents, current count: {}", documents.size());
            List<MyDocument> allDocuments = documentRepository.findAll();
            allDocuments.forEach(doc -> logger.debug("Document: {}", doc.toString()));

            // CHECK -
            // documentRepository.saveAll(documents);
            // logger.info("Saved {} documents to database", documents.size());

            allDocuments = documentRepository.findAll();

            logger.info("Before saving documents, current count: {}", documents.size());
            allDocuments.forEach(doc -> logger.debug("Document: {}", doc.toString()));

            // Add to vector store
            vectorStore.add(aiDocuments);
            logger.debug("Added {} documents to vector store", aiDocuments.size());

        } catch (Exception e) {
            logger.error("Error processing batch: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to process batch", e);
        }
    }

    /** Clear all data for a specific table */
    @Transactional
    public void clearTableData(String tableName) {
        logger.info("Clearing data for table: {}", tableName);

        // Delete from relational database
        List<MyDocument> documents = documentRepository.findBySourceTable(tableName);
        documentRepository.deleteAll(documents);

        // Note: Redis vector store doesn't have direct table-based deletion
        // You might need to implement custom logic based on your requirements

        logger.info("Cleared {} documents for table: {}", documents.size(), tableName);
    }

    /** Get ingestion statistics */
    public Map<String, Long> getIngestionStats() {
        Map<String, Long> stats = new HashMap<>();

        List<String> sourceTables = documentRepository.findDistinctSourceTables();
        for (String table : sourceTables) {
            long count = documentRepository.countBySourceTable(table);
            stats.put(table, count);
        }

        return stats;
    }
}
