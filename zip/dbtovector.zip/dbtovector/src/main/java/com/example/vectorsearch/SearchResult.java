package com.example.vectorsearch;

import java.util.Map;

public class SearchResult {

    private Long id;
    private String title;
    private String content;
    private String sourceTable;
    private String sourceId;
    private double similarityScore;
    private Map<String, Object> metadata;

    public SearchResult() {}

    public SearchResult(
            Long id,
            String title,
            String content,
            String sourceTable,
            String sourceId,
            double similarityScore) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.sourceTable = sourceTable;
        this.sourceId = sourceId;
        this.similarityScore = similarityScore;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSourceTable() {
        return sourceTable;
    }

    public void setSourceTable(String sourceTable) {
        this.sourceTable = sourceTable;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public double getSimilarityScore() {
        return similarityScore;
    }

    public void setSimilarityScore(double similarityScore) {
        this.similarityScore = similarityScore;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }

    /** Get a truncated version of content for display */
    public String getContentPreview(int maxLength) {
        if (content == null) return "";
        if (content.length() <= maxLength) return content;
        return content.substring(0, maxLength) + "...";
    }

    /** Get similarity score as a percentage */
    public String getSimilarityPercentage() {
        return String.format("%.1f%%", similarityScore * 100);
    }

    @Override
    public String toString() {
        return "SearchResult{"
                + "id="
                + id
                + ", title='"
                + title
                + '\''
                + ", sourceTable='"
                + sourceTable
                + '\''
                + ", sourceId='"
                + sourceId
                + '\''
                + ", similarityScore="
                + similarityScore
                + '}';
    }
}
