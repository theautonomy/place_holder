const API_BASE = '/api';

// Load repositories on page load
document.addEventListener('DOMContentLoaded', () => {
    loadRepositories();
});

// Load repositories
async function loadRepositories() {
    try {
        const response = await fetch(`${API_BASE}/repositories`);
        if (!response.ok) throw new Error('Failed to load repositories');

        const repos = await response.json();
        const select = document.getElementById('repoSelect');

        // Clear existing options (except first)
        select.innerHTML = '<option value="">-- Select a Repository --</option>';

        // Add repository options
        repos.forEach(repo => {
            const option = document.createElement('option');
            option.value = repo.fullName;
            option.textContent = `${repo.fullName}${repo.isPrivate ? ' 🔒' : ''}`;
            select.appendChild(option);
        });

        hideLoading();
    } catch (error) {
        showError('Failed to load repositories: ' + error.message);
    }
}

// Load dashboard data
async function loadDashboard() {
    const repoSelect = document.getElementById('repoSelect');
    const workflowSelect = document.getElementById('workflowSelect');

    const selectedRepo = repoSelect.value;
    const selectedWorkflow = workflowSelect.value;

    if (!selectedRepo) {
        hideAllSections();
        return;
    }

    showLoading();
    hideError();

    const [owner, repo] = selectedRepo.split('/');

    try {
        // Load workflows for the repository
        await loadWorkflows(owner, repo);

        // Load dashboard data
        const [dashboardData, deploymentData] = await Promise.all([
            fetch(`${API_BASE}/dashboard/${owner}/${repo}?workflow=${selectedWorkflow}`).then(r => r.json()),
            fetch(`${API_BASE}/deployments/${owner}/${repo}`).then(r => r.json())
        ]);

        // Update UI
        updateMetrics(dashboardData.metrics);
        updateWorkflow(dashboardData.workflow);
        updateDeployments(deploymentData);

        showAllSections();
        hideLoading();
    } catch (error) {
        showError('Failed to load dashboard: ' + error.message);
        hideLoading();
    }
}

// Load available workflows
async function loadWorkflows(owner, repo) {
    try {
        const response = await fetch(`${API_BASE}/workflows/${owner}/${repo}`);
        const workflows = await response.json();

        const select = document.getElementById('workflowSelect');
        const currentValue = select.value;

        select.innerHTML = '';

        workflows.forEach(workflow => {
            const option = document.createElement('option');
            option.value = workflow;
            option.textContent = workflow;
            select.appendChild(option);
        });

        // Try to restore previous selection
        if (currentValue && workflows.includes(currentValue)) {
            select.value = currentValue;
        }
    } catch (error) {
        console.error('Failed to load workflows:', error);
    }
}

// Update metrics section
function updateMetrics(metrics) {
    document.getElementById('runsToday').textContent = metrics.runsToday;
    document.getElementById('runsThisWeek').textContent = metrics.runsThisWeek;
    document.getElementById('failedBuilds').textContent = metrics.failedBuilds;
    document.getElementById('avgDuration').textContent = formatDuration(metrics.avgDurationSeconds);
}

// Update workflow section
function updateWorkflow(workflow) {
    document.getElementById('totalRuns').textContent = workflow.totalRuns;
    document.getElementById('successRate').textContent = workflow.successRate.toFixed(1) + '%';
    document.getElementById('inProgress').textContent = workflow.inProgressRuns;

    const tbody = document.getElementById('workflowTableBody');
    tbody.innerHTML = '';

    workflow.recentRuns.forEach(run => {
        const tr = document.createElement('tr');

        const status = run.conclusion || run.status;
        const statusClass = getStatusClass(status);

        tr.innerHTML = `
            <td>#${run.runNumber}</td>
            <td><span class="status-badge status-${statusClass}">${status}</span></td>
            <td>${run.branch}</td>
            <td>${formatTimeAgo(run.createdAt)}</td>
            <td><a href="${run.url}" target="_blank" class="btn-small">View</a></td>
        `;

        tbody.appendChild(tr);
    });
}

// Update deployments section
function updateDeployments(data) {
    if (!data.metrics) return;

    document.getElementById('totalDeployments').textContent = data.metrics.totalDeployments;
    document.getElementById('deploymentsToday').textContent = data.metrics.deploymentsToday;
    document.getElementById('deploymentsLast7Days').textContent = data.metrics.deploymentsLast7Days;
    document.getElementById('deploymentSuccessRate').textContent = data.metrics.overallSuccessRate.toFixed(1) + '%';

    const container = document.getElementById('environmentsContainer');
    container.innerHTML = '';

    if (data.environments && data.environments.length > 0) {
        data.environments.forEach(env => {
            const card = createEnvironmentCard(env);
            container.appendChild(card);
        });
    } else {
        container.innerHTML = '<p style="color: #666;">No deployments found</p>';
    }
}

// Create environment card
function createEnvironmentCard(env) {
    const card = document.createElement('div');
    card.className = 'environment-card';

    const statusClass = getStatusClass(env.currentStatus);

    let deploymentInfo = '';
    if (env.latestDeployment) {
        deploymentInfo = `
            <div class="env-info">
                Latest: ${env.latestDeployment.sha}<br>
                By: ${env.latestDeployment.creator}<br>
                ${formatTimeAgo(env.latestDeployment.createdAt)}
            </div>
        `;
    }

    card.innerHTML = `
        <h4>
            <span class="env-status ${statusClass}"></span>
            ${env.name.toUpperCase()}
        </h4>
        ${deploymentInfo}
        <div class="env-metrics">
            <div class="env-metric">
                <div class="env-metric-value">${env.deploymentsLast30Days}</div>
                <div class="env-metric-label">Last 30 Days</div>
            </div>
            <div class="env-metric">
                <div class="env-metric-value">${env.successRate.toFixed(1)}%</div>
                <div class="env-metric-label">Success Rate</div>
            </div>
        </div>
    `;

    return card;
}

// Helper functions
function formatDuration(seconds) {
    if (!seconds || seconds === 0) return 'N/A';

    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);

    if (minutes === 0) return `${secs}s`;
    return `${minutes}m ${secs}s`;
}

function formatTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);

    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
}

function getStatusClass(status) {
    if (!status) return 'unknown';

    const statusLower = status.toLowerCase();

    if (statusLower.includes('success')) return 'success';
    if (statusLower.includes('failure') || statusLower.includes('error')) return 'failure';
    if (statusLower.includes('progress')) return 'in_progress';
    if (statusLower.includes('queued') || statusLower.includes('pending')) return 'queued';

    return 'unknown';
}

function showLoading() {
    document.getElementById('loading').style.display = 'block';
}

function hideLoading() {
    document.getElementById('loading').style.display = 'none';
}

function showError(message) {
    const errorDiv = document.getElementById('error');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function hideError() {
    document.getElementById('error').style.display = 'none';
}

function showAllSections() {
    document.getElementById('metricsSection').style.display = 'block';
    document.getElementById('workflowSection').style.display = 'block';
    document.getElementById('deploymentSection').style.display = 'block';
}

function hideAllSections() {
    document.getElementById('metricsSection').style.display = 'none';
    document.getElementById('workflowSection').style.display = 'none';
    document.getElementById('deploymentSection').style.display = 'none';
}
