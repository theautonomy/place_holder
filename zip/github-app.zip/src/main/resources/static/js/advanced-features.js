// Advanced Features JavaScript v2
console.log('Advanced Features JS loaded - Version 2');

const API_BASE = '/api/rag/advanced';

// Feature navigation
function showFeature(featureName) {
    // Hide all feature sections
    document.querySelectorAll('.feature-section').forEach(section => {
        section.classList.remove('active');
    });

    // Remove active class from all tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });

    // Show selected feature
    document.getElementById(featureName).classList.add('active');

    // Add active class to clicked tab
    event.target.classList.add('active');
}

// Utility functions
function showError(elementId, message) {
    const element = document.getElementById(elementId);
    element.style.display = 'block';
    element.innerHTML = `<div class="error-message">❌ Error: ${message}</div>`;
}

function showSuccess(elementId, content) {
    console.log('showSuccess called for:', elementId);
    const element = document.getElementById(elementId);
    console.log('Element found:', element);
    element.innerHTML = content;

    // Also show the parent results card if it exists
    const parentId = elementId.replace('-content', '-results');
    const parent = document.getElementById(parentId);
    console.log('Parent ID:', parentId, 'Parent element:', parent);
    if (parent) {
        parent.style.display = 'block';
        console.log('Parent display set to block');
    }
}

function getFilesList(textareaId) {
    const text = document.getElementById(textareaId).value;
    return text.split('\n').filter(line => line.trim()).map(line => line.trim());
}

// 1. PREDICTIVE ANALYSIS

async function predictFailure() {
    const repository = document.getElementById('pred-repo').value;
    const branch = document.getElementById('pred-branch').value;
    const changedFiles = getFilesList('pred-files');

    console.log('Predicting failure for:', { repository, branch, changedFiles });

    if (!repository || !branch || changedFiles.length === 0) {
        showError('pred-content', 'Please fill in all fields');
        document.getElementById('pred-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/predict-failure`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repository, branch, changedFiles })
        });

        if (!response.ok) throw new Error('Failed to predict failure');

        const data = await response.json();
        console.log('Received data:', data);
        displayPredictionResults(data);
    } catch (error) {
        console.error('Error:', error);
        showError('pred-content', error.message);
        document.getElementById('pred-results').style.display = 'block';
    }
}

function displayPredictionResults(data) {
    console.log('Displaying prediction results:', data);
    const percentage = (data.failureProbability * 100).toFixed(0);
    const riskClass = percentage >= 70 ? 'risk-critical' : percentage >= 50 ? 'risk-high' : percentage >= 30 ? 'risk-medium' : 'risk-low';

    let html = `
        <div class="prediction-summary ${riskClass}">
            <h4>Failure Probability: ${percentage}%</h4>
            <p class="confidence">Confidence: ${data.confidence}</p>
        </div>

        <div class="recommendation-box">
            <h4>📋 Recommendation</h4>
            <pre>${data.recommendation}</pre>
        </div>
    `;

    if (data.predictedErrors && data.predictedErrors.length > 0) {
        html += `
            <h4>Most Likely Errors:</h4>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>Error Type</th>
                        <th>Occurrences</th>
                        <th>Probability</th>
                    </tr>
                </thead>
                <tbody>
        `;

        data.predictedErrors.forEach(error => {
            const prob = (error.probability * 100).toFixed(0);
            html += `
                <tr>
                    <td>${error.errorType}</td>
                    <td>${error.occurrenceCount}</td>
                    <td>${prob}%</td>
                </tr>
            `;
        });

        html += `</tbody></table>`;
    } else {
        html += `<p class="info-message">No specific error patterns identified.</p>`;
    }

    console.log('Calling showSuccess with html length:', html.length);
    showSuccess('pred-content', html);
    console.log('showSuccess completed');
}

async function analyzeFileRisk() {
    const repository = document.getElementById('risk-repo').value;
    const changedFiles = getFilesList('risk-files');

    if (!repository || changedFiles.length === 0) {
        showError('risk-content', 'Please fill in all fields');
        document.getElementById('risk-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/analyze-file-risk`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repository, changedFiles })
        });

        if (!response.ok) throw new Error('Failed to analyze file risk');

        const data = await response.json();
        displayFileRiskResults(data);
    } catch (error) {
        showError('risk-content', error.message);
        document.getElementById('risk-results').style.display = 'block';
    }
}

function displayFileRiskResults(data) {
    if (!data || data.length === 0) {
        showSuccess('risk-content', '<p class="info-message">✅ No high-risk files detected! All files have low incident rates.</p>');
        return;
    }

    let html = `
        <table class="results-table">
            <thead>
                <tr>
                    <th>File Path</th>
                    <th>Incident Rate</th>
                    <th>Total Modifications</th>
                    <th>Past Issues</th>
                </tr>
            </thead>
            <tbody>
    `;

    data.forEach(file => {
        const ratePercent = (file.incidentRate * 100).toFixed(0);
        const riskClass = file.incidentRate >= 0.5 ? 'risk-critical' : file.incidentRate >= 0.3 ? 'risk-high' : 'risk-medium';

        html += `
            <tr class="${riskClass}">
                <td><code>${file.filePath}</code></td>
                <td><strong>${ratePercent}%</strong></td>
                <td>${file.totalModifications} (${file.modificationsWithIncidents} incidents)</td>
                <td><small>${file.pastIssues.slice(0, 2).join('; ')}</small></td>
            </tr>
        `;
    });

    html += `</tbody></table>`;
    showSuccess('risk-content', html);
}

// 2. PROACTIVE WARNINGS

async function generateWarnings() {
    const repository = document.getElementById('warn-repo').value;
    const environment = document.getElementById('warn-env').value;
    const changedFiles = getFilesList('warn-files');
    const commitMessages = getFilesList('warn-commits');
    const hasDatabaseChanges = document.getElementById('warn-db').checked;
    const hasConfigChanges = document.getElementById('warn-config').checked;
    const hasCriticalFiles = document.getElementById('warn-critical').checked;

    if (!repository || changedFiles.length === 0) {
        showError('warnings-content', 'Please fill in required fields');
        document.getElementById('warnings-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/deployment-warnings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                repository,
                environment,
                changedFiles,
                commitMessages,
                hasDatabaseChanges,
                hasConfigChanges,
                hasCriticalFiles,
                deploymentTime: null
            })
        });

        if (!response.ok) throw new Error('Failed to generate warnings');

        const data = await response.json();
        displayWarnings(data);
    } catch (error) {
        showError('warnings-content', error.message);
        document.getElementById('warnings-results').style.display = 'block';
    }
}

function displayWarnings(warnings) {
    if (!warnings || warnings.length === 0) {
        showSuccess('warnings-content', '<p class="success-message">✅ No warnings! This deployment looks safe.</p>');
        return;
    }

    let html = '<div class="warnings-list">';

    warnings.forEach(warning => {
        const severityIcon = {
            'CRITICAL': '🔴',
            'HIGH': '🟠',
            'MEDIUM': '🟡',
            'LOW': '🔵'
        }[warning.severity] || '⚪';

        html += `
            <div class="warning-card severity-${warning.severity.toLowerCase()}">
                <h4>${severityIcon} ${warning.severity}: ${warning.title}</h4>
                <p><strong>Issue:</strong> ${warning.description}</p>
                <p><strong>Recommendation:</strong> ${warning.recommendation}</p>
                <div class="action-items">
                    <strong>Action Items:</strong>
                    <ul>
                        ${warning.actionItems.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
    });

    html += '</div>';
    showSuccess('warnings-content', html);
}

// 3. TEAM LEARNING

async function getTeamInsights() {
    const repository = document.getElementById('learn-repo').value;
    const errorMessage = document.getElementById('learn-error').value;

    if (!repository || !errorMessage) {
        showError('insights-content', 'Please fill in all fields');
        document.getElementById('insights-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/team-insights`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repository, errorMessage })
        });

        if (!response.ok) throw new Error('Failed to get team insights');

        const data = await response.json();
        displayTeamInsights(data);
    } catch (error) {
        showError('insights-content', error.message);
        document.getElementById('insights-results').style.display = 'block';
    }
}

function displayTeamInsights(data) {
    let html = `
        <div class="insights-grid">
            <div class="insight-card">
                <div class="insight-value">${data.totalOccurrences}</div>
                <div class="insight-label">Total Occurrences</div>
            </div>
            <div class="insight-card">
                <div class="insight-value">${Math.round(data.averageFixTimeMinutes)} min</div>
                <div class="insight-label">Average Fix Time</div>
            </div>
            ${data.mostFrequentFixer ? `
            <div class="insight-card">
                <div class="insight-value">👤 ${data.mostFrequentFixer}</div>
                <div class="insight-label">Team Expert</div>
            </div>
            ` : ''}
        </div>

        ${data.commonRootCause ? `
        <div class="info-box">
            <h4>Common Root Cause</h4>
            <p>${data.commonRootCause}</p>
        </div>
        ` : ''}

        ${data.typicalFix ? `
        <div class="solution-box">
            <h4>💡 Typical Fix (Works ${data.totalOccurrences > 0 ? '90' : '0'}% of the time)</h4>
            <pre>${data.typicalFix}</pre>
        </div>
        ` : ''}

        ${data.preventionTips && data.preventionTips.length > 0 ? `
        <div class="tips-box">
            <h4>🛡️ Prevention Tips</h4>
            <ul>
                ${data.preventionTips.map(tip => `<li>${tip}</li>`).join('')}
            </ul>
        </div>
        ` : ''}
    `;

    showSuccess('insights-content', html);
}

async function getRecurringPatterns() {
    const repository = document.getElementById('pattern-repo').value;
    const sinceMonths = document.getElementById('pattern-months').value;

    if (!repository) {
        showError('patterns-content', 'Please enter repository name');
        document.getElementById('patterns-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/recurring-patterns?repository=${encodeURIComponent(repository)}&sinceMonths=${sinceMonths}`);

        if (!response.ok) throw new Error('Failed to get recurring patterns');

        const data = await response.json();
        displayRecurringPatterns(data);
    } catch (error) {
        showError('patterns-content', error.message);
        document.getElementById('patterns-results').style.display = 'block';
    }
}

function displayRecurringPatterns(patterns) {
    if (!patterns || patterns.length === 0) {
        showSuccess('patterns-content', '<p class="info-message">No recurring patterns found.</p>');
        return;
    }

    let html = '<div class="patterns-list">';

    patterns.forEach((pattern, index) => {
        const resolutionRate = (pattern.resolutionRate * 100).toFixed(0);

        html += `
            <div class="pattern-card">
                <h4>${index + 1}. ${pattern.errorType} <span class="badge">${pattern.occurrences} occurrences</span></h4>
                <p class="pattern-description">${pattern.description}</p>
                <div class="pattern-stats">
                    <span>📊 Resolution Rate: ${resolutionRate}%</span>
                    <span>⏱️ Avg Fix Time: ${Math.round(pattern.avgResolutionTime)} min</span>
                </div>
                ${pattern.recommendedSolution ? `
                <div class="pattern-solution">
                    <strong>Recommended Solution:</strong>
                    <p>${pattern.recommendedSolution}</p>
                </div>
                ` : ''}
            </div>
        `;
    });

    html += '</div>';
    showSuccess('patterns-content', html);
}

async function getTeamExperts() {
    const repository = document.getElementById('expert-repo').value;

    if (!repository) {
        showError('experts-content', 'Please enter repository name');
        document.getElementById('experts-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/team-experts?repository=${encodeURIComponent(repository)}`);

        if (!response.ok) throw new Error('Failed to get team experts');

        const data = await response.json();
        displayTeamExperts(data);
    } catch (error) {
        showError('experts-content', error.message);
        document.getElementById('experts-results').style.display = 'block';
    }
}

function displayTeamExperts(experts) {
    if (!experts || Object.keys(experts).length === 0) {
        showSuccess('experts-content', '<p class="info-message">No expert data available yet.</p>');
        return;
    }

    let html = `
        <table class="results-table">
            <thead>
                <tr>
                    <th>Expert</th>
                    <th>Expertise Area</th>
                    <th>Fixes</th>
                    <th>Effectiveness</th>
                    <th>Avg Fix Time</th>
                </tr>
            </thead>
            <tbody>
    `;

    Object.entries(experts).forEach(([errorType, expert]) => {
        const effectiveness = (expert.avgEffectiveness * 10).toFixed(1);

        html += `
            <tr>
                <td><strong>👤 ${expert.name}</strong></td>
                <td>${expert.expertise}</td>
                <td>${expert.fixCount}</td>
                <td>${effectiveness}/10</td>
                <td>${Math.round(expert.avgFixTimeMinutes)} min</td>
            </tr>
        `;
    });

    html += `</tbody></table>`;
    showSuccess('experts-content', html);
}

// 4. SMART ESCALATION

async function recommendExpert() {
    const repository = document.getElementById('esc-repo').value;
    const errorMessage = document.getElementById('esc-error').value;

    if (!repository || !errorMessage) {
        showError('expert-content', 'Please fill in all fields');
        document.getElementById('expert-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/recommend-expert`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repository, errorMessage })
        });

        if (!response.ok) throw new Error('Failed to recommend expert');

        const data = await response.json();
        displayExpertRecommendations(data);
    } catch (error) {
        showError('expert-content', error.message);
        document.getElementById('expert-results').style.display = 'block';
    }
}

function displayExpertRecommendations(experts) {
    if (!experts || experts.length === 0) {
        showSuccess('expert-content', '<p class="info-message">No expert recommendations available.</p>');
        return;
    }

    let html = `
        <div class="experts-grid">
    `;

    experts.forEach((expert, index) => {
        const effectiveness = (expert.avgEffectiveness * 10).toFixed(1);
        const rank = ['🥇', '🥈', '🥉'][index] || '🏅';

        html += `
            <div class="expert-card">
                <div class="expert-rank">${rank}</div>
                <h4>👤 ${expert.name}</h4>
                <div class="expert-stats">
                    <div class="stat">
                        <span class="stat-value">${expert.fixCount}</span>
                        <span class="stat-label">Fixes</span>
                    </div>
                    <div class="stat">
                        <span class="stat-value">${effectiveness}/10</span>
                        <span class="stat-label">Effectiveness</span>
                    </div>
                    ${expert.avgFixTimeMinutes > 0 ? `
                    <div class="stat">
                        <span class="stat-value">${Math.round(expert.avgFixTimeMinutes)}m</span>
                        <span class="stat-label">Avg Time</span>
                    </div>
                    ` : ''}
                </div>
            </div>
        `;
    });

    html += '</div>';
    showSuccess('expert-content', html);
}

async function estimateTime() {
    const repository = document.getElementById('time-repo').value;
    const errorMessage = document.getElementById('time-error').value;

    if (!repository || !errorMessage) {
        showError('time-content', 'Please fill in all fields');
        document.getElementById('time-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/estimate-resolution-time`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ repository, errorMessage })
        });

        if (!response.ok) throw new Error('Failed to estimate time');

        const data = await response.json();
        displayTimeEstimate(data);
    } catch (error) {
        showError('time-content', error.message);
        document.getElementById('time-results').style.display = 'block';
    }
}

function displayTimeEstimate(estimate) {
    const confidenceClass = {
        'HIGH': 'confidence-high',
        'MEDIUM': 'confidence-medium',
        'LOW': 'confidence-low'
    }[estimate.confidence] || '';

    let html = `
        <div class="time-estimate ${confidenceClass}">
            <h4>⏱️ Estimated Resolution Time</h4>
            <div class="time-range">
                <span class="time-value">${estimate.minMinutes}</span> -
                <span class="time-value">${estimate.maxMinutes}</span> minutes
            </div>
            <div class="time-average">Average: <strong>${estimate.averageMinutes} minutes</strong></div>
            <p class="confidence-badge">Confidence: ${estimate.confidence}</p>
            <p class="explanation">${estimate.explanation}</p>
        </div>
    `;

    showSuccess('time-content', html);
}

// 5. DEPLOYMENT OPTIMIZER

async function getOptimalWindows() {
    const repository = document.getElementById('opt-repo').value;
    const environment = document.getElementById('opt-env').value;

    if (!repository) {
        showError('optimal-content', 'Please enter repository name');
        document.getElementById('optimal-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/optimal-windows?repository=${encodeURIComponent(repository)}&environment=${environment}`);

        if (!response.ok) throw new Error('Failed to get optimal windows');

        const data = await response.json();
        displayOptimalWindows(data);
    } catch (error) {
        showError('optimal-content', error.message);
        document.getElementById('optimal-results').style.display = 'block';
    }
}

function displayOptimalWindows(data) {
    let html = `<p class="summary">${data.summary}</p>`;

    if (data.recommendedWindows && data.recommendedWindows.length > 0) {
        html += `
            <h4>🟢 Best Deployment Times:</h4>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Day & Time</th>
                        <th>Success Rate</th>
                        <th>Deployments</th>
                    </tr>
                </thead>
                <tbody>
        `;

        data.recommendedWindows.forEach((window, index) => {
            const rate = (window.successRate * 100).toFixed(0);
            const rank = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'][index] || '';

            html += `
                <tr>
                    <td>${rank}</td>
                    <td><strong>${window.dayName}, ${window.timeRange}</strong></td>
                    <td class="success-rate">${rate}%</td>
                    <td>${window.totalDeployments}</td>
                </tr>
            `;
        });

        html += `</tbody></table>`;
    }

    if (data.worstWindows && data.worstWindows.length > 0) {
        html += `
            <h4 style="margin-top: 20px;">🔴 Times to Avoid:</h4>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>Day & Time</th>
                        <th>Success Rate</th>
                        <th>Deployments</th>
                    </tr>
                </thead>
                <tbody>
        `;

        data.worstWindows.slice(0, 3).forEach(window => {
            const rate = (window.successRate * 100).toFixed(0);

            html += `
                <tr class="risk-high">
                    <td>${window.dayName}, ${window.timeRange}</td>
                    <td>${rate}%</td>
                    <td>${window.totalDeployments}</td>
                </tr>
            `;
        });

        html += `</tbody></table>`;
    }

    showSuccess('optimal-content', html);
}

async function evaluateCurrentTime() {
    const repository = document.getElementById('eval-repo').value;
    const environment = document.getElementById('eval-env').value;

    if (!repository) {
        showError('eval-content', 'Please enter repository name');
        document.getElementById('eval-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/evaluate-current-time?repository=${encodeURIComponent(repository)}&environment=${environment}`);

        if (!response.ok) throw new Error('Failed to evaluate current time');

        const data = await response.json();
        displayTimeEvaluation(data);
    } catch (error) {
        showError('eval-content', error.message);
        document.getElementById('eval-results').style.display = 'block';
    }
}

function displayTimeEvaluation(data) {
    const ratingClass = {
        'EXCELLENT': 'rating-excellent',
        'GOOD': 'rating-good',
        'FAIR': 'rating-fair',
        'POOR': 'rating-poor',
        'UNKNOWN': 'rating-unknown'
    }[data.rating] || '';

    const ratingIcon = {
        'EXCELLENT': '✅',
        'GOOD': '👍',
        'FAIR': '⚠️',
        'POOR': '❌',
        'UNKNOWN': 'ℹ️'
    }[data.rating] || '';

    let html = `
        <div class="evaluation ${ratingClass}">
            <h4>${ratingIcon} Current Time: ${data.rating}</h4>
            ${data.successRate !== null ? `<p class="success-rate-large">${(data.successRate * 100).toFixed(0)}% Success Rate</p>` : ''}
            <p class="recommendation-text">${data.recommendation}</p>
        </div>
    `;

    if (data.concerns && data.concerns.length > 0) {
        html += `
            <div class="concerns-box">
                <h4>⚠️ Concerns:</h4>
                <ul>
                    ${data.concerns.map(concern => `<li>${concern}</li>`).join('')}
                </ul>
            </div>
        `;
    }

    if (data.suggestedAlternative) {
        const alt = data.suggestedAlternative;
        html += `
            <div class="alternative-box">
                <h4>💡 Better Alternative:</h4>
                <p><strong>${alt.dayName}, ${alt.timeRange}</strong></p>
                <p>Success Rate: ${(alt.successRate * 100).toFixed(0)}%</p>
            </div>
        `;
    }

    showSuccess('eval-content', html);
}

async function suggestNextWindow() {
    const repository = document.getElementById('next-repo').value;
    const environment = document.getElementById('next-env').value;

    if (!repository) {
        showError('next-content', 'Please enter repository name');
        document.getElementById('next-results').style.display = 'block';
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/suggest-next-window?repository=${encodeURIComponent(repository)}&environment=${environment}`);

        if (!response.ok) throw new Error('Failed to suggest next window');

        const data = await response.json();
        displayNextWindow(data);
    } catch (error) {
        showError('next-content', error.message);
        document.getElementById('next-results').style.display = 'block';
    }
}

function displayNextWindow(data) {
    if (!data.window) {
        showSuccess('next-content', `<p class="info-message">${data.explanation}</p>`);
        return;
    }

    const window = data.window;
    const successRate = (window.successRate * 100).toFixed(0);

    let html = `
        <div class="next-window">
            <h4>📅 Next Recommended Deployment:</h4>
            <div class="window-time">
                <strong>${window.dayName}, ${window.timeRange}</strong>
            </div>
            <div class="window-stats">
                <span>Success Rate: <strong>${successRate}%</strong></span>
                <span>Based on ${window.totalDeployments} deployments</span>
            </div>
            ${data.nextOccurrence ? `
            <p class="next-occurrence">Next occurrence: ${new Date(data.nextOccurrence).toLocaleString()}</p>
            ` : ''}
            <p class="explanation">${data.explanation}</p>
        </div>
    `;

    showSuccess('next-content', html);
}
