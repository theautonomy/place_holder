// Build Failure Search JavaScript
const API_BASE = '/api/rag/advanced';

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    loadStatistics();
});

/**
 * Load statistics overview
 */
async function loadStatistics(repository = null) {
    try {
        const url = repository
            ? `${API_BASE}/search-statistics?repository=${encodeURIComponent(repository)}`
            : `${API_BASE}/search-statistics`;

        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to load statistics');

        const stats = await response.json();

        // Update UI
        document.getElementById('stat-total').textContent = stats.totalFailures || 0;
        document.getElementById('stat-unresolved').textContent = stats.unresolvedFailures || 0;
        document.getElementById('stat-recent').textContent = stats.recentFailuresCount || 0;

        const avgTime = stats.averageTimeToFix;
        document.getElementById('stat-avg-time').textContent =
            avgTime ? Math.round(avgTime) : 'N/A';
    } catch (error) {
        console.error('Error loading statistics:', error);
        // Don't show error to user for statistics - just log it
    }
}

/**
 * Perform search based on user input
 */
async function performSearch() {
    const query = document.getElementById('search-query').value.trim();

    if (!query) {
        alert('Please enter a search query');
        return;
    }

    // Get search options
    const searchType = document.querySelector('input[name="search-type"]:checked').value;
    const limit = parseInt(document.getElementById('result-limit').value);
    const threshold = parseFloat(document.getElementById('similarity-threshold').value);
    const repository = document.getElementById('repo-filter').value.trim();

    // Show loading
    showLoading();
    hideResults();

    try {
        let results;

        // Call appropriate endpoint based on search type
        switch (searchType) {
            case 'resolved':
                results = await searchResolvedFailures(query, limit, threshold);
                break;
            case 'effective':
                results = await searchEffectiveSolutions(query, limit);
                break;
            default:
                results = await searchAllFailures(query, limit, threshold);
        }

        // Filter by repository if specified
        if (repository) {
            results = results.filter(r =>
                r.failure.repository.toLowerCase().includes(repository.toLowerCase())
            );
        }

        // Display results
        hideLoading();
        displayResults(results);

        // Update statistics for the filtered repository
        if (repository) {
            loadStatistics(repository);
        }

    } catch (error) {
        hideLoading();
        console.error('Search error:', error);
        alert('Search failed: ' + error.message);
    }
}

/**
 * Search all failures
 */
async function searchAllFailures(query, limit, threshold) {
    const response = await fetch(`${API_BASE}/search`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            query: query,
            limit: limit,
            threshold: threshold
        })
    });

    if (!response.ok) {
        throw new Error('Search request failed');
    }

    return await response.json();
}

/**
 * Search resolved failures with solutions
 */
async function searchResolvedFailures(query, limit, threshold) {
    const response = await fetch(`${API_BASE}/search-resolved`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            query: query,
            limit: limit,
            threshold: threshold
        })
    });

    if (!response.ok) {
        throw new Error('Search request failed');
    }

    return await response.json();
}

/**
 * Search effective solutions
 */
async function searchEffectiveSolutions(query, limit) {
    const response = await fetch(`${API_BASE}/search-solutions`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            query: query,
            limit: limit,
            minEffectiveness: 0.5,
            minTimesHelped: 1
        })
    });

    if (!response.ok) {
        throw new Error('Search request failed');
    }

    return await response.json();
}

/**
 * Display search results
 */
function displayResults(results) {
    const resultsSection = document.getElementById('search-results');
    const resultsList = document.getElementById('results-list');
    const noResults = document.getElementById('no-results');
    const resultCount = document.getElementById('result-count');

    if (results.length === 0) {
        resultsSection.style.display = 'none';
        noResults.style.display = 'block';
        return;
    }

    // Clear previous results
    resultsList.innerHTML = '';

    // Update count
    resultCount.textContent = `${results.length} result${results.length > 1 ? 's' : ''}`;

    // Create result cards
    results.forEach((result, index) => {
        const card = createResultCard(result, index);
        resultsList.appendChild(card);
    });

    // Show results
    resultsSection.style.display = 'block';
    noResults.style.display = 'none';
}

/**
 * Create a result card element
 */
function createResultCard(result, index) {
    const failure = result.failure;
    const similarity = result.similarityScore;

    const card = document.createElement('div');
    card.className = `result-card ${failure.resolved ? 'resolved' : 'unresolved'}`;
    card.onclick = () => showDetailModal(result);

    // Build card HTML
    card.innerHTML = `
        <div class="result-header">
            <div class="result-title">
                <h3>${escapeHtml(failure.repository)} - ${escapeHtml(failure.workflowName)}</h3>
                <div class="result-meta">
                    <span>Run #${failure.runNumber}</span>
                    <span>${formatDate(failure.failedAt)}</span>
                    ${failure.branch ? `<span>Branch: ${escapeHtml(failure.branch)}</span>` : ''}
                </div>
            </div>
            <div class="result-badges">
                <span class="badge ${failure.resolved ? 'resolved' : 'unresolved'}">
                    ${failure.resolved ? '✓ Resolved' : '⚠ Unresolved'}
                </span>
                ${failure.solutionEffectiveness >= 0.7 ?
                    '<span class="badge high-effectiveness">High Effectiveness</span>' : ''}
            </div>
        </div>

        <div class="result-similarity">
            <span>Similarity:</span>
            <div class="similarity-bar">
                <div class="similarity-fill" style="width: ${similarity * 100}%"></div>
            </div>
            <span>${Math.round(similarity * 100)}%</span>
        </div>

        <div class="result-error">
            ${failure.errorType ?
                `<div class="error-type">${escapeHtml(failure.errorType)}</div>` : ''}
            <div class="error-message">${escapeHtml(truncateText(failure.errorMessage, 200))}</div>
        </div>

        ${failure.resolved && failure.resolutionDescription ? `
            <div class="result-solution">
                <div class="solution-label">
                    ✓ Solution Available
                    ${failure.timesHelped > 0 ? `<span>(Helped ${failure.timesHelped} time${failure.timesHelped > 1 ? 's' : ''})</span>` : ''}
                </div>
                <div class="solution-text">${escapeHtml(truncateText(failure.resolutionDescription, 150))}</div>
            </div>
        ` : ''}

        <div class="result-footer">
            <div class="footer-info">
                ${failure.failedStep ? `<span>Failed Step: ${escapeHtml(failure.failedStep)}</span>` : ''}
                ${failure.timeToFixMinutes ? `<span>Fixed in: ${failure.timeToFixMinutes} min</span>` : ''}
                ${failure.fixedBy ? `<span>Fixed by: ${escapeHtml(failure.fixedBy)}</span>` : ''}
            </div>
            <div class="view-details">View Details →</div>
        </div>
    `;

    return card;
}

/**
 * Show detailed modal for a result
 */
function showDetailModal(result) {
    const failure = result.failure;
    const modal = document.getElementById('detail-modal');
    const content = document.getElementById('detail-content');

    content.innerHTML = `
        <h2>${escapeHtml(failure.repository)} - Build Failure Details</h2>

        <div class="detail-section">
            <h3>Build Information</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">Repository</span>
                    <span class="info-value">${escapeHtml(failure.repository)}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Workflow</span>
                    <span class="info-value">${escapeHtml(failure.workflowName)}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Run Number</span>
                    <span class="info-value">#${failure.runNumber}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Run ID</span>
                    <span class="info-value">${failure.runId}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Branch</span>
                    <span class="info-value">${escapeHtml(failure.branch || 'N/A')}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Commit</span>
                    <span class="info-value">${escapeHtml(failure.commitSha ? failure.commitSha.substring(0, 8) : 'N/A')}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Failed At</span>
                    <span class="info-value">${formatDate(failure.failedAt)}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Status</span>
                    <span class="info-value">
                        <span class="badge ${failure.resolved ? 'resolved' : 'unresolved'}">
                            ${failure.resolved ? 'Resolved' : 'Unresolved'}
                        </span>
                    </span>
                </div>
            </div>
        </div>

        <div class="detail-section">
            <h3>Error Details</h3>
            ${failure.errorType ? `<p><strong>Type:</strong> ${escapeHtml(failure.errorType)}</p>` : ''}
            ${failure.failedStep ? `<p><strong>Failed Step:</strong> ${escapeHtml(failure.failedStep)}</p>` : ''}
            <p><strong>Error Message:</strong></p>
            <div class="code-block">${escapeHtml(failure.errorMessage)}</div>
            ${failure.errorStacktrace ? `
                <p><strong>Stack Trace:</strong></p>
                <div class="code-block">${escapeHtml(failure.errorStacktrace)}</div>
            ` : ''}
        </div>

        ${failure.aiAnalysis ? `
            <div class="detail-section">
                <h3>AI Analysis</h3>
                <p>${escapeHtml(failure.aiAnalysis)}</p>
                ${failure.aiConfidence ? `<p><strong>Confidence:</strong> ${escapeHtml(failure.aiConfidence)}</p>` : ''}
            </div>
        ` : ''}

        ${failure.resolved ? `
            <div class="detail-section">
                <h3>Resolution</h3>
                <div class="info-grid">
                    ${failure.resolvedAt ? `
                        <div class="info-item">
                            <span class="info-label">Resolved At</span>
                            <span class="info-value">${formatDate(failure.resolvedAt)}</span>
                        </div>
                    ` : ''}
                    ${failure.timeToFixMinutes ? `
                        <div class="info-item">
                            <span class="info-label">Time to Fix</span>
                            <span class="info-value">${failure.timeToFixMinutes} minutes</span>
                        </div>
                    ` : ''}
                    ${failure.fixedBy ? `
                        <div class="info-item">
                            <span class="info-label">Fixed By</span>
                            <span class="info-value">${escapeHtml(failure.fixedBy)}</span>
                        </div>
                    ` : ''}
                    ${failure.resolutionCommit ? `
                        <div class="info-item">
                            <span class="info-label">Resolution Commit</span>
                            <span class="info-value">${escapeHtml(failure.resolutionCommit.substring(0, 8))}</span>
                        </div>
                    ` : ''}
                    ${failure.solutionEffectiveness ? `
                        <div class="info-item">
                            <span class="info-label">Effectiveness</span>
                            <span class="info-value">${Math.round(failure.solutionEffectiveness * 100)}%</span>
                        </div>
                    ` : ''}
                    ${failure.timesHelped ? `
                        <div class="info-item">
                            <span class="info-label">Times Helped</span>
                            <span class="info-value">${failure.timesHelped}</span>
                        </div>
                    ` : ''}
                </div>

                ${failure.resolutionDescription ? `
                    <p><strong>Description:</strong></p>
                    <p>${escapeHtml(failure.resolutionDescription)}</p>
                ` : ''}

                ${failure.resolutionCodeSnippet ? `
                    <p><strong>Code Changes:</strong></p>
                    <div class="code-block">${escapeHtml(failure.resolutionCodeSnippet)}</div>
                ` : ''}
            </div>
        ` : ''}

        <div class="detail-section">
            <h3>Similarity Score</h3>
            <p>This failure has a similarity score of <strong>${Math.round(result.similarityScore * 100)}%</strong> with your search query.</p>
        </div>
    `;

    modal.style.display = 'block';
}

/**
 * Close the detail modal
 */
function closeDetailModal() {
    document.getElementById('detail-modal').style.display = 'none';
}

/**
 * Show loading spinner
 */
function showLoading() {
    document.getElementById('loading-spinner').style.display = 'block';
}

/**
 * Hide loading spinner
 */
function hideLoading() {
    document.getElementById('loading-spinner').style.display = 'none';
}

/**
 * Hide results section
 */
function hideResults() {
    document.getElementById('search-results').style.display = 'none';
    document.getElementById('no-results').style.display = 'none';
}

/**
 * Format date to readable string
 */
function formatDate(dateString) {
    if (!dateString) return 'N/A';

    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) {
        return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    } else if (diffHours < 24) {
        return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    } else if (diffDays < 7) {
        return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    } else {
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }
}

/**
 * Truncate text to specified length
 */
function truncateText(text, maxLength) {
    if (!text || text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('detail-modal');
    if (event.target === modal) {
        closeDetailModal();
    }
}

// Allow Enter key to trigger search
document.getElementById('search-query')?.addEventListener('keypress', function(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        performSearch();
    }
});
