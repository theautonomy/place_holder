-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Create build_failures table with vector support
CREATE TABLE IF NOT EXISTS build_failures (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- Build Information
    repository VARCHAR(255) NOT NULL,
    workflow_name VARCHAR(255) NOT NULL,
    run_id BIGINT NOT NULL,
    run_number INTEGER NOT NULL,
    branch VARCHAR(255),
    commit_sha VARCHAR(40),

    -- Error Details
    error_type VARCHAR(100),
    error_message TEXT NOT NULL,
    error_stacktrace TEXT,
    failed_step VARCHAR(255),

    -- Temporal Data
    failed_at TIMESTAMP NOT NULL,

    -- Resolution Information
    resolved BOOLEAN DEFAULT FALSE,
    resolution_commit VARCHAR(40),
    resolution_description TEXT,
    resolution_code_snippet TEXT,
    time_to_fix_minutes INTEGER,
    fixed_by VARCHAR(100),
    resolved_at TIMESTAMP,

    -- Effectiveness Tracking
    solution_effectiveness FLOAT DEFAULT 0.0,
    times_helped INTEGER DEFAULT 0,

    -- AI Context
    ai_analysis TEXT,
    ai_confidence VARCHAR(20),

    -- Vector Embedding (1536 dimensions for OpenAI text-embedding-3-small)
    error_embedding vector(1536),

    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS idx_build_failures_repository ON build_failures(repository);
CREATE INDEX IF NOT EXISTS idx_build_failures_failed_at ON build_failures(failed_at DESC);
CREATE INDEX IF NOT EXISTS idx_build_failures_resolved ON build_failures(resolved);
CREATE INDEX IF NOT EXISTS idx_build_failures_run_id ON build_failures(run_id);

-- Create HNSW index for fast vector similarity search
CREATE INDEX IF NOT EXISTS idx_build_failures_embedding ON build_failures
USING hnsw (error_embedding vector_cosine_ops);

-- Create function to update updated_at timestamp
--CREATE OR REPLACE FUNCTION update_updated_at_column()
--RETURNS TRIGGER AS $$
--BEGIN
--    NEW.updated_at = CURRENT_TIMESTAMP;
--    RETURN NEW;
--END;
--$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
--CREATE TRIGGER update_build_failures_updated_at BEFORE UPDATE
--ON build_failures FOR EACH ROW
--EXECUTE FUNCTION update_updated_at_column();
