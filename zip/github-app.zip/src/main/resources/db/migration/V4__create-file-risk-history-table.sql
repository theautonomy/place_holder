-- Create file_risk_history table for tracking file-specific risk metrics
-- This table helps identify which files are dangerous to modify based on past deployment outcomes

CREATE TABLE IF NOT EXISTS file_risk_history (
    -- Primary Key
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- File Information
    repository VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),  -- java, yaml, sql, ts, etc.

    -- Risk Metrics
    total_modifications INTEGER DEFAULT 0,
    modifications_causing_incidents INTEGER DEFAULT 0,
    incident_rate DOUBLE PRECISION,  -- modifications_causing_incidents / total_modifications

    -- Incident Details
    last_incident_date TIMESTAMP,
    last_incident_description TEXT,
    common_failure_types TEXT[],

    -- Complexity Metrics
    average_lines_changed DOUBLE PRECISION,
    max_lines_changed INTEGER,
    requires_expert BOOLEAN DEFAULT FALSE,
    expert_developers TEXT[],  -- Who has successfully modified this file

    -- Metadata
    first_modified_at TIMESTAMP,
    last_modified_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    -- Constraints
    CONSTRAINT unique_repository_file UNIQUE (repository, file_path)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_repository_file ON file_risk_history(repository, file_path);
CREATE INDEX IF NOT EXISTS idx_incident_rate ON file_risk_history(incident_rate);
CREATE INDEX IF NOT EXISTS idx_repository_requires_expert ON file_risk_history(repository, requires_expert);
CREATE INDEX IF NOT EXISTS idx_last_incident_date ON file_risk_history(last_incident_date);

-- Add comment to table
COMMENT ON TABLE file_risk_history IS 'Tracks file-specific risk metrics based on historical incidents to identify dangerous files';

-- Add comments to important columns
COMMENT ON COLUMN file_risk_history.incident_rate IS 'Percentage of modifications that caused incidents (0.0 to 1.0)';
COMMENT ON COLUMN file_risk_history.requires_expert IS 'TRUE if incident_rate > 0.3 (30%)';
COMMENT ON COLUMN file_risk_history.common_failure_types IS 'Array of common error types when this file is modified';
COMMENT ON COLUMN file_risk_history.expert_developers IS 'Developers who have successfully modified this risky file';
