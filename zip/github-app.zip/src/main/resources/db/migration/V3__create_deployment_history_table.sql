-- Create deployment_history table for tracking deployment outcomes with vector embeddings

CREATE TABLE deployment_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    -- Deployment Information
    repository VARCHAR(255) NOT NULL,
    from_commit VARCHAR(40) NOT NULL,
    to_commit VARCHAR(40) NOT NULL,
    environment VARCHAR(50) NOT NULL, -- production, staging, development

    -- Changes Summary
    total_commits INTEGER,
    files_changed INTEGER,
    lines_added INTEGER,
    lines_deleted INTEGER,
    changed_files TEXT[], -- Array of file paths
    commit_messages TEXT[],

    -- Risk Assessment (Predicted)
    predicted_risk_level VARCHAR(20), -- low, medium, high, critical
    predicted_risk_score DOUBLE PRECISION, -- 0-10
    ai_risk_factors TEXT[],
    ai_recommendations TEXT[],

    -- Actual Outcome
    deployment_status VARCHAR(20), -- success, failed, rolled_back, pending
    actual_success BOOLEAN,
    deployment_duration_minutes INTEGER,

    -- Issues Encountered
    issues_encountered TEXT[],
    incident_severity VARCHAR(20), -- none, minor, major, critical
    downtime_minutes INTEGER,
    error_logs TEXT,

    -- Resolution
    rollback_required BOOLEAN,
    rollback_commit VARCHAR(40),
    resolution_description TEXT,

    -- Temporal Data
    deployed_at TIMESTAMP NOT NULL,
    deployed_by VARCHAR(100),
    day_of_week INTEGER, -- 0=Sunday, 6=Saturday
    hour_of_day INTEGER, -- 0-23

    -- Pattern Detection Flags
    has_database_changes BOOLEAN DEFAULT FALSE,
    has_config_changes BOOLEAN DEFAULT FALSE,
    has_critical_files BOOLEAN DEFAULT FALSE,

    -- Vector Embedding (1536 dimensions for OpenAI embeddings)
    change_embedding VECTOR(1536),

    -- Metadata
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX idx_deployment_repository ON deployment_history(repository);
CREATE INDEX idx_deployment_environment ON deployment_history(environment);
CREATE INDEX idx_deployment_deployed_at ON deployment_history(deployed_at);
CREATE INDEX idx_deployment_status ON deployment_history(deployment_status);
CREATE INDEX idx_deployment_day_of_week ON deployment_history(day_of_week);
CREATE INDEX idx_deployment_hour_of_day ON deployment_history(hour_of_day);

-- Create vector similarity index using HNSW for fast similarity search
CREATE INDEX idx_deployment_change_embedding ON deployment_history
USING hnsw (change_embedding vector_cosine_ops);

-- Add comment to table
COMMENT ON TABLE deployment_history IS 'Stores deployment history with vector embeddings for RAG-based risk assessment';

-- Add comments to key columns
COMMENT ON COLUMN deployment_history.change_embedding IS 'Vector embedding of deployment changes for similarity search';
COMMENT ON COLUMN deployment_history.predicted_risk_score IS 'AI-predicted risk score (0-10) before deployment';
COMMENT ON COLUMN deployment_history.actual_success IS 'Actual deployment outcome (true=success, false=failed)';
COMMENT ON COLUMN deployment_history.day_of_week IS 'Day of week when deployed (0=Sunday, 6=Saturday)';
COMMENT ON COLUMN deployment_history.hour_of_day IS 'Hour of day when deployed (0-23)';
