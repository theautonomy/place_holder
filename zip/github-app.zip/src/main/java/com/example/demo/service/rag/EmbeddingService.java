package com.example.demo.service.rag;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.stereotype.Service;

@Service
public class EmbeddingService {

    private final EmbeddingModel embeddingModel;

    public EmbeddingService(EmbeddingModel embeddingModel) {
        this.embeddingModel = embeddingModel;
    }

    /**
     * Generate embedding vector for text using OpenAI
     *
     * @param text Input text to embed
     * @return float array of embeddings (1536 dimensions for text-embedding-3-small)
     */
    public float[] generateEmbedding(String text) {
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException("Text cannot be empty");
        }

        // Clean and prepare text
        String cleanedText = text.trim();

        // Generate embedding using Spring AI
        EmbeddingResponse response = embeddingModel.embedForResponse(List.of(cleanedText));

        // Extract the float array from the response
        float[] result = response.getResults().get(0).getOutput();

        return result;
    }

    /**
     * Generate embeddings for multiple texts in batch
     *
     * @param texts List of texts to embed
     * @return List of float arrays
     */
    public List<float[]> generateEmbeddings(List<String> texts) {
        if (texts == null || texts.isEmpty()) {
            throw new IllegalArgumentException("Texts list cannot be empty");
        }

        return texts.stream().map(this::generateEmbedding).collect(Collectors.toList());
    }

    /**
     * Convert float array to pgvector string format
     *
     * @param embedding Float array of embeddings
     * @return String in format "[0.1,0.2,0.3,...]"
     */
    public String vectorToString(float[] embedding) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < embedding.length; i++) {
            if (i > 0) sb.append(",");
            sb.append(embedding[i]);
        }
        sb.append("]");
        return sb.toString();
    }
}
