package com.example.demo.service.rag;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.example.demo.entity.BuildFailure;
import com.example.demo.repository.BuildFailureRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Service for semantic search of build failures using natural language queries. Converts user
 * queries to embeddings and finds similar build failures using vector similarity.
 */
@Service
public class BuildFailureSearchService {

    private static final Logger logger = LoggerFactory.getLogger(BuildFailureSearchService.class);

    private final BuildFailureRepository buildFailureRepository;
    private final EmbeddingService embeddingService;

    public BuildFailureSearchService(
            BuildFailureRepository buildFailureRepository, EmbeddingService embeddingService) {
        this.buildFailureRepository = buildFailureRepository;
        this.embeddingService = embeddingService;
    }

    /**
     * Search for build failures using natural language query Uses hybrid search that prioritizes
     * exact keyword matches first, then semantic similarity
     *
     * @param query Natural language search query (e.g., "compilation errors", "test failures")
     * @param limit Maximum number of results to return
     * @param threshold Maximum cosine distance threshold (0.0-2.0, lower = more similar)
     * @return List of similar build failures
     */
    public List<BuildFailureSearchResult> searchFailures(
            String query, int limit, double threshold) {
        logger.info(
                "Searching failures with query: '{}', limit: {}, threshold: {}",
                query,
                limit,
                threshold);

        // Generate embedding for the search query
        float[] queryEmbedding = embeddingService.generateEmbedding(query);
        String embeddingString = embeddingService.vectorToString(queryEmbedding);

        // Use hybrid search: keyword matching + vector similarity
        List<Object[]> resultsWithDistance =
                buildFailureRepository.findSimilarFailuresHybrid(
                        query, embeddingString, threshold, limit);

        logger.info("Found {} similar failures (hybrid search)", resultsWithDistance.size());

        // Convert to result objects with actual similarity scores
        List<BuildFailureSearchResult> results = new ArrayList<>();
        for (Object[] row : resultsWithDistance) {
            UUID id = UUID.fromString(row[0].toString());
            double distance = ((Number) row[1]).doubleValue();
            int matchType = ((Number) row[2]).intValue(); // 1 = keyword, 2 = vector

            BuildFailure failure = buildFailureRepository.findById(id).orElse(null);
            if (failure != null) {
                double similarityScore =
                        matchType == 1 ? 1.0 : convertDistanceToSimilarity(distance);
                logger.debug(
                        "Failure ID: {}, MatchType: {}, Distance: {}, Similarity: {}%",
                        id,
                        matchType == 1 ? "KEYWORD" : "VECTOR",
                        distance,
                        Math.round(similarityScore * 100));
                results.add(new BuildFailureSearchResult(failure, similarityScore));
            }
        }

        return results;
    }

    /**
     * Search for resolved build failures with solutions Uses hybrid search that prioritizes exact
     * keyword matches first, then semantic similarity
     *
     * @param query Natural language search query
     * @param limit Maximum number of results
     * @param threshold Maximum cosine distance threshold
     * @return List of similar resolved failures with solutions
     */
    public List<BuildFailureSearchResult> searchResolvedFailures(
            String query, int limit, double threshold) {
        logger.info(
                "Searching resolved failures with query: '{}', limit: {}, threshold: {}",
                query,
                limit,
                threshold);

        float[] queryEmbedding = embeddingService.generateEmbedding(query);
        String embeddingString = embeddingService.vectorToString(queryEmbedding);

        // Use hybrid search: keyword matching + vector similarity
        List<Object[]> resultsWithDistance =
                buildFailureRepository.findSimilarResolvedFailuresHybrid(
                        query, embeddingString, threshold, limit);

        logger.info(
                "Found {} similar resolved failures (hybrid search)", resultsWithDistance.size());

        List<BuildFailureSearchResult> results = new ArrayList<>();
        for (Object[] row : resultsWithDistance) {
            UUID id = UUID.fromString(row[0].toString());
            double distance = ((Number) row[1]).doubleValue();
            int matchType = ((Number) row[2]).intValue();

            BuildFailure failure = buildFailureRepository.findById(id).orElse(null);
            if (failure != null) {
                double similarityScore =
                        matchType == 1 ? 1.0 : convertDistanceToSimilarity(distance);
                logger.debug(
                        "Resolved Failure ID: {}, MatchType: {}, Similarity: {}%",
                        id,
                        matchType == 1 ? "KEYWORD" : "VECTOR",
                        Math.round(similarityScore * 100));
                results.add(new BuildFailureSearchResult(failure, similarityScore));
            }
        }

        return results;
    }

    /**
     * Search for effective solutions to similar problems Uses hybrid search that prioritizes exact
     * keyword matches first, then semantic similarity
     *
     * @param query Natural language search query
     * @param limit Maximum number of results
     * @param minEffectiveness Minimum solution effectiveness score (0.0-1.0)
     * @param minTimesHelped Minimum number of times the solution has helped
     * @return List of effective solutions
     */
    public List<BuildFailureSearchResult> searchEffectiveSolutions(
            String query, int limit, float minEffectiveness, int minTimesHelped) {
        logger.info(
                "Searching effective solutions with query: '{}', limit: {}, minEffectiveness: {}, minTimesHelped: {}",
                query,
                limit,
                minEffectiveness,
                minTimesHelped);

        float[] queryEmbedding = embeddingService.generateEmbedding(query);
        String embeddingString = embeddingService.vectorToString(queryEmbedding);

        // Use hybrid search: keyword matching + vector similarity
        List<Object[]> resultsWithDistance =
                buildFailureRepository.findEffectiveSolutionsHybrid(
                        query, embeddingString, minEffectiveness, minTimesHelped, limit);

        logger.info("Found {} effective solutions (hybrid search)", resultsWithDistance.size());

        List<BuildFailureSearchResult> results = new ArrayList<>();
        for (Object[] row : resultsWithDistance) {
            UUID id = UUID.fromString(row[0].toString());
            double distance = ((Number) row[1]).doubleValue();
            int matchType = ((Number) row[2]).intValue();

            BuildFailure failure = buildFailureRepository.findById(id).orElse(null);
            if (failure != null) {
                double similarityScore =
                        matchType == 1 ? 1.0 : convertDistanceToSimilarity(distance);
                logger.debug(
                        "Effective Solution ID: {}, MatchType: {}, Similarity: {}%",
                        id,
                        matchType == 1 ? "KEYWORD" : "VECTOR",
                        Math.round(similarityScore * 100));
                results.add(new BuildFailureSearchResult(failure, similarityScore));
            }
        }

        return results;
    }

    /**
     * Get statistics about build failures
     *
     * @param repository Optional repository filter
     * @return Search statistics
     */
    public SearchStatistics getStatistics(String repository) {
        SearchStatistics stats = new SearchStatistics();

        if (repository != null && !repository.isEmpty()) {
            stats.totalFailures = buildFailureRepository.countByRepository(repository);
            stats.unresolvedFailures =
                    buildFailureRepository.countByRepositoryAndResolvedFalse(repository);
            stats.averageTimeToFix =
                    buildFailureRepository.getAverageTimeToFixByRepository(repository);

            // Get recent failures (last 7 days)
            LocalDateTime sevenDaysAgo = LocalDateTime.now().minusDays(7);
            List<BuildFailure> recentFailures =
                    buildFailureRepository.findByRepositoryAndFailedAtAfter(
                            repository, sevenDaysAgo);
            stats.recentFailuresCount = recentFailures.size();
        } else {
            stats.totalFailures = buildFailureRepository.count();
            stats.unresolvedFailures =
                    buildFailureRepository.findByResolvedFalseOrderByFailedAtDesc().size();
            stats.averageTimeToFix = buildFailureRepository.getAverageTimeToFix();

            // Get recent failures (last 7 days)
            LocalDateTime sevenDaysAgo = LocalDateTime.now().minusDays(7);
            stats.recentFailuresCount =
                    buildFailureRepository.findRecentFailures(sevenDaysAgo).size();
        }

        return stats;
    }

    /**
     * Convert cosine distance to similarity score Cosine distance: 0.0 = identical, 2.0 = opposite
     * Similarity score: 1.0 = identical, 0.0 = opposite
     *
     * @param distance Cosine distance from pgvector
     * @return Similarity score (0.0-1.0, higher = more similar)
     */
    private double convertDistanceToSimilarity(double distance) {
        // Cosine distance ranges from 0 to 2
        // Convert to similarity percentage (0 to 1)
        return Math.max(0.0, 1.0 - (distance / 2.0));
    }

    /** Result object for build failure search */
    public static class BuildFailureSearchResult {
        private final BuildFailure failure;
        private final double similarityScore;

        public BuildFailureSearchResult(BuildFailure failure, double similarityScore) {
            this.failure = failure;
            this.similarityScore = similarityScore;
        }

        public BuildFailure getFailure() {
            return failure;
        }

        public double getSimilarityScore() {
            return similarityScore;
        }
    }

    /** Statistics about build failures */
    public static class SearchStatistics {
        public long totalFailures;
        public long unresolvedFailures;
        public long recentFailuresCount;
        public Double averageTimeToFix;

        public long getTotalFailures() {
            return totalFailures;
        }

        public long getUnresolvedFailures() {
            return unresolvedFailures;
        }

        public long getRecentFailuresCount() {
            return recentFailuresCount;
        }

        public Double getAverageTimeToFix() {
            return averageTimeToFix;
        }
    }
}
