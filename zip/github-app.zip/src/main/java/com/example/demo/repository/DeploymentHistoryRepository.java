package com.example.demo.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import com.example.demo.entity.DeploymentHistory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DeploymentHistoryRepository extends JpaRepository<DeploymentHistory, UUID> {

    /**
     * Find similar deployments using vector similarity search Uses cosine distance - lower distance
     * means more similar
     *
     * @param embedding The vector embedding to compare against
     * @param threshold Maximum distance threshold (0.0 = identical, 2.0 = opposite)
     * @param limit Maximum number of results to return
     * @return List of similar deployments ordered by similarity
     */
    @Query(
            value =
                    """
        SELECT * FROM deployment_history
        WHERE change_embedding IS NOT NULL
        AND (change_embedding <=> CAST(:embedding AS vector)) < :threshold
        ORDER BY change_embedding <=> CAST(:embedding AS vector)
        LIMIT :limit
        """,
            nativeQuery = true)
    List<DeploymentHistory> findSimilarDeployments(
            @Param("embedding") String embedding,
            @Param("threshold") double threshold,
            @Param("limit") int limit);

    /**
     * Find similar successful deployments (useful for learning from successes)
     *
     * @param embedding The vector embedding to compare against
     * @param threshold Maximum distance threshold
     * @param limit Maximum number of results to return
     * @return List of similar successful deployments ordered by similarity
     */
    @Query(
            value =
                    """
        SELECT * FROM deployment_history
        WHERE change_embedding IS NOT NULL
        AND actual_success = true
        AND (change_embedding <=> CAST(:embedding AS vector)) < :threshold
        ORDER BY change_embedding <=> CAST(:embedding AS vector)
        LIMIT :limit
        """,
            nativeQuery = true)
    List<DeploymentHistory> findSimilarSuccessfulDeployments(
            @Param("embedding") String embedding,
            @Param("threshold") double threshold,
            @Param("limit") int limit);

    /**
     * Find similar failed deployments (useful for risk assessment)
     *
     * @param embedding The vector embedding to compare against
     * @param threshold Maximum distance threshold
     * @param limit Maximum number of results to return
     * @return List of similar failed deployments ordered by similarity
     */
    @Query(
            value =
                    """
        SELECT * FROM deployment_history
        WHERE change_embedding IS NOT NULL
        AND actual_success = false
        AND (change_embedding <=> CAST(:embedding AS vector)) < :threshold
        ORDER BY change_embedding <=> CAST(:embedding AS vector)
        LIMIT :limit
        """,
            nativeQuery = true)
    List<DeploymentHistory> findSimilarFailedDeployments(
            @Param("embedding") String embedding,
            @Param("threshold") double threshold,
            @Param("limit") int limit);

    /**
     * Get deployment success rate by day of week and hour of day
     *
     * @param repository Repository name
     * @param environment Environment name
     * @param minDeployments Minimum number of deployments to consider
     * @return Statistics grouped by time
     */
    @Query(
            value =
                    """
        SELECT
            day_of_week,
            hour_of_day,
            COUNT(*) as total_deployments,
            SUM(CASE WHEN actual_success = true THEN 1 ELSE 0 END) as successful_deployments,
            CAST(AVG(CASE WHEN actual_success = true THEN 1.0 ELSE 0.0 END) AS DOUBLE PRECISION) as success_rate,
            CAST(AVG(deployment_duration_minutes) AS INTEGER) as avg_duration_minutes
        FROM deployment_history
        WHERE repository = :repository
        AND environment = :environment
        AND deployment_status != 'pending'
        AND deployed_at > NOW() - INTERVAL '6 months'
        GROUP BY day_of_week, hour_of_day
        HAVING COUNT(*) >= :minDeployments
        ORDER BY success_rate DESC, avg_duration_minutes ASC
        """,
            nativeQuery = true)
    List<Object[]> getDeploymentStatsByTime(
            @Param("repository") String repository,
            @Param("environment") String environment,
            @Param("minDeployments") int minDeployments);

    /**
     * Find deployments for a specific repository and environment
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return List of deployments
     */
    List<DeploymentHistory> findByRepositoryAndEnvironmentOrderByDeployedAtDesc(
            String repository, String environment);

    /**
     * Find recent deployments (last N days)
     *
     * @param since Start date
     * @return List of recent deployments
     */
    @Query(
            "SELECT d FROM DeploymentHistory d WHERE d.deployedAt >= :since ORDER BY d.deployedAt DESC")
    List<DeploymentHistory> findRecentDeployments(@Param("since") LocalDateTime since);

    /**
     * Find deployments by status
     *
     * @param status Deployment status
     * @return List of deployments with the given status
     */
    List<DeploymentHistory> findByDeploymentStatusOrderByDeployedAtDesc(String status);

    /**
     * Count total deployments for a repository
     *
     * @param repository Repository name
     * @return Count of deployments
     */
    long countByRepository(String repository);

    /**
     * Count successful deployments for a repository
     *
     * @param repository Repository name
     * @return Count of successful deployments
     */
    long countByRepositoryAndActualSuccessTrue(String repository);

    /**
     * Count failed deployments for a repository
     *
     * @param repository Repository name
     * @return Count of failed deployments
     */
    long countByRepositoryAndActualSuccessFalse(String repository);

    /**
     * Get average deployment duration for successful deployments
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Average duration in minutes
     */
    @Query(
            "SELECT AVG(d.deploymentDurationMinutes) FROM DeploymentHistory d "
                    + "WHERE d.repository = :repository AND d.environment = :environment "
                    + "AND d.actualSuccess = true AND d.deploymentDurationMinutes IS NOT NULL")
    Double getAverageDuration(
            @Param("repository") String repository, @Param("environment") String environment);

    /**
     * Get overall success rate for a repository and environment
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Success rate as percentage (0-1)
     */
    @Query(
            value =
                    """
        SELECT CAST(AVG(CASE WHEN actual_success = true THEN 1.0 ELSE 0.0 END) AS DOUBLE PRECISION)
        FROM deployment_history
        WHERE repository = :repository
        AND environment = :environment
        AND deployment_status != 'pending'
        """,
            nativeQuery = true)
    Double getSuccessRate(
            @Param("repository") String repository, @Param("environment") String environment);

    /**
     * Find the most recent deployment for a repository and environment
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Most recent deployment
     */
    DeploymentHistory findFirstByRepositoryAndEnvironmentOrderByDeployedAtDesc(
            String repository, String environment);

    /**
     * Find deployments that required rollback
     *
     * @return List of deployments that were rolled back
     */
    List<DeploymentHistory> findByRollbackRequiredTrueOrderByDeployedAtDesc();

    /**
     * Find deployments by deployed by user
     *
     * @param deployedBy Username
     * @return List of deployments by user
     */
    List<DeploymentHistory> findByDeployedByOrderByDeployedAtDesc(String deployedBy);

    /**
     * Find deployment by repository, from commit, and to commit (for duplicate prevention)
     *
     * @param repository Repository name
     * @param fromCommit From commit SHA
     * @param toCommit To commit SHA
     * @return Deployment if exists
     */
    DeploymentHistory findByRepositoryAndFromCommitAndToCommit(
            String repository, String fromCommit, String toCommit);

    /**
     * Count deployments by repository and flags
     *
     * @param repository Repository name
     * @param hasDatabaseChanges Has database changes flag
     * @param hasCriticalFiles Has critical files flag
     * @return Count of matching deployments
     */
    long countByRepositoryAndHasDatabaseChangesAndHasCriticalFiles(
            String repository, Boolean hasDatabaseChanges, Boolean hasCriticalFiles);

    /**
     * Count failed deployments by repository and flags
     *
     * @param repository Repository name
     * @param hasDatabaseChanges Has database changes flag
     * @param hasCriticalFiles Has critical files flag
     * @param actualSuccess Success status
     * @return Count of matching deployments
     */
    long countByRepositoryAndHasDatabaseChangesAndHasCriticalFilesAndActualSuccess(
            String repository,
            Boolean hasDatabaseChanges,
            Boolean hasCriticalFiles,
            Boolean actualSuccess);

    /**
     * Find deployments where changed files array contains a specific file
     *
     * @param repository Repository name
     * @param filePath File path to search for
     * @return List of deployments that modified this file
     */
    @Query(
            value =
                    """
        SELECT * FROM deployment_history
        WHERE repository = :repository
        AND :filePath = ANY(changed_files)
        ORDER BY deployed_at DESC
        """,
            nativeQuery = true)
    List<DeploymentHistory> findByRepositoryAndChangedFilesContaining(
            @Param("repository") String repository, @Param("filePath") String filePath);
}
