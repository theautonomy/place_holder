package com.example.demo;

import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GitHub;
import org.kohsuke.github.GitHubBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class DeploymentTrackingRunner implements CommandLineRunner {

    @Value("${github.pat}")
    private String githubPat;

    @Value("${github.repository}")
    private String repository;

    @Value("${deployment.tracking.enabled:false}")
    private boolean deploymentTrackingEnabled;

    @Value("${deployment.tracking.show-metrics:true}")
    private boolean showDeploymentMetrics;

    @Value("${deployment.tracking.show-history:false}")
    private boolean showDeploymentHistory;

    @Value("${deployment.tracking.show-comparison:false}")
    private boolean showDeploymentComparison;

    @Value("${deployment.tracking.history-limit:10}")
    private int historyLimit;

    @Value("${deployment.tracking.comparison-environment:production}")
    private String comparisonEnvironment;

    @Override
    public void run(String... args) throws Exception {
        if (!deploymentTrackingEnabled) {
            return;
        }

        try {
            // Initialize GitHub API
            GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();
            GHRepository repo = gitHub.getRepository(repository);

            // Initialize Deployment Tracking Service
            DeploymentTrackingService deploymentService = new DeploymentTrackingService(repo);

            // 1. Deployment Metrics Overview
            if (showDeploymentMetrics) {
                var deploymentMetrics = deploymentService.getDeploymentMetrics();
                DeploymentFormatter.printDeploymentMetrics(deploymentMetrics);
            }

            // 2. Deployment Tracking for All Environments
            var deploymentTracking = deploymentService.getDeploymentTracking();
            DeploymentFormatter.printDeploymentTracking(deploymentTracking);

            // 3. Deployment History (optional)
            if (showDeploymentHistory
                    && comparisonEnvironment != null
                    && !comparisonEnvironment.isEmpty()) {
                var history =
                        deploymentService.getDeploymentHistory(comparisonEnvironment, historyLimit);
                if (!history.isEmpty()) {
                    DeploymentFormatter.printDeploymentHistory(comparisonEnvironment, history);
                }
            }

            // 4. Deployment Comparison (optional)
            if (showDeploymentComparison
                    && comparisonEnvironment != null
                    && !comparisonEnvironment.isEmpty()) {
                var comparison = deploymentService.compareDeployments(comparisonEnvironment);
                if (comparison != null) {
                    DeploymentFormatter.printDeploymentComparison(comparison);
                }
            }

        } catch (Exception e) {
            System.err.println("Error generating deployment tracking: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
