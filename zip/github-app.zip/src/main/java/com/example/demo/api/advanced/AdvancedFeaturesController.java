package com.example.demo.api.advanced;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.example.demo.entity.BuildFailure;
import com.example.demo.repository.BuildFailureRepository;
import com.example.demo.service.advanced.DeploymentOptimizerService;
import com.example.demo.service.advanced.PredictiveAnalysisService;
import com.example.demo.service.advanced.ProactiveWarningService;
import com.example.demo.service.advanced.SmartEscalationService;
import com.example.demo.service.advanced.TeamLearningService;
import com.example.demo.service.rag.BuildFailureSearchService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * REST Controller for Phase 4 Advanced RAG Features - Predictive analysis - Proactive warnings -
 * Team learning - Smart escalation - Deployment optimization
 */
@RestController
@RequestMapping("/api/rag/advanced")
@Tag(name = "Advanced RAG Features", description = "Phase 4: Advanced AI-powered features")
public class AdvancedFeaturesController {

    private static final Logger logger = LoggerFactory.getLogger(AdvancedFeaturesController.class);

    private final PredictiveAnalysisService predictiveAnalysisService;
    private final ProactiveWarningService proactiveWarningService;
    private final TeamLearningService teamLearningService;
    private final SmartEscalationService smartEscalationService;
    private final DeploymentOptimizerService deploymentOptimizerService;
    private final BuildFailureRepository buildFailureRepository;
    private final BuildFailureSearchService buildFailureSearchService;

    public AdvancedFeaturesController(
            PredictiveAnalysisService predictiveAnalysisService,
            ProactiveWarningService proactiveWarningService,
            TeamLearningService teamLearningService,
            SmartEscalationService smartEscalationService,
            DeploymentOptimizerService deploymentOptimizerService,
            BuildFailureRepository buildFailureRepository,
            BuildFailureSearchService buildFailureSearchService) {
        this.predictiveAnalysisService = predictiveAnalysisService;
        this.proactiveWarningService = proactiveWarningService;
        this.teamLearningService = teamLearningService;
        this.smartEscalationService = smartEscalationService;
        this.deploymentOptimizerService = deploymentOptimizerService;
        this.buildFailureRepository = buildFailureRepository;
        this.buildFailureSearchService = buildFailureSearchService;
    }

    // ========== SEMANTIC SEARCH ==========

    @PostMapping("/search")
    @Operation(
            summary = "Search build failures using natural language",
            description = "Searches for similar build failures using semantic similarity")
    public ResponseEntity<List<BuildFailureSearchService.BuildFailureSearchResult>> searchFailures(
            @RequestBody SearchRequest request) {

        logger.info("Searching build failures with query: {}", request.query());

        int limit = request.limit() != null ? request.limit() : 10;
        double threshold = request.threshold() != null ? request.threshold() : 1.0;

        List<BuildFailureSearchService.BuildFailureSearchResult> results =
                buildFailureSearchService.searchFailures(request.query(), limit, threshold);

        return ResponseEntity.ok(results);
    }

    @PostMapping("/search-resolved")
    @Operation(
            summary = "Search resolved build failures with solutions",
            description = "Searches for similar resolved build failures that have solutions")
    public ResponseEntity<List<BuildFailureSearchService.BuildFailureSearchResult>>
            searchResolvedFailures(@RequestBody SearchRequest request) {

        logger.info("Searching resolved build failures with query: {}", request.query());

        int limit = request.limit() != null ? request.limit() : 10;
        double threshold = request.threshold() != null ? request.threshold() : 1.0;

        List<BuildFailureSearchService.BuildFailureSearchResult> results =
                buildFailureSearchService.searchResolvedFailures(request.query(), limit, threshold);

        return ResponseEntity.ok(results);
    }

    @PostMapping("/search-solutions")
    @Operation(
            summary = "Search effective solutions",
            description = "Searches for effective solutions to similar problems")
    public ResponseEntity<List<BuildFailureSearchService.BuildFailureSearchResult>>
            searchEffectiveSolutions(@RequestBody EffectiveSolutionsRequest request) {

        logger.info("Searching effective solutions with query: {}", request.query());

        int limit = request.limit() != null ? request.limit() : 10;
        float minEffectiveness =
                request.minEffectiveness() != null ? request.minEffectiveness() : 0.5f;
        int minTimesHelped = request.minTimesHelped() != null ? request.minTimesHelped() : 1;

        List<BuildFailureSearchService.BuildFailureSearchResult> results =
                buildFailureSearchService.searchEffectiveSolutions(
                        request.query(), limit, minEffectiveness, minTimesHelped);

        return ResponseEntity.ok(results);
    }

    @GetMapping("/search-statistics")
    @Operation(
            summary = "Get search statistics",
            description = "Returns statistics about build failures")
    public ResponseEntity<BuildFailureSearchService.SearchStatistics> getSearchStatistics(
            @RequestParam(required = false) String repository) {

        logger.info("Getting search statistics for repository: {}", repository);

        BuildFailureSearchService.SearchStatistics stats =
                buildFailureSearchService.getStatistics(repository);

        return ResponseEntity.ok(stats);
    }

    // ========== PREDICTIVE ANALYSIS ==========

    @PostMapping("/predict-failure")
    @Operation(
            summary = "Predict build failure probability",
            description = "Predicts likelihood of build failure based on changed files")
    public ResponseEntity<PredictiveAnalysisService.FailurePrediction> predictBuildFailure(
            @RequestBody FailurePredictionRequest request) {

        logger.info(
                "Predicting build failure for repository: {}, branch: {}",
                request.repository(),
                request.branch());

        PredictiveAnalysisService.FailurePrediction prediction =
                predictiveAnalysisService.predictBuildFailure(
                        request.repository(), request.branch(), request.changedFiles());

        return ResponseEntity.ok(prediction);
    }

    @PostMapping("/analyze-file-risk")
    @Operation(
            summary = "Analyze file-specific risk",
            description = "Analyzes risk of specific files based on historical incidents")
    public ResponseEntity<List<PredictiveAnalysisService.RiskyFileAnalysis>> analyzeFileRisk(
            @RequestBody FileRiskRequest request) {

        logger.info("Analyzing file risk for repository: {}", request.repository());

        List<PredictiveAnalysisService.RiskyFileAnalysis> analysis =
                predictiveAnalysisService.analyzeFileRisk(
                        request.repository(), request.changedFiles());

        return ResponseEntity.ok(analysis);
    }

    // ========== PROACTIVE WARNINGS ==========

    @PostMapping("/deployment-warnings")
    @Operation(
            summary = "Generate proactive deployment warnings",
            description = "Identifies potential issues before deployment")
    public ResponseEntity<List<ProactiveWarningService.DeploymentWarning>> generateWarnings(
            @RequestBody DeploymentWarningRequest request) {

        logger.info(
                "Generating deployment warnings for repository: {}, environment: {}",
                request.repository(),
                request.environment());

        List<ProactiveWarningService.DeploymentWarning> warnings =
                proactiveWarningService.generateWarnings(
                        request.repository(),
                        request.environment(),
                        request.changedFiles(),
                        request.commitMessages(),
                        request.hasDatabaseChanges(),
                        request.hasConfigChanges(),
                        request.hasCriticalFiles(),
                        request.deploymentTime());

        return ResponseEntity.ok(warnings);
    }

    // ========== TEAM LEARNING ==========

    @PostMapping("/team-insights")
    @Operation(
            summary = "Get team learning insights",
            description = "Provides insights based on team history for a specific problem")
    public ResponseEntity<TeamLearningService.LearningInsights> getTeamInsights(
            @RequestBody TeamInsightsRequest request) {

        logger.info("Getting team insights for repository: {}", request.repository());

        TeamLearningService.LearningInsights insights =
                teamLearningService.analyzeProblem(request.errorMessage(), request.repository());

        return ResponseEntity.ok(insights);
    }

    @GetMapping("/recurring-patterns")
    @Operation(
            summary = "Identify recurring error patterns",
            description = "Finds patterns in team's historical failures")
    public ResponseEntity<List<TeamLearningService.RecurringPattern>> getRecurringPatterns(
            @RequestParam String repository, @RequestParam(defaultValue = "6") int sinceMonths) {

        logger.info("Identifying recurring patterns for repository: {}", repository);

        List<TeamLearningService.RecurringPattern> patterns =
                teamLearningService.identifyRecurringPatterns(repository, sinceMonths);

        return ResponseEntity.ok(patterns);
    }

    @GetMapping("/team-experts")
    @Operation(
            summary = "Identify team experts",
            description = "Maps team members to their areas of expertise")
    public ResponseEntity<Map<String, TeamLearningService.TeamExpert>> getTeamExperts(
            @RequestParam String repository) {

        logger.info("Identifying team experts for repository: {}", repository);

        Map<String, TeamLearningService.TeamExpert> experts =
                teamLearningService.identifyTeamExperts(repository);

        return ResponseEntity.ok(experts);
    }

    // ========== SMART ESCALATION ==========

    @GetMapping("/escalation/{failureId}")
    @Operation(
            summary = "Get escalation recommendation",
            description = "Recommends whether and how to escalate a build failure")
    public ResponseEntity<SmartEscalationService.EscalationRecommendation>
            getEscalationRecommendation(@PathVariable UUID failureId) {

        logger.info("Getting escalation recommendation for failure: {}", failureId);

        BuildFailure failure =
                buildFailureRepository
                        .findById(failureId)
                        .orElseThrow(
                                () ->
                                        new RuntimeException(
                                                "Build failure not found: " + failureId));

        SmartEscalationService.EscalationRecommendation recommendation =
                smartEscalationService.analyzeEscalation(failure);

        return ResponseEntity.ok(recommendation);
    }

    @PostMapping("/recommend-expert")
    @Operation(
            summary = "Recommend expert for error",
            description = "Recommends team members who can best handle this error")
    public ResponseEntity<List<SmartEscalationService.Expert>> recommendExpert(
            @RequestBody ExpertRecommendationRequest request) {

        logger.info("Recommending expert for repository: {}", request.repository());

        List<SmartEscalationService.Expert> experts =
                smartEscalationService.recommendExpert(
                        request.errorMessage(), request.repository());

        return ResponseEntity.ok(experts);
    }

    @PostMapping("/estimate-resolution-time")
    @Operation(
            summary = "Estimate resolution time",
            description = "Estimates how long it will take to fix based on historical data")
    public ResponseEntity<SmartEscalationService.TimeEstimate> estimateResolutionTime(
            @RequestBody TimeEstimateRequest request) {

        logger.info("Estimating resolution time for repository: {}", request.repository());

        SmartEscalationService.TimeEstimate estimate =
                smartEscalationService.estimateResolutionTime(
                        request.errorMessage(), request.repository());

        return ResponseEntity.ok(estimate);
    }

    // ========== DEPLOYMENT OPTIMIZER ==========

    @GetMapping("/optimal-windows")
    @Operation(
            summary = "Find optimal deployment windows",
            description = "Identifies best times to deploy based on historical success")
    public ResponseEntity<DeploymentOptimizerService.OptimalDeploymentWindows> getOptimalWindows(
            @RequestParam String repository, @RequestParam String environment) {

        logger.info(
                "Finding optimal deployment windows for repository: {}, environment: {}",
                repository,
                environment);

        DeploymentOptimizerService.OptimalDeploymentWindows windows =
                deploymentOptimizerService.findOptimalWindows(repository, environment);

        return ResponseEntity.ok(windows);
    }

    @GetMapping("/evaluate-current-time")
    @Operation(
            summary = "Evaluate current deployment timing",
            description = "Evaluates if now is a good time to deploy")
    public ResponseEntity<DeploymentOptimizerService.DeploymentTimingEvaluation>
            evaluateCurrentTime(@RequestParam String repository, @RequestParam String environment) {

        logger.info(
                "Evaluating current deployment time for repository: {}, environment: {}",
                repository,
                environment);

        DeploymentOptimizerService.DeploymentTimingEvaluation evaluation =
                deploymentOptimizerService.evaluateCurrentTime(repository, environment);

        return ResponseEntity.ok(evaluation);
    }

    @GetMapping("/suggest-next-window")
    @Operation(
            summary = "Suggest next deployment window",
            description = "Recommends next best time to deploy")
    public ResponseEntity<DeploymentOptimizerService.NextDeploymentWindow> suggestNextWindow(
            @RequestParam String repository, @RequestParam String environment) {

        logger.info(
                "Suggesting next deployment window for repository: {}, environment: {}",
                repository,
                environment);

        DeploymentOptimizerService.NextDeploymentWindow window =
                deploymentOptimizerService.suggestNextWindow(repository, environment);

        return ResponseEntity.ok(window);
    }

    // ========== REQUEST/RESPONSE DTOs ==========

    public record FailurePredictionRequest(
            String repository, String branch, List<String> changedFiles) {}

    public record FileRiskRequest(String repository, List<String> changedFiles) {}

    public record DeploymentWarningRequest(
            String repository,
            String environment,
            List<String> changedFiles,
            List<String> commitMessages,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles,
            java.time.LocalDateTime deploymentTime) {}

    public record TeamInsightsRequest(String errorMessage, String repository) {}

    public record ExpertRecommendationRequest(String errorMessage, String repository) {}

    public record TimeEstimateRequest(String errorMessage, String repository) {}

    public record SearchRequest(String query, Integer limit, Double threshold) {}

    public record EffectiveSolutionsRequest(
            String query, Integer limit, Float minEffectiveness, Integer minTimesHelped) {}
}
