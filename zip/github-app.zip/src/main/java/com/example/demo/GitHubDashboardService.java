package com.example.demo;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.kohsuke.github.GHCommit;
import org.kohsuke.github.GHCompare;
import org.kohsuke.github.GHDeployment;
import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GHWorkflowJob;
import org.kohsuke.github.GHWorkflowRun;
import org.kohsuke.github.GitHub;

public class GitHubDashboardService {

    private final GitHub gitHub;
    private final GHRepository repository;

    public GitHubDashboardService(GitHub gitHub, String repositoryName) throws IOException {
        this.gitHub = gitHub;
        this.repository = gitHub.getRepository(repositoryName);
    }

    /** Get workflow monitoring data including recent runs and statistics */
    public WorkflowMonitoringData getWorkflowMonitoring(String workflowFileName)
            throws IOException {
        var workflow = repository.getWorkflow(workflowFileName);
        var runs = workflow.listRuns().toList();

        List<GHWorkflowRun> recentRuns = runs.stream().limit(10).collect(Collectors.toList());

        // Calculate statistics
        long totalRuns = runs.size();
        long successfulRuns =
                runs.stream()
                        .filter(
                                run ->
                                        run.getConclusion() != null
                                                && run.getConclusion()
                                                        .toString()
                                                        .equalsIgnoreCase("success"))
                        .count();
        long failedRuns =
                runs.stream()
                        .filter(
                                run ->
                                        run.getConclusion() != null
                                                && run.getConclusion()
                                                        .toString()
                                                        .equalsIgnoreCase("failure"))
                        .count();
        long inProgressRuns =
                runs.stream()
                        .filter(
                                run ->
                                        run.getStatus() != null
                                                && run.getStatus()
                                                        .toString()
                                                        .equalsIgnoreCase("in_progress"))
                        .count();

        double successRate = totalRuns > 0 ? (successfulRuns * 100.0 / totalRuns) : 0.0;

        return new WorkflowMonitoringData(
                workflowFileName,
                recentRuns,
                totalRuns,
                successfulRuns,
                failedRuns,
                inProgressRuns,
                successRate);
    }

    /** Get deployment status across different environments */
    public List<DeploymentStatus> getDeploymentStatus() throws IOException {
        List<DeploymentStatus> deploymentStatuses = new ArrayList<>();

        var deployments = repository.listDeployments(null, null, null, null).toList();

        // Group by environment
        Map<String, GHDeployment> latestByEnvironment = new HashMap<>();
        for (var deployment : deployments) {
            String env = deployment.getEnvironment();
            if (!latestByEnvironment.containsKey(env)) {
                latestByEnvironment.put(env, deployment);
            }
        }

        for (var entry : latestByEnvironment.entrySet()) {
            var deployment = entry.getValue();
            var statuses = deployment.listStatuses().toList();
            String status = statuses.isEmpty() ? "unknown" : statuses.get(0).getState().name();

            deploymentStatuses.add(
                    new DeploymentStatus(
                            entry.getKey(),
                            deployment.getSha(),
                            status,
                            deployment.getCreatedAt(),
                            deployment.getTask() != null ? deployment.getTask() : "deploy"));
        }

        return deploymentStatuses;
    }

    /** Get commit diff between latest build and its parent */
    public CommitDiffData getLatestBuildDiff(String workflowFileName) throws IOException {
        var workflow = repository.getWorkflow(workflowFileName);
        var runs = workflow.listRuns().toList();

        if (runs.isEmpty()) {
            return null;
        }

        var latestRun = runs.get(0);
        var latestCommit = repository.getCommit(latestRun.getHeadSha());
        var parents = latestCommit.getParentSHA1s();

        if (parents == null || parents.isEmpty()) {
            return null;
        }

        String parentSha = parents.get(0);
        var parentCommit = repository.getCommit(parentSha);
        var compareResult = repository.getCompare(parentSha, latestRun.getHeadSha());

        return new CommitDiffData(latestCommit, parentCommit, compareResult, latestRun);
    }

    /** Get quick dashboard metrics */
    public DashboardMetrics getDashboardMetrics(String workflowFileName) throws IOException {
        var workflow = repository.getWorkflow(workflowFileName);
        var runs = workflow.listRuns().toList();

        // Filter runs from last 24 hours
        Instant yesterday = Instant.now().minus(Duration.ofHours(24));
        long runsToday = 0;
        for (var run : runs) {
            try {
                if (run.getCreatedAt().toInstant().isAfter(yesterday)) {
                    runsToday++;
                }
            } catch (IOException e) {
                // Skip this run
            }
        }

        // Filter runs from last 7 days
        Instant lastWeek = Instant.now().minus(Duration.ofDays(7));
        long runsThisWeek = 0;
        for (var run : runs) {
            try {
                if (run.getCreatedAt().toInstant().isAfter(lastWeek)) {
                    runsThisWeek++;
                }
            } catch (IOException e) {
                // Skip this run
            }
        }

        long failedBuilds =
                runs.stream()
                        .filter(
                                run ->
                                        run.getConclusion() != null
                                                && run.getConclusion()
                                                        .toString()
                                                        .equalsIgnoreCase("failure"))
                        .count();

        // Calculate average build duration (completed runs only)
        long totalDuration = 0;
        long completedCount = 0;
        for (var run : runs) {
            try {
                if (run.getStatus() != null
                        && run.getStatus().toString().equalsIgnoreCase("completed")
                        && run.getUpdatedAt() != null
                        && run.getCreatedAt() != null) {
                    totalDuration +=
                            Duration.between(
                                            run.getCreatedAt().toInstant(),
                                            run.getUpdatedAt().toInstant())
                                    .toSeconds();
                    completedCount++;
                }
            } catch (IOException e) {
                // Skip this run
            }
        }
        double avgDuration = completedCount > 0 ? (double) totalDuration / completedCount : 0.0;

        // Get latest run
        GHWorkflowRun latestRun = runs.isEmpty() ? null : runs.get(0);

        // Get deployments
        var deployments = repository.listDeployments(null, null, null, null).toList();
        Map<String, Date> lastDeploymentByEnv = new HashMap<>();
        for (var deployment : deployments) {
            String env = deployment.getEnvironment();
            if (!lastDeploymentByEnv.containsKey(env)) {
                lastDeploymentByEnv.put(env, deployment.getCreatedAt());
            }
        }

        return new DashboardMetrics(
                runsToday, runsThisWeek, failedBuilds, avgDuration, latestRun, lastDeploymentByEnv);
    }

    /** Get workflow jobs for detailed status */
    public List<GHWorkflowJob> getWorkflowJobs(GHWorkflowRun run) throws IOException {
        return run.listJobs().toList();
    }

    // Data classes
    public static class WorkflowMonitoringData {
        public final String workflowName;
        public final List<GHWorkflowRun> recentRuns;
        public final long totalRuns;
        public final long successfulRuns;
        public final long failedRuns;
        public final long inProgressRuns;
        public final double successRate;

        public WorkflowMonitoringData(
                String workflowName,
                List<GHWorkflowRun> recentRuns,
                long totalRuns,
                long successfulRuns,
                long failedRuns,
                long inProgressRuns,
                double successRate) {
            this.workflowName = workflowName;
            this.recentRuns = recentRuns;
            this.totalRuns = totalRuns;
            this.successfulRuns = successfulRuns;
            this.failedRuns = failedRuns;
            this.inProgressRuns = inProgressRuns;
            this.successRate = successRate;
        }
    }

    public static class DeploymentStatus {
        public final String environment;
        public final String commitSha;
        public final String status;
        public final Date deployedAt;
        public final String description;

        public DeploymentStatus(
                String environment,
                String commitSha,
                String status,
                Date deployedAt,
                String description) {
            this.environment = environment;
            this.commitSha = commitSha;
            this.status = status;
            this.deployedAt = deployedAt;
            this.description = description;
        }
    }

    public static class CommitDiffData {
        public final GHCommit latestCommit;
        public final GHCommit parentCommit;
        public final GHCompare compareResult;
        public final GHWorkflowRun workflowRun;

        public CommitDiffData(
                GHCommit latestCommit,
                GHCommit parentCommit,
                GHCompare compareResult,
                GHWorkflowRun workflowRun) {
            this.latestCommit = latestCommit;
            this.parentCommit = parentCommit;
            this.compareResult = compareResult;
            this.workflowRun = workflowRun;
        }
    }

    public static class DashboardMetrics {
        public final long runsToday;
        public final long runsThisWeek;
        public final long failedBuilds;
        public final double avgDurationSeconds;
        public final GHWorkflowRun latestRun;
        public final Map<String, Date> lastDeploymentByEnv;

        public DashboardMetrics(
                long runsToday,
                long runsThisWeek,
                long failedBuilds,
                double avgDurationSeconds,
                GHWorkflowRun latestRun,
                Map<String, Date> lastDeploymentByEnv) {
            this.runsToday = runsToday;
            this.runsThisWeek = runsThisWeek;
            this.failedBuilds = failedBuilds;
            this.avgDurationSeconds = avgDurationSeconds;
            this.latestRun = latestRun;
            this.lastDeploymentByEnv = lastDeploymentByEnv;
        }
    }
}
