package com.example.demo.dto;

import com.example.demo.entity.BuildFailure;

/** DTO that wraps a BuildFailure with its similarity distance score */
public class BuildFailureWithDistance {
    private final BuildFailure failure;
    private final double distance;

    public BuildFailureWithDistance(BuildFailure failure, double distance) {
        this.failure = failure;
        this.distance = distance;
    }

    public BuildFailure getFailure() {
        return failure;
    }

    public double getDistance() {
        return distance;
    }

    /**
     * Convert cosine distance to similarity score Cosine distance: 0.0 = identical, 2.0 = opposite
     * Similarity: 1.0 = identical, 0.0 = opposite
     */
    public double getSimilarityScore() {
        return 1.0 - (distance / 2.0);
    }
}
