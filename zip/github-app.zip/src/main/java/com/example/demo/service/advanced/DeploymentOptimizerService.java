package com.example.demo.service.advanced;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.TextStyle;
import java.util.*;
import java.util.stream.Collectors;

import com.example.demo.repository.DeploymentHistoryRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Deployment Optimizer Service Finds optimal deployment windows based on historical success
 * patterns
 */
@Service
public class DeploymentOptimizerService {

    private static final Logger logger = LoggerFactory.getLogger(DeploymentOptimizerService.class);

    private final DeploymentHistoryRepository deploymentRepository;

    private static final int ANALYSIS_MONTHS = 3; // Analyze last 3 months
    private static final int MIN_DEPLOYMENTS_FOR_STATS = 3; // Need at least 3 deployments
    private static final double GOOD_SUCCESS_RATE = 0.8; // 80% or higher

    public DeploymentOptimizerService(DeploymentHistoryRepository deploymentRepository) {
        this.deploymentRepository = deploymentRepository;
    }

    /**
     * Find optimal deployment windows based on historical data
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Optimal deployment windows
     */
    public OptimalDeploymentWindows findOptimalWindows(String repository, String environment) {

        logger.info(
                "Finding optimal deployment windows for repository: {}, environment: {}",
                repository,
                environment);

        // Get deployment statistics by time
        List<Object[]> stats =
                deploymentRepository.getDeploymentStatsByTime(
                        repository, environment, ANALYSIS_MONTHS);

        if (stats.isEmpty()) {
            logger.info("No deployment history found");
            return new OptimalDeploymentWindows(
                    List.of(), null, null, "No historical data available");
        }

        // Convert to TimeWindow objects
        List<TimeWindow> allWindows = new ArrayList<>();

        for (Object[] row : stats) {
            Integer dayOfWeek = (Integer) row[0];
            Integer hourOfDay = (Integer) row[1];
            Long totalDeployments = ((Number) row[2]).longValue();
            Long successfulDeployments = ((Number) row[3]).longValue();
            Double successRate = (Double) row[4];

            if (totalDeployments >= MIN_DEPLOYMENTS_FOR_STATS) {
                DayOfWeek day = DayOfWeek.of(dayOfWeek);
                String dayName = day.getDisplayName(TextStyle.FULL, Locale.ENGLISH);

                allWindows.add(
                        new TimeWindow(
                                dayOfWeek,
                                hourOfDay,
                                dayName,
                                String.format("%02d:00 - %02d:00", hourOfDay, hourOfDay + 1),
                                successRate,
                                totalDeployments.intValue(),
                                successfulDeployments.intValue(),
                                calculateAvgDuration(
                                        repository, environment, dayOfWeek, hourOfDay)));
            }
        }

        if (allWindows.isEmpty()) {
            return new OptimalDeploymentWindows(
                    List.of(), null, null, "Not enough deployment data for analysis");
        }

        // Sort by success rate descending
        allWindows.sort((a, b) -> Double.compare(b.successRate(), a.successRate()));

        // Get top 5 recommended windows
        List<TimeWindow> recommendedWindows =
                allWindows.stream()
                        .filter(w -> w.successRate() >= GOOD_SUCCESS_RATE)
                        .limit(5)
                        .collect(Collectors.toList());

        // Find worst windows (to avoid)
        List<TimeWindow> worstWindows =
                allWindows.stream()
                        .sorted((a, b) -> Double.compare(a.successRate(), b.successRate()))
                        .limit(5)
                        .collect(Collectors.toList());

        // Get current time window stats
        LocalDateTime now = LocalDateTime.now();
        TimeWindow currentWindow = findWindowForTime(allWindows, now);

        String summary = generateSummary(allWindows, recommendedWindows);

        logger.info("Found {} recommended windows", recommendedWindows.size());

        return new OptimalDeploymentWindows(
                recommendedWindows, worstWindows, currentWindow, summary);
    }

    /**
     * Evaluate if now is a good time to deploy
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Deployment timing evaluation
     */
    public DeploymentTimingEvaluation evaluateCurrentTime(String repository, String environment) {

        logger.info("Evaluating current deployment timing");

        LocalDateTime now = LocalDateTime.now();
        int dayOfWeek = now.getDayOfWeek().getValue();
        int hourOfDay = now.getHour();

        // Get stats for current time
        List<Object[]> stats =
                deploymentRepository.getDeploymentStatsByTime(
                        repository, environment, ANALYSIS_MONTHS);

        Optional<Object[]> currentStats =
                stats.stream()
                        .filter(
                                row ->
                                        (Integer) row[0] == dayOfWeek
                                                && (Integer) row[1] == hourOfDay)
                        .findFirst();

        if (currentStats.isEmpty()) {
            return new DeploymentTimingEvaluation(
                    "UNKNOWN", null, "No historical data for current time window", List.of(), null);
        }

        Object[] current = currentStats.get();
        Long totalDeployments = ((Number) current[2]).longValue();
        Double successRate = (Double) current[4];

        if (totalDeployments < MIN_DEPLOYMENTS_FOR_STATS) {
            return new DeploymentTimingEvaluation(
                    "UNKNOWN",
                    successRate,
                    "Limited historical data for current time window",
                    List.of(),
                    null);
        }

        // Determine rating
        String rating;
        List<String> pros = new ArrayList<>();
        List<String> cons = new ArrayList<>();

        if (successRate >= 0.9) {
            rating = "EXCELLENT";
            pros.add(String.format("%.0f%% historical success rate", successRate * 100));
            pros.add("One of the best times to deploy based on data");
        } else if (successRate >= 0.8) {
            rating = "GOOD";
            pros.add(String.format("%.0f%% historical success rate", successRate * 100));
            pros.add("Reliable time window for deployments");
        } else if (successRate >= 0.6) {
            rating = "FAIR";
            cons.add(String.format("Only %.0f%% historical success rate", successRate * 100));
            cons.add("Consider deploying at a better time if possible");
        } else {
            rating = "POOR";
            cons.add(String.format("Low %.0f%% historical success rate", successRate * 100));
            cons.add("Strongly recommend choosing a different time");
        }

        // Add day-specific factors
        DayOfWeek day = now.getDayOfWeek();
        if (day == DayOfWeek.FRIDAY && hourOfDay >= 15) {
            cons.add("Late Friday deployment - risk of weekend incidents");
        } else if (day == DayOfWeek.MONDAY && hourOfDay < 10) {
            cons.add("Early Monday morning - team may not be fully available");
        } else if (day == DayOfWeek.TUESDAY
                || day == DayOfWeek.WEDNESDAY
                || day == DayOfWeek.THURSDAY) {
            if (hourOfDay >= 9 && hourOfDay <= 15) {
                pros.add("Mid-week deployment during business hours");
            }
        }

        // Add hour-specific factors
        if (hourOfDay >= 22 || hourOfDay <= 6) {
            cons.add("Off-hours deployment - delayed incident response");
        } else if (hourOfDay >= 9 && hourOfDay <= 16) {
            pros.add("Business hours - team readily available");
        }

        // Find alternative time
        TimeWindow alternative = findBestAlternative(stats, dayOfWeek, hourOfDay);

        String recommendation = buildRecommendation(rating, successRate, alternative);

        logger.info("Current time rating: {}, success rate: {}", rating, successRate);

        return new DeploymentTimingEvaluation(
                rating, successRate, recommendation, cons, alternative);
    }

    /**
     * Suggest next best deployment time
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Next available good deployment window
     */
    public NextDeploymentWindow suggestNextWindow(String repository, String environment) {

        logger.info("Suggesting next deployment window");

        OptimalDeploymentWindows optimal = findOptimalWindows(repository, environment);

        if (optimal.recommendedWindows().isEmpty()) {
            return new NextDeploymentWindow(
                    null, null, "No historical data to make recommendation");
        }

        LocalDateTime now = LocalDateTime.now();
        TimeWindow bestWindow = optimal.recommendedWindows().get(0);

        // Find next occurrence of this window
        LocalDateTime nextOccurrence =
                findNextOccurrence(now, bestWindow.dayOfWeek(), bestWindow.hourOfDay());

        long hoursUntil = java.time.Duration.between(now, nextOccurrence).toHours();

        String explanation =
                String.format(
                        "Best window is %s at %s with %.0f%% success rate. Next occurrence is in %d hours.",
                        bestWindow.dayName(),
                        bestWindow.timeRange(),
                        bestWindow.successRate() * 100,
                        hoursUntil);

        return new NextDeploymentWindow(nextOccurrence, bestWindow, explanation);
    }

    private double calculateAvgDuration(
            String repository, String environment, int dayOfWeek, int hourOfDay) {
        // This would ideally query the database for average duration
        // For now, return 0 as placeholder
        return 0.0;
    }

    private TimeWindow findWindowForTime(List<TimeWindow> windows, LocalDateTime time) {
        int dayOfWeek = time.getDayOfWeek().getValue();
        int hourOfDay = time.getHour();

        return windows.stream()
                .filter(w -> w.dayOfWeek() == dayOfWeek && w.hourOfDay() == hourOfDay)
                .findFirst()
                .orElse(null);
    }

    private String generateSummary(
            List<TimeWindow> allWindows, List<TimeWindow> recommendedWindows) {
        if (recommendedWindows.isEmpty()) {
            return "No deployment windows with >80% success rate found. Review deployment practices.";
        }

        TimeWindow best = recommendedWindows.get(0);
        double avgSuccessRate =
                allWindows.stream().mapToDouble(TimeWindow::successRate).average().orElse(0.0);

        return String.format(
                "Based on %d deployment time slots: Best window is %s at %s (%.0f%% success rate). "
                        + "Overall average success rate: %.0f%%",
                allWindows.size(),
                best.dayName(),
                best.timeRange(),
                best.successRate() * 100,
                avgSuccessRate * 100);
    }

    private TimeWindow findBestAlternative(List<Object[]> stats, int currentDay, int currentHour) {
        // Find best alternative within next 7 days
        TimeWindow best = null;
        double bestRate = 0;

        for (Object[] row : stats) {
            Integer day = (Integer) row[0];
            Integer hour = (Integer) row[1];
            Long total = ((Number) row[2]).longValue();
            Double rate = (Double) row[4];

            if (total >= MIN_DEPLOYMENTS_FOR_STATS
                    && rate > bestRate
                    && !(day == currentDay && hour == currentHour)) {
                bestRate = rate;
                DayOfWeek dayOfWeek = DayOfWeek.of(day);
                best =
                        new TimeWindow(
                                day,
                                hour,
                                dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH),
                                String.format("%02d:00 - %02d:00", hour, hour + 1),
                                rate,
                                total.intValue(),
                                0,
                                0.0);
            }
        }

        return best;
    }

    private String buildRecommendation(String rating, Double successRate, TimeWindow alternative) {
        StringBuilder rec = new StringBuilder();

        switch (rating) {
            case "EXCELLENT" -> rec.append(
                    "✅ Now is an excellent time to deploy. Proceed with confidence.");
            case "GOOD" -> rec.append(
                    "👍 Now is a good time to deploy. Standard precautions apply.");
            case "FAIR" -> rec.append(
                    "⚠️ Current time is fair. Consider waiting for a better window if not urgent.");
            case "POOR" -> rec.append("❌ Not recommended to deploy now. Choose a different time.");
            default -> rec.append("ℹ️ Insufficient data to make recommendation.");
        }

        if (alternative != null
                && successRate != null
                && alternative.successRate() > successRate + 0.2) {
            rec.append(
                    String.format(
                            "\n\nBetter alternative: %s at %s (%.0f%% success rate vs current %.0f%%)",
                            alternative.dayName(),
                            alternative.timeRange(),
                            alternative.successRate() * 100,
                            successRate * 100));
        }

        return rec.toString();
    }

    private LocalDateTime findNextOccurrence(LocalDateTime from, int targetDay, int targetHour) {
        LocalDateTime next = from;

        // Find next occurrence of target day
        while (next.getDayOfWeek().getValue() != targetDay) {
            next = next.plusDays(1);
        }

        // Set to target hour
        next = next.withHour(targetHour).withMinute(0).withSecond(0);

        // If we're already past that time today, move to next week
        if (!next.isAfter(from)) {
            next = next.plusWeeks(1);
        }

        return next;
    }

    /** Time window with deployment statistics */
    public record TimeWindow(
            int dayOfWeek,
            int hourOfDay,
            String dayName,
            String timeRange,
            double successRate,
            int totalDeployments,
            int successfulDeployments,
            double avgDurationMinutes) {}

    /** Optimal deployment windows analysis */
    public record OptimalDeploymentWindows(
            List<TimeWindow> recommendedWindows,
            List<TimeWindow> worstWindows,
            TimeWindow currentWindow,
            String summary) {}

    /** Deployment timing evaluation */
    public record DeploymentTimingEvaluation(
            String rating, // EXCELLENT, GOOD, FAIR, POOR, UNKNOWN
            Double successRate,
            String recommendation,
            List<String> concerns,
            TimeWindow suggestedAlternative) {}

    /** Next recommended deployment window */
    public record NextDeploymentWindow(
            LocalDateTime nextOccurrence, TimeWindow window, String explanation) {}
}
