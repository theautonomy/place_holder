package com.example.demo.ai;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.rag.RAGService;
import com.example.demo.rag.entity.BuildFailure;

import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GHWorkflowRun;
import org.kohsuke.github.GitHub;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class BuildFailureAnalysisService {

    private static final Logger logger = LoggerFactory.getLogger(BuildFailureAnalysisService.class);

    private final ChatClient chatClient;
    private final RAGService ragService;

    public BuildFailureAnalysisService(
            ChatClient.Builder chatClientBuilder, RAGService ragService) {
        this.chatClient = chatClientBuilder.build();
        this.ragService = ragService;
    }

    /** Analyze a failed workflow run and provide AI-powered insights */
    public FailureAnalysis analyzeFailure(GitHub gitHub, String repoFullName, long runId)
            throws IOException {

        logger.info("Analyzing failure for repository: {}, runId: {}", repoFullName, runId);

        GHRepository repository = gitHub.getRepository(repoFullName);
        GHWorkflowRun run = repository.getWorkflowRun(runId);

        // Check if the run actually failed
        if (run.getConclusion() == null
                || !run.getConclusion().toString().equalsIgnoreCase("FAILURE")) {
            throw new IllegalArgumentException(
                    "Workflow run #" + runId + " did not fail. Cannot analyze.");
        }

        // Gather context about the failure
        String workflowName = run.getName();
        String branch = run.getHeadBranch();
        String commitMessage = run.getHeadCommit().getMessage();
        String commitAuthor = run.getHeadCommit().getAuthor().getName();
        String commitSha = run.getHeadSha();

        // Get workflow run logs (simplified - in production you'd fetch actual logs)
        String logs = getWorkflowLogs(run);

        // Store the failure in RAG database for future learning
        logger.info("Storing failure in RAG database");
        BuildFailure storedFailure =
                ragService.storeFailure(
                        repoFullName,
                        workflowName,
                        runId,
                        (int) run.getRunNumber(), // Cast to Integer
                        logs, // Use logs as error message for now
                        null, // No stacktrace yet
                        branch,
                        commitSha,
                        null // No specific failed step yet
                        );

        // Query RAG for similar past failures
        logger.info("Querying RAG for similar failures");
        List<BuildFailure> similarFailures =
                ragService.findSimilarResolvedFailures(logs, null, null);

        // Build context from similar failures
        String ragContext = buildRAGContext(similarFailures);

        // Create enhanced AI prompt with RAG context
        String promptText =
                String.format(
                        """
                You are an expert DevOps engineer analyzing a failed CI/CD build.
                You have access to historical data about similar failures and their solutions.

                Workflow Information:
                - Repository: %s
                - Workflow: %s
                - Branch: %s
                - Commit: %s
                - Author: %s
                - Status: FAILURE

                Build Logs:
                %s

                %s

                Please analyze this build failure and provide:

                1. ROOT CAUSE: A concise explanation of what caused the build to fail (2-3 sentences)
                2. SUGGESTED FIX: Specific actionable steps to resolve the issue (bullet points)
                3. CONFIDENCE LEVEL: Your confidence in this analysis (high/medium/low)
                4. SIMILAR ISSUES: Common patterns or known issues this might be related to
                5. PREVENTION: How to prevent this issue in the future

                Format your response as JSON with these fields:
                - rootCause: string
                - suggestedFix: array of strings
                - confidence: "high" or "medium" or "low"
                - similarIssues: array of strings
                - prevention: string
                """,
                        repoFullName,
                        workflowName,
                        branch,
                        commitMessage,
                        commitAuthor,
                        logs,
                        ragContext);

        // Call AI to analyze - use the prompt directly (already formatted)
        logger.info("Calling AI for analysis with RAG context");
        String aiResponse = chatClient.prompt().user(promptText).call().content();

        // Store AI analysis in RAG database
        String confidence = extractJsonField(aiResponse, "confidence");
        ragService.storeAIAnalysis(storedFailure.getId(), aiResponse, confidence.toUpperCase());

        // Parse the AI response (simplified - in production use proper JSON parsing)
        FailureAnalysis analysis = parseAiResponse(aiResponse, run);
        analysis.similarFailuresCount = similarFailures.size();
        analysis.hasHistoricalSolutions = !similarFailures.isEmpty();

        logger.info("Analysis complete with {} similar failures found", similarFailures.size());
        return analysis;
    }

    /** Build context from similar failures in RAG database */
    private String buildRAGContext(List<BuildFailure> similarFailures) {
        if (similarFailures.isEmpty()) {
            return "HISTORICAL CONTEXT:\nNo similar failures found in the database. This appears to be a new type of failure.";
        }

        StringBuilder context = new StringBuilder();
        context.append("HISTORICAL CONTEXT:\n");
        context.append(
                String.format(
                        "Found %d similar failures in the database:\n\n", similarFailures.size()));

        int count = 1;
        for (BuildFailure failure : similarFailures) {
            context.append(String.format("Similar Failure #%d:\n", count++));
            context.append(String.format("  - Repository: %s\n", failure.getRepository()));
            context.append(String.format("  - Workflow: %s\n", failure.getWorkflowName()));
            context.append(String.format("  - Branch: %s\n", failure.getBranch()));

            if (failure.getResolutionDescription() != null) {
                context.append(
                        String.format("  - Solution: %s\n", failure.getResolutionDescription()));
                if (failure.getTimeToFixMinutes() != null) {
                    context.append(
                            String.format(
                                    "  - Time to Fix: %d minutes\n",
                                    failure.getTimeToFixMinutes()));
                }
                context.append(String.format("  - Fixed by: %s\n", failure.getFixedBy()));
                context.append(
                        String.format(
                                "  - Solution Effectiveness: %.2f (used %d times)\n",
                                failure.getSolutionEffectiveness(), failure.getTimesHelped()));

                if (failure.getResolutionCodeSnippet() != null) {
                    context.append("  - Code Fix:\n");
                    context.append("    ```\n");
                    context.append(
                            "    " + failure.getResolutionCodeSnippet().replace("\n", "\n    "));
                    context.append("\n    ```\n");
                }
            }
            context.append("\n");
        }

        context.append(
                "Use this historical context to inform your analysis and provide more accurate recommendations.\n");
        return context.toString();
    }

    /**
     * Get workflow run logs (simplified version) In production, you would fetch actual logs from
     * GitHub API
     */
    private String getWorkflowLogs(GHWorkflowRun run) throws IOException {
        // For now, return a summary based on available information
        // In production, use: run.downloadLogs() or GitHub API to get actual logs

        StringBuilder logSummary = new StringBuilder();
        logSummary.append("Workflow Run #").append(run.getRunNumber()).append("\n");
        logSummary.append("Status: ").append(run.getStatus()).append("\n");
        logSummary.append("Conclusion: ").append(run.getConclusion()).append("\n");
        logSummary.append("Started: ").append(run.getCreatedAt()).append("\n");
        logSummary.append("Updated: ").append(run.getUpdatedAt()).append("\n");

        // Note: To get actual logs, you would need to:
        // 1. Use GitHub API to download log archive
        // 2. Extract and parse the log files
        // 3. Identify the failed step
        // For now, we provide a placeholder

        logSummary.append(
                "\nNOTE: This is a simplified analysis. For full log analysis, implement log"
                        + " download.");

        return logSummary.toString();
    }

    /** Parse AI response into structured FailureAnalysis object */
    private FailureAnalysis parseAiResponse(String aiResponse, GHWorkflowRun run)
            throws IOException {
        // Simple parsing - in production, use Jackson or Gson for proper JSON parsing
        FailureAnalysis analysis = new FailureAnalysis();
        analysis.runNumber = run.getRunNumber();
        analysis.workflowName = run.getName();
        analysis.branch = run.getHeadBranch();
        analysis.url = run.getHtmlUrl().toString();

        // For now, just store the raw AI response
        // In production, properly parse the JSON response
        analysis.aiAnalysis = aiResponse;

        // Try to extract key information (very basic parsing)
        if (aiResponse.contains("\"rootCause\"")) {
            analysis.rootCause = extractJsonField(aiResponse, "rootCause");
            analysis.confidence = extractJsonField(aiResponse, "confidence");
            analysis.prevention = extractJsonField(aiResponse, "prevention");
        } else {
            // If AI didn't return JSON, use the whole response
            analysis.rootCause = "See AI analysis for details";
            analysis.confidence = "medium";
        }

        analysis.suggestedFixes = new ArrayList<>();
        analysis.suggestedFixes.add("Review the AI analysis below for detailed recommendations");

        return analysis;
    }

    /** Simple JSON field extraction (replace with proper JSON parsing in production) */
    private String extractJsonField(String json, String fieldName) {
        try {
            String pattern = "\"" + fieldName + "\"\\s*:\\s*\"([^\"]+)\"";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                return m.group(1);
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return "Not specified";
    }

    /** DTO for failure analysis results */
    public static class FailureAnalysis {
        public long runNumber;
        public String workflowName;
        public String branch;
        public String url;
        public String rootCause;
        public List<String> suggestedFixes;
        public String confidence;
        public String prevention;
        public String aiAnalysis; // Full AI response
        public int similarFailuresCount; // Number of similar failures found in RAG
        public boolean hasHistoricalSolutions; // Whether we found historical solutions
    }
}
