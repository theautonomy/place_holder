package com.example.demo.ai;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GHWorkflowRun;
import org.kohsuke.github.GitHub;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class BuildFailureAnalysisService {

    private final ChatClient chatClient;

    public BuildFailureAnalysisService(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    /** Analyze a failed workflow run and provide AI-powered insights */
    public FailureAnalysis analyzeFailure(GitHub gitHub, String repoFullName, long runId)
            throws IOException {

        GHRepository repository = gitHub.getRepository(repoFullName);
        GHWorkflowRun run = repository.getWorkflowRun(runId);

        // Check if the run actually failed
        if (run.getConclusion() == null
                || !run.getConclusion().toString().equalsIgnoreCase("FAILURE")) {
            throw new IllegalArgumentException(
                    "Workflow run #" + runId + " did not fail. Cannot analyze.");
        }

        // Gather context about the failure
        String workflowName = run.getName();
        String branch = run.getHeadBranch();
        String commitMessage = run.getHeadCommit().getMessage();
        String commitAuthor = run.getHeadCommit().getAuthor().getName();

        // Get workflow run logs (simplified - in production you'd fetch actual logs)
        String logs = getWorkflowLogs(run);

        // Create AI prompt for analysis
        // Build the prompt - use simple string concatenation to avoid template issues
        String promptText =
                String.format(
                        """
                You are an expert DevOps engineer analyzing a failed CI/CD build.

                Workflow Information:
                - Workflow: %s
                - Branch: %s
                - Commit: %s
                - Author: %s
                - Status: FAILURE

                Build Logs:
                %s

                Please analyze this build failure and provide:

                1. ROOT CAUSE: A concise explanation of what caused the build to fail (2-3 sentences)
                2. SUGGESTED FIX: Specific actionable steps to resolve the issue (bullet points)
                3. CONFIDENCE LEVEL: Your confidence in this analysis (high/medium/low)
                4. SIMILAR ISSUES: Common patterns or known issues this might be related to
                5. PREVENTION: How to prevent this issue in the future

                Format your response as JSON with these fields:
                - rootCause: string
                - suggestedFix: array of strings
                - confidence: "high" or "medium" or "low"
                - similarIssues: array of strings
                - prevention: string
                """,
                        workflowName, branch, commitMessage, commitAuthor, logs);

        // Call AI to analyze - use the prompt directly (already formatted)
        String aiResponse = chatClient.prompt().user(promptText).call().content();

        // Parse the AI response (simplified - in production use proper JSON parsing)
        return parseAiResponse(aiResponse, run);
    }

    /**
     * Get workflow run logs (simplified version) In production, you would fetch actual logs from
     * GitHub API
     */
    private String getWorkflowLogs(GHWorkflowRun run) throws IOException {
        // For now, return a summary based on available information
        // In production, use: run.downloadLogs() or GitHub API to get actual logs

        StringBuilder logSummary = new StringBuilder();
        logSummary.append("Workflow Run #").append(run.getRunNumber()).append("\n");
        logSummary.append("Status: ").append(run.getStatus()).append("\n");
        logSummary.append("Conclusion: ").append(run.getConclusion()).append("\n");
        logSummary.append("Started: ").append(run.getCreatedAt()).append("\n");
        logSummary.append("Updated: ").append(run.getUpdatedAt()).append("\n");

        // Note: To get actual logs, you would need to:
        // 1. Use GitHub API to download log archive
        // 2. Extract and parse the log files
        // 3. Identify the failed step
        // For now, we provide a placeholder

        logSummary.append(
                "\nNOTE: This is a simplified analysis. For full log analysis, implement log"
                        + " download.");

        return logSummary.toString();
    }

    /** Parse AI response into structured FailureAnalysis object */
    private FailureAnalysis parseAiResponse(String aiResponse, GHWorkflowRun run)
            throws IOException {
        // Simple parsing - in production, use Jackson or Gson for proper JSON parsing
        FailureAnalysis analysis = new FailureAnalysis();
        analysis.runNumber = run.getRunNumber();
        analysis.workflowName = run.getName();
        analysis.branch = run.getHeadBranch();
        analysis.url = run.getHtmlUrl().toString();

        // For now, just store the raw AI response
        // In production, properly parse the JSON response
        analysis.aiAnalysis = aiResponse;

        // Try to extract key information (very basic parsing)
        if (aiResponse.contains("\"rootCause\"")) {
            analysis.rootCause = extractJsonField(aiResponse, "rootCause");
            analysis.confidence = extractJsonField(aiResponse, "confidence");
            analysis.prevention = extractJsonField(aiResponse, "prevention");
        } else {
            // If AI didn't return JSON, use the whole response
            analysis.rootCause = "See AI analysis for details";
            analysis.confidence = "medium";
        }

        analysis.suggestedFixes = new ArrayList<>();
        analysis.suggestedFixes.add("Review the AI analysis below for detailed recommendations");

        return analysis;
    }

    /** Simple JSON field extraction (replace with proper JSON parsing in production) */
    private String extractJsonField(String json, String fieldName) {
        try {
            String pattern = "\"" + fieldName + "\"\\s*:\\s*\"([^\"]+)\"";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                return m.group(1);
            }
        } catch (Exception e) {
            // Ignore parsing errors
        }
        return "Not specified";
    }

    /** DTO for failure analysis results */
    public static class FailureAnalysis {
        public long runNumber;
        public String workflowName;
        public String branch;
        public String url;
        public String rootCause;
        public List<String> suggestedFixes;
        public String confidence;
        public String prevention;
        public String aiAnalysis; // Full AI response
    }
}
