package com.example.demo.ai;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.kohsuke.github.GHCommit;
import org.kohsuke.github.GHCompare;
import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GitHub;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class DeploymentRiskService {

    private final ChatClient chatClient;

    public DeploymentRiskService(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    /** Assess deployment risk by analyzing changes between two commits */
    public RiskAssessment assessDeploymentRisk(
            GitHub gitHub,
            String repoFullName,
            String fromCommit,
            String toCommit,
            String targetEnvironment)
            throws IOException {

        GHRepository repository = gitHub.getRepository(repoFullName);

        // Get comparison between commits
        GHCompare comparison = repository.getCompare(fromCommit, toCommit);

        // Gather change statistics
        int totalCommits = comparison.getTotalCommits();
        var files = comparison.getFiles();
        int filesChanged = files.length;
        int additions = 0;
        int deletions = 0;

        List<String> changedFiles = new ArrayList<>();
        for (var file : files) {
            changedFiles.add(file.getFileName());
            additions += file.getLinesAdded();
            deletions += file.getLinesDeleted();
        }

        // Get commit messages
        List<String> commitMessages = new ArrayList<>();
        for (GHCommit commit : comparison.getCommits()) {
            try {
                var shortInfo = commit.getCommitShortInfo();
                if (shortInfo != null && shortInfo.getMessage() != null) {
                    commitMessages.add(shortInfo.getMessage());
                }
            } catch (Exception e) {
                // Skip commits that can't be accessed
            }
        }

        // Analyze file types and patterns
        boolean hasDatabaseChanges =
                changedFiles.stream()
                        .anyMatch(
                                f ->
                                        f.contains("migration")
                                                || f.contains("schema")
                                                || f.endsWith(".sql"));
        boolean hasConfigChanges =
                changedFiles.stream()
                        .anyMatch(
                                f ->
                                        f.contains("config")
                                                || f.endsWith(".properties")
                                                || f.endsWith(".yml")
                                                || f.endsWith(".yaml"));
        boolean hasCriticalFiles =
                changedFiles.stream()
                        .anyMatch(
                                f ->
                                        f.contains("Auth")
                                                || f.contains("Security")
                                                || f.contains("Payment"));

        // Build AI prompt
        String promptText =
                String.format(
                        """
                You are an expert DevOps engineer assessing deployment risk.

                Deployment Information:
                - Repository: %s
                - From Commit: %s
                - To Commit: %s
                - Target Environment: %s

                Change Statistics:
                - Total Commits: %d
                - Files Changed: %d
                - Lines Added: %d
                - Lines Deleted: %d
                - Has Database Changes: %s
                - Has Config Changes: %s
                - Has Critical Files (Auth/Security/Payment): %s

                Changed Files:
                %s

                Recent Commit Messages:
                %s

                Please assess the deployment risk and provide:

                1. RISK LEVEL: Overall risk level (low/medium/high/critical)
                2. RISK SCORE: Numerical score from 0-10 (0=no risk, 10=critical risk)
                3. RISK FACTORS: Key factors contributing to the risk
                4. RECOMMENDATIONS: Specific recommendations for this deployment
                5. AFFECTED COMPONENTS: Which parts of the system are affected
                6. DEPLOYMENT STRATEGY: Recommended deployment approach (standard/canary/blue-green/staged)

                Format your response as JSON with these fields:
                - riskLevel: "low" or "medium" or "high" or "critical"
                - riskScore: number between 0-10
                - riskFactors: array of strings
                - recommendations: array of strings
                - affectedComponents: array of strings
                - deploymentStrategy: string
                - reasoning: string explaining the assessment
                """,
                        repoFullName,
                        fromCommit.substring(0, Math.min(7, fromCommit.length())),
                        toCommit.substring(0, Math.min(7, toCommit.length())),
                        targetEnvironment,
                        totalCommits,
                        filesChanged,
                        additions,
                        deletions,
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles,
                        String.join("\n", changedFiles.stream().limit(20).toList()),
                        String.join("\n", commitMessages.stream().limit(10).toList()));

        // Call AI to analyze
        String aiResponse = chatClient.prompt().user(promptText).call().content();

        // Parse and return assessment
        return parseRiskAssessment(aiResponse, totalCommits, filesChanged, additions, deletions);
    }

    /** Parse AI response into structured RiskAssessment object */
    private RiskAssessment parseRiskAssessment(
            String aiResponse, int commits, int files, int additions, int deletions) {

        RiskAssessment assessment = new RiskAssessment();
        assessment.totalCommits = commits;
        assessment.filesChanged = files;
        assessment.linesAdded = additions;
        assessment.linesDeleted = deletions;
        assessment.aiAnalysis = aiResponse;

        // Try to extract structured information from AI response
        assessment.riskLevel = extractJsonField(aiResponse, "riskLevel");
        assessment.deploymentStrategy = extractJsonField(aiResponse, "deploymentStrategy");
        assessment.reasoning = extractJsonField(aiResponse, "reasoning");

        // Try to parse risk score
        try {
            String scoreStr = extractJsonField(aiResponse, "riskScore");
            assessment.riskScore = Double.parseDouble(scoreStr.replaceAll("[^0-9.]", ""));
        } catch (Exception e) {
            // Default based on risk level
            assessment.riskScore =
                    switch (assessment.riskLevel.toLowerCase()) {
                        case "critical" -> 9.0;
                        case "high" -> 7.0;
                        case "medium" -> 5.0;
                        default -> 2.0;
                    };
        }

        // Extract arrays (simplified - in production use proper JSON parsing)
        assessment.riskFactors = extractArrayField(aiResponse, "riskFactors");
        assessment.recommendations = extractArrayField(aiResponse, "recommendations");
        assessment.affectedComponents = extractArrayField(aiResponse, "affectedComponents");

        // Provide defaults if extraction failed
        if (assessment.riskFactors.isEmpty()) {
            assessment.riskFactors.add("See AI analysis for detailed risk factors");
        }
        if (assessment.recommendations.isEmpty()) {
            assessment.recommendations.add("Review the AI analysis below for recommendations");
        }

        return assessment;
    }

    /** Simple JSON field extraction */
    private String extractJsonField(String json, String fieldName) {
        try {
            String pattern = "\"" + fieldName + "\"\\s*:\\s*\"([^\"]+)\"";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                return m.group(1);
            }
        } catch (Exception e) {
            // Ignore
        }
        return "Not specified";
    }

    /** Extract array field from JSON (simplified) */
    private List<String> extractArrayField(String json, String fieldName) {
        List<String> result = new ArrayList<>();
        try {
            // Look for pattern: "fieldName": ["item1", "item2"]
            String pattern = "\"" + fieldName + "\"\\s*:\\s*\\[(.*?)\\]";
            java.util.regex.Pattern p =
                    java.util.regex.Pattern.compile(pattern, java.util.regex.Pattern.DOTALL);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                String arrayContent = m.group(1);
                // Extract quoted strings
                java.util.regex.Pattern itemPattern =
                        java.util.regex.Pattern.compile("\"([^\"]+)\"");
                java.util.regex.Matcher itemMatcher = itemPattern.matcher(arrayContent);
                while (itemMatcher.find()) {
                    result.add(itemMatcher.group(1));
                }
            }
        } catch (Exception e) {
            // Ignore
        }
        return result;
    }

    /** DTO for risk assessment results */
    public static class RiskAssessment {
        public String riskLevel; // low, medium, high, critical
        public double riskScore; // 0-10
        public List<String> riskFactors;
        public List<String> recommendations;
        public List<String> affectedComponents;
        public String deploymentStrategy;
        public String reasoning;

        // Change statistics
        public int totalCommits;
        public int filesChanged;
        public int linesAdded;
        public int linesDeleted;

        // Full AI response
        public String aiAnalysis;
    }
}
