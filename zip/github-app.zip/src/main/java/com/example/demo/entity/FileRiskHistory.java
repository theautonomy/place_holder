package com.example.demo.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * Entity tracking file-specific risk metrics based on historical incidents Helps identify which
 * files are dangerous to modify based on past deployment outcomes
 */
@Entity
@Table(
        name = "file_risk_history",
        indexes = {
            @Index(name = "idx_repository_file", columnList = "repository,file_path"),
            @Index(name = "idx_incident_rate", columnList = "incident_rate")
        },
        uniqueConstraints = @UniqueConstraint(columnNames = {"repository", "file_path"}))
public class FileRiskHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    // File Information
    @Column(nullable = false, length = 255)
    private String repository;

    @Column(name = "file_path", nullable = false, length = 500)
    private String filePath;

    @Column(name = "file_type", length = 50)
    private String fileType; // java, yaml, sql, ts, etc.

    // Risk Metrics
    @Column(name = "total_modifications")
    private Integer totalModifications = 0;

    @Column(name = "modifications_causing_incidents")
    private Integer modificationsCausingIncidents = 0;

    @Column(name = "incident_rate")
    private Double incidentRate; // modifications_causing_incidents / total_modifications

    // Incident Details
    @Column(name = "last_incident_date")
    private LocalDateTime lastIncidentDate;

    @Column(name = "last_incident_description", columnDefinition = "TEXT")
    private String lastIncidentDescription;

    @Column(name = "common_failure_types", columnDefinition = "TEXT[]")
    private String[] commonFailureTypes;

    // Complexity Metrics
    @Column(name = "average_lines_changed")
    private Double averageLinesChanged;

    @Column(name = "max_lines_changed")
    private Integer maxLinesChanged;

    @Column(name = "requires_expert")
    private Boolean requiresExpert = false;

    @Column(name = "expert_developers", columnDefinition = "TEXT[]")
    private String[] expertDevelopers; // Who has successfully modified this file

    // Metadata
    @Column(name = "first_modified_at")
    private LocalDateTime firstModifiedAt;

    @Column(name = "last_modified_at")
    private LocalDateTime lastModifiedAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
        // Recalculate incident rate
        if (totalModifications != null && totalModifications > 0) {
            incidentRate =
                    (double)
                                    (modificationsCausingIncidents != null
                                            ? modificationsCausingIncidents
                                            : 0)
                            / totalModifications;
        }
    }

    // Constructors
    public FileRiskHistory() {}

    public FileRiskHistory(String repository, String filePath) {
        this.repository = repository;
        this.filePath = filePath;
        this.totalModifications = 0;
        this.modificationsCausingIncidents = 0;
        this.incidentRate = 0.0;
    }

    // Business Methods

    /** Record a successful modification */
    public void recordSuccessfulModification(int linesChanged, String developer) {
        this.totalModifications++;
        updateComplexityMetrics(linesChanged);
        updateExpertise(developer, true);
        recalculateIncidentRate();
    }

    /** Record a modification that caused an incident */
    public void recordIncidentModification(
            int linesChanged, String developer, String incidentDescription, String failureType) {
        this.totalModifications++;
        this.modificationsCausingIncidents++;
        updateComplexityMetrics(linesChanged);
        updateExpertise(developer, false);
        this.lastIncidentDate = LocalDateTime.now();
        this.lastIncidentDescription = incidentDescription;
        addFailureType(failureType);
        recalculateIncidentRate();
    }

    private void updateComplexityMetrics(int linesChanged) {
        if (averageLinesChanged == null) {
            averageLinesChanged = (double) linesChanged;
        } else {
            averageLinesChanged =
                    ((averageLinesChanged * (totalModifications - 1)) + linesChanged)
                            / totalModifications;
        }

        if (maxLinesChanged == null || linesChanged > maxLinesChanged) {
            maxLinesChanged = linesChanged;
        }
    }

    private void updateExpertise(String developer, boolean success) {
        if (developer == null || developer.isEmpty()) return;

        if (success && incidentRate != null && incidentRate > 0.3) {
            // This developer successfully modified a risky file
            addExpert(developer);
        }
    }

    private void addExpert(String developer) {
        if (expertDevelopers == null) {
            expertDevelopers = new String[] {developer};
        } else {
            // Check if already in list
            for (String expert : expertDevelopers) {
                if (expert.equals(developer)) return;
            }
            // Add to list
            String[] newExperts = new String[expertDevelopers.length + 1];
            System.arraycopy(expertDevelopers, 0, newExperts, 0, expertDevelopers.length);
            newExperts[expertDevelopers.length] = developer;
            expertDevelopers = newExperts;
        }
    }

    private void addFailureType(String failureType) {
        if (failureType == null || failureType.isEmpty()) return;

        if (commonFailureTypes == null) {
            commonFailureTypes = new String[] {failureType};
        } else {
            // Check if already in list
            for (String type : commonFailureTypes) {
                if (type.equals(failureType)) return;
            }
            // Add to list
            String[] newTypes = new String[commonFailureTypes.length + 1];
            System.arraycopy(commonFailureTypes, 0, newTypes, 0, commonFailureTypes.length);
            newTypes[commonFailureTypes.length] = failureType;
            commonFailureTypes = newTypes;
        }
    }

    private void recalculateIncidentRate() {
        if (totalModifications > 0) {
            incidentRate = (double) modificationsCausingIncidents / totalModifications;
            requiresExpert = incidentRate > 0.3; // 30% incident rate = needs expert
        }
    }

    /** Determine risk level based on incident rate */
    public String getRiskLevel() {
        if (incidentRate == null || incidentRate == 0) return "LOW";
        if (incidentRate < 0.2) return "LOW";
        if (incidentRate < 0.4) return "MEDIUM";
        if (incidentRate < 0.6) return "HIGH";
        return "CRITICAL";
    }

    // Getters and Setters

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public Integer getTotalModifications() {
        return totalModifications;
    }

    public void setTotalModifications(Integer totalModifications) {
        this.totalModifications = totalModifications;
    }

    public Integer getModificationsCausingIncidents() {
        return modificationsCausingIncidents;
    }

    public void setModificationsCausingIncidents(Integer modificationsCausingIncidents) {
        this.modificationsCausingIncidents = modificationsCausingIncidents;
    }

    public Double getIncidentRate() {
        return incidentRate;
    }

    public void setIncidentRate(Double incidentRate) {
        this.incidentRate = incidentRate;
    }

    public LocalDateTime getLastIncidentDate() {
        return lastIncidentDate;
    }

    public void setLastIncidentDate(LocalDateTime lastIncidentDate) {
        this.lastIncidentDate = lastIncidentDate;
    }

    public String getLastIncidentDescription() {
        return lastIncidentDescription;
    }

    public void setLastIncidentDescription(String lastIncidentDescription) {
        this.lastIncidentDescription = lastIncidentDescription;
    }

    public String[] getCommonFailureTypes() {
        return commonFailureTypes;
    }

    public void setCommonFailureTypes(String[] commonFailureTypes) {
        this.commonFailureTypes = commonFailureTypes;
    }

    public Double getAverageLinesChanged() {
        return averageLinesChanged;
    }

    public void setAverageLinesChanged(Double averageLinesChanged) {
        this.averageLinesChanged = averageLinesChanged;
    }

    public Integer getMaxLinesChanged() {
        return maxLinesChanged;
    }

    public void setMaxLinesChanged(Integer maxLinesChanged) {
        this.maxLinesChanged = maxLinesChanged;
    }

    public Boolean getRequiresExpert() {
        return requiresExpert;
    }

    public void setRequiresExpert(Boolean requiresExpert) {
        this.requiresExpert = requiresExpert;
    }

    public String[] getExpertDevelopers() {
        return expertDevelopers;
    }

    public void setExpertDevelopers(String[] expertDevelopers) {
        this.expertDevelopers = expertDevelopers;
    }

    public LocalDateTime getFirstModifiedAt() {
        return firstModifiedAt;
    }

    public void setFirstModifiedAt(LocalDateTime firstModifiedAt) {
        this.firstModifiedAt = firstModifiedAt;
    }

    public LocalDateTime getLastModifiedAt() {
        return lastModifiedAt;
    }

    public void setLastModifiedAt(LocalDateTime lastModifiedAt) {
        this.lastModifiedAt = lastModifiedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
