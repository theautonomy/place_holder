package com.example.demo;

import org.kohsuke.github.GitHub;
import org.kohsuke.github.GitHubBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(1)
public class WorkflowDashboardRunner implements CommandLineRunner {

    @Value("${github.pat}")
    private String githubPat;

    @Value("${github.repository}")
    private String repository;

    @Value("${github.workflow}")
    private String workflow;

    @Value("${dashboard.enabled:true}")
    private boolean dashboardEnabled;

    @Value("${dashboard.show-deployments:true}")
    private boolean showDeployments;

    @Value("${dashboard.show-commit-diff:true}")
    private boolean showCommitDiff;

    @Value("${deployment.tracking.enabled:false}")
    private boolean deploymentTrackingEnabled;

    @Override
    public void run(String... args) throws Exception {
        if (!dashboardEnabled) {
            return;
        }

        try {
            // Initialize GitHub API
            GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();

            // Initialize Dashboard Service
            GitHubDashboardService dashboardService =
                    new GitHubDashboardService(gitHub, repository);

            // Print Dashboard Header
            DashboardFormatter.printHeader(repository);

            // 1. Quick Metrics Overview
            var metrics = dashboardService.getDashboardMetrics(workflow);
            DashboardFormatter.printQuickMetrics(metrics);

            // 2. Workflow Monitoring
            var workflowData = dashboardService.getWorkflowMonitoring(workflow);
            DashboardFormatter.printWorkflowMonitoring(workflowData);

            // 3. Deployment Status (optional - legacy, only if deployment tracking is disabled)
            if (showDeployments && !deploymentTrackingEnabled) {
                var deployments = dashboardService.getDeploymentStatus();
                if (!deployments.isEmpty()) {
                    DashboardFormatter.printDeploymentStatus(deployments);
                }
            }

            // 4. Latest Build Commit Diff (optional)
            if (showCommitDiff) {
                var diffData = dashboardService.getLatestBuildDiff(workflow);
                if (diffData != null) {
                    DashboardFormatter.printCommitDiff(diffData);
                }
            }

        } catch (Exception e) {
            System.err.println("Error generating workflow dashboard: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
