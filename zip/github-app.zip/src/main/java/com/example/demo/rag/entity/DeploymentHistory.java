package com.example.demo.rag.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import com.pgvector.PGvector;

import org.hibernate.annotations.Type;

import jakarta.persistence.*;

/**
 * Entity representing a deployment's historical data including predictions, actual outcomes, and
 * vector embeddings for similarity search
 */
@Entity
@Table(
        name = "deployment_history",
        indexes = {
            @Index(name = "idx_deployment_repository", columnList = "repository"),
            @Index(name = "idx_deployment_environment", columnList = "environment"),
            @Index(name = "idx_deployment_deployed_at", columnList = "deployed_at"),
            @Index(name = "idx_deployment_status", columnList = "deployment_status"),
            @Index(name = "idx_deployment_day_of_week", columnList = "day_of_week"),
            @Index(name = "idx_deployment_hour_of_day", columnList = "hour_of_day")
        })
public class DeploymentHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    // Deployment Information
    @Column(nullable = false, length = 255)
    private String repository;

    @Column(name = "from_commit", nullable = false, length = 40)
    private String fromCommit;

    @Column(name = "to_commit", nullable = false, length = 40)
    private String toCommit;

    @Column(nullable = false, length = 50)
    private String environment; // production, staging, development

    // Changes Summary
    @Column(name = "total_commits")
    private Integer totalCommits;

    @Column(name = "files_changed")
    private Integer filesChanged;

    @Column(name = "lines_added")
    private Integer linesAdded;

    @Column(name = "lines_deleted")
    private Integer linesDeleted;

    @Column(name = "changed_files", columnDefinition = "TEXT[]")
    private String[] changedFiles;

    @Column(name = "commit_messages", columnDefinition = "TEXT[]")
    private String[] commitMessages;

    // Risk Assessment (Predicted)
    @Column(name = "predicted_risk_level", length = 20)
    private String predictedRiskLevel; // low, medium, high, critical

    @Column(name = "predicted_risk_score")
    private Double predictedRiskScore; // 0-10

    @Column(name = "ai_risk_factors", columnDefinition = "TEXT[]")
    private String[] aiRiskFactors;

    @Column(name = "ai_recommendations", columnDefinition = "TEXT[]")
    private String[] aiRecommendations;

    // Actual Outcome
    @Column(name = "deployment_status", length = 20)
    private String deploymentStatus; // success, failed, rolled_back, pending

    @Column(name = "actual_success")
    private Boolean actualSuccess;

    @Column(name = "deployment_duration_minutes")
    private Integer deploymentDurationMinutes;

    // Issues Encountered
    @Column(name = "issues_encountered", columnDefinition = "TEXT[]")
    private String[] issuesEncountered;

    @Column(name = "incident_severity", length = 20)
    private String incidentSeverity; // none, minor, major, critical

    @Column(name = "downtime_minutes")
    private Integer downtimeMinutes;

    @Column(name = "error_logs", columnDefinition = "TEXT")
    private String errorLogs;

    // Resolution
    @Column(name = "rollback_required")
    private Boolean rollbackRequired;

    @Column(name = "rollback_commit", length = 40)
    private String rollbackCommit;

    @Column(name = "resolution_description", columnDefinition = "TEXT")
    private String resolutionDescription;

    // Temporal Data
    @Column(name = "deployed_at", nullable = false)
    private LocalDateTime deployedAt;

    @Column(name = "deployed_by", length = 100)
    private String deployedBy;

    @Column(name = "day_of_week")
    private Integer dayOfWeek; // 0=Sunday, 6=Saturday

    @Column(name = "hour_of_day")
    private Integer hourOfDay; // 0-23

    // Pattern Detection Flags
    @Column(name = "has_database_changes")
    private Boolean hasDatabaseChanges = false;

    @Column(name = "has_config_changes")
    private Boolean hasConfigChanges = false;

    @Column(name = "has_critical_files")
    private Boolean hasCriticalFiles = false;

    // Vector Embedding
    @Column(name = "change_embedding", columnDefinition = "vector(1536)")
    @Type(com.example.demo.rag.VectorType.class)
    private PGvector changeEmbedding;

    // Metadata
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public DeploymentHistory() {}

    public DeploymentHistory(
            String repository,
            String fromCommit,
            String toCommit,
            String environment,
            LocalDateTime deployedAt) {
        this.repository = repository;
        this.fromCommit = fromCommit;
        this.toCommit = toCommit;
        this.environment = environment;
        this.deployedAt = deployedAt;

        // Set time-based fields
        if (deployedAt != null) {
            this.dayOfWeek = deployedAt.getDayOfWeek().getValue() % 7; // Convert to 0=Sun, 6=Sat
            this.hourOfDay = deployedAt.getHour();
        }
    }

    // Getters and Setters

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getFromCommit() {
        return fromCommit;
    }

    public void setFromCommit(String fromCommit) {
        this.fromCommit = fromCommit;
    }

    public String getToCommit() {
        return toCommit;
    }

    public void setToCommit(String toCommit) {
        this.toCommit = toCommit;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public Integer getTotalCommits() {
        return totalCommits;
    }

    public void setTotalCommits(Integer totalCommits) {
        this.totalCommits = totalCommits;
    }

    public Integer getFilesChanged() {
        return filesChanged;
    }

    public void setFilesChanged(Integer filesChanged) {
        this.filesChanged = filesChanged;
    }

    public Integer getLinesAdded() {
        return linesAdded;
    }

    public void setLinesAdded(Integer linesAdded) {
        this.linesAdded = linesAdded;
    }

    public Integer getLinesDeleted() {
        return linesDeleted;
    }

    public void setLinesDeleted(Integer linesDeleted) {
        this.linesDeleted = linesDeleted;
    }

    public String[] getChangedFiles() {
        return changedFiles;
    }

    public void setChangedFiles(String[] changedFiles) {
        this.changedFiles = changedFiles;
    }

    public String[] getCommitMessages() {
        return commitMessages;
    }

    public void setCommitMessages(String[] commitMessages) {
        this.commitMessages = commitMessages;
    }

    public String getPredictedRiskLevel() {
        return predictedRiskLevel;
    }

    public void setPredictedRiskLevel(String predictedRiskLevel) {
        this.predictedRiskLevel = predictedRiskLevel;
    }

    public Double getPredictedRiskScore() {
        return predictedRiskScore;
    }

    public void setPredictedRiskScore(Double predictedRiskScore) {
        this.predictedRiskScore = predictedRiskScore;
    }

    public String[] getAiRiskFactors() {
        return aiRiskFactors;
    }

    public void setAiRiskFactors(String[] aiRiskFactors) {
        this.aiRiskFactors = aiRiskFactors;
    }

    public String[] getAiRecommendations() {
        return aiRecommendations;
    }

    public void setAiRecommendations(String[] aiRecommendations) {
        this.aiRecommendations = aiRecommendations;
    }

    public String getDeploymentStatus() {
        return deploymentStatus;
    }

    public void setDeploymentStatus(String deploymentStatus) {
        this.deploymentStatus = deploymentStatus;
    }

    public Boolean getActualSuccess() {
        return actualSuccess;
    }

    public void setActualSuccess(Boolean actualSuccess) {
        this.actualSuccess = actualSuccess;
    }

    public Integer getDeploymentDurationMinutes() {
        return deploymentDurationMinutes;
    }

    public void setDeploymentDurationMinutes(Integer deploymentDurationMinutes) {
        this.deploymentDurationMinutes = deploymentDurationMinutes;
    }

    public String[] getIssuesEncountered() {
        return issuesEncountered;
    }

    public void setIssuesEncountered(String[] issuesEncountered) {
        this.issuesEncountered = issuesEncountered;
    }

    public String getIncidentSeverity() {
        return incidentSeverity;
    }

    public void setIncidentSeverity(String incidentSeverity) {
        this.incidentSeverity = incidentSeverity;
    }

    public Integer getDowntimeMinutes() {
        return downtimeMinutes;
    }

    public void setDowntimeMinutes(Integer downtimeMinutes) {
        this.downtimeMinutes = downtimeMinutes;
    }

    public String getErrorLogs() {
        return errorLogs;
    }

    public void setErrorLogs(String errorLogs) {
        this.errorLogs = errorLogs;
    }

    public Boolean getRollbackRequired() {
        return rollbackRequired;
    }

    public void setRollbackRequired(Boolean rollbackRequired) {
        this.rollbackRequired = rollbackRequired;
    }

    public String getRollbackCommit() {
        return rollbackCommit;
    }

    public void setRollbackCommit(String rollbackCommit) {
        this.rollbackCommit = rollbackCommit;
    }

    public String getResolutionDescription() {
        return resolutionDescription;
    }

    public void setResolutionDescription(String resolutionDescription) {
        this.resolutionDescription = resolutionDescription;
    }

    public LocalDateTime getDeployedAt() {
        return deployedAt;
    }

    public void setDeployedAt(LocalDateTime deployedAt) {
        this.deployedAt = deployedAt;
        if (deployedAt != null) {
            this.dayOfWeek = deployedAt.getDayOfWeek().getValue() % 7;
            this.hourOfDay = deployedAt.getHour();
        }
    }

    public String getDeployedBy() {
        return deployedBy;
    }

    public void setDeployedBy(String deployedBy) {
        this.deployedBy = deployedBy;
    }

    public Integer getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(Integer dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public Integer getHourOfDay() {
        return hourOfDay;
    }

    public void setHourOfDay(Integer hourOfDay) {
        this.hourOfDay = hourOfDay;
    }

    public Boolean getHasDatabaseChanges() {
        return hasDatabaseChanges;
    }

    public void setHasDatabaseChanges(Boolean hasDatabaseChanges) {
        this.hasDatabaseChanges = hasDatabaseChanges;
    }

    public Boolean getHasConfigChanges() {
        return hasConfigChanges;
    }

    public void setHasConfigChanges(Boolean hasConfigChanges) {
        this.hasConfigChanges = hasConfigChanges;
    }

    public Boolean getHasCriticalFiles() {
        return hasCriticalFiles;
    }

    public void setHasCriticalFiles(Boolean hasCriticalFiles) {
        this.hasCriticalFiles = hasCriticalFiles;
    }

    public PGvector getChangeEmbedding() {
        return changeEmbedding;
    }

    public void setChangeEmbedding(PGvector changeEmbedding) {
        this.changeEmbedding = changeEmbedding;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
