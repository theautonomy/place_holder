package com.example.demo.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.demo.DeploymentTrackingService;
import com.example.demo.GitHubDashboardService;
import com.example.demo.ai.BuildFailureAnalysisService;
import com.example.demo.ai.BuildFailureAnalysisService.FailureAnalysis;
import com.example.demo.ai.DeploymentRiskService;
import com.example.demo.ai.DeploymentRiskService.RiskAssessment;

import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GitHub;
import org.kohsuke.github.GitHubBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class DashboardController {

    @Value("${github.pat}")
    private String githubPat;

    @Autowired private BuildFailureAnalysisService buildFailureAnalysisService;

    @Autowired private DeploymentRiskService deploymentRiskService;

    /** Get list of repositories accessible to the user */
    @GetMapping("/repositories")
    public List<RepositoryInfo> getRepositories() throws IOException {
        GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();

        List<RepositoryInfo> repos = new ArrayList<>();
        var repositories = gitHub.getMyself().listRepositories().toList();

        for (var repo : repositories) {
            repos.add(
                    new RepositoryInfo(
                            repo.getFullName(),
                            repo.getName(),
                            repo.getDescription(),
                            repo.isPrivate()));
        }

        return repos;
    }

    /** Get workflow dashboard data for a specific repository */
    @GetMapping("/dashboard/{owner}/{repo}")
    public Map<String, Object> getDashboard(
            @PathVariable String owner,
            @PathVariable String repo,
            @RequestParam(defaultValue = "build.yml") String workflow)
            throws Exception {

        GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();
        String fullRepoName = owner + "/" + repo;

        GitHubDashboardService dashboardService = new GitHubDashboardService(gitHub, fullRepoName);

        Map<String, Object> response = new HashMap<>();

        try {
            // Quick Metrics
            var metrics = dashboardService.getDashboardMetrics(workflow);
            response.put(
                    "metrics",
                    Map.of(
                            "runsToday", metrics.runsToday,
                            "runsThisWeek", metrics.runsThisWeek,
                            "failedBuilds", metrics.failedBuilds,
                            "avgDurationSeconds", metrics.avgDurationSeconds,
                            "latestRun",
                                    metrics.latestRun != null
                                            ? Map.of(
                                                    "conclusion",
                                                            metrics.latestRun.getConclusion()
                                                                            != null
                                                                    ? metrics.latestRun
                                                                            .getConclusion()
                                                                            .toString()
                                                                    : "RUNNING",
                                                    "status",
                                                            metrics.latestRun
                                                                    .getStatus()
                                                                    .toString(),
                                                    "createdAt", metrics.latestRun.getCreatedAt(),
                                                    "url", metrics.latestRun.getHtmlUrl())
                                            : null));

            // Workflow Monitoring
            var workflowData = dashboardService.getWorkflowMonitoring(workflow);
            response.put(
                    "workflow",
                    Map.of(
                            "name", workflowData.workflowName,
                            "totalRuns", workflowData.totalRuns,
                            "successfulRuns", workflowData.successfulRuns,
                            "failedRuns", workflowData.failedRuns,
                            "inProgressRuns", workflowData.inProgressRuns,
                            "successRate", workflowData.successRate,
                            "recentRuns", convertWorkflowRuns(workflowData.recentRuns)));
        } catch (org.kohsuke.github.GHFileNotFoundException e) {
            // Workflow not found - return empty data
            response.put("error", "Workflow '" + workflow + "' not found");

            Map<String, Object> metricsMap = new HashMap<>();
            metricsMap.put("runsToday", 0);
            metricsMap.put("runsThisWeek", 0);
            metricsMap.put("failedBuilds", 0);
            metricsMap.put("avgDurationSeconds", 0.0);
            metricsMap.put("latestRun", null);
            response.put("metrics", metricsMap);

            response.put(
                    "workflow",
                    Map.of(
                            "name", workflow,
                            "totalRuns", 0,
                            "successfulRuns", 0,
                            "failedRuns", 0,
                            "inProgressRuns", 0,
                            "successRate", 0.0,
                            "recentRuns", new ArrayList<>()));
        }

        return response;
    }

    /** Get deployment tracking data for a specific repository */
    @GetMapping("/deployments/{owner}/{repo}")
    public Map<String, Object> getDeployments(@PathVariable String owner, @PathVariable String repo)
            throws Exception {

        GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();
        String fullRepoName = owner + "/" + repo;
        GHRepository repository = gitHub.getRepository(fullRepoName);

        DeploymentTrackingService deploymentService = new DeploymentTrackingService(repository);

        Map<String, Object> response = new HashMap<>();

        // Deployment Metrics
        var metrics = deploymentService.getDeploymentMetrics();
        response.put(
                "metrics",
                Map.of(
                        "totalDeployments", metrics.totalDeployments,
                        "deploymentsToday", metrics.deploymentsToday,
                        "deploymentsLast7Days", metrics.deploymentsLast7Days,
                        "avgDeploymentsPerDay", metrics.avgDeploymentsPerDay,
                        "environmentCount", metrics.environmentCount,
                        "overallSuccessRate", metrics.overallSuccessRate));

        // Deployment Tracking
        var tracking = deploymentService.getDeploymentTracking();
        List<Map<String, Object>> environments = new ArrayList<>();

        for (var env : tracking.environments) {
            Map<String, Object> envData = new HashMap<>();
            envData.put("name", env.environmentName);
            envData.put("currentStatus", env.currentStatus);
            envData.put("deploymentsLast30Days", env.deploymentsLast30Days);
            envData.put("successRate", env.successRate);
            envData.put("totalDeployments", env.totalDeployments);

            if (env.latestDeployment != null) {
                envData.put(
                        "latestDeployment",
                        Map.of(
                                "sha", env.latestDeployment.getSha().substring(0, 7),
                                "createdAt", env.latestDeployment.getCreatedAt(),
                                "creator", env.latestDeployment.getCreator().getLogin()));
            }

            environments.add(envData);
        }

        response.put("environments", environments);

        return response;
    }

    /** Get available workflows for a repository */
    @GetMapping("/workflows/{owner}/{repo}")
    public List<String> getWorkflows(@PathVariable String owner, @PathVariable String repo)
            throws IOException {

        GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();
        String fullRepoName = owner + "/" + repo;
        GHRepository repository = gitHub.getRepository(fullRepoName);

        List<String> workflowNames = new ArrayList<>();
        var workflows = repository.listWorkflows().toList();

        for (var workflow : workflows) {
            // Only include workflows that have a valid path (actual workflow files)
            // Skip GitHub-managed workflows like pages-build-deployment
            try {
                String path = workflow.getPath();
                if (path != null && path.startsWith(".github/workflows/")) {
                    // Extract filename from path (e.g., ".github/workflows/build.yml" ->
                    // "build.yml")
                    String filename = path.substring(path.lastIndexOf('/') + 1);
                    workflowNames.add(filename);
                }
            } catch (Exception e) {
                // Skip workflows that can't be accessed
                continue;
            }
        }

        return workflowNames;
    }

    /** Analyze a failed workflow run using AI */
    @PostMapping("/ai/analyze-failure")
    public Map<String, Object> analyzeFailure(@RequestBody AnalyzeFailureRequest request)
            throws Exception {

        GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();
        String fullRepoName = request.owner + "/" + request.repo;

        try {
            FailureAnalysis analysis =
                    buildFailureAnalysisService.analyzeFailure(gitHub, fullRepoName, request.runId);

            Map<String, Object> response = new HashMap<>();
            response.put("runNumber", analysis.runNumber);
            response.put("workflowName", analysis.workflowName);
            response.put("branch", analysis.branch);
            response.put("url", analysis.url);
            response.put("rootCause", analysis.rootCause);
            response.put("suggestedFixes", analysis.suggestedFixes);
            response.put("confidence", analysis.confidence);
            response.put("prevention", analysis.prevention);
            response.put("aiAnalysis", analysis.aiAnalysis);

            return response;
        } catch (IllegalArgumentException e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return errorResponse;
        }
    }

    /** Assess deployment risk using AI */
    @PostMapping("/ai/assess-deployment-risk")
    public Map<String, Object> assessDeploymentRisk(@RequestBody AssessRiskRequest request)
            throws Exception {

        GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();
        String fullRepoName = request.owner + "/" + request.repo;

        try {
            RiskAssessment assessment =
                    deploymentRiskService.assessDeploymentRisk(
                            gitHub,
                            fullRepoName,
                            request.fromCommit,
                            request.toCommit,
                            request.targetEnvironment != null
                                    ? request.targetEnvironment
                                    : "production");

            Map<String, Object> response = new HashMap<>();
            response.put("riskLevel", assessment.riskLevel);
            response.put("riskScore", assessment.riskScore);
            response.put("riskFactors", assessment.riskFactors);
            response.put("recommendations", assessment.recommendations);
            response.put("affectedComponents", assessment.affectedComponents);
            response.put("deploymentStrategy", assessment.deploymentStrategy);
            response.put("reasoning", assessment.reasoning);
            response.put("totalCommits", assessment.totalCommits);
            response.put("filesChanged", assessment.filesChanged);
            response.put("linesAdded", assessment.linesAdded);
            response.put("linesDeleted", assessment.linesDeleted);
            response.put("aiAnalysis", assessment.aiAnalysis);

            return response;
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return errorResponse;
        }
    }

    // Helper methods
    private List<Map<String, Object>> convertWorkflowRuns(
            List<org.kohsuke.github.GHWorkflowRun> runs) throws IOException {
        List<Map<String, Object>> result = new ArrayList<>();

        for (var run : runs) {
            Map<String, Object> runData = new HashMap<>();
            runData.put("runId", run.getId()); // Unique ID for API calls
            runData.put("runNumber", run.getRunNumber()); // Display number
            runData.put(
                    "conclusion",
                    run.getConclusion() != null ? run.getConclusion().toString() : null);
            runData.put("status", run.getStatus().toString());
            runData.put("branch", run.getHeadBranch());
            runData.put("createdAt", run.getCreatedAt());
            runData.put("updatedAt", run.getUpdatedAt());
            runData.put("url", run.getHtmlUrl());

            result.add(runData);
        }

        return result;
    }

    // DTOs
    public static class RepositoryInfo {
        public String fullName;
        public String name;
        public String description;
        public boolean isPrivate;

        public RepositoryInfo(String fullName, String name, String description, boolean isPrivate) {
            this.fullName = fullName;
            this.name = name;
            this.description = description;
            this.isPrivate = isPrivate;
        }
    }

    public static class AnalyzeFailureRequest {
        public String owner;
        public String repo;
        public long runId;
    }

    public static class AssessRiskRequest {
        public String owner;
        public String repo;
        public String fromCommit;
        public String toCommit;
        public String targetEnvironment; // Optional, defaults to "production"
    }
}
