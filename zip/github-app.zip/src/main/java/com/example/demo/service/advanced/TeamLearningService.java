package com.example.demo.service.advanced;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import com.example.demo.entity.BuildFailure;
import com.example.demo.repository.BuildFailureRepository;
import com.example.demo.service.rag.EmbeddingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Team Learning Service Extracts insights and patterns from team's historical data to provide
 * learning and improvement recommendations
 */
@Service
public class TeamLearningService {

    private static final Logger logger = LoggerFactory.getLogger(TeamLearningService.class);

    private final BuildFailureRepository buildFailureRepository;
    private final EmbeddingService embeddingService;

    private static final double SIMILARITY_THRESHOLD = 0.2; // Cosine distance
    private static final int RECENT_MONTHS = 6;
    private static final int MIN_OCCURRENCES_FOR_PATTERN = 3;

    public TeamLearningService(
            BuildFailureRepository buildFailureRepository, EmbeddingService embeddingService) {
        this.buildFailureRepository = buildFailureRepository;
        this.embeddingService = embeddingService;
    }

    /**
     * Analyze a specific problem and provide team-specific insights
     *
     * @param errorMessage Error message to analyze
     * @param repository Repository name
     * @return Learning insights based on team history
     */
    public LearningInsights analyzeProblem(String errorMessage, String repository) {

        logger.info("Analyzing problem for team learning insights: {}", repository);

        // Generate embedding for the error
        float[] embedding = embeddingService.generateEmbedding(errorMessage);
        String embeddingStr = embeddingService.vectorToString(embedding);

        // Find similar resolved failures
        List<BuildFailure> similarFailures =
                buildFailureRepository.findSimilarResolvedFailures(
                        embeddingStr, SIMILARITY_THRESHOLD, 20);

        if (similarFailures.isEmpty()) {
            return new LearningInsights(
                    0,
                    0.0,
                    null,
                    List.of(),
                    "No similar past occurrences found",
                    "This appears to be a novel error for your team",
                    List.of());
        }

        // Calculate statistics
        int totalOccurrences = similarFailures.size();
        double avgFixTime =
                similarFailures.stream()
                        .filter(f -> f.getTimeToFixMinutes() != null && f.getTimeToFixMinutes() > 0)
                        .mapToInt(BuildFailure::getTimeToFixMinutes)
                        .average()
                        .orElse(0.0);

        // Find most frequent fixer (expert)
        Map<String, Long> fixerCounts =
                similarFailures.stream()
                        .filter(f -> f.getFixedBy() != null && !f.getFixedBy().isEmpty())
                        .collect(
                                Collectors.groupingBy(
                                        BuildFailure::getFixedBy, Collectors.counting()));

        String mostFrequentFixer = null;
        long maxCount = 0;
        for (Map.Entry<String, Long> entry : fixerCounts.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                mostFrequentFixer = entry.getKey();
            }
        }

        // Extract all unique solutions
        List<String> allSolutions =
                similarFailures.stream()
                        .filter(f -> f.getResolutionDescription() != null)
                        .map(BuildFailure::getResolutionDescription)
                        .distinct()
                        .limit(10)
                        .collect(Collectors.toList());

        // Find common root cause
        String commonRootCause = extractCommonRootCause(similarFailures);

        // Find most effective solution
        Optional<BuildFailure> mostEffective =
                similarFailures.stream()
                        .filter(f -> f.getSolutionEffectiveness() > 0.7f && f.getTimesHelped() > 0)
                        .max(
                                Comparator.comparingDouble(
                                        f -> f.getSolutionEffectiveness() * f.getTimesHelped()));

        String typicalFix =
                mostEffective.isPresent()
                        ? mostEffective.get().getResolutionDescription()
                        : (allSolutions.isEmpty() ? null : allSolutions.get(0));

        // Generate prevention tips
        List<String> preventionTips = generatePreventionTips(similarFailures, commonRootCause);

        logger.info(
                "Found {} occurrences, avg fix time: {} minutes, expert: {}",
                totalOccurrences,
                avgFixTime,
                mostFrequentFixer);

        return new LearningInsights(
                totalOccurrences,
                avgFixTime,
                mostFrequentFixer,
                allSolutions,
                commonRootCause,
                typicalFix,
                preventionTips);
    }

    /**
     * Identify recurring error patterns across the team
     *
     * @param repository Repository name
     * @param sinceMonths How many months back to analyze
     * @return List of recurring patterns
     */
    public List<RecurringPattern> identifyRecurringPatterns(String repository, int sinceMonths) {

        logger.info("Identifying recurring patterns for repository: {}", repository);

        LocalDateTime since = LocalDateTime.now().minusMonths(sinceMonths);
        List<BuildFailure> recentFailures =
                buildFailureRepository.findByRepositoryAndFailedAtAfter(repository, since);

        if (recentFailures.size() < MIN_OCCURRENCES_FOR_PATTERN) {
            logger.info("Not enough failures to identify patterns");
            return List.of();
        }

        // Group similar failures
        Map<String, List<BuildFailure>> clusteredFailures = clusterSimilarFailures(recentFailures);

        // Convert to recurring patterns
        List<RecurringPattern> patterns = new ArrayList<>();
        for (Map.Entry<String, List<BuildFailure>> entry : clusteredFailures.entrySet()) {
            if (entry.getValue().size() >= MIN_OCCURRENCES_FOR_PATTERN) {
                List<BuildFailure> cluster = entry.getValue();

                String errorType = classifyErrorType(cluster.get(0));
                int occurrences = cluster.size();
                double avgResolutionTime =
                        cluster.stream()
                                .filter(f -> f.getTimeToFixMinutes() != null)
                                .mapToInt(BuildFailure::getTimeToFixMinutes)
                                .average()
                                .orElse(0.0);

                long resolvedCount =
                        cluster.stream().filter(f -> Boolean.TRUE.equals(f.getResolved())).count();
                double resolutionRate = (double) resolvedCount / occurrences;

                String description = cluster.get(0).getErrorMessage();
                if (description.length() > 200) {
                    description = description.substring(0, 200) + "...";
                }

                LocalDateTime firstSeen =
                        cluster.stream()
                                .map(BuildFailure::getFailedAt)
                                .min(LocalDateTime::compareTo)
                                .orElse(null);

                LocalDateTime lastSeen =
                        cluster.stream()
                                .map(BuildFailure::getFailedAt)
                                .max(LocalDateTime::compareTo)
                                .orElse(null);

                // Get most effective solution from this cluster
                String recommendedSolution =
                        cluster.stream()
                                .filter(
                                        f ->
                                                Boolean.TRUE.equals(f.getResolved())
                                                        && f.getResolutionDescription() != null
                                                        && f.getSolutionEffectiveness() > 0.7f)
                                .max(
                                        Comparator.comparingDouble(
                                                BuildFailure::getSolutionEffectiveness))
                                .map(BuildFailure::getResolutionDescription)
                                .orElse(null);

                patterns.add(
                        new RecurringPattern(
                                errorType,
                                description,
                                occurrences,
                                avgResolutionTime,
                                resolutionRate,
                                firstSeen,
                                lastSeen,
                                recommendedSolution));
            }
        }

        // Sort by occurrence count
        patterns.sort((a, b) -> Integer.compare(b.occurrences(), a.occurrences()));

        logger.info("Identified {} recurring patterns", patterns.size());
        return patterns;
    }

    /**
     * Identify team experts for different types of problems
     *
     * @param repository Repository name
     * @return Map of expertise areas to experts
     */
    public Map<String, TeamExpert> identifyTeamExperts(String repository) {

        logger.info("Identifying team experts for repository: {}", repository);

        LocalDateTime since = LocalDateTime.now().minusMonths(RECENT_MONTHS);
        List<BuildFailure> resolvedFailures =
                buildFailureRepository.findByRepositoryAndResolvedTrueAndResolvedAtAfter(
                        repository, since);

        if (resolvedFailures.isEmpty()) {
            logger.info("No resolved failures found");
            return Map.of();
        }

        // Group by error type and fixer
        Map<String, Map<String, List<BuildFailure>>> expertiseByType = new HashMap<>();

        for (BuildFailure failure : resolvedFailures) {
            if (failure.getFixedBy() == null || failure.getFixedBy().isEmpty()) {
                continue;
            }

            String errorType = classifyErrorType(failure);
            String fixer = failure.getFixedBy();

            expertiseByType
                    .computeIfAbsent(errorType, k -> new HashMap<>())
                    .computeIfAbsent(fixer, k -> new ArrayList<>())
                    .add(failure);
        }

        // Calculate expert rankings for each type
        Map<String, TeamExpert> experts = new HashMap<>();

        for (Map.Entry<String, Map<String, List<BuildFailure>>> typeEntry :
                expertiseByType.entrySet()) {
            String errorType = typeEntry.getKey();

            // Find the best expert for this error type
            TeamExpert topExpert = null;
            double topScore = 0;

            for (Map.Entry<String, List<BuildFailure>> fixerEntry :
                    typeEntry.getValue().entrySet()) {
                String fixer = fixerEntry.getKey();
                List<BuildFailure> fixes = fixerEntry.getValue();

                int fixCount = fixes.size();
                double avgEffectiveness =
                        fixes.stream()
                                .mapToDouble(BuildFailure::getSolutionEffectiveness)
                                .average()
                                .orElse(0.0);
                double avgFixTime =
                        fixes.stream()
                                .filter(f -> f.getTimeToFixMinutes() != null)
                                .mapToInt(BuildFailure::getTimeToFixMinutes)
                                .average()
                                .orElse(0.0);

                // Score = (fixCount * effectiveness) / avgFixTime
                double score = (fixCount * avgEffectiveness) / Math.max(1, avgFixTime / 60.0);

                if (score > topScore) {
                    topScore = score;
                    topExpert =
                            new TeamExpert(
                                    fixer, errorType, fixCount, avgEffectiveness, avgFixTime);
                }
            }

            if (topExpert != null) {
                experts.put(errorType, topExpert);
            }
        }

        logger.info("Identified {} experts across different error types", experts.size());
        return experts;
    }

    private String extractCommonRootCause(List<BuildFailure> failures) {
        // Look for common patterns in error messages
        Map<String, Integer> termCounts = new HashMap<>();

        for (BuildFailure failure : failures) {
            String error = failure.getErrorMessage().toLowerCase();

            // Extract key terms
            if (error.contains("null")) termCounts.merge("null pointer issues", 1, Integer::sum);
            if (error.contains("timeout")) termCounts.merge("timeout issues", 1, Integer::sum);
            if (error.contains("connection"))
                termCounts.merge("connection issues", 1, Integer::sum);
            if (error.contains("config") || error.contains("property"))
                termCounts.merge("configuration issues", 1, Integer::sum);
            if (error.contains("dependency"))
                termCounts.merge("dependency issues", 1, Integer::sum);
            if (error.contains("auth")) termCounts.merge("authentication issues", 1, Integer::sum);
            if (error.contains("database") || error.contains("sql"))
                termCounts.merge("database issues", 1, Integer::sum);
        }

        // Find most common
        return termCounts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("various technical issues");
    }

    private List<String> generatePreventionTips(
            List<BuildFailure> failures, String commonRootCause) {
        List<String> tips = new ArrayList<>();

        if (commonRootCause.contains("null")) {
            tips.add("Add null checks before accessing objects");
            tips.add("Use Optional<T> for nullable return values");
            tips.add("Enable strict null checking in your IDE");
        } else if (commonRootCause.contains("config")) {
            tips.add("Add pre-deployment configuration validation");
            tips.add("Use environment-specific configuration files");
            tips.add("Document all required configuration properties");
        } else if (commonRootCause.contains("dependency")) {
            tips.add("Lock dependency versions in pom.xml/package.json");
            tips.add("Run dependency vulnerability scans regularly");
            tips.add("Test with exact production dependencies locally");
        } else if (commonRootCause.contains("auth")) {
            tips.add("Add comprehensive authentication tests");
            tips.add("Test token expiration and renewal flows");
            tips.add("Verify permissions and roles thoroughly");
        } else if (commonRootCause.contains("database")) {
            tips.add("Test database migrations on production-like data");
            tips.add("Always have rollback scripts ready");
            tips.add("Use database versioning tools (Flyway/Liquibase)");
        } else {
            tips.add("Add comprehensive integration tests");
            tips.add("Review code changes carefully before deployment");
            tips.add("Test in staging environment first");
        }

        return tips;
    }

    private Map<String, List<BuildFailure>> clusterSimilarFailures(List<BuildFailure> failures) {
        Map<String, List<BuildFailure>> clusters = new HashMap<>();

        for (BuildFailure failure : failures) {
            // Simple clustering by error type
            String errorType = classifyErrorType(failure);
            clusters.computeIfAbsent(errorType, k -> new ArrayList<>()).add(failure);
        }

        return clusters;
    }

    private String classifyErrorType(BuildFailure failure) {
        String errorMessage = failure.getErrorMessage().toLowerCase();

        if (errorMessage.contains("nullpointer") || errorMessage.contains("null")) {
            return "NullPointerException";
        } else if (errorMessage.contains("timeout")) {
            return "Timeout";
        } else if (errorMessage.contains("authentication") || errorMessage.contains("auth")) {
            return "Authentication";
        } else if (errorMessage.contains("database") || errorMessage.contains("sql")) {
            return "Database";
        } else if (errorMessage.contains("dependency") || errorMessage.contains("import")) {
            return "Dependency";
        } else if (errorMessage.contains("test")) {
            return "TestFailure";
        } else if (errorMessage.contains("compile") || errorMessage.contains("syntax")) {
            return "Compilation";
        } else if (errorMessage.contains("config") || errorMessage.contains("property")) {
            return "Configuration";
        } else {
            return "General";
        }
    }

    /** Learning insights from team history */
    public record LearningInsights(
            int totalOccurrences,
            double averageFixTimeMinutes,
            String mostFrequentFixer,
            List<String> allSolutions,
            String commonRootCause,
            String typicalFix,
            List<String> preventionTips) {}

    /** Recurring error pattern */
    public record RecurringPattern(
            String errorType,
            String description,
            int occurrences,
            double avgResolutionTime,
            double resolutionRate,
            LocalDateTime firstSeen,
            LocalDateTime lastSeen,
            String recommendedSolution) {}

    /** Team expert for specific error type */
    public record TeamExpert(
            String name,
            String expertise,
            int fixCount,
            double avgEffectiveness,
            double avgFixTimeMinutes) {}
}
