package com.example.demo.service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.entity.DeploymentHistory;
import com.example.demo.service.rag.RAGService;

import org.kohsuke.github.GHCommit;
import org.kohsuke.github.GHCompare;
import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GitHub;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class DeploymentRiskService {

    private static final Logger logger = LoggerFactory.getLogger(DeploymentRiskService.class);

    private final ChatClient chatClient;
    private final RAGService ragService;

    public DeploymentRiskService(ChatClient.Builder chatClientBuilder, RAGService ragService) {
        this.chatClient = chatClientBuilder.build();
        this.ragService = ragService;
    }

    /** Assess deployment risk by analyzing changes between two commits */
    public RiskAssessment assessDeploymentRisk(
            GitHub gitHub,
            String repoFullName,
            String fromCommit,
            String toCommit,
            String targetEnvironment)
            throws IOException {

        logger.info(
                "Assessing deployment risk for repository: {}, from: {} to: {}, environment: {}",
                repoFullName,
                fromCommit,
                toCommit,
                targetEnvironment);

        GHRepository repository = gitHub.getRepository(repoFullName);

        // Get comparison between commits
        GHCompare comparison = repository.getCompare(fromCommit, toCommit);

        // Gather change statistics
        int totalCommits = comparison.getTotalCommits();
        var files = comparison.getFiles();
        int filesChanged = files.length;
        int additions = 0;
        int deletions = 0;

        List<String> changedFiles = new ArrayList<>();
        for (var file : files) {
            changedFiles.add(file.getFileName());
            additions += file.getLinesAdded();
            deletions += file.getLinesDeleted();
        }

        // Get commit messages
        List<String> commitMessages = new ArrayList<>();
        for (GHCommit commit : comparison.getCommits()) {
            try {
                var shortInfo = commit.getCommitShortInfo();
                if (shortInfo != null && shortInfo.getMessage() != null) {
                    commitMessages.add(shortInfo.getMessage());
                }
            } catch (Exception e) {
                // Skip commits that can't be accessed
            }
        }

        // Analyze file types and patterns
        boolean hasDatabaseChanges =
                changedFiles.stream()
                        .anyMatch(
                                f ->
                                        f.contains("migration")
                                                || f.contains("schema")
                                                || f.endsWith(".sql"));
        boolean hasConfigChanges =
                changedFiles.stream()
                        .anyMatch(
                                f ->
                                        f.contains("config")
                                                || f.endsWith(".properties")
                                                || f.endsWith(".yml")
                                                || f.endsWith(".yaml"));
        boolean hasCriticalFiles =
                changedFiles.stream()
                        .anyMatch(
                                f ->
                                        f.contains("Auth")
                                                || f.contains("Security")
                                                || f.contains("Payment"));

        // *** NEW: Query RAG for similar past deployments ***
        logger.info("Querying RAG for similar deployments");
        List<DeploymentHistory> similarDeployments =
                ragService.findSimilarDeployments(
                        changedFiles.toArray(new String[0]),
                        commitMessages.toArray(new String[0]),
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles);

        List<DeploymentHistory> similarSuccessful =
                ragService.findSimilarSuccessfulDeployments(
                        changedFiles.toArray(new String[0]),
                        commitMessages.toArray(new String[0]),
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles);

        List<DeploymentHistory> similarFailed =
                ragService.findSimilarFailedDeployments(
                        changedFiles.toArray(new String[0]),
                        commitMessages.toArray(new String[0]),
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles);

        // *** NEW: Get deployment time statistics ***
        RAGService.DeploymentTimeStatistics timeStats =
                ragService.getDeploymentTimeStatistics(repoFullName, targetEnvironment);
        RAGService.DeploymentStatistics overallStats =
                ragService.getDeploymentStatistics(repoFullName, targetEnvironment);

        // *** NEW: Build context from similar deployments ***
        String ragContext =
                buildRAGContext(
                        similarDeployments,
                        similarSuccessful,
                        similarFailed,
                        timeStats,
                        overallStats);

        // Build AI prompt with RAG context
        String promptText =
                String.format(
                        """
                You are an expert DevOps engineer assessing deployment risk.
                You have access to historical deployment data from this organization.

                Deployment Information:
                - Repository: %s
                - From Commit: %s
                - To Commit: %s
                - Target Environment: %s

                Change Statistics:
                - Total Commits: %d
                - Files Changed: %d
                - Lines Added: %d
                - Lines Deleted: %d
                - Has Database Changes: %s
                - Has Config Changes: %s
                - Has Critical Files (Auth/Security/Payment): %s

                Changed Files:
                %s

                Recent Commit Messages:
                %s

                %s

                Please assess the deployment risk and provide:

                1. RISK LEVEL: Overall risk level (low/medium/high/critical)
                2. RISK SCORE: Numerical score from 0-10 (0=no risk, 10=critical risk)
                3. RISK FACTORS: Key factors contributing to the risk
                4. RECOMMENDATIONS: Specific recommendations for this deployment
                5. AFFECTED COMPONENTS: Which parts of the system are affected
                6. DEPLOYMENT STRATEGY: Recommended deployment approach (standard/canary/blue-green/staged)

                Format your response as JSON with these fields:
                - riskLevel: "low" or "medium" or "high" or "critical"
                - riskScore: number between 0-10
                - riskFactors: array of strings
                - recommendations: array of strings
                - affectedComponents: array of strings
                - deploymentStrategy: string
                - reasoning: string explaining the assessment
                """,
                        repoFullName,
                        fromCommit.substring(0, Math.min(7, fromCommit.length())),
                        toCommit.substring(0, Math.min(7, toCommit.length())),
                        targetEnvironment,
                        totalCommits,
                        filesChanged,
                        additions,
                        deletions,
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles,
                        String.join("\n", changedFiles.stream().limit(20).toList()),
                        String.join("\n", commitMessages.stream().limit(10).toList()),
                        ragContext);

        // Call AI to analyze
        logger.info("Calling AI for risk assessment with RAG context");
        String aiResponse = chatClient.prompt().user(promptText).call().content();

        // Parse assessment
        RiskAssessment assessment =
                parseRiskAssessment(aiResponse, totalCommits, filesChanged, additions, deletions);

        // *** NEW: Add historical context to assessment ***
        assessment.similarDeploymentsCount = similarDeployments.size();
        assessment.hasHistoricalData = !similarDeployments.isEmpty();
        if (!similarDeployments.isEmpty()) {
            long successCount =
                    similarDeployments.stream()
                            .filter(d -> Boolean.TRUE.equals(d.getActualSuccess()))
                            .count();
            assessment.historicalSuccessRate = (double) successCount / similarDeployments.size();
        }

        // *** NEW: Store deployment prediction in RAG for future learning ***
        logger.info("Storing deployment prediction in RAG database");
        DeploymentHistory deployment =
                new DeploymentHistory(
                        repoFullName, fromCommit, toCommit, targetEnvironment, LocalDateTime.now());
        deployment.setTotalCommits(totalCommits);
        deployment.setFilesChanged(filesChanged);
        deployment.setLinesAdded(additions);
        deployment.setLinesDeleted(deletions);
        deployment.setChangedFiles(changedFiles.toArray(new String[0]));
        deployment.setCommitMessages(commitMessages.toArray(new String[0]));
        deployment.setHasDatabaseChanges(hasDatabaseChanges);
        deployment.setHasConfigChanges(hasConfigChanges);
        deployment.setHasCriticalFiles(hasCriticalFiles);
        deployment.setPredictedRiskLevel(assessment.riskLevel);
        deployment.setPredictedRiskScore(assessment.riskScore);
        deployment.setAiRiskFactors(
                assessment.riskFactors != null
                        ? assessment.riskFactors.toArray(new String[0])
                        : new String[0]);
        deployment.setAiRecommendations(
                assessment.recommendations != null
                        ? assessment.recommendations.toArray(new String[0])
                        : new String[0]);
        deployment.setDeploymentStatus("pending");
        deployment.setDeployedBy("system"); // Could be set from current user context

        DeploymentHistory storedDeployment = ragService.storeDeployment(deployment);
        assessment.deploymentId = storedDeployment.getId();

        logger.info(
                "Assessment complete with {} similar deployments found", similarDeployments.size());
        return assessment;
    }

    /** Parse AI response into structured RiskAssessment object */
    private RiskAssessment parseRiskAssessment(
            String aiResponse, int commits, int files, int additions, int deletions) {

        RiskAssessment assessment = new RiskAssessment();
        assessment.totalCommits = commits;
        assessment.filesChanged = files;
        assessment.linesAdded = additions;
        assessment.linesDeleted = deletions;
        assessment.aiAnalysis = aiResponse;

        // Try to extract structured information from AI response
        assessment.riskLevel = extractJsonField(aiResponse, "riskLevel");
        assessment.deploymentStrategy = extractJsonField(aiResponse, "deploymentStrategy");
        assessment.reasoning = extractJsonField(aiResponse, "reasoning");

        // Try to parse risk score
        try {
            String scoreStr = extractJsonField(aiResponse, "riskScore");
            assessment.riskScore = Double.parseDouble(scoreStr.replaceAll("[^0-9.]", ""));
        } catch (Exception e) {
            // Default based on risk level
            assessment.riskScore =
                    switch (assessment.riskLevel.toLowerCase()) {
                        case "critical" -> 9.0;
                        case "high" -> 7.0;
                        case "medium" -> 5.0;
                        default -> 2.0;
                    };
        }

        // Extract arrays (simplified - in production use proper JSON parsing)
        assessment.riskFactors = extractArrayField(aiResponse, "riskFactors");
        assessment.recommendations = extractArrayField(aiResponse, "recommendations");
        assessment.affectedComponents = extractArrayField(aiResponse, "affectedComponents");

        // Provide defaults if extraction failed
        if (assessment.riskFactors.isEmpty()) {
            assessment.riskFactors.add("See AI analysis for detailed risk factors");
        }
        if (assessment.recommendations.isEmpty()) {
            assessment.recommendations.add("Review the AI analysis below for recommendations");
        }

        return assessment;
    }

    /** Simple JSON field extraction */
    private String extractJsonField(String json, String fieldName) {
        try {
            String pattern = "\"" + fieldName + "\"\\s*:\\s*\"([^\"]+)\"";
            java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                return m.group(1);
            }
        } catch (Exception e) {
            // Ignore
        }
        return "Not specified";
    }

    /** Extract array field from JSON (simplified) */
    private List<String> extractArrayField(String json, String fieldName) {
        List<String> result = new ArrayList<>();
        try {
            // Look for pattern: "fieldName": ["item1", "item2"]
            String pattern = "\"" + fieldName + "\"\\s*:\\s*\\[(.*?)\\]";
            java.util.regex.Pattern p =
                    java.util.regex.Pattern.compile(pattern, java.util.regex.Pattern.DOTALL);
            java.util.regex.Matcher m = p.matcher(json);
            if (m.find()) {
                String arrayContent = m.group(1);
                // Extract quoted strings
                java.util.regex.Pattern itemPattern =
                        java.util.regex.Pattern.compile("\"([^\"]+)\"");
                java.util.regex.Matcher itemMatcher = itemPattern.matcher(arrayContent);
                while (itemMatcher.find()) {
                    result.add(itemMatcher.group(1));
                }
            }
        } catch (Exception e) {
            // Ignore
        }
        return result;
    }

    /** Build RAG context from similar deployments */
    private String buildRAGContext(
            List<DeploymentHistory> similarDeployments,
            List<DeploymentHistory> similarSuccessful,
            List<DeploymentHistory> similarFailed,
            RAGService.DeploymentTimeStatistics timeStats,
            RAGService.DeploymentStatistics overallStats) {

        if (similarDeployments.isEmpty() && overallStats.totalDeployments() == 0) {
            return "HISTORICAL CONTEXT:\nNo historical deployment data found. This appears to be the first deployment for this repository/environment.";
        }

        StringBuilder context = new StringBuilder();
        context.append("HISTORICAL CONTEXT:\n\n");

        // Overall statistics
        if (overallStats.totalDeployments() > 0) {
            context.append(
                    String.format(
                            "Overall Deployment Statistics:\n"
                                    + "- Total Deployments: %d\n"
                                    + "- Success Rate: %.1f%%\n"
                                    + "- Average Duration: %.0f minutes\n\n",
                            overallStats.totalDeployments(),
                            overallStats.successRate() * 100,
                            overallStats.averageDurationMinutes()));
        }

        // Similar deployments analysis
        if (!similarDeployments.isEmpty()) {
            long successCount =
                    similarDeployments.stream()
                            .filter(d -> Boolean.TRUE.equals(d.getActualSuccess()))
                            .count();
            double successRate = (double) successCount / similarDeployments.size();

            context.append(
                    String.format(
                            "Similar Past Deployments: %d found\n"
                                    + "- Success Rate: %.1f%% (%d succeeded, %d failed)\n\n",
                            similarDeployments.size(),
                            successRate * 100,
                            successCount,
                            similarDeployments.size() - successCount));

            // Show a few examples
            int count = 1;
            for (DeploymentHistory deployment : similarDeployments.stream().limit(3).toList()) {
                context.append(String.format("Similar Deployment #%d:\n", count++));
                context.append(String.format("  - Status: %s\n", deployment.getDeploymentStatus()));
                if (deployment.getActualSuccess() != null) {
                    context.append(
                            String.format(
                                    "  - Outcome: %s\n",
                                    deployment.getActualSuccess() ? "SUCCESS" : "FAILED"));
                }
                if (deployment.getDeploymentDurationMinutes() != null) {
                    context.append(
                            String.format(
                                    "  - Duration: %d minutes\n",
                                    deployment.getDeploymentDurationMinutes()));
                }
                if (deployment.getIssuesEncountered() != null
                        && deployment.getIssuesEncountered().length > 0) {
                    context.append(
                            String.format(
                                    "  - Issues: %s\n",
                                    String.join(", ", deployment.getIssuesEncountered())));
                }
                context.append("\n");
            }
        }

        // Similar failed deployments (warnings)
        if (!similarFailed.isEmpty()) {
            context.append(
                    String.format(
                            "⚠️ WARNING: Found %d similar deployments that FAILED:\n",
                            similarFailed.size()));
            for (DeploymentHistory deployment : similarFailed.stream().limit(2).toList()) {
                if (deployment.getIssuesEncountered() != null
                        && deployment.getIssuesEncountered().length > 0) {
                    context.append(
                            String.format(
                                    "  - Issues encountered: %s\n",
                                    String.join(", ", deployment.getIssuesEncountered())));
                }
                if (deployment.getResolutionDescription() != null) {
                    context.append(
                            String.format(
                                    "  - Resolution: %s\n", deployment.getResolutionDescription()));
                }
            }
            context.append("\n");
        }

        // Deployment timing recommendations
        Object[] optimalTime = timeStats.getOptimalTime();
        if (optimalTime != null) {
            String[] dayNames = {
                "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
            };
            int day = (Integer) optimalTime[0];
            int hour = (Integer) optimalTime[1];
            double rate = (Double) optimalTime[2];

            context.append("Deployment Timing Analysis:\n");
            context.append(
                    String.format(
                            "- Optimal Time: %s at %02d:00 (%.1f%% success rate)\n",
                            dayNames[day], hour, rate * 100));

            // Check current time
            LocalDateTime now = LocalDateTime.now();
            int currentDay = now.getDayOfWeek().getValue() % 7;
            int currentHour = now.getHour();
            Double currentRate = timeStats.getSuccessRate(currentDay, currentHour);
            if (currentRate != null) {
                context.append(
                        String.format(
                                "- Current Time (%s %02d:00): %.1f%% success rate\n",
                                dayNames[currentDay], currentHour, currentRate * 100));
            }
            context.append("\n");
        }

        context.append(
                "Use this historical data to inform your risk assessment and provide data-driven recommendations.\n");
        return context.toString();
    }

    /** DTO for risk assessment results */
    public static class RiskAssessment {
        public String riskLevel; // low, medium, high, critical
        public double riskScore; // 0-10
        public List<String> riskFactors;
        public List<String> recommendations;
        public List<String> affectedComponents;
        public String deploymentStrategy;
        public String reasoning;

        // Change statistics
        public int totalCommits;
        public int filesChanged;
        public int linesAdded;
        public int linesDeleted;

        // Full AI response
        public String aiAnalysis;

        // RAG enhancements
        public java.util.UUID deploymentId; // ID of stored deployment
        public int similarDeploymentsCount; // Number of similar past deployments
        public boolean hasHistoricalData; // Whether historical data was available
        public double historicalSuccessRate; // Success rate of similar deployments
    }
}
