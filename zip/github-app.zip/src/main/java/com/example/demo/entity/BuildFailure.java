package com.example.demo.entity;

import java.time.LocalDateTime;
import java.util.UUID;

import com.pgvector.PGvector;

import org.hibernate.annotations.Type;

import jakarta.persistence.*;

@Entity
@Table(name = "build_failures")
public class BuildFailure {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    // Build Information
    @Column(nullable = false)
    private String repository;

    @Column(name = "workflow_name", nullable = false)
    private String workflowName;

    @Column(name = "run_id", nullable = false)
    private Long runId;

    @Column(name = "run_number", nullable = false)
    private Integer runNumber;

    private String branch;

    @Column(name = "commit_sha", length = 40)
    private String commitSha;

    // Error Details
    @Column(name = "error_type", length = 100)
    private String errorType;

    @Column(name = "error_message", nullable = false, columnDefinition = "TEXT")
    private String errorMessage;

    @Column(name = "error_stacktrace", columnDefinition = "TEXT")
    private String errorStacktrace;

    @Column(name = "failed_step")
    private String failedStep;

    // Temporal Data
    @Column(name = "failed_at", nullable = false)
    private LocalDateTime failedAt;

    // Resolution Information
    @Column(nullable = false)
    private Boolean resolved = false;

    @Column(name = "resolution_commit", length = 40)
    private String resolutionCommit;

    @Column(name = "resolution_description", columnDefinition = "TEXT")
    private String resolutionDescription;

    @Column(name = "resolution_code_snippet", columnDefinition = "TEXT")
    private String resolutionCodeSnippet;

    @Column(name = "time_to_fix_minutes")
    private Integer timeToFixMinutes;

    @Column(name = "fixed_by", length = 100)
    private String fixedBy;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    // Effectiveness Tracking
    @Column(name = "solution_effectiveness")
    private Float solutionEffectiveness = 0.0f;

    @Column(name = "times_helped")
    private Integer timesHelped = 0;

    // AI Context
    @Column(name = "ai_analysis", columnDefinition = "TEXT")
    private String aiAnalysis;

    @Column(name = "ai_confidence", length = 20)
    private String aiConfidence;

    // Vector Embedding
    @Type(VectorType.class)
    @Column(name = "error_embedding", columnDefinition = "vector(1536)")
    private PGvector errorEmbedding;

    // Metadata
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // Constructors
    public BuildFailure() {}

    public BuildFailure(
            String repository,
            String workflowName,
            Long runId,
            Integer runNumber,
            String errorMessage) {
        this.repository = repository;
        this.workflowName = workflowName;
        this.runId = runId;
        this.runNumber = runNumber;
        this.errorMessage = errorMessage;
        this.failedAt = LocalDateTime.now();
    }

    // Getters and Setters
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    public String getWorkflowName() {
        return workflowName;
    }

    public void setWorkflowName(String workflowName) {
        this.workflowName = workflowName;
    }

    public Long getRunId() {
        return runId;
    }

    public void setRunId(Long runId) {
        this.runId = runId;
    }

    public Integer getRunNumber() {
        return runNumber;
    }

    public void setRunNumber(Integer runNumber) {
        this.runNumber = runNumber;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getCommitSha() {
        return commitSha;
    }

    public void setCommitSha(String commitSha) {
        this.commitSha = commitSha;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorStacktrace() {
        return errorStacktrace;
    }

    public void setErrorStacktrace(String errorStacktrace) {
        this.errorStacktrace = errorStacktrace;
    }

    public String getFailedStep() {
        return failedStep;
    }

    public void setFailedStep(String failedStep) {
        this.failedStep = failedStep;
    }

    public LocalDateTime getFailedAt() {
        return failedAt;
    }

    public void setFailedAt(LocalDateTime failedAt) {
        this.failedAt = failedAt;
    }

    public Boolean getResolved() {
        return resolved;
    }

    public void setResolved(Boolean resolved) {
        this.resolved = resolved;
    }

    public String getResolutionCommit() {
        return resolutionCommit;
    }

    public void setResolutionCommit(String resolutionCommit) {
        this.resolutionCommit = resolutionCommit;
    }

    public String getResolutionDescription() {
        return resolutionDescription;
    }

    public void setResolutionDescription(String resolutionDescription) {
        this.resolutionDescription = resolutionDescription;
    }

    public String getResolutionCodeSnippet() {
        return resolutionCodeSnippet;
    }

    public void setResolutionCodeSnippet(String resolutionCodeSnippet) {
        this.resolutionCodeSnippet = resolutionCodeSnippet;
    }

    public Integer getTimeToFixMinutes() {
        return timeToFixMinutes;
    }

    public void setTimeToFixMinutes(Integer timeToFixMinutes) {
        this.timeToFixMinutes = timeToFixMinutes;
    }

    public String getFixedBy() {
        return fixedBy;
    }

    public void setFixedBy(String fixedBy) {
        this.fixedBy = fixedBy;
    }

    public LocalDateTime getResolvedAt() {
        return resolvedAt;
    }

    public void setResolvedAt(LocalDateTime resolvedAt) {
        this.resolvedAt = resolvedAt;
    }

    public Float getSolutionEffectiveness() {
        return solutionEffectiveness;
    }

    public void setSolutionEffectiveness(Float solutionEffectiveness) {
        this.solutionEffectiveness = solutionEffectiveness;
    }

    public Integer getTimesHelped() {
        return timesHelped;
    }

    public void setTimesHelped(Integer timesHelped) {
        this.timesHelped = timesHelped;
    }

    public String getAiAnalysis() {
        return aiAnalysis;
    }

    public void setAiAnalysis(String aiAnalysis) {
        this.aiAnalysis = aiAnalysis;
    }

    public String getAiConfidence() {
        return aiConfidence;
    }

    public void setAiConfidence(String aiConfidence) {
        this.aiConfidence = aiConfidence;
    }

    public PGvector getErrorEmbedding() {
        return errorEmbedding;
    }

    public void setErrorEmbedding(PGvector errorEmbedding) {
        this.errorEmbedding = errorEmbedding;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
