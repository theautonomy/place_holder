package com.example.demo.rag.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import com.example.demo.rag.entity.BuildFailure;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BuildFailureRepository extends JpaRepository<BuildFailure, UUID> {

    /**
     * Find similar build failures using vector similarity search Uses cosine distance - lower
     * distance means more similar
     *
     * @param embedding The vector embedding to compare against
     * @param threshold Maximum distance threshold (0.0 = identical, 2.0 = opposite)
     * @param limit Maximum number of results to return
     * @return List of similar build failures ordered by similarity
     */
    @Query(
            value =
                    """
        SELECT * FROM build_failures
        WHERE error_embedding IS NOT NULL
        AND (error_embedding <=> CAST(:embedding AS vector)) < :threshold
        ORDER BY error_embedding <=> CAST(:embedding AS vector)
        LIMIT :limit
        """,
            nativeQuery = true)
    List<BuildFailure> findSimilarFailures(
            @Param("embedding") String embedding,
            @Param("threshold") double threshold,
            @Param("limit") int limit);

    /**
     * Find similar resolved failures (useful for finding known solutions)
     *
     * @param embedding The vector embedding to compare against
     * @param threshold Maximum distance threshold
     * @param limit Maximum number of results to return
     * @return List of similar resolved failures ordered by similarity
     */
    @Query(
            value =
                    """
        SELECT * FROM build_failures
        WHERE error_embedding IS NOT NULL
        AND resolved = true
        AND resolution_description IS NOT NULL
        AND (error_embedding <=> CAST(:embedding AS vector)) < :threshold
        ORDER BY error_embedding <=> CAST(:embedding AS vector)
        LIMIT :limit
        """,
            nativeQuery = true)
    List<BuildFailure> findSimilarResolvedFailures(
            @Param("embedding") String embedding,
            @Param("threshold") double threshold,
            @Param("limit") int limit);

    /**
     * Find most effective solutions for similar failures Filters by solution effectiveness and
     * times helped
     *
     * @param embedding The vector embedding to compare against
     * @param minEffectiveness Minimum solution effectiveness score (0.0 - 1.0)
     * @param minTimesHelped Minimum number of times the solution has helped
     * @param limit Maximum number of results to return
     * @return List of effective solutions ordered by similarity
     */
    @Query(
            value =
                    """
        SELECT * FROM build_failures
        WHERE error_embedding IS NOT NULL
        AND resolved = true
        AND solution_effectiveness >= :minEffectiveness
        AND times_helped >= :minTimesHelped
        AND resolution_description IS NOT NULL
        ORDER BY error_embedding <=> CAST(:embedding AS vector)
        LIMIT :limit
        """,
            nativeQuery = true)
    List<BuildFailure> findEffectiveSolutions(
            @Param("embedding") String embedding,
            @Param("minEffectiveness") float minEffectiveness,
            @Param("minTimesHelped") int minTimesHelped,
            @Param("limit") int limit);

    // Standard JPA query methods

    /** Find all failures for a specific repository */
    List<BuildFailure> findByRepositoryOrderByFailedAtDesc(String repository);

    /** Find all unresolved failures */
    List<BuildFailure> findByResolvedFalseOrderByFailedAtDesc();

    /** Find all unresolved failures for a specific repository */
    List<BuildFailure> findByRepositoryAndResolvedFalseOrderByFailedAtDesc(String repository);

    /** Find failures by workflow name */
    List<BuildFailure> findByWorkflowNameOrderByFailedAtDesc(String workflowName);

    /** Find failures by error type */
    List<BuildFailure> findByErrorTypeOrderByFailedAtDesc(String errorType);

    /** Find failures within a time range */
    List<BuildFailure> findByFailedAtBetweenOrderByFailedAtDesc(
            LocalDateTime startDate, LocalDateTime endDate);

    /** Find resolved failures by who fixed them */
    List<BuildFailure> findByFixedByOrderByResolvedAtDesc(String fixedBy);

    /** Find failures by run ID */
    BuildFailure findByRunId(Long runId);

    /** Count unresolved failures for a repository */
    long countByRepositoryAndResolvedFalse(String repository);

    /** Count total failures for a repository */
    long countByRepository(String repository);

    /** Get average time to fix for resolved failures */
    @Query(
            "SELECT AVG(b.timeToFixMinutes) FROM BuildFailure b WHERE b.resolved = true AND b.timeToFixMinutes IS NOT NULL")
    Double getAverageTimeToFix();

    /** Get average time to fix for a specific repository */
    @Query(
            "SELECT AVG(b.timeToFixMinutes) FROM BuildFailure b WHERE b.repository = :repository AND b.resolved = true AND b.timeToFixMinutes IS NOT NULL")
    Double getAverageTimeToFixByRepository(@Param("repository") String repository);

    /** Find recent failures (last N days) */
    @Query("SELECT b FROM BuildFailure b WHERE b.failedAt >= :since ORDER BY b.failedAt DESC")
    List<BuildFailure> findRecentFailures(@Param("since") LocalDateTime since);

    /** Find failures that took longest to fix */
    List<BuildFailure> findTop10ByResolvedTrueOrderByTimeToFixMinutesDesc();

    /** Find most helpful solutions (sorted by times helped) */
    @Query(
            "SELECT b FROM BuildFailure b WHERE b.resolved = true AND b.timesHelped > 0 ORDER BY b.timesHelped DESC, b.solutionEffectiveness DESC")
    List<BuildFailure> findMostHelpfulSolutions();
}
