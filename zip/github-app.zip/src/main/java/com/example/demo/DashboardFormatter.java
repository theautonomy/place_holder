package com.example.demo;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.kohsuke.github.*;

public class DashboardFormatter {

    private static final DateTimeFormatter DATE_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());

    /** Print dashboard header */
    public static void printHeader(String repositoryName) {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("  DEVOPS DASHBOARD - " + repositoryName.toUpperCase());
        System.out.println("  " + DATE_FORMATTER.format(Instant.now()));
        System.out.println("=".repeat(80) + "\n");
    }

    /** Print quick metrics overview */
    public static void printQuickMetrics(GitHubDashboardService.DashboardMetrics metrics)
            throws Exception {
        System.out.println("╔" + "═".repeat(78) + "╗");
        System.out.println("║" + centerText("QUICK METRICS", 78) + "║");
        System.out.println("╠" + "═".repeat(78) + "╣");

        String latestStatus = "N/A";
        String latestTime = "N/A";
        if (metrics.latestRun != null) {
            String conclusion =
                    metrics.latestRun.getConclusion() != null
                            ? metrics.latestRun.getConclusion().toString()
                            : "RUNNING";
            latestStatus = getStatusIcon(conclusion) + " " + conclusion.toUpperCase();
            latestTime = formatTimeAgo(metrics.latestRun.getCreatedAt());
        }

        System.out.println(
                "║  Latest Build: "
                        + padRight(latestStatus, 30)
                        + "│  Time: "
                        + padRight(latestTime, 29)
                        + "║");
        System.out.println(
                "║  Runs Today: "
                        + padRight(String.valueOf(metrics.runsToday), 32)
                        + "│  This Week: "
                        + padRight(String.valueOf(metrics.runsThisWeek), 26)
                        + "║");
        System.out.println(
                "║  Failed Builds: "
                        + padRight(String.valueOf(metrics.failedBuilds), 29)
                        + "│  Avg Duration: "
                        + padRight(formatDuration(metrics.avgDurationSeconds), 23)
                        + "║");

        // Deployment times
        if (!metrics.lastDeploymentByEnv.isEmpty()) {
            System.out.println("╠" + "═".repeat(78) + "╣");
            System.out.println("║  Last Deployments:" + " ".repeat(59) + "║");
            for (Map.Entry<String, Date> entry : metrics.lastDeploymentByEnv.entrySet()) {
                String env = padRight("    " + entry.getKey().toUpperCase() + ":", 25);
                String time = formatTimeAgo(entry.getValue());
                System.out.println("║  " + env + padRight(time, 51) + "║");
            }
        }

        System.out.println("╚" + "═".repeat(78) + "╝\n");
    }

    /** Print workflow monitoring section */
    public static void printWorkflowMonitoring(GitHubDashboardService.WorkflowMonitoringData data)
            throws Exception {
        System.out.println("┌" + "─".repeat(78) + "┐");
        System.out.println("│" + centerText("WORKFLOW: " + data.workflowName, 78) + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        // Statistics
        System.out.println(
                "│  Total Runs: "
                        + padRight(String.valueOf(data.totalRuns), 15)
                        + "Success: "
                        + padRight(String.valueOf(data.successfulRuns), 10)
                        + "Failed: "
                        + padRight(String.valueOf(data.failedRuns), 10)
                        + "In Progress: "
                        + padRight(String.valueOf(data.inProgressRuns), 10)
                        + "│");
        System.out.println(
                "│  Success Rate: "
                        + padRight(String.format("%.1f%%", data.successRate), 61)
                        + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        // Recent runs header
        System.out.println(
                "│  "
                        + padRight("Run #", 8)
                        + padRight("Status", 15)
                        + padRight("Branch", 20)
                        + padRight("Time", 20)
                        + padRight("Duration", 13)
                        + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        // Recent runs
        for (GHWorkflowRun run : data.recentRuns) {
            String runNum = "#" + run.getRunNumber();
            String conclusionStr =
                    run.getConclusion() != null
                            ? run.getConclusion().toString()
                            : run.getStatus().toString();
            String status = getStatusIcon(conclusionStr) + " " + conclusionStr;
            String branch = run.getHeadBranch();
            String time = formatTimeAgo(run.getCreatedAt());
            String duration = calculateDuration(run);

            System.out.println(
                    "│  "
                            + padRight(runNum, 8)
                            + padRight(status, 15)
                            + padRight(truncate(branch, 18), 20)
                            + padRight(time, 20)
                            + padRight(duration, 13)
                            + "│");
        }

        System.out.println("└" + "─".repeat(78) + "┘\n");
    }

    /** Print deployment status section */
    public static void printDeploymentStatus(
            List<GitHubDashboardService.DeploymentStatus> deployments) {
        if (deployments.isEmpty()) {
            return;
        }

        System.out.println("┌" + "─".repeat(78) + "┐");
        System.out.println("│" + centerText("DEPLOYMENT STATUS", 78) + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        System.out.println(
                "│  "
                        + padRight("Environment", 20)
                        + padRight("Status", 15)
                        + padRight("Commit", 12)
                        + padRight("Deployed", 29)
                        + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        for (GitHubDashboardService.DeploymentStatus deployment : deployments) {
            String env = deployment.environment.toUpperCase();
            String status = getDeploymentStatusIcon(deployment.status) + " " + deployment.status;
            String commit =
                    deployment.commitSha.substring(0, Math.min(7, deployment.commitSha.length()));
            String time = formatTimeAgo(deployment.deployedAt);

            System.out.println(
                    "│  "
                            + padRight(env, 20)
                            + padRight(status, 15)
                            + padRight(commit, 12)
                            + padRight(time, 29)
                            + "│");
        }

        System.out.println("└" + "─".repeat(78) + "┘\n");
    }

    /** Print commit diff section */
    public static void printCommitDiff(GitHubDashboardService.CommitDiffData diffData)
            throws Exception {
        if (diffData == null) {
            return;
        }

        System.out.println("┌" + "─".repeat(78) + "┐");
        System.out.println("│" + centerText("LATEST BUILD COMMIT DIFF", 78) + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        // Latest commit
        System.out.println(
                "│  Latest: "
                        + diffData.latestCommit.getSHA1().substring(0, 7)
                        + " ".repeat(63)
                        + "│");
        System.out.println(
                "│    "
                        + padRight(
                                truncate(
                                        diffData.latestCommit.getCommitShortInfo().getMessage(),
                                        72),
                                74)
                        + "│");
        System.out.println(
                "│    Author: "
                        + padRight(
                                diffData.latestCommit.getCommitShortInfo().getAuthor().getName(),
                                64)
                        + "│");

        // Parent commit
        System.out.println("│  " + " ".repeat(76) + "│");
        System.out.println(
                "│  Parent: "
                        + diffData.parentCommit.getSHA1().substring(0, 7)
                        + " ".repeat(63)
                        + "│");
        System.out.println(
                "│    "
                        + padRight(
                                truncate(
                                        diffData.parentCommit.getCommitShortInfo().getMessage(),
                                        72),
                                74)
                        + "│");

        System.out.println("├" + "─".repeat(78) + "┤");

        // Files changed
        var files = diffData.compareResult.getFiles();
        System.out.println("│  Files Changed: " + files.length + " ".repeat(59) + "│");

        for (int i = 0; i < Math.min(5, files.length); i++) {
            var file = files[i];
            String fileName = truncate(file.getFileName(), 50);
            String changes = "+" + file.getLinesAdded() + " -" + file.getLinesDeleted();

            System.out.println("│    " + padRight(fileName, 52) + padRight(changes, 22) + "│");
        }

        if (files.length > 5) {
            System.out.println(
                    "│    ... and " + (files.length - 5) + " more files" + " ".repeat(54) + "│");
        }

        System.out.println("└" + "─".repeat(78) + "┘\n");
    }

    // Helper methods

    private static String getStatusIcon(String conclusion) {
        if (conclusion == null) return "⏳";
        return switch (conclusion.toLowerCase()) {
            case "success" -> "✓";
            case "failure" -> "✗";
            case "cancelled" -> "⊘";
            case "skipped" -> "⊝";
            default -> "•";
        };
    }

    private static String getDeploymentStatusIcon(String status) {
        if (status == null) return "•";
        return switch (status.toLowerCase()) {
            case "success" -> "✓";
            case "failure", "error" -> "✗";
            case "in_progress", "pending", "queued" -> "⏳";
            default -> "•";
        };
    }

    private static String formatTimeAgo(Date date) {
        if (date == null) return "N/A";

        Instant instant = date.toInstant();
        Duration duration = Duration.between(instant, Instant.now());

        long seconds = duration.getSeconds();
        if (seconds < 60) return seconds + "s ago";
        if (seconds < 3600) return (seconds / 60) + "m ago";
        if (seconds < 86400) return (seconds / 3600) + "h ago";
        return (seconds / 86400) + "d ago";
    }

    private static String formatDuration(double seconds) {
        if (seconds == 0) return "N/A";

        long s = (long) seconds;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m " + (s % 60) + "s";
        return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
    }

    private static String calculateDuration(GHWorkflowRun run) throws Exception {
        if (run.getUpdatedAt() == null || run.getCreatedAt() == null) {
            return "N/A";
        }

        Duration duration =
                Duration.between(run.getCreatedAt().toInstant(), run.getUpdatedAt().toInstant());

        return formatDuration(duration.getSeconds());
    }

    private static String padRight(String text, int length) {
        if (text.length() >= length) return text.substring(0, length);
        return text + " ".repeat(length - text.length());
    }

    private static String centerText(String text, int width) {
        int padding = (width - text.length()) / 2;
        int rightPadding = width - text.length() - padding;
        return " ".repeat(Math.max(0, padding)) + text + " ".repeat(Math.max(0, rightPadding));
    }

    private static String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + "...";
    }
}
