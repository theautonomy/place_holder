package com.example.demo.config;

import org.kohsuke.github.GHRepository;
import org.kohsuke.github.GitHub;
import org.kohsuke.github.GitHubBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(99)
public class DashboardCompletionRunner implements CommandLineRunner {

    @Value("${github.pat}")
    private String githubPat;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("==============================");
        System.out.println("File Diff Between 2 Workflow builds");

        GitHub gitHub = new GitHubBuilder().withOAuthToken(githubPat).build();
        System.out.println(gitHub.getApiUrl());

        GHRepository repo = gitHub.getRepository("theautonomy/articles");

        // Get the latest workflow run for build.yml
        var workflow = repo.getWorkflow("build.yml");
        var runs = workflow.listRuns().toList();

        if (!runs.isEmpty()) {
            var latestRun = runs.get(0);

            System.out.println("\n=== Latest Workflow Build Summary ===");
            System.out.println("Workflow: " + latestRun.getName());
            System.out.println("Status: " + latestRun.getStatus());
            System.out.println("Conclusion: " + latestRun.getConclusion());
            System.out.println("Branch: " + latestRun.getHeadBranch());
            System.out.println("Run Number: " + latestRun.getRunNumber());
            System.out.println("Created: " + latestRun.getCreatedAt());
            System.out.println("Updated: " + latestRun.getUpdatedAt());
            System.out.println("URL: " + latestRun.getHtmlUrl());

            // Get the commit from the latest build
            var latestCommit = repo.getCommit(latestRun.getHeadSha());
            var parents = latestCommit.getParentSHA1s();

            if (parents != null && parents.size() > 0) {
                var parentCommitSha = parents.get(0);
                var parentCommit = repo.getCommit(parentCommitSha);

                System.out.println("\n=== Commit Comparison ===");
                System.out.println("Latest Commit: " + latestRun.getHeadSha().substring(0, 7));
                System.out.println("  Message: " + latestCommit.getCommitShortInfo().getMessage());
                System.out.println(
                        "  Author: " + latestCommit.getCommitShortInfo().getAuthor().getName());
                System.out.println("  Date: " + latestCommit.getCommitDate());

                System.out.println("\nParent Commit: " + parentCommitSha.substring(0, 7));
                System.out.println("  Message: " + parentCommit.getCommitShortInfo().getMessage());
                System.out.println(
                        "  Author: " + parentCommit.getCommitShortInfo().getAuthor().getName());
                System.out.println("  Date: " + parentCommit.getCommitDate());

                // Get the diff between the parent commit and latest commit
                System.out.println("\n=== Commit Diff ===");
                var compareResult = repo.getCompare(parentCommitSha, latestRun.getHeadSha());

                System.out.println("Files Changed: " + compareResult.getFiles().length);

                System.out.println("\nFile Changes:");
                for (var file : compareResult.getFiles()) {
                    System.out.println("\n  File: " + file.getFileName());
                    System.out.println("  Status: " + file.getStatus());
                    System.out.println("  Additions: +" + file.getLinesAdded());
                    System.out.println("  Deletions: -" + file.getLinesDeleted());
                    System.out.println("  Changes: " + file.getLinesChanged());

                    if (file.getPatch() != null && !file.getPatch().isEmpty()) {
                        System.out.println("\n  Patch:");
                        System.out.println("  " + file.getPatch().replace("\n", "\n  "));
                    }
                }

                System.out.println("\n=========================================\n");
            } else {
                System.out.println("\nNo parent commit found (this might be the initial commit)");
                System.out.println("=====================================\n");
            }
        } else {
            System.out.println("No workflow runs found for build.yml");
        }
    }
}
