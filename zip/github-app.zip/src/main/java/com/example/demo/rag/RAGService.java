package com.example.demo.rag;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.example.demo.rag.entity.BuildFailure;
import com.example.demo.rag.entity.DeploymentHistory;
import com.example.demo.rag.repository.BuildFailureRepository;
import com.example.demo.rag.repository.DeploymentHistoryRepository;
import com.pgvector.PGvector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * RAG (Retrieval-Augmented Generation) Service Manages storage and retrieval of build failures with
 * vector embeddings for similarity search and AI-powered recommendations
 */
@Service
public class RAGService {

    private static final Logger logger = LoggerFactory.getLogger(RAGService.class);

    private final BuildFailureRepository repository;
    private final DeploymentHistoryRepository deploymentRepository;
    private final EmbeddingService embeddingService;

    // Constants for similarity search
    private static final double DEFAULT_SIMILARITY_THRESHOLD = 0.3; // Cosine distance threshold
    private static final int DEFAULT_RESULT_LIMIT = 5;
    private static final float MIN_EFFECTIVENESS_SCORE = 0.7f;
    private static final int MIN_TIMES_HELPED = 1;

    public RAGService(
            BuildFailureRepository repository,
            DeploymentHistoryRepository deploymentRepository,
            EmbeddingService embeddingService) {
        this.repository = repository;
        this.deploymentRepository = deploymentRepository;
        this.embeddingService = embeddingService;
    }

    /**
     * Store a new build failure with vector embedding
     *
     * @param repositoryName Repository name
     * @param workflowName Workflow name
     * @param runId GitHub Actions run ID
     * @param runNumber Run number
     * @param errorMessage Error message
     * @param errorStacktrace Optional stacktrace
     * @param branch Branch name
     * @param commitSha Commit SHA
     * @param failedStep Failed step name
     * @return Saved BuildFailure entity
     */
    @Transactional
    public BuildFailure storeFailure(
            String repositoryName,
            String workflowName,
            Long runId,
            Integer runNumber,
            String errorMessage,
            String errorStacktrace,
            String branch,
            String commitSha,
            String failedStep) {

        logger.info(
                "Storing build failure for repository: {}, workflow: {}, run: {}",
                repositoryName,
                workflowName,
                runId);

        // Check if a failure with this runId already exists
        BuildFailure existingFailure = repository.findByRunId(runId);
        if (existingFailure != null) {
            logger.info(
                    "Build failure with run ID {} already exists (ID: {}), skipping duplicate save",
                    runId,
                    existingFailure.getId());
            return existingFailure;
        }

        // Create build failure entity
        BuildFailure failure =
                new BuildFailure(repositoryName, workflowName, runId, runNumber, errorMessage);
        failure.setErrorStacktrace(errorStacktrace);
        failure.setBranch(branch);
        failure.setCommitSha(commitSha);
        failure.setFailedStep(failedStep);

        // Generate embedding for the error
        String textToEmbed = buildEmbeddingText(errorMessage, errorStacktrace, failedStep);
        try {
            float[] embedding = embeddingService.generateEmbedding(textToEmbed);
            failure.setErrorEmbedding(new PGvector(embedding));
            logger.debug("Generated embedding with {} dimensions", embedding.length);
        } catch (Exception e) {
            logger.error("Failed to generate embedding for build failure", e);
            // Store without embedding - can be regenerated later
        }

        // Save to database
        BuildFailure saved = repository.save(failure);
        logger.info("Stored build failure with ID: {}", saved.getId());

        return saved;
    }

    /**
     * Find similar past failures to help diagnose current issue
     *
     * @param errorMessage Current error message
     * @param errorStacktrace Optional stacktrace
     * @param failedStep Optional failed step
     * @return List of similar failures ordered by similarity
     */
    public List<BuildFailure> findSimilarFailures(
            String errorMessage, String errorStacktrace, String failedStep) {

        logger.info(
                "Finding similar failures for error: {}",
                errorMessage.substring(0, Math.min(100, errorMessage.length())));

        // Generate embedding for the current error
        String textToEmbed = buildEmbeddingText(errorMessage, errorStacktrace, failedStep);
        float[] embedding = embeddingService.generateEmbedding(textToEmbed);
        String embeddingStr = embeddingService.vectorToString(embedding);

        // Query for similar failures
        List<BuildFailure> similar =
                repository.findSimilarFailures(
                        embeddingStr, DEFAULT_SIMILARITY_THRESHOLD, DEFAULT_RESULT_LIMIT);

        logger.info("Found {} similar failures", similar.size());
        return similar;
    }

    /**
     * Find similar failures that have been resolved (known solutions)
     *
     * @param errorMessage Current error message
     * @param errorStacktrace Optional stacktrace
     * @param failedStep Optional failed step
     * @return List of resolved failures with solutions
     */
    public List<BuildFailure> findSimilarResolvedFailures(
            String errorMessage, String errorStacktrace, String failedStep) {

        logger.info("Finding similar resolved failures");

        String textToEmbed = buildEmbeddingText(errorMessage, errorStacktrace, failedStep);
        float[] embedding = embeddingService.generateEmbedding(textToEmbed);
        String embeddingStr = embeddingService.vectorToString(embedding);

        List<BuildFailure> resolved =
                repository.findSimilarResolvedFailures(
                        embeddingStr, DEFAULT_SIMILARITY_THRESHOLD, DEFAULT_RESULT_LIMIT);

        logger.info("Found {} similar resolved failures", resolved.size());
        return resolved;
    }

    /**
     * Find most effective solutions for similar failures
     *
     * @param errorMessage Current error message
     * @param errorStacktrace Optional stacktrace
     * @param failedStep Optional failed step
     * @return List of effective solutions
     */
    public List<BuildFailure> findEffectiveSolutions(
            String errorMessage, String errorStacktrace, String failedStep) {

        logger.info("Finding effective solutions");

        String textToEmbed = buildEmbeddingText(errorMessage, errorStacktrace, failedStep);
        float[] embedding = embeddingService.generateEmbedding(textToEmbed);
        String embeddingStr = embeddingService.vectorToString(embedding);

        List<BuildFailure> effective =
                repository.findEffectiveSolutions(
                        embeddingStr,
                        MIN_EFFECTIVENESS_SCORE,
                        MIN_TIMES_HELPED,
                        DEFAULT_RESULT_LIMIT);

        logger.info("Found {} effective solutions", effective.size());
        return effective;
    }

    /**
     * Mark a failure as resolved with solution details
     *
     * @param failureId ID of the failure to resolve
     * @param resolutionCommit Commit SHA that fixed the issue
     * @param resolutionDescription Description of how it was fixed
     * @param resolutionCodeSnippet Optional code snippet of the fix
     * @param fixedBy Who fixed it
     * @return Updated BuildFailure
     */
    @Transactional
    public Optional<BuildFailure> markAsResolved(
            UUID failureId,
            String resolutionCommit,
            String resolutionDescription,
            String resolutionCodeSnippet,
            String fixedBy) {

        logger.info("Marking failure {} as resolved", failureId);

        Optional<BuildFailure> optionalFailure = repository.findById(failureId);
        if (optionalFailure.isEmpty()) {
            logger.warn("Failure {} not found", failureId);
            return Optional.empty();
        }

        BuildFailure failure = optionalFailure.get();
        failure.setResolved(true);
        failure.setResolutionCommit(resolutionCommit);
        failure.setResolutionDescription(resolutionDescription);
        failure.setResolutionCodeSnippet(resolutionCodeSnippet);
        failure.setFixedBy(fixedBy);
        failure.setResolvedAt(LocalDateTime.now());

        // Calculate time to fix
        if (failure.getFailedAt() != null) {
            Duration duration = Duration.between(failure.getFailedAt(), LocalDateTime.now());
            failure.setTimeToFixMinutes((int) duration.toMinutes());
        }

        BuildFailure saved = repository.save(failure);
        logger.info("Marked failure {} as resolved", failureId);

        return Optional.of(saved);
    }

    /**
     * Mark a failure as resolved by run ID
     *
     * @param runId GitHub Actions run ID
     * @param resolutionCommit Commit SHA that fixed the issue
     * @param resolutionDescription Description of how it was fixed
     * @param resolutionCodeSnippet Optional code snippet of the fix
     * @param fixedBy Who fixed it
     * @return Updated BuildFailure
     */
    @Transactional
    public Optional<BuildFailure> markAsResolvedByRunId(
            Long runId,
            String resolutionCommit,
            String resolutionDescription,
            String resolutionCodeSnippet,
            String fixedBy) {

        BuildFailure failure = repository.findByRunId(runId);
        if (failure == null) {
            logger.warn("Failure with run ID {} not found", runId);
            return Optional.empty();
        }

        return markAsResolved(
                failure.getId(),
                resolutionCommit,
                resolutionDescription,
                resolutionCodeSnippet,
                fixedBy);
    }

    /**
     * Record that a solution helped resolve a similar failure Updates effectiveness tracking
     *
     * @param solutionFailureId ID of the failure with the helpful solution
     * @param wasEffective Whether the solution was effective
     */
    @Transactional
    public void recordSolutionUsed(UUID solutionFailureId, boolean wasEffective) {
        logger.info("Recording solution usage for failure {}", solutionFailureId);

        Optional<BuildFailure> optionalFailure = repository.findById(solutionFailureId);
        if (optionalFailure.isEmpty()) {
            logger.warn("Failure {} not found", solutionFailureId);
            return;
        }

        BuildFailure failure = optionalFailure.get();
        failure.setTimesHelped(failure.getTimesHelped() + 1);

        if (wasEffective) {
            // Update effectiveness score using exponential moving average
            float currentScore = failure.getSolutionEffectiveness();
            float alpha = 0.3f; // Weight for new observation
            float newScore = currentScore + alpha * (1.0f - currentScore);
            failure.setSolutionEffectiveness(newScore);
        } else {
            // Decrease effectiveness score
            float currentScore = failure.getSolutionEffectiveness();
            float alpha = 0.3f;
            float newScore = currentScore * (1.0f - alpha);
            failure.setSolutionEffectiveness(newScore);
        }

        repository.save(failure);
        logger.info("Updated solution effectiveness to {}", failure.getSolutionEffectiveness());
    }

    /**
     * Store AI analysis for a failure
     *
     * @param failureId ID of the failure
     * @param aiAnalysis AI-generated analysis text
     * @param aiConfidence Confidence level (HIGH, MEDIUM, LOW)
     */
    @Transactional
    public void storeAIAnalysis(UUID failureId, String aiAnalysis, String aiConfidence) {
        logger.info("Storing AI analysis for failure {}", failureId);

        Optional<BuildFailure> optionalFailure = repository.findById(failureId);
        if (optionalFailure.isEmpty()) {
            logger.warn("Failure {} not found", failureId);
            return;
        }

        BuildFailure failure = optionalFailure.get();
        failure.setAiAnalysis(aiAnalysis);
        failure.setAiConfidence(aiConfidence);

        repository.save(failure);
        logger.info("Stored AI analysis for failure {}", failureId);
    }

    /** Get all unresolved failures for a repository */
    public List<BuildFailure> getUnresolvedFailures(String repositoryName) {
        return this.repository.findByRepositoryAndResolvedFalseOrderByFailedAtDesc(repositoryName);
    }

    /** Get recent failures (last N days) */
    public List<BuildFailure> getRecentFailures(int days) {
        LocalDateTime since = LocalDateTime.now().minusDays(days);
        return repository.findRecentFailures(since);
    }

    /** Get statistics for a repository */
    public FailureStatistics getStatistics(String repositoryName) {
        long totalFailures = this.repository.countByRepository(repositoryName);
        long unresolvedFailures = this.repository.countByRepositoryAndResolvedFalse(repositoryName);
        Double avgTimeToFix = this.repository.getAverageTimeToFixByRepository(repositoryName);

        return new FailureStatistics(
                totalFailures,
                unresolvedFailures,
                totalFailures - unresolvedFailures,
                avgTimeToFix != null ? avgTimeToFix : 0.0);
    }

    /** Build text for embedding from error components */
    private String buildEmbeddingText(
            String errorMessage, String errorStacktrace, String failedStep) {
        StringBuilder text = new StringBuilder();

        if (failedStep != null && !failedStep.isEmpty()) {
            text.append("Failed Step: ").append(failedStep).append("\n");
        }

        text.append("Error: ").append(errorMessage);

        if (errorStacktrace != null && !errorStacktrace.isEmpty()) {
            // Include first 1000 characters of stacktrace
            String truncatedStacktrace =
                    errorStacktrace.substring(0, Math.min(1000, errorStacktrace.length()));
            text.append("\nStacktrace: ").append(truncatedStacktrace);
        }

        return text.toString();
    }

    /** Statistics record */
    public record FailureStatistics(
            long totalFailures,
            long unresolvedFailures,
            long resolvedFailures,
            double averageTimeToFixMinutes) {}

    // ========== DEPLOYMENT HISTORY METHODS ==========

    /**
     * Store a deployment with its predicted risk assessment
     *
     * @param deployment DeploymentHistory entity to store
     * @return Saved DeploymentHistory entity
     */
    @Transactional
    public DeploymentHistory storeDeployment(DeploymentHistory deployment) {
        logger.info(
                "Storing deployment for repository: {}, environment: {}, from: {} to: {}",
                deployment.getRepository(),
                deployment.getEnvironment(),
                deployment.getFromCommit(),
                deployment.getToCommit());

        // Check if a deployment with the same repository and commit range already exists
        DeploymentHistory existingDeployment =
                deploymentRepository.findByRepositoryAndFromCommitAndToCommit(
                        deployment.getRepository(),
                        deployment.getFromCommit(),
                        deployment.getToCommit());

        if (existingDeployment != null) {
            logger.info(
                    "Deployment for repository: {}, from: {} to: {} already exists (ID: {}), skipping duplicate save",
                    deployment.getRepository(),
                    deployment.getFromCommit(),
                    deployment.getToCommit(),
                    existingDeployment.getId());
            return existingDeployment;
        }

        // Generate embedding for the deployment changes
        String textToEmbed =
                buildDeploymentEmbeddingText(
                        deployment.getChangedFiles(),
                        deployment.getCommitMessages(),
                        deployment.getHasDatabaseChanges(),
                        deployment.getHasConfigChanges(),
                        deployment.getHasCriticalFiles());

        try {
            float[] embedding = embeddingService.generateEmbedding(textToEmbed);
            deployment.setChangeEmbedding(new PGvector(embedding));
            logger.debug("Generated embedding with {} dimensions", embedding.length);
        } catch (Exception e) {
            logger.error("Failed to generate embedding for deployment", e);
            // Store without embedding - can be regenerated later
        }

        // Save to database
        DeploymentHistory saved = deploymentRepository.save(deployment);
        logger.info("Stored deployment with ID: {}", saved.getId());

        return saved;
    }

    /**
     * Update deployment with actual outcome
     *
     * @param deploymentId ID of the deployment to update
     * @param actualSuccess Whether the deployment succeeded
     * @param deploymentDurationMinutes Duration in minutes
     * @param issuesEncountered Issues that occurred
     * @param incidentSeverity Severity of any incidents
     * @return Updated DeploymentHistory
     */
    @Transactional
    public Optional<DeploymentHistory> updateDeploymentOutcome(
            UUID deploymentId,
            boolean actualSuccess,
            Integer deploymentDurationMinutes,
            String[] issuesEncountered,
            String incidentSeverity) {

        logger.info("Updating deployment outcome for ID: {}", deploymentId);

        Optional<DeploymentHistory> optionalDeployment =
                deploymentRepository.findById(deploymentId);
        if (optionalDeployment.isEmpty()) {
            logger.warn("Deployment {} not found", deploymentId);
            return Optional.empty();
        }

        DeploymentHistory deployment = optionalDeployment.get();
        deployment.setActualSuccess(actualSuccess);
        deployment.setDeploymentStatus(
                actualSuccess ? "success" : (issuesEncountered != null ? "failed" : "success"));
        deployment.setDeploymentDurationMinutes(deploymentDurationMinutes);
        deployment.setIssuesEncountered(issuesEncountered);
        deployment.setIncidentSeverity(incidentSeverity != null ? incidentSeverity : "none");

        DeploymentHistory saved = deploymentRepository.save(deployment);
        logger.info("Updated deployment outcome for ID: {}", deploymentId);

        return Optional.of(saved);
    }

    /**
     * Find similar past deployments to assess risk
     *
     * @param changedFiles Files being changed
     * @param commitMessages Commit messages
     * @param hasDatabaseChanges Whether database changes are included
     * @param hasConfigChanges Whether config changes are included
     * @param hasCriticalFiles Whether critical files are affected
     * @return List of similar deployments
     */
    public List<DeploymentHistory> findSimilarDeployments(
            String[] changedFiles,
            String[] commitMessages,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles) {

        logger.info("Finding similar deployments");

        String textToEmbed =
                buildDeploymentEmbeddingText(
                        changedFiles,
                        commitMessages,
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles);
        float[] embedding = embeddingService.generateEmbedding(textToEmbed);
        String embeddingStr = embeddingService.vectorToString(embedding);

        List<DeploymentHistory> similar =
                deploymentRepository.findSimilarDeployments(
                        embeddingStr, DEFAULT_SIMILARITY_THRESHOLD, DEFAULT_RESULT_LIMIT);

        logger.info("Found {} similar deployments", similar.size());
        return similar;
    }

    /**
     * Find similar successful deployments (for learning from successes)
     *
     * @param changedFiles Files being changed
     * @param commitMessages Commit messages
     * @param hasDatabaseChanges Whether database changes are included
     * @param hasConfigChanges Whether config changes are included
     * @param hasCriticalFiles Whether critical files are affected
     * @return List of similar successful deployments
     */
    public List<DeploymentHistory> findSimilarSuccessfulDeployments(
            String[] changedFiles,
            String[] commitMessages,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles) {

        logger.info("Finding similar successful deployments");

        String textToEmbed =
                buildDeploymentEmbeddingText(
                        changedFiles,
                        commitMessages,
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles);
        float[] embedding = embeddingService.generateEmbedding(textToEmbed);
        String embeddingStr = embeddingService.vectorToString(embedding);

        List<DeploymentHistory> successful =
                deploymentRepository.findSimilarSuccessfulDeployments(
                        embeddingStr, DEFAULT_SIMILARITY_THRESHOLD, DEFAULT_RESULT_LIMIT);

        logger.info("Found {} similar successful deployments", successful.size());
        return successful;
    }

    /**
     * Find similar failed deployments (for risk assessment)
     *
     * @param changedFiles Files being changed
     * @param commitMessages Commit messages
     * @param hasDatabaseChanges Whether database changes are included
     * @param hasConfigChanges Whether config changes are included
     * @param hasCriticalFiles Whether critical files are affected
     * @return List of similar failed deployments
     */
    public List<DeploymentHistory> findSimilarFailedDeployments(
            String[] changedFiles,
            String[] commitMessages,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles) {

        logger.info("Finding similar failed deployments");

        String textToEmbed =
                buildDeploymentEmbeddingText(
                        changedFiles,
                        commitMessages,
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles);
        float[] embedding = embeddingService.generateEmbedding(textToEmbed);
        String embeddingStr = embeddingService.vectorToString(embedding);

        List<DeploymentHistory> failed =
                deploymentRepository.findSimilarFailedDeployments(
                        embeddingStr, DEFAULT_SIMILARITY_THRESHOLD, DEFAULT_RESULT_LIMIT);

        logger.info("Found {} similar failed deployments", failed.size());
        return failed;
    }

    /**
     * Get deployment statistics by time (day of week and hour of day)
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Deployment time statistics
     */
    public DeploymentTimeStatistics getDeploymentTimeStatistics(
            String repository, String environment) {

        logger.info(
                "Getting deployment time statistics for repository: {}, environment: {}",
                repository,
                environment);

        List<Object[]> results =
                deploymentRepository.getDeploymentStatsByTime(repository, environment, 3);

        return new DeploymentTimeStatistics(results);
    }

    /**
     * Get deployment statistics for a repository and environment
     *
     * @param repository Repository name
     * @param environment Environment name
     * @return Deployment statistics
     */
    public DeploymentStatistics getDeploymentStatistics(String repository, String environment) {
        long totalDeployments = deploymentRepository.countByRepository(repository);
        long successfulDeployments =
                deploymentRepository.countByRepositoryAndActualSuccessTrue(repository);
        long failedDeployments =
                deploymentRepository.countByRepositoryAndActualSuccessFalse(repository);
        Double avgDuration = deploymentRepository.getAverageDuration(repository, environment);
        Double successRate = deploymentRepository.getSuccessRate(repository, environment);

        return new DeploymentStatistics(
                totalDeployments,
                successfulDeployments,
                failedDeployments,
                avgDuration != null ? avgDuration : 0.0,
                successRate != null ? successRate : 0.0);
    }

    /** Build text for embedding from deployment components */
    private String buildDeploymentEmbeddingText(
            String[] changedFiles,
            String[] commitMessages,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles) {

        StringBuilder text = new StringBuilder();

        // Add file changes
        if (changedFiles != null && changedFiles.length > 0) {
            text.append("Files changed: ");
            text.append(String.join(", ", changedFiles));
            text.append("\n");
        }

        // Add commit messages
        if (commitMessages != null && commitMessages.length > 0) {
            text.append("Commits: ");
            text.append(String.join(". ", commitMessages));
            text.append("\n");
        }

        // Add flags
        if (Boolean.TRUE.equals(hasDatabaseChanges)) {
            text.append("Includes database changes. ");
        }
        if (Boolean.TRUE.equals(hasConfigChanges)) {
            text.append("Includes configuration changes. ");
        }
        if (Boolean.TRUE.equals(hasCriticalFiles)) {
            text.append("Affects critical files (auth, security, payment). ");
        }

        return text.toString();
    }

    /** Deployment statistics record */
    public record DeploymentStatistics(
            long totalDeployments,
            long successfulDeployments,
            long failedDeployments,
            double averageDurationMinutes,
            double successRate) {}

    /** Deployment time statistics */
    public static class DeploymentTimeStatistics {
        private final List<Object[]> rawData;

        public DeploymentTimeStatistics(List<Object[]> rawData) {
            this.rawData = rawData;
        }

        /**
         * Get success rate for a specific day and hour
         *
         * @param dayOfWeek Day of week (0=Sunday, 6=Saturday)
         * @param hourOfDay Hour of day (0-23)
         * @return Success rate (0-1) or null if no data
         */
        public Double getSuccessRate(int dayOfWeek, int hourOfDay) {
            for (Object[] row : rawData) {
                Integer day = (Integer) row[0];
                Integer hour = (Integer) row[1];
                if (day == dayOfWeek && hour == hourOfDay) {
                    return (Double) row[4]; // success_rate column
                }
            }
            return null;
        }

        /**
         * Get the optimal deployment time (highest success rate)
         *
         * @return Array [dayOfWeek, hourOfDay, successRate] or null if no data
         */
        public Object[] getOptimalTime() {
            if (rawData.isEmpty()) {
                return null;
            }
            // First row is already sorted by success_rate DESC
            Object[] best = rawData.get(0);
            return new Object[] {best[0], best[1], best[4]};
        }

        public List<Object[]> getAllTimeSlots() {
            return rawData;
        }
    }
}
