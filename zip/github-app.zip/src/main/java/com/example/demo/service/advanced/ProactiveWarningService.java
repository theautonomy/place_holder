package com.example.demo.service.advanced;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.demo.entity.DeploymentHistory;
import com.example.demo.repository.DeploymentHistoryRepository;
import com.example.demo.service.rag.RAGService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Proactive Warning Service Generates warnings about risky deployment patterns before deployment
 * happens
 */
@Service
public class ProactiveWarningService {

    private static final Logger logger = LoggerFactory.getLogger(ProactiveWarningService.class);

    private final DeploymentHistoryRepository deploymentRepository;
    private final RAGService ragService;

    // Thresholds
    private static final float RISKY_COMBINATION_THRESHOLD = 0.75f; // 75% failure rate
    private static final float POOR_TIMING_THRESHOLD = 0.6f; // Less than 60% success rate
    private static final int MINIMUM_SAMPLES = 3; // Need at least 3 deployments for statistics

    public ProactiveWarningService(
            DeploymentHistoryRepository deploymentRepository, RAGService ragService) {
        this.deploymentRepository = deploymentRepository;
        this.ragService = ragService;
    }

    /**
     * Generate proactive warnings for a planned deployment
     *
     * @param repository Repository name
     * @param environment Target environment
     * @param changedFiles Files being changed
     * @param commitMessages Commit messages
     * @param hasDatabaseChanges Whether DB changes are included
     * @param hasConfigChanges Whether config changes are included
     * @param hasCriticalFiles Whether critical files are affected
     * @param deploymentTime Planned deployment time (null for current time)
     * @return List of warnings
     */
    public List<DeploymentWarning> generateWarnings(
            String repository,
            String environment,
            List<String> changedFiles,
            List<String> commitMessages,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles,
            LocalDateTime deploymentTime) {

        logger.info("Generating proactive warnings for deployment to {}", environment);

        List<DeploymentWarning> warnings = new ArrayList<>();
        LocalDateTime plannedTime = deploymentTime != null ? deploymentTime : LocalDateTime.now();

        // 1. Check for dangerous file combinations
        warnings.addAll(
                checkRiskyFileCombinations(
                        repository, hasDatabaseChanges, hasConfigChanges, hasCriticalFiles));

        // 2. Check deployment timing
        warnings.addAll(checkDeploymentTiming(repository, environment, plannedTime));

        // 3. Check for missing prerequisites (based on similar past deployments)
        warnings.addAll(
                checkMissingPrerequisites(
                        repository,
                        changedFiles.toArray(new String[0]),
                        commitMessages.toArray(new String[0]),
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles));

        // 4. Check for risky file patterns
        warnings.addAll(checkRiskyFilePatterns(changedFiles));

        // 5. Check for large changeset warnings
        warnings.addAll(checkChangesetSize(changedFiles.size(), commitMessages.size()));

        logger.info("Generated {} warnings", warnings.size());
        return warnings;
    }

    private List<DeploymentWarning> checkRiskyFileCombinations(
            String repository,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles) {

        List<DeploymentWarning> warnings = new ArrayList<>();

        // Database + Auth changes
        if (Boolean.TRUE.equals(hasDatabaseChanges) && Boolean.TRUE.equals(hasCriticalFiles)) {
            // Check historical failure rate
            long dbAndAuthDeployments =
                    deploymentRepository.countByRepositoryAndHasDatabaseChangesAndHasCriticalFiles(
                            repository, true, true);
            long dbAndAuthFailures =
                    deploymentRepository
                            .countByRepositoryAndHasDatabaseChangesAndHasCriticalFilesAndActualSuccess(
                                    repository, true, true, false);

            if (dbAndAuthDeployments >= MINIMUM_SAMPLES) {
                float failureRate = (float) dbAndAuthFailures / dbAndAuthDeployments;

                if (failureRate >= RISKY_COMBINATION_THRESHOLD) {
                    warnings.add(
                            new DeploymentWarning(
                                    "CRITICAL",
                                    "Risky Combination: Database + Critical File Changes",
                                    String.format(
                                            "This combination has a %.0f%% failure rate (% failed out of %d deployments)",
                                            failureRate * 100,
                                            dbAndAuthFailures,
                                            dbAndAuthDeployments),
                                    "Split into two separate deployments: (1) Database migration first, (2) Code changes after verification",
                                    List.of(
                                            "Test database migration in staging first",
                                            "Have rollback scripts ready",
                                            "Deploy during low-traffic window")));
                }
            }
        }

        // Database + Config changes
        if (Boolean.TRUE.equals(hasDatabaseChanges) && Boolean.TRUE.equals(hasConfigChanges)) {
            warnings.add(
                    new DeploymentWarning(
                            "HIGH",
                            "Database and Configuration Changes Combined",
                            "Changes to both database schema and configuration can cause startup failures",
                            "Verify configuration matches database schema version",
                            List.of(
                                    "Test configuration in staging environment",
                                    "Ensure database migrations run before app restarts",
                                    "Have previous configuration backed up")));
        }

        // Multiple critical systems
        if (Boolean.TRUE.equals(hasCriticalFiles)
                && Boolean.TRUE.equals(hasConfigChanges)
                && Boolean.TRUE.equals(hasDatabaseChanges)) {
            warnings.add(
                    new DeploymentWarning(
                            "CRITICAL",
                            "Multiple Critical Systems Modified",
                            "Changing database, configuration, and critical files in one deployment increases risk significantly",
                            "Break into smaller deployments or schedule extensive testing",
                            List.of(
                                    "Allocate extra time for this deployment",
                                    "Have senior engineers on standby",
                                    "Prepare detailed rollback procedure")));
        }

        return warnings;
    }

    private List<DeploymentWarning> checkDeploymentTiming(
            String repository, String environment, LocalDateTime plannedTime) {

        List<DeploymentWarning> warnings = new ArrayList<>();

        DayOfWeek dayOfWeek = plannedTime.getDayOfWeek();
        int hourOfDay = plannedTime.getHour();

        // Get historical timing statistics
        RAGService.DeploymentTimeStatistics stats =
                ragService.getDeploymentTimeStatistics(repository, environment);

        Double currentTimeSuccessRate = stats.getSuccessRate(dayOfWeek.getValue(), hourOfDay);

        if (currentTimeSuccessRate != null && currentTimeSuccessRate < POOR_TIMING_THRESHOLD) {
            Object[] optimalTime = stats.getOptimalTime();

            if (optimalTime != null) {
                double optimalSuccessRate = (Double) optimalTime[2];
                int optimalDay = (Integer) optimalTime[0];
                int optimalHour = (Integer) optimalTime[1];

                String dayName = DayOfWeek.of(optimalDay).name();

                warnings.add(
                        new DeploymentWarning(
                                "HIGH",
                                "Suboptimal Deployment Timing",
                                String.format(
                                        "Deployments at %s %d:00 have %.0f%% success rate vs %.0f%% at optimal time (%s %d:00)",
                                        dayOfWeek.name(),
                                        hourOfDay,
                                        currentTimeSuccessRate * 100,
                                        optimalSuccessRate * 100,
                                        dayName,
                                        optimalHour),
                                String.format(
                                        "Consider rescheduling to %s at %d:00 for %.0f%% higher success rate",
                                        dayName,
                                        optimalHour,
                                        (optimalSuccessRate - currentTimeSuccessRate) * 100),
                                List.of(
                                        "Reschedule to optimal time if possible",
                                        "If deploying now, allocate extra monitoring time",
                                        "Have rollback plan ready")));
            }
        }

        // Friday afternoon warning
        if (dayOfWeek == DayOfWeek.FRIDAY && hourOfDay >= 15) {
            warnings.add(
                    new DeploymentWarning(
                            "MEDIUM",
                            "Late Friday Deployment",
                            "Deploying late on Friday increases risk of weekend incidents",
                            "Consider delaying until Monday morning unless urgent",
                            List.of(
                                    "Ensure team availability over weekend",
                                    "Have clear rollback procedure",
                                    "Monitor closely for several hours post-deployment")));
        }

        // Late night deployment warning
        if (hourOfDay >= 22 || hourOfDay <= 6) {
            warnings.add(
                    new DeploymentWarning(
                            "MEDIUM",
                            "Late Night Deployment",
                            "Deploying during off-hours may delay incident response",
                            "Ensure on-call engineer is available and alert",
                            List.of(
                                    "Verify on-call rotation is up to date",
                                    "Set up enhanced monitoring and alerts",
                                    "Document deployment steps clearly")));
        }

        return warnings;
    }

    private List<DeploymentWarning> checkMissingPrerequisites(
            String repository,
            String[] changedFiles,
            String[] commitMessages,
            Boolean hasDatabaseChanges,
            Boolean hasConfigChanges,
            Boolean hasCriticalFiles) {

        List<DeploymentWarning> warnings = new ArrayList<>();

        // Find similar failed deployments
        List<DeploymentHistory> similarFailed =
                ragService.findSimilarFailedDeployments(
                        changedFiles,
                        commitMessages,
                        hasDatabaseChanges,
                        hasConfigChanges,
                        hasCriticalFiles);

        // Extract common failure reasons
        Map<String, Integer> failureReasons = new HashMap<>();

        for (DeploymentHistory failed : similarFailed) {
            if (failed.getIssuesEncountered() != null) {
                for (String issue : failed.getIssuesEncountered()) {
                    // Look for configuration-related issues
                    if (issue.toLowerCase().contains("config")
                            || issue.toLowerCase().contains("setting")
                            || issue.toLowerCase().contains("property")
                            || issue.toLowerCase().contains("environment variable")) {
                        failureReasons.put(issue, failureReasons.getOrDefault(issue, 0) + 1);
                    }
                }
            }
        }

        // If we found common configuration issues
        if (!failureReasons.isEmpty()) {
            List<String> commonIssues = new ArrayList<>();
            for (Map.Entry<String, Integer> entry : failureReasons.entrySet()) {
                if (entry.getValue() >= 2) { // Occurred at least twice
                    commonIssues.add(entry.getKey());
                }
            }

            if (!commonIssues.isEmpty()) {
                warnings.add(
                        new DeploymentWarning(
                                "MEDIUM",
                                "Potential Missing Configuration",
                                String.format(
                                        "Similar deployments failed due to configuration issues: %s",
                                        String.join(", ", commonIssues)),
                                "Verify all required configurations are present in target environment",
                                List.of(
                                        "Review environment variables",
                                        "Check configuration files",
                                        "Verify secrets and credentials",
                                        "Test in staging first")));
            }
        }

        return warnings;
    }

    private List<DeploymentWarning> checkRiskyFilePatterns(List<String> changedFiles) {
        List<DeploymentWarning> warnings = new ArrayList<>();

        long criticalFileCount =
                changedFiles.stream()
                        .filter(
                                f ->
                                        f.toLowerCase().contains("auth")
                                                || f.toLowerCase().contains("security")
                                                || f.toLowerCase().contains("payment")
                                                || f.toLowerCase().contains("billing"))
                        .count();

        if (criticalFileCount > 0) {
            warnings.add(
                    new DeploymentWarning(
                            "HIGH",
                            String.format("Critical Files Modified (%d files)", criticalFileCount),
                            "Changes to authentication, security, or payment systems require extra caution",
                            "Perform thorough security testing before deployment",
                            List.of(
                                    "Run security regression tests",
                                    "Verify authentication flows",
                                    "Test payment processing in staging",
                                    "Have security team review changes")));
        }

        // Check for database migration files
        long migrationFileCount =
                changedFiles.stream()
                        .filter(
                                f ->
                                        f.toLowerCase().contains("migration")
                                                || f.toLowerCase().contains("schema")
                                                || f.matches(".*V\\d+__.*\\.sql"))
                        .count();

        if (migrationFileCount > 0) {
            warnings.add(
                    new DeploymentWarning(
                            "HIGH",
                            String.format(
                                    "Database Migration Files (%d files)", migrationFileCount),
                            "Database migrations are irreversible and can cause data loss or downtime",
                            "Test migrations thoroughly and have rollback plan ready",
                            List.of(
                                    "Test migration on production-like dataset",
                                    "Verify migration is backward compatible",
                                    "Backup database before migration",
                                    "Prepare rollback migration script")));
        }

        return warnings;
    }

    private List<DeploymentWarning> checkChangesetSize(int filesChanged, int commitsCount) {
        List<DeploymentWarning> warnings = new ArrayList<>();

        if (filesChanged > 50) {
            warnings.add(
                    new DeploymentWarning(
                            "MEDIUM",
                            String.format("Large Changeset (%d files)", filesChanged),
                            "Large deployments are harder to test and debug if issues occur",
                            "Consider breaking into smaller deployments",
                            List.of(
                                    "Group related changes together",
                                    "Deploy in phases if possible",
                                    "Allocate extra time for testing and monitoring")));
        }

        if (commitsCount > 100) {
            warnings.add(
                    new DeploymentWarning(
                            "LOW",
                            String.format("Many Commits (%d commits)", commitsCount),
                            "Large number of commits may indicate accumulated changes",
                            "Review all changes carefully",
                            List.of(
                                    "Generate comprehensive release notes",
                                    "Review breaking changes",
                                    "Ensure all changes are tested")));
        }

        return warnings;
    }

    /** Deployment warning with severity and recommendations */
    public record DeploymentWarning(
            String severity, // CRITICAL, HIGH, MEDIUM, LOW
            String title,
            String description,
            String recommendation,
            List<String> actionItems) {}
}
