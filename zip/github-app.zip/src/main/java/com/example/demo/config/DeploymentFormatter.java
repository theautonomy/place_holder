package com.example.demo.config;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;

import com.example.demo.service.DeploymentTrackingService;

import org.kohsuke.github.GHDeployment;

public class DeploymentFormatter {

    /** Print deployment tracking overview */
    public static void printDeploymentTracking(
            DeploymentTrackingService.DeploymentTrackingData data) throws IOException {
        System.out.println("╔" + "═".repeat(78) + "╗");
        System.out.println("║" + centerText("DEPLOYMENT TRACKING - ALL ENVIRONMENTS", 78) + "║");
        System.out.println("╠" + "═".repeat(78) + "╣");

        System.out.println(
                "║  Total Deployments Tracked: "
                        + padRight(String.valueOf(data.totalDeployments), 47)
                        + "║");
        System.out.println(
                "║  Active Environments: "
                        + padRight(String.valueOf(data.environments.size()), 52)
                        + "║");
        System.out.println("╚" + "═".repeat(78) + "╝\n");

        // Print each environment
        for (DeploymentTrackingService.EnvironmentDeploymentData env : data.environments) {
            printEnvironmentDeployment(env);
        }
    }

    /** Print individual environment deployment data */
    public static void printEnvironmentDeployment(
            DeploymentTrackingService.EnvironmentDeploymentData env) throws IOException {
        System.out.println("┌" + "─".repeat(78) + "┐");
        System.out.println(
                "│" + centerText("ENVIRONMENT: " + env.environmentName.toUpperCase(), 78) + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        // Current status
        String statusIcon = getDeploymentStatusIcon(env.currentStatus);
        System.out.println(
                "│  Current Status: "
                        + padRight(statusIcon + " " + env.currentStatus.toUpperCase(), 58)
                        + "║");

        if (env.latestDeployment != null) {
            String commit = env.latestDeployment.getSha().substring(0, 7);
            String time = formatTimeAgo(env.latestDeployment.getCreatedAt());

            System.out.println(
                    "│  Latest Deployment: " + padRight(commit + " (" + time + ")", 55) + "│");

            if (env.statusUpdatedAt != null) {
                System.out.println(
                        "│  Status Updated: "
                                + padRight(formatTimeAgo(env.statusUpdatedAt), 58)
                                + "│");
            }
        }

        System.out.println("├" + "─".repeat(78) + "┤");

        // Metrics
        System.out.println(
                "│  "
                        + padRight("Deployments (30d)", 25)
                        + padRight(String.valueOf(env.deploymentsLast30Days), 10)
                        + "Success Rate: "
                        + padRight(String.format("%.1f%%", env.successRate), 27)
                        + "│");
        System.out.println(
                "│  "
                        + padRight("Total Deployments", 25)
                        + padRight(String.valueOf(env.totalDeployments), 51)
                        + "│");

        // Recent deployment history
        if (!env.recentDeployments.isEmpty()) {
            System.out.println("├" + "─".repeat(78) + "┤");
            System.out.println("│  " + padRight("Recent Deployments", 76) + "│");
            System.out.println(
                    "│  "
                            + padRight("Commit", 12)
                            + padRight("Status", 15)
                            + padRight("Time", 20)
                            + padRight("By", 27)
                            + "│");

            for (int i = 0; i < Math.min(3, env.recentDeployments.size()); i++) {
                GHDeployment dep = env.recentDeployments.get(i);
                String commitShort = dep.getSha().substring(0, 7);

                var statuses = dep.listStatuses().toList();
                String status = statuses.isEmpty() ? "unknown" : statuses.get(0).getState().name();
                String statusIcon2 = getDeploymentStatusIcon(status);

                String time = formatTimeAgo(dep.getCreatedAt());
                String by = dep.getCreator().getLogin();

                System.out.println(
                        "│  "
                                + padRight(commitShort, 12)
                                + padRight(statusIcon2 + " " + status, 15)
                                + padRight(time, 20)
                                + padRight(truncate(by, 25), 27)
                                + "│");
            }
        }

        System.out.println("└" + "─".repeat(78) + "┘\n");
    }

    /** Print deployment history for a specific environment */
    public static void printDeploymentHistory(
            String environment, List<DeploymentTrackingService.DeploymentHistoryEntry> history) {
        if (history.isEmpty()) {
            return;
        }

        System.out.println("┌" + "─".repeat(78) + "┐");
        System.out.println(
                "│" + centerText("DEPLOYMENT HISTORY - " + environment.toUpperCase(), 78) + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        System.out.println(
                "│  "
                        + padRight("Commit", 10)
                        + padRight("Status", 12)
                        + padRight("Deployed", 18)
                        + padRight("By", 15)
                        + padRight("Message", 21)
                        + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        for (DeploymentTrackingService.DeploymentHistoryEntry entry : history) {
            String commit = entry.commitSha.substring(0, 7);
            String statusIcon = getDeploymentStatusIcon(entry.status);
            String status = statusIcon + " " + entry.status;
            String time = formatTimeAgo(entry.deployedAt);
            String by = truncate(entry.deployedBy, 13);
            String message = truncate(entry.commitMessage, 19);

            System.out.println(
                    "│  "
                            + padRight(commit, 10)
                            + padRight(status, 12)
                            + padRight(time, 18)
                            + padRight(by, 15)
                            + padRight(message, 21)
                            + "│");
        }

        System.out.println("└" + "─".repeat(78) + "┘\n");
    }

    /** Print deployment comparison */
    public static void printDeploymentComparison(
            DeploymentTrackingService.DeploymentComparisonData comparison) throws Exception {
        if (comparison == null) {
            return;
        }

        System.out.println("┌" + "─".repeat(78) + "┐");
        System.out.println("│" + centerText("DEPLOYMENT COMPARISON", 78) + "│");
        System.out.println("├" + "─".repeat(78) + "┤");

        // Current deployment
        System.out.println(
                "│  Current: "
                        + comparison.currentDeployment.getSha().substring(0, 7)
                        + " ".repeat(61)
                        + "│");
        System.out.println(
                "│    "
                        + padRight(
                                truncate(
                                        comparison.currentCommit.getCommitShortInfo().getMessage(),
                                        72),
                                74)
                        + "│");
        System.out.println(
                "│    Deployed: "
                        + padRight(formatTimeAgo(comparison.currentDeployment.getCreatedAt()), 62)
                        + "│");

        System.out.println("│  " + " ".repeat(76) + "│");

        // Previous deployment
        System.out.println(
                "│  Previous: "
                        + comparison.previousDeployment.getSha().substring(0, 7)
                        + " ".repeat(59)
                        + "│");
        System.out.println(
                "│    "
                        + padRight(
                                truncate(
                                        comparison.previousCommit.getCommitShortInfo().getMessage(),
                                        72),
                                74)
                        + "│");
        System.out.println(
                "│    Deployed: "
                        + padRight(formatTimeAgo(comparison.previousDeployment.getCreatedAt()), 62)
                        + "│");

        System.out.println("├" + "─".repeat(78) + "┤");

        // Time between deployments
        String timeBetween = formatDuration(comparison.timeBetweenDeployments.toSeconds());
        System.out.println("│  Time Between Deployments: " + padRight(timeBetween, 48) + "│");

        // Changes
        var files = comparison.comparison.getFiles();
        System.out.println("│  Files Changed: " + padRight(String.valueOf(files.length), 59) + "│");
        System.out.println(
                "│  Total Commits: "
                        + padRight(String.valueOf(comparison.comparison.getTotalCommits()), 59)
                        + "│");

        if (files.length > 0) {
            System.out.println("├" + "─".repeat(78) + "┤");
            System.out.println("│  " + padRight("Top Changed Files", 76) + "│");

            for (int i = 0; i < Math.min(5, files.length); i++) {
                var file = files[i];
                String fileName = truncate(file.getFileName(), 50);
                String changes = "+" + file.getLinesAdded() + " -" + file.getLinesDeleted();

                System.out.println("│    " + padRight(fileName, 52) + padRight(changes, 22) + "│");
            }

            if (files.length > 5) {
                System.out.println(
                        "│    ... and "
                                + (files.length - 5)
                                + " more files"
                                + " ".repeat(54)
                                + "│");
            }
        }

        System.out.println("└" + "─".repeat(78) + "┘\n");
    }

    /** Print overall deployment metrics */
    public static void printDeploymentMetrics(DeploymentTrackingService.DeploymentMetrics metrics) {
        System.out.println("╔" + "═".repeat(78) + "╗");
        System.out.println("║" + centerText("DEPLOYMENT METRICS", 78) + "║");
        System.out.println("╠" + "═".repeat(78) + "╣");

        System.out.println(
                "║  Total Deployments: "
                        + padRight(String.valueOf(metrics.totalDeployments), 55)
                        + "║");
        System.out.println("║  " + " ".repeat(76) + "║");
        System.out.println(
                "║  Deployments Today: "
                        + padRight(String.valueOf(metrics.deploymentsToday), 23)
                        + "│  Last 7 Days: "
                        + padRight(String.valueOf(metrics.deploymentsLast7Days), 23)
                        + "║");
        System.out.println(
                "║  Avg/Day: "
                        + padRight(String.format("%.1f", metrics.avgDeploymentsPerDay), 33)
                        + "│  Success Rate: "
                        + padRight(String.format("%.1f%%", metrics.overallSuccessRate), 21)
                        + "║");
        System.out.println("║  " + " ".repeat(76) + "║");
        System.out.println(
                "║  Active Environments: "
                        + padRight(String.valueOf(metrics.environmentCount), 52)
                        + "║");

        System.out.println("╚" + "═".repeat(78) + "╝\n");
    }

    // Helper methods

    private static String getDeploymentStatusIcon(String status) {
        if (status == null) return "•";
        return switch (status.toLowerCase()) {
            case "success" -> "✓";
            case "failure", "error" -> "✗";
            case "in_progress", "pending", "queued" -> "⏳";
            case "inactive" -> "○";
            default -> "•";
        };
    }

    private static String formatTimeAgo(Date date) {
        if (date == null) return "N/A";

        Instant instant = date.toInstant();
        Duration duration = Duration.between(instant, Instant.now());

        long seconds = duration.getSeconds();
        if (seconds < 60) return seconds + "s ago";
        if (seconds < 3600) return (seconds / 60) + "m ago";
        if (seconds < 86400) return (seconds / 3600) + "h ago";
        return (seconds / 86400) + "d ago";
    }

    private static String formatDuration(double seconds) {
        if (seconds == 0) return "N/A";

        long s = (long) seconds;
        if (s < 60) return s + "s";
        if (s < 3600) return (s / 60) + "m " + (s % 60) + "s";
        if (s < 86400) return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
        return (s / 86400) + "d " + ((s % 86400) / 3600) + "h";
    }

    private static String padRight(String text, int length) {
        if (text.length() >= length) return text.substring(0, length);
        return text + " ".repeat(length - text.length());
    }

    private static String centerText(String text, int width) {
        int padding = (width - text.length()) / 2;
        int rightPadding = width - text.length() - padding;
        return " ".repeat(Math.max(0, padding)) + text + " ".repeat(Math.max(0, rightPadding));
    }

    private static String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + "...";
    }
}
