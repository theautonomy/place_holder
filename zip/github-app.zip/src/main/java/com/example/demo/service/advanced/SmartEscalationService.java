package com.example.demo.service.advanced;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import com.example.demo.entity.BuildFailure;
import com.example.demo.repository.BuildFailureRepository;
import com.example.demo.service.rag.EmbeddingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Smart Escalation Service Intelligently recommends who should handle a build failure based on
 * historical expertise and patterns
 */
@Service
public class SmartEscalationService {

    private static final Logger logger = LoggerFactory.getLogger(SmartEscalationService.class);

    private final BuildFailureRepository buildFailureRepository;
    private final EmbeddingService embeddingService;

    private static final double NOVEL_ERROR_THRESHOLD = 0.3; // Cosine distance
    private static final int EXPERTISE_WINDOW_MONTHS = 6;
    private static final int MIN_FIXES_FOR_EXPERT = 2;

    public SmartEscalationService(
            BuildFailureRepository buildFailureRepository, EmbeddingService embeddingService) {
        this.buildFailureRepository = buildFailureRepository;
        this.embeddingService = embeddingService;
    }

    /**
     * Determine if and how a build failure should be escalated
     *
     * @param failure BuildFailure to analyze
     * @return Escalation recommendation
     */
    public EscalationRecommendation analyzeEscalation(BuildFailure failure) {

        logger.info("Analyzing escalation for failure ID: {}", failure.getId());

        // Generate embedding for the error
        String textToEmbed = buildEmbeddingText(failure);
        float[] embedding = embeddingService.generateEmbedding(textToEmbed);
        String embeddingStr = embeddingService.vectorToString(embedding);

        // Check if this is a novel error
        List<BuildFailure> similarFailures =
                buildFailureRepository.findSimilarFailures(embeddingStr, NOVEL_ERROR_THRESHOLD, 10);

        if (similarFailures.isEmpty()) {
            // Novel error - find expert for this area
            logger.info("Novel error detected - finding area expert");
            return findExpertForNovelError(failure);
        } else {
            // Known error - find who usually fixes it
            logger.info("Known error - finding usual resolver");
            return findUsualResolver(failure, similarFailures);
        }
    }

    /**
     * Recommend expert for a specific error message
     *
     * @param errorMessage Error message
     * @param repository Repository name
     * @return List of recommended experts
     */
    public List<Expert> recommendExpert(String errorMessage, String repository) {

        logger.info("Recommending expert for error in repository: {}", repository);

        // Generate embedding
        float[] embedding = embeddingService.generateEmbedding(errorMessage);
        String embeddingStr = embeddingService.vectorToString(embedding);

        // Find similar resolved failures
        List<BuildFailure> similarResolved =
                buildFailureRepository.findSimilarResolvedFailures(embeddingStr, 0.3, 20);

        if (similarResolved.isEmpty()) {
            logger.info("No similar resolved failures found");
            return List.of();
        }

        // Group by fixer and calculate expertise scores
        Map<String, ExpertiseData> expertiseMap = new HashMap<>();

        for (BuildFailure resolved : similarResolved) {
            if (resolved.getFixedBy() == null || resolved.getFixedBy().isEmpty()) {
                continue;
            }

            String fixer = resolved.getFixedBy();
            ExpertiseData data = expertiseMap.computeIfAbsent(fixer, k -> new ExpertiseData());

            data.fixCount++;
            if (resolved.getSolutionEffectiveness() > 0) {
                data.totalEffectiveness += resolved.getSolutionEffectiveness();
                data.effectivenessCount++;
            }
            if (resolved.getTimeToFixMinutes() != null && resolved.getTimeToFixMinutes() > 0) {
                data.totalFixTime += resolved.getTimeToFixMinutes();
                data.fixTimeCount++;
            }
        }

        // Convert to Expert records and sort
        List<Expert> experts = new ArrayList<>();
        for (Map.Entry<String, ExpertiseData> entry : expertiseMap.entrySet()) {
            if (entry.getValue().fixCount >= MIN_FIXES_FOR_EXPERT) {
                ExpertiseData data = entry.getValue();
                double avgEffectiveness =
                        data.effectivenessCount > 0
                                ? data.totalEffectiveness / data.effectivenessCount
                                : 0.5;
                double avgFixTime =
                        data.fixTimeCount > 0 ? data.totalFixTime / data.fixTimeCount : 60.0;

                // Calculate overall score (higher is better)
                double score =
                        (data.fixCount * avgEffectiveness * 10) / Math.max(1, avgFixTime / 60.0);

                experts.add(
                        new Expert(
                                entry.getKey(),
                                data.fixCount,
                                avgEffectiveness,
                                avgFixTime,
                                score));
            }
        }

        // Sort by score descending
        experts.sort((a, b) -> Double.compare(b.score(), a.score()));

        // Return top 3
        List<Expert> topExperts = experts.stream().limit(3).collect(Collectors.toList());

        logger.info("Found {} experts", topExperts.size());
        return topExperts;
    }

    /**
     * Get estimated resolution time based on historical data
     *
     * @param errorMessage Error message
     * @param repository Repository name
     * @return Estimated time range in minutes
     */
    public TimeEstimate estimateResolutionTime(String errorMessage, String repository) {

        logger.info("Estimating resolution time for repository: {}", repository);

        // Generate embedding
        float[] embedding = embeddingService.generateEmbedding(errorMessage);
        String embeddingStr = embeddingService.vectorToString(embedding);

        // Find similar resolved failures
        List<BuildFailure> similarResolved =
                buildFailureRepository.findSimilarResolvedFailures(embeddingStr, 0.3, 20);

        if (similarResolved.isEmpty()) {
            // No historical data - return general estimate
            return new TimeEstimate(30, 120, 60, "LOW", "No historical data available");
        }

        // Calculate statistics
        List<Integer> fixTimes =
                similarResolved.stream()
                        .filter(f -> f.getTimeToFixMinutes() != null && f.getTimeToFixMinutes() > 0)
                        .map(BuildFailure::getTimeToFixMinutes)
                        .sorted()
                        .collect(Collectors.toList());

        if (fixTimes.isEmpty()) {
            return new TimeEstimate(30, 120, 60, "LOW", "Historical data incomplete");
        }

        int minTime = fixTimes.get(0);
        int maxTime = fixTimes.get(fixTimes.size() - 1);
        double avgTime = fixTimes.stream().mapToInt(Integer::intValue).average().orElse(60.0);

        // Calculate percentiles
        int p25 = fixTimes.get(Math.min(fixTimes.size() / 4, fixTimes.size() - 1));
        int p75 = fixTimes.get(Math.min((fixTimes.size() * 3) / 4, fixTimes.size() - 1));

        String confidence =
                fixTimes.size() >= 10 ? "HIGH" : fixTimes.size() >= 5 ? "MEDIUM" : "LOW";
        String explanation =
                String.format(
                        "Based on %d similar past failures. 50%% resolved in %d-%d minutes",
                        fixTimes.size(), p25, p75);

        logger.info(
                "Estimated time: {} minutes (range: {}-{}), confidence: {}",
                (int) avgTime,
                minTime,
                maxTime,
                confidence);

        return new TimeEstimate(minTime, maxTime, (int) avgTime, confidence, explanation);
    }

    private EscalationRecommendation findExpertForNovelError(BuildFailure failure) {
        String repository = failure.getRepository();
        String failedStep = failure.getFailedStep();

        // Find developers with most experience in the failed area
        LocalDateTime since = LocalDateTime.now().minusMonths(EXPERTISE_WINDOW_MONTHS);
        List<BuildFailure> recentResolvedInRepo =
                buildFailureRepository.findByRepositoryAndResolvedTrueAndResolvedAtAfter(
                        repository, since);

        // Group by fixer
        Map<String, AreaExpertise> expertise = new HashMap<>();

        for (BuildFailure resolved : recentResolvedInRepo) {
            if (resolved.getFixedBy() == null || resolved.getFixedBy().isEmpty()) {
                continue;
            }

            String fixer = resolved.getFixedBy();
            AreaExpertise area = expertise.computeIfAbsent(fixer, k -> new AreaExpertise());

            area.totalFixes++;

            // Bonus points for same failed step
            if (failedStep != null
                    && resolved.getFailedStep() != null
                    && resolved.getFailedStep().equals(failedStep)) {
                area.sameStepFixes++;
            }

            if (resolved.getSolutionEffectiveness() > 0) {
                area.totalEffectiveness += resolved.getSolutionEffectiveness();
            }
        }

        // Convert to experts
        List<Expert> experts = new ArrayList<>();
        for (Map.Entry<String, AreaExpertise> entry : expertise.entrySet()) {
            if (entry.getValue().totalFixes >= MIN_FIXES_FOR_EXPERT) {
                AreaExpertise area = entry.getValue();
                double avgEffectiveness = area.totalEffectiveness / area.totalFixes;

                // Score = fixes + (same_step_bonus * 3) + effectiveness
                double score = area.totalFixes + (area.sameStepFixes * 3) + (avgEffectiveness * 10);

                experts.add(
                        new Expert(
                                entry.getKey(),
                                area.totalFixes,
                                avgEffectiveness,
                                0.0, // Unknown time
                                score));
            }
        }

        experts.sort((a, b) -> Double.compare(b.score(), a.score()));
        List<Expert> topExperts = experts.stream().limit(3).collect(Collectors.toList());

        String reason =
                String.format(
                        "This error pattern has not been seen before (0 similar occurrences). Recommending developers with most experience in %s",
                        repository);

        List<String> suggestedActions =
                Arrays.asList(
                        "Assign to recommended expert",
                        "Schedule pair programming session",
                        "Document the solution thoroughly for future reference",
                        "Add automated tests to prevent recurrence");

        // Estimate time for novel errors
        TimeEstimate estimate =
                new TimeEstimate(45, 180, 90, "LOW", "Novel errors typically take longer");

        return new EscalationRecommendation(
                true, "NOVEL_ERROR", reason, topExperts, estimate, suggestedActions);
    }

    private EscalationRecommendation findUsualResolver(
            BuildFailure failure, List<BuildFailure> similarFailures) {

        // Find who fixed similar issues
        Map<String, ResolverStats> resolverStats = new HashMap<>();

        for (BuildFailure similar : similarFailures) {
            if (!Boolean.TRUE.equals(similar.getResolved()) || similar.getFixedBy() == null) {
                continue;
            }

            String fixer = similar.getFixedBy();
            ResolverStats stats = resolverStats.computeIfAbsent(fixer, k -> new ResolverStats());

            stats.fixCount++;
            if (similar.getTimeToFixMinutes() != null) {
                stats.totalTime += similar.getTimeToFixMinutes();
                stats.timeCount++;
            }
            if (similar.getSolutionEffectiveness() > 0.7f) {
                stats.effectiveFixes++;
            }
        }

        // Convert to experts
        List<Expert> experts = new ArrayList<>();
        for (Map.Entry<String, ResolverStats> entry : resolverStats.entrySet()) {
            ResolverStats stats = entry.getValue();
            if (stats.fixCount >= 1) {
                double avgTime =
                        stats.timeCount > 0 ? (double) stats.totalTime / stats.timeCount : 0;
                double effectiveness = (double) stats.effectiveFixes / stats.fixCount;
                double score = stats.fixCount * effectiveness * 10;

                experts.add(
                        new Expert(entry.getKey(), stats.fixCount, effectiveness, avgTime, score));
            }
        }

        experts.sort((a, b) -> Double.compare(b.score(), a.score()));
        List<Expert> topExperts = experts.stream().limit(3).collect(Collectors.toList());

        // Calculate time estimate
        List<Integer> times =
                similarFailures.stream()
                        .filter(f -> f.getTimeToFixMinutes() != null && f.getTimeToFixMinutes() > 0)
                        .map(BuildFailure::getTimeToFixMinutes)
                        .collect(Collectors.toList());

        TimeEstimate estimate;
        if (!times.isEmpty()) {
            int min = Collections.min(times);
            int max = Collections.max(times);
            int avg = (int) times.stream().mapToInt(Integer::intValue).average().orElse(30);
            estimate =
                    new TimeEstimate(
                            min,
                            max,
                            avg,
                            "HIGH",
                            String.format(
                                    "Based on %d similar past failures", similarFailures.size()));
        } else {
            estimate =
                    new TimeEstimate(
                            15, 60, 30, "MEDIUM", "Estimated based on similar error types");
        }

        long resolvedCount =
                similarFailures.stream().filter(f -> Boolean.TRUE.equals(f.getResolved())).count();
        double resolutionRate = (double) resolvedCount / similarFailures.size();

        boolean shouldEscalate = resolutionRate < 0.5 || estimate.averageMinutes() > 120;

        String reason =
                String.format(
                        "This error has occurred %d times before with %.0f%% resolution rate",
                        similarFailures.size(), resolutionRate * 100);

        List<String> suggestedActions =
                topExperts.isEmpty()
                        ? Arrays.asList(
                                "This is a known issue but no clear expert",
                                "Review past solutions in the knowledge base",
                                "Consider creating documentation for this error")
                        : Arrays.asList(
                                "Consult with recommended expert",
                                "Review their past solutions",
                                "Follow established fix patterns");

        return new EscalationRecommendation(
                shouldEscalate,
                shouldEscalate ? "DIFFICULT_KNOWN_ERROR" : "ROUTINE_KNOWN_ERROR",
                reason,
                topExperts,
                estimate,
                suggestedActions);
    }

    private String buildEmbeddingText(BuildFailure failure) {
        StringBuilder text = new StringBuilder();

        if (failure.getFailedStep() != null) {
            text.append("Failed Step: ").append(failure.getFailedStep()).append("\n");
        }

        text.append("Error: ").append(failure.getErrorMessage());

        if (failure.getErrorStacktrace() != null && !failure.getErrorStacktrace().isEmpty()) {
            String truncated =
                    failure.getErrorStacktrace()
                            .substring(0, Math.min(500, failure.getErrorStacktrace().length()));
            text.append("\nStacktrace: ").append(truncated);
        }

        return text.toString();
    }

    // Helper classes for tracking expertise
    private static class ExpertiseData {
        int fixCount = 0;
        double totalEffectiveness = 0;
        int effectivenessCount = 0;
        int totalFixTime = 0;
        int fixTimeCount = 0;
    }

    private static class AreaExpertise {
        int totalFixes = 0;
        int sameStepFixes = 0;
        double totalEffectiveness = 0;
    }

    private static class ResolverStats {
        int fixCount = 0;
        int totalTime = 0;
        int timeCount = 0;
        int effectiveFixes = 0;
    }

    /** Expert recommendation */
    public record Expert(
            String name,
            int fixCount,
            double avgEffectiveness,
            double avgFixTimeMinutes,
            double score) {}

    /** Time estimate for resolution */
    public record TimeEstimate(
            int minMinutes,
            int maxMinutes,
            int averageMinutes,
            String confidence,
            String explanation) {}

    /** Escalation recommendation */
    public record EscalationRecommendation(
            boolean shouldEscalate,
            String escalationType,
            String reason,
            List<Expert> recommendedExperts,
            TimeEstimate timeEstimate,
            List<String> suggestedActions) {}
}
