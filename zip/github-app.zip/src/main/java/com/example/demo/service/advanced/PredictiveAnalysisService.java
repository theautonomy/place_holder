package com.example.demo.service.advanced;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.example.demo.entity.BuildFailure;
import com.example.demo.entity.DeploymentHistory;
import com.example.demo.repository.BuildFailureRepository;
import com.example.demo.repository.DeploymentHistoryRepository;
import com.example.demo.service.rag.EmbeddingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Predictive Analysis Service Predicts potential build failures before they happen based on code
 * changes and historical patterns
 */
@Service
public class PredictiveAnalysisService {

    private static final Logger logger = LoggerFactory.getLogger(PredictiveAnalysisService.class);

    private final BuildFailureRepository buildFailureRepository;
    private final DeploymentHistoryRepository deploymentRepository;
    private final EmbeddingService embeddingService;

    private static final int ANALYSIS_WINDOW_HOURS = 1;
    private static final int SIMILAR_DEPLOYMENTS_LIMIT = 20;
    private static final double HIGH_RISK_THRESHOLD = 0.5;

    public PredictiveAnalysisService(
            BuildFailureRepository buildFailureRepository,
            DeploymentHistoryRepository deploymentRepository,
            EmbeddingService embeddingService) {
        this.buildFailureRepository = buildFailureRepository;
        this.deploymentRepository = deploymentRepository;
        this.embeddingService = embeddingService;
    }

    /**
     * Predict the likelihood of build failure based on changed files
     *
     * @param repository Repository name
     * @param branch Branch name
     * @param changedFiles List of files being changed
     * @return FailurePrediction with probability and likely error types
     */
    public FailurePrediction predictBuildFailure(
            String repository, String branch, List<String> changedFiles) {

        logger.info(
                "Predicting build failure for repository: {}, branch: {}, files: {}",
                repository,
                branch,
                changedFiles.size());

        // Build description of changes
        String changeDescription = buildChangeDescription(changedFiles);

        // Generate embedding for the changes
        float[] embedding = embeddingService.generateEmbedding(changeDescription);
        String embeddingStr = embeddingService.vectorToString(embedding);

        // Find similar past deployments using vector similarity
        List<DeploymentHistory> similarDeployments =
                deploymentRepository.findSimilarDeployments(
                        embeddingStr, 0.3, SIMILAR_DEPLOYMENTS_LIMIT);

        // Fallback: If no vector matches found, try finding by file names
        if (similarDeployments.isEmpty()) {
            logger.info("No vector similarity matches, trying file-based search...");
            similarDeployments = findDeploymentsByFiles(repository, changedFiles);
        }

        if (similarDeployments.isEmpty()) {
            logger.info("No similar deployments found, returning low-confidence prediction");
            return new FailurePrediction(
                    0.3f,
                    List.of(),
                    "Low confidence - no similar historical deployments found",
                    "LOW");
        }

        // Find failures that occurred shortly after similar deployments
        Map<String, Integer> errorTypeCounts = new HashMap<>();
        int totalFollowingFailures = 0;

        for (DeploymentHistory deployment : similarDeployments) {
            // Find failures within 1 hour after deployment
            LocalDateTime deploymentTime = deployment.getDeployedAt();
            LocalDateTime windowEnd = deploymentTime.plusHours(ANALYSIS_WINDOW_HOURS);

            List<BuildFailure> followingFailures =
                    buildFailureRepository.findByRepositoryAndFailedAtBetween(
                            repository, deploymentTime, windowEnd);

            for (BuildFailure failure : followingFailures) {
                String errorType = classifyErrorType(failure);
                errorTypeCounts.put(errorType, errorTypeCounts.getOrDefault(errorType, 0) + 1);
                totalFollowingFailures++;
            }
        }

        // Calculate failure probability
        float failureProbability =
                (float) totalFollowingFailures / Math.max(1, similarDeployments.size());

        // Build list of predicted errors
        List<PredictedError> predictedErrors = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : errorTypeCounts.entrySet()) {
            predictedErrors.add(
                    new PredictedError(
                            entry.getKey(),
                            entry.getValue(),
                            (float) entry.getValue() / totalFollowingFailures));
        }

        // Sort by occurrence count
        predictedErrors.sort((a, b) -> Integer.compare(b.occurrenceCount(), a.occurrenceCount()));

        // Build recommendation
        String recommendation = buildRecommendation(failureProbability, predictedErrors);

        // Determine confidence
        String confidence = similarDeployments.size() >= 10 ? "HIGH" : "MEDIUM";

        logger.info(
                "Predicted failure probability: {}, based on {} similar deployments",
                failureProbability,
                similarDeployments.size());

        return new FailurePrediction(
                failureProbability, predictedErrors, recommendation, confidence);
    }

    /**
     * Analyze file-specific risk based on historical failure patterns
     *
     * @param repository Repository name
     * @param changedFiles Files being changed
     * @return List of risky files with their history
     */
    public List<RiskyFileAnalysis> analyzeFileRisk(String repository, List<String> changedFiles) {

        logger.info("Analyzing file risk for {} files in {}", changedFiles.size(), repository);

        List<RiskyFileAnalysis> riskyFiles = new ArrayList<>();

        for (String filePath : changedFiles) {
            // Find all deployments that modified this file and had failures
            List<DeploymentHistory> deploymentsWithFile =
                    deploymentRepository.findByRepositoryAndChangedFilesContaining(
                            repository, filePath);

            int totalModifications = deploymentsWithFile.size();
            int modificationsWithIncidents = 0;
            List<String> pastIssues = new ArrayList<>();

            for (DeploymentHistory deployment : deploymentsWithFile) {
                if (!deployment.getActualSuccess()
                        || (deployment.getIncidentSeverity() != null
                                && !deployment.getIncidentSeverity().equals("none"))) {
                    modificationsWithIncidents++;
                    if (deployment.getIssuesEncountered() != null) {
                        for (String issue : deployment.getIssuesEncountered()) {
                            if (!pastIssues.contains(issue)) {
                                pastIssues.add(issue);
                            }
                        }
                    }
                }
            }

            if (totalModifications > 0) {
                float incidentRate = (float) modificationsWithIncidents / totalModifications;

                // Only include files with significant risk
                if (incidentRate > 0.1) { // More than 10% incident rate
                    riskyFiles.add(
                            new RiskyFileAnalysis(
                                    filePath,
                                    incidentRate,
                                    totalModifications,
                                    modificationsWithIncidents,
                                    pastIssues));
                }
            }
        }

        // Sort by incident rate
        riskyFiles.sort((a, b) -> Float.compare(b.incidentRate(), a.incidentRate()));

        logger.info("Found {} risky files", riskyFiles.size());
        return riskyFiles;
    }

    private String buildChangeDescription(List<String> changedFiles) {
        StringBuilder desc = new StringBuilder();
        desc.append("Files being changed: ");
        desc.append(String.join(", ", changedFiles));

        // Detect patterns
        boolean hasAuthChanges =
                changedFiles.stream().anyMatch(f -> f.contains("auth") || f.contains("Auth"));
        boolean hasDatabaseChanges =
                changedFiles.stream().anyMatch(f -> f.contains("sql") || f.contains("migration"));
        boolean hasConfigChanges =
                changedFiles.stream()
                        .anyMatch(
                                f ->
                                        f.contains("config")
                                                || f.contains("properties")
                                                || f.contains("yml"));

        if (hasAuthChanges) {
            desc.append(". Includes authentication changes");
        }
        if (hasDatabaseChanges) {
            desc.append(". Includes database changes");
        }
        if (hasConfigChanges) {
            desc.append(". Includes configuration changes");
        }

        return desc.toString();
    }

    private String classifyErrorType(BuildFailure failure) {
        String errorMessage = failure.getErrorMessage().toLowerCase();

        if (errorMessage.contains("nullpointer") || errorMessage.contains("null")) {
            return "NullPointerException";
        } else if (errorMessage.contains("timeout")) {
            return "Timeout";
        } else if (errorMessage.contains("authentication") || errorMessage.contains("auth")) {
            return "AuthenticationException";
        } else if (errorMessage.contains("database") || errorMessage.contains("sql")) {
            return "DatabaseException";
        } else if (errorMessage.contains("dependency") || errorMessage.contains("import")) {
            return "DependencyError";
        } else if (errorMessage.contains("test")) {
            return "TestFailure";
        } else if (errorMessage.contains("compile") || errorMessage.contains("syntax")) {
            return "CompilationError";
        } else {
            return "GeneralError";
        }
    }

    private String buildRecommendation(
            float failureProbability, List<PredictedError> predictedErrors) {
        StringBuilder recommendation = new StringBuilder();

        if (failureProbability >= HIGH_RISK_THRESHOLD) {
            recommendation.append(
                    String.format(
                            "⚠️ HIGH RISK: %.0f%% probability of build failure. ",
                            failureProbability * 100));
            recommendation.append("RECOMMENDATIONS:\n");
            recommendation.append("- Run integration tests locally before pushing\n");

            if (!predictedErrors.isEmpty()) {
                PredictedError topError = predictedErrors.get(0);
                recommendation
                        .append("- Pay special attention to: ")
                        .append(topError.errorType())
                        .append("\n");
            }

            recommendation.append("- Consider breaking changes into smaller commits\n");
            recommendation.append("- Have a rollback plan ready");
        } else if (failureProbability >= 0.3) {
            recommendation.append(
                    String.format(
                            "⚡ MEDIUM RISK: %.0f%% probability of build failure. ",
                            failureProbability * 100));
            recommendation.append("RECOMMENDATIONS:\n");
            recommendation.append("- Run tests locally before pushing\n");
            recommendation.append("- Monitor build logs carefully");
        } else {
            recommendation.append(
                    String.format(
                            "✅ LOW RISK: %.0f%% probability of build failure. ",
                            failureProbability * 100));
            recommendation.append("Proceed with normal testing practices.");
        }

        return recommendation.toString();
    }

    /** Fallback method: Find deployments by matching file names (for testing with sample data) */
    private List<DeploymentHistory> findDeploymentsByFiles(
            String repository, List<String> changedFiles) {
        List<DeploymentHistory> result = new ArrayList<>();

        for (String file : changedFiles) {
            List<DeploymentHistory> matchingDeployments =
                    deploymentRepository.findByRepositoryAndChangedFilesContaining(
                            repository, file);
            result.addAll(matchingDeployments);
        }

        // Remove duplicates
        return result.stream()
                .distinct()
                .limit(SIMILAR_DEPLOYMENTS_LIMIT)
                .collect(Collectors.toList());
    }

    /** Predicted error type with occurrence statistics */
    public record PredictedError(String errorType, int occurrenceCount, float probability) {}

    /** Failure prediction result */
    public record FailurePrediction(
            float failureProbability,
            List<PredictedError> predictedErrors,
            String recommendation,
            String confidence) {}

    /** Risky file analysis result */
    public record RiskyFileAnalysis(
            String filePath,
            float incidentRate,
            int totalModifications,
            int modificationsWithIncidents,
            List<String> pastIssues) {}
}
