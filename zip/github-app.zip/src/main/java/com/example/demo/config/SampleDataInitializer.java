package com.example.demo.config;

import java.time.LocalDateTime;

import com.example.demo.entity.BuildFailure;
import com.example.demo.entity.DeploymentHistory;
import com.example.demo.entity.FileRiskHistory;
import com.example.demo.repository.BuildFailureRepository;
import com.example.demo.repository.DeploymentHistoryRepository;
import com.example.demo.repository.FileRiskHistoryRepository;
import com.example.demo.service.rag.EmbeddingService;
import com.pgvector.PGvector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * Sample Data Initializer Loads test data for Phase 4 Advanced Features demonstration
 *
 * <p>This initializer only runs when the 'sample-data' profile is active. To enable: mvn
 * spring-boot:run -Dspring-boot.run.profiles=sample-data
 *
 * <p>Or add to application.properties: spring.profiles.active=sample-data
 */
@Component
@Profile("sample-data")
public class SampleDataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(SampleDataInitializer.class);

    private final BuildFailureRepository buildFailureRepository;
    private final DeploymentHistoryRepository deploymentHistoryRepository;
    private final FileRiskHistoryRepository fileRiskHistoryRepository;
    private final EmbeddingService embeddingService;

    public SampleDataInitializer(
            BuildFailureRepository buildFailureRepository,
            DeploymentHistoryRepository deploymentHistoryRepository,
            FileRiskHistoryRepository fileRiskHistoryRepository,
            EmbeddingService embeddingService) {
        this.buildFailureRepository = buildFailureRepository;
        this.deploymentHistoryRepository = deploymentHistoryRepository;
        this.fileRiskHistoryRepository = fileRiskHistoryRepository;
        this.embeddingService = embeddingService;
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("========================================");
        logger.info("Loading Sample Data for Phase 4 Advanced Features");
        logger.info("========================================");

        // Check if data already exists
        long existingFailures = buildFailureRepository.count();
        if (existingFailures > 1) {
            logger.info(
                    "Sample data already exists ({} build failures). Skipping...",
                    existingFailures);
            return;
        }

        loadBuildFailures();
        loadDeploymentHistory();
        loadFileRiskHistory();

        logger.info("========================================");
        logger.info("✅ Sample data loaded successfully!");
        logger.info("BUILD FAILURES: {}", buildFailureRepository.count());
        logger.info("DEPLOYMENT HISTORY: {}", deploymentHistoryRepository.count());
        logger.info("FILE RISK HISTORY: {}", fileRiskHistoryRepository.count());
        logger.info("========================================");
        logger.info("🚀 Ready to test! Open: http://localhost:8080/advanced-features.html");
        logger.info("========================================");
    }

    private void loadBuildFailures() {
        logger.info("Loading build failures...");

        // Scenario 1: Recurring NullPointerException (Alice is the expert)
        BuildFailure bf1 = new BuildFailure();
        bf1.setRepository("theautonomy/articles");
        bf1.setWorkflowName("build.yml");
        bf1.setRunId(1001L);
        bf1.setRunNumber(101);
        bf1.setBranch("main");
        bf1.setCommitSha("abc123");
        bf1.setErrorType("NullPointerException");
        bf1.setErrorMessage(
                "java.lang.NullPointerException: Cannot invoke \"User.getProfile()\" because \"user\" is null");
        bf1.setErrorStacktrace(
                "at com.example.UserService.authenticate(UserService.java:142)\nat com.example.AuthController.login(AuthController.java:45)");
        bf1.setFailedStep("Run Tests");
        bf1.setFailedAt(LocalDateTime.now().minusDays(15));
        bf1.setResolved(true);
        bf1.setResolutionCommit("def456");
        bf1.setResolutionDescription("Added null check before accessing user.getProfile()");
        bf1.setResolutionCodeSnippet(
                "if (user != null && user.getProfile() != null) { // safe to access }");
        bf1.setTimeToFixMinutes(12);
        bf1.setFixedBy("Alice");
        bf1.setResolvedAt(LocalDateTime.now().minusDays(15));
        bf1.setSolutionEffectiveness(0.95f);
        bf1.setTimesHelped(5);
        bf1.setAiAnalysis(
                "Null pointer exception in authentication flow. User object not validated before accessing profile.");
        bf1.setAiConfidence("HIGH");
        bf1.setErrorEmbedding(generateTestEmbedding(0.1f, 0.2f, 0.3f));
        buildFailureRepository.save(bf1);

        BuildFailure bf2 = new BuildFailure();
        bf2.setRepository("theautonomy/articles");
        bf2.setWorkflowName("build.yml");
        bf2.setRunId(1002L);
        bf2.setRunNumber(102);
        bf2.setBranch("main");
        bf2.setCommitSha("bcd234");
        bf2.setErrorType("NullPointerException");
        bf2.setErrorMessage(
                "java.lang.NullPointerException: Cannot invoke \"User.getProfile()\" because \"user\" is null");
        bf2.setErrorStacktrace("at com.example.UserService.authenticate(UserService.java:142)");
        bf2.setFailedStep("Run Tests");
        bf2.setFailedAt(LocalDateTime.now().minusDays(10));
        bf2.setResolved(true);
        bf2.setResolutionCommit("ghi789");
        bf2.setResolutionDescription("Added null check for user profile access");
        bf2.setResolutionCodeSnippet("Objects.requireNonNull(user, \"User cannot be null\")");
        bf2.setTimeToFixMinutes(8);
        bf2.setFixedBy("Alice");
        bf2.setResolvedAt(LocalDateTime.now().minusDays(10));
        bf2.setSolutionEffectiveness(0.92f);
        bf2.setTimesHelped(3);
        bf2.setAiAnalysis("Same null pointer issue, fixed with null check");
        bf2.setAiConfidence("HIGH");
        bf2.setErrorEmbedding(generateTestEmbedding(0.1f, 0.2f, 0.3f));
        buildFailureRepository.save(bf2);

        BuildFailure bf3 = new BuildFailure();
        bf3.setRepository("theautonomy/articles");
        bf3.setWorkflowName("build.yml");
        bf3.setRunId(1003L);
        bf3.setRunNumber(103);
        bf3.setBranch("develop");
        bf3.setCommitSha("cde345");
        bf3.setErrorType("NullPointerException");
        bf3.setErrorMessage("NullPointerException in UserService authentication method");
        bf3.setErrorStacktrace("at com.example.UserService.authenticate(UserService.java:142)");
        bf3.setFailedStep("Run Tests");
        bf3.setFailedAt(LocalDateTime.now().minusDays(5));
        bf3.setResolved(true);
        bf3.setResolutionCommit("jkl012");
        bf3.setResolutionDescription("Added Optional<User> pattern");
        bf3.setResolutionCodeSnippet(
                "Optional.ofNullable(user).map(User::getProfile).orElse(null)");
        bf3.setTimeToFixMinutes(15);
        bf3.setFixedBy("Alice");
        bf3.setResolvedAt(LocalDateTime.now().minusDays(5));
        bf3.setSolutionEffectiveness(0.88f);
        bf3.setTimesHelped(2);
        bf3.setAiAnalysis("Null pointer in user authentication");
        bf3.setAiConfidence("HIGH");
        bf3.setErrorEmbedding(generateTestEmbedding(0.1f, 0.2f, 0.3f));
        buildFailureRepository.save(bf3);

        // Scenario 2: Database Connection Issues (Bob is the expert)
        BuildFailure bf4 = new BuildFailure();
        bf4.setRepository("theautonomy/articles");
        bf4.setWorkflowName("build.yml");
        bf4.setRunId(2001L);
        bf4.setRunNumber(201);
        bf4.setBranch("main");
        bf4.setCommitSha("xyz123");
        bf4.setErrorType("DatabaseException");
        bf4.setErrorMessage("Database connection pool exhausted - max pool size 10 reached");
        bf4.setFailedStep("Integration Tests");
        bf4.setFailedAt(LocalDateTime.now().minusDays(20));
        bf4.setResolved(true);
        bf4.setResolutionDescription(
                "Increased connection pool size to 20 in application.properties");
        bf4.setTimeToFixMinutes(25);
        bf4.setFixedBy("Bob");
        bf4.setResolvedAt(LocalDateTime.now().minusDays(20));
        bf4.setSolutionEffectiveness(0.90f);
        bf4.setTimesHelped(4);
        bf4.setAiConfidence("HIGH");
        bf4.setErrorEmbedding(generateTestEmbedding(0.4f, 0.5f, 0.6f));
        buildFailureRepository.save(bf4);

        BuildFailure bf5 = new BuildFailure();
        bf5.setRepository("theautonomy/articles");
        bf5.setWorkflowName("build.yml");
        bf5.setRunId(2002L);
        bf5.setRunNumber(202);
        bf5.setBranch("main");
        bf5.setCommitSha("xyz234");
        bf5.setErrorType("DatabaseException");
        bf5.setErrorMessage("Connection pool exhausted under load");
        bf5.setFailedStep("Integration Tests");
        bf5.setFailedAt(LocalDateTime.now().minusDays(12));
        bf5.setResolved(true);
        bf5.setResolutionDescription("Optimized connection pool settings and added timeout");
        bf5.setTimeToFixMinutes(30);
        bf5.setFixedBy("Bob");
        bf5.setResolvedAt(LocalDateTime.now().minusDays(12));
        bf5.setSolutionEffectiveness(0.85f);
        bf5.setTimesHelped(2);
        bf5.setAiConfidence("HIGH");
        bf5.setErrorEmbedding(generateTestEmbedding(0.4f, 0.5f, 0.6f));
        buildFailureRepository.save(bf5);

        BuildFailure bf6 = new BuildFailure();
        bf6.setRepository("theautonomy/articles");
        bf6.setWorkflowName("build.yml");
        bf6.setRunId(2003L);
        bf6.setRunNumber(203);
        bf6.setBranch("develop");
        bf6.setCommitSha("xyz345");
        bf6.setErrorType("DatabaseException");
        bf6.setErrorMessage("Database connection timeout");
        bf6.setFailedStep("Integration Tests");
        bf6.setFailedAt(LocalDateTime.now().minusDays(3));
        bf6.setResolved(true);
        bf6.setResolutionDescription("Fixed connection leak in UserRepository");
        bf6.setTimeToFixMinutes(45);
        bf6.setFixedBy("Bob");
        bf6.setResolvedAt(LocalDateTime.now().minusDays(3));
        bf6.setSolutionEffectiveness(0.88f);
        bf6.setTimesHelped(1);
        bf6.setAiConfidence("MEDIUM");
        bf6.setErrorEmbedding(generateTestEmbedding(0.4f, 0.5f, 0.6f));
        buildFailureRepository.save(bf6);

        // Scenario 3: Test Timeouts (Charlie fixes these)
        BuildFailure bf7 = new BuildFailure();
        bf7.setRepository("theautonomy/articles");
        bf7.setWorkflowName("build.yml");
        bf7.setRunId(3001L);
        bf7.setRunNumber(301);
        bf7.setBranch("main");
        bf7.setCommitSha("test123");
        bf7.setErrorType("TestTimeout");
        bf7.setErrorMessage("Test execution timed out after 60 seconds");
        bf7.setFailedStep("Run Tests");
        bf7.setFailedAt(LocalDateTime.now().minusDays(8));
        bf7.setResolved(true);
        bf7.setResolutionDescription(
                "Increased test timeout to 120 seconds and optimized slow test");
        bf7.setTimeToFixMinutes(20);
        bf7.setFixedBy("Charlie");
        bf7.setResolvedAt(LocalDateTime.now().minusDays(8));
        bf7.setSolutionEffectiveness(0.85f);
        bf7.setTimesHelped(2);
        bf7.setAiConfidence("MEDIUM");
        bf7.setErrorEmbedding(generateTestEmbedding(0.7f, 0.8f, 0.9f));
        buildFailureRepository.save(bf7);

        BuildFailure bf8 = new BuildFailure();
        bf8.setRepository("theautonomy/articles");
        bf8.setWorkflowName("build.yml");
        bf8.setRunId(3002L);
        bf8.setRunNumber(302);
        bf8.setBranch("develop");
        bf8.setCommitSha("test234");
        bf8.setErrorType("TestTimeout");
        bf8.setErrorMessage("Integration test timeout");
        bf8.setFailedStep("Run Tests");
        bf8.setFailedAt(LocalDateTime.now().minusDays(4));
        bf8.setResolved(true);
        bf8.setResolutionDescription("Mocked external API calls to speed up tests");
        bf8.setTimeToFixMinutes(35);
        bf8.setFixedBy("Charlie");
        bf8.setResolvedAt(LocalDateTime.now().minusDays(4));
        bf8.setSolutionEffectiveness(0.80f);
        bf8.setTimesHelped(1);
        bf8.setAiConfidence("MEDIUM");
        bf8.setErrorEmbedding(generateTestEmbedding(0.7f, 0.8f, 0.9f));
        buildFailureRepository.save(bf8);

        // Scenario 4: Recent Unresolved Failures
        BuildFailure bf9 = new BuildFailure();
        bf9.setRepository("theautonomy/articles");
        bf9.setWorkflowName("build.yml");
        bf9.setRunId(4001L);
        bf9.setRunNumber(401);
        bf9.setBranch("feature/auth");
        bf9.setCommitSha("new123");
        bf9.setErrorType("AuthenticationException");
        bf9.setErrorMessage("Authentication failed: Invalid credentials");
        bf9.setFailedStep("Run Tests");
        bf9.setFailedAt(LocalDateTime.now().minusHours(1));
        bf9.setResolved(false);
        bf9.setAiConfidence("MEDIUM");
        bf9.setErrorEmbedding(generateTestEmbedding(0.15f, 0.25f, 0.35f));
        buildFailureRepository.save(bf9);

        BuildFailure bf10 = new BuildFailure();
        bf10.setRepository("theautonomy/articles");
        bf10.setWorkflowName("build.yml");
        bf10.setRunId(4002L);
        bf10.setRunNumber(402);
        bf10.setBranch("feature/payment");
        bf10.setCommitSha("new234");
        bf10.setErrorType("CompilationError");
        bf10.setErrorMessage("Compilation failed: missing import statement");
        bf10.setFailedStep("Build");
        bf10.setFailedAt(LocalDateTime.now().minusHours(2));
        bf10.setResolved(false);
        bf10.setAiConfidence("HIGH");
        bf10.setErrorEmbedding(generateTestEmbedding(0.9f, 0.95f, 0.92f));
        buildFailureRepository.save(bf10);

        // Add 3 more failures to reach 13 total
        BuildFailure bf11 = new BuildFailure();
        bf11.setRepository("theautonomy/articles");
        bf11.setWorkflowName("build.yml");
        bf11.setRunId(5001L);
        bf11.setRunNumber(501);
        bf11.setBranch("main");
        bf11.setCommitSha("extra123");
        bf11.setErrorType("NullPointerException");
        bf11.setErrorMessage("NullPointerException in payment processing");
        bf11.setFailedStep("Run Tests");
        bf11.setFailedAt(LocalDateTime.now().minusDays(7));
        bf11.setResolved(true);
        bf11.setResolutionDescription("Added null check in PaymentProcessor");
        bf11.setTimeToFixMinutes(18);
        bf11.setFixedBy("Alice");
        bf11.setResolvedAt(LocalDateTime.now().minusDays(7));
        bf11.setSolutionEffectiveness(0.87f);
        bf11.setTimesHelped(2);
        bf11.setAiConfidence("HIGH");
        bf11.setErrorEmbedding(generateTestEmbedding(0.1f, 0.2f, 0.3f));
        buildFailureRepository.save(bf11);

        BuildFailure bf12 = new BuildFailure();
        bf12.setRepository("theautonomy/articles");
        bf12.setWorkflowName("build.yml");
        bf12.setRunId(5002L);
        bf12.setRunNumber(502);
        bf12.setBranch("develop");
        bf12.setCommitSha("extra234");
        bf12.setErrorType("DatabaseException");
        bf12.setErrorMessage("Database migration failed");
        bf12.setFailedStep("Integration Tests");
        bf12.setFailedAt(LocalDateTime.now().minusDays(6));
        bf12.setResolved(true);
        bf12.setResolutionDescription("Fixed SQL syntax in migration script");
        bf12.setTimeToFixMinutes(40);
        bf12.setFixedBy("Bob");
        bf12.setResolvedAt(LocalDateTime.now().minusDays(6));
        bf12.setSolutionEffectiveness(0.92f);
        bf12.setTimesHelped(3);
        bf12.setAiConfidence("HIGH");
        bf12.setErrorEmbedding(generateTestEmbedding(0.4f, 0.5f, 0.6f));
        buildFailureRepository.save(bf12);

        BuildFailure bf13 = new BuildFailure();
        bf13.setRepository("theautonomy/articles");
        bf13.setWorkflowName("build.yml");
        bf13.setRunId(5003L);
        bf13.setRunNumber(503);
        bf13.setBranch("main");
        bf13.setCommitSha("extra345");
        bf13.setErrorType("TestTimeout");
        bf13.setErrorMessage("Unit test timeout in OrderService");
        bf13.setFailedStep("Run Tests");
        bf13.setFailedAt(LocalDateTime.now().minusDays(2));
        bf13.setResolved(true);
        bf13.setResolutionDescription("Optimized database queries in test");
        bf13.setTimeToFixMinutes(25);
        bf13.setFixedBy("Charlie");
        bf13.setResolvedAt(LocalDateTime.now().minusDays(2));
        bf13.setSolutionEffectiveness(0.83f);
        bf13.setTimesHelped(1);
        bf13.setAiConfidence("MEDIUM");
        bf13.setErrorEmbedding(generateTestEmbedding(0.7f, 0.8f, 0.9f));
        buildFailureRepository.save(bf13);

        logger.info("✓ Loaded {} build failures", buildFailureRepository.count());
    }

    private void loadDeploymentHistory() {
        logger.info("Loading deployment history...");

        // Tuesday 10am deployments (high success rate)
        DeploymentHistory dh1 = new DeploymentHistory();
        dh1.setRepository("theautonomy/articles");
        dh1.setFromCommit("aaa111");
        dh1.setToCommit("bbb222");
        dh1.setEnvironment("production");
        dh1.setTotalCommits(5);
        dh1.setFilesChanged(8);
        dh1.setLinesAdded(150);
        dh1.setLinesDeleted(50);
        dh1.setChangedFiles(new String[] {"UserService.java", "HomeController.java"});
        dh1.setCommitMessages(new String[] {"Fix user auth bug", "Update home page"});
        dh1.setPredictedRiskLevel("LOW");
        dh1.setPredictedRiskScore(2.5);
        dh1.setDeploymentStatus("success");
        dh1.setActualSuccess(true);
        dh1.setDeploymentDurationMinutes(12);
        dh1.setDeployedAt(LocalDateTime.now().minusDays(25).withHour(10).withMinute(0));
        dh1.setDeployedBy("Alice");
        dh1.setDayOfWeek(2); // Tuesday
        dh1.setHourOfDay(10);
        dh1.setHasDatabaseChanges(false);
        dh1.setHasConfigChanges(false);
        dh1.setHasCriticalFiles(false);
        dh1.setChangeEmbedding(generateTestEmbedding(0.1f, 0.1f, 0.1f));
        deploymentHistoryRepository.save(dh1);

        DeploymentHistory dh2 = new DeploymentHistory();
        dh2.setRepository("theautonomy/articles");
        dh2.setFromCommit("bbb222");
        dh2.setToCommit("ccc333");
        dh2.setEnvironment("production");
        dh2.setTotalCommits(3);
        dh2.setFilesChanged(5);
        dh2.setLinesAdded(80);
        dh2.setLinesDeleted(20);
        dh2.setChangedFiles(new String[] {"PaymentService.java"});
        dh2.setCommitMessages(new String[] {"Optimize payment flow"});
        dh2.setPredictedRiskLevel("LOW");
        dh2.setPredictedRiskScore(3.0);
        dh2.setDeploymentStatus("success");
        dh2.setActualSuccess(true);
        dh2.setDeploymentDurationMinutes(10);
        dh2.setDeployedAt(LocalDateTime.now().minusDays(18).withHour(10).withMinute(0));
        dh2.setDeployedBy("Bob");
        dh2.setDayOfWeek(2); // Tuesday
        dh2.setHourOfDay(10);
        dh2.setHasDatabaseChanges(false);
        dh2.setHasConfigChanges(true);
        dh2.setHasCriticalFiles(false);
        dh2.setChangeEmbedding(generateTestEmbedding(0.2f, 0.2f, 0.2f));
        deploymentHistoryRepository.save(dh2);

        DeploymentHistory dh3 = new DeploymentHistory();
        dh3.setRepository("theautonomy/articles");
        dh3.setFromCommit("ccc333");
        dh3.setToCommit("ddd444");
        dh3.setEnvironment("production");
        dh3.setTotalCommits(4);
        dh3.setFilesChanged(6);
        dh3.setLinesAdded(100);
        dh3.setLinesDeleted(30);
        dh3.setChangedFiles(new String[] {"OrderService.java", "config.yml"});
        dh3.setCommitMessages(new String[] {"Add order validation"});
        dh3.setPredictedRiskLevel("MEDIUM");
        dh3.setPredictedRiskScore(4.0);
        dh3.setDeploymentStatus("success");
        dh3.setActualSuccess(true);
        dh3.setDeploymentDurationMinutes(15);
        dh3.setDeployedAt(LocalDateTime.now().minusDays(11).withHour(10).withMinute(0));
        dh3.setDeployedBy("Charlie");
        dh3.setDayOfWeek(2); // Tuesday
        dh3.setHourOfDay(10);
        dh3.setHasDatabaseChanges(false);
        dh3.setHasConfigChanges(true);
        dh3.setHasCriticalFiles(false);
        dh3.setChangeEmbedding(generateTestEmbedding(0.3f, 0.3f, 0.3f));
        deploymentHistoryRepository.save(dh3);

        // Wednesday 10am deployments (also good)
        DeploymentHistory dh4 = new DeploymentHistory();
        dh4.setRepository("theautonomy/articles");
        dh4.setFromCommit("ddd444");
        dh4.setToCommit("eee555");
        dh4.setEnvironment("production");
        dh4.setTotalCommits(6);
        dh4.setFilesChanged(10);
        dh4.setLinesAdded(200);
        dh4.setLinesDeleted(80);
        dh4.setChangedFiles(new String[] {"ReportService.java"});
        dh4.setCommitMessages(new String[] {"Add monthly reports"});
        dh4.setPredictedRiskLevel("LOW");
        dh4.setPredictedRiskScore(2.8);
        dh4.setDeploymentStatus("success");
        dh4.setActualSuccess(true);
        dh4.setDeploymentDurationMinutes(14);
        dh4.setDeployedAt(LocalDateTime.now().minusDays(24).withHour(10).withMinute(0));
        dh4.setDeployedBy("Alice");
        dh4.setDayOfWeek(3); // Wednesday
        dh4.setHourOfDay(10);
        dh4.setHasDatabaseChanges(false);
        dh4.setHasConfigChanges(false);
        dh4.setHasCriticalFiles(false);
        dh4.setChangeEmbedding(generateTestEmbedding(0.4f, 0.4f, 0.4f));
        deploymentHistoryRepository.save(dh4);

        DeploymentHistory dh5 = new DeploymentHistory();
        dh5.setRepository("theautonomy/articles");
        dh5.setFromCommit("eee555");
        dh5.setToCommit("fff666");
        dh5.setEnvironment("production");
        dh5.setTotalCommits(2);
        dh5.setFilesChanged(3);
        dh5.setLinesAdded(50);
        dh5.setLinesDeleted(10);
        dh5.setChangedFiles(new String[] {"UserController.java"});
        dh5.setCommitMessages(new String[] {"Fix UI bug"});
        dh5.setPredictedRiskLevel("LOW");
        dh5.setPredictedRiskScore(2.2);
        dh5.setDeploymentStatus("success");
        dh5.setActualSuccess(true);
        dh5.setDeploymentDurationMinutes(8);
        dh5.setDeployedAt(LocalDateTime.now().minusDays(17).withHour(10).withMinute(0));
        dh5.setDeployedBy("Bob");
        dh5.setDayOfWeek(3); // Wednesday
        dh5.setHourOfDay(10);
        dh5.setHasDatabaseChanges(false);
        dh5.setHasConfigChanges(false);
        dh5.setHasCriticalFiles(false);
        dh5.setChangeEmbedding(generateTestEmbedding(0.5f, 0.5f, 0.5f));
        deploymentHistoryRepository.save(dh5);

        // Friday afternoon deployments (risky - low success rate)
        DeploymentHistory dh6 = new DeploymentHistory();
        dh6.setRepository("theautonomy/articles");
        dh6.setFromCommit("fri111");
        dh6.setToCommit("fri222");
        dh6.setEnvironment("production");
        dh6.setTotalCommits(8);
        dh6.setFilesChanged(15);
        dh6.setLinesAdded(300);
        dh6.setLinesDeleted(100);
        dh6.setChangedFiles(new String[] {"UserService.java", "AuthController.java"});
        dh6.setCommitMessages(new String[] {"Major auth refactor"});
        dh6.setPredictedRiskLevel("HIGH");
        dh6.setPredictedRiskScore(7.5);
        dh6.setDeploymentStatus("failed");
        dh6.setActualSuccess(false);
        dh6.setDeploymentDurationMinutes(45);
        dh6.setDeployedAt(LocalDateTime.now().minusDays(22).withHour(16).withMinute(0));
        dh6.setDeployedBy("Alice");
        dh6.setDayOfWeek(5); // Friday
        dh6.setHourOfDay(16);
        dh6.setHasDatabaseChanges(false);
        dh6.setHasConfigChanges(true);
        dh6.setHasCriticalFiles(true);
        dh6.setIssuesEncountered(
                new String[] {"Authentication timeout", "Session management failed"});
        dh6.setIncidentSeverity("major");
        dh6.setDowntimeMinutes(120);
        dh6.setChangeEmbedding(generateTestEmbedding(0.15f, 0.25f, 0.35f));
        deploymentHistoryRepository.save(dh6);

        DeploymentHistory dh7 = new DeploymentHistory();
        dh7.setRepository("theautonomy/articles");
        dh7.setFromCommit("fri333");
        dh7.setToCommit("fri444");
        dh7.setEnvironment("production");
        dh7.setTotalCommits(10);
        dh7.setFilesChanged(20);
        dh7.setLinesAdded(400);
        dh7.setLinesDeleted(150);
        dh7.setChangedFiles(new String[] {"database/migration_v23.sql", "UserService.java"});
        dh7.setCommitMessages(new String[] {"Database schema update", "Update user model"});
        dh7.setPredictedRiskLevel("CRITICAL");
        dh7.setPredictedRiskScore(8.5);
        dh7.setDeploymentStatus("failed");
        dh7.setActualSuccess(false);
        dh7.setDeploymentDurationMinutes(60);
        dh7.setDeployedAt(LocalDateTime.now().minusDays(15).withHour(17).withMinute(0));
        dh7.setDeployedBy("Bob");
        dh7.setDayOfWeek(5); // Friday
        dh7.setHourOfDay(17);
        dh7.setHasDatabaseChanges(true);
        dh7.setHasConfigChanges(false);
        dh7.setHasCriticalFiles(true);
        dh7.setIssuesEncountered(new String[] {"Database migration failed", "Table lock timeout"});
        dh7.setIncidentSeverity("critical");
        dh7.setDowntimeMinutes(180);
        dh7.setChangeEmbedding(generateTestEmbedding(0.2f, 0.3f, 0.4f));
        deploymentHistoryRepository.save(dh7);

        DeploymentHistory dh8 = new DeploymentHistory();
        dh8.setRepository("theautonomy/articles");
        dh8.setFromCommit("fri555");
        dh8.setToCommit("fri666");
        dh8.setEnvironment("production");
        dh8.setTotalCommits(5);
        dh8.setFilesChanged(12);
        dh8.setLinesAdded(250);
        dh8.setLinesDeleted(80);
        dh8.setChangedFiles(new String[] {"PaymentProcessor.java", "config/payment.yml"});
        dh8.setCommitMessages(new String[] {"Update payment gateway"});
        dh8.setPredictedRiskLevel("HIGH");
        dh8.setPredictedRiskScore(7.0);
        dh8.setDeploymentStatus("rolled_back");
        dh8.setActualSuccess(false);
        dh8.setDeploymentDurationMinutes(90);
        dh8.setDeployedAt(LocalDateTime.now().minusDays(8).withHour(16).withMinute(30));
        dh8.setDeployedBy("Charlie");
        dh8.setDayOfWeek(5); // Friday
        dh8.setHourOfDay(16);
        dh8.setHasDatabaseChanges(false);
        dh8.setHasConfigChanges(true);
        dh8.setHasCriticalFiles(true);
        dh8.setIssuesEncountered(new String[] {"Payment processing failed", "Gateway timeout"});
        dh8.setIncidentSeverity("major");
        dh8.setDowntimeMinutes(90);
        dh8.setChangeEmbedding(generateTestEmbedding(0.3f, 0.4f, 0.5f));
        deploymentHistoryRepository.save(dh8);

        // Database + Critical Files combination (high failure rate)
        DeploymentHistory dh9 = new DeploymentHistory();
        dh9.setRepository("theautonomy/articles");
        dh9.setFromCommit("db111");
        dh9.setToCommit("db222");
        dh9.setEnvironment("production");
        dh9.setTotalCommits(7);
        dh9.setFilesChanged(12);
        dh9.setLinesAdded(200);
        dh9.setLinesDeleted(50);
        dh9.setChangedFiles(new String[] {"database/migration_v20.sql", "AuthService.java"});
        dh9.setCommitMessages(new String[] {"Add auth tables", "Update auth logic"});
        dh9.setPredictedRiskLevel("CRITICAL");
        dh9.setPredictedRiskScore(9.0);
        dh9.setDeploymentStatus("failed");
        dh9.setActualSuccess(false);
        dh9.setDeploymentDurationMinutes(120);
        dh9.setDeployedAt(LocalDateTime.now().minusDays(30).withHour(14).withMinute(0));
        dh9.setDeployedBy("Alice");
        dh9.setDayOfWeek(3); // Wednesday
        dh9.setHourOfDay(14);
        dh9.setHasDatabaseChanges(true);
        dh9.setHasConfigChanges(false);
        dh9.setHasCriticalFiles(true);
        dh9.setIssuesEncountered(new String[] {"Migration failed - missing foreign key"});
        dh9.setIncidentSeverity("major");
        dh9.setChangeEmbedding(generateTestEmbedding(0.11f, 0.21f, 0.31f));
        deploymentHistoryRepository.save(dh9);

        DeploymentHistory dh10 = new DeploymentHistory();
        dh10.setRepository("theautonomy/articles");
        dh10.setFromCommit("db333");
        dh10.setToCommit("db444");
        dh10.setEnvironment("production");
        dh10.setTotalCommits(6);
        dh10.setFilesChanged(10);
        dh10.setLinesAdded(180);
        dh10.setLinesDeleted(40);
        dh10.setChangedFiles(new String[] {"database/migration_v21.sql", "PaymentService.java"});
        dh10.setCommitMessages(new String[] {"Add payment tables", "Update payment service"});
        dh10.setPredictedRiskLevel("CRITICAL");
        dh10.setPredictedRiskScore(8.8);
        dh10.setDeploymentStatus("failed");
        dh10.setActualSuccess(false);
        dh10.setDeploymentDurationMinutes(150);
        dh10.setDeployedAt(LocalDateTime.now().minusDays(20).withHour(15).withMinute(0));
        dh10.setDeployedBy("Bob");
        dh10.setDayOfWeek(4); // Thursday
        dh10.setHourOfDay(15);
        dh10.setHasDatabaseChanges(true);
        dh10.setHasConfigChanges(false);
        dh10.setHasCriticalFiles(true);
        dh10.setIssuesEncountered(new String[] {"Database deadlock during migration"});
        dh10.setIncidentSeverity("critical");
        dh10.setChangeEmbedding(generateTestEmbedding(0.12f, 0.22f, 0.32f));
        deploymentHistoryRepository.save(dh10);

        DeploymentHistory dh11 = new DeploymentHistory();
        dh11.setRepository("theautonomy/articles");
        dh11.setFromCommit("db555");
        dh11.setToCommit("db666");
        dh11.setEnvironment("production");
        dh11.setTotalCommits(8);
        dh11.setFilesChanged(14);
        dh11.setLinesAdded(220);
        dh11.setLinesDeleted(60);
        dh11.setChangedFiles(
                new String[] {
                    "database/migration_v22.sql", "UserService.java", "AuthController.java"
                });
        dh11.setCommitMessages(new String[] {"Schema update", "Update user logic", "Update auth"});
        dh11.setPredictedRiskLevel("CRITICAL");
        dh11.setPredictedRiskScore(9.2);
        dh11.setDeploymentStatus("success");
        dh11.setActualSuccess(true);
        dh11.setDeploymentDurationMinutes(180);
        dh11.setDeployedAt(LocalDateTime.now().minusDays(10).withHour(10).withMinute(0));
        dh11.setDeployedBy("Alice");
        dh11.setDayOfWeek(2); // Tuesday
        dh11.setHourOfDay(10);
        dh11.setHasDatabaseChanges(true);
        dh11.setHasConfigChanges(false);
        dh11.setHasCriticalFiles(true);
        dh11.setIncidentSeverity("none");
        dh11.setChangeEmbedding(generateTestEmbedding(0.13f, 0.23f, 0.33f));
        deploymentHistoryRepository.save(dh11);

        // More successful deployments for good statistics
        DeploymentHistory dh12 = new DeploymentHistory();
        dh12.setRepository("theautonomy/articles");
        dh12.setFromCommit("good1");
        dh12.setToCommit("good2");
        dh12.setEnvironment("production");
        dh12.setTotalCommits(4);
        dh12.setFilesChanged(7);
        dh12.setLinesAdded(120);
        dh12.setLinesDeleted(30);
        dh12.setChangedFiles(new String[] {"ReportController.java"});
        dh12.setCommitMessages(new String[] {"Add report feature"});
        dh12.setPredictedRiskLevel("LOW");
        dh12.setPredictedRiskScore(2.0);
        dh12.setDeploymentStatus("success");
        dh12.setActualSuccess(true);
        dh12.setDeploymentDurationMinutes(11);
        dh12.setDeployedAt(LocalDateTime.now().minusDays(23).withHour(11).withMinute(0));
        dh12.setDeployedBy("Charlie");
        dh12.setDayOfWeek(2); // Tuesday
        dh12.setHourOfDay(11);
        dh12.setHasDatabaseChanges(false);
        dh12.setHasConfigChanges(false);
        dh12.setHasCriticalFiles(false);
        dh12.setChangeEmbedding(generateTestEmbedding(0.6f, 0.6f, 0.6f));
        deploymentHistoryRepository.save(dh12);

        DeploymentHistory dh13 = new DeploymentHistory();
        dh13.setRepository("theautonomy/articles");
        dh13.setFromCommit("good3");
        dh13.setToCommit("good4");
        dh13.setEnvironment("production");
        dh13.setTotalCommits(3);
        dh13.setFilesChanged(5);
        dh13.setLinesAdded(90);
        dh13.setLinesDeleted(20);
        dh13.setChangedFiles(new String[] {"DashboardService.java"});
        dh13.setCommitMessages(new String[] {"Update dashboard"});
        dh13.setPredictedRiskLevel("LOW");
        dh13.setPredictedRiskScore(2.5);
        dh13.setDeploymentStatus("success");
        dh13.setActualSuccess(true);
        dh13.setDeploymentDurationMinutes(9);
        dh13.setDeployedAt(LocalDateTime.now().minusDays(16).withHour(14).withMinute(0));
        dh13.setDeployedBy("Alice");
        dh13.setDayOfWeek(4); // Thursday
        dh13.setHourOfDay(14);
        dh13.setHasDatabaseChanges(false);
        dh13.setHasConfigChanges(false);
        dh13.setHasCriticalFiles(false);
        dh13.setChangeEmbedding(generateTestEmbedding(0.7f, 0.7f, 0.7f));
        deploymentHistoryRepository.save(dh13);

        DeploymentHistory dh14 = new DeploymentHistory();
        dh14.setRepository("theautonomy/articles");
        dh14.setFromCommit("good5");
        dh14.setToCommit("good6");
        dh14.setEnvironment("production");
        dh14.setTotalCommits(5);
        dh14.setFilesChanged(8);
        dh14.setLinesAdded(140);
        dh14.setLinesDeleted(35);
        dh14.setChangedFiles(new String[] {"NotificationService.java"});
        dh14.setCommitMessages(new String[] {"Add email notifications"});
        dh14.setPredictedRiskLevel("LOW");
        dh14.setPredictedRiskScore(3.0);
        dh14.setDeploymentStatus("success");
        dh14.setActualSuccess(true);
        dh14.setDeploymentDurationMinutes(13);
        dh14.setDeployedAt(LocalDateTime.now().minusDays(9).withHour(10).withMinute(0));
        dh14.setDeployedBy("Bob");
        dh14.setDayOfWeek(3); // Wednesday
        dh14.setHourOfDay(10);
        dh14.setHasDatabaseChanges(false);
        dh14.setHasConfigChanges(true);
        dh14.setHasCriticalFiles(false);
        dh14.setChangeEmbedding(generateTestEmbedding(0.8f, 0.8f, 0.8f));
        deploymentHistoryRepository.save(dh14);

        // Add 2 more to reach 16 total
        DeploymentHistory dh15 = new DeploymentHistory();
        dh15.setRepository("theautonomy/articles");
        dh15.setFromCommit("extra1");
        dh15.setToCommit("extra2");
        dh15.setEnvironment("production");
        dh15.setTotalCommits(3);
        dh15.setFilesChanged(4);
        dh15.setLinesAdded(70);
        dh15.setLinesDeleted(15);
        dh15.setChangedFiles(new String[] {"AnalyticsService.java"});
        dh15.setCommitMessages(new String[] {"Add analytics tracking"});
        dh15.setPredictedRiskLevel("LOW");
        dh15.setPredictedRiskScore(2.3);
        dh15.setDeploymentStatus("success");
        dh15.setActualSuccess(true);
        dh15.setDeploymentDurationMinutes(9);
        dh15.setDeployedAt(LocalDateTime.now().minusDays(14).withHour(10).withMinute(0));
        dh15.setDeployedBy("Charlie");
        dh15.setDayOfWeek(2); // Tuesday
        dh15.setHourOfDay(10);
        dh15.setHasDatabaseChanges(false);
        dh15.setHasConfigChanges(false);
        dh15.setHasCriticalFiles(false);
        dh15.setChangeEmbedding(generateTestEmbedding(0.6f, 0.6f, 0.6f));
        deploymentHistoryRepository.save(dh15);

        DeploymentHistory dh16 = new DeploymentHistory();
        dh16.setRepository("theautonomy/articles");
        dh16.setFromCommit("extra3");
        dh16.setToCommit("extra4");
        dh16.setEnvironment("production");
        dh16.setTotalCommits(2);
        dh16.setFilesChanged(3);
        dh16.setLinesAdded(60);
        dh16.setLinesDeleted(12);
        dh16.setChangedFiles(new String[] {"LoggingService.java"});
        dh16.setCommitMessages(new String[] {"Improve logging"});
        dh16.setPredictedRiskLevel("LOW");
        dh16.setPredictedRiskScore(2.0);
        dh16.setDeploymentStatus("success");
        dh16.setActualSuccess(true);
        dh16.setDeploymentDurationMinutes(7);
        dh16.setDeployedAt(LocalDateTime.now().minusDays(12).withHour(11).withMinute(0));
        dh16.setDeployedBy("Alice");
        dh16.setDayOfWeek(3); // Wednesday
        dh16.setHourOfDay(11);
        dh16.setHasDatabaseChanges(false);
        dh16.setHasConfigChanges(false);
        dh16.setHasCriticalFiles(false);
        dh16.setChangeEmbedding(generateTestEmbedding(0.5f, 0.5f, 0.5f));
        deploymentHistoryRepository.save(dh16);

        logger.info("✓ Loaded {} deployment history records", deploymentHistoryRepository.count());
    }

    private void loadFileRiskHistory() {
        logger.info("Loading file risk history...");

        FileRiskHistory frh1 = new FileRiskHistory();
        frh1.setRepository("theautonomy/articles");
        frh1.setFilePath("UserService.java");
        frh1.setFileType("java");
        frh1.setTotalModifications(15);
        frh1.setModificationsCausingIncidents(5);
        frh1.setIncidentRate(0.33);
        frh1.setLastIncidentDate(LocalDateTime.now().minusDays(5));
        frh1.setLastIncidentDescription("NullPointerException in authentication");
        frh1.setCommonFailureTypes(
                new String[] {"NullPointerException", "AuthenticationException"});
        frh1.setAverageLinesChanged(85.5);
        frh1.setMaxLinesChanged(200);
        frh1.setRequiresExpert(true);
        frh1.setExpertDevelopers(new String[] {"Alice", "Bob"});
        frh1.setFirstModifiedAt(LocalDateTime.now().minusDays(90));
        frh1.setLastModifiedAt(LocalDateTime.now().minusDays(5));
        fileRiskHistoryRepository.save(frh1);

        FileRiskHistory frh2 = new FileRiskHistory();
        frh2.setRepository("theautonomy/articles");
        frh2.setFilePath("PaymentProcessor.java");
        frh2.setFileType("java");
        frh2.setTotalModifications(12);
        frh2.setModificationsCausingIncidents(4);
        frh2.setIncidentRate(0.33);
        frh2.setLastIncidentDate(LocalDateTime.now().minusDays(8));
        frh2.setLastIncidentDescription("Payment gateway timeout");
        frh2.setCommonFailureTypes(new String[] {"TimeoutException", "PaymentException"});
        frh2.setAverageLinesChanged(120.0);
        frh2.setMaxLinesChanged(300);
        frh2.setRequiresExpert(true);
        frh2.setExpertDevelopers(new String[] {"Charlie", "Bob"});
        frh2.setFirstModifiedAt(LocalDateTime.now().minusDays(120));
        frh2.setLastModifiedAt(LocalDateTime.now().minusDays(8));
        fileRiskHistoryRepository.save(frh2);

        FileRiskHistory frh3 = new FileRiskHistory();
        frh3.setRepository("theautonomy/articles");
        frh3.setFilePath("AuthController.java");
        frh3.setFileType("java");
        frh3.setTotalModifications(20);
        frh3.setModificationsCausingIncidents(2);
        frh3.setIncidentRate(0.10);
        frh3.setLastIncidentDate(LocalDateTime.now().minusDays(15));
        frh3.setLastIncidentDescription("Session validation failed");
        frh3.setCommonFailureTypes(new String[] {"AuthenticationException"});
        frh3.setAverageLinesChanged(50.5);
        frh3.setMaxLinesChanged(120);
        frh3.setRequiresExpert(false);
        frh3.setExpertDevelopers(new String[] {"Alice"});
        frh3.setFirstModifiedAt(LocalDateTime.now().minusDays(180));
        frh3.setLastModifiedAt(LocalDateTime.now().minusDays(15));
        fileRiskHistoryRepository.save(frh3);

        FileRiskHistory frh4 = new FileRiskHistory();
        frh4.setRepository("theautonomy/articles");
        frh4.setFilePath("database/migration_v23.sql");
        frh4.setFileType("sql");
        frh4.setTotalModifications(3);
        frh4.setModificationsCausingIncidents(2);
        frh4.setIncidentRate(0.67);
        frh4.setLastIncidentDate(LocalDateTime.now().minusDays(10));
        frh4.setLastIncidentDescription("Migration failed - table lock");
        frh4.setCommonFailureTypes(new String[] {"DatabaseException", "MigrationException"});
        frh4.setAverageLinesChanged(200.0);
        frh4.setMaxLinesChanged(500);
        frh4.setRequiresExpert(true);
        frh4.setExpertDevelopers(new String[] {"Bob"});
        frh4.setFirstModifiedAt(LocalDateTime.now().minusDays(30));
        frh4.setLastModifiedAt(LocalDateTime.now().minusDays(10));
        fileRiskHistoryRepository.save(frh4);

        logger.info("✓ Loaded {} file risk history records", fileRiskHistoryRepository.count());
    }

    /**
     * Generate a test embedding vector with 1536 dimensions as PGvector
     *
     * @param base1 Base value for dimension pattern 1
     * @param base2 Base value for dimension pattern 2
     * @param base3 Base value for dimension pattern 3
     * @return PGvector with 1536 dimensions
     */
    private PGvector generateTestEmbedding(float base1, float base2, float base3) {
        float[] embedding = new float[1536];
        for (int i = 0; i < 1536; i++) {
            if (i % 3 == 0) {
                embedding[i] = base1 + (i / 10000.0f);
            } else if (i % 3 == 1) {
                embedding[i] = base2 + (i / 10000.0f);
            } else {
                embedding[i] = base3 + (i / 10000.0f);
            }
        }
        return new PGvector(embedding);
    }
}
