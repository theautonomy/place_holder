package com.example.demo.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.example.demo.entity.FileRiskHistory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FileRiskHistoryRepository extends JpaRepository<FileRiskHistory, UUID> {

    /**
     * Find file risk by repository and file path
     *
     * @param repository Repository name
     * @param filePath File path
     * @return File risk history if exists
     */
    Optional<FileRiskHistory> findByRepositoryAndFilePath(String repository, String filePath);

    /**
     * Get all high-risk files for a repository (incident rate > threshold)
     *
     * @param repository Repository name
     * @param minIncidentRate Minimum incident rate to consider high-risk
     * @return List of high-risk files
     */
    @Query(
            "SELECT f FROM FileRiskHistory f WHERE f.repository = :repository "
                    + "AND f.incidentRate >= :minIncidentRate ORDER BY f.incidentRate DESC")
    List<FileRiskHistory> findHighRiskFiles(
            @Param("repository") String repository,
            @Param("minIncidentRate") double minIncidentRate);

    /**
     * Get files that require expert attention
     *
     * @param repository Repository name
     * @return List of files requiring expert
     */
    List<FileRiskHistory> findByRepositoryAndRequiresExpertTrue(String repository);

    /**
     * Get top N riskiest files in a repository
     *
     * @param repository Repository name
     * @param limit Number of results
     * @return List of riskiest files
     */
    @Query(
            value =
                    "SELECT * FROM file_risk_history WHERE repository = :repository "
                            + "AND incident_rate > 0 ORDER BY incident_rate DESC LIMIT :limit",
            nativeQuery = true)
    List<FileRiskHistory> findTopRiskyFiles(
            @Param("repository") String repository, @Param("limit") int limit);

    /**
     * Get files modified by a specific developer
     *
     * @param repository Repository name
     * @param developer Developer name
     * @return List of files
     */
    @Query(
            value =
                    "SELECT * FROM file_risk_history WHERE repository = :repository "
                            + "AND :developer = ANY(expert_developers)",
            nativeQuery = true)
    List<FileRiskHistory> findByRepositoryAndExpertDeveloper(
            @Param("repository") String repository, @Param("developer") String developer);

    /**
     * Get risk statistics for a repository
     *
     * @param repository Repository name
     * @return Statistics as Object array [total_files, high_risk_files, avg_incident_rate]
     */
    @Query(
            value =
                    """
            SELECT
                COUNT(*) as total_files,
                SUM(CASE WHEN incident_rate >= 0.3 THEN 1 ELSE 0 END) as high_risk_files,
                AVG(incident_rate) as avg_incident_rate,
                SUM(total_modifications) as total_modifications,
                SUM(modifications_causing_incidents) as total_incidents
            FROM file_risk_history
            WHERE repository = :repository
            """,
            nativeQuery = true)
    Object[] getRepositoryRiskStatistics(@Param("repository") String repository);

    /**
     * Find files by file type
     *
     * @param repository Repository name
     * @param fileType File type
     * @return List of files
     */
    List<FileRiskHistory> findByRepositoryAndFileType(String repository, String fileType);

    /**
     * Count high-risk files in a repository
     *
     * @param repository Repository name
     * @param minIncidentRate Minimum incident rate
     * @return Count of high-risk files
     */
    @Query(
            "SELECT COUNT(f) FROM FileRiskHistory f WHERE f.repository = :repository "
                    + "AND f.incidentRate >= :minIncidentRate")
    long countHighRiskFiles(
            @Param("repository") String repository,
            @Param("minIncidentRate") double minIncidentRate);

    /**
     * Get files with recent incidents (within last N days)
     *
     * @param repository Repository name
     * @param daysSince Days to look back
     * @return List of files with recent incidents
     */
    @Query(
            value =
                    "SELECT * FROM file_risk_history WHERE repository = :repository "
                            + "AND last_incident_date > NOW() - INTERVAL ':daysSince days' "
                            + "ORDER BY last_incident_date DESC",
            nativeQuery = true)
    List<FileRiskHistory> findFilesWithRecentIncidents(
            @Param("repository") String repository, @Param("daysSince") int daysSince);

    /**
     * Get all files in a repository ordered by risk
     *
     * @param repository Repository name
     * @return List of all files ordered by incident rate
     */
    List<FileRiskHistory> findByRepositoryOrderByIncidentRateDesc(String repository);
}
