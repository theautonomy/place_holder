package com.example.demo.service;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.kohsuke.github.GHCommit;
import org.kohsuke.github.GHCompare;
import org.kohsuke.github.GHDeployment;
import org.kohsuke.github.GHRepository;

public class DeploymentTrackingService {

    private final GHRepository repository;

    public DeploymentTrackingService(GHRepository repository) {
        this.repository = repository;
    }

    /** Get comprehensive deployment tracking data for all environments */
    public DeploymentTrackingData getDeploymentTracking() throws IOException {
        var allDeployments = repository.listDeployments(null, null, null, null).toList();

        // Group deployments by environment
        Map<String, List<GHDeployment>> deploymentsByEnv = new HashMap<>();
        for (var deployment : allDeployments) {
            String env = deployment.getEnvironment();
            deploymentsByEnv.computeIfAbsent(env, k -> new ArrayList<>()).add(deployment);
        }

        List<EnvironmentDeploymentData> envData = new ArrayList<>();

        for (Map.Entry<String, List<GHDeployment>> entry : deploymentsByEnv.entrySet()) {
            String envName = entry.getKey();
            List<GHDeployment> deployments = entry.getValue();

            // Sort by creation date (newest first)
            deployments.sort(
                    (d1, d2) -> {
                        try {
                            return d2.getCreatedAt().compareTo(d1.getCreatedAt());
                        } catch (IOException e) {
                            return 0;
                        }
                    });

            // Get latest deployment
            GHDeployment latestDeployment = deployments.isEmpty() ? null : deployments.get(0);

            // Get deployment status
            String status = "unknown";
            Date statusUpdatedAt = null;
            if (latestDeployment != null) {
                var statuses = latestDeployment.listStatuses().toList();
                if (!statuses.isEmpty()) {
                    status = statuses.get(0).getState().name();
                    statusUpdatedAt = statuses.get(0).getCreatedAt();
                }
            }

            // Calculate deployment frequency (last 30 days)
            Instant thirtyDaysAgo = Instant.now().minus(Duration.ofDays(30));
            long deploymentsLast30Days = 0;
            for (var dep : deployments) {
                try {
                    if (dep.getCreatedAt().toInstant().isAfter(thirtyDaysAgo)) {
                        deploymentsLast30Days++;
                    }
                } catch (IOException e) {
                    // Skip
                }
            }

            // Get last 5 deployments for history
            List<GHDeployment> recentDeployments =
                    deployments.stream().limit(5).collect(Collectors.toList());

            // Calculate success rate
            long successfulDeployments = 0;
            for (var dep : deployments) {
                try {
                    var statuses = dep.listStatuses().toList();
                    if (!statuses.isEmpty()
                            && "success".equalsIgnoreCase(statuses.get(0).getState().name())) {
                        successfulDeployments++;
                    }
                } catch (IOException e) {
                    // Skip
                }
            }
            double successRate =
                    deployments.isEmpty()
                            ? 0.0
                            : (successfulDeployments * 100.0 / deployments.size());

            envData.add(
                    new EnvironmentDeploymentData(
                            envName,
                            latestDeployment,
                            status,
                            statusUpdatedAt,
                            recentDeployments,
                            deploymentsLast30Days,
                            successRate,
                            deployments.size()));
        }

        return new DeploymentTrackingData(envData, allDeployments.size());
    }

    /** Get deployment history for a specific environment */
    public List<DeploymentHistoryEntry> getDeploymentHistory(String environment, int limit)
            throws IOException {
        var deployments = repository.listDeployments(null, environment, null, null).toList();

        List<DeploymentHistoryEntry> history = new ArrayList<>();

        int count = 0;
        for (var deployment : deployments) {
            if (count >= limit) break;

            try {
                var statuses = deployment.listStatuses().toList();
                String status = statuses.isEmpty() ? "unknown" : statuses.get(0).getState().name();
                String statusDescription = "";
                if (!statuses.isEmpty() && statuses.get(0).getTargetUrl() != null) {
                    statusDescription = statuses.get(0).getTargetUrl().toString();
                }
                Date statusUpdatedAt = statuses.isEmpty() ? null : statuses.get(0).getCreatedAt();

                // Get commit info
                GHCommit commit = repository.getCommit(deployment.getSha());

                history.add(
                        new DeploymentHistoryEntry(
                                deployment.getId(),
                                deployment.getSha(),
                                deployment.getEnvironment(),
                                status,
                                statusDescription,
                                deployment.getCreatedAt(),
                                statusUpdatedAt,
                                deployment.getCreator().getLogin(),
                                commit.getCommitShortInfo().getMessage(),
                                deployment.getTask()));

                count++;
            } catch (IOException e) {
                // Skip this deployment
            }
        }

        return history;
    }

    /** Compare two deployments to see what changed */
    public DeploymentComparisonData compareDeployments(String environment) throws IOException {
        var deployments = repository.listDeployments(null, environment, null, null).toList();

        if (deployments.size() < 2) {
            return null;
        }

        GHDeployment current = deployments.get(0);
        GHDeployment previous = deployments.get(1);

        // Get commits for both deployments
        GHCommit currentCommit = repository.getCommit(current.getSha());
        GHCommit previousCommit = repository.getCommit(previous.getSha());

        // Compare the two commits
        GHCompare comparison = repository.getCompare(previous.getSha(), current.getSha());

        // Calculate time between deployments
        Duration timeBetween =
                Duration.between(
                        previous.getCreatedAt().toInstant(), current.getCreatedAt().toInstant());

        return new DeploymentComparisonData(
                current, previous, currentCommit, previousCommit, comparison, timeBetween);
    }

    /** Get deployment metrics across all environments */
    public DeploymentMetrics getDeploymentMetrics() throws IOException {
        var allDeployments = repository.listDeployments(null, null, null, null).toList();

        // Total deployments
        int totalDeployments = allDeployments.size();

        // Deployments in last 7 days
        Instant sevenDaysAgo = Instant.now().minus(Duration.ofDays(7));
        long deploymentsLast7Days = 0;
        for (var dep : allDeployments) {
            try {
                if (dep.getCreatedAt().toInstant().isAfter(sevenDaysAgo)) {
                    deploymentsLast7Days++;
                }
            } catch (IOException e) {
                // Skip
            }
        }

        // Deployments today
        Instant today = Instant.now().minus(Duration.ofHours(24));
        long deploymentsToday = 0;
        for (var dep : allDeployments) {
            try {
                if (dep.getCreatedAt().toInstant().isAfter(today)) {
                    deploymentsToday++;
                }
            } catch (IOException e) {
                // Skip
            }
        }

        // Calculate average deployment frequency (deployments per day)
        double avgDeploymentsPerDay = deploymentsLast7Days / 7.0;

        // Count environments
        Set<String> environments = new HashSet<>();
        for (var dep : allDeployments) {
            environments.add(dep.getEnvironment());
        }

        // Calculate success rate
        long successfulDeployments = 0;
        for (var dep : allDeployments) {
            try {
                var statuses = dep.listStatuses().toList();
                if (!statuses.isEmpty()
                        && "success".equalsIgnoreCase(statuses.get(0).getState().name())) {
                    successfulDeployments++;
                }
            } catch (IOException e) {
                // Skip
            }
        }
        double overallSuccessRate =
                totalDeployments > 0 ? (successfulDeployments * 100.0 / totalDeployments) : 0.0;

        return new DeploymentMetrics(
                totalDeployments,
                deploymentsToday,
                deploymentsLast7Days,
                avgDeploymentsPerDay,
                environments.size(),
                overallSuccessRate);
    }

    // Data classes

    public static class DeploymentTrackingData {
        public final List<EnvironmentDeploymentData> environments;
        public final int totalDeployments;

        public DeploymentTrackingData(
                List<EnvironmentDeploymentData> environments, int totalDeployments) {
            this.environments = environments;
            this.totalDeployments = totalDeployments;
        }
    }

    public static class EnvironmentDeploymentData {
        public final String environmentName;
        public final GHDeployment latestDeployment;
        public final String currentStatus;
        public final Date statusUpdatedAt;
        public final List<GHDeployment> recentDeployments;
        public final long deploymentsLast30Days;
        public final double successRate;
        public final long totalDeployments;

        public EnvironmentDeploymentData(
                String environmentName,
                GHDeployment latestDeployment,
                String currentStatus,
                Date statusUpdatedAt,
                List<GHDeployment> recentDeployments,
                long deploymentsLast30Days,
                double successRate,
                long totalDeployments) {
            this.environmentName = environmentName;
            this.latestDeployment = latestDeployment;
            this.currentStatus = currentStatus;
            this.statusUpdatedAt = statusUpdatedAt;
            this.recentDeployments = recentDeployments;
            this.deploymentsLast30Days = deploymentsLast30Days;
            this.successRate = successRate;
            this.totalDeployments = totalDeployments;
        }
    }

    public static class DeploymentHistoryEntry {
        public final long deploymentId;
        public final String commitSha;
        public final String environment;
        public final String status;
        public final String statusDescription;
        public final Date deployedAt;
        public final Date statusUpdatedAt;
        public final String deployedBy;
        public final String commitMessage;
        public final String task;

        public DeploymentHistoryEntry(
                long deploymentId,
                String commitSha,
                String environment,
                String status,
                String statusDescription,
                Date deployedAt,
                Date statusUpdatedAt,
                String deployedBy,
                String commitMessage,
                String task) {
            this.deploymentId = deploymentId;
            this.commitSha = commitSha;
            this.environment = environment;
            this.status = status;
            this.statusDescription = statusDescription;
            this.deployedAt = deployedAt;
            this.statusUpdatedAt = statusUpdatedAt;
            this.deployedBy = deployedBy;
            this.commitMessage = commitMessage;
            this.task = task;
        }
    }

    public static class DeploymentComparisonData {
        public final GHDeployment currentDeployment;
        public final GHDeployment previousDeployment;
        public final GHCommit currentCommit;
        public final GHCommit previousCommit;
        public final GHCompare comparison;
        public final Duration timeBetweenDeployments;

        public DeploymentComparisonData(
                GHDeployment currentDeployment,
                GHDeployment previousDeployment,
                GHCommit currentCommit,
                GHCommit previousCommit,
                GHCompare comparison,
                Duration timeBetweenDeployments) {
            this.currentDeployment = currentDeployment;
            this.previousDeployment = previousDeployment;
            this.currentCommit = currentCommit;
            this.previousCommit = previousCommit;
            this.comparison = comparison;
            this.timeBetweenDeployments = timeBetweenDeployments;
        }
    }

    public static class DeploymentMetrics {
        public final int totalDeployments;
        public final long deploymentsToday;
        public final long deploymentsLast7Days;
        public final double avgDeploymentsPerDay;
        public final int environmentCount;
        public final double overallSuccessRate;

        public DeploymentMetrics(
                int totalDeployments,
                long deploymentsToday,
                long deploymentsLast7Days,
                double avgDeploymentsPerDay,
                int environmentCount,
                double overallSuccessRate) {
            this.totalDeployments = totalDeployments;
            this.deploymentsToday = deploymentsToday;
            this.deploymentsLast7Days = deploymentsLast7Days;
            this.avgDeploymentsPerDay = avgDeploymentsPerDay;
            this.environmentCount = environmentCount;
            this.overallSuccessRate = overallSuccessRate;
        }
    }
}
