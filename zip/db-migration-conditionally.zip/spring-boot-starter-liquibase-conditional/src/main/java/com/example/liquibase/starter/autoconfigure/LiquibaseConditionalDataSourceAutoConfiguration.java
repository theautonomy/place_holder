package com.example.liquibase.starter.autoconfigure;

import javax.sql.DataSource;

import com.example.liquibase.starter.condition.ConditionalOnLiquibaseChangesets;
import com.zaxxer.hikari.HikariDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(LiquibaseConditionalProperties.class)
public class LiquibaseConditionalDataSourceAutoConfiguration {

    private static final Logger logger =
            LoggerFactory.getLogger(LiquibaseConditionalDataSourceAutoConfiguration.class);

    @Bean
    @Qualifier("liquibaseDataSource")
    @ConditionalOnLiquibaseChangesets
    @ConditionalOnProperty(prefix = "liquibase.datasource", name = "url")
    public DataSource liquibaseDataSource(LiquibaseConditionalProperties properties) {
        LiquibaseConditionalProperties.DataSourceProperties dsProps = properties.getDatasource();
        logger.info("Creating dedicated Liquibase DataSource for URL: {}", dsProps.getUrl());
        logger.debug("Using deploy username: {}", dsProps.getDeployUsername());

        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(dsProps.getUrl());
        // Use deploy credentials for Liquibase operations (schema changes)
        dataSource.setUsername(dsProps.getDeployUsername());
        dataSource.setPassword(dsProps.getDeployPassword());
        dataSource.setDriverClassName(dsProps.getDriverClassName());
        return dataSource;
    }
}
