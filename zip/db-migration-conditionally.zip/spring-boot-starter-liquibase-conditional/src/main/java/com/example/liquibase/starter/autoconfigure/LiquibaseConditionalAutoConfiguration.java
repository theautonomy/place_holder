package com.example.liquibase.starter.autoconfigure;

import javax.sql.DataSource;

import com.example.liquibase.starter.condition.ConditionalOnLiquibaseChangesets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

import liquibase.integration.spring.SpringLiquibase;

@AutoConfiguration(before = LiquibaseAutoConfiguration.class)
@EnableConfigurationProperties(LiquibaseConditionalProperties.class)
public class LiquibaseConditionalAutoConfiguration {

    private static final Logger logger =
            LoggerFactory.getLogger(LiquibaseConditionalAutoConfiguration.class);

    @Bean
    @Primary
    @ConditionalOnLiquibaseChangesets
    public SpringLiquibase liquibase(
            DataSource primaryDataSource,
            LiquibaseConditionalProperties properties,
            Environment environment,
            @Autowired(required = false) @Qualifier("liquibaseDataSource")
                    DataSource liquibaseDataSource) {

        logger.info("New changesets found, enabling Liquibase auto-configuration");
        DataSource dataSource =
                liquibaseDataSource != null ? liquibaseDataSource : primaryDataSource;
        return createSpringLiquibase(dataSource, properties, environment, true);
    }

    @Bean
    @Primary
    @ConditionalOnMissingBean(SpringLiquibase.class)
    public SpringLiquibase noOpLiquibase(
            DataSource primaryDataSource,
            LiquibaseConditionalProperties properties,
            Environment environment) {
        logger.info("No new changesets found, disabling Liquibase auto-configuration");
        return createSpringLiquibase(primaryDataSource, properties, environment, false);
    }

    private SpringLiquibase createSpringLiquibase(
            DataSource dataSource,
            LiquibaseConditionalProperties properties,
            Environment environment,
            boolean shouldRun) {
        SpringLiquibase liquibase = new SpringLiquibase();
        liquibase.setDataSource(dataSource);
        liquibase.setChangeLog(resolveChangeLogFile(properties, environment));
        liquibase.setShouldRun(shouldRun);
        return liquibase;
    }

    private String resolveChangeLogFile(
            LiquibaseConditionalProperties properties, Environment environment) {
        String changeLogFile = properties.getChangeLog();
        if (changeLogFile == null) {
            changeLogFile = environment.getProperty("spring.liquibase.change-log");
        }
        return changeLogFile;
    }
}
