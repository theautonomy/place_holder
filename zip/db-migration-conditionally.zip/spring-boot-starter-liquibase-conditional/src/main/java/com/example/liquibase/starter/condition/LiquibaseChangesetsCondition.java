package com.example.liquibase.starter.condition;

import java.sql.Connection;

import com.zaxxer.hikari.HikariDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import liquibase.Contexts;
import liquibase.LabelExpression;
import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;
import liquibase.resource.ResourceAccessor;

public class LiquibaseChangesetsCondition extends SpringBootCondition {

    private static final Logger logger =
            LoggerFactory.getLogger(LiquibaseChangesetsCondition.class);

    @Override
    public ConditionOutcome getMatchOutcome(
            ConditionContext context, AnnotatedTypeMetadata metadata) {
        try {
            logger.debug("Evaluating LiquibaseChangesetsCondition");

            HikariDataSource dataSource = createDataSource(context);
            if (dataSource == null) {
                return ConditionOutcome.noMatch("No DataSource configuration found");
            }

            String changeLogFile = resolveChangeLogFile(context);
            if (changeLogFile == null) {
                return ConditionOutcome.noMatch("No Liquibase changelog configured");
            }

            try (Connection connection = dataSource.getConnection()) {
                Database database =
                        DatabaseFactory.getInstance()
                                .findCorrectDatabaseImplementation(new JdbcConnection(connection));

                ResourceAccessor resourceAccessor =
                        new ClassLoaderResourceAccessor(
                                Thread.currentThread().getContextClassLoader());
                String changelogPath =
                        changeLogFile.startsWith("classpath:")
                                ? changeLogFile.substring(10)
                                : changeLogFile;

                Liquibase liquibase = new Liquibase(changelogPath, resourceAccessor, database);

                int unrunChangeSets =
                        liquibase.listUnrunChangeSets(new Contexts(), new LabelExpression()).size();
                logger.debug(
                        "Found {} unrun changesets in changelog: {}",
                        unrunChangeSets,
                        changeLogFile);

                if (unrunChangeSets > 0) {
                    logger.info(
                            "LiquibaseChangesetsCondition matched: {} unrun changesets found",
                            unrunChangeSets);
                    return ConditionOutcome.match("Found " + unrunChangeSets + " unrun changesets");
                } else {
                    logger.debug(
                            "LiquibaseChangesetsCondition not matched: no unrun changesets found");
                    return ConditionOutcome.noMatch("No unrun changesets found");
                }
            } finally {
                dataSource.close();
            }
        } catch (Exception e) {
            return ConditionOutcome.noMatch("Error checking for changesets: " + e.getMessage());
        }
    }

    private HikariDataSource createDataSource(ConditionContext context) {
        String url = context.getEnvironment().getProperty("liquibase.datasource.url");
        if (url == null) {
            return null;
        }

        String driverClassName =
                context.getEnvironment().getProperty("liquibase.datasource.driver-class-name");
        String username = context.getEnvironment().getProperty("liquibase.datasource.rw_username");
        String password = context.getEnvironment().getProperty("liquibase.datasource.rw_password");

        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setDriverClassName(driverClassName);
        return dataSource;
    }

    private String resolveChangeLogFile(ConditionContext context) {
        String changeLogFile = context.getEnvironment().getProperty("liquibase.change-log");
        if (changeLogFile == null) {
            changeLogFile = context.getEnvironment().getProperty("spring.liquibase.change-log");
        }
        return changeLogFile;
    }
}
