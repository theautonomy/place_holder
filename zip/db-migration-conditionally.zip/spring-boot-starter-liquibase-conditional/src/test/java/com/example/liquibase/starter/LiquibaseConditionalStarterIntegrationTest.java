package com.example.liquibase.starter;

import static org.assertj.core.api.Assertions.*;

import javax.sql.DataSource;

import com.example.liquibase.starter.autoconfigure.LiquibaseConditionalAutoConfiguration;
import com.example.liquibase.starter.autoconfigure.LiquibaseConditionalDataSourceAutoConfiguration;
import com.example.liquibase.starter.autoconfigure.LiquibaseConditionalProperties;
import com.zaxxer.hikari.HikariDataSource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

class LiquibaseConditionalStarterIntegrationTest {

    private final ApplicationContextRunner contextRunner =
            new ApplicationContextRunner()
                    .withConfiguration(
                            AutoConfigurations.of(
                                    DataSourceAutoConfiguration.class,
                                    LiquibaseConditionalAutoConfiguration.class,
                                    LiquibaseConditionalDataSourceAutoConfiguration.class));

    @Test
    void testStarterAutoConfigurationLoads() {
        // Test that the starter can load the auto-configurations without errors
        assertThat(LiquibaseConditionalAutoConfiguration.class).isNotNull();
        assertThat(LiquibaseConditionalDataSourceAutoConfiguration.class).isNotNull();
        assertThat(LiquibaseConditionalProperties.class).isNotNull();
    }

    @Test
    void testPropertiesOnlyConfiguration() {
        // Test that properties bean can be created in isolation
        new ApplicationContextRunner()
                .withUserConfiguration(PropertiesOnlyConfiguration.class)
                .withPropertyValues(
                        "liquibase.change-log=classpath:test-changelog.xml",
                        "liquibase.datasource.url=jdbc:h2:mem:testdb",
                        "liquibase.datasource.driver-class-name=org.h2.Driver",
                        "liquibase.datasource.rw_username=sa",
                        "liquibase.datasource.rw_password=")
                .run(
                        context -> {
                            // Check if any properties bean exists
                            assertThat(
                                            context.getBeanNamesForType(
                                                    LiquibaseConditionalProperties.class))
                                    .hasSizeGreaterThan(0);
                            LiquibaseConditionalProperties properties =
                                    context.getBean(LiquibaseConditionalProperties.class);
                            assertThat(properties.getChangeLog())
                                    .isEqualTo("classpath:test-changelog.xml");
                            assertThat(properties.getDatasource().getUrl())
                                    .isEqualTo("jdbc:h2:mem:testdb");
                        });
    }

    @Configuration
    static class DataSourceConfiguration {
        @Bean
        public DataSource existingDataSource() {
            HikariDataSource dataSource = new HikariDataSource();
            dataSource.setJdbcUrl("jdbc:h2:mem:existing;DB_CLOSE_DELAY=-1");
            dataSource.setUsername("sa");
            dataSource.setPassword("");
            dataSource.setDriverClassName("org.h2.Driver");
            return dataSource;
        }
    }

    @Configuration
    @EnableConfigurationProperties(LiquibaseConditionalProperties.class)
    static class PropertiesOnlyConfiguration {
        // Only provides properties bean for testing
    }
}
