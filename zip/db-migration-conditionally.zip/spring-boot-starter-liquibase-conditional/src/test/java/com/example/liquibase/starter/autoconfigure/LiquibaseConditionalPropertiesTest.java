package com.example.liquibase.starter.autoconfigure;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LiquibaseConditionalPropertiesTest {

    private LiquibaseConditionalProperties properties;

    @BeforeEach
    void setUp() {
        properties = new LiquibaseConditionalProperties();
    }

    @Test
    void testDefaultValues() {
        // Then
        assertThat(properties.getChangeLog()).isNull();
        assertThat(properties.getDatasource()).isNotNull();

        LiquibaseConditionalProperties.DataSourceProperties datasource = properties.getDatasource();
        assertThat(datasource.getUrl()).isNull();
        assertThat(datasource.getDriverClassName()).isNull();
        assertThat(datasource.getDeployUsername()).isNull();
        assertThat(datasource.getDeployPassword()).isNull();
        assertThat(datasource.getRwUsername()).isNull();
        assertThat(datasource.getRwPassword()).isNull();
    }

    @Test
    void testSetChangeLog() {
        // Given
        String changeLog = "classpath:db/changelog/master.xml";

        // When
        properties.setChangeLog(changeLog);

        // Then
        assertThat(properties.getChangeLog()).isEqualTo(changeLog);
    }

    @Test
    void testDatasourceProperties() {
        // Given
        LiquibaseConditionalProperties.DataSourceProperties datasource = properties.getDatasource();
        String url = "jdbc:h2:mem:testdb";
        String driverClassName = "org.h2.Driver";
        String deployUsername = "deploy_user";
        String deployPassword = "deploy_pass";
        String rwUsername = "rw_user";
        String rwPassword = "rw_pass";

        // When
        datasource.setUrl(url);
        datasource.setDriverClassName(driverClassName);
        datasource.setDeployUsername(deployUsername);
        datasource.setDeployPassword(deployPassword);
        datasource.setRwUsername(rwUsername);
        datasource.setRwPassword(rwPassword);

        // Then
        assertThat(datasource.getUrl()).isEqualTo(url);
        assertThat(datasource.getDriverClassName()).isEqualTo(driverClassName);
        assertThat(datasource.getDeployUsername()).isEqualTo(deployUsername);
        assertThat(datasource.getDeployPassword()).isEqualTo(deployPassword);
        assertThat(datasource.getRwUsername()).isEqualTo(rwUsername);
        assertThat(datasource.getRwPassword()).isEqualTo(rwPassword);
    }

    @Test
    void testDatasourceDefaults() {
        // Given
        LiquibaseConditionalProperties.DataSourceProperties datasource =
                new LiquibaseConditionalProperties.DataSourceProperties();

        // Then
        assertThat(datasource.getUrl()).isNull();
        assertThat(datasource.getDriverClassName()).isNull();
        assertThat(datasource.getDeployUsername()).isNull();
        assertThat(datasource.getDeployPassword()).isNull();
        assertThat(datasource.getRwUsername()).isNull();
        assertThat(datasource.getRwPassword()).isNull();
    }

    @Test
    void testSetDatasource() {
        // Given
        LiquibaseConditionalProperties.DataSourceProperties newDatasource =
                new LiquibaseConditionalProperties.DataSourceProperties();
        newDatasource.setUrl("jdbc:postgresql://localhost:5432/testdb");
        newDatasource.setDriverClassName("org.postgresql.Driver");

        // When
        properties.setDatasource(newDatasource);

        // Then
        assertThat(properties.getDatasource()).isEqualTo(newDatasource);
        assertThat(properties.getDatasource().getUrl())
                .isEqualTo("jdbc:postgresql://localhost:5432/testdb");
        assertThat(properties.getDatasource().getDriverClassName())
                .isEqualTo("org.postgresql.Driver");
    }

    @Test
    void testCompleteConfiguration() {
        // Given
        String changeLog = "classpath:db/changelog/master.xml";
        String url = "jdbc:mysql://localhost:3306/testdb";
        String driverClassName = "com.mysql.cj.jdbc.Driver";
        String deployUsername = "liquibase_deploy";
        String deployPassword = "deploy_secret";
        String rwUsername = "app_user";
        String rwPassword = "app_secret";

        // When
        properties.setChangeLog(changeLog);
        properties.getDatasource().setUrl(url);
        properties.getDatasource().setDriverClassName(driverClassName);
        properties.getDatasource().setDeployUsername(deployUsername);
        properties.getDatasource().setDeployPassword(deployPassword);
        properties.getDatasource().setRwUsername(rwUsername);
        properties.getDatasource().setRwPassword(rwPassword);

        // Then
        assertThat(properties.getChangeLog()).isEqualTo(changeLog);
        assertThat(properties.getDatasource().getUrl()).isEqualTo(url);
        assertThat(properties.getDatasource().getDriverClassName()).isEqualTo(driverClassName);
        assertThat(properties.getDatasource().getDeployUsername()).isEqualTo(deployUsername);
        assertThat(properties.getDatasource().getDeployPassword()).isEqualTo(deployPassword);
        assertThat(properties.getDatasource().getRwUsername()).isEqualTo(rwUsername);
        assertThat(properties.getDatasource().getRwPassword()).isEqualTo(rwPassword);
    }
}
