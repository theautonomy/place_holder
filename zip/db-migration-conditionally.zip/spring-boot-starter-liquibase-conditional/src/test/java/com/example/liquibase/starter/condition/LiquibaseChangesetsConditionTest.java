package com.example.liquibase.starter.condition;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.lenient;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

@ExtendWith(MockitoExtension.class)
class LiquibaseChangesetsConditionTest {

    @Mock private ConditionContext context;

    @Mock private Environment environment;

    @Mock private AnnotatedTypeMetadata metadata;

    private LiquibaseChangesetsCondition condition;

    @BeforeEach
    void setUp() {
        condition = new LiquibaseChangesetsCondition();
        when(context.getEnvironment()).thenReturn(environment);
    }

    @Test
    void testGetMatchOutcome_NoDataSourceUrl_ReturnsNoMatch() {
        // Given
        when(environment.getProperty("liquibase.datasource.url")).thenReturn(null);

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).isEqualTo("No DataSource configuration found");
    }

    @Test
    void testGetMatchOutcome_NoChangelogConfigured_ReturnsNoMatch() {
        // Given
        when(environment.getProperty("liquibase.datasource.url")).thenReturn("jdbc:h2:mem:testdb");
        when(environment.getProperty("liquibase.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        when(environment.getProperty("liquibase.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("liquibase.datasource.rw_password")).thenReturn("password");
        when(environment.getProperty("liquibase.change-log")).thenReturn(null);

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).isEqualTo("No Liquibase changelog configured");
    }

    @Test
    void testGetMatchOutcome_DatabaseConnectionError_ReturnsNoMatch() {
        // Given
        lenient()
                .when(environment.getProperty("liquibase.datasource.url"))
                .thenReturn("jdbc:h2:mem:invaliddb");
        lenient()
                .when(environment.getProperty("liquibase.datasource.driver-class-name"))
                .thenReturn("invalid.Driver");
        lenient()
                .when(environment.getProperty("liquibase.datasource.rw_username"))
                .thenReturn("sa");
        lenient()
                .when(environment.getProperty("liquibase.datasource.rw_password"))
                .thenReturn("password");
        lenient()
                .when(environment.getProperty("liquibase.change-log"))
                .thenReturn("classpath:db/changelog/test.xml");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).startsWith("Error checking for changesets:");
    }

    @Test
    void testGetMatchOutcome_ValidConfiguration_ChecksForChangesets() {
        // Given - Setup valid H2 in-memory database configuration
        when(environment.getProperty("liquibase.datasource.url"))
                .thenReturn("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
        when(environment.getProperty("liquibase.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        when(environment.getProperty("liquibase.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("liquibase.datasource.rw_password")).thenReturn("");
        when(environment.getProperty("liquibase.change-log"))
                .thenReturn("classpath:test-changelog.xml");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        // The condition actually works and finds changesets in our test-changelog.xml
        assertThat(outcome).isNotNull();
        assertThat(outcome.getMessage())
                .satisfiesAnyOf(
                        msg -> assertThat(msg).contains("Error checking for changesets"),
                        msg -> assertThat(msg).contains("No unrun changesets found"),
                        msg -> assertThat(msg).contains("Found"),
                        msg -> assertThat(msg).contains("unrun changesets"));
    }

    @Test
    void testGetMatchOutcome_PropertyPrecedence() {
        // Given - Test that liquibase.change-log takes precedence over spring.liquibase.change-log
        lenient()
                .when(environment.getProperty("liquibase.datasource.url"))
                .thenReturn("jdbc:h2:mem:testdb");
        lenient()
                .when(environment.getProperty("liquibase.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        lenient()
                .when(environment.getProperty("liquibase.datasource.rw_username"))
                .thenReturn("sa");
        lenient().when(environment.getProperty("liquibase.datasource.rw_password")).thenReturn("");
        lenient()
                .when(environment.getProperty("liquibase.change-log"))
                .thenReturn("classpath:primary-changelog.xml");
        lenient()
                .when(environment.getProperty("spring.liquibase.change-log"))
                .thenReturn("classpath:fallback-changelog.xml");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        // The condition should use liquibase.change-log, not spring.liquibase.change-log
        assertThat(outcome).isNotNull();
        // We can't verify the exact changeset count without a real database and changelog,
        // but we can verify the condition runs without configuration errors
    }

    @Test
    void testGetMatchOutcome_FallbackToSpringLiquibaseChangeLog() {
        // Given - Test fallback when liquibase.change-log is not set
        when(environment.getProperty("liquibase.datasource.url")).thenReturn("jdbc:h2:mem:testdb");
        when(environment.getProperty("liquibase.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        when(environment.getProperty("liquibase.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("liquibase.datasource.rw_password")).thenReturn("");
        when(environment.getProperty("liquibase.change-log")).thenReturn(null);
        when(environment.getProperty("spring.liquibase.change-log"))
                .thenReturn("classpath:fallback-changelog.xml");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        assertThat(outcome).isNotNull();
        // Should use the fallback spring.liquibase.change-log property
    }
}
