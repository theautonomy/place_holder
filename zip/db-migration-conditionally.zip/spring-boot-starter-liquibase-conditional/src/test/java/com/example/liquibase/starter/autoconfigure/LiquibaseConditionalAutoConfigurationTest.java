package com.example.liquibase.starter.autoconfigure;

import static org.assertj.core.api.Assertions.assertThat;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

class LiquibaseConditionalAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner =
            new ApplicationContextRunner()
                    .withConfiguration(
                            AutoConfigurations.of(
                                    DataSourceAutoConfiguration.class,
                                    LiquibaseConditionalAutoConfiguration.class));

    @Test
    void testAutoConfigurationExists() {
        // Verify the auto-configuration class can be loaded
        assertThat(LiquibaseConditionalAutoConfiguration.class).isNotNull();
        assertThat(LiquibaseConditionalAutoConfiguration.class)
                .hasAnnotation(org.springframework.boot.autoconfigure.AutoConfiguration.class);
        assertThat(LiquibaseConditionalAutoConfiguration.class)
                .hasAnnotation(EnableConfigurationProperties.class);
    }

    @Test
    void testPropertiesBean() {
        // Properties bean should always be available - test only the properties configuration part
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of())
                .withUserConfiguration(PropertiesOnlyConfiguration.class)
                .run(
                        context -> {
                            // Check if any properties bean exists
                            assertThat(
                                            context.getBeanNamesForType(
                                                    LiquibaseConditionalProperties.class))
                                    .hasSizeGreaterThan(0);
                            LiquibaseConditionalProperties properties =
                                    context.getBean(LiquibaseConditionalProperties.class);
                            assertThat(properties).isNotNull();
                            assertThat(properties.getDatasource()).isNotNull();
                        });
    }

    @Test
    void testPropertiesBindingFromConfigurationProperties() {
        // Test that configuration properties are properly bound
        new ApplicationContextRunner()
                .withUserConfiguration(PropertiesOnlyConfiguration.class)
                .withPropertyValues(
                        "liquibase.change-log=classpath:test-changelog.xml",
                        "liquibase.datasource.url=jdbc:h2:mem:bindingtest",
                        "liquibase.datasource.driver-class-name=org.h2.Driver",
                        "liquibase.datasource.deploy_username=deploy_user",
                        "liquibase.datasource.deploy_password=deploy_pass",
                        "liquibase.datasource.rw_username=rw_user",
                        "liquibase.datasource.rw_password=rw_pass")
                .run(
                        context -> {
                            LiquibaseConditionalProperties properties =
                                    context.getBean(LiquibaseConditionalProperties.class);

                            assertThat(properties.getChangeLog())
                                    .isEqualTo("classpath:test-changelog.xml");
                            assertThat(properties.getDatasource().getUrl())
                                    .isEqualTo("jdbc:h2:mem:bindingtest");
                            assertThat(properties.getDatasource().getDriverClassName())
                                    .isEqualTo("org.h2.Driver");
                            assertThat(properties.getDatasource().getDeployUsername())
                                    .isEqualTo("deploy_user");
                            assertThat(properties.getDatasource().getDeployPassword())
                                    .isEqualTo("deploy_pass");
                            assertThat(properties.getDatasource().getRwUsername())
                                    .isEqualTo("rw_user");
                            assertThat(properties.getDatasource().getRwPassword())
                                    .isEqualTo("rw_pass");
                        });
    }

    @Test
    void testConfigurationAnnotations() {
        // Verify the configuration has the correct annotations
        org.springframework.boot.autoconfigure.AutoConfiguration autoConfigAnnotation =
                LiquibaseConditionalAutoConfiguration.class.getAnnotation(
                        org.springframework.boot.autoconfigure.AutoConfiguration.class);
        assertThat(autoConfigAnnotation).isNotNull();

        // Verify it runs before LiquibaseAutoConfiguration
        Class<?>[] beforeClasses = autoConfigAnnotation.before();
        assertThat(beforeClasses).hasSize(1);
        assertThat(beforeClasses[0])
                .isEqualTo(
                        org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration
                                .class);
    }

    @Configuration
    static class TestConfiguration {
        @Bean
        public DataSource testDataSource() {
            HikariDataSource dataSource = new HikariDataSource();
            dataSource.setJdbcUrl("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
            dataSource.setUsername("sa");
            dataSource.setPassword("");
            dataSource.setDriverClassName("org.h2.Driver");
            return dataSource;
        }
    }

    @Configuration
    @EnableConfigurationProperties(LiquibaseConditionalProperties.class)
    static class PropertiesOnlyConfiguration {
        // Only provides properties bean for testing
    }
}
