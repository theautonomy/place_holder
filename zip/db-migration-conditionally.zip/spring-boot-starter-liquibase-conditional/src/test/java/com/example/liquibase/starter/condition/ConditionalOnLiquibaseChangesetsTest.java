package com.example.liquibase.starter.condition;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Conditional;

class ConditionalOnLiquibaseChangesetsTest {

    @Test
    void testAnnotationPresent() {
        // Verify the annotation exists and has the expected properties
        assertThat(ConditionalOnLiquibaseChangesets.class.isAnnotation()).isTrue();
    }

    @Test
    void testAnnotationHasConditionalAnnotation() {
        // Verify the annotation is properly annotated with @Conditional
        Conditional conditional =
                ConditionalOnLiquibaseChangesets.class.getAnnotation(Conditional.class);
        assertThat(conditional).isNotNull();

        // Verify it points to the correct condition class
        Class<?>[] value = conditional.value();
        assertThat(value).hasSize(1);
        assertThat(value[0]).isEqualTo(LiquibaseChangesetsCondition.class);
    }

    @Test
    void testAnnotationRetention() {
        // Verify the annotation has runtime retention
        java.lang.annotation.Retention retention =
                ConditionalOnLiquibaseChangesets.class.getAnnotation(
                        java.lang.annotation.Retention.class);
        assertThat(retention).isNotNull();
        assertThat(retention.value()).isEqualTo(java.lang.annotation.RetentionPolicy.RUNTIME);
    }

    @Test
    void testAnnotationTarget() {
        // Verify the annotation can be applied to types and methods
        java.lang.annotation.Target target =
                ConditionalOnLiquibaseChangesets.class.getAnnotation(
                        java.lang.annotation.Target.class);
        assertThat(target).isNotNull();

        java.lang.annotation.ElementType[] elementTypes = target.value();
        assertThat(elementTypes).hasSizeGreaterThanOrEqualTo(1);

        // Should allow TYPE and METHOD targets
        assertThat(elementTypes)
                .contains(
                        java.lang.annotation.ElementType.TYPE,
                        java.lang.annotation.ElementType.METHOD);
    }

    @Test
    void testAnnotationCanBeAppliedToClass() {
        // Test that the annotation can be applied to a class
        @ConditionalOnLiquibaseChangesets
        class TestClass {}

        ConditionalOnLiquibaseChangesets annotation =
                TestClass.class.getAnnotation(ConditionalOnLiquibaseChangesets.class);
        assertThat(annotation).isNotNull();
    }

    @Test
    void testAnnotationCanBeAppliedToMethod() throws NoSuchMethodException {
        // Test that the annotation can be applied to a method
        class TestClass {
            @ConditionalOnLiquibaseChangesets
            public void testMethod() {}
        }

        ConditionalOnLiquibaseChangesets annotation =
                TestClass.class
                        .getMethod("testMethod")
                        .getAnnotation(ConditionalOnLiquibaseChangesets.class);
        assertThat(annotation).isNotNull();
    }
}
