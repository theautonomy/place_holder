INSERT INTO test_table (id, name) VALUES 
(1, 'Test Record 1'),
(2, 'Test Record 2');