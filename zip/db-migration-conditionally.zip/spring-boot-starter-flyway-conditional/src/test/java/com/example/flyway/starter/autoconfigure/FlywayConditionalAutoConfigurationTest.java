package com.example.flyway.starter.autoconfigure;

import static org.assertj.core.api.Assertions.*;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

class FlywayConditionalAutoConfigurationTest {

    private final ApplicationContextRunner contextRunner =
            new ApplicationContextRunner()
                    .withConfiguration(
                            AutoConfigurations.of(
                                    DataSourceAutoConfiguration.class,
                                    FlywayConditionalAutoConfiguration.class));

    @Test
    void testAutoConfigurationExists() {
        // Verify the auto-configuration class can be loaded
        assertThat(FlywayConditionalAutoConfiguration.class).isNotNull();
        assertThat(FlywayConditionalAutoConfiguration.class)
                .hasAnnotation(org.springframework.boot.autoconfigure.AutoConfiguration.class);
        assertThat(FlywayConditionalAutoConfiguration.class)
                .hasAnnotation(EnableConfigurationProperties.class);
    }

    @Test
    void testPropertiesBean() {
        // Properties bean should always be available - test only the properties configuration part
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of())
                .withUserConfiguration(PropertiesOnlyConfiguration.class)
                .run(
                        context -> {
                            // Check if any properties bean exists
                            assertThat(
                                            context.getBeanNamesForType(
                                                    FlywayConditionalProperties.class))
                                    .hasSizeGreaterThan(0);
                            FlywayConditionalProperties properties =
                                    context.getBean(FlywayConditionalProperties.class);
                            assertThat(properties).isNotNull();
                            assertThat(properties.getDatasource()).isNotNull();
                        });
    }

    @Test
    void testPropertiesBindingFromConfigurationProperties() {
        // Test that configuration properties are properly bound
        new ApplicationContextRunner()
                .withUserConfiguration(PropertiesOnlyConfiguration.class)
                .withPropertyValues(
                        "flyway.locations=classpath:db/migration,classpath:db/testdata",
                        "flyway.datasource.url=jdbc:h2:mem:bindingtest",
                        "flyway.datasource.driver-class-name=org.h2.Driver",
                        "flyway.datasource.deploy_username=deploy_user",
                        "flyway.datasource.deploy_password=deploy_pass",
                        "flyway.datasource.rw_username=rw_user",
                        "flyway.datasource.rw_password=rw_pass")
                .run(
                        context -> {
                            FlywayConditionalProperties properties =
                                    context.getBean(FlywayConditionalProperties.class);

                            assertThat(properties.getLocations())
                                    .isEqualTo("classpath:db/migration,classpath:db/testdata");
                            assertThat(properties.getDatasource().getUrl())
                                    .isEqualTo("jdbc:h2:mem:bindingtest");
                            assertThat(properties.getDatasource().getDriverClassName())
                                    .isEqualTo("org.h2.Driver");
                            assertThat(properties.getDatasource().getDeployUsername())
                                    .isEqualTo("deploy_user");
                            assertThat(properties.getDatasource().getDeployPassword())
                                    .isEqualTo("deploy_pass");
                            assertThat(properties.getDatasource().getRwUsername())
                                    .isEqualTo("rw_user");
                            assertThat(properties.getDatasource().getRwPassword())
                                    .isEqualTo("rw_pass");
                        });
    }

    @Test
    void testConfigurationAnnotations() {
        // Verify the configuration has the correct annotations
        org.springframework.boot.autoconfigure.AutoConfiguration autoConfigAnnotation =
                FlywayConditionalAutoConfiguration.class.getAnnotation(
                        org.springframework.boot.autoconfigure.AutoConfiguration.class);
        assertThat(autoConfigAnnotation).isNotNull();

        // Verify it runs before FlywayAutoConfiguration
        Class<?>[] beforeClasses = autoConfigAnnotation.before();
        assertThat(beforeClasses).hasSize(1);
        assertThat(beforeClasses[0])
                .isEqualTo(
                        org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration
                                .class);
    }

    @Configuration
    static class TestConfiguration {
        @Bean
        public DataSource testDataSource() {
            HikariDataSource dataSource = new HikariDataSource();
            dataSource.setJdbcUrl("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
            dataSource.setUsername("sa");
            dataSource.setPassword("");
            dataSource.setDriverClassName("org.h2.Driver");
            return dataSource;
        }
    }

    @Configuration
    @EnableConfigurationProperties(FlywayConditionalProperties.class)
    static class PropertiesOnlyConfiguration {
        // Only provides properties bean for testing
    }
}
