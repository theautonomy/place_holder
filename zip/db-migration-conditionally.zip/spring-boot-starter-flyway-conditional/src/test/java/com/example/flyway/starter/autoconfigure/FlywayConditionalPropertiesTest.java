package com.example.flyway.starter.autoconfigure;

import static org.assertj.core.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FlywayConditionalPropertiesTest {

    private FlywayConditionalProperties properties;

    @BeforeEach
    void setUp() {
        properties = new FlywayConditionalProperties();
    }

    @Test
    void testDefaultValues() {
        // Then
        assertThat(properties.isEnabled()).isTrue();
        assertThat(properties.getLocations()).isEqualTo("classpath:db/migration");
        assertThat(properties.getDatasource()).isNotNull();

        FlywayConditionalProperties.DataSourceProperties datasource = properties.getDatasource();
        assertThat(datasource.getUrl()).isNull();
        assertThat(datasource.getDriverClassName()).isNull();
        assertThat(datasource.getDeployUsername()).isNull();
        assertThat(datasource.getDeployPassword()).isNull();
        assertThat(datasource.getRwUsername()).isNull();
        assertThat(datasource.getRwPassword()).isNull();
    }

    @Test
    void testSetEnabled() {
        // When
        properties.setEnabled(false);

        // Then
        assertThat(properties.isEnabled()).isFalse();
    }

    @Test
    void testSetLocations() {
        // Given
        String locations = "classpath:db/migration,filesystem:migrations";

        // When
        properties.setLocations(locations);

        // Then
        assertThat(properties.getLocations()).isEqualTo(locations);
    }

    @Test
    void testDatasourceProperties() {
        // Given
        FlywayConditionalProperties.DataSourceProperties datasource = properties.getDatasource();
        String url = "jdbc:h2:mem:testdb";
        String driverClassName = "org.h2.Driver";
        String deployUsername = "deploy_user";
        String deployPassword = "deploy_pass";
        String rwUsername = "rw_user";
        String rwPassword = "rw_pass";

        // When
        datasource.setUrl(url);
        datasource.setDriverClassName(driverClassName);
        datasource.setDeployUsername(deployUsername);
        datasource.setDeployPassword(deployPassword);
        datasource.setRwUsername(rwUsername);
        datasource.setRwPassword(rwPassword);

        // Then
        assertThat(datasource.getUrl()).isEqualTo(url);
        assertThat(datasource.getDriverClassName()).isEqualTo(driverClassName);
        assertThat(datasource.getDeployUsername()).isEqualTo(deployUsername);
        assertThat(datasource.getDeployPassword()).isEqualTo(deployPassword);
        assertThat(datasource.getRwUsername()).isEqualTo(rwUsername);
        assertThat(datasource.getRwPassword()).isEqualTo(rwPassword);
    }

    @Test
    void testDatasourceDefaults() {
        // Given
        FlywayConditionalProperties.DataSourceProperties datasource =
                new FlywayConditionalProperties.DataSourceProperties();

        // Then
        assertThat(datasource.getUrl()).isNull();
        assertThat(datasource.getDriverClassName()).isNull();
        assertThat(datasource.getDeployUsername()).isNull();
        assertThat(datasource.getDeployPassword()).isNull();
        assertThat(datasource.getRwUsername()).isNull();
        assertThat(datasource.getRwPassword()).isNull();
    }

    @Test
    void testSetDatasource() {
        // Given
        FlywayConditionalProperties.DataSourceProperties newDatasource =
                new FlywayConditionalProperties.DataSourceProperties();
        newDatasource.setUrl("jdbc:postgresql://localhost:5432/testdb");
        newDatasource.setDriverClassName("org.postgresql.Driver");

        // When
        properties.setDatasource(newDatasource);

        // Then
        assertThat(properties.getDatasource()).isEqualTo(newDatasource);
        assertThat(properties.getDatasource().getUrl())
                .isEqualTo("jdbc:postgresql://localhost:5432/testdb");
        assertThat(properties.getDatasource().getDriverClassName())
                .isEqualTo("org.postgresql.Driver");
    }

    @Test
    void testCompleteConfiguration() {
        // Given
        String locations = "classpath:db/migration,classpath:db/testdata";
        String url = "jdbc:mysql://localhost:3306/testdb";
        String driverClassName = "com.mysql.cj.jdbc.Driver";
        String deployUsername = "flyway_deploy";
        String deployPassword = "deploy_secret";
        String rwUsername = "app_user";
        String rwPassword = "app_secret";

        // When
        properties.setEnabled(true);
        properties.setLocations(locations);
        properties.getDatasource().setUrl(url);
        properties.getDatasource().setDriverClassName(driverClassName);
        properties.getDatasource().setDeployUsername(deployUsername);
        properties.getDatasource().setDeployPassword(deployPassword);
        properties.getDatasource().setRwUsername(rwUsername);
        properties.getDatasource().setRwPassword(rwPassword);

        // Then
        assertThat(properties.isEnabled()).isTrue();
        assertThat(properties.getLocations()).isEqualTo(locations);
        assertThat(properties.getDatasource().getUrl()).isEqualTo(url);
        assertThat(properties.getDatasource().getDriverClassName()).isEqualTo(driverClassName);
        assertThat(properties.getDatasource().getDeployUsername()).isEqualTo(deployUsername);
        assertThat(properties.getDatasource().getDeployPassword()).isEqualTo(deployPassword);
        assertThat(properties.getDatasource().getRwUsername()).isEqualTo(rwUsername);
        assertThat(properties.getDatasource().getRwPassword()).isEqualTo(rwPassword);
    }
}
