package com.example.flyway.starter.condition;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

class FlywayMigrationsConditionTest {

    @Mock private ConditionContext context;

    @Mock private AnnotatedTypeMetadata metadata;

    @Mock private Environment environment;

    private FlywayMigrationsCondition condition;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        condition = new FlywayMigrationsCondition();
        when(context.getEnvironment()).thenReturn(environment);
    }

    @Test
    void testNoDataSourceConfiguration() {
        // Given
        when(environment.getProperty("flyway.datasource.url")).thenReturn(null);

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).isEqualTo("No DataSource configuration found");
    }

    @Test
    void testWithEmptyMigrationLocations() {
        // Given
        when(environment.getProperty("flyway.datasource.url")).thenReturn("jdbc:h2:mem:testdb");
        when(environment.getProperty("flyway.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        when(environment.getProperty("flyway.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("flyway.datasource.rw_password")).thenReturn("");
        when(environment.getProperty("flyway.locations")).thenReturn("classpath:db/nonexistent");
        when(environment.getProperty("spring.flyway.locations")).thenReturn(null);

        // When - Using a location that doesn't exist
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then - Should not match since no migrations found at specified location
        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).contains("No pending migrations found");
    }

    @Test
    void testWithValidConfiguration() {
        // Given
        when(environment.getProperty("flyway.datasource.url"))
                .thenReturn("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
        when(environment.getProperty("flyway.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        when(environment.getProperty("flyway.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("flyway.datasource.rw_password")).thenReturn("");
        when(environment.getProperty("flyway.locations")).thenReturn("classpath:db/migration");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then - Should match since we have test migrations
        assertThat(outcome.isMatch()).isTrue();
        assertThat(outcome.getMessage()).contains("Found 2 pending migrations");
    }

    @Test
    void testWithInvalidDriverClass() {
        // Given
        when(environment.getProperty("flyway.datasource.url")).thenReturn("jdbc:h2:mem:testdb");
        when(environment.getProperty("flyway.datasource.driver-class-name"))
                .thenReturn("invalid.Driver");
        when(environment.getProperty("flyway.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("flyway.datasource.rw_password")).thenReturn("");
        when(environment.getProperty("flyway.locations")).thenReturn("classpath:db/migration");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).contains("Error checking for migrations");
    }

    @Test
    void testWithSpringFlywayLocationsFallback() {
        // Given
        when(environment.getProperty("flyway.datasource.url"))
                .thenReturn("jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
        when(environment.getProperty("flyway.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        when(environment.getProperty("flyway.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("flyway.datasource.rw_password")).thenReturn("");
        when(environment.getProperty("flyway.locations")).thenReturn(null);
        when(environment.getProperty("spring.flyway.locations"))
                .thenReturn("classpath:db/migration");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then - Should match using spring.flyway.locations fallback
        assertThat(outcome.isMatch()).isTrue();
        assertThat(outcome.getMessage()).contains("Found 2 pending migrations");
    }

    @Test
    void testWithDatabaseConnectionError() {
        // Given
        when(environment.getProperty("flyway.datasource.url")).thenReturn("jdbc:invalid:invalid");
        when(environment.getProperty("flyway.datasource.driver-class-name"))
                .thenReturn("org.h2.Driver");
        when(environment.getProperty("flyway.datasource.rw_username")).thenReturn("sa");
        when(environment.getProperty("flyway.datasource.rw_password")).thenReturn("");
        when(environment.getProperty("flyway.locations")).thenReturn("classpath:db/migration");

        // When
        ConditionOutcome outcome = condition.getMatchOutcome(context, metadata);

        // Then
        assertThat(outcome.isMatch()).isFalse();
        assertThat(outcome.getMessage()).contains("Error checking for migrations");
    }
}
