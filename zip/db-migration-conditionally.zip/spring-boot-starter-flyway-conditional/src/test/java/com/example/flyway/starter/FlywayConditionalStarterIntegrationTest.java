package com.example.flyway.starter;

import static org.assertj.core.api.Assertions.*;

import javax.sql.DataSource;

import com.example.flyway.starter.autoconfigure.FlywayConditionalAutoConfiguration;
import com.example.flyway.starter.autoconfigure.FlywayConditionalDataSourceAutoConfiguration;
import com.example.flyway.starter.autoconfigure.FlywayConditionalProperties;
import com.zaxxer.hikari.HikariDataSource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

class FlywayConditionalStarterIntegrationTest {

    private final ApplicationContextRunner contextRunner =
            new ApplicationContextRunner()
                    .withConfiguration(
                            AutoConfigurations.of(
                                    DataSourceAutoConfiguration.class,
                                    FlywayConditionalAutoConfiguration.class,
                                    FlywayConditionalDataSourceAutoConfiguration.class));

    @Test
    void testStarterAutoConfigurationLoads() {
        // Test that the starter can load the auto-configurations without errors
        assertThat(FlywayConditionalAutoConfiguration.class).isNotNull();
        assertThat(FlywayConditionalDataSourceAutoConfiguration.class).isNotNull();
        assertThat(FlywayConditionalProperties.class).isNotNull();
    }

    @Test
    void testPropertiesOnlyConfiguration() {
        // Test that properties bean can be created in isolation
        new ApplicationContextRunner()
                .withUserConfiguration(PropertiesOnlyConfiguration.class)
                .withPropertyValues(
                        "flyway.locations=classpath:db/migration",
                        "flyway.datasource.url=jdbc:h2:mem:testdb",
                        "flyway.datasource.driver-class-name=org.h2.Driver",
                        "flyway.datasource.rw_username=sa",
                        "flyway.datasource.rw_password=")
                .run(
                        context -> {
                            // Check if any properties bean exists
                            assertThat(
                                            context.getBeanNamesForType(
                                                    FlywayConditionalProperties.class))
                                    .hasSizeGreaterThan(0);
                            FlywayConditionalProperties properties =
                                    context.getBean(FlywayConditionalProperties.class);
                            assertThat(properties.getLocations())
                                    .isEqualTo("classpath:db/migration");
                            assertThat(properties.getDatasource().getUrl())
                                    .isEqualTo("jdbc:h2:mem:testdb");
                        });
    }

    @Configuration
    static class DataSourceConfiguration {
        @Bean
        public DataSource existingDataSource() {
            HikariDataSource dataSource = new HikariDataSource();
            dataSource.setJdbcUrl("jdbc:h2:mem:existing;DB_CLOSE_DELAY=-1");
            dataSource.setUsername("sa");
            dataSource.setPassword("");
            dataSource.setDriverClassName("org.h2.Driver");
            return dataSource;
        }
    }

    @Configuration
    @EnableConfigurationProperties(FlywayConditionalProperties.class)
    static class PropertiesOnlyConfiguration {
        // Only provides properties bean for testing
    }
}
