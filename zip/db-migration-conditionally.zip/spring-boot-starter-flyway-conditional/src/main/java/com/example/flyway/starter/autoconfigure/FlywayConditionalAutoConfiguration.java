package com.example.flyway.starter.autoconfigure;

import javax.sql.DataSource;

import com.example.flyway.starter.condition.ConditionalOnFlywayMigrations;

import org.flywaydb.core.Flyway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayMigrationInitializer;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

@AutoConfiguration(before = FlywayAutoConfiguration.class)
@EnableConfigurationProperties(FlywayConditionalProperties.class)
public class FlywayConditionalAutoConfiguration {

    private static final Logger logger =
            LoggerFactory.getLogger(FlywayConditionalAutoConfiguration.class);

    @Bean
    @ConditionalOnFlywayMigrations
    public Flyway flyway(
            DataSource primaryDataSource,
            FlywayConditionalProperties properties,
            Environment environment,
            @Autowired(required = false) @Qualifier("flywayDataSource")
                    DataSource flywayDataSource) {

        logger.info("New migrations found, enabling Flyway auto-configuration");
        DataSource dataSource = flywayDataSource != null ? flywayDataSource : primaryDataSource;
        return createFlyway(dataSource, properties, environment);
    }

    @Bean
    @ConditionalOnFlywayMigrations
    public FlywayMigrationInitializer flywayInitializer(Flyway flyway) {
        logger.info("Creating Flyway migration initializer to execute migrations on startup");
        return new FlywayMigrationInitializer(flyway, null);
    }

    private Flyway createFlyway(
            DataSource dataSource,
            FlywayConditionalProperties properties,
            Environment environment) {
        String[] locations = resolveMigrationLocations(properties, environment);

        return Flyway.configure().dataSource(dataSource).locations(locations).load();
    }

    private String[] resolveMigrationLocations(
            FlywayConditionalProperties properties, Environment environment) {
        String locations = properties.getLocations();
        if (locations == null) {
            locations =
                    environment.getProperty("spring.flyway.locations", "classpath:db/migration");
        }
        return locations.split(",");
    }
}
