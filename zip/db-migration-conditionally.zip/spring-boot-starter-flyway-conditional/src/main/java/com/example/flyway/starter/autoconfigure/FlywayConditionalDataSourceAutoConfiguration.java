package com.example.flyway.starter.autoconfigure;

import javax.sql.DataSource;

import com.example.flyway.starter.condition.ConditionalOnFlywayMigrations;
import com.zaxxer.hikari.HikariDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(FlywayConditionalProperties.class)
public class FlywayConditionalDataSourceAutoConfiguration {

    private static final Logger logger =
            LoggerFactory.getLogger(FlywayConditionalDataSourceAutoConfiguration.class);

    @Bean
    @Qualifier("flywayDataSource")
    @ConditionalOnFlywayMigrations
    @ConditionalOnProperty(prefix = "flyway.datasource", name = "url")
    public DataSource flywayDataSource(FlywayConditionalProperties properties) {
        FlywayConditionalProperties.DataSourceProperties dsProps = properties.getDatasource();
        logger.info("Creating dedicated Flyway DataSource for URL: {}", dsProps.getUrl());
        logger.debug("Using deploy username: {}", dsProps.getDeployUsername());

        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(dsProps.getUrl());
        // Use deploy credentials for Flyway operations (schema changes)
        dataSource.setUsername(dsProps.getDeployUsername());
        dataSource.setPassword(dsProps.getDeployPassword());
        dataSource.setDriverClassName(dsProps.getDriverClassName());
        return dataSource;
    }
}
