package com.example.flyway.starter.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "flyway")
public class FlywayConditionalProperties {

    /** Whether to enable conditional Flyway functionality */
    private boolean enabled = true;

    /** Flyway migration locations */
    private String locations = "classpath:db/migration";

    /** DataSource configuration for Flyway operations */
    private DataSourceProperties datasource = new DataSourceProperties();

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getLocations() {
        return locations;
    }

    public void setLocations(String locations) {
        this.locations = locations;
    }

    public DataSourceProperties getDatasource() {
        return datasource;
    }

    public void setDatasource(DataSourceProperties datasource) {
        this.datasource = datasource;
    }

    public static class DataSourceProperties {
        private String url;
        private String driverClassName;

        /** Deploy user credentials (higher privileges for schema changes) */
        private String deployUsername;

        private String deployPassword;

        /** Read-write user credentials (for application runtime) */
        private String rwUsername;

        private String rwPassword;

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getDriverClassName() {
            return driverClassName;
        }

        public void setDriverClassName(String driverClassName) {
            this.driverClassName = driverClassName;
        }

        public String getDeployUsername() {
            return deployUsername;
        }

        public void setDeployUsername(String deployUsername) {
            this.deployUsername = deployUsername;
        }

        public String getDeployPassword() {
            return deployPassword;
        }

        public void setDeployPassword(String deployPassword) {
            this.deployPassword = deployPassword;
        }

        public String getRwUsername() {
            return rwUsername;
        }

        public void setRwUsername(String rwUsername) {
            this.rwUsername = rwUsername;
        }

        public String getRwPassword() {
            return rwPassword;
        }

        public void setRwPassword(String rwPassword) {
            this.rwPassword = rwPassword;
        }
    }
}
