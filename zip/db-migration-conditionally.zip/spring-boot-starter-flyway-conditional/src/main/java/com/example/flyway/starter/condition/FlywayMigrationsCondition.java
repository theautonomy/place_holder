package com.example.flyway.starter.condition;

import com.zaxxer.hikari.HikariDataSource;

import org.flywaydb.core.Flyway;
import org.flywaydb.core.api.MigrationInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class FlywayMigrationsCondition extends SpringBootCondition {

    private static final Logger logger = LoggerFactory.getLogger(FlywayMigrationsCondition.class);

    @Override
    public ConditionOutcome getMatchOutcome(
            ConditionContext context, AnnotatedTypeMetadata metadata) {
        try {
            logger.debug("Evaluating FlywayMigrationsCondition");

            HikariDataSource dataSource = createDataSource(context);
            if (dataSource == null) {
                return ConditionOutcome.noMatch("No DataSource configuration found");
            }

            String[] locations = resolveMigrationLocations(context);
            if (locations == null || locations.length == 0) {
                return ConditionOutcome.noMatch("No Flyway migration locations configured");
            }

            try {
                Flyway flyway =
                        Flyway.configure().dataSource(dataSource).locations(locations).load();

                MigrationInfo[] pendingMigrations = flyway.info().pending();
                int pendingCount = pendingMigrations.length;

                logger.debug(
                        "Found {} pending migrations in locations: {}",
                        pendingCount,
                        String.join(", ", locations));

                if (pendingCount > 0) {
                    logger.info(
                            "FlywayMigrationsCondition matched: {} pending migrations found",
                            pendingCount);
                    return ConditionOutcome.match("Found " + pendingCount + " pending migrations");
                } else {
                    logger.debug(
                            "FlywayMigrationsCondition not matched: no pending migrations found");
                    return ConditionOutcome.noMatch("No pending migrations found");
                }
            } finally {
                dataSource.close();
            }
        } catch (Exception e) {
            logger.debug("Error checking for migrations: {}", e.getMessage());
            // When there's an error (like wrong credentials), we should not match
            // This prevents any Flyway beans from being created
            return ConditionOutcome.noMatch("Error checking for migrations: " + e.getMessage());
        }
    }

    private HikariDataSource createDataSource(ConditionContext context) {
        String url = context.getEnvironment().getProperty("flyway.datasource.url");
        if (url == null) {
            return null;
        }

        String driverClassName =
                context.getEnvironment().getProperty("flyway.datasource.driver-class-name");
        String username = context.getEnvironment().getProperty("flyway.datasource.rw_username");
        String password = context.getEnvironment().getProperty("flyway.datasource.rw_password");

        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setDriverClassName(driverClassName);
        return dataSource;
    }

    private String[] resolveMigrationLocations(ConditionContext context) {
        String locations = context.getEnvironment().getProperty("flyway.locations");
        if (locations == null) {
            locations = context.getEnvironment().getProperty("spring.flyway.locations");
        }
        if (locations == null) {
            // Use Flyway default location
            return new String[] {"classpath:db/migration"};
        }
        return locations.split(",");
    }
}
