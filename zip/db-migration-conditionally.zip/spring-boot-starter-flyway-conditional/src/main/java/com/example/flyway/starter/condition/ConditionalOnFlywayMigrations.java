package com.example.flyway.starter.condition;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Conditional;

/**
 * Conditional annotation that evaluates to true when there are pending Flyway migrations that need
 * to be executed. This condition checks the configured Flyway migration directories and compares
 * them against the current database schema to determine if migrations should run.
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Conditional(FlywayMigrationsCondition.class)
public @interface ConditionalOnFlywayMigrations {}
