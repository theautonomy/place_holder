# Spring Boot Starter for Conditional Flyway

A Spring Boot starter that conditionally enables Flyway database migrations based on pending migration availability.

## Overview

This starter provides conditional Flyway functionality that only runs migrations when there are actually pending migrations to execute. This is useful for:

- Development environments where you want migrations to run automatically only when needed
- CI/CD pipelines where you want to skip migration execution when no new migrations are available
- Multi-environment deployments with different migration strategies

## Key Features

- **Conditional Migration Execution**: Flyway only runs when pending migrations are detected
- **Dual DataSource Support**: Separate DataSource for migrations with higher privileges
- **Spring Boot Integration**: Seamless integration with Spring Boot auto-configuration
- **Flexible Configuration**: Support for both Flyway-specific and Spring Flyway properties

## Quick Start

### 1. Add Dependency

```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>spring-boot-starter-flyway-conditional</artifactId>
    <version>1.0.0</version>
</dependency>
```

### 2. Configure Properties

```yaml
flyway:
  enabled: true
  locations: classpath:db/migration
  datasource:
    url: jdbc:postgresql://localhost:5432/mydb
    driver-class-name: org.postgresql.Driver
    deploy_username: flyway_user
    deploy_password: flyway_password
    rw_username: app_user
    rw_password: app_password
```

### 3. Add Migrations

Place your SQL migration files in `src/main/resources/db/migration/`:

```
src/main/resources/db/migration/
├── V1__Create_users_table.sql
├── V2__Add_user_email_index.sql
└── V3__Insert_initial_data.sql
```

## How It Works

1. **Migration Detection**: The `FlywayMigrationsCondition` checks for pending migrations at startup
2. **Conditional Execution**: If pending migrations exist, Flyway is configured to run
3. **DataSource Selection**: Uses dedicated Flyway DataSource if configured, otherwise falls back to primary DataSource
4. **No-Op Mode**: When no migrations are pending, creates a no-op Flyway configuration

## Configuration Properties

| Property | Description | Default |
|----------|-------------|---------|
| `flyway.enabled` | Whether to enable conditional Flyway functionality | `true` |
| `flyway.locations` | Migration file locations | `classpath:db/migration` |
| `flyway.datasource.url` | Database URL for Flyway operations | - |
| `flyway.datasource.driver-class-name` | JDBC driver class name | - |
| `flyway.datasource.deploy_username` | Username for schema changes (higher privileges) | - |
| `flyway.datasource.deploy_password` | Password for schema changes | - |
| `flyway.datasource.rw_username` | Username for application runtime (lower privileges) | - |
| `flyway.datasource.rw_password` | Password for application runtime | - |

## Architecture

### Components

- **`FlywayMigrationsCondition`**: Core condition logic that checks for pending migrations
- **`ConditionalOnFlywayMigrations`**: Custom annotation for conditional bean creation
- **`FlywayConditionalAutoConfiguration`**: Main auto-configuration class
- **`FlywayConditionalDataSourceAutoConfiguration`**: DataSource auto-configuration
- **`FlywayConditionalProperties`**: Configuration properties binding

### Condition Evaluation

The condition evaluates as follows:

1. Check for DataSource configuration (`flyway.datasource.url`)
2. Resolve migration locations (with fallback to Spring Flyway properties)
3. Connect to database and scan for pending migrations
4. Return match if migrations are found, no-match otherwise

## Testing

The starter includes comprehensive unit tests:

- **Condition Logic Tests**: Various scenarios for migration detection
- **Properties Tests**: Configuration binding and validation
- **Auto-Configuration Tests**: Spring Boot integration
- **Integration Tests**: End-to-end functionality

Run tests with:

```bash
mvn test
```

## Comparison with Liquibase Starter

| Feature | Flyway Starter | Liquibase Starter |
|---------|---------------|------------------|
| Migration Format | SQL files | XML/YAML/SQL |
| Condition Logic | Pending migrations | Unrun changesets |
| Default Location | `classpath:db/migration` | `classpath:db/changelog` |
| Framework | Flyway | Liquibase |

## License

This project is licensed under the MIT License.
