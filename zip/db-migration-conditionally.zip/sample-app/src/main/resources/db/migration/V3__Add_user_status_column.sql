-- Add status column to users table
ALTER TABLE users ADD COLUMN status VARCHAR(20) DEFAULT 'ACTIVE';

-- Create index on status for faster filtering
CREATE INDEX idx_users_status ON users(status);

-- Update existing users to have ACTIVE status
UPDATE users SET status = 'ACTIVE' WHERE status IS NULL;