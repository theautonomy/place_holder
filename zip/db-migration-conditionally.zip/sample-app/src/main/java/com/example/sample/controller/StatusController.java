package com.example.sample.controller;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.example.sample.entity.User;
import com.example.sample.repository.UserRepository;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class StatusController {

    private final DataSource dataSource;
    private final UserRepository userRepository;
    private final JdbcClient jdbcClient;

    public StatusController(
            DataSource dataSource, UserRepository userRepository, JdbcClient jdbcClient) {
        this.dataSource = dataSource;
        this.userRepository = userRepository;
        this.jdbcClient = jdbcClient;
    }

    @GetMapping("/status")
    public Map<String, Object> getStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("databaseTables", getDatabaseTables());
        status.put("message", "Sample application using Liquibase Conditional Starter");
        return status;
    }

    @GetMapping("/users/top5")
    public Map<String, Object> getTop5Users() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<User> top5Users = userRepository.findTop5ByOrderByCreatedAtDesc();
            response.put("users", top5Users);
            response.put("count", top5Users.size());
            response.put(
                    "message",
                    "Top 5 users ordered by creation date (newest first) - via JPA Repository");
        } catch (Exception e) {
            response.put("error", "Error retrieving users: " + e.getMessage());
            response.put("users", new ArrayList<>());
            response.put("count", 0);
        }
        return response;
    }

    @GetMapping("/users/top5-jdbc")
    public Map<String, Object> getTop5UsersViaJdbc() {
        Map<String, Object> response = new HashMap<>();
        try {
            String sql =
                    "SELECT id, username, email, created_at FROM users ORDER BY created_at DESC LIMIT 5";

            List<Map<String, Object>> top5Users = jdbcClient.sql(sql).query().listOfRows();

            response.put("users", top5Users);
            response.put("count", top5Users.size());
            response.put(
                    "message",
                    "Top 5 users ordered by creation date (newest first) - via JdbcClient");
            response.put("dataSource", "Primary DataSource");
        } catch (Exception e) {
            response.put("error", "Error retrieving users via JDBC: " + e.getMessage());
            response.put("users", new ArrayList<>());
            response.put("count", 0);
        }
        return response;
    }

    private List<String> getDatabaseTables() {
        List<String> tables = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            ResultSet resultSet = metaData.getTables(null, null, "%", new String[] {"TABLE"});

            while (resultSet.next()) {
                String tableName = resultSet.getString("TABLE_NAME");
                if (!tableName.startsWith("DATABASECHANGELOG")) {
                    tables.add(tableName);
                }
            }
        } catch (Exception e) {
            tables.add("Error retrieving tables: " + e.getMessage());
        }
        return tables;
    }
}
