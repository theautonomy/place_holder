# Sample Application - Liquibase Conditional Starter

This is a sample Spring Boot application demonstrating the usage of the `spring-boot-starter-liquibase-conditional` starter.

## Features

- **Automatic Liquibase Management**: Uses the conditional starter to automatically enable/disable Liquibase based on changeset availability
- **REST API**: Provides `/api/status` endpoint to check the application status
- **H2 Database**: Uses H2 file database for data persistence
- **Sample Data**: Includes sample database schema and data

## Running the Application

From the project root:

```bash
# Build all modules
mvn clean install

# Run the sample application
cd sample-app
mvn spring-boot:run
```

The application will start on port 8082.

## Testing the Conditional Behavior

### First Run (New Changesets Available)
```bash
# Delete database files to start fresh
rm -rf sample-data/

# Start the application
mvn spring-boot:run
```

**Expected**: Liquibase will detect 2 new changesets and execute them.

### Second Run (No New Changesets)
```bash
# Start the application again
mvn spring-boot:run
```

**Expected**: Liquibase will be disabled as no new changesets are available.

## API Endpoints

- `GET /api/status` - Shows application status including:
  - Whether new changesets are available
  - List of database tables
  - Application message

## H2 Console

Access the H2 database console at: http://localhost:8082/h2-console

- JDBC URL: `jdbc:h2:file:./sample-data/testdb`
- Username: `sa`
- Password: `password`

## Configuration

The conditional starter is configured in `application.yml`:

```yaml
liquibase:
  conditional:
    enabled: true
    datasource:
      url: jdbc:h2:file:./sample-data/testdb
      driver-class-name: org.h2.Driver
      username: sa
      password: password
```

This configuration creates a separate DataSource for Liquibase operations that is only initialized when changesets are available.
