# Spring Boot Conditional Database Migration Starters

A collection of reusable Spring Boot starters that conditionally enable database migration tools based on migration availability. These starters automatically disable migration execution when there are no new migrations to run, improving application startup performance.

## Project Structure

```
liquibase-conditionally/
├── spring-boot-starter-liquibase-conditional/    # Liquibase conditional starter
├── spring-boot-starter-flyway-conditional/       # Flyway conditional starter  
└── sample-app/                                   # Example application using both starters
```

## Features

- **Conditional Migration Execution**: Automatically checks for new migrations before running
- **Multiple Database Tools**: Support for both Liquibase and Flyway
- **Optional Separate DataSource**: Configure dedicated DataSource for migration operations
- **Spring Boot Auto-Configuration**: Zero configuration required, works out of the box
- **Performance Optimization**: Skips migration initialization when no new migrations need to run
- **Production Ready**: Handles edge cases and provides proper logging

## How to Use These Starters

### 1. Add Dependency

Choose the appropriate starter for your preferred migration tool:

**Liquibase Starter - Maven:**
```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>spring-boot-starter-liquibase-conditional</artifactId>
    <version>1.0.0</version>
</dependency>
```

**Flyway Starter - Maven:**
```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>spring-boot-starter-flyway-conditional</artifactId>
    <version>1.0.0</version>
</dependency>
```

**Gradle:**
```gradle
// For Liquibase
implementation 'com.example:spring-boot-starter-liquibase-conditional:1.0.0'

// For Flyway
implementation 'com.example:spring-boot-starter-flyway-conditional:1.0.0'
```

### 2. Basic Configuration

#### Liquibase Configuration

```yaml
spring:
  # Your primary DataSource
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    username: sa
    password: password

  # Standard Liquibase configuration
  liquibase:
    change-log: classpath:db/changelog/db.changelog-master.xml
```

#### Flyway Configuration

```yaml
spring:
  # Your primary DataSource
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    username: sa
    password: password

  # Disable Spring Boot's default Flyway (our conditional starter will handle it)
  flyway:
    enabled: false

# Flyway Conditional Starter configuration
flyway:
  enabled: true
  locations: classpath:db/migration
```

### 3. Optional: Separate Migration DataSource

For enhanced security or different database credentials:

#### Liquibase with Separate DataSource
```yaml
spring:
  # Your primary DataSource (for application use)
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    username: app_user
    password: app_password

  liquibase:
    change-log: classpath:db/changelog/db.changelog-master.xml

# Optional: Dedicated Liquibase DataSource
liquibase:
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    deploy_username: liquibase_user
    deploy_password: liquibase_password
```

#### Flyway with Separate DataSource
```yaml
spring:
  # Your primary DataSource (for application use)
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    username: app_user
    password: app_password

  flyway:
    enabled: false

# Flyway Conditional Starter configuration
flyway:
  enabled: true
  locations: classpath:db/migration
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    deploy_username: flyway_user
    deploy_password: flyway_password
```

### 4. Usage in Your Application

Both starters provide services to check migration status:

#### Liquibase Status Check
```java
@RestController
public class StatusController {

    @Autowired
    private LiquibaseChangesetChecker changesetChecker;

    @GetMapping("/api/liquibase-status")
    public Map<String, Object> getLiquibaseStatus() {
        return Map.of(
            "hasNewChangesets", changesetChecker.hasNewChangesets(),
            "message", "Liquibase conditional starter is active"
        );
    }
}
```

#### Flyway Status Check
```java
@RestController
public class StatusController {

    @Autowired(required = false)
    private Flyway flyway;

    @GetMapping("/api/flyway-status")
    public Map<String, Object> getFlywayStatus() {
        if (flyway != null) {
            int pendingCount = flyway.info().pending().length;
            return Map.of(
                "hasNewMigrations", pendingCount > 0,
                "pendingCount", pendingCount,
                "message", "Flyway conditional starter is active"
            );
        }
        return Map.of("message", "Flyway is not active");
    }
}
```

### 5. Behavior

Both starters automatically:

- **First run** (or when new migrations exist): Migration tool runs normally, applies all migrations
- **Subsequent runs** (when no new migrations): Migration tool is disabled, faster startup

#### Liquibase Logs
**When changesets found:**
```
INFO - New changesets found, enabling Liquibase auto-configuration
INFO - Running Changeset: db/changelog/changes/001-initial-schema.xml
```

**When no changesets:**
```
INFO - No new changesets found, disabling Liquibase auto-configuration
INFO - Liquibase did not run because 'shouldRun' property was set to false
```

#### Flyway Logs
**When migrations found:**
```
INFO - New migrations found, enabling Flyway auto-configuration
INFO - Creating Flyway migration initializer to execute migrations on startup
INFO - Flyway Community Edition by Redgate
INFO - Database: jdbc:h2:file:./sample-data/testdb (H2 2.2)
INFO - Successfully applied 2 migrations to schema "PUBLIC"
```

**When no migrations:**
```
INFO - No pending migrations found, Flyway will not be initialized
```

## How It Works

### Liquibase Starter
1. **Auto-Configuration**: Spring Boot automatically detects and configures the starter
2. **Condition Evaluation**: Before Liquibase runs, checks for unrun changesets
3. **Conditional Beans**: Creates appropriate Liquibase bean (enabled/disabled) based on changeset availability
4. **DataSource Management**: Optionally uses separate DataSource for Liquibase operations

### Flyway Starter
1. **Auto-Configuration**: Spring Boot automatically detects and configures the starter
2. **Migration Detection**: Before Flyway runs, scans for pending migrations
3. **Conditional Execution**: Creates Flyway beans and migration initializer only when migrations are needed
4. **DataSource Management**: Optionally uses separate DataSource for Flyway operations

## Sample Application

This repository includes a sample application (`sample-app/`) that demonstrates both starters in action. The sample is currently configured to use the Flyway starter, but can be switched to Liquibase by changing the configuration.

### Running the Sample

1. **Build the entire project:**
   ```bash
   mvn clean install
   ```

2. **Run the sample application:**
   ```bash
   cd sample-app
   mvn spring-boot:run
   ```

3. **Test the API:**
   ```bash
   curl http://localhost:8082/api/status
   ```

### Testing Conditional Behavior

#### First Run (New Migrations Available)
```bash
# Delete database files to start fresh
cd sample-app
rm -rf sample-data/
mvn spring-boot:run
```
**Expected**: The active migration tool (Flyway or Liquibase) will detect new migrations and execute them.

#### Second Run (No New Migrations)
```bash
# Start the application again
mvn spring-boot:run
```
**Expected**: The migration tool will be disabled as no new migrations are available.

### Sample Application Features

- **REST API**: 
  - `/api/status` - Shows which migration starter is active
  - `/api/users/top5-jdbc` - Sample users endpoint
- **H2 Console**: Available at `http://localhost:8082/h2-console`
- **Database**: File-based H2 database (`./sample-data/testdb`)
- **Sample Data**: Includes user table with sample records
- **Migration Scripts**: 
  - Liquibase: `src/main/resources/db/changelog/`
  - Flyway: `src/main/resources/db/migration/`

### Switching Between Migration Tools

To switch from Flyway to Liquibase (or vice versa), modify `application.yml`:

**Enable Flyway:**
```yaml
flyway:
  enabled: true
liquibase:
  enabled: false  # Add this line
```

**Enable Liquibase:**
```yaml
flyway:
  enabled: false
# Remove or comment out liquibase.enabled: false
```

## Development

### Building from Source

```bash
git clone <repository-url>
cd liquibase-conditionally
mvn clean install
```

### Using in Your Maven Build

Install to local repository:
```bash
mvn clean install
```

Then add the dependency to your project as shown in the usage section above.

## Requirements

- Java 17+
- Spring Boot 3.2.0+
- For Liquibase starter: Liquibase 4.x
- For Flyway starter: Flyway 9.x

## License

[Add your license information here]
