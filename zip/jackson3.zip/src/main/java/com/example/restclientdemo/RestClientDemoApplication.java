package com.example.restclientdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestClientDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(RestClientDemoApplication.class, args);
    }
}
