package com.example.jspecify.nullaway.service;

import org.jspecify.annotations.Nullable;

public class UserService {

    public @Nullable String findUserById(long userId) {
        // return null;
        return "John";
    }

    public void greetUser(long useId) {
        System.out.println(findUserById(useId).toUpperCase());
    }

}
