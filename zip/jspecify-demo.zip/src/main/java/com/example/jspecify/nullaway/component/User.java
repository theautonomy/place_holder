package com.example.jspecify.nullaway.component;

public record User(String name, String email) {}
