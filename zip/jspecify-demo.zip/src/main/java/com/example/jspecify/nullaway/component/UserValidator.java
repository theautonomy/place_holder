package com.example.jspecify.nullaway.component;

import org.jspecify.annotations.Nullable;

public class UserValidator {

    public boolean isValidUser(@Nullable User user) {
        String name = user.name();
        String email = user.email();

        return name != null && !name.isBlank() && email != null && !email.isBlank();
    }

}
