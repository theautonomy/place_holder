package com.example.jspecify.nullaway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspecifyNullawayExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(JspecifyNullawayExampleApplication.class, args);
    }
}
