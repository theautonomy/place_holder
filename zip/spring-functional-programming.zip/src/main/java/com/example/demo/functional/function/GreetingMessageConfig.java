package com.example.demo.functional.function;

import java.util.function.Function;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.PropertyMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * PropertyMapper.Source.as(...) transforms an optional property value before applying it, skipping
 * the .to(...) call entirely when the source is null -- no manual null-checking needed. Its
 * Adapter<T, R> parameter has the exact single-method shape of Function<T, R>, but is Spring's own
 * named type, so a plain Function has to be adapted via a method reference (Adapter::adapt vs.
 * Function::apply are structurally identical).
 */
@Configuration
@EnableConfigurationProperties(GreetingProperties.class)
public class GreetingMessageConfig {

    static final Function<String, String> MOOD_TO_PUNCTUATION =
            mood ->
                    switch (mood) {
                        case "excited" -> "!!!";
                        case "calm" -> ".";
                        default -> "!";
                    };

    @Bean
    public GreetingMessage greetingMessage(GreetingProperties properties) {
        GreetingMessage message = new GreetingMessage();
        PropertyMapper map = PropertyMapper.get();
        map.from(properties::getDefaultPrefix).whenHasText().to(message::prefix);
        map.from(properties::getMood).as(MOOD_TO_PUNCTUATION::apply).to(message::punctuation);
        return message;
    }
}
