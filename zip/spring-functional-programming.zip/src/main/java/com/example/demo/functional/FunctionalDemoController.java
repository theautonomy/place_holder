package com.example.demo.functional;

import com.example.demo.functional.customizer.CustomizableGreetingService;

import org.springframework.core.convert.converter.Converter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Ties the Supplier/Function/Consumer service and the Converter bean to plain @RequestMapping
 * endpoints, for comparison against the functional endpoints in FunctionalRouterConfig.
 */
@RestController
public class FunctionalDemoController {

    private final GreetingService greetingService;

    private final CustomizableGreetingService customizableGreetingService;

    private final Converter<String, UpperCaseText> upperCaseConverter;

    public FunctionalDemoController(
            GreetingService greetingService,
            CustomizableGreetingService customizableGreetingService,
            Converter<String, UpperCaseText> upperCaseConverter) {
        this.greetingService = greetingService;
        this.customizableGreetingService = customizableGreetingService;
        this.upperCaseConverter = upperCaseConverter;
    }

    @GetMapping("/api/greet")
    public String greet(@RequestParam(required = false) String name) {
        return greetingService.greet(name);
    }

    @GetMapping("/api/greet-custom")
    public String greetCustom(@RequestParam(required = false) String name) {
        return customizableGreetingService.greet(name);
    }

    @GetMapping("/api/upper")
    public String upper(@RequestParam String text) {
        return upperCaseConverter.convert(text).value();
    }
}
