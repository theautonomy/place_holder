package com.example.demo.functional;

public record UpperCaseText(String value) {}
