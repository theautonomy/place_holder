package com.example.demo.functional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * ApplicationListener<E> has a single abstract method, so it can be a lambda. BeanPostProcessor's
 * two methods both have default bodies (no single abstract method), so it stays an anonymous class
 * here -- included for contrast.
 */
@Configuration
public class LifecycleConfig {

    private static final Logger log = LoggerFactory.getLogger(LifecycleConfig.class);

    @Bean
    public ApplicationListener<ApplicationReadyEvent> onReady() {
        return event -> log.info("application ready");
    }

    @Bean
    public static BeanPostProcessor loggingBeanPostProcessor() {
        return new BeanPostProcessor() {
            @Override
            public Object postProcessAfterInitialization(Object bean, String beanName) {
                if (beanName.startsWith("com.example.demo")) {
                    log.info("initialized bean: {}", beanName);
                }
                return bean;
            }
        };
    }
}
