package com.example.demo.functional.selfinvocation;

import org.springframework.stereotype.Service;

@Service
public class GreetingAnnouncer {

    @Logged
    public String announce(String name) {
        return "Announcing: " + name;
    }

    /**
     * Calls announce() as a plain this.announce() -- a normal Java method call that never leaves
     * this object, so it never passes through the proxy Spring wrapped around this bean
     * for @Logged. LoggedAspect does not fire, even though announce() itself is still annotated.
     */
    public String announceViaSelfInvocation(String name) {
        return announce(name);
    }
}
