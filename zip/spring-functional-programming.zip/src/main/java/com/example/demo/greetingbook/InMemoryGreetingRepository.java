package com.example.demo.greetingbook;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Repository;

/**
 * A real DataSource-backed implementation (JdbcTemplate, Spring Data JPA) would live behind this
 * same GreetingRepository interface without the service or controller changing at all -- that's the
 * point of depending on the interface rather than this class.
 */
@Repository
public class InMemoryGreetingRepository implements GreetingRepository {

    private final Map<Long, Greeting> store = new ConcurrentHashMap<>();

    @Override
    public Greeting save(Greeting greeting) {
        store.put(greeting.id(), greeting);
        return greeting;
    }

    @Override
    public Optional<Greeting> findById(long id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public List<Greeting> findAll() {
        return List.copyOf(store.values());
    }

    @Override
    public boolean deleteById(long id) {
        return store.remove(id) != null;
    }
}
