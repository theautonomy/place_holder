package com.example.demo.functional.selfinvocation;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SelfInvocationController {

    private final GreetingAnnouncer greetingAnnouncer;

    private final InterceptionCounter interceptionCounter;

    public SelfInvocationController(
            GreetingAnnouncer greetingAnnouncer, InterceptionCounter interceptionCounter) {
        this.greetingAnnouncer = greetingAnnouncer;
        this.interceptionCounter = interceptionCounter;
    }

    @GetMapping("/api/self-invocation")
    public String demonstrate(@RequestParam String name) {
        int before = interceptionCounter.get();
        greetingAnnouncer.announce(name);
        int afterDirectCall = interceptionCounter.get();
        greetingAnnouncer.announceViaSelfInvocation(name);
        int afterSelfInvocation = interceptionCounter.get();

        return "direct call intercepted: "
                + (afterDirectCall > before)
                + ", self-invocation intercepted: "
                + (afterSelfInvocation > afterDirectCall);
    }
}
