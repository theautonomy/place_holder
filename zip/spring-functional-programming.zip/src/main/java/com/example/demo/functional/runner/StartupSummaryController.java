package com.example.demo.functional.runner;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StartupSummaryController {

    private final StartupSummary summary;

    public StartupSummaryController(StartupSummary summary) {
        this.summary = summary;
    }

    @GetMapping("/api/startup-summary")
    public String summary() {
        return summary.rawArgsSummary() + " | " + summary.parsedArgsSummary();
    }
}
