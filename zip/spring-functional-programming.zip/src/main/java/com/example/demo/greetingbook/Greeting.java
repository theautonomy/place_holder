package com.example.demo.greetingbook;

import java.time.Instant;

public record Greeting(long id, String recipient, String message, Instant createdAt) {}
