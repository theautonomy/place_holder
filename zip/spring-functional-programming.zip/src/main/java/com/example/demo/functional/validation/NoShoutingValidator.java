package com.example.demo.functional.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * ConstraintValidator<A, T> has a single method that matters here -- isValid(T,
 * ConstraintValidatorContext) -- the same "one method that does the real work" shape as the rest of
 * this project's examples. Null/blank values are left to @NotBlank to reject; this only judges
 * non-blank text.
 */
public class NoShoutingValidator implements ConstraintValidator<NoShouting, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isBlank()) {
            return true;
        }
        boolean hasLetters = value.chars().anyMatch(Character::isLetter);
        boolean isAllUpperCase = value.equals(value.toUpperCase());
        return !(hasLetters && isAllUpperCase);
    }
}
