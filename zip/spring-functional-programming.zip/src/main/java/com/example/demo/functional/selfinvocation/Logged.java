package com.example.demo.functional.selfinvocation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * A stand-in for @Transactional/@Async/@Cacheable -- any annotation whose behavior is applied by
 * wrapping the bean in a proxy. The proxy only sees calls that arrive from outside the bean,
 * through the proxy reference itself; a call made from inside the bean (this.method()) is a plain
 * Java call on the real object and never passes through it.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Logged {}
