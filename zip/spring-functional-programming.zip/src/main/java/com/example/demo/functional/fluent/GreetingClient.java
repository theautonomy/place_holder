package com.example.demo.functional.fluent;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

/**
 * Spring's own staged fluent builder: RestClient.get() returns RequestHeadersUriSpec<?>; .uri(...)
 * narrows that to RequestHeadersSpec<?>, which exposes .header(...) and .retrieve(); only
 * .retrieve() finally yields a ResponseSpec, which is the only place .body(Class) lives. Each
 * step's return type only exposes the calls that are legal next -- you cannot call .retrieve()
 * before .uri(...), because RequestHeadersUriSpec doesn't have a no-arg path to ResponseSpec.
 */
@Service
public class GreetingClient {

    private final RestClient restClient;

    public GreetingClient(RestClient restClient) {
        this.restClient = restClient;
    }

    public String fetchGreeting(String baseUrl, String name) {
        return restClient
                .get()
                .uri(baseUrl + "/api/greet?name={name}", name)
                .header("X-Requested-Via", "GreetingClient")
                .retrieve()
                .body(String.class);
    }
}
