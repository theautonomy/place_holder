package com.example.demo.functional.objectprovider;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingSigningController {

    private final GreetingSigningService signingService;

    public GreetingSigningController(GreetingSigningService signingService) {
        this.signingService = signingService;
    }

    @GetMapping("/api/sign")
    public String sign(@RequestParam String message) {
        return signingService.sign(message);
    }
}
