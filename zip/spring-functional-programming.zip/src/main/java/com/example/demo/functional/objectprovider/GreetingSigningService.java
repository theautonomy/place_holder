package com.example.demo.functional.objectprovider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

/**
 * ObjectProvider<T> is what Spring injects when a constructor asks for a provider of a bean type
 * instead of the bean itself -- the same mechanism RestClientAutoConfiguration uses internally for
 * ObjectProvider<RestClientCustomizer> (see qa.md). getIfAvailable(Supplier<T>) falls back to the
 * supplied default when no bean of that type exists; ifAvailable(Consumer<T>) runs a side effect
 * only when one does -- neither ever throws NoSuchBeanDefinitionException the way a
 * plain @Autowired dependency would.
 */
@Service
public class GreetingSigningService {

    private static final Logger log = LoggerFactory.getLogger(GreetingSigningService.class);

    private final ObjectProvider<GreetingSigner> signerProvider;

    public GreetingSigningService(ObjectProvider<GreetingSigner> signerProvider) {
        this.signerProvider = signerProvider;
    }

    public String sign(String message) {
        signerProvider.ifAvailable(
                signer -> log.info("using {}", signer.getClass().getSimpleName()));
        GreetingSigner signer = signerProvider.getIfAvailable(() -> plain -> plain);
        return signer.sign(message);
    }
}
