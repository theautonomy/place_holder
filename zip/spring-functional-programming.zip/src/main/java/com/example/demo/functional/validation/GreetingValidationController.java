package com.example.demo.functional.validation;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
public class GreetingValidationController {

    @PostMapping("/api/validated-greeting")
    public String greet(@Valid @RequestBody GreetingRequest request) {
        return "Hello, " + request.getName() + "! (" + request.getMessage() + ")";
    }
}
