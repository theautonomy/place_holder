package com.example.demo.functional.template;

/**
 * The resource GreetingSessionTemplate manages the lifecycle of -- the same role
 * java.sql.Connection plays for JdbcTemplate.
 */
public class GreetingSession implements AutoCloseable {

    private final String id;

    private boolean open = true;

    GreetingSession(String id) {
        this.id = id;
    }

    public String greet(String name) {
        if (!open) {
            throw new IllegalStateException("session " + id + " is closed");
        }
        return "Hello, " + name + "! (session " + id + ")";
    }

    @Override
    public void close() {
        open = false;
    }
}
