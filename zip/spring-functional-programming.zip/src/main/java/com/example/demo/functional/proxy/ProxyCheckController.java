package com.example.demo.functional.proxy;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProxyCheckController {

    private final IngredientPair ingredientPair;

    private final LiteIngredientPair liteIngredientPair;

    public ProxyCheckController(
            IngredientPair ingredientPair, LiteIngredientPair liteIngredientPair) {
        this.ingredientPair = ingredientPair;
        this.liteIngredientPair = liteIngredientPair;
    }

    @GetMapping("/api/proxy-check")
    public String proxyCheck() {
        return "same instance: "
                + ingredientPair.sameInstance()
                + " (first="
                + ingredientPair.first().id()
                + ", second="
                + ingredientPair.second().id()
                + ")";
    }

    @GetMapping("/api/proxy-check-lite")
    public String proxyCheckLite() {
        return "same instance: "
                + liteIngredientPair.sameInstance()
                + " (first="
                + liteIngredientPair.first().id()
                + ", second="
                + liteIngredientPair.second().id()
                + ")";
    }
}
