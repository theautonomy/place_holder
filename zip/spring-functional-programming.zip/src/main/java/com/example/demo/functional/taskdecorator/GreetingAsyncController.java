package com.example.demo.functional.taskdecorator;

import java.util.concurrent.ExecutionException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingAsyncController {

    private final GreetingAsyncService greetingAsyncService;

    public GreetingAsyncController(GreetingAsyncService greetingAsyncService) {
        this.greetingAsyncService = greetingAsyncService;
    }

    @GetMapping("/api/async-correlation")
    public String asyncCorrelation(@RequestParam String correlationId)
            throws ExecutionException, InterruptedException {
        String seenByWorker = greetingAsyncService.correlationSeenByWorker(correlationId).get();
        return "worker thread saw correlation id: " + seenByWorker;
    }
}
