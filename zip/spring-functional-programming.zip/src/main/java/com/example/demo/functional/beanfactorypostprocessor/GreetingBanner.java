package com.example.demo.functional.beanfactorypostprocessor;

/**
 * A plain JavaBean whose "text" property is deliberately left unset by GreetingBannerConfig --
 * GreetingBannerTextInjector supplies it before this bean is ever instantiated.
 */
public class GreetingBanner {

    private String text = "unset";

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
