package com.example.demo.functional.objectprovider;

@FunctionalInterface
public interface GreetingSigner {

    String sign(String message);
}
