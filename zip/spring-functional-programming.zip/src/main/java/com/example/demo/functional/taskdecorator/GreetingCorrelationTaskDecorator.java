package com.example.demo.functional.taskdecorator;

import org.springframework.core.task.TaskDecorator;

/**
 * TaskDecorator has a single abstract method -- Runnable decorate(Runnable) -- the same
 * Function<Runnable, Runnable> shape as any other Function<T, R>, just applied to the task itself
 * rather than a value. decorate() runs on the *submitting* thread, so it's the only place that can
 * read the caller's ThreadLocal; the Runnable it returns is what actually runs on the worker thread
 * later.
 */
public class GreetingCorrelationTaskDecorator implements TaskDecorator {

    @Override
    public Runnable decorate(Runnable runnable) {
        String correlationId = GreetingCorrelation.get();
        return () -> {
            GreetingCorrelation.set(correlationId);
            try {
                runnable.run();
            } finally {
                GreetingCorrelation.clear();
            }
        };
    }
}
