package com.example.demo.functional.fluent;

public enum GreetingTone {
    FORMAL,
    CASUAL,
    EXCITED
}
