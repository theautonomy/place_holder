package com.example.demo.functional.template;

/**
 * Mimics Spring's exception-translation role (checked SQLException -> unchecked
 * DataAccessException): the template catches whatever the callback throws and rethrows this
 * instead, so callers only ever deal with one exception type regardless of what failed inside the
 * session.
 */
public class GreetingSessionException extends RuntimeException {

    public GreetingSessionException(String message, Throwable cause) {
        super(message, cause);
    }
}
