package com.example.demo.functional.template;

import org.springframework.stereotype.Service;

@Service
public class GreetingSessionService {

    private final GreetingSessionTemplate template;

    public GreetingSessionService(GreetingSessionTemplate template) {
        this.template = template;
    }

    public String greet(String name) {
        return template.execute(
                session -> {
                    if (name == null || name.isBlank()) {
                        throw new IllegalArgumentException("name must not be blank");
                    }
                    return session.greet(name);
                });
    }
}
