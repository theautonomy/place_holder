package com.example.demo.functional;

import static org.springframework.web.servlet.function.RouterFunctions.route;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.ServerResponse;

/**
 * WebMvc.fn: routes and handlers built entirely from lambdas (Function<ServerRequest,
 * ServerResponse>) instead of @Controller/@RequestMapping.
 */
@Configuration
public class FunctionalRouterConfig {

    @Bean
    public RouterFunction<ServerResponse> functionalRoutes(GreetingService greetingService) {
        return route().GET(
                        "/functional/route",
                        request -> {
                            String name = request.param("name").orElse(null);
                            return ServerResponse.ok().body(greetingService.greet(name));
                        })
                .build();
    }
}
