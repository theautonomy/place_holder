package com.example.demo.functional;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Plain java.util.function building blocks: Supplier (no args -> value), Function (value -> value),
 * Consumer (value -> void).
 */
@Service
public class GreetingService {

    private static final Logger log = LoggerFactory.getLogger(GreetingService.class);

    private final Supplier<String> defaultName = () -> "World";

    private final Function<String, String> toGreeting = name -> "Hello, " + name + "!";

    private final Consumer<String> logger = log::info;

    public String greet(String name) {
        String target = (name != null && !name.isBlank()) ? name : defaultName.get();
        String greeting = toGreeting.apply(target);
        logger.accept(greeting);
        return greeting;
    }
}
