package com.example.demo.functional.proxy;

public record IngredientPair(Ingredient first, Ingredient second) {

    public boolean sameInstance() {
        return first == second;
    }
}
