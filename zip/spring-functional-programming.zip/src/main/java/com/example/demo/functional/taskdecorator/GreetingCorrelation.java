package com.example.demo.functional.taskdecorator;

/**
 * A ThreadLocal correlation id, the same shape as MDC's per-thread map. On its own, a value set
 * here is invisible to any @Async worker thread -- that's exactly the gap
 * GreetingCorrelationTaskDecorator closes.
 */
public final class GreetingCorrelation {

    private static final ThreadLocal<String> CURRENT = new ThreadLocal<>();

    private GreetingCorrelation() {}

    public static void set(String correlationId) {
        CURRENT.set(correlationId);
    }

    public static String get() {
        return CURRENT.get();
    }

    public static void clear() {
        CURRENT.remove();
    }
}
