package com.example.demo.functional.proxy;

import java.util.UUID;

/**
 * Identity, not equality, is the point here -- id() lets us tell two Ingredient instances apart
 * even though nothing about their state differs.
 */
public class Ingredient {

    private final String id = UUID.randomUUID().toString();

    public String id() {
        return id;
    }
}
