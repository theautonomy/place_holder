package com.example.demo.functional.fluent;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingInvitationController {

    @GetMapping("/api/invitation")
    public String invitation(@RequestParam String recipient, @RequestParam GreetingTone tone) {
        return GreetingInvitation.newInvitation().to(recipient).tone(tone).build();
    }
}
