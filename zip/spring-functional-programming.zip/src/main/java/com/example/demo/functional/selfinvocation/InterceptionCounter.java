package com.example.demo.functional.selfinvocation;

import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

/**
 * Ticked by LoggedAspect every time it actually fires -- a way to prove whether the aspect ran,
 * without depending on captured log output.
 */
@Component
public class InterceptionCounter {

    private final AtomicInteger count = new AtomicInteger();

    void increment() {
        count.incrementAndGet();
    }

    public int get() {
        return count.get();
    }
}
