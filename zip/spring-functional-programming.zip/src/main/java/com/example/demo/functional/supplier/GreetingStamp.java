package com.example.demo.functional.supplier;

import java.time.Instant;

public record GreetingStamp(Instant createdAt) {}
