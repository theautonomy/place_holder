package com.example.demo.functional.validation;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class GreetingRequest {

    @NotBlank(message = "name must not be blank")
    @Size(max = 20, message = "name must be at most 20 characters")
    private String name;

    @NoShouting private String message;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
