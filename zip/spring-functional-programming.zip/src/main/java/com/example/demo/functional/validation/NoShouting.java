package com.example.demo.functional.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

/**
 * A custom constraint, built the exact same way @NotBlank/@Size are: a @Constraint-meta-annotated
 * annotation naming the ConstraintValidator class that actually enforces it. This is the real
 * extension point Jakarta Bean Validation offers for business rules the built-in constraints don't
 * cover -- @Valid discovers and runs it identically to any standard one.
 */
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = NoShoutingValidator.class)
public @interface NoShouting {

    String message() default "must not be written in all caps";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
