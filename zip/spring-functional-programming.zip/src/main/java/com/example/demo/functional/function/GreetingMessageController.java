package com.example.demo.functional.function;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingMessageController {

    private final GreetingMessage greetingMessage;

    public GreetingMessageController(GreetingMessage greetingMessage) {
        this.greetingMessage = greetingMessage;
    }

    @GetMapping("/api/greet-mapped")
    public String greetMapped(@RequestParam(required = false) String name) {
        return greetingMessage.render(name);
    }
}
