package com.example.demo.functional.beanfactorypostprocessor;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * BeanFactoryPostProcessor has a single abstract method --
 * postProcessBeanFactory(ConfigurableListableBeanFactory) -- so, unlike BeanPostProcessor
 * (LifecycleConfig, section 9), it CAN be a lambda. It also runs much earlier: before any bean is
 * instantiated, mutating BeanDefinition metadata rather than live objects -- the same mechanism
 * PropertySourcesPlaceholderConfigurer itself is built on.
 */
@Configuration
public class GreetingBannerConfig {

    @Bean
    public GreetingBanner greetingBanner() {
        return new GreetingBanner();
    }

    @Bean
    public static BeanFactoryPostProcessor greetingBannerTextInjector() {
        return beanFactory -> {
            BeanDefinition definition = beanFactory.getBeanDefinition("greetingBanner");
            definition.getPropertyValues().add("text", "Injected before instantiation");
        };
    }
}
