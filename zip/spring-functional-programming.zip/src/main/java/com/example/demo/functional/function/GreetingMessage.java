package com.example.demo.functional.function;

/**
 * Mutable target that GreetingMessageConfig populates via PropertyMapper -- the same role a request
 * builder plays for map(...).to(builder::method).
 */
public class GreetingMessage {

    private String prefix = "Hello";

    private String punctuation = "!";

    public GreetingMessage prefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    public GreetingMessage punctuation(String punctuation) {
        this.punctuation = punctuation;
        return this;
    }

    public String render(String name) {
        String target = (name != null && !name.isBlank()) ? name : "World";
        return prefix + ", " + target + punctuation;
    }
}
