package com.example.demo.functional.template;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Component;

/**
 * Template-callback pattern: the template owns resource setup/teardown and exception translation
 * (the boilerplate); the callback supplies only the part that varies -- the same split
 * JdbcTemplate.execute(ConnectionCallback) and TransactionTemplate.execute(TransactionCallback)
 * use.
 */
@Component
public class GreetingSessionTemplate {

    private final AtomicLong sessionCounter = new AtomicLong();

    public <T> T execute(GreetingSessionCallback<T> callback) {
        String sessionId = "s" + sessionCounter.incrementAndGet();
        try (GreetingSession session = new GreetingSession(sessionId)) {
            return callback.doInSession(session);
        } catch (RuntimeException ex) {
            throw new GreetingSessionException("greeting session " + sessionId + " failed", ex);
        }
    }
}
