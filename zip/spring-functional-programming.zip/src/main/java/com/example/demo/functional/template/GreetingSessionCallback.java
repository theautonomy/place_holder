package com.example.demo.functional.template;

/**
 * Our own callback interface -- the same role JdbcTemplate's ConnectionCallback<T> or RowMapper<T>
 * plays: the caller supplies only the part of the work that varies, while GreetingSessionTemplate
 * owns setup/teardown and exception translation.
 */
@FunctionalInterface
public interface GreetingSessionCallback<T> {

    T doInSession(GreetingSession session);
}
