package com.example.demo.functional;

import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * WebMvcConfigurer is a plain interface with default methods; only the ones you need are
 * overridden, each configuring its registry argument (here: a Consumer<CorsRegistry>-shaped call)
 * in place.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(@NonNull CorsRegistry registry) {
        registry.addMapping("/functional/**").allowedMethods("GET");
    }
}
