package com.example.demo.functional.predicate;

import static com.example.demo.functional.predicate.GreetingRequestPredicates.hasName;
import static com.example.demo.functional.predicate.GreetingRequestPredicates.wantsShout;
import static org.springframework.web.servlet.function.RouterFunctions.route;

import com.example.demo.functional.GreetingService;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.ServerResponse;

/**
 * Composes RequestPredicates the same way Spring itself does -- hasName().and(wantsShout()) -- to
 * route the same path to a different handler depending on the request, instead of branching inside
 * one handler. Unmatched requests (no "name" param) fall through to a normal 404, since no route
 * claims them.
 */
@Configuration
public class PredicateRouterConfig {

    @Bean
    public RouterFunction<ServerResponse> predicateRoutes(GreetingService greetingService) {
        return route().GET(
                        "/functional/predicate-route",
                        hasName().and(wantsShout()),
                        request ->
                                ServerResponse.ok()
                                        .body(
                                                greetingService
                                                        .greet(request.param("name").orElseThrow())
                                                        .toUpperCase()))
                .GET(
                        "/functional/predicate-route",
                        hasName().and(wantsShout().negate()),
                        request ->
                                ServerResponse.ok()
                                        .body(
                                                greetingService.greet(
                                                        request.param("name").orElseThrow())))
                .build();
    }
}
