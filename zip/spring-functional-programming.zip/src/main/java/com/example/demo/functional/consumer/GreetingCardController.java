package com.example.demo.functional.consumer;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingCardController {

    private final GreetingCardService greetingCardService;

    public GreetingCardController(GreetingCardService greetingCardService) {
        this.greetingCardService = greetingCardService;
    }

    @GetMapping("/api/card")
    public String card(
            @RequestParam(required = false) String message,
            @RequestParam(required = false, defaultValue = "false") boolean signed) {
        return greetingCardService.createCard(
                card -> {
                    if (message != null && !message.isBlank()) {
                        card.message(message);
                    }
                    if (signed) {
                        card.sign();
                    }
                });
    }
}
