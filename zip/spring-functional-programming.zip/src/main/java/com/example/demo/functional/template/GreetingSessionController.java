package com.example.demo.functional.template;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingSessionController {

    private final GreetingSessionService greetingSessionService;

    public GreetingSessionController(GreetingSessionService greetingSessionService) {
        this.greetingSessionService = greetingSessionService;
    }

    @GetMapping("/api/session-greet")
    public String sessionGreet(@RequestParam(required = false) String name) {
        return greetingSessionService.greet(name);
    }

    @ExceptionHandler(GreetingSessionException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handleSessionFailure(GreetingSessionException ex) {
        return ex.getCause().getMessage();
    }
}
