package com.example.demo.functional.taskdecorator;

import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

@Service
public class GreetingAsyncService {

    private final ThreadPoolTaskExecutor executor;

    public GreetingAsyncService(ThreadPoolTaskExecutor greetingTaskExecutor) {
        this.executor = greetingTaskExecutor;
    }

    /**
     * Sets the correlation id on the calling thread, then hands work to the executor. Without the
     * TaskDecorator, GreetingCorrelation.get() inside the submitted task would return null -- the
     * worker thread has its own ThreadLocal storage, unrelated to the caller's.
     */
    public CompletableFuture<String> correlationSeenByWorker(String correlationId) {
        CompletableFuture<String> result = new CompletableFuture<>();
        GreetingCorrelation.set(correlationId);
        try {
            executor.execute(() -> result.complete(GreetingCorrelation.get()));
        } finally {
            GreetingCorrelation.clear();
        }
        return result;
    }
}
