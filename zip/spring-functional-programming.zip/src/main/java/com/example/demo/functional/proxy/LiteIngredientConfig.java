package com.example.demo.functional.proxy;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * The live-app counterpart to the test-only LiteProxyConfig: identical proxyBeanMethods = false
 * behavior (no CGLIB subclassing, so liteIngredient() really does run twice), registered here as
 * real beans so /api/proxy-check-lite can be curled directly instead of only proven inside an
 * isolated test context.
 */
@Configuration(proxyBeanMethods = false)
public class LiteIngredientConfig {

    @Bean
    public Ingredient liteIngredient() {
        return new Ingredient();
    }

    @Bean
    public LiteIngredientPair liteIngredientPair() {
        return new LiteIngredientPair(liteIngredient(), liteIngredient());
    }
}
