package com.example.demo.functional.customizer;

import java.util.List;

import org.springframework.stereotype.Service;

/**
 * Collects every Customizer<GreetingOptions> bean (Spring injects a List<T> of all beans of that
 * type, honoring @Order) and applies them to a fresh GreetingOptions before building the message --
 * the same collect-then-apply mechanism Boot's RestClientBuilderConfigurer uses for
 * RestClientCustomizer.
 */
@Service
public class CustomizableGreetingService {

    private final List<Customizer<GreetingOptions>> customizers;

    public CustomizableGreetingService(List<Customizer<GreetingOptions>> customizers) {
        this.customizers = customizers;
    }

    public String greet(String name) {
        GreetingOptions options = new GreetingOptions();
        customizers.forEach(customizer -> customizer.customize(options));

        String target = (name != null && !name.isBlank()) ? name : "World";
        String message = options.prefix() + ", " + target + options.suffix();
        return options.shout() ? message.toUpperCase() : message;
    }
}
