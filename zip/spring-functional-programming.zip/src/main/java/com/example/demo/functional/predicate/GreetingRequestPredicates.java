package com.example.demo.functional.predicate;

import java.util.function.Predicate;

import org.springframework.web.servlet.function.RequestPredicate;
import org.springframework.web.servlet.function.RequestPredicates;

/**
 * Mimics Spring's own RequestPredicates: named static factories returning RequestPredicate.
 * RequestPredicate has a single abstract method -- boolean test(ServerRequest) -- the exact shape
 * of Predicate<ServerRequest>, plus default and()/or()/negate() combinators, same as Predicate<T>
 * itself. RequestPredicates.param(String, Predicate<String>) takes a plain
 * java.util.function.Predicate<String> to check the param's value.
 */
public final class GreetingRequestPredicates {

    static final Predicate<String> NAME_PRESENT = name -> !name.isBlank();

    static final Predicate<String> WANTS_SHOUT = "true"::equals;

    private GreetingRequestPredicates() {}

    public static RequestPredicate hasName() {
        return RequestPredicates.param("name", NAME_PRESENT);
    }

    public static RequestPredicate wantsShout() {
        return RequestPredicates.param("shout", WANTS_SHOUT);
    }
}
