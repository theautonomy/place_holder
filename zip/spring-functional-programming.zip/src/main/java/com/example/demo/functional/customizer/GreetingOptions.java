package com.example.demo.functional.customizer;

/**
 * Mutable target for Customizer<GreetingOptions> beans to configure -- the same role
 * RestClient.Builder or CorsRegistry play for Spring's built-in customizers.
 */
public class GreetingOptions {

    private String prefix = "Hello";

    private String suffix = "!";

    private boolean shout = false;

    public GreetingOptions prefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    public GreetingOptions suffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public GreetingOptions shout(boolean shout) {
        this.shout = shout;
        return this;
    }

    public String prefix() {
        return prefix;
    }

    public String suffix() {
        return suffix;
    }

    public boolean shout() {
        return shout;
    }
}
