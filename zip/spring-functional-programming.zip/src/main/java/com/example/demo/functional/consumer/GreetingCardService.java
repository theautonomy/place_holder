package com.example.demo.functional.consumer;

import java.util.function.Consumer;

import org.springframework.stereotype.Service;

/**
 * Consumer<T>-based builder method: the caller passes a plain Consumer<T> lambda directly to the
 * method instead of a named Customizer<T> type and a collected list of beans -- the same shape
 * RestClient.headers(Consumer<HttpHeaders>) uses.
 */
@Service
public class GreetingCardService {

    public String createCard(Consumer<GreetingCard> customizer) {
        GreetingCard card = new GreetingCard();
        customizer.accept(card);
        return card.render();
    }
}
