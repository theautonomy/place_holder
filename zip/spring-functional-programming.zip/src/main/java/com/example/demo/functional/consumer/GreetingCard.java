package com.example.demo.functional.consumer;

/**
 * Mutable target for a Consumer<GreetingCard> to configure -- the same role HttpHeaders plays for
 * RestClient.headers(Consumer<HttpHeaders>).
 */
public class GreetingCard {

    private String message = "Hello!";

    private boolean signed = false;

    public GreetingCard message(String message) {
        this.message = message;
        return this;
    }

    public GreetingCard sign() {
        this.signed = true;
        return this;
    }

    public String render() {
        return signed ? message + " -- Spring Team" : message;
    }
}
