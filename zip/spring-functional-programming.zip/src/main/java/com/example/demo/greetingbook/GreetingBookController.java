package com.example.demo.greetingbook;

import java.net.URI;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import jakarta.validation.Valid;

/**
 * @Valid failures here are caught by the same global ValidationErrorHandler (functional.validation)
 * that handles every other @RestController -- no per-controller wiring needed.
 */
@RestController
public class GreetingBookController {

    private final GreetingBookService greetingBookService;

    public GreetingBookController(GreetingBookService greetingBookService) {
        this.greetingBookService = greetingBookService;
    }

    @PostMapping("/api/greeting-book")
    public ResponseEntity<Greeting> create(@Valid @RequestBody CreateGreetingRequest request) {
        Greeting greeting =
                greetingBookService.create(request.getRecipient(), request.getMessage());
        URI location =
                ServletUriComponentsBuilder.fromCurrentRequest()
                        .path("/{id}")
                        .buildAndExpand(greeting.id())
                        .toUri();
        return ResponseEntity.created(location).body(greeting);
    }

    @GetMapping("/api/greeting-book")
    public List<Greeting> findAll() {
        return greetingBookService.findAll();
    }

    @GetMapping("/api/greeting-book/{id}")
    public Greeting findById(@PathVariable long id) {
        return greetingBookService.findById(id);
    }

    @DeleteMapping("/api/greeting-book/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable long id) {
        greetingBookService.deleteById(id);
    }

    @ExceptionHandler(GreetingNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleNotFound(GreetingNotFoundException ex) {
        return ex.getMessage();
    }
}
