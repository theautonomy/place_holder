package com.example.demo.functional.beanfactorypostprocessor;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingBannerController {

    private final GreetingBanner greetingBanner;

    public GreetingBannerController(GreetingBanner greetingBanner) {
        this.greetingBanner = greetingBanner;
    }

    @GetMapping("/api/banner")
    public String banner() {
        return greetingBanner.getText();
    }
}
