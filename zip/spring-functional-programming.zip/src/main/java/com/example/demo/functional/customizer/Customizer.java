package com.example.demo.functional.customizer;

/**
 * Our own version of Spring's Customizer<T>: a lambda that receives a mutable target and configures
 * it in place, returning nothing. Spring Boot's *Customizer beans (RestClientCustomizer,
 * WebClientCustomizer, ...) follow this exact shape.
 */
@FunctionalInterface
public interface Customizer<T> {

    void customize(T target);
}
