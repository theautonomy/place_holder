package com.example.demo.functional.proxy;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Configuration classes are CGLIB-subclassed by default (proxyBeanMethods = true, the default) --
 * this is the "$$SpringCGLIB$$" you've seen throughout this project's own test logs, on
 * every @Configuration class here, unexplained until now. Spring intercepts every call to a @Bean
 * method -- even a plain Java method call from inside this same class -- and redirects it through
 * the container, returning the existing singleton instead of running the method body again. That's
 * how calling ingredient() twice below still yields one Ingredient instance: this file contains
 * exactly two calls to "new Ingredient()" worth of source code, but the container only ever
 * actually executes it once.
 */
@Configuration
public class CglibProxyConfig {

    @Bean
    public Ingredient ingredient() {
        return new Ingredient();
    }

    @Bean
    public IngredientPair ingredientPair() {
        return new IngredientPair(ingredient(), ingredient());
    }
}
