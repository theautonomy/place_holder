package com.example.demo.greetingbook;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

@Service
public class GreetingBookService {

    private final GreetingRepository repository;

    private final AtomicLong idSequence = new AtomicLong();

    public GreetingBookService(GreetingRepository repository) {
        this.repository = repository;
    }

    public Greeting create(String recipient, String message) {
        Greeting greeting =
                new Greeting(idSequence.incrementAndGet(), recipient, message, Instant.now());
        return repository.save(greeting);
    }

    public List<Greeting> findAll() {
        return repository.findAll();
    }

    public Greeting findById(long id) {
        return repository.findById(id).orElseThrow(() -> new GreetingNotFoundException(id));
    }

    public void deleteById(long id) {
        if (!repository.deleteById(id)) {
            throw new GreetingNotFoundException(id);
        }
    }
}
