package com.example.demo.greetingbook;

import com.example.demo.functional.validation.NoShouting;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CreateGreetingRequest {

    @NotBlank(message = "recipient must not be blank")
    @Size(max = 50, message = "recipient must be at most 50 characters")
    private String recipient;

    @NotBlank(message = "message must not be blank")
    @NoShouting
    private String message;

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
