package com.example.demo.functional.selfinvocation;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

/**
 * @Before("@annotation(Logged)") matches any method carrying @Logged -- but only when the call
 * arrives through the Spring-managed proxy that wraps the bean, never on a plain internal method
 * call.
 */
@Aspect
@Component
public class LoggedAspect {

    private final InterceptionCounter interceptionCounter;

    public LoggedAspect(InterceptionCounter interceptionCounter) {
        this.interceptionCounter = interceptionCounter;
    }

    @Before("@annotation(Logged)")
    public void logInvocation() {
        interceptionCounter.increment();
    }
}
