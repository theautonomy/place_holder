package com.example.demo.greetingbook;

import java.util.List;
import java.util.Optional;

public interface GreetingRepository {

    Greeting save(Greeting greeting);

    Optional<Greeting> findById(long id);

    List<Greeting> findAll();

    boolean deleteById(long id);
}
