package com.example.demo.functional.fluent;

/**
 * Our own staged (typed) fluent builder, reproducing the same trick RestClient uses: each step
 * returns a narrower interface exposing only the next legal call, so an incomplete chain fails to
 * compile instead of throwing at runtime. newInvitation() only offers .to(...); .to(...) only
 * offers .tone(...); only .tone(...) finally offers .build(). There is no way to call .build()
 * before supplying both a recipient and a tone.
 */
public final class GreetingInvitation {

    private GreetingInvitation() {}

    public static RecipientStep newInvitation() {
        return new Steps();
    }

    public interface RecipientStep {

        ToneStep to(String recipient);
    }

    public interface ToneStep {

        BuildStep tone(GreetingTone tone);
    }

    public interface BuildStep {

        String build();
    }

    private static final class Steps implements RecipientStep, ToneStep, BuildStep {

        private String recipient;

        private GreetingTone tone;

        @Override
        public ToneStep to(String recipient) {
            this.recipient = recipient;
            return this;
        }

        @Override
        public BuildStep tone(GreetingTone tone) {
            this.tone = tone;
            return this;
        }

        @Override
        public String build() {
            return switch (tone) {
                case FORMAL -> "Dear " + recipient + ", you are cordially invited.";
                case CASUAL -> "Hey " + recipient + ", come on over!";
                case EXCITED -> "OMG " + recipient + ", YOU HAVE TO COME!!!";
            };
        }
    }
}
