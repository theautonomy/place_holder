package com.example.demo.functional.proxy;

/**
 * Same shape as IngredientPair, kept as its own type only so this bean and CglibProxyConfig's
 * IngredientPair bean can coexist in the same running app without an ambiguous-autowiring conflict
 * -- the point here is the proxying behavior, not bean disambiguation.
 */
public record LiteIngredientPair(Ingredient first, Ingredient second) {

    public boolean sameInstance() {
        return first == second;
    }
}
