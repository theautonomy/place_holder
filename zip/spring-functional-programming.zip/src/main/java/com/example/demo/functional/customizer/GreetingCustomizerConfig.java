package com.example.demo.functional.customizer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

/**
 * Two Customizer<GreetingOptions> beans, applied in @Order. Mirrors the Boot pattern where multiple
 * *Customizer beans (e.g. RestClientCustomizer) all get collected and applied to the same target.
 */
@Configuration
public class GreetingCustomizerConfig {

    @Bean
    @Order(1)
    public Customizer<GreetingOptions> signatureCustomizer() {
        return options -> options.suffix(options.suffix() + " - sent from Spring");
    }

    @Bean
    @Order(2)
    public Customizer<GreetingOptions> shoutCustomizer() {
        return options -> options.shout(true);
    }
}
