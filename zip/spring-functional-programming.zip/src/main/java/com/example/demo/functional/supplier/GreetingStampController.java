package com.example.demo.functional.supplier;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingStampController {

    private final GreetingStamp greetingStamp;

    public GreetingStampController(GreetingStamp greetingStamp) {
        this.greetingStamp = greetingStamp;
    }

    @GetMapping("/api/stamp")
    public String stamp() {
        return "Context started at " + greetingStamp.createdAt();
    }
}
