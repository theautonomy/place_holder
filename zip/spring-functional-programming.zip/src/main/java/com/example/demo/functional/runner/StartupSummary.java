package com.example.demo.functional.runner;

import java.util.Arrays;

import org.springframework.boot.ApplicationArguments;
import org.springframework.stereotype.Component;

/**
 * Populated once at startup by GreetingRunnerConfig's CommandLineRunner and ApplicationRunner beans
 * -- exposed so both /api/startup-summary and tests can observe what each one saw.
 */
@Component
public class StartupSummary {

    private volatile String rawArgsSummary = "not yet run";

    private volatile String parsedArgsSummary = "not yet run";

    void recordRawArgs(String[] args) {
        this.rawArgsSummary = "raw args: " + Arrays.toString(args);
    }

    void recordParsedArgs(ApplicationArguments args) {
        this.parsedArgsSummary =
                "non-option args: "
                        + args.getNonOptionArgs()
                        + ", option names: "
                        + args.getOptionNames();
    }

    public String rawArgsSummary() {
        return rawArgsSummary;
    }

    public String parsedArgsSummary() {
        return parsedArgsSummary;
    }
}
