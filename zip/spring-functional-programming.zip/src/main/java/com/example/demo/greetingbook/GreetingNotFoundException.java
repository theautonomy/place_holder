package com.example.demo.greetingbook;

public class GreetingNotFoundException extends RuntimeException {

    public GreetingNotFoundException(long id) {
        super("greeting " + id + " not found");
    }
}
