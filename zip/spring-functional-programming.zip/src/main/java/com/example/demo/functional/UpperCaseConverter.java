package com.example.demo.functional;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;

/**
 * Spring's Converter<S, T> has the same shape as Function<S, T> (a convert/apply method returning a
 * value) but is discovered and registered by Spring's ConversionService. Converting String ->
 * String would apply to every String request param app-wide, so this converts to a distinct type
 * instead, as most real Converter beans do.
 */
@Configuration
public class UpperCaseConverter {

    @Bean
    public Converter<String, UpperCaseText> upperCaseTextConverter() {
        return source -> new UpperCaseText(source.toUpperCase());
    }
}
