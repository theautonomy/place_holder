package com.example.demo.functional.supplier;

import java.time.Instant;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.support.GenericApplicationContext;

/**
 * Functional bean registration: GenericApplicationContext.registerBean(Class, Supplier, ...)
 * registers a bean straight from a Supplier<T>, no @Bean method or @Component scanning involved.
 * Wired in via META-INF/spring.factories so it runs before the context refreshes -- @Bean methods
 * run too late for this API.
 */
public class GreetingStampInitializer
        implements ApplicationContextInitializer<GenericApplicationContext> {

    @Override
    public void initialize(GenericApplicationContext context) {
        context.registerBean(GreetingStamp.class, () -> new GreetingStamp(Instant.now()));
    }
}
