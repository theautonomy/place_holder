package com.example.demo.functional.taskdecorator;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class GreetingTaskExecutorConfig {

    @Bean
    public ThreadPoolTaskExecutor greetingTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setThreadNamePrefix("greeting-task-");
        executor.setTaskDecorator(new GreetingCorrelationTaskDecorator());
        executor.initialize();
        return executor;
    }
}
