package com.example.demo.functional.objectprovider;

import org.springframework.stereotype.Component;

/**
 * The one GreetingSigner bean registered in this app -- exercises the "present" branch of
 * GreetingSigningService in the real running context. Tests exercise the "absent" branch with an
 * empty bean factory instead of removing this bean.
 */
@Component
public class DefaultGreetingSigner implements GreetingSigner {

    @Override
    public String sign(String message) {
        return message + " [signed]";
    }
}
