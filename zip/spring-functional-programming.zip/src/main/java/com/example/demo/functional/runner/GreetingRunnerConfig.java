package com.example.demo.functional.runner;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * CommandLineRunner (run(String... args)) and ApplicationRunner (run(ApplicationArguments args))
 * each have a single abstract method, so both are lambda-friendly. Boot calls every bean of both
 * types exactly once, right after the context refreshes and before SpringApplication.run() returns
 * -- earlier than the ApplicationReadyEvent LifecycleConfig listens for. CommandLineRunner gets the
 * raw String[]; ApplicationRunner gets them already split into option ("--name=value") vs.
 * non-option arguments.
 */
@Configuration
public class GreetingRunnerConfig {

    @Bean
    public CommandLineRunner greetingCommandLineRunner(StartupSummary summary) {
        return args -> summary.recordRawArgs(args);
    }

    @Bean
    public ApplicationRunner greetingApplicationRunner(StartupSummary summary) {
        return args -> summary.recordParsedArgs(args);
    }
}
