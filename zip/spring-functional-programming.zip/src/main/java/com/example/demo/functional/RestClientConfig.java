package com.example.demo.functional;

import org.springframework.boot.restclient.RestClientCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

/**
 * Boot-level "customizer bean" pattern: implementing RestClientCustomizer as a lambda lets Boot
 * apply it to the auto-configured RestClient.Builder without subclassing anything.
 */
@Configuration
public class RestClientConfig {

    @Bean
    public RestClientCustomizer restClientCustomizer() {
        return builder -> builder.defaultHeader("X-Demo-Source", "functional-examples");
    }

    @Bean
    public RestClient demoRestClient(RestClient.Builder restClientBuilder) {
        return restClientBuilder.build();
    }
}
