package com.example.demo.functional.validation;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class GreetingValidationControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void acceptsAValidRequest() throws Exception {
        mockMvc.perform(
                        post("/api/validated-greeting")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content("{\"name\":\"Ada\",\"message\":\"hi there\"}"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, Ada! (hi there)"));
    }

    @Test
    void rejectsABlankName() throws Exception {
        mockMvc.perform(
                        post("/api/validated-greeting")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content("{\"name\":\"\",\"message\":\"hi there\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.name").value("name must not be blank"));
    }

    @Test
    void rejectsANameThatIsTooLong() throws Exception {
        mockMvc.perform(
                        post("/api/validated-greeting")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(
                                        "{\"name\":\"a-name-that-is-way-too-long-for-this-field\",\"message\":\"hi there\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.name").value("name must be at most 20 characters"));
    }

    @Test
    void rejectsAShoutingMessageUsingTheCustomConstraint() throws Exception {
        mockMvc.perform(
                        post("/api/validated-greeting")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content("{\"name\":\"Ada\",\"message\":\"HELLO THERE\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("must not be written in all caps"));
    }
}
