package com.example.demo.functional.fluent;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class GreetingInvitationControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void invitationEndpointBuildsFromRecipientAndTone() throws Exception {
        mockMvc.perform(get("/api/invitation").param("recipient", "Ada").param("tone", "EXCITED"))
                .andExpect(status().isOk())
                .andExpect(content().string("OMG Ada, YOU HAVE TO COME!!!"));
    }
}
