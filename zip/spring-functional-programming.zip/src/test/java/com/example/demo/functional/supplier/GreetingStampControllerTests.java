package com.example.demo.functional.supplier;

import static org.hamcrest.Matchers.startsWith;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class GreetingStampControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void stampEndpointReturnsFunctionallyRegisteredBean() throws Exception {
        mockMvc.perform(get("/api/stamp"))
                .andExpect(status().isOk())
                .andExpect(content().string(startsWith("Context started at")));
    }
}
