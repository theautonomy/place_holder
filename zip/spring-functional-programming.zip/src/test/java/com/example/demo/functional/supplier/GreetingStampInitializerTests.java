package com.example.demo.functional.supplier;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreetingStampInitializerTests {

    @Autowired private GreetingStamp greetingStamp;

    @Test
    void registersGreetingStampBeanFunctionally() {
        assertThat(greetingStamp).isNotNull();
        assertThat(greetingStamp.createdAt()).isNotNull();
    }
}
