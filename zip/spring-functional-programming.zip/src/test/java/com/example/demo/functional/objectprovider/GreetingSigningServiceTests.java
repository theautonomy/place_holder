package com.example.demo.functional.objectprovider;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;

class GreetingSigningServiceTests {

    @Test
    void fallsBackToIdentityWhenNoSignerBeanExists() {
        ObjectProvider<GreetingSigner> emptyProvider =
                new DefaultListableBeanFactory().getBeanProvider(GreetingSigner.class);
        GreetingSigningService service = new GreetingSigningService(emptyProvider);

        assertThat(service.sign("Hello")).isEqualTo("Hello");
    }

    @Test
    void usesTheRegisteredSignerWhenOneExists() {
        DefaultListableBeanFactory beanFactory = new DefaultListableBeanFactory();
        beanFactory.registerSingleton("defaultGreetingSigner", new DefaultGreetingSigner());
        ObjectProvider<GreetingSigner> provider = beanFactory.getBeanProvider(GreetingSigner.class);
        GreetingSigningService service = new GreetingSigningService(provider);

        assertThat(service.sign("Hello")).isEqualTo("Hello [signed]");
    }
}
