package com.example.demo.greetingbook;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;

import org.junit.jupiter.api.Test;

class InMemoryGreetingRepositoryTests {

    private final InMemoryGreetingRepository repository = new InMemoryGreetingRepository();

    @Test
    void savesAndFindsById() {
        Greeting saved = repository.save(new Greeting(1, "Ada", "hi", Instant.now()));

        assertThat(repository.findById(1)).contains(saved);
    }

    @Test
    void findByIdIsEmptyWhenMissing() {
        assertThat(repository.findById(99)).isEmpty();
    }

    @Test
    void findAllReturnsEverySavedGreeting() {
        repository.save(new Greeting(1, "Ada", "hi", Instant.now()));
        repository.save(new Greeting(2, "Grace", "hello", Instant.now()));

        assertThat(repository.findAll()).hasSize(2);
    }

    @Test
    void deleteByIdRemovesTheEntryAndReportsSuccess() {
        repository.save(new Greeting(1, "Ada", "hi", Instant.now()));

        assertThat(repository.deleteById(1)).isTrue();
        assertThat(repository.findById(1)).isEmpty();
    }

    @Test
    void deleteByIdReportsFailureWhenMissing() {
        assertThat(repository.deleteById(99)).isFalse();
    }
}
