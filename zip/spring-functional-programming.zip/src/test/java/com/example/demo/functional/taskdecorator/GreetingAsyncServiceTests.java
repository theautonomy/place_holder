package com.example.demo.functional.taskdecorator;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

class GreetingAsyncServiceTests {

    private ThreadPoolTaskExecutor executor;

    private GreetingAsyncService service;

    @BeforeEach
    void setUp() {
        executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(1);
        executor.setTaskDecorator(new GreetingCorrelationTaskDecorator());
        executor.initialize();
        service = new GreetingAsyncService(executor);
    }

    @AfterEach
    void tearDown() {
        executor.shutdown();
    }

    @Test
    void workerThreadSeesTheCallingThreadsCorrelationId()
            throws ExecutionException, InterruptedException {
        String seen = service.correlationSeenByWorker("req-42").get();

        assertThat(seen).isEqualTo("req-42");
    }
}
