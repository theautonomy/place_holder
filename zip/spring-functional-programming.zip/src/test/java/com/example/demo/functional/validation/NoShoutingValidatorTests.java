package com.example.demo.functional.validation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class NoShoutingValidatorTests {

    private final NoShoutingValidator validator = new NoShoutingValidator();

    @Test
    void acceptsNullAndBlank() {
        assertThat(validator.isValid(null, null)).isTrue();
        assertThat(validator.isValid("  ", null)).isTrue();
    }

    @Test
    void acceptsMixedCaseText() {
        assertThat(validator.isValid("Hello there", null)).isTrue();
    }

    @Test
    void rejectsAllCapsText() {
        assertThat(validator.isValid("HELLO THERE", null)).isFalse();
    }

    @Test
    void acceptsAllCapsTextWithoutLetters() {
        assertThat(validator.isValid("123!!!", null)).isTrue();
    }
}
