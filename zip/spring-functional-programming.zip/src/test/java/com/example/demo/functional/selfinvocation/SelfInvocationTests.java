package com.example.demo.functional.selfinvocation;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

class SelfInvocationTests {

    @Configuration
    @EnableAspectJAutoProxy
    @ComponentScan(basePackageClasses = SelfInvocationTests.class)
    static class TestConfig {}

    @Test
    void directCallThroughTheProxyIsIntercepted() {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(TestConfig.class)) {
            GreetingAnnouncer announcer = context.getBean(GreetingAnnouncer.class);
            InterceptionCounter counter = context.getBean(InterceptionCounter.class);

            announcer.announce("Ada");

            assertThat(counter.get()).isEqualTo(1);
        }
    }

    @Test
    void selfInvocationBypassesTheProxyAndIsNotIntercepted() {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(TestConfig.class)) {
            GreetingAnnouncer announcer = context.getBean(GreetingAnnouncer.class);
            InterceptionCounter counter = context.getBean(InterceptionCounter.class);

            announcer.announceViaSelfInvocation("Ada");

            assertThat(counter.get()).isZero();
        }
    }
}
