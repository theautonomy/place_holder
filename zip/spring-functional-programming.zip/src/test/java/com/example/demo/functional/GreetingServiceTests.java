package com.example.demo.functional;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class GreetingServiceTests {

    private final GreetingService greetingService = new GreetingService();

    @Test
    void greetsGivenName() {
        assertThat(greetingService.greet("Ada")).isEqualTo("Hello, Ada!");
    }

    @Test
    void fallsBackToDefaultNameWhenBlank() {
        assertThat(greetingService.greet("  ")).isEqualTo("Hello, World!");
        assertThat(greetingService.greet(null)).isEqualTo("Hello, World!");
    }
}
