package com.example.demo.functional.runner;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * A distinct set of program args (via @SpringBootTest(args = ...)) proves the actual reason
 * ApplicationRunner exists: CommandLineRunner only ever sees the raw strings,
 * "--greeting.audit=true" included verbatim, while ApplicationRunner gets it pre-split into a
 * recognized option name/value and a separate non-option argument.
 */
@SpringBootTest(args = {"--greeting.audit=true", "hello"})
class GreetingRunnerConfigArgsTests {

    @Autowired private StartupSummary summary;

    @Test
    void commandLineRunnerSeesTheRawArgStrings() {
        assertThat(summary.rawArgsSummary()).contains("--greeting.audit=true").contains("hello");
    }

    @Test
    void applicationRunnerSeesThemAlreadyParsed() {
        assertThat(summary.parsedArgsSummary()).contains("hello").contains("greeting.audit");
    }
}
