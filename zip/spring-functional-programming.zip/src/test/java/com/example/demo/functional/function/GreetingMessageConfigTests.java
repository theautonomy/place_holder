package com.example.demo.functional.function;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class GreetingMessageConfigTests {

    @Test
    void moodToPunctuationMapsKnownMoods() {
        assertThat(GreetingMessageConfig.MOOD_TO_PUNCTUATION.apply("excited")).isEqualTo("!!!");
        assertThat(GreetingMessageConfig.MOOD_TO_PUNCTUATION.apply("calm")).isEqualTo(".");
    }

    @Test
    void moodToPunctuationFallsBackForUnknownMood() {
        assertThat(GreetingMessageConfig.MOOD_TO_PUNCTUATION.apply("mysterious")).isEqualTo("!");
    }

    @Test
    void greetingMessageBeanAppliesOnlyPresentProperties() {
        GreetingProperties properties = new GreetingProperties();
        properties.setMood("calm");

        GreetingMessage message = new GreetingMessageConfig().greetingMessage(properties);

        assertThat(message.render("Ada")).isEqualTo("Hello, Ada.");
    }
}
