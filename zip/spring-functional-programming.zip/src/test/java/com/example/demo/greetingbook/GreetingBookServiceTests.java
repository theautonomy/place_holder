package com.example.demo.greetingbook;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class GreetingBookServiceTests {

    private final GreetingBookService service =
            new GreetingBookService(new InMemoryGreetingRepository());

    @Test
    void createAssignsAnIdAndStoresTheGreeting() {
        Greeting created = service.create("Ada", "hi there");

        assertThat(created.id()).isPositive();
        assertThat(service.findById(created.id())).isEqualTo(created);
    }

    @Test
    void findByIdThrowsWhenMissing() {
        assertThatThrownBy(() -> service.findById(99))
                .isInstanceOf(GreetingNotFoundException.class)
                .hasMessage("greeting 99 not found");
    }

    @Test
    void deleteByIdThrowsWhenMissing() {
        assertThatThrownBy(() -> service.deleteById(99))
                .isInstanceOf(GreetingNotFoundException.class);
    }

    @Test
    void deleteByIdRemovesAnExistingGreeting() {
        Greeting created = service.create("Ada", "hi there");

        service.deleteById(created.id());

        assertThatThrownBy(() -> service.findById(created.id()))
                .isInstanceOf(GreetingNotFoundException.class);
    }

    @Test
    void findAllReturnsEveryCreatedGreeting() {
        service.create("Ada", "hi");
        service.create("Grace", "hello");

        assertThat(service.findAll()).hasSize(2);
    }
}
