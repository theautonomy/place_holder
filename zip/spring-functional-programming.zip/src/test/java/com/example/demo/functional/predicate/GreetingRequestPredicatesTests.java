package com.example.demo.functional.predicate;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class GreetingRequestPredicatesTests {

    @Test
    void namePresentRejectsBlank() {
        assertThat(GreetingRequestPredicates.NAME_PRESENT.test("Ada")).isTrue();
        assertThat(GreetingRequestPredicates.NAME_PRESENT.test(" ")).isFalse();
    }

    @Test
    void wantsShoutOnlyMatchesTrue() {
        assertThat(GreetingRequestPredicates.WANTS_SHOUT.test("true")).isTrue();
        assertThat(GreetingRequestPredicates.WANTS_SHOUT.test("false")).isFalse();
    }
}
