package com.example.demo.functional.taskdecorator;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class GreetingAsyncControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void asyncCorrelationEndpointPropagatesIdToWorkerThread() throws Exception {
        mockMvc.perform(get("/api/async-correlation").param("correlationId", "req-99"))
                .andExpect(status().isOk())
                .andExpect(content().string("worker thread saw correlation id: req-99"));
    }
}
