package com.example.demo.functional.template;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class GreetingSessionTemplateTests {

    private final GreetingSessionTemplate template = new GreetingSessionTemplate();

    @Test
    void executesCallbackWithAnOpenSession() {
        String result = template.execute(session -> session.greet("Ada"));

        assertThat(result).isEqualTo("Hello, Ada! (session s1)");
    }

    @Test
    void closesTheSessionAfterTheCallbackReturns() {
        GreetingSession[] captured = new GreetingSession[1];
        template.execute(session -> captured[0] = session);

        assertThatThrownBy(() -> captured[0].greet("Ada"))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void translatesCallbackExceptionsIntoGreetingSessionException() {
        assertThatThrownBy(
                        () ->
                                template.execute(
                                        session -> {
                                            throw new IllegalArgumentException("boom");
                                        }))
                .isInstanceOf(GreetingSessionException.class)
                .hasCauseInstanceOf(IllegalArgumentException.class)
                .cause()
                .hasMessage("boom");
    }

    @Test
    void closesTheSessionEvenWhenTheCallbackThrows() {
        GreetingSession[] captured = new GreetingSession[1];

        assertThatThrownBy(
                        () ->
                                template.execute(
                                        session -> {
                                            captured[0] = session;
                                            throw new IllegalStateException("boom");
                                        }))
                .isInstanceOf(GreetingSessionException.class);

        assertThatThrownBy(() -> captured[0].greet("Ada"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("is closed");
    }
}
