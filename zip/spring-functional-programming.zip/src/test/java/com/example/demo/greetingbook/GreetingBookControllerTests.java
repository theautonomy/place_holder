package com.example.demo.greetingbook;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.jayway.jsonpath.JsonPath;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest
@AutoConfigureMockMvc
class GreetingBookControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void createReturns201WithLocationAndBody() throws Exception {
        mockMvc.perform(
                        post("/api/greeting-book")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content("{\"recipient\":\"Ada\",\"message\":\"hi there\"}"))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", containsString("/api/greeting-book/")))
                .andExpect(jsonPath("$.recipient").value("Ada"))
                .andExpect(jsonPath("$.message").value("hi there"))
                .andExpect(jsonPath("$.id").exists());
    }

    @Test
    void createRejectsAnInvalidRequestViaTheSharedValidationErrorHandler() throws Exception {
        mockMvc.perform(
                        post("/api/greeting-book")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content("{\"recipient\":\"\",\"message\":\"HELLO\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.recipient").value("recipient must not be blank"))
                .andExpect(jsonPath("$.message").value("must not be written in all caps"));
    }

    @Test
    void findByIdReturnsWhatWasCreated() throws Exception {
        long id = createAndCaptureId("Grace", "hello");

        mockMvc.perform(get("/api/greeting-book/" + id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.recipient").value("Grace"));
    }

    @Test
    void findByIdReturns404WhenMissing() throws Exception {
        mockMvc.perform(get("/api/greeting-book/999999"))
                .andExpect(status().isNotFound())
                .andExpect(content().string("greeting 999999 not found"));
    }

    @Test
    void findAllIncludesCreatedGreetings() throws Exception {
        createAndCaptureId("Ada", "hi");

        mockMvc.perform(get("/api/greeting-book"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    @Test
    void deleteRemovesTheGreetingThenReturns404OnSecondDelete() throws Exception {
        long id = createAndCaptureId("Ada", "hi");

        mockMvc.perform(delete("/api/greeting-book/" + id)).andExpect(status().isNoContent());
        mockMvc.perform(delete("/api/greeting-book/" + id)).andExpect(status().isNotFound());
    }

    private long createAndCaptureId(String recipient, String message) throws Exception {
        MvcResult result =
                mockMvc.perform(
                                post("/api/greeting-book")
                                        .contentType(MediaType.APPLICATION_JSON)
                                        .content(
                                                "{\"recipient\":\""
                                                        + recipient
                                                        + "\",\"message\":\""
                                                        + message
                                                        + "\"}"))
                        .andExpect(status().isCreated())
                        .andReturn();
        return ((Number) JsonPath.parse(result.getResponse().getContentAsString()).read("$.id"))
                .longValue();
    }
}
