package com.example.demo.functional.beanfactorypostprocessor;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

class GreetingBannerConfigTests {

    @Test
    void beanFactoryPostProcessorInjectsTextBeforeTheBeanIsInstantiated() {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(GreetingBannerConfig.class)) {
            GreetingBanner banner = context.getBean(GreetingBanner.class);

            assertThat(banner.getText()).isEqualTo("Injected before instantiation");
        }
    }
}
