package com.example.demo.functional.consumer;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class GreetingCardServiceTests {

    private final GreetingCardService greetingCardService = new GreetingCardService();

    @Test
    void appliesConsumerToDefaultCard() {
        String card = greetingCardService.createCard(c -> {});

        assertThat(card).isEqualTo("Hello!");
    }

    @Test
    void appliesConsumerThatMutatesMessageAndSigns() {
        String card = greetingCardService.createCard(c -> c.message("Congrats").sign());

        assertThat(card).isEqualTo("Congrats -- Spring Team");
    }
}
