package com.example.demo.functional.fluent;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class GreetingInvitationTests {

    @Test
    void buildsAFormalInvitation() {
        String invitation =
                GreetingInvitation.newInvitation().to("Ada").tone(GreetingTone.FORMAL).build();

        assertThat(invitation).isEqualTo("Dear Ada, you are cordially invited.");
    }

    @Test
    void buildsACasualInvitation() {
        String invitation =
                GreetingInvitation.newInvitation().to("Ada").tone(GreetingTone.CASUAL).build();

        assertThat(invitation).isEqualTo("Hey Ada, come on over!");
    }

    @Test
    void buildsAnExcitedInvitation() {
        String invitation =
                GreetingInvitation.newInvitation().to("Ada").tone(GreetingTone.EXCITED).build();

        assertThat(invitation).isEqualTo("OMG Ada, YOU HAVE TO COME!!!");
    }
}
