package com.example.demo.functional.taskdecorator;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.Test;

class GreetingCorrelationTaskDecoratorTests {

    private final GreetingCorrelationTaskDecorator decorator =
            new GreetingCorrelationTaskDecorator();

    @Test
    void decoratedTaskCarriesTheSubmittingThreadsCorrelationIdToAnotherThread()
            throws InterruptedException {
        AtomicReference<String> seenInsideTask = new AtomicReference<>();
        GreetingCorrelation.set("abc-123");
        Runnable decorated =
                decorator.decorate(() -> seenInsideTask.set(GreetingCorrelation.get()));
        GreetingCorrelation.clear();

        runOnANewThread(decorated);

        assertThat(seenInsideTask.get()).isEqualTo("abc-123");
    }

    @Test
    void plainUndecoratedTaskSeesNoCorrelationOnAnotherThread() throws InterruptedException {
        AtomicReference<String> seenInsideTask = new AtomicReference<>();
        GreetingCorrelation.set("abc-123");
        Runnable plain = () -> seenInsideTask.set(GreetingCorrelation.get());
        GreetingCorrelation.clear();

        runOnANewThread(plain);

        assertThat(seenInsideTask.get()).isNull();
    }

    private void runOnANewThread(Runnable task) throws InterruptedException {
        Thread worker = new Thread(task);
        worker.start();
        worker.join();
    }
}
