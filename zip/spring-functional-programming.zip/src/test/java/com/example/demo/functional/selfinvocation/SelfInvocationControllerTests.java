package com.example.demo.functional.selfinvocation;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class SelfInvocationControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void directCallIsInterceptedButSelfInvocationIsNot() throws Exception {
        mockMvc.perform(get("/api/self-invocation").param("name", "Ada"))
                .andExpect(status().isOk())
                .andExpect(
                        content()
                                .string(
                                        "direct call intercepted: true, self-invocation intercepted: false"));
    }
}
