package com.example.demo.functional.proxy;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

class ProxyBeanMethodsTests {

    @Test
    void fullProxyingReturnsTheSameInstanceOnEveryInterBeanMethodCall() {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(CglibProxyConfig.class)) {
            IngredientPair pair = context.getBean(IngredientPair.class);

            assertThat(pair.sameInstance()).isTrue();
        }
    }

    @Test
    void liteModeReturnsADifferentInstanceOnEveryInterBeanMethodCall() {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(LiteProxyConfig.class)) {
            IngredientPair pair = context.getBean(IngredientPair.class);

            assertThat(pair.sameInstance()).isFalse();
        }
    }

    @Test
    void configClassItselfIsACglibSubclassWhenFullyProxied() {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(CglibProxyConfig.class)) {
            CglibProxyConfig configBean = context.getBean(CglibProxyConfig.class);

            assertThat(configBean.getClass().getName()).contains("$$SpringCGLIB$$");
        }
    }

    @Test
    void configClassIsNotProxiedInLiteMode() {
        try (AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(LiteProxyConfig.class)) {
            LiteProxyConfig configBean = context.getBean(LiteProxyConfig.class);

            assertThat(configBean.getClass().getName()).doesNotContain("$$SpringCGLIB$$");
        }
    }
}
