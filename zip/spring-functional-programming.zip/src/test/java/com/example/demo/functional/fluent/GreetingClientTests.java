package com.example.demo.functional.fluent;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class GreetingClientTests {

    @LocalServerPort private int port;

    @Autowired private GreetingClient greetingClient;

    @Test
    void fetchesGreetingFromTheRunningAppOverRealHttp() {
        String greeting = greetingClient.fetchGreeting("http://localhost:" + port, "Ada");

        assertThat(greeting).isEqualTo("Hello, Ada!");
    }
}
