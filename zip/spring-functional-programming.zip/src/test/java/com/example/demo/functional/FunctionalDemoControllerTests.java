package com.example.demo.functional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class FunctionalDemoControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void greetEndpointUsesFunctionAndSupplier() throws Exception {
        mockMvc.perform(get("/api/greet").param("name", "Ada"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, Ada!"));
    }

    @Test
    void greetEndpointFallsBackToDefaultSupplier() throws Exception {
        mockMvc.perform(get("/api/greet"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, World!"));
    }

    @Test
    void upperEndpointUsesConverter() throws Exception {
        mockMvc.perform(get("/api/upper").param("text", "abc"))
                .andExpect(status().isOk())
                .andExpect(content().string("ABC"));
    }

    @Test
    void functionalRouteRespondsLikeGreetEndpoint() throws Exception {
        mockMvc.perform(get("/functional/route").param("name", "Grace"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, Grace!"));
    }

    @Test
    void greetCustomEndpointAppliesRegisteredCustomizers() throws Exception {
        mockMvc.perform(get("/api/greet-custom").param("name", "Ada"))
                .andExpect(status().isOk())
                .andExpect(content().string("HELLO, ADA! - SENT FROM SPRING"));
    }
}
