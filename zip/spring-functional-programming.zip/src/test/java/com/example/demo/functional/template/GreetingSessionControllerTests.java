package com.example.demo.functional.template;

import static org.hamcrest.Matchers.startsWith;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class GreetingSessionControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void sessionGreetEndpointReturnsGreetingFromTemplate() throws Exception {
        mockMvc.perform(get("/api/session-greet").param("name", "Ada"))
                .andExpect(status().isOk())
                .andExpect(content().string(startsWith("Hello, Ada!")));
    }

    @Test
    void sessionGreetEndpointTranslatesFailureIntoBadRequest() throws Exception {
        mockMvc.perform(get("/api/session-greet"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("name must not be blank"));
    }
}
