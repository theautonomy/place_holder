package com.example.demo.functional.predicate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class PredicateRouterConfigTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void routesToShoutingHandlerWhenShoutRequested() throws Exception {
        mockMvc.perform(
                        get("/functional/predicate-route")
                                .param("name", "Ada")
                                .param("shout", "true"))
                .andExpect(status().isOk())
                .andExpect(content().string("HELLO, ADA!"));
    }

    @Test
    void routesToPlainHandlerWhenShoutNotRequested() throws Exception {
        mockMvc.perform(get("/functional/predicate-route").param("name", "Ada"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, Ada!"));
    }

    @Test
    void noRouteMatchesWithoutNameParam() throws Exception {
        mockMvc.perform(get("/functional/predicate-route")).andExpect(status().isNotFound());
    }
}
