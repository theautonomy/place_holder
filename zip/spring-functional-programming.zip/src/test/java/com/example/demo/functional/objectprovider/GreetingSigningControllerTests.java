package com.example.demo.functional.objectprovider;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class GreetingSigningControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void signEndpointUsesTheRegisteredSignerBean() throws Exception {
        mockMvc.perform(get("/api/sign").param("message", "Hello"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello [signed]"));
    }
}
