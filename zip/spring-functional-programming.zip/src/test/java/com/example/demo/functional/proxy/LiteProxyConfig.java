package com.example.demo.functional.proxy;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

/**
 * "Lite" mode: proxyBeanMethods = false skips the CGLIB subclassing entirely. Now ingredient() is
 * just a plain Java method -- calling it twice runs the method body twice, producing two different
 * Ingredient instances. This is the exact same Java source as CglibProxyConfig; only the proxying
 * behavior differs. @TestConfiguration, not plain @Configuration: Maven's test classpath includes
 * both src/main and src/test classes together, so @SpringBootApplication's component scan would
 * otherwise pick this up in every other @SpringBootTest in the project too, colliding with
 * CglibProxyConfig's "ingredient" bean name. @TestConfiguration is specifically excluded from that
 * automatic scan (TestTypeExcludeFilter) while still working when registered explicitly, as
 * ProxyBeanMethodsTests does.
 */
@TestConfiguration(proxyBeanMethods = false)
public class LiteProxyConfig {

    @Bean
    public Ingredient ingredient() {
        return new Ingredient();
    }

    @Bean
    public IngredientPair ingredientPair() {
        return new IngredientPair(ingredient(), ingredient());
    }
}
