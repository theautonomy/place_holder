package com.example.demo.functional.customizer;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;

class CustomizableGreetingServiceTests {

    @Test
    void appliesEveryCustomizerInOrder() {
        CustomizableGreetingService service =
                new CustomizableGreetingService(
                        List.of(
                                options -> options.suffix(options.suffix() + " - sent from Spring"),
                                options -> options.shout(true)));

        assertThat(service.greet("Ada")).isEqualTo("HELLO, ADA! - SENT FROM SPRING");
    }

    @Test
    void worksWithNoCustomizers() {
        CustomizableGreetingService service = new CustomizableGreetingService(List.of());

        assertThat(service.greet("Ada")).isEqualTo("Hello, Ada!");
    }
}
