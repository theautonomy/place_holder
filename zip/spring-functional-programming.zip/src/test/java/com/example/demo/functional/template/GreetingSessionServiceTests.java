package com.example.demo.functional.template;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;

class GreetingSessionServiceTests {

    private final GreetingSessionService service =
            new GreetingSessionService(new GreetingSessionTemplate());

    @Test
    void greetsWithinASession() {
        assertThat(service.greet("Ada")).startsWith("Hello, Ada!");
    }

    @Test
    void wrapsBlankNameFailureAsGreetingSessionException() {
        assertThatThrownBy(() -> service.greet(" "))
                .isInstanceOf(GreetingSessionException.class)
                .hasCauseInstanceOf(IllegalArgumentException.class);
    }
}
