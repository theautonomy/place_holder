package com.example.demo.functional.runner;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class StartupSummaryControllerTests {

    @Autowired private MockMvc mockMvc;

    @Test
    void startupSummaryEndpointReflectsRunnersRunOnceAtStartup() throws Exception {
        mockMvc.perform(get("/api/startup-summary"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("raw args: []")))
                .andExpect(content().string(containsString("non-option args: []")));
    }
}
