# Functional Programming Patterns in Spring

Spring Framework and Spring Boot lean heavily on Java's functional interfaces (`Function`,
`Consumer`, `Supplier`) and Spring's own `Customizer<T>` to let you configure builders and beans
with lambdas instead of subclassing or long setter chains.

This app has one small, runnable, tested example per pattern under
`src/main/java/com/example/demo/functional/`. Each section below points at the real classes and
endpoints instead of a generic snippet — run the app and hit the URLs to see it work.

## Layout

| Package | Pattern | Shape |
|---|---|---|
| `functional` (root) | `Supplier`/`Function`/`Consumer` basics, `Converter<S,T>`, `RestClientCustomizer`, `RouterFunction`, `WebMvcConfigurer`, lifecycle lambdas | mixed |
| `functional.customizer` | our own `Customizer<T>` + Boot's collect-and-apply mechanism | `void customize(T)` |
| `functional.consumer` | `Consumer<T>`-based builder method (unnamed, not collected) | `void accept(T)` |
| `functional.supplier` | functional bean registration | `T get()` |
| `functional.function` | `PropertyMapper.Source.as(...)` | `R adapt(T)` |
| `functional.template` | template-callback pattern | `T doInSession(R)` |
| `functional.predicate` | `RequestPredicates` composition | `boolean test(T)` |
| `functional.objectprovider` | optional-dependency injection | `getIfAvailable(Supplier)` / `ifAvailable(Consumer)` |
| `functional.runner` | `CommandLineRunner` / `ApplicationRunner` | `void run(...)` |
| `functional.taskdecorator` | `TaskDecorator` (async context propagation) | `Runnable decorate(Runnable)` |
| `functional.beanfactorypostprocessor` | `BeanFactoryPostProcessor` (bean-definition mutation) | `void postProcessBeanFactory(...)` |
| `functional.fluent` | fluent/staged builder API | method chain, narrowing return types |
| `functional.validation` | `@Valid` + custom Bean Validation constraint | `ConstraintValidator<A,T>.isValid(T, ctx)` |
| `functional.proxy` | `@Configuration` CGLIB proxying (`proxyBeanMethods`) | inter-bean-method call interception |
| `functional.selfinvocation` | self-invocation bypasses AOP proxies | `@Aspect` / `@Before("@annotation(...)")` |

## 1. Plain `Supplier` / `Function` / `Consumer` — `GreetingService`

`GreetingService` (`functional/GreetingService.java`) holds all three JDK shapes as fields:

```java
private final Supplier<String> defaultName = () -> "World";
private final Function<String, String> toGreeting = name -> "Hello, " + name + "!";
private final Consumer<String> logger = log::info;
```

`logger` is a method reference to an SLF4J `Logger`, not `System.out.println` — `Logger.info(String)`
has the same `void accept(String)` shape `Consumer<String>` needs, so it's a one-line swap, and log
output gets the class name, timestamp, and level for free instead of a hand-written `[GreetingService]`
prefix.

`greet(name)` falls back to the `Supplier` when `name` is blank, transforms it with the `Function`,
and logs it with the `Consumer` before returning.

Try it: `GET /api/greet?name=Ada` → `Hello, Ada!` · `GET /api/greet` → `Hello, World!`

## 2. `Converter<S, T>` — `UpperCaseConverter`

`Converter<S,T>` has one abstract method, the same shape as `Function<S,T>`, but Spring's
`ConversionService` auto-discovers any `Converter` bean and applies it globally to matching
request-param conversions. `UpperCaseConverter` (`functional/UpperCaseConverter.java`) registers
it as a lambda `@Bean` rather than a class implementing the interface:

```java
@Bean
public Converter<String, UpperCaseText> upperCaseTextConverter() {
    return source -> new UpperCaseText(source.toUpperCase());
}
```

**Gotcha we hit building this:** the first version converted `String -> String`. Because
`ConversionService` applies matching converters to *every* `@RequestParam String` in the app, it
silently uppercased the `name` param on `/api/greet` too. Converting to a distinct wrapper type
(`UpperCaseText`, `functional/UpperCaseText.java`) avoids the collision — which is also how most
real `Converter` beans are written.

Try it: `GET /api/upper?text=abc` → `ABC`

## 3. The `Customizer<T>` pattern — `functional.customizer`

Spring's own `Customizer<T>` (`org.springframework.security.config.Customizer`) is a lambda that
receives a mutable target and configures it in place, returning `void` — e.g.
`http.csrf(csrf -> csrf.disable())`. `functional.customizer.Customizer<T>` reproduces the same
shape from scratch:

```java
@FunctionalInterface
public interface Customizer<T> {
    void customize(T target);
}
```

`GreetingOptions` is the mutable target (plays the role `RestClient.Builder` or `CorsRegistry`
play for Spring's built-ins). `GreetingCustomizerConfig` registers two ordered beans:

```java
@Bean @Order(1)
public Customizer<GreetingOptions> signatureCustomizer() {
    return options -> options.suffix(options.suffix() + " - sent from Spring");
}

@Bean @Order(2)
public Customizer<GreetingOptions> shoutCustomizer() {
    return options -> options.shout(true);
}
```

`CustomizableGreetingService` reproduces Boot's own collect-then-apply mechanism (the same one
`RestClientBuilderConfigurer` uses for every `RestClientCustomizer` bean): inject `List<Customizer<GreetingOptions>>`
— Spring collects every bean of that type, sorted by `@Order` — and apply each one to a fresh
`GreetingOptions` before building the message.

Try it: `GET /api/greet-custom?name=Ada` → `HELLO, ADA! - SENT FROM SPRING`

## 4. Boot-level `*Customizer` bean pattern — `RestClientConfig`

Boot exposes many `*Customizer` interfaces you implement as `@Bean`s; Boot discovers and applies
them to its auto-configured objects.

| Customizer | Applies to |
|---|---|
| `RestTemplateCustomizer` | auto-configured `RestTemplate` |
| `RestClientCustomizer` | auto-configured `RestClient.Builder` |
| `WebClientCustomizer` | auto-configured `WebClient.Builder` |
| `Jackson2ObjectMapperBuilderCustomizer` | the shared `ObjectMapper` |
| `WebServerFactoryCustomizer<ConfigurableWebServerFactory>` | embedded Tomcat/Jetty/Netty |
| `ThreadPoolTaskExecutorCustomizer` / `ThreadPoolTaskSchedulerCustomizer` | task executors/schedulers |

`functional/RestClientConfig.java`:

```java
@Bean
public RestClientCustomizer restClientCustomizer() {
    return builder -> builder.defaultHeader("X-Demo-Source", "functional-examples");
}

@Bean
public RestClient demoRestClient(RestClient.Builder restClientBuilder) {
    return restClientBuilder.build();
}
```

**Gotcha:** in Spring Boot 4.1, `RestClientCustomizer` moved out of `spring-boot-autoconfigure` into
its own `org.springframework.boot.restclient` package, shipped by the `spring-boot-starter-restclient`
dependency (added to `pom.xml` alongside `spring-boot-starter-web`) — not
`org.springframework.boot.webclient` as older docs/examples show.

Multiple `RestClientCustomizer` beans can coexist — Boot applies all of them (add `@Order` if you
need a guaranteed sequence).

## 5. Plain `Consumer<T>`-based builder method — `functional.consumer`

Contrast with section 3: many Spring builder methods take a **plain, unnamed** `Consumer<T>`
directly as a parameter, applied once and discarded — no named type, no bean collection. Example
from Framework itself: `RestClient.create().get().uri("/users").headers(h -> h.setBearerAuth(token))`.

`GreetingCardService` (`functional/consumer/GreetingCardService.java`) reproduces exactly that:

```java
public String createCard(Consumer<GreetingCard> customizer) {
    GreetingCard card = new GreetingCard();
    customizer.accept(card);
    return card.render();
}
```

`GreetingCardController` builds the `Consumer<GreetingCard>` lambda inline from request params and
hands it straight to the service — no `@Bean`, no `List<Customizer<T>>` collection.

Try it: `GET /api/card?message=Congrats&signed=true` → `Congrats -- Spring Team`

## 6. Functional bean registration — `functional.supplier`

`GenericApplicationContext.registerBean(Class, Supplier, ...)` registers a bean straight from a
`Supplier<T>` lambda — no `@Bean` method, no `@Component` scanning.

`GreetingStampInitializer` (`functional/supplier/GreetingStampInitializer.java`) does this inside
an `ApplicationContextInitializer`, since `registerBean` must run before the context refreshes —
`@Bean` methods run too late for this API:

```java
public class GreetingStampInitializer implements ApplicationContextInitializer<GenericApplicationContext> {
    @Override
    public void initialize(GenericApplicationContext context) {
        context.registerBean(GreetingStamp.class, () -> new GreetingStamp(Instant.now()));
    }
}
```

**Gotcha:** the traditional way to wire in an extra initializer is the `context.initializer.classes`
property, backed by `DelegatingApplicationContextInitializer`. That class has been **removed** in
Spring Boot 4.1 — verified by inspecting the actual `spring-boot-4.1.0.jar`, it's not present.
Instead, `SpringApplication`'s constructor still auto-discovers `ApplicationContextInitializer`
beans via `META-INF/spring.factories` (a mechanism independent of the removed property), so this
app wires it there instead:

```
# src/main/resources/META-INF/spring.factories
org.springframework.context.ApplicationContextInitializer=\
com.example.demo.functional.supplier.GreetingStampInitializer
```

This required no changes to `DemoApplication.java`, and the same discovery path is used both by
`main()` and by `@SpringBootTest`.

Try it: `GET /api/stamp` → `Context started at 2026-...`

## 7. `Function<T, R>` via `PropertyMapper.Source.as(...)` — `functional.function`

`PropertyMapper` maps optional `@ConfigurationProperties` values through a transform, skipping the
`.to(...)` call entirely when the source is absent — no manual null-checking. `GreetingMessageConfig`
(`functional/function/GreetingMessageConfig.java`):

```java
static final Function<String, String> MOOD_TO_PUNCTUATION = mood -> switch (mood) {
    case "excited" -> "!!!";
    case "calm" -> ".";
    default -> "!";
};

@Bean
public GreetingMessage greetingMessage(GreetingProperties properties) {
    GreetingMessage message = new GreetingMessage();
    PropertyMapper map = PropertyMapper.get();
    map.from(properties::getDefaultPrefix).whenHasText().to(message::prefix);
    map.from(properties::getMood).as(MOOD_TO_PUNCTUATION::apply).to(message::punctuation);
    return message;
}
```

`GreetingProperties` is a plain `@ConfigurationProperties(prefix = "greeting")` class, enabled via
`@EnableConfigurationProperties(GreetingProperties.class)` on the same config class (no
`@ConfigurationPropertiesScan` needed). `greeting.mood=excited` is set in `application.properties`.

**Gotchas found by checking the real `PropertyMapper` bytecode, not just docs:**
- `Source.whenNonNull()` doesn't exist. Turns out it's unnecessary: `.as(...)` and `.to(...)` are
  already null-safe internally — the adapter/consumer only runs when the underlying value is
  non-null.
- `Source.as(...)` doesn't accept a `java.util.function.Function<T,R>`. It takes Spring's own
  `Source.Adapter<T,R>` — structurally identical (one method, `T -> R`) but a distinct named type,
  so a real `Function` field has to be adapted via a method reference: `MOOD_TO_PUNCTUATION::apply`.

Try it: `GET /api/greet-mapped?name=Ada` → `Hello, Ada!!!`

## 8. Functional endpoints (WebMvc.fn) — `FunctionalRouterConfig`

`RouterFunctions.route()` builds routing entirely from lambdas instead of `@Controller`/`@RequestMapping`:

```java
@Bean
public RouterFunction<ServerResponse> functionalRoutes(GreetingService greetingService) {
    return route()
        .GET("/functional/route", request -> {
            String name = request.param("name").orElse(null);
            return ServerResponse.ok().body(greetingService.greet(name));
        })
        .build();
}
```

Try it: `GET /functional/route?name=Grace` → `Hello, Grace!` (same underlying `GreetingService` as `/api/greet`)

## 9. Core lifecycle callbacks as lambdas — `LifecycleConfig`

- `ApplicationListener<E>` has a single abstract method, so it's lambda-friendly:
  ```java
  @Bean
  public ApplicationListener<ApplicationReadyEvent> onReady() {
      return event -> log.info("application ready");
  }
  ```
- `BeanPostProcessor` is included for contrast: both its methods have default bodies (no single
  abstract method), so it **cannot** be a lambda — it stays an anonymous class.
- **Gotcha:** the `BeanPostProcessor` `@Bean` method must be `static`. A non-static method requires
  Spring to fully instantiate the enclosing `@Configuration` class first (to call the method on
  it) — but `BeanPostProcessor`s must exist before other beans are post-processed, including the
  config class itself. Making the method `static` lets Spring produce the `BeanPostProcessor`
  without instantiating `LifecycleConfig` at all, avoiding the ordering conflict (see `qa.md` for
  the full explanation).

## 10. `WebMvcConfigurer` — `WebConfig`

A plain interface with default methods; override only what you need, each method configuring its
registry argument in place (the same `Consumer<T>`-shaped call as section 5):

```java
@Override
public void addCorsMappings(CorsRegistry registry) {
    registry.addMapping("/functional/**").allowedMethods("GET");
}
```

## 11. Template-callback pattern — `functional.template`

The older Spring style — `JdbcTemplate.query(sql, (rs, rowNum) -> ...)`,
`TransactionTemplate.execute(status -> ...)` — splits work into a **template** that owns
setup/teardown/exception-translation boilerplate, and a **callback** the caller supplies for just
the part that varies. `functional.template` reproduces the whole shape:

- `GreetingSession` — the managed resource (`AutoCloseable`), the role `java.sql.Connection` plays for `JdbcTemplate`.
- `GreetingSessionCallback<T>` — our own callback interface (`T doInSession(GreetingSession session)`), the role `ConnectionCallback<T>`/`RowMapper<T>` play.
- `GreetingSessionTemplate.execute(callback)` — opens a session, invokes the callback, closes the session via try-with-resources (even on failure), and translates any `RuntimeException` into...
- `GreetingSessionException` — mirrors Spring's checked→unchecked translation (`SQLException` → `DataAccessException`): callers only ever deal with one exception type.

```java
public <T> T execute(GreetingSessionCallback<T> callback) {
    String sessionId = "s" + sessionCounter.incrementAndGet();
    try (GreetingSession session = new GreetingSession(sessionId)) {
        return callback.doInSession(session);
    }
    catch (RuntimeException ex) {
        throw new GreetingSessionException("greeting session " + sessionId + " failed", ex);
    }
}
```

`GreetingSessionService` supplies the callback; `GreetingSessionController` translates
`GreetingSessionException` back into an HTTP 400 via `@ExceptionHandler`.

Try it: `GET /api/session-greet?name=Ada` → `Hello, Ada! (session s1)` · `GET /api/session-greet` (no name) → `400 name must not be blank`

## 12. `Predicate<T>` — `functional.predicate`

The fourth core `java.util.function` shape (`Supplier`/`Function`/`Consumer` are sections 1–2, 5–6).
Spring's `RequestPredicates` (WebMvc.fn) is the clearest real usage: named static factories return
`RequestPredicate`, a type with a single abstract method — `boolean test(ServerRequest)`,
structurally identical to `Predicate<ServerRequest>` — plus default `and()`/`or()`/`negate()`
combinators, exactly like `Predicate<T>` itself. `RequestPredicates.param(String, Predicate<String>)`
takes a **plain** `java.util.function.Predicate<String>` for the value check, so one example covers
both the named Spring type and the raw JDK one.

`GreetingRequestPredicates` (`functional/predicate/GreetingRequestPredicates.java`) mimics
`RequestPredicates`' own naming style:

```java
static final Predicate<String> NAME_PRESENT = name -> !name.isBlank();
static final Predicate<String> WANTS_SHOUT = "true"::equals;

public static RequestPredicate hasName() {
    return RequestPredicates.param("name", NAME_PRESENT);
}

public static RequestPredicate wantsShout() {
    return RequestPredicates.param("shout", WANTS_SHOUT);
}
```

`PredicateRouterConfig` composes them to route the *same path* to different handlers depending on
the request, instead of branching inside one handler:

```java
return route()
    .GET("/functional/predicate-route", hasName().and(wantsShout()),
            request -> ServerResponse.ok().body(greetingService.greet(request.param("name").orElseThrow()).toUpperCase()))
    .GET("/functional/predicate-route", hasName().and(wantsShout().negate()),
            request -> ServerResponse.ok().body(greetingService.greet(request.param("name").orElseThrow())))
    .build();
```

**Gotcha:** the method is `RequestPredicates.param(String, Predicate<String>)` in Spring Framework 7
(Boot 4.1) — older WebFlux-era docs/examples call it `queryParam`, which doesn't exist here.
Confirmed by disassembling the actual `spring-webmvc-7.0.8.jar` before writing any code, rather than
guessing from memory.

Try it: `GET /functional/predicate-route?name=Ada&shout=true` → `HELLO, ADA!` · `GET /functional/predicate-route?name=Ada` → `Hello, Ada!` · `GET /functional/predicate-route` (no name) → `404`

## 13. `ObjectProvider<T>` — `functional.objectprovider`

`ObjectProvider<T>` is what Spring injects when a constructor asks for a *provider* of a bean type
instead of the bean itself. It's the real mechanism `RestClientAutoConfiguration` uses internally
for `ObjectProvider<RestClientCustomizer>` (see `qa.md`'s explanation of how `RestClientCustomizer`
beans get collected). Two of its methods take functional interfaces directly:

- `T getIfAvailable(Supplier<T> defaultSupplier)` — returns the bean if one exists, otherwise calls
  the `Supplier` for a fallback.
- `void ifAvailable(Consumer<T> action)` — runs the `Consumer` only if a bean exists; a no-op
  otherwise.

Neither ever throws `NoSuchBeanDefinitionException` the way a plain `@Autowired` dependency would.

`GreetingSigningService` (`functional/objectprovider/GreetingSigningService.java`):

```java
public String sign(String message) {
    signerProvider.ifAvailable(signer -> log.info("using {}", signer.getClass().getSimpleName()));
    GreetingSigner signer = signerProvider.getIfAvailable(() -> plain -> plain);
    return signer.sign(message);
}
```

`DefaultGreetingSigner` is the one `GreetingSigner` bean actually registered in this app, so the
live endpoint exercises the "present" branch. The "absent" branch is exercised in
`GreetingSigningServiceTests` — not with a mock, but with a real `ObjectProvider` obtained from a
bare `DefaultListableBeanFactory` that has no `GreetingSigner` registered:

```java
ObjectProvider<GreetingSigner> emptyProvider = new DefaultListableBeanFactory().getBeanProvider(GreetingSigner.class);
```

Try it: `GET /api/sign?message=Hello` → `Hello [signed]`

## 14. `CommandLineRunner` / `ApplicationRunner` — `functional.runner`

Both have a single abstract method — `CommandLineRunner.run(String... args)` and
`ApplicationRunner.run(ApplicationArguments args)` — so both are lambda-friendly, and are the
standard way to run startup logic in a Boot app. Boot calls every bean of both types exactly once,
right after the context refreshes and *before* `SpringApplication.run()` returns — earlier than the
`ApplicationReadyEvent` `LifecycleConfig` (section 9) listens for.

`GreetingRunnerConfig` (`functional/runner/GreetingRunnerConfig.java`):

```java
@Bean
public CommandLineRunner greetingCommandLineRunner(StartupSummary summary) {
    return args -> summary.recordRawArgs(args);
}

@Bean
public ApplicationRunner greetingApplicationRunner(StartupSummary summary) {
    return args -> summary.recordParsedArgs(args);
}
```

The real reason `ApplicationRunner` exists: `CommandLineRunner` only ever sees raw strings —
`"--greeting.audit=true"` verbatim — while `ApplicationRunner` gets the same input pre-split into
recognized option names/values and separate non-option arguments. `GreetingRunnerConfigArgsTests`
proves this by starting a distinct context with `@SpringBootTest(args = {"--greeting.audit=true", "hello"})`
and asserting both runners' output differs accordingly.

Try it: `GET /api/startup-summary` → `raw args: [] | non-option args: [], option names: []` (no args passed to this running instance)

## 15. `TaskDecorator` — `functional.taskdecorator`

`TaskDecorator` has a single abstract method — `Runnable decorate(Runnable runnable)` — the same
`Function<T,R>` shape as any other `Function`, just applied to the task itself (`Runnable -> Runnable`)
instead of a value. `ThreadPoolTaskExecutor.setTaskDecorator(...)` runs it once per submitted task,
**on the submitting thread**, right before the task is handed to a worker thread — the only place
that can see the caller's `ThreadLocal` state before it's lost.

The classic real use case (MDC/context propagation across async boundaries) is what
`GreetingCorrelationTaskDecorator` reproduces, using its own `ThreadLocal` instead of MDC:

```java
@Override
public Runnable decorate(Runnable runnable) {
    String correlationId = GreetingCorrelation.get();
    return () -> {
        GreetingCorrelation.set(correlationId);
        try {
            runnable.run();
        }
        finally {
            GreetingCorrelation.clear();
        }
    };
}
```

`GreetingTaskExecutorConfig` wires it into a `ThreadPoolTaskExecutor` bean; `GreetingAsyncService`
submits work to it. `GreetingCorrelationTaskDecoratorTests` proves both halves of the story: run a
plain (undecorated) `Runnable` on a new thread and `GreetingCorrelation.get()` comes back `null` —
worker threads don't inherit the caller's `ThreadLocal` — but run the *decorated* version and it
sees the value the submitting thread had, because `decorate()` captured it before handoff.

Try it: `GET /api/async-correlation?correlationId=req-99` → `worker thread saw correlation id: req-99`

## 16. `BeanFactoryPostProcessor` — `functional.beanfactorypostprocessor`

`BeanFactoryPostProcessor` has a single abstract method —
`postProcessBeanFactory(ConfigurableListableBeanFactory)` — so, unlike `BeanPostProcessor`
(`LifecycleConfig`, section 9, which has two default methods and *can't* be a lambda), this one can.
It also runs much earlier: before any bean is instantiated, mutating `BeanDefinition` metadata
rather than live objects — the mechanism `PropertySourcesPlaceholderConfigurer` itself is built on.

`GreetingBanner` is a plain JavaBean whose `text` property is deliberately left unset.
`GreetingBannerConfig` (`functional/beanfactorypostprocessor/GreetingBannerConfig.java`) supplies it
via a `BeanFactoryPostProcessor` lambda that reaches into the bean definition directly:

```java
@Bean
public static BeanFactoryPostProcessor greetingBannerTextInjector() {
    return beanFactory -> {
        BeanDefinition definition = beanFactory.getBeanDefinition("greetingBanner");
        definition.getPropertyValues().add("text", "Injected before instantiation");
    };
}
```

Like `LifecycleConfig`'s `BeanPostProcessor` `@Bean`, this method must be `static` — for the same
reason (see `qa.md`): a `BeanFactoryPostProcessor` must exist before the enclosing `@Configuration`
class itself gets processed as a bean.

`GreetingBannerConfigTests` proves the injection actually lands *before* instantiation, not as a
side effect — it spins up an isolated `AnnotationConfigApplicationContext` with only this config and
asserts the bean's property, confirming this works for `@Bean`-method-declared beans (Spring still
runs standard property-value population after invoking the factory method, regardless of how the
instance was created) and not just XML- or component-scan-declared ones.

Try it: `GET /api/banner` → `Injected before instantiation`

## 17. Fluent / staged builder APIs — `functional.fluent`

Not a `java.util.function` shape like the rest of this document, but a closely related idiom Spring
leans on constantly: a chain of method calls, each one returning something (usually `this`, or the
next step of a staged builder) so the whole construction reads as one expression instead of a
sequence of statements plus a final `build()` call on a separate line.

**The real Spring example — `RestClient`.** `RestClient` is a *staged* fluent builder: each method
doesn't just return the same type for further chaining, it returns a **narrower interface** that
only exposes what's legal to call next. `.get()` returns `RequestHeadersUriSpec<?>`; `.uri(...)`
narrows that to `RequestHeadersSpec<?>`, which exposes `.header(...)` and `.retrieve()`; only
`.retrieve()` finally yields `ResponseSpec`, the only place `.body(Class<T>)` lives. There is no
path from `RequestHeadersUriSpec` straight to `ResponseSpec` — the type system enforces call order
at compile time, not runtime.

`GreetingClient` (`functional/fluent/GreetingClient.java`) finally puts the `demoRestClient` bean
from section 4 to real use — this had been defined but never called anywhere until now:

```java
public String fetchGreeting(String baseUrl, String name) {
    return restClient.get()
        .uri(baseUrl + "/api/greet?name={name}", name)
        .header("X-Requested-Via", "GreetingClient")
        .retrieve()
        .body(String.class);
}
```

`GreetingClientTests` doesn't mock any of this — it starts a **real embedded Tomcat** on a random
port (`@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)` + `@LocalServerPort`) and makes
an actual HTTP round trip from `GreetingClient` to this app's own `/api/greet` endpoint.

**The custom implementation — `GreetingInvitation`.** Reproduces the exact same staged-builder trick
from scratch, so an incomplete chain fails to *compile* instead of throwing at runtime:

```java
public interface RecipientStep {
    ToneStep to(String recipient);
}

public interface ToneStep {
    BuildStep tone(GreetingTone tone);
}

public interface BuildStep {
    String build();
}
```

`newInvitation()` only offers `.to(...)`; `.to(...)` only offers `.tone(...)`; only `.tone(...)`
finally offers `.build()`. A single private nested class (`Steps`) implements all three interfaces
at once and narrows its own apparent type with each return — `GreetingInvitation.newInvitation().to("Ada").tone(GreetingTone.EXCITED).build()`.
There's no way to call `.build()` without first supplying both a recipient and a tone; the compiler
rejects it, the same way it would reject skipping `.uri(...)` in a `RestClient` chain.

Try it: `GET /api/invitation?recipient=Ada&tone=EXCITED` → `OMG Ada, YOU HAVE TO COME!!!`

## 18. `@Valid` + custom Bean Validation constraint — `functional.validation`

Not a `java.util.function` shape either, but one of the most common things a real Spring MVC
controller does, and it fills a gap from the session review: nothing here previously touched
request-body binding, validation, or a *global* exception handler.

**The real Spring/Jakarta mechanism.** `GreetingRequest` (`functional/validation/GreetingRequest.java`)
uses the built-in constraints:

```java
@NotBlank(message = "name must not be blank")
@Size(max = 20, message = "name must be at most 20 characters")
private String name;
```

`GreetingValidationController` puts `@Valid @RequestBody GreetingRequest request` on a `POST
/api/validated-greeting` handler; Spring MVC validates the body before the method body even runs,
throwing `MethodArgumentNotValidException` on failure. `ValidationErrorHandler`, a
`@RestControllerAdvice`, catches that globally — across *every* `@RestController` in the app, not
just one — and turns it into a `{"field": "message"}` JSON body. This is the global counterpart to
the single-controller `@ExceptionHandler` already used in `functional.template.GreetingSessionController`
(section 11).

**The custom implementation — a constraint of our own.** `@NotBlank`/`@Size` are themselves built
from a public extension point: a `@Constraint`-meta-annotated annotation naming a
`ConstraintValidator` class. `NoShouting` + `NoShoutingValidator`
(`functional/validation/NoShouting.java`, `NoShoutingValidator.java`) build a business rule the same
way, from scratch:

```java
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = NoShoutingValidator.class)
public @interface NoShouting {
    String message() default "must not be written in all caps";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
```

```java
public class NoShoutingValidator implements ConstraintValidator<NoShouting, String> {
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isBlank()) {
            return true; // let @NotBlank handle presence
        }
        boolean hasLetters = value.chars().anyMatch(Character::isLetter);
        boolean isAllUpperCase = value.equals(value.toUpperCase());
        return !(hasLetters && isAllUpperCase);
    }
}
```

`@NoShouting` on `GreetingRequest.message` is discovered and enforced by `@Valid` identically to
`@NotBlank` — same validation pass, same `BindingResult`, same error map shape. Required adding
`spring-boot-starter-validation` (pulls in `hibernate-validator:9.1.0.Final` and
`jakarta.validation-api:3.1.1`, confirmed via `dependency:tree` before writing any code), since the
base `spring-boot-starter-web` app had no Bean Validation on the classpath at all.

Try it:
```
POST /api/validated-greeting
{"name": "Ada", "message": "hi there"}
```
→ `200 Hello, Ada! (hi there)`
```
POST /api/validated-greeting
{"name": "", "message": "HELLO THERE"}
```
→ `400 {"name": "name must not be blank", "message": "must not be written in all caps"}`

## 19. The CGLIB proxy behind every `@Configuration` class — `functional.proxy`

Every `@Configuration` class in this project has been logging as something like
`LifecycleConfig$$SpringCGLIB$$0` in test output since section 9 — that's been sitting unexplained
in this project's own logs the whole time. Here's what it actually is, and why it's there.

`@Configuration` classes are subclassed at runtime by CGLIB (`proxyBeanMethods = true`, the
default). Spring intercepts *every* call to a `@Bean` method — even a plain Java method call from
inside the same class — and redirects it through the container, returning the existing singleton
instead of re-running the method body. `CglibProxyConfig` (`functional/proxy/CglibProxyConfig.java`)
makes this directly observable:

```java
@Bean
public Ingredient ingredient() {
    return new Ingredient();
}

@Bean
public IngredientPair ingredientPair() {
    return new IngredientPair(ingredient(), ingredient());
}
```

Two calls to `ingredient()`, textually — but only one `Ingredient` is ever constructed, because the
second call is intercepted by the proxy and short-circuited straight to the cached singleton.
`IngredientPair.sameInstance()` (`first == second`) is `true`.

**The contrast that proves it's the proxy, not Java semantics:** `LiteProxyConfig`
(`functional/proxy/LiteProxyConfig.java`) is the *exact same source*, except
`@TestConfiguration(proxyBeanMethods = false)` — Boot's "lite" mode, which skips the CGLIB
subclassing entirely. With no proxy in the way, `ingredient()` is just a normal method: calling it
twice really does run the body twice, producing two different instances.
`ProxyBeanMethodsTests` proves both halves in isolated `AnnotationConfigApplicationContext`s,
including asserting the literal class name: `configBean.getClass().getName()` contains
`"$$SpringCGLIB$$"` for the fully-proxied config and doesn't for the lite one.

**Gotcha hit building this:** `LiteProxyConfig` started life as plain `@Configuration`. Since Maven's
test classpath merges `src/main` *and* `src/test` compiled classes together, `@SpringBootApplication`'s
component scan found it regardless of which source root it lived in, and it collided with
`CglibProxyConfig`'s `ingredient` bean name — breaking every other `@SpringBootTest` in the project
at once, not just this one. The fix is `@TestConfiguration` instead of `@Configuration`: Boot's test
support (`TestTypeExcludeFilter`) specifically excludes classes carrying that annotation from
regular component scanning, while manual registration (`new AnnotationConfigApplicationContext(LiteProxyConfig.class)`,
what `ProxyBeanMethodsTests` does) still works. This is the standard, real-world fix for any
test-only `@Configuration` class, not just this example.

**A second, live version of the lite-mode contrast:** since `LiteProxyConfig` only exists in
`src/test` (it can never be reachable from the running app), `LiteIngredientConfig`
(`functional/proxy/LiteIngredientConfig.java`) is a real, `src/main`-registered
`@Configuration(proxyBeanMethods = false)` class you can actually curl, not just prove in an
isolated test context. It needs its own `LiteIngredientPair` type, distinct from `IngredientPair` —
reusing the same type would make two beans of that type coexist in the app, and `ProxyCheckController`
autowiring `IngredientPair` by type alone would become ambiguous.

Try it: `GET /api/proxy-check` → `same instance: true (first=..., second=...)` — same UUID both
times. `GET /api/proxy-check-lite` → `same instance: false` — two different UUIDs, same source
shape, only `proxyBeanMethods` differs.

## 20. The self-invocation gotcha — `functional.selfinvocation`

Probably the most common real-world Spring surprise: `@Transactional`, `@Async`, `@Cacheable`, and
any custom `@Aspect`-based behavior are all applied by wrapping a bean in a proxy. The proxy only
sees calls that arrive *through* it, from outside the bean. A call made from inside the bean itself
(`this.method()`) is a plain Java call on the real object — it never reaches the proxy, so none of
that behavior fires, even though the method is still annotated.

`Logged` (`functional/selfinvocation/Logged.java`) stands in for `@Transactional`/`@Async`; `LoggedAspect`
is a minimal `@Aspect`:

```java
@Before("@annotation(Logged)")
public void logInvocation() {
    interceptionCounter.increment();
}
```

`GreetingAnnouncer` has one `@Logged` method and two ways to reach it:

```java
@Logged
public String announce(String name) {
    return "Announcing: " + name;
}

public String announceViaSelfInvocation(String name) {
    return announce(name);   // this.announce(name) -- bypasses the proxy
}
```

Calling `announcer.announce("Ada")` from outside the bean goes through the proxy and the aspect
fires. Calling `announcer.announceViaSelfInvocation("Ada")` runs `announce()` too — same method, same
`@Logged` annotation — but the aspect never fires, because that call happened inside the bean.
`SelfInvocationTests` proves both outcomes with a real counter, not log-scraping.

**Gotcha in building this one, before writing any code:** `spring-boot-starter-aop` — the dependency
every existing guide tells you to add for this — doesn't exist for Spring Boot 4.x at all (confirmed:
Maven Central tops out at `3.5.3`). `spring-aop` itself is already transitively present (via
`spring-webmvc`), and Boot's `AopAutoConfiguration` still auto-enables CGLIB proxying once
`@Aspect`'s annotation class is on the classpath — the starter's only real job had been pulling in
`aspectjweaver` for the annotation-style pointcut parser. Boot's dependency BOM still manages an
`aspectj.version`, so `org.aspectj:aspectjweaver` (no explicit version needed) is the correct
replacement, added directly in `pom.xml`.

Try it: `GET /api/self-invocation?name=Ada` → `direct call intercepted: true, self-invocation intercepted: false`

## Beyond the gallery: Greeting Book

Everything above is a small, isolated example of one pattern. `com.example.demo.greetingbook` is
different on purpose: a real (if simple) feature — a REST API for saving, listing, and deleting
greetings — built as an ordinary layered Spring app, using several of the patterns above as
building blocks rather than as the point of the exercise. It lives in its own top-level package,
a sibling of `functional`, not inside it.

| Class | Role |
|---|---|
| `Greeting` | domain record — `id`, `recipient`, `message`, `createdAt` |
| `GreetingRepository` / `InMemoryGreetingRepository` | repository abstraction over a `ConcurrentHashMap`; a real `DataSource`-backed implementation would sit behind the same interface without the service or controller changing |
| `GreetingBookService` | business logic — id assignment, not-found handling |
| `CreateGreetingRequest` | request DTO, reusing `@NoShouting` from `functional.validation` directly |
| `GreetingBookController` | `POST`/`GET`/`GET {id}`/`DELETE {id}` on `/api/greeting-book` |
| `GreetingNotFoundException` | translated to `404` via a controller-local `@ExceptionHandler` |

Three things carry over directly from the gallery, proving they weren't just toy examples:

- **`@Valid` validation errors on this controller are caught by the same global
  `ValidationErrorHandler`** (`functional.validation`, section 18) that was written for a completely
  different controller — no per-controller wiring needed. `POST` with a blank recipient *and* a
  shouting message returns both errors from one request, driven by two independent constraints
  (`@NotBlank` and the custom `@NoShouting`) doing double duty across two unrelated features.
- **`ResponseEntity.created(location).body(greeting)` and `ServletUriComponentsBuilder`** are two
  more real Spring fluent/staged builders (section 17's theme) put to actual use, building the
  `Location` header for the `201` response.
- **The repository/service split** is the same "depend on the interface, not the implementation"
  shape `GreetingClient` (section 17) depends on `RestClient` for.

Verified end to end with a real running instance, not just tests — `curl` against a live
`spring-boot:run` process confirmed the `Instant` field serializes as clean ISO-8601 with no extra
Jackson module needed, the `Location` header is correct, and both the built-in and custom
constraint fire together on one bad request:

```
$ curl -i -X POST :8099/api/greeting-book -d '{"recipient":"","message":"HELLO"}'
HTTP/1.1 400
{"recipient":"recipient must not be blank","message":"must not be written in all caps"}

$ curl -i -X POST :8099/api/greeting-book -d '{"recipient":"Ada","message":"hi there"}'
HTTP/1.1 201
Location: http://localhost:8099/api/greeting-book/1
{"id":1,"recipient":"Ada","message":"hi there","createdAt":"2026-07-25T17:25:32.975540Z"}
```

## Patterns mentioned but not built here

These need dependencies or infrastructure this app doesn't have (WebFlux, a real datasource, Spring
Cloud Gateway/Function, Spring Integration):

- Reactor `map()` / `WebClient.exchangeToMono(Function<ClientResponse, Mono<T>>)` (needs WebFlux)
- `JdbcTemplate`/`TransactionTemplate` themselves (needs a real `DataSource`; section 11 mimics the
  pattern without one)
- Spring Integration Java DSL, Spring Cloud Function, Spring Cloud Gateway's `RouteLocatorBuilder`

## Summary

| Shape | Returns | Our example | Endpoint |
|---|---|---|---|
| `Supplier<T>` | `T` | `GreetingService.defaultName` | `GET /api/greet` |
| `Function<T,R>` | `R` | `GreetingService.toGreeting` | `GET /api/greet` |
| `Consumer<T>` (field) | `void` | `GreetingService.logger` | `GET /api/greet` |
| `Converter<S,T>` | `T` | `UpperCaseConverter` | `GET /api/upper` |
| `Customizer<T>` (named, collected) | `void` | `functional.customizer` | `GET /api/greet-custom` |
| `Consumer<T>` (builder param) | `void` | `functional.consumer` | `GET /api/card` |
| `Supplier<T>` (bean registration) | `T` | `functional.supplier` | `GET /api/stamp` |
| `Source.Adapter<T,R>` (Function-shaped) | `R` | `functional.function` | `GET /api/greet-mapped` |
| `RouterFunction`/`HandlerFunction` | `ServerResponse` | `FunctionalRouterConfig` | `GET /functional/route` |
| `ApplicationListener<E>` | `void` | `LifecycleConfig` | (startup log) |
| Template + callback | `T` | `functional.template` | `GET /api/session-greet` |
| `Predicate<T>` / `RequestPredicate` | `boolean` | `functional.predicate` | `GET /functional/predicate-route` |
| `ObjectProvider<T>` (`getIfAvailable`/`ifAvailable`) | `T` / `void` | `functional.objectprovider` | `GET /api/sign` |
| `CommandLineRunner` / `ApplicationRunner` | `void` | `functional.runner` | `GET /api/startup-summary` |
| `TaskDecorator` | `Runnable` | `functional.taskdecorator` | `GET /api/async-correlation` |
| `BeanFactoryPostProcessor` | `void` | `functional.beanfactorypostprocessor` | `GET /api/banner` |
| Fluent / staged builder | narrowing interfaces | `functional.fluent` | `GET /api/invitation` |
| `ConstraintValidator<A,T>` (`@Valid`) | `boolean` | `functional.validation` | `POST /api/validated-greeting` |
| `@Configuration` CGLIB proxy (`proxyBeanMethods`) | same instance | `functional.proxy` | `GET /api/proxy-check` |
| `@Aspect` + self-invocation | `void` (side effect) | `functional.selfinvocation` | `GET /api/self-invocation` |
