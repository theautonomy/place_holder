-- Remove occurrence tracking columns
-- Each row now represents a single error occurrence
-- Occurrence counts are calculated dynamically by grouping

ALTER TABLE error_logs DROP COLUMN IF EXISTS occurrence_count;
ALTER TABLE error_logs DROP COLUMN IF EXISTS first_occurrence;
ALTER TABLE error_logs DROP COLUMN IF EXISTS last_occurrence;

-- Drop the old index on last_occurrence
DROP INDEX IF EXISTS idx_error_logs_last_occurrence;

-- Add index on error_type and error_message for faster grouping
CREATE INDEX IF NOT EXISTS idx_error_logs_type_message ON error_logs(error_type, error_message);

-- Update comments
COMMENT ON TABLE error_logs IS 'Stores every error occurrence separately for trend analysis';
COMMENT ON COLUMN error_logs.id IS 'Unique identifier for each error occurrence';
