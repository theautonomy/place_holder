package com.example.demo.service;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.example.demo.model.ErrorLog;
import com.example.demo.model.SimilarError;
import com.example.demo.repository.ErrorLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.stereotype.Service;

@Service
public class ErrorChatService {

    private static final Logger logger = LoggerFactory.getLogger(ErrorChatService.class);

    private final ChatClient chatClient;
    private final ErrorSearchService errorSearchService;
    private final ErrorAnalyticsService errorAnalyticsService;
    private final ErrorLogRepository errorLogRepository;

    public ErrorChatService(
            ChatClient.Builder chatClientBuilder,
            ErrorSearchService errorSearchService,
            ErrorAnalyticsService errorAnalyticsService,
            ErrorLogRepository errorLogRepository) {
        this.chatClient = chatClientBuilder.build();
        this.errorSearchService = errorSearchService;
        this.errorAnalyticsService = errorAnalyticsService;
        this.errorLogRepository = errorLogRepository;
    }

    /** Query intent types */
    private enum QueryIntent {
        TEMPORAL, // "errors from last Tuesday"
        CORRELATION, // "what errors happen together"
        TRENDING, // "which errors are increasing"
        COMPARISON, // "compare production vs staging"
        ROOT_CAUSE, // "why did error X spike"
        IMPACT, // "how many users were affected"
        GENERAL // General questions
    }

    /** Answer questions about errors using RAG (Retrieval Augmented Generation) */
    public String askQuestion(String question) {
        logger.info("Received question: {}", question);

        // Step 1: Detect query intent
        QueryIntent intent = detectIntent(question);
        logger.info("Detected query intent: {}", intent);

        // Step 2: Route to appropriate handler based on intent
        try {
            return switch (intent) {
                case TEMPORAL -> handleTemporalQuery(question);
                case CORRELATION -> handleCorrelationQuery(question);
                case TRENDING -> handleTrendingQuery(question);
                case COMPARISON -> handleComparisonQuery(question);
                case ROOT_CAUSE -> handleRootCauseQuery(question);
                case IMPACT -> handleImpactQuery(question);
                case GENERAL -> handleGeneralQuery(question);
            };
        } catch (Exception e) {
            logger.error("Error handling question: {}", question, e);
            return "I encountered an error while processing your question. Please try again or rephrase your question.";
        }
    }

    /** Ask about a specific error */
    public String askAboutError(Long errorId, String question) {
        logger.info("Question about error {}: {}", errorId, question);

        // Find similar errors for context
        List<SimilarError> similarErrors = errorSearchService.findSimilarToError(errorId, 3);

        String context = buildContextFromErrors(similarErrors);

        String promptText =
                """
            Based on the following error information, answer the user's question.

            Context:
            {context}

            User Question: {question}

            Provide a clear, concise, and actionable answer.
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("context", context);
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating answer", e);
            return "I encountered an error while processing your question. Please try again.";
        }
    }

    /** Get insights about error patterns */
    public String getErrorInsights(String applicationName, String environment) {
        String query =
                String.format(
                        "Show me error patterns for %s in %s environment",
                        applicationName, environment);

        List<SimilarError> errors = errorSearchService.searchByNaturalLanguage(query, 10);

        if (errors.isEmpty()) {
            return String.format(
                    "No errors found for %s in %s environment.", applicationName, environment);
        }

        String context = buildContextFromErrors(errors);

        String promptText =
                """
            Analyze the following errors and provide insights about patterns, common issues, and recommendations.

            Errors:
            {context}

            Provide:
            1. Common error patterns
            2. Most critical issues
            3. Recommended actions
            4. Potential root causes
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("context", context);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating insights", e);
            return "Unable to generate insights at this time.";
        }
    }

    /** Compare and explain differences between errors */
    public String compareErrors(Long errorId1, Long errorId2) {
        List<SimilarError> errors1 = errorSearchService.findSimilarToError(errorId1, 1);
        List<SimilarError> errors2 = errorSearchService.findSimilarToError(errorId2, 1);

        if (errors1.isEmpty() || errors2.isEmpty()) {
            return "Unable to find one or both errors for comparison.";
        }

        String promptText =
                """
            Compare the following two errors and explain:
            1. Similarities
            2. Differences
            3. Whether they might have the same root cause
            4. How to approach fixing each one

            Error 1:
            Application: {app1}
            Error Type: {type1}
            Message: {msg1}
            Stack Trace: {stack1}

            Error 2:
            Application: {app2}
            Error Type: {type2}
            Message: {msg2}
            Stack Trace: {stack2}
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();

        var error1 = errors1.get(0).getErrorLog();
        var error2 = errors2.get(0).getErrorLog();

        params.put("app1", error1.getApplicationName());
        params.put("type1", error1.getErrorType());
        params.put("msg1", error1.getErrorMessage());
        params.put("stack1", truncate(error1.getStackTrace(), 500));

        params.put("app2", error2.getApplicationName());
        params.put("type2", error2.getErrorType());
        params.put("msg2", error2.getErrorMessage());
        params.put("stack2", truncate(error2.getStackTrace(), 500));

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error comparing errors", e);
            return "Unable to compare errors at this time.";
        }
    }

    /** Generate automated trend report for a time period */
    public String generateTrendReport(String applicationName, int days, String reportType) {
        long startTime = System.currentTimeMillis();
        logger.info(
                "=== Starting trend report generation: {} report for {} (last {} days) ===",
                reportType,
                applicationName,
                days);

        LocalDateTime since = LocalDateTime.now().minusDays(days);

        // Step 1: Detect trends
        long step1Start = System.currentTimeMillis();
        Map<String, Object> trends = errorAnalyticsService.detectTrends(applicationName, days);
        logger.info("Step 1 (Detect trends): {} ms", System.currentTimeMillis() - step1Start);

        // Step 2: Get error statistics
        long step2Start = System.currentTimeMillis();
        Map<String, Object> stats =
                errorAnalyticsService.getErrorStatistics(applicationName, days * 24, 20);
        logger.info(
                "Step 2 (Get error statistics): {} ms", System.currentTimeMillis() - step2Start);

        // Step 3: Compare environments
        long step3Start = System.currentTimeMillis();
        Map<String, Object> comparison = errorAnalyticsService.compareEnvironments(applicationName);
        logger.info(
                "Step 3 (Compare environments): {} ms", System.currentTimeMillis() - step3Start);

        // Step 4: Get recent critical errors
        long step4Start = System.currentTimeMillis();
        List<ErrorLog> recentErrors = errorLogRepository.findRecentErrors(since);
        List<ErrorLog> criticalErrors =
                recentErrors.stream()
                        .filter(e -> "CRITICAL".equals(e.getSeverity()))
                        .limit(10)
                        .collect(Collectors.toList());
        logger.info(
                "Step 4 (Get critical errors): {} ms, found {} critical out of {} total",
                System.currentTimeMillis() - step4Start,
                criticalErrors.size(),
                recentErrors.size());

        // Step 5: Build comprehensive context
        long step5Start = System.currentTimeMillis();
        String trendContext = formatTrendsForContext(trends);
        String statsContext = formatStatsForContext(stats);
        String comparisonContext = formatComparisonForContext(comparison);
        String criticalContext = buildContextFromErrorLogs(criticalErrors);
        logger.info("Step 5 (Build contexts): {} ms", System.currentTimeMillis() - step5Start);

        // Step 6: Build prompt template
        long step6Start = System.currentTimeMillis();
        String promptText = buildTrendReportPrompt(reportType, days, applicationName);
        logger.info(
                "Step 6 (Build prompt template): {} ms", System.currentTimeMillis() - step6Start);

        // Step 7: Prepare prompt parameters
        long step7Start = System.currentTimeMillis();
        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("applicationName", applicationName);
        params.put("days", days);
        params.put("period", days == 1 ? "Last 24 Hours" : "Last " + days + " Days");
        params.put("trends", trendContext);
        params.put("statistics", statsContext);
        params.put("comparison", comparisonContext);
        params.put(
                "criticalErrors",
                criticalErrors.isEmpty() ? "No critical errors in this period." : criticalContext);
        params.put("totalErrors", trends.get("totalErrors"));
        params.put("averageErrorsPerDay", trends.get("averageErrorsPerDay"));
        params.put(
                "generatedAt",
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")));

        Prompt prompt = promptTemplate.create(params);
        logger.info("Step 7 (Prepare prompt): {} ms", System.currentTimeMillis() - step7Start);

        // Step 8: AI/LLM call
        try {
            long step8Start = System.currentTimeMillis();
            logger.info("Step 8: Calling AI/LLM for {} report generation...", reportType);
            String result = chatClient.prompt(prompt).call().content();
            logger.info("Step 8 (AI/LLM call): {} ms", System.currentTimeMillis() - step8Start);
            logger.info(
                    "=== Total trend report generation time: {} ms ===",
                    System.currentTimeMillis() - startTime);
            return result;
        } catch (Exception e) {
            logger.error("Error generating trend report", e);
            return "Unable to generate trend report at this time. Please try again later.";
        }
    }

    /** Build prompt for trend report based on type */
    private String buildTrendReportPrompt(String reportType, int days, String applicationName) {
        if ("executive".equals(reportType)) {
            return """
                Generate an EXECUTIVE SUMMARY trend report for error analysis.

                Application: {applicationName}
                Time Period: {period}
                Report Generated: {generatedAt}

                ## DATA SUMMARY

                Total Errors: {totalErrors}
                Average Errors/Day: {averageErrorsPerDay}

                Statistics:
                {statistics}

                Trends:
                {trends}

                Environment Comparison:
                {comparison}

                Critical Errors:
                {criticalErrors}

                ## INSTRUCTIONS

                Create a concise executive summary (suitable for C-level executives) that includes:

                1. **Executive Summary** (2-3 sentences)
                   - Overall health status (Healthy/Concerning/Critical)
                   - Key takeaway

                2. **Key Metrics** (bullet points)
                   - Total error count and trend direction
                   - Critical vs non-critical breakdown
                   - Environment comparison highlights

                3. **Top Issues** (3-5 items)
                   - Most impactful errors
                   - Priority ranking

                4. **Action Items** (3-5 recommendations)
                   - Immediate actions required
                   - Long-term improvements

                5. **Risk Assessment**
                   - Current risk level (Low/Medium/High/Critical)
                   - Potential business impact

                Keep it concise, actionable, and non-technical. Focus on business impact.
                """;
        } else if ("detailed".equals(reportType)) {
            return """
                Generate a DETAILED TECHNICAL trend report for error analysis.

                Application: {applicationName}
                Time Period: {period}
                Report Generated: {generatedAt}

                ## DATA SUMMARY

                Total Errors: {totalErrors}
                Average Errors/Day: {averageErrorsPerDay}

                Statistics:
                {statistics}

                Trends:
                {trends}

                Environment Comparison:
                {comparison}

                Critical Errors:
                {criticalErrors}

                ## INSTRUCTIONS

                Create a comprehensive technical report that includes:

                1. **Overview**
                   - Period summary
                   - Overall trend analysis
                   - Health status

                2. **Error Analysis**
                   - Top error types with occurrence counts
                   - Severity distribution
                   - Error patterns and correlations

                3. **Trend Analysis**
                   - Errors increasing vs decreasing
                   - Spike detection and analysis
                   - New error types identified

                4. **Environment Comparison**
                   - Production vs Staging vs Development
                   - Environment-specific issues

                5. **Critical Errors Deep Dive**
                   - Analysis of critical errors
                   - Potential root causes
                   - Stack trace patterns

                6. **Recommendations**
                   - Technical improvements
                   - Monitoring enhancements
                   - Prevention strategies

                7. **Risk Assessment**
                   - Current system stability
                   - Potential failure points
                   - Recommended actions

                Be thorough, technical, and provide specific actionable insights.
                """;
        } else {
            // Standard report
            return """
                Generate a STANDARD trend report for error analysis.

                Application: {applicationName}
                Time Period: {period}
                Report Generated: {generatedAt}

                ## DATA SUMMARY

                Total Errors: {totalErrors}
                Average Errors/Day: {averageErrorsPerDay}

                Statistics:
                {statistics}

                Trends:
                {trends}

                Environment Comparison:
                {comparison}

                Critical Errors:
                {criticalErrors}

                ## INSTRUCTIONS

                Create a balanced trend report that includes:

                1. **Summary**
                   - Period overview
                   - Key findings (3-5 bullet points)

                2. **Error Statistics**
                   - Total errors and breakdown by severity
                   - Top 5 most frequent errors

                3. **Trends**
                   - Notable increases or decreases
                   - Spike detection results
                   - New error types

                4. **Environment Health**
                   - Comparison across environments
                   - Environment-specific concerns

                5. **Recommendations**
                   - Top 3-5 action items
                   - Priority levels (High/Medium/Low)

                Provide clear, actionable insights suitable for engineering teams.
                """;
        }
    }

    /** Analyze root cause for a specific error with spike detection */
    public String analyzeRootCause(Long errorId) {
        long startTime = System.currentTimeMillis();
        logger.info("=== Starting root cause analysis for error ID: {} ===", errorId);

        // Step 1: Get the error details
        long step1Start = System.currentTimeMillis();
        ErrorLog targetError =
                errorLogRepository
                        .findById(errorId)
                        .orElseThrow(() -> new RuntimeException("Error not found: " + errorId));
        logger.info("Step 1 (Get error details): {} ms", System.currentTimeMillis() - step1Start);

        // Step 2: Detect if there's a spike
        long step2Start = System.currentTimeMillis();
        Map<String, Object> spikeInfo = errorAnalyticsService.detectErrorSpike(errorId);
        logger.info("Step 2 (Detect spike): {} ms", System.currentTimeMillis() - step2Start);

        // Step 3: Find correlated errors (within ±30 minutes)
        long step3Start = System.currentTimeMillis();
        List<ErrorLog> correlatedErrors = errorAnalyticsService.findCorrelatedErrors(errorId);
        logger.info(
                "Step 3 (Find correlated errors): {} ms", System.currentTimeMillis() - step3Start);

        // Step 4: Analyze stack trace patterns
        long step4Start = System.currentTimeMillis();
        Map<String, Object> stackTraceAnalysis =
                errorAnalyticsService.analyzeStackTracePatterns(targetError.getErrorType(), 24);
        logger.info(
                "Step 4 (Analyze stack traces): {} ms", System.currentTimeMillis() - step4Start);

        // Step 5: Find similar errors using semantic search
        long step5Start = System.currentTimeMillis();
        List<SimilarError> similarErrors =
                errorSearchService.findSimilarErrors(targetError.getStackTrace(), 5, 0.7);
        logger.info(
                "Step 5 (Find similar errors - vector search): {} ms",
                System.currentTimeMillis() - step5Start);

        // Step 6: Build comprehensive context
        long step6Start = System.currentTimeMillis();
        String spikeContext = formatSpikeInfoForContext(spikeInfo);
        String correlatedContext = buildCorrelatedErrorsContext(correlatedErrors);
        String stackTraceContext = formatStackTraceAnalysisForContext(stackTraceAnalysis);
        String similarContext = buildContextFromErrors(similarErrors);
        logger.info("Step 6 (Build contexts): {} ms", System.currentTimeMillis() - step6Start);

        // Step 7: Generate AI-powered root cause analysis
        String promptText =
                """
            Perform a comprehensive root cause analysis for the following error spike.

            # TARGET ERROR

            Error ID: {errorId}
            Application: {applicationName}
            Environment: {environment}
            Error Type: {errorType}
            Error Message: {errorMessage}
            Severity: {severity}
            Occurred At: {occurredAt}
            Stack Trace: {stackTrace}

            # SPIKE ANALYSIS

            {spikeInfo}

            # CORRELATED ERRORS (within ±30 minutes)

            {correlatedErrors}

            # STACK TRACE PATTERNS

            {stackTracePatterns}

            # SIMILAR ERRORS

            {similarErrors}

            # INSTRUCTIONS

            Provide a structured root cause analysis with the following sections:

            ## 1. Spike Assessment
            - Is this a genuine spike or normal behavior?
            - Severity and urgency level

            ## 2. Potential Root Causes (ranked by confidence)
            For each potential cause:
            - Confidence level (percentage)
            - Evidence supporting this cause
            - Timeline alignment

            Example format:
            **1. Database Connection Pool Exhaustion (80% confidence)**
            - Evidence: Concurrent increase in SQLException timeout errors
            - Timeline: Both errors spiked at the same time (±5 minutes)

            ## 3. Correlated Events
            - What other errors or events occurred around the same time?
            - Are these likely related or coincidental?

            ## 4. Stack Trace Insights
            - What do the stack trace patterns reveal?
            - Which methods/classes are most frequently involved?

            ## 5. Recommended Investigation Steps
            - Immediate actions to take
            - Where to look for more information
            - Diagnostic queries or logs to check

            ## 6. Mitigation Suggestions
            - Short-term fixes to stop the bleeding
            - Long-term solutions to prevent recurrence

            Be specific, actionable, and focus on evidence-based analysis. If confidence is low, state that clearly.
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("errorId", errorId);
        params.put("applicationName", targetError.getApplicationName());
        params.put("environment", targetError.getEnvironment());
        params.put("errorType", targetError.getErrorType());
        params.put("errorMessage", targetError.getErrorMessage());
        params.put("severity", targetError.getSeverity());
        params.put(
                "occurredAt",
                targetError
                        .getOccurredAt()
                        .format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm:ss")));
        params.put("stackTrace", truncate(targetError.getStackTrace(), 1000));
        params.put("spikeInfo", spikeContext);
        params.put(
                "correlatedErrors",
                correlatedErrors.isEmpty()
                        ? "No significantly correlated errors found in the ±30 minute window."
                        : correlatedContext);
        params.put("stackTracePatterns", stackTraceContext);
        params.put(
                "similarErrors",
                similarErrors.isEmpty()
                        ? "No similar errors found using semantic search."
                        : similarContext);

        Prompt prompt = promptTemplate.create(params);

        try {
            long step7Start = System.currentTimeMillis();
            logger.info("Step 7: Calling AI/LLM for analysis...");
            String result = chatClient.prompt(prompt).call().content();
            logger.info("Step 7 (AI/LLM call): {} ms", System.currentTimeMillis() - step7Start);
            logger.info(
                    "=== Total root cause analysis time: {} ms ===",
                    System.currentTimeMillis() - startTime);
            return result;
        } catch (Exception e) {
            logger.error("Error generating root cause analysis", e);
            return "Unable to generate root cause analysis at this time. Please try again later.";
        }
    }

    /** Format spike info for context */
    private String formatSpikeInfoForContext(Map<String, Object> spikeInfo) {
        StringBuilder sb = new StringBuilder();

        sb.append("Spike Detected: ").append(spikeInfo.get("isSpike")).append("\n");
        sb.append("Error Type: ").append(spikeInfo.get("errorType")).append("\n");
        sb.append("Application: ").append(spikeInfo.get("applicationName")).append("\n");
        sb.append("Error Time: ").append(spikeInfo.get("errorTime")).append("\n");
        sb.append("Baseline Rate: ").append(spikeInfo.get("baselineRate")).append("\n");
        sb.append("Spike Rate: ").append(spikeInfo.get("spikeRate")).append("\n");
        sb.append("Spike Ratio: ").append(spikeInfo.get("spikeRatio")).append("\n");
        sb.append("Baseline Count (7 days): ").append(spikeInfo.get("baselineCount")).append("\n");
        sb.append("Spike Window Count (2 hours): ")
                .append(spikeInfo.get("spikeCount"))
                .append("\n");
        sb.append("Spike Window: ").append(spikeInfo.get("spikeWindow")).append("\n");

        return sb.toString();
    }

    /** Build context from correlated errors */
    private String buildCorrelatedErrorsContext(List<ErrorLog> correlatedErrors) {
        if (correlatedErrors.isEmpty()) {
            return "No correlated errors found.";
        }

        // Group by error type and count
        Map<String, Long> errorTypeCounts =
                correlatedErrors.stream()
                        .collect(
                                Collectors.groupingBy(
                                        ErrorLog::getErrorType, Collectors.counting()));

        StringBuilder sb = new StringBuilder();
        sb.append("Found ")
                .append(correlatedErrors.size())
                .append(" correlated errors of ")
                .append(errorTypeCounts.size())
                .append(" different types:\n\n");

        errorTypeCounts.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .forEach(
                        entry -> {
                            sb.append("- ")
                                    .append(entry.getKey())
                                    .append(": ")
                                    .append(entry.getValue())
                                    .append(" occurrences\n");
                        });

        // Add sample details for top correlated errors
        sb.append("\nSample Error Details:\n");
        correlatedErrors.stream()
                .limit(3)
                .forEach(
                        error -> {
                            sb.append("\n")
                                    .append("Error Type: ")
                                    .append(error.getErrorType())
                                    .append("\n");
                            sb.append("Message: ").append(error.getErrorMessage()).append("\n");
                            sb.append("Severity: ").append(error.getSeverity()).append("\n");
                            sb.append("Occurred At: ").append(error.getOccurredAt()).append("\n");
                            sb.append("---\n");
                        });

        return sb.toString();
    }

    /** Format stack trace analysis for context */
    private String formatStackTraceAnalysisForContext(Map<String, Object> analysis) {
        StringBuilder sb = new StringBuilder();

        sb.append("Total Matching Errors: ").append(analysis.get("totalMatches")).append("\n");
        sb.append("Error Type: ").append(analysis.get("errorType")).append("\n\n");

        @SuppressWarnings("unchecked")
        List<Map.Entry<String, Integer>> topMethods =
                (List<Map.Entry<String, Integer>>) analysis.get("topMethods");

        if (topMethods != null && !topMethods.isEmpty()) {
            sb.append("Top Methods (most frequently appearing in stack traces):\n");
            topMethods.forEach(
                    entry ->
                            sb.append("  ")
                                    .append(entry.getKey())
                                    .append(": ")
                                    .append(entry.getValue())
                                    .append(" times\n"));
        }

        @SuppressWarnings("unchecked")
        List<Map.Entry<String, Integer>> topClasses =
                (List<Map.Entry<String, Integer>>) analysis.get("topClasses");

        if (topClasses != null && !topClasses.isEmpty()) {
            sb.append("\nTop Classes:\n");
            topClasses.forEach(
                    entry ->
                            sb.append("  ")
                                    .append(entry.getKey())
                                    .append(": ")
                                    .append(entry.getValue())
                                    .append(" times\n"));
        }

        return sb.toString();
    }

    /** Suggest solutions based on error query */
    public String suggestSolutions(String errorDescription) {
        List<SimilarError> similarErrors =
                errorSearchService.searchByNaturalLanguage(errorDescription, 5);

        String context = buildContextFromErrors(similarErrors);

        String promptText =
                """
            Based on similar errors in our system and the user's error description, suggest solutions.

            User's Error Description:
            {errorDescription}

            Similar Errors in System:
            {context}

            Provide:
            1. Most likely cause
            2. Step-by-step solution
            3. Code examples if applicable
            4. Prevention tips
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("errorDescription", errorDescription);
        params.put("context", context);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error suggesting solutions", e);
            return "Unable to suggest solutions at this time.";
        }
    }

    /** Detect the intent of a user query */
    private QueryIntent detectIntent(String question) {
        String lowerQuestion = question.toLowerCase();

        // Temporal queries - looking for time-based patterns
        if (lowerQuestion.matches(
                ".*(yesterday|last (monday|tuesday|wednesday|thursday|friday|saturday|sunday)|last week|last month|this week|today).*")) {
            return QueryIntent.TEMPORAL;
        }

        // Correlation queries - looking for relationships between errors
        if (lowerQuestion.matches(
                ".*(together|correlation|related|same time|concurrent|along with|associated).*")) {
            return QueryIntent.CORRELATION;
        }

        // Trending queries - looking for patterns over time
        if (lowerQuestion.matches(
                ".*(increasing|decreasing|trending|growing|rising|falling|trend|more frequent|less frequent).*")) {
            return QueryIntent.TRENDING;
        }

        // Comparison queries - comparing environments, applications, etc.
        if (lowerQuestion.matches(
                ".*(compare|comparison|versus|vs\\.?|difference between|compared to).*")) {
            return QueryIntent.COMPARISON;
        }

        // Root cause queries - why something happened
        if (lowerQuestion.matches(".*(why|cause|reason|spike|surge|sudden).*")) {
            return QueryIntent.ROOT_CAUSE;
        }

        // Impact queries - scope and effect
        if (lowerQuestion.matches(
                ".*(how many|users affected|impact|affected|scope|widespread).*")) {
            return QueryIntent.IMPACT;
        }

        return QueryIntent.GENERAL;
    }

    /** Handle temporal queries like "errors from last Tuesday" */
    private String handleTemporalQuery(String question) {
        logger.info("Handling temporal query: {}", question);

        // Parse time references from the question
        LocalDateTime startTime = parseTemporalReference(question);
        LocalDateTime endTime = LocalDateTime.now();

        // Fetch errors in the time range
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(startTime);

        if (errors.isEmpty()) {
            return String.format(
                    "No errors found in the specified time period (since %s).",
                    startTime.format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")));
        }

        // Build context and generate answer
        String context = buildContextFromErrorLogs(errors);
        String promptText =
                """
            Based on the errors that occurred during the specified time period, answer the user's question.

            Time Period: {startTime} to {endTime}
            Total Errors Found: {count}

            Error Context:
            {context}

            User Question: {question}

            Provide a clear, time-focused analysis of these errors.
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put(
                "startTime", startTime.format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")));
        params.put("endTime", endTime.format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")));
        params.put("count", errors.size());
        params.put("context", context);
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating temporal answer", e);
            return "Unable to analyze temporal data at this time.";
        }
    }

    /** Handle correlation queries like "what errors happen together" */
    private String handleCorrelationQuery(String question) {
        logger.info("Handling correlation query: {}", question);

        // Get recent errors to analyze correlations
        LocalDateTime since = LocalDateTime.now().minusDays(7);
        List<ErrorLog> errors = errorLogRepository.findRecentErrors(since);

        if (errors.size() < 2) {
            return "Not enough error data to identify correlations. Please try again when more errors are available.";
        }

        // Analyze correlations by grouping errors by time windows
        Map<String, List<ErrorLog>> timeWindows = groupErrorsByTimeWindows(errors);

        String context = buildCorrelationContext(timeWindows);
        String promptText =
                """
            Analyze the following errors to identify patterns and correlations.
            Look for errors that tend to occur together or in sequence.

            Error Data:
            {context}

            User Question: {question}

            Provide insights about:
            1. Errors that frequently occur together
            2. Possible causal relationships
            3. Common patterns across correlated errors
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("context", context);
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating correlation answer", e);
            return "Unable to analyze error correlations at this time.";
        }
    }

    /** Handle trending queries like "which errors are increasing" */
    private String handleTrendingQuery(String question) {
        logger.info("Handling trending query: {}", question);

        // Use analytics service to get trend data
        Map<String, Object> trends = errorAnalyticsService.detectTrends("all", 7);

        String promptText =
                """
            Based on the error trend analysis below, answer the user's question about error patterns.

            Trend Analysis:
            {trends}

            User Question: {question}

            Provide insights about:
            1. Which errors are trending up or down
            2. Significant changes in error patterns
            3. Recommendations based on trends
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("trends", formatTrendsForContext(trends));
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating trending answer", e);
            return "Unable to analyze error trends at this time.";
        }
    }

    /** Handle comparison queries like "compare production vs staging" */
    private String handleComparisonQuery(String question) {
        logger.info("Handling comparison query: {}", question);

        // Use analytics service to get comparison data
        Map<String, Object> comparison = errorAnalyticsService.compareEnvironments("all");

        String promptText =
                """
            Based on the environment comparison data below, answer the user's question.

            Environment Comparison:
            {comparison}

            User Question: {question}

            Provide insights about:
            1. Key differences between environments
            2. Environment-specific issues
            3. Recommendations for each environment
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("comparison", formatComparisonForContext(comparison));
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating comparison answer", e);
            return "Unable to compare environments at this time.";
        }
    }

    /** Handle root cause queries like "why did error X spike" */
    private String handleRootCauseQuery(String question) {
        logger.info("Handling root cause query: {}", question);

        // Get relevant errors and trend data
        List<SimilarError> relevantErrors =
                errorSearchService.searchByNaturalLanguage(question, 10);
        Map<String, Object> trends = errorAnalyticsService.detectTrends("all", 7);

        if (relevantErrors.isEmpty()) {
            return "I couldn't find relevant errors to analyze root causes. Please provide more details or check if there are errors in the system.";
        }

        String errorContext = buildContextFromErrors(relevantErrors);
        String trendContext = formatTrendsForContext(trends);

        String promptText =
                """
            Analyze the following error and trend data to identify potential root causes.

            Error Context:
            {errorContext}

            Trend Analysis:
            {trendContext}

            User Question: {question}

            Provide a root cause analysis including:
            1. Most likely root cause(s)
            2. Contributing factors
            3. Evidence from the data
            4. Recommended investigation steps
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("errorContext", errorContext);
        params.put("trendContext", trendContext);
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating root cause answer", e);
            return "Unable to analyze root cause at this time.";
        }
    }

    /** Handle impact queries like "how many users were affected" */
    private String handleImpactQuery(String question) {
        logger.info("Handling impact query: {}", question);

        // Get statistics and relevant errors
        Map<String, Object> stats = errorAnalyticsService.getErrorStatistics("all", 24, 10);
        List<SimilarError> relevantErrors = errorSearchService.searchByNaturalLanguage(question, 5);

        String errorContext = buildContextFromErrors(relevantErrors);

        String promptText =
                """
            Based on the error statistics and context below, assess the impact.

            Statistics (Last 24 hours):
            {stats}

            Error Context:
            {errorContext}

            User Question: {question}

            Provide an impact assessment including:
            1. Scope of impact (number of occurrences, affected systems)
            2. Severity assessment
            3. Estimated user/business impact
            4. Urgency level
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("stats", formatStatsForContext(stats));
        params.put("errorContext", errorContext);
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating impact answer", e);
            return "Unable to assess impact at this time.";
        }
    }

    /** Handle general queries using standard RAG */
    private String handleGeneralQuery(String question) {
        logger.info("Handling general query: {}", question);

        // Use standard RAG approach
        List<SimilarError> relevantErrors = errorSearchService.searchByNaturalLanguage(question, 5);

        if (relevantErrors.isEmpty()) {
            return "I couldn't find any relevant errors to answer your question. Please try rephrasing or check if there are errors in the system.";
        }

        String context = buildContextFromErrors(relevantErrors);
        return generateAnswer(question, context);
    }

    /** Parse temporal references from natural language */
    private LocalDateTime parseTemporalReference(String question) {
        String lowerQuestion = question.toLowerCase();
        LocalDateTime now = LocalDateTime.now();

        if (lowerQuestion.contains("yesterday")) {
            return now.minusDays(1).withHour(0).withMinute(0).withSecond(0);
        }
        if (lowerQuestion.contains("today")) {
            return now.withHour(0).withMinute(0).withSecond(0);
        }
        if (lowerQuestion.contains("last week")) {
            return now.minusWeeks(1)
                    .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                    .withHour(0)
                    .withMinute(0)
                    .withSecond(0);
        }
        if (lowerQuestion.contains("this week")) {
            return now.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                    .withHour(0)
                    .withMinute(0)
                    .withSecond(0);
        }
        if (lowerQuestion.contains("last month")) {
            return now.minusMonths(1).withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
        }

        // Check for specific days of the week
        for (DayOfWeek day : DayOfWeek.values()) {
            if (lowerQuestion.contains("last " + day.name().toLowerCase())) {
                return now.with(TemporalAdjusters.previous(day))
                        .withHour(0)
                        .withMinute(0)
                        .withSecond(0);
            }
        }

        // Default to last 24 hours
        return now.minusDays(1);
    }

    /** Group errors by 1-hour time windows */
    private Map<String, List<ErrorLog>> groupErrorsByTimeWindows(List<ErrorLog> errors) {
        Map<String, List<ErrorLog>> windows = new HashMap<>();

        for (ErrorLog error : errors) {
            String windowKey =
                    error.getOccurredAt()
                            .truncatedTo(java.time.temporal.ChronoUnit.HOURS)
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:00"));
            windows.computeIfAbsent(windowKey, k -> new java.util.ArrayList<>()).add(error);
        }

        return windows;
    }

    /** Build context from ErrorLog entities */
    private String buildContextFromErrorLogs(List<ErrorLog> errors) {
        return errors.stream()
                .limit(20) // Limit to avoid token overflow
                .map(
                        error ->
                                String.format(
                                        """
                    Error ID: %d
                    Application: %s
                    Environment: %s
                    Type: %s
                    Message: %s
                    Severity: %s
                    Occurred At: %s
                    Stack Trace: %s
                    ---
                    """,
                                        error.getId(),
                                        error.getApplicationName(),
                                        error.getEnvironment(),
                                        error.getErrorType(),
                                        error.getErrorMessage(),
                                        error.getSeverity(),
                                        error.getOccurredAt(),
                                        truncate(error.getStackTrace(), 300)))
                .collect(Collectors.joining("\n"));
    }

    /** Build correlation context from time-windowed errors */
    private String buildCorrelationContext(Map<String, List<ErrorLog>> timeWindows) {
        StringBuilder sb = new StringBuilder();

        timeWindows.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .limit(10) // Limit to most recent windows
                .forEach(
                        entry -> {
                            sb.append(String.format("Time Window: %s\n", entry.getKey()));
                            sb.append(String.format("Error Count: %d\n", entry.getValue().size()));
                            sb.append("Error Types: ");
                            sb.append(
                                    entry.getValue().stream()
                                            .map(ErrorLog::getErrorType)
                                            .distinct()
                                            .collect(Collectors.joining(", ")));
                            sb.append("\n---\n");
                        });

        return sb.toString();
    }

    /** Format trends data for context */
    private String formatTrendsForContext(Map<String, Object> trends) {
        StringBuilder sb = new StringBuilder();

        sb.append("Average Errors per Day: ")
                .append(trends.get("averageErrorsPerDay"))
                .append("\n");
        sb.append("Total Errors: ").append(trends.get("totalErrors")).append("\n");
        sb.append("Spike Days: ").append(trends.get("spikeDays")).append("\n");
        sb.append("New Error Types: ").append(trends.get("newErrorTypes")).append("\n");

        return sb.toString();
    }

    /** Format comparison data for context */
    private String formatComparisonForContext(Map<String, Object> comparison) {
        StringBuilder sb = new StringBuilder();

        @SuppressWarnings("unchecked")
        Map<String, Integer> envCounts =
                (Map<String, Integer>) comparison.get("errorsByEnvironment");
        if (envCounts != null) {
            sb.append("Errors by Environment:\n");
            envCounts.forEach((env, count) -> sb.append(String.format("  %s: %d\n", env, count)));
        }

        return sb.toString();
    }

    /** Format statistics for context */
    private String formatStatsForContext(Map<String, Object> stats) {
        StringBuilder sb = new StringBuilder();

        sb.append("Total Errors: ").append(stats.get("totalErrors")).append("\n");
        sb.append("Critical: ").append(stats.get("criticalCount")).append("\n");
        sb.append("Error: ").append(stats.get("errorCount")).append("\n");
        sb.append("Warning: ").append(stats.get("warningCount")).append("\n");

        return sb.toString();
    }

    private String buildContextFromErrors(List<SimilarError> errors) {
        return errors.stream()
                .map(
                        se -> {
                            var error = se.getErrorLog();
                            return String.format(
                                    """
                    Error ID: %d
                    Application: %s
                    Environment: %s
                    Type: %s
                    Message: %s
                    Severity: %s
                    Occurred At: %s
                    Stack Trace: %s
                    ---
                    """,
                                    error.getId(),
                                    error.getApplicationName(),
                                    error.getEnvironment(),
                                    error.getErrorType(),
                                    error.getErrorMessage(),
                                    error.getSeverity(),
                                    error.getOccurredAt(),
                                    truncate(error.getStackTrace(), 500));
                        })
                .collect(Collectors.joining("\n"));
    }

    private String generateAnswer(String question, String context) {
        String promptText =
                """
            You are an expert software engineer helping to analyze production errors.
            Answer the user's question based on the error information provided.

            Error Context:
            {context}

            User Question: {question}

            Provide a clear, accurate, and actionable answer. If the context doesn't contain enough information to fully answer the question, say so and provide what information you can.
            """;

        PromptTemplate promptTemplate = new PromptTemplate(promptText);
        Map<String, Object> params = new HashMap<>();
        params.put("context", context);
        params.put("question", question);

        Prompt prompt = promptTemplate.create(params);

        try {
            return chatClient.prompt(prompt).call().content();
        } catch (Exception e) {
            logger.error("Error generating answer", e);
            return "I encountered an error while processing your question. Please try again.";
        }
    }

    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength) + "...";
    }
}
