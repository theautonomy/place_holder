package com.example.demo.config;

import java.util.List;

import com.example.demo.model.ErrorLog;
import com.example.demo.model.ErrorLogDocument;
import com.example.demo.repository.ErrorLogMongoRepository;
import com.example.demo.repository.ErrorLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

@Configuration
public class MongoToPostgresImporter {

    private static final Logger logger = LoggerFactory.getLogger(MongoToPostgresImporter.class);

    @Bean
    @Order(2) // Run after MongoDataInitializer (which is Order 1 by default)
    CommandLineRunner importMongoToPostgres(
            ErrorLogMongoRepository mongoRepository,
            ErrorLogRepository postgresRepository,
            EmbeddingModel embeddingModel) {
        return args -> {
            logger.info("=== Starting MongoDB to PostgreSQL Import ===");

            // Get all errors from MongoDB
            List<ErrorLogDocument> mongoErrors = mongoRepository.findAll();
            logger.info("Found {} errors in MongoDB to import", mongoErrors.size());

            if (mongoErrors.isEmpty()) {
                logger.info("No errors to import from MongoDB");
                return;
            }

            int successCount = 0;
            int errorCount = 0;
            long startTime = System.currentTimeMillis();

            for (ErrorLogDocument mongoError : mongoErrors) {
                try {
                    // Convert MongoDB document to PostgreSQL entity
                    ErrorLog postgresError = new ErrorLog();
                    postgresError.setApplicationName(mongoError.getApplicationName());
                    postgresError.setEnvironment(mongoError.getEnvironment());
                    postgresError.setErrorType(mongoError.getErrorType());
                    postgresError.setErrorMessage(mongoError.getErrorMessage());
                    postgresError.setStackTrace(mongoError.getStackTrace());
                    postgresError.setSeverity(mongoError.getSeverity());
                    postgresError.setStatus(mongoError.getStatus());
                    postgresError.setOccurredAt(mongoError.getOccurredAt());

                    // Generate and store embedding from stack trace
                    logger.debug(
                            "Generating embedding for error: {} - {}",
                            mongoError.getErrorType(),
                            mongoError.getErrorMessage());
                    float[] embedding = embeddingModel.embed(mongoError.getStackTrace());
                    postgresError.setEmbedding(embedding);

                    // Save to PostgreSQL
                    postgresRepository.save(postgresError);
                    successCount++;

                    if (successCount % 10 == 0) {
                        logger.info("Progress: {} errors imported...", successCount);
                    }

                } catch (Exception e) {
                    errorCount++;
                    logger.error(
                            "Failed to import error {} ({}): {}",
                            mongoError.getId(),
                            mongoError.getErrorType(),
                            e.getMessage());
                }
            }

            long elapsed = System.currentTimeMillis() - startTime;
            double rate = successCount / (elapsed / 1000.0);

            logger.info("=== Import Completed ===");
            logger.info("Total MongoDB errors: {}", mongoErrors.size());
            logger.info("Successfully imported: {}", successCount);
            logger.info("Failed: {}", errorCount);
            logger.info(
                    "Time elapsed: {} ms ({} errors/sec)", elapsed, String.format("%.2f", rate));
            logger.info("Total PostgreSQL errors: {}", postgresRepository.count());
            logger.info("========================");
        };
    }
}
