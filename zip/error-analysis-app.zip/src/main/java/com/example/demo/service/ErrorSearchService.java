package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.model.ErrorLog;
import com.example.demo.model.SimilarError;
import com.example.demo.repository.ErrorLogRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@Service
public class ErrorSearchService {

    private static final Logger logger = LoggerFactory.getLogger(ErrorSearchService.class);

    private final EntityManager entityManager;
    private final EmbeddingModel embeddingModel;
    private final ErrorLogRepository errorLogRepository;

    public ErrorSearchService(
            EntityManager entityManager,
            EmbeddingModel embeddingModel,
            ErrorLogRepository errorLogRepository) {
        this.entityManager = entityManager;
        this.embeddingModel = embeddingModel;
        this.errorLogRepository = errorLogRepository;
    }

    /** Find similar errors using semantic search */
    public List<SimilarError> findSimilarErrors(
            String queryText, int topK, double similarityThreshold) {
        logger.info("Searching for similar errors with query: {}", queryText);

        try {
            // Generate embedding for the query
            float[] queryEmbedding = embeddingModel.embed(queryText);

            // Convert float array to PostgreSQL vector string format
            String vectorStr = convertToVectorString(queryEmbedding);

            // Perform cosine similarity search
            String sql =
                    """
                SELECT id, (1 - (embedding <=> CAST(:queryVector AS vector))) AS similarity
                FROM error_logs
                WHERE embedding IS NOT NULL
                AND (1 - (embedding <=> CAST(:queryVector AS vector))) >= :threshold
                ORDER BY similarity DESC
                LIMIT :topK
                """;

            Query query = entityManager.createNativeQuery(sql);
            query.setParameter("queryVector", vectorStr);
            query.setParameter("threshold", similarityThreshold);
            query.setParameter("topK", topK);

            @SuppressWarnings("unchecked")
            List<Object[]> results = query.getResultList();

            List<SimilarError> similarErrors = new ArrayList<>();
            for (Object[] row : results) {
                Long errorId = ((Number) row[0]).longValue();
                Double similarity = ((Number) row[1]).doubleValue();

                ErrorLog errorLog = errorLogRepository.findById(errorId).orElse(null);
                if (errorLog != null) {
                    similarErrors.add(new SimilarError(errorLog, similarity));
                }
            }

            logger.info("Found {} similar errors", similarErrors.size());
            return similarErrors;

        } catch (Exception e) {
            logger.error("Error performing similarity search", e);
            return new ArrayList<>();
        }
    }

    /** Find errors similar to a specific error */
    public List<SimilarError> findSimilarToError(Long errorLogId, int topK) {
        logger.info("Finding errors similar to error ID: {}", errorLogId);

        ErrorLog errorLog =
                errorLogRepository
                        .findById(errorLogId)
                        .orElseThrow(() -> new RuntimeException("Error not found: " + errorLogId));

        if (errorLog.getEmbedding() == null) {
            logger.warn("Error {} has no embedding", errorLogId);
            return new ArrayList<>();
        }

        try {
            // Use the error's embedding for similarity search
            String vectorStr = convertToVectorString(errorLog.getEmbedding());

            String sql =
                    """
                SELECT id, (1 - (embedding <=> CAST(:queryVector AS vector))) AS similarity
                FROM error_logs
                WHERE embedding IS NOT NULL
                AND id != :excludeId
                ORDER BY similarity DESC
                LIMIT :topK
                """;

            Query query = entityManager.createNativeQuery(sql);
            query.setParameter("queryVector", vectorStr);
            query.setParameter("excludeId", errorLogId);
            query.setParameter("topK", topK);

            @SuppressWarnings("unchecked")
            List<Object[]> results = query.getResultList();

            List<SimilarError> similarErrors = new ArrayList<>();
            for (Object[] row : results) {
                Long id = ((Number) row[0]).longValue();
                Double similarity = ((Number) row[1]).doubleValue();

                ErrorLog similar = errorLogRepository.findById(id).orElse(null);
                if (similar != null) {
                    similarErrors.add(new SimilarError(similar, similarity));
                }
            }

            logger.info("Found {} similar errors to error {}", similarErrors.size(), errorLogId);
            return similarErrors;

        } catch (Exception e) {
            logger.error("Error finding similar errors", e);
            return new ArrayList<>();
        }
    }

    /** Search errors by natural language query */
    public List<SimilarError> searchByNaturalLanguage(String query, int topK) {
        logger.info("Natural language search: {}", query);
        return findSimilarErrors(query, topK, 0.6);
    }

    /** Search errors by error message or stack trace snippet */
    public List<SimilarError> searchByErrorDetails(
            String errorMessage, String stackTraceSnippet, int topK) {
        StringBuilder query = new StringBuilder();
        if (errorMessage != null && !errorMessage.isEmpty()) {
            query.append("Error Message: ").append(errorMessage).append("\n");
        }
        if (stackTraceSnippet != null && !stackTraceSnippet.isEmpty()) {
            query.append("Stack Trace: ").append(stackTraceSnippet);
        }

        return findSimilarErrors(query.toString(), topK, 0.7);
    }

    /** Convert float array to PostgreSQL vector string format */
    private String convertToVectorString(float[] embedding) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < embedding.length; i++) {
            if (i > 0) sb.append(",");
            sb.append(embedding[i]);
        }
        sb.append("]");
        return sb.toString();
    }
}
