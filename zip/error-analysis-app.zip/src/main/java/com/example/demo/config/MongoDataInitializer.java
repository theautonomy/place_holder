package com.example.demo.config;

import java.time.LocalDateTime;

import com.example.demo.model.ErrorLogDocument;
import com.example.demo.repository.ErrorLogMongoRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.data.mongodb.core.MongoTemplate;

// @Configuration
public class MongoDataInitializer {

    @Bean
    @Order(1) // Run before MongoToPostgresImporter
    CommandLineRunner initMongoDatabase(
            ErrorLogMongoRepository repository, MongoTemplate mongoTemplate) {
        return args -> {
            // Log MongoDB connection details
            String databaseName = mongoTemplate.getDb().getName();
            System.out.println("=== MongoDB Connection Info ===");
            System.out.println("Connected to database: " + databaseName);
            System.out.println("Collection count before: " + repository.count());
            System.out.println("===============================");

            // Clear existing data (optional - comment out if you want to keep existing data)
            repository.deleteAll();
            System.out.println("Cleared existing MongoDB error_logs collection");

            // Create test error logs
            ErrorLogDocument error1 =
                    new ErrorLogDocument(
                            "demo-app",
                            "production",
                            "NullPointerException",
                            "Object reference not set to an instance of an object",
                            "java.lang.NullPointerException\n\tat com.example.demo.service.UserService.getUser(UserService.java:45)\n\tat com.example.demo.controller.UserController.getUserById(UserController.java:32)",
                            "ERROR",
                            "OPEN");
            error1.setOccurredAt(LocalDateTime.now().minusHours(2));

            ErrorLogDocument error2 =
                    new ErrorLogDocument(
                            "demo-app",
                            "production",
                            "IllegalArgumentException",
                            "Invalid user ID format",
                            "java.lang.IllegalArgumentException: Invalid user ID format\n\tat com.example.demo.service.UserService.validateUserId(UserService.java:67)\n\tat com.example.demo.service.UserService.getUser(UserService.java:42)",
                            "WARNING",
                            "OPEN");
            error2.setOccurredAt(LocalDateTime.now().minusHours(1));

            ErrorLogDocument error3 =
                    new ErrorLogDocument(
                            "demo-app",
                            "staging",
                            "SQLException",
                            "Connection timeout to database",
                            "java.sql.SQLException: Connection timeout\n\tat com.example.demo.repository.UserRepository.findById(UserRepository.java:23)\n\tat com.example.demo.service.UserService.getUser(UserService.java:43)",
                            "CRITICAL",
                            "OPEN");
            error3.setOccurredAt(LocalDateTime.now().minusMinutes(30));

            ErrorLogDocument error4 =
                    new ErrorLogDocument(
                            "demo-app",
                            "production",
                            "FileNotFoundException",
                            "Configuration file not found: /etc/app/config.yml",
                            "java.io.FileNotFoundException: /etc/app/config.yml\n\tat com.example.demo.config.ConfigLoader.loadConfig(ConfigLoader.java:28)\n\tat com.example.demo.Application.main(Application.java:15)",
                            "ERROR",
                            "RESOLVED");
            error4.setOccurredAt(LocalDateTime.now().minusDays(1));

            ErrorLogDocument error5 =
                    new ErrorLogDocument(
                            "demo-app",
                            "production",
                            "OutOfMemoryError",
                            "Java heap space",
                            "java.lang.OutOfMemoryError: Java heap space\n\tat java.util.Arrays.copyOf(Arrays.java:3332)\n\tat com.example.demo.service.DataProcessor.processLargeDataset(DataProcessor.java:89)",
                            "CRITICAL",
                            "OPEN");
            error5.setOccurredAt(LocalDateTime.now().minusMinutes(15));

            ErrorLogDocument error6 =
                    new ErrorLogDocument(
                            "payment-service",
                            "production",
                            "PaymentException",
                            "Payment gateway timeout",
                            "com.example.payment.PaymentException: Gateway timeout\n\tat com.example.payment.service.PaymentService.processPayment(PaymentService.java:102)\n\tat com.example.payment.controller.PaymentController.charge(PaymentController.java:45)",
                            "ERROR",
                            "OPEN");
            error6.setOccurredAt(LocalDateTime.now().minusMinutes(45));

            // Save all test errors
            ErrorLogDocument saved1 = repository.save(error1);
            ErrorLogDocument saved2 = repository.save(error2);
            ErrorLogDocument saved3 = repository.save(error3);
            ErrorLogDocument saved4 = repository.save(error4);
            ErrorLogDocument saved5 = repository.save(error5);
            ErrorLogDocument saved6 = repository.save(error6);

            System.out.println("Saved error 1 with ID: " + saved1.getId());
            System.out.println("Saved error 2 with ID: " + saved2.getId());
            System.out.println("Saved error 3 with ID: " + saved3.getId());
            System.out.println("Saved error 4 with ID: " + saved4.getId());
            System.out.println("Saved error 5 with ID: " + saved5.getId());
            System.out.println("Saved error 6 with ID: " + saved6.getId());

            long count = repository.count();
            System.out.println("Total documents in collection: " + count);
            System.out.println("Inserted " + count + " test error logs into MongoDB");
            System.out.println("MongoDB error_logs collection initialized successfully!");

            // Verify by reading back
            System.out.println("\n=== Verification: Reading back from MongoDB ===");
            repository
                    .findAll()
                    .forEach(
                            error -> {
                                System.out.println(
                                        "ID: "
                                                + error.getId()
                                                + ", Type: "
                                                + error.getErrorType()
                                                + ", Message: "
                                                + error.getErrorMessage());
                            });
        };
    }
}
