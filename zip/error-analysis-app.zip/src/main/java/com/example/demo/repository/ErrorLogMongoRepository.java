package com.example.demo.repository;

import java.time.LocalDateTime;
import java.util.List;

import com.example.demo.model.ErrorLogDocument;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ErrorLogMongoRepository extends MongoRepository<ErrorLogDocument, String> {

    @Query("{ 'occurred_at': { $gte: ?0 } }")
    List<ErrorLogDocument> findRecentErrors(LocalDateTime since);

    List<ErrorLogDocument> findAllByOrderByOccurredAtDesc();

    List<ErrorLogDocument> findByStatusOrderByOccurredAtDesc(String status);

    List<ErrorLogDocument> findByApplicationNameAndOccurredAtAfter(
            String applicationName, LocalDateTime since);

    List<ErrorLogDocument> findByApplicationName(String applicationName);

    List<ErrorLogDocument> findByErrorType(String errorType);

    List<ErrorLogDocument> findByApplicationNameOrderByOccurredAtDesc(String applicationName);

    List<ErrorLogDocument> findByErrorTypeAndErrorMessageAndApplicationNameAndEnvironment(
            String errorType, String errorMessage, String applicationName, String environment);

    List<ErrorLogDocument> findByApplicationNameAndOccurredAtBetween(
            String applicationName, LocalDateTime start, LocalDateTime end);
}
