package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import com.example.demo.model.ErrorLogDocument;
import com.example.demo.repository.ErrorLogMongoRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class MongoErrorService {

    private static final Logger logger = LoggerFactory.getLogger(MongoErrorService.class);

    private final ErrorLogMongoRepository errorLogMongoRepository;

    public MongoErrorService(ErrorLogMongoRepository errorLogMongoRepository) {
        this.errorLogMongoRepository = errorLogMongoRepository;
    }

    /** Generate a random test error with timestamp in the past 30 days */
    public ErrorLogDocument generateRandomTestError() {
        Random random = new Random();

        // Random application names
        String[] apps = new String[] {"demo-app", "user-service", "payment-service", "api-gateway"};
        String applicationName = apps[random.nextInt(apps.length)];

        // Random environments
        String[] envs = new String[] {"production", "staging", "development"};
        String environment = envs[random.nextInt(envs.length)];

        // Random error types
        String[] errorTypes =
                new String[] {
                    "NullPointerException",
                    "SQLException",
                    "TimeoutException",
                    "IllegalArgumentException",
                    "IOException",
                    "AuthenticationException",
                    "OutOfMemoryError",
                    "ConcurrentModificationException",
                    "ClassCastException",
                    "ArrayIndexOutOfBoundsException"
                };
        String errorType = errorTypes[random.nextInt(errorTypes.length)];

        // Random error messages
        String[] messages =
                new String[] {
                    "Cannot invoke method on null object",
                    "Connection timeout to database",
                    "Request timeout",
                    "Invalid user input",
                    "File not found",
                    "Invalid credentials",
                    "Java heap space",
                    "Deadlock detected in transaction",
                    "API call timed out after 30 seconds",
                    "Email format is invalid",
                    "Unable to write to disk",
                    "Session expired",
                    "GC overhead limit exceeded",
                    "Connection pool exhausted",
                    "Resource not found",
                    "Permission denied"
                };
        String errorMessage = messages[random.nextInt(messages.length)];

        // Random severities
        String[] severities = new String[] {"CRITICAL", "ERROR", "WARNING"};
        String severity = severities[random.nextInt(severities.length)];

        // Random statuses
        String[] statuses = new String[] {"OPEN", "IN_PROGRESS", "RESOLVED", "CLOSED"};
        String status = statuses[random.nextInt(statuses.length)];

        // Generate stack trace
        String stackTrace =
                errorType
                        + ": "
                        + errorMessage
                        + "\n\tat com.example.demo.service.UserService.processUser(UserService.java:"
                        + (10 + random.nextInt(200))
                        + ")\n\tat com.example.demo.controller.UserController.handleRequest(UserController.java:"
                        + (10 + random.nextInt(100))
                        + ")\n\tat org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:123)";

        // Create error log document
        ErrorLogDocument errorLog =
                new ErrorLogDocument(
                        applicationName,
                        environment,
                        errorType,
                        errorMessage,
                        stackTrace,
                        severity,
                        status);

        // Generate random timestamp in the past 30 days
        long thirtyDaysInSeconds = 30L * 24 * 60 * 60;
        long randomSeconds = (long) (random.nextDouble() * thirtyDaysInSeconds);
        LocalDateTime randomTimestamp = LocalDateTime.now().minusSeconds(randomSeconds);
        errorLog.setOccurredAt(randomTimestamp);

        // Save to MongoDB
        errorLog = errorLogMongoRepository.save(errorLog);

        logger.info(
                "Generated random test error: id={}, type={}, occurredAt={}",
                errorLog.getId(),
                errorLog.getErrorType(),
                errorLog.getOccurredAt());

        return errorLog;
    }

    public List<ErrorLogDocument> getAllErrors() {
        return errorLogMongoRepository.findAll();
    }

    public Optional<ErrorLogDocument> getErrorById(String id) {
        return errorLogMongoRepository.findById(id);
    }

    public List<ErrorLogDocument> getRecentErrors(int hours) {
        LocalDateTime since = LocalDateTime.now().minusHours(hours);
        return errorLogMongoRepository.findRecentErrors(since);
    }

    public long getErrorCount() {
        return errorLogMongoRepository.count();
    }
}
