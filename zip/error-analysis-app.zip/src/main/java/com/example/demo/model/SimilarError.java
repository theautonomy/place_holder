package com.example.demo.model;

public class SimilarError {
    private ErrorLog errorLog;
    private double similarityScore;

    public SimilarError(ErrorLog errorLog, double similarityScore) {
        this.errorLog = errorLog;
        this.similarityScore = similarityScore;
    }

    public ErrorLog getErrorLog() {
        return errorLog;
    }

    public void setErrorLog(ErrorLog errorLog) {
        this.errorLog = errorLog;
    }

    public double getSimilarityScore() {
        return similarityScore;
    }

    public void setSimilarityScore(double similarityScore) {
        this.similarityScore = similarityScore;
    }
}
