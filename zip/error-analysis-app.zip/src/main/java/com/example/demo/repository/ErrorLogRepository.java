package com.example.demo.repository;

import java.time.LocalDateTime;
import java.util.List;

import com.example.demo.model.ErrorLog;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ErrorLogRepository extends JpaRepository<ErrorLog, Long> {

    @Query("SELECT e FROM ErrorLog e WHERE e.occurredAt >= :since ORDER BY e.occurredAt DESC")
    List<ErrorLog> findRecentErrors(@Param("since") LocalDateTime since);

    @Query("SELECT e FROM ErrorLog e ORDER BY e.occurredAt DESC")
    List<ErrorLog> findAllByOccurredAtDesc();

    @Query("SELECT e FROM ErrorLog e WHERE e.status = :status ORDER BY e.occurredAt DESC")
    List<ErrorLog> findByStatus(@Param("status") String status);

    @Query("SELECT e FROM ErrorLog e WHERE e.applicationName = :appName AND e.occurredAt >= :since")
    List<ErrorLog> findByApplicationNameAndOccurredAtAfter(
            @Param("appName") String applicationName, @Param("since") LocalDateTime since);

    @Query("SELECT e FROM ErrorLog e WHERE e.applicationName = :appName")
    List<ErrorLog> findByApplicationName(@Param("appName") String applicationName);

    @Query(
            "SELECT e.severity as severity, COUNT(e) as count FROM ErrorLog e WHERE e.applicationName = :appName GROUP BY e.severity")
    List<Object[]> countBySeverity(@Param("appName") String applicationName);

    @Query("SELECT e FROM ErrorLog e WHERE e.applicationName = :appName ORDER BY e.occurredAt DESC")
    List<ErrorLog> findTopErrorsByOccurrence(@Param("appName") String applicationName);

    @Query(
            "SELECT e FROM ErrorLog e WHERE e.errorType = :errorType AND e.errorMessage = :errorMessage AND e.applicationName = :appName AND e.environment = :env")
    List<ErrorLog> findByErrorTypeAndMessageAndApplicationAndEnvironment(
            @Param("errorType") String errorType,
            @Param("errorMessage") String errorMessage,
            @Param("appName") String applicationName,
            @Param("env") String environment);

    @Query("SELECT e FROM ErrorLog e WHERE e.errorType = :errorType")
    List<ErrorLog> findByErrorType(@Param("errorType") String errorType);

    @Query(
            "SELECT e FROM ErrorLog e WHERE e.applicationName = :appName AND e.occurredAt BETWEEN :start AND :end ORDER BY e.occurredAt DESC")
    List<ErrorLog> findByApplicationNameAndOccurredAtBetween(
            @Param("appName") String applicationName,
            @Param("start") LocalDateTime start,
            @Param("end") LocalDateTime end);
}
