#!/usr/bin/env python3
"""
Script to generate random test errors in MongoDB using the REST API endpoint.
Each error will have a random timestamp within the past 30 days.

Usage:
    python generate_mongo_errors.py              # Generate 1000 errors (default)
    python generate_mongo_errors.py 500          # Generate 500 errors
    python generate_mongo_errors.py 5000 -b 100  # Generate 5000 errors, batch size 100
"""

import argparse
import requests
import time
from datetime import datetime

# Configuration
API_URL = "http://localhost:8080/api/mongo/errors/test/random"

def generate_errors(total_errors, batch_size):
    """Generate random test errors by calling the MongoDB API endpoint."""
    print(f"Starting to generate {total_errors} random test errors in MongoDB...")
    print(f"API endpoint: {API_URL}")
    print(f"Batch size: {batch_size}")
    print("-" * 60)

    success_count = 0
    error_count = 0
    start_time = time.time()

    for i in range(1, total_errors + 1):
        try:
            response = requests.post(API_URL, timeout=10)

            if response.status_code == 200:
                success_count += 1
                data = response.json()

                # Show progress every batch_size errors
                if i % batch_size == 0:
                    elapsed = time.time() - start_time
                    rate = i / elapsed
                    print(f"Progress: {i}/{total_errors} errors generated "
                          f"({success_count} successful, {error_count} failed) "
                          f"- {rate:.1f} errors/sec")
            else:
                error_count += 1
                print(f"Error at #{i}: HTTP {response.status_code} - {response.text}")

        except requests.exceptions.RequestException as e:
            error_count += 1
            print(f"Request error at #{i}: {e}")
        except Exception as e:
            error_count += 1
            print(f"Unexpected error at #{i}: {e}")

    # Final summary
    elapsed = time.time() - start_time
    print("-" * 60)
    print(f"Completed in {elapsed:.2f} seconds")
    print(f"Total: {total_errors} requests")
    print(f"Successful: {success_count}")
    print(f"Failed: {error_count}")
    print(f"Average rate: {total_errors / elapsed:.1f} errors/sec")

if __name__ == "__main__":
    # Set up argument parser
    parser = argparse.ArgumentParser(
        description="Generate random test errors in MongoDB using the REST API endpoint.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s              Generate 1000 errors (default)
  %(prog)s 500          Generate 500 errors
  %(prog)s 5000 -b 100  Generate 5000 errors with batch size 100
        """
    )

    parser.add_argument(
        'count',
        type=int,
        nargs='?',
        default=1000,
        help='Number of errors to generate (default: 1000)'
    )

    parser.add_argument(
        '-b', '--batch-size',
        type=int,
        default=50,
        help='Number of errors to generate before showing progress (default: 50)'
    )

    args = parser.parse_args()

    # Validate arguments
    if args.count <= 0:
        parser.error("Error count must be positive")
    if args.batch_size <= 0:
        parser.error("Batch size must be positive")

    # Run the script
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Starting MongoDB error generation")
    generate_errors(args.count, args.batch_size)
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Done!")
