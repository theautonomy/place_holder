<!-- pages: 1 -->
<!-- slug: vscode -->
# VS Code Shortcuts

My custom keybindings, plus the defaults I still use. Most custom keys are a chord: hold `Alt` and tap the same letter twice (`Alt+F Alt+F`), usually the first letter of what it opens. Windows / Linux keys; on macOS `Ctrl` is `Cmd` for the defaults.

## Find & navigate (custom)

| Keys | What it does | Replaces |
|---|---|---|
| `Alt+F Alt+F` | Go to file (Quick Open) | `Ctrl+P` |
| `Ctrl+P Ctrl+P` | Command Palette | `Ctrl+Shift+P` |
| `Alt+S Alt+S` | Search in files | `Ctrl+Shift+F` |
| `Alt+O Alt+O` | Outline view | — |
| `Alt+L Alt+L` | Last edit location | `Ctrl+K Ctrl+Q` |
| `Alt+D Alt+D` | Go to type definition | `Ctrl+K F12` |

## Views & layout (custom)

| Keys | What it does | Replaces |
|---|---|---|
| `Alt+E Alt+E` | Explorer | `Ctrl+Shift+E` |
| `Alt+G Alt+G` | Source Control | — |
| `Alt+P Alt+P` | Problems | `Ctrl+Shift+M` |
| `Alt+S Alt+B` | Spring Boot beans | — |
| `Alt+B Alt+B` | Toggle primary sidebar | `Ctrl+B` |
| `Alt+H Alt+H` | Toggle secondary sidebar | `Ctrl+Alt+B` |
| `Alt+A Alt+I` | Chat in the sidebar | — |
| `Alt+W Alt+W` | Full screen | `F11` |

## Edit & code (custom)

| Keys | What it does | Replaces |
|---|---|---|
| `Alt+. Alt+.` | Quick fix | `Ctrl+.` |
| `Alt+C Alt+C` | Source action (imports, generate) | `Alt+Insert` |
| `Alt+M Alt+M` | Editor context menu | `Shift+F10` |
| `Alt+T Alt+T` | Run the test at the cursor | `Ctrl+; C` |
| `Alt+A Alt+A` | Save all | `Ctrl+K S` |
| `Alt+Z Alt+Z` | Close all editors | `Ctrl+K Ctrl+Shift+W` |

## Terminal (custom)

| Keys | What it does |
|---|---|
| `Shift+Enter` | Send `\` + newline: a line break without running (multi-line input in Claude Code and shells) |

## Notes on the custom set

- The old keys in **Replaces** are unbound, so they do nothing now.
- `Ctrl+P` is now the start of a chord: VS Code waits for a second key after it.
- `Alt+D Alt+D` is bound twice, to *reveal definition aside* and *go to type definition*. The later entry wins, so it goes to the type definition.
- `Alt+H Alt+H` is also bound twice (close / toggle secondary sidebar); toggle wins.
- `Alt+P Alt+P` only fires when the Problems view is already active (its `when` clause was copied from the default).
- `Ctrl+W` no longer restores a maximized secondary sidebar; it just closes the editor.
- Edit them: `Ctrl+K Ctrl+S`, then the file icon at the top right opens `keybindings.json`.

## Editing (defaults)

| Keys | What it does |
|---|---|
| `Ctrl+D` | Select next match |
| `Ctrl+Shift+L` | Select all matches |
| `Alt+Click` | Add a cursor |
| `Ctrl+Alt+↑` / `↓` | Cursor above / below |
| `Shift+Alt+Drag` | Column select |
| `Ctrl+U` | Undo last cursor |
| `Alt+↑` / `↓` | Move line |
| `Shift+Alt+↑` / `↓` | Copy line |
| `Ctrl+Shift+K` | Delete line |
| `Ctrl+Enter` | Insert line below |
| `Ctrl+L` | Select line |
| `Shift+Alt+→` / `←` | Expand / shrink selection |
| `Ctrl+/` | Toggle line comment |
| `Shift+Alt+A` | Block comment |
| `Shift+Alt+F` | Format document |
| `Ctrl+Space` | Suggestions |
| `Ctrl+Shift+Space` | Parameter hints |
| `F2` | Rename symbol |
| `Ctrl+H` | Replace |
| `Ctrl+Shift+\` | Jump to matching bracket |
| `Ctrl+Shift+[` / `]` | Fold / unfold |
| `Ctrl+K Ctrl+0` / `J` | Fold / unfold all |

## Code navigation (defaults)

| Keys | What it does |
|---|---|
| `F12` | Go to definition |
| `Alt+F12` | Peek definition |
| `Ctrl+F12` | Go to implementation |
| `Shift+F12` | Find references |
| `Shift+Alt+H` | Call hierarchy |
| `Ctrl+Shift+O` | Symbol in file |
| `Ctrl+T` | Symbol in workspace |
| `Ctrl+G` | Go to line |
| `Alt+←` / `→` | Back / forward |
| `F8` / `Shift+F8` | Next / previous problem |
| `Ctrl+K Ctrl+I` | Show hover |

## Editors & windows (defaults)

| Keys | What it does |
|---|---|
| `Ctrl+Tab` | Switch editor |
| `Ctrl+W` | Close editor |
| `Ctrl+Shift+T` | Reopen closed editor |
| `Ctrl+\` | Split editor |
| `Ctrl+1` / `2` / `3` | Focus editor group |
| `Ctrl+K ←` / `→` | Move to group |
| `Ctrl+J` | Toggle bottom panel |
| ``Ctrl+` `` | Toggle terminal |
| ``Ctrl+Shift+` `` | New terminal |
| `Ctrl+Shift+X` | Extensions |
| `Ctrl+Shift+D` | Run and Debug |
| `Ctrl+,` | Settings |
| `Ctrl+K Ctrl+S` | Keyboard shortcuts |
| `Ctrl+K Z` | Zen mode |
| `Ctrl+K V` | Markdown preview to the side |
| `Ctrl+K M` | Change language mode |
| `Ctrl+=` / `Ctrl+-` | Zoom in / out |

## Debug (defaults)

| Keys | What it does |
|---|---|
| `F5` | Start / continue |
| `Shift+F5` | Stop |
| `Ctrl+Shift+F5` | Restart |
| `F9` | Toggle breakpoint |
| `F10` / `F11` | Step over / into |
| `Shift+F11` | Step out |
