<!-- pages: 2 -->
<!-- slug: shell -->
# Unix Shell Cheat Sheet

Everyday commands for developers. `f` = a file, `url` = a URL. GNU flags; on macOS use `sed -i ''`.

## find

| Command | What it does |
|---|---|
| `find . -name '*.js'` | By name |
| `find . -iname '*.log'` | Ignore case |
| `find . -type d` | Directories only |
| `find . -type f` | Files only |
| `find . -size +100M` | Over 100 MB |
| `find . -mtime -7` | Changed ≤ 7 days |
| `find . -atime +30` | Unread 30+ days |
| `... -delete` | Delete matches |
| `... -exec cmd {} \;` | Run per file |
| `... -exec cmd {} +` | Run on batches |

```bash
find . -name '*.tmp' -delete
find . -name '*.log' -exec gzip {} \;
find . -name '*.js' -exec grep -l TODO {} +
# skip a dir; either extension; combine tests
find . -name '*.js' -not -path '*/node_modules/*'
find . \( -name '*.js' -o -name '*.ts' \)
find . -name '*.py' -size +1k -mtime -30
```

## grep

| Command | What it does |
|---|---|
| `grep -i err f` | Ignore case |
| `grep -v debug f` | Exclude matches |
| `grep -n fn f` | Line numbers |
| `grep -c err f` | Count lines |
| `grep -l class *.py` | File names only |
| `grep -r TODO src/` | Recursive |
| `grep '^Error' f` | Starts with |
| `grep 'Error$' f` | Ends with |
| `grep '[0-9]\{3\}' f` | Three digits |
| `grep -E 'err\|warn' f` | Regex OR |
| `grep -A 3 err f` | 3 lines after |
| `grep -B 2 err f` | 2 lines before |
| `grep -C 2 err f` | 2 lines around |
| `ag TODO` | Faster, skips .gitignore'd |

```bash
grep -r import --include='*.js' .
grep --color=always err f | less -R
```

## sed

| Command | What it does |
|---|---|
| `sed 's/a/b/' f` | Replace first per line |
| `sed 's/a/b/g' f` | Replace all |
| `sed -i 's/a/b/g' f` | Edit in place |
| `sed '5d' f` | Delete line 5 |
| `sed '2,5d' f` | Delete lines 2–5 |
| `sed -n '10,20p' f` | Print lines 10–20 |
| `sed '/re/d' f` | Delete matching lines |
| `sed '/^$/d' f` | Drop blank lines |
| `sed '/^#/d' f` | Drop comment lines |
| `sed 's/.*ERR.*/X/' f` | Replace whole line |

```bash
sed 's/\([0-9]\+\)/[\1]/g' f     # [42]: wrap numbers
find . -name '*.js' -exec sed -i 's/a/b/g' {} +
```

## awk

| Command | What it does |
|---|---|
| `awk '{print $1,$3}' f` | Columns 1 and 3 |
| `awk -F: '{print $1}' f` | Split on `:` |
| `awk 'NR==5' f` | Line 5 |
| `awk '$3 > 100' f` | Rows where col 3 > 100 |
| `awk '/ERR/{print NR}' f` | Line nos. of matches |
| `awk '{s+=$1} END{print s}'` | Sum column 1 |
| `awk 'END{print NR}' f` | Count lines |

## sort, uniq, cut, wc

| Command | What it does |
|---|---|
| `sort f` | Alphabetical |
| `sort -n f` | Numeric |
| `sort -r f` | Reverse |
| `sort -k2 f` | By column 2 |
| `sort -u f` | Sort, drop duplicates |
| `sort f \| uniq -c` | Count each line |
| `sort f \| uniq -d` | Duplicates only |
| `cut -d, -f2 f` | CSV field 2 |
| `wc -l *.js` | Lines per file |
| `ls -1 \| wc -l` | Count entries |

## xargs

| Command | What it does |
|---|---|
| `xargs rm` | stdin lines → args |
| `xargs -0` | NUL-separated (`-print0`) |
| `xargs -I {} cp {} bak/` | Place each item |
| `xargs -n 3 echo` | 3 args per run |
| `xargs -P 4 -n 1 cmd` | 4 runs in parallel |
| `xargs -r rm` | Skip if no input |

```bash
find . -name '*.tmp' | xargs rm
find . -name '*.log' -print0 | xargs -0 gzip
find . -name '*.jpg' | xargs -P 4 -I {} \
  convert {} {}.png
```

## Pipelines

```bash
# Logs
grep GET access.log | grep -v ' 200 ' | wc -l
tail -f error.log | grep -i error |
  awk '{print $1, $4}'

# Most frequent first
cut -d, -f2 data.csv | sort | uniq -c |
  sort -nr
grep -r import src/ | cut -d: -f1 |
  sort | uniq -c | sort -nr

# Files
find . -name '*.js' | xargs grep -l TODO |
  head -10

# System
ps aux | sort -nrk 3 | head -5   # top CPU
df -h | awk '$5+0 > 80'          # disks >80%

# Git
git diff --name-only HEAD~1 | grep '\.js$'
git branch --merged | grep -v main |
  xargs git branch -d
```

## Viewing files

| Command | What it does |
|---|---|
| `less f` | Page through (`/` search, `q` quit) |
| `head -n 20 f` | First 20 lines |
| `tail -n 20 f` | Last 20 lines |
| `tail -f f` | Follow as it grows |
| `cat -n f` | With line numbers |
| `diff -u a b` | Unified diff |
| `file f` | Detect file type |
| `stat f` | Size, perms, times |

## Redirection & chaining

| Syntax | What it does |
|---|---|
| `cmd > f` | stdout to file (overwrite) |
| `cmd >> f` | Append |
| `cmd 2> err.log` | stderr to file |
| `cmd > f 2>&1` | Both to file |
| `cmd &> /dev/null` | Silence everything |
| `cmd < f` | File as stdin |
| `cmd \| tee f` | Show and save |
| `a && b` | `b` only if `a` succeeds |
| `a \|\| b` | `b` only if `a` fails |
| `$(cmd)` | Insert command output |
| `echo $?` | Last exit code |

```bash
cat > notes.txt <<'EOF'
multi-line text, no $expansion
EOF
diff <(sort a) <(sort b)    # compare outputs
```

## Permissions

| Command | What it does |
|---|---|
| `ls -l` | Show perms + owner |
| `chmod +x f` | Make executable |
| `chmod 644 f` | rw-r--r-- |
| `chmod 755 dir` | rwxr-xr-x |
| `chmod -R g+w dir` | Recursive, group write |
| `chown me:grp f` | Change owner/group |
| `sudo !!` | Rerun last as root |

`r`=4 `w`=2 `x`=1, per user / group / others.

## Archives

| Command | What it does |
|---|---|
| `tar -czf a.tgz dir` | Create .tar.gz |
| `tar -xzf a.tgz` | Extract |
| `tar -xzf a.tgz -C d` | Extract into `d` |
| `tar -tzf a.tgz` | List contents |
| `zip -r a.zip dir` | Create .zip |
| `unzip a.zip` | Extract .zip |
| `gzip f` / `gunzip f.gz` | (De)compress a file |
| `zcat f.gz \| grep x` | Search compressed |

## SSH & copying

| Command | What it does |
|---|---|
| `ssh user@host` | Log in |
| `ssh -p 2222 u@h` | Other port |
| `ssh-keygen -t ed25519` | New key pair |
| `ssh-copy-id u@h` | Install your key |
| `scp f u@h:/tmp/` | Copy to remote |
| `scp u@h:/tmp/f .` | Copy from remote |
| `rsync -avz src/ u@h:dst/` | Sync (only changes) |
| `ssh -L 8080:localhost:80 u@h` | Tunnel a port |

## Jobs & history

| Keys / command | What it does |
|---|---|
| `cmd &` | Run in background |
| `Ctrl-Z` then `bg` | Suspend, resume in bg |
| `jobs` / `fg %1` | List / bring back |
| `nohup cmd &` | Survive logout |
| `kill %1` | Kill job 1 |
| `Ctrl-C` | Interrupt |
| `Ctrl-R` | Search history |
| `history \| grep x` | Find old commands |
| `!!` | Previous command |
| `!$` | Its last argument |

## Environment

| Command | What it does |
|---|---|
| `export K=v` | Set for child processes |
| `K=v cmd` | Set for one command |
| `echo $PATH` | Show a variable |
| `env` | All variables |
| `which cmd` / `type cmd` | Where a command is |
| `alias ll='ls -la'` | Shortcut |
| `source ~/.bashrc` | Reload config |
| `date +%F` | Today, YYYY-MM-DD |
| `time cmd` | How long it takes |

## Directories & disk

| Command | What it does |
|---|---|
| `cd -` | Previous directory |
| `pushd dir` / `popd` | Directory stack |
| `mkdir -p a/b/c` | Create nested dirs |
| `du -sh *` | Size of each entry |
| `df -h` | Free disk space |

## Processes & ports

| Command | What it does |
|---|---|
| `ps aux \| grep node` | Find a process |
| `pgrep -f python` | PIDs by command |
| `pkill -f node` | Kill by command |
| `lsof -i :3000` | Who has port 3000 |
| `ss -tulpn` | Listening ports |
| `watch 'ls -la'` | Rerun every 2 s |
| `tail -f app.log` | Follow a log |

## curl

| Command | What it does |
|---|---|
| `curl url` | GET |
| `curl -X DELETE url` | Other methods |
| `curl -L url` | Follow redirects |
| `curl -O url` | Save, remote name |
| `curl -o f url` | Save as `f` |
| `curl -C - -O url` | Resume download |
| `curl -i url` | + response headers |
| `curl -I url` | Headers only |
| `curl -v url` | Verbose |
| `curl -s url \| jq` | Quiet, pretty JSON |
| `curl -u user:pw url` | Basic auth |
| `curl -F file=@a.pdf url` | Upload a file |
| `curl -d 'a=1&b=2' url` | Form POST |

```bash
curl -H "Authorization: Bearer $TOKEN" url
curl -X POST url -H 'Content-Type: application/json' \
  -d '{"name":"John"}'
curl -X PUT url -H 'Content-Type: application/json' \
  -d @data.json
curl --data-urlencode 'msg=Hi there' url
curl -s -o /dev/null -w '%{http_code}\n' url
curl --connect-timeout 10 --max-time 30 url
```

## HTTPie

| Command | What it does |
|---|---|
| `http url` | GET |
| `http POST url a=1` | JSON `{"a":"1"}` |
| `http POST url n:=30` | Raw JSON value |
| `http PUT url a=1` | Update |
| `http DELETE url` | Delete |
| `http url X-Key:abc` | Send a header |
| `http -a user:pw url` | Basic auth |
| `http -f POST url f@a.pdf` | Form / upload |
| `http POST url < a.json` | Body from file |
| `http -v url` | Show request too |
| `http -d url` | Download |
| `http --session=me url` | Keep cookies/auth |

## jq

| Command | What it does |
|---|---|
| `jq . f` | Pretty-print |
| `jq .name f` | A field |
| `jq -r .name f` | Raw, no quotes |
| `jq '.[2]'` | Array element |
| `jq '.[]'` | Expand array |
| `jq length` | Length |
| `jq keys` | Object keys |
| `jq 'map(.name)'` | Map a field |

```bash
jq '.users[] | select(.age > 25)' f
jq '.users[] | {name, email}' f
jq '.items[] | select(.status == "active")
  | .name' f
jq 'group_by(.category)
  | map({category: .[0].category, count: length})' f
curl -s url | jq -r '.data[]
  | select(.role == "admin") | .name'
```

## More text tools

| Command | What it does |
|---|---|
| `tr a-z A-Z < f` | Upper-case |
| `tr -d '\r' < f` | Strip Windows CRs |
| `tr -s ' ' < f` | Squeeze repeated spaces |
| `column -t -s, f` | Align CSV columns |
| `paste -sd, f` | Join lines with commas |
| `paste a b` | Merge files side by side |
| `comm -12 a b` | Lines in both (sorted) |
| `nl f` | Number lines |
| `rev f` | Reverse each line |
| `split -l 1000 f` | Split into 1000-line files |
| `shuf -n 5 f` | 5 random lines |
| `seq 1 10` | Numbers 1 to 10 |
