<!-- pages: 2 -->
<!-- slug: curl-httpie -->
# curl & HTTPie Cheat Sheet

HTTP from the command line: curl 8.x (everywhere, scriptable) and HTTPie 3.x (`http` / `https`: readable, JSON-first). Examples use `API=https://api.example.com`.

## Same task, both tools

```sh
# GET with a query string
curl -G $API/users -d q=ann -d limit=5
http $API/users q==ann limit==5

# POST JSON
curl $API/users \
  --json '{"name":"ann","age":30}'
http POST $API/users name=ann age:=30

# PUT JSON from a file
curl -X PUT --json @u.json $API/users/7
http PUT $API/users/7 < u.json

# Form post (url-encoded)
curl -d name=ann -d age=30 $API/login
http -f POST $API/login name=ann age=30

# Upload a file (multipart)
curl -F file=@a.png $API/upload
http -f POST $API/upload file@a.png

# Header + bearer token
curl -H "Authorization: Bearer $T" $API/me
http -A bearer -a $T $API/me

# Basic auth (prompts for the password)
curl -u ann $API/me
http -a ann $API/me

# Only the response headers
curl -I $API          # sends HEAD
http --headers $API   # GET, headers only

# Follow redirects
curl -L $API/old
http --follow $API/old

# Download to a file
curl -LO $API/files/report.pdf
http -d $API/files/report.pdf

# Show the full exchange
curl -v $API/users
http -v $API/users

# DELETE
curl -X DELETE $API/users/7
http DELETE $API/users/7
```

## curl: request

| Option | What it does |
|---|---|
| `-X M` | Method (`-d` already means POST) |
| `-H "K: v"` | Add a header (`"K:"` removes one) |
| `-d DATA` | POST form data (`@file` reads a file) |
| `--data-raw` | Like `-d`, but `@` is literal |
| `--data-binary` | Send `@file` byte for byte |
| `--data-urlencode` | URL-encode the value for you |
| `--json DATA` | POST JSON: sets both headers |
| `-G` | Send `-d` data as the query string |
| `--url-query` | Add a query parameter |
| `-F k=v` | Multipart form (`k=@file` uploads) |
| `-T FILE` | PUT a file |
| `-A UA` | User-Agent |
| `-e URL` | Referer |
| `-b` / `-c` | Send cookies / save them to a jar |
| `--compressed` | Ask for gzip/br and decode it |

## curl: output & debugging

| Option | What it does |
|---|---|
| `-o FILE` | Save the body to a file |
| `-O` | Save using the URL's file name |
| `-J` | With `-O`: name from Content-Disposition |
| `--output-dir` | Folder for `-o` / `-O` |
| `--create-dirs` | Make missing folders for `-o` |
| `-i` | Include response headers |
| `-D FILE` | Dump headers (`-D -`: to stdout) |
| `-s` | Silent: no progress bar |
| `-S` | With `-s`: still show errors |
| `-f` | Fail (exit 22) on HTTP ≥ 400, no body |
| `--fail-with-body` | Fail but keep the body |
| `-v` | Verbose: request + response headers |
| `--trace-ascii -` | Everything, including the body |
| `-w FMT` | Print info after the transfer |

Scripts: `curl -fsSL URL` fails loudly, stays quiet otherwise, follows redirects.

## curl: -w write-out

```sh
curl -so /dev/null -w '%{http_code}\n' $API
# timing breakdown (@- reads the format
# from stdin, @file from a file)
curl -so /dev/null -w @- $API <<'EOF'
dns   %{time_namelookup}s
tcp   %{time_connect}s
tls   %{time_appconnect}s
ttfb  %{time_starttransfer}s
total %{time_total}s
size  %{size_download} bytes
EOF
# every variable as JSON
curl -so /dev/null -w '%{json}' $API \
  | jq .
```

Also `%{url_effective}`, `%{redirect_url}`, `%{num_redirects}`, `%{content_type}`, `%{remote_ip}`, `%{header_json}`, `%header{name}`.

## curl: auth, TLS, proxy

| Option | What it does |
|---|---|
| `-u u:p` | Basic auth (`-u u` prompts) |
| `--oauth2-bearer` | Send `Authorization: Bearer T` |
| `--digest` | Digest auth (with `-u`) |
| `-n` | Read credentials from `~/.netrc` |
| `-k` | Skip TLS verification (testing only) |
| `--cacert F` | Trust this CA bundle |
| `--cert` / `--key` | Client certificate (mTLS) |
| `-x URL` | Proxy (`socks5h://` for SOCKS) |
| `--noproxy '*'` | Bypass the proxy |
| `--resolve` | Pin `host:port:ip` |
| `--connect-to` | Reroute host:port to another |
| `--unix-socket` | Talk to a Unix socket |
| `--http3` | Force HTTP/3 (or `--http2`) |
| `-4` / `-6` | IPv4 / IPv6 only |

## curl: timeouts, retries, speed

| Option | What it does |
|---|---|
| `--connect-timeout` | Seconds for the connect phase |
| `-m S` | Seconds for the whole transfer |
| `--retry N` | Retry transient errors N times |
| `--retry-all-errors` | Retry on any error |
| `--retry-delay` | Seconds between retries |
| `-C -` | Resume a partial download |
| `-r 0-999` | Byte range |
| `-Z` | Transfer several URLs in parallel |
| `--limit-rate 1M` | Cap the speed |

## curl: recipes

```sh
# Status code only, for scripts
code=$(curl -so /dev/null \
  -w '%{http_code}' $API)
# One server by IP, right Host + SNI
curl $API --resolve \
  api.example.com:443:10.0.0.5
# Docker API over its socket
curl --unix-socket /var/run/docker.sock \
  http://localhost/containers/json
# 20 numbered files, in parallel
curl -ZO "$API/img[1-20].png"
# JSON body from stdin
jq -n '{a:1}' | curl --json @- $API/x
```

Defaults go in `~/.curlrc`, one option per line:

```sh
silent
show-error
location
connect-timeout = 5
```

## HTTPie: request items

`http [flags] [METHOD] URL [ITEM ...]` — GET by default, POST once there is data.

| Item | Sends |
|---|---|
| `Key:value` | Header |
| `Key:` | Remove a default header |
| `name==value` | Query parameter |
| `name=value` | JSON string field (form with `-f`) |
| `name:=42` | Raw JSON: number, bool, array, object |
| `name:='[1,2]'` | Raw JSON literal (quote it) |
| `name=@a.txt` | Field value from a file |
| `name:=@a.json` | Raw JSON from a file |
| `name@a.png` | File upload (multipart, with `-f`) |
| `user[name]=ann` | Nested JSON: `{"user":{"name":…}}` |
| `tags[]=a` | Append to a JSON array |

- `:3000/api` means `http://localhost:3000/api`; `https` defaults to the https scheme.
- Escape a separator with `\`: `a\:b=c` is field `a:b`.
- Body from stdin or a file: `http POST $API < body.json`.

## HTTPie: flags

| Flag | What it does |
|---|---|
| `-j` / `-f` | JSON (default) / form body |
| `--multipart` | Force multipart form |
| `--raw 'txt'` | Send this exact body |
| `-v` | Print the request too (`-vv`: + timing) |
| `-h` / `-b` | Response headers / body only |
| `-p HBhbm` | Parts: request `H`/`B`, response `h`/`b`, meta `m` |
| `--pretty=none` | No colors or formatting |
| `-s THEME` | Color style (`monokai`, …) |
| `--offline` | Build and print the request, don't send it |
| `-F` | Follow redirects |
| `--check-status` | Exit 3/4/5 on 3xx/4xx/5xx |
| `--timeout=S` | Give up after S seconds |
| `-d` / `-o F` | Download / save to a file |
| `-c` | Resume the download (with `-o`) |
| `-S` | Stream the response line by line |
| `--verify=no` | Skip TLS verification |
| `--cert` | Client cert (key: `--cert-key`) |
| `--proxy` | Per scheme: `--proxy=https:URL` |
| `--ignore-stdin` | Don't read stdin (use in scripts / cron) |

## HTTPie: auth & sessions

```sh
# basic, digest, bearer
http -a ann:secret $API/me
http -A digest -a ann:secret $API/me
http -A bearer -a "$TOKEN" $API/me
# Sessions keep headers, cookies, auth
http --session=dev -a ann:pw $API/login
http --session=dev $API/me
# use it but don't save changes
http --session-read-only=dev $API/me
```

- Named sessions live in `~/.config/httpie/sessions/<host>/`; a path (`--session=./s.json`) works too.
- Default flags: `~/.config/httpie/config.json` → `{"default_options": ["--style=monokai"]}`.
- `xh` is a fast single-binary port with the same syntax.

## Gotchas

- **Windows PowerShell 5.1**: `curl` is an alias for `Invoke-WebRequest`; call `curl.exe`. Quote JSON with single quotes in PowerShell 7, or use `@file`.
- curl `-d` sends `application/x-www-form-urlencoded` unless you set `Content-Type`; `--json` sets it for you.
- `-X POST` with `-L` keeps POST after a 301/302; plain `-d` switches to GET like a browser.
- `-I` sends HEAD; some servers answer HEAD differently from GET. Use `-sD - -o /dev/null` to see real GET headers.
- `http` reads stdin when it isn't a terminal, so in scripts and CI it can hang or send an empty body: add `--ignore-stdin`.
- HTTPie `name=30` sends the string `"30"`; use `name:=30` for a number.
- Neither follows redirects by default.
