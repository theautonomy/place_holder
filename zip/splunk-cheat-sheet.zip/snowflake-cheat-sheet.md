<!-- pages: 4 -->
<!-- slug: snowflake -->
# Snowflake SQL Cheat Sheet

Everyday Snowflake SQL for querying data. Standard SQL works; this sheet covers what's different or Snowflake-only. Clause order: `FROM → WHERE → GROUP BY → HAVING → QUALIFY → ORDER BY → LIMIT`. Unquoted names are case-insensitive; `"Quoted"` names are case-sensitive.

## Context

| Command | What it does |
|---|---|
| `USE WAREHOUSE wh` | Compute to run on |
| `USE ROLE analyst` | Switch role |
| `USE DATABASE db` | Default database |
| `USE SCHEMA db.sch` | Default schema |
| `db.sch.tbl` | Fully qualified name |
| `SHOW TABLES` | List tables |
| `SHOW TABLES LIKE '%o%'` | Filter a `SHOW` |
| `DESC TABLE t` | Columns and types |
| `SELECT CURRENT_ROLE()` | Also `CURRENT_USER()` |

## SELECT extras

| Syntax | What it does |
|---|---|
| `SELECT * EXCLUDE (a, b)` | All but these |
| `SELECT * RENAME a AS x` | All, one renamed |
| `* REPLACE (a*2 AS a)` | All, one rewritten |
| `SELECT * ILIKE '%_id'` | Columns by name |
| `SELECT TOP 10 *` | Same as `LIMIT 10` |
| `GROUP BY ALL` | Group by every non-aggregate |
| `GROUP BY 1, 2` | By select position |
| `ORDER BY x NULLS LAST` | Control null order |
| `LIMIT 10 OFFSET 20` | Page through rows |

Order when combining: `EXCLUDE` or `ILIKE` (not both), then `REPLACE`, then `RENAME`.

## Filtering

| Predicate | Matches |
|---|---|
| `name ILIKE '%smith%'` | Case-insensitive `LIKE` |
| `c LIKE ANY ('a%', 'b%')` | Any pattern |
| `c ILIKE ANY (...)` | Any, ignore case |
| `c LIKE ALL (...)` | Every pattern |
| `c RLIKE '[0-9]+'` | Regex, whole string |
| `CONTAINS(c, 'err')` | Substring |
| `STARTSWITH(c, 'api')` | Prefix (`ENDSWITH` too) |
| `a IS DISTINCT FROM b` | Null-safe `<>` |
| `EQUAL_NULL(a, b)` | Null-safe `=` |

`LIKE`/`RLIKE` must match the **whole** string: use `%…%` or `.*….*`.

## QUALIFY

Filter on a window function, like `HAVING` for aggregates. No subquery needed.

```sql
-- Latest row per customer
SELECT *
FROM orders
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY customer_id
  ORDER BY order_ts DESC) = 1;
```

```sql
-- Top 3 products per region
SELECT region, product, sales,
  RANK() OVER (PARTITION BY region
    ORDER BY sales DESC) AS rnk
FROM product_sales
QUALIFY rnk <= 3;
```

## Dates & times

| Function | Result |
|---|---|
| `CURRENT_DATE` | Today |
| `CURRENT_TIMESTAMP` | Now, session TZ |
| `DATEADD(day, -7, d)` | Unit **first** |
| `DATEDIFF(day, start, end)` | Units between |
| `DATE_TRUNC('month', ts)` | Start of month |
| `LAST_DAY(d)` | End of month |
| `TIME_SLICE(ts, 15, 'MINUTE')` | 15-min bucket |
| `DATE_PART(hour, ts)` | Also `EXTRACT` |
| `DAYNAME(d)` / `MONTHNAME` | `Mon` / `Jan` |
| `TO_DATE('2026-09-26')` | String → date |
| `TO_TIMESTAMP(1758844800)` | Epoch → timestamp |
| `ts::DATE` | Drop the time |
| `d2 - d1` | Days between dates |

`DATEDIFF` counts boundaries crossed: year from Dec 31 to Jan 1 is 1. Units: `year`, `quarter`, `month`, `week`, `day`, `hour`, `minute`, `second`.

## Time zones

```sql
-- 3 args: wall clock in UTC → NY
CONVERT_TIMEZONE('UTC',
  'America/New_York', ts_ntz)
-- 2 args: any ts → NY TIMESTAMP_TZ
CONVERT_TIMEZONE('America/New_York', ts)
ALTER SESSION SET TIMEZONE = 'UTC';
```

Use IANA names; most abbreviations like `EST` aren't supported. Types: `_NTZ` no zone, `_LTZ` session zone, `_TZ` stored offset.

## Time-range filters

```sql
WHERE ts >= DATEADD(hour, -24,
             CURRENT_TIMESTAMP())
WHERE ts >= DATE_TRUNC('day',
             CURRENT_TIMESTAMP())
WHERE d BETWEEN '2026-01-01'
            AND '2026-01-31'
WHERE ts >= DATE_TRUNC('month',
  DATEADD(month, -1, CURRENT_DATE))
  AND ts < DATE_TRUNC('month',
  CURRENT_DATE)  -- last full month
```

## Strings

| Function | Result |
|---|---|
| `a \|\| b` | Concatenate |
| `CONCAT_WS('-', a, b)` | Join with separator |
| `SPLIT_PART(s, '.', 1)` | 1st part (1-based) |
| `SPLIT_PART(s, '.', -1)` | Last part |
| `SPLIT(s, ',')` | String → array |
| `SUBSTR(s, 1, 5)` | Substring |
| `LEFT(s, 3)` / `RIGHT` | First / last N |
| `POSITION('x' IN s)` | Index of substring |
| `TRIM(s)` / `UPPER` / `LOWER` | Clean up |
| `REPLACE(s, 'a', 'b')` | Replace all |
| `LPAD(s, 5, '0')` | Pad left |
| `INITCAP(s)` | Title Case |
| `PARSE_URL(u):host` | URL parts |

## Regex

```sql
REGEXP_SUBSTR(s, 'id=(\\d+)',
  1, 1, 'e')           -- group 1
REGEXP_SUBSTR_ALL(s, '\\d+') -- array
REGEXP_REPLACE(s, '\\s+', ' ')
REGEXP_COUNT(s, 'err')
REGEXP_LIKE(s, '.*err.*', 'i')
```

Params: `i` ignore case, `c` case-sensitive, `e` extract group, `s` dot matches newline, `m` multiline. In `'…'` double the backslashes; in `$$\d+$$` don't. No lazy `*?`.

## Null & conditional

| Function | Result |
|---|---|
| `IFF(cond, a, b)` | Inline if |
| `COALESCE(a, b, 0)` | First non-null |
| `NVL(a, 0)` / `IFNULL` | Two-arg fallback |
| `NVL2(a, 'y', 'n')` | Non-null / null |
| `NULLIF(a, 0)` | Null if equal |
| `ZEROIFNULL(a)` | Null → 0 |
| `DIV0(a, b)` | 0 if `b` is 0 |
| `DECODE(c, 1,'a', 'z')` | Value map |
| `GREATEST(a, b)` | Null if any null |

## Casting

| Syntax | What it does |
|---|---|
| `x::NUMBER(10,2)` | Cast |
| `TRY_CAST(s AS INT)` | Null on failure |
| `TRY_TO_NUMBER(s)` | Same, by type |
| `TRY_TO_DATE(s, fmt)` | Parse with a format |
| `TRY_TO_TIMESTAMP(s)` | Null on failure |
| `TO_CHAR(d, 'YYYY-MM')` | Format a date |

`TRY_CAST` accepts string input only.

## Aggregates

| Function | Result |
|---|---|
| `COUNT_IF(status >= 500)` | Count matching |
| `COUNT(DISTINCT u)` | Distinct count |
| `APPROX_COUNT_DISTINCT` | Fast distinct estimate |
| `APPROX_TOP_K(x, 10)` | Top 10 values + counts |
| `MAX_BY(price, ts)` | Price at latest `ts` |
| `MIN_BY(user, ts)` | User at earliest `ts` |
| `MEDIAN(x)` / `MODE(x)` | Middle / most common |
| `ANY_VALUE(name)` | Any one value |
| `BOOLOR_AGG(flag)` | Any true? |
| `ARRAY_AGG(DISTINCT x)` | Values → array |
| `OBJECT_AGG(k, v)` | Pairs → object |

```sql
APPROX_PERCENTILE(ms, 0.95) -- fast p95
PERCENTILE_CONT(0.95)       -- exact
  WITHIN GROUP (ORDER BY ms)
LISTAGG(DISTINCT tag, ', ')
  WITHIN GROUP (ORDER BY tag)
```

Without `WITHIN GROUP`, `LISTAGG` order is unpredictable.

## Window functions

| Function | Result |
|---|---|
| `ROW_NUMBER()` | 1, 2, 3 … |
| `RANK()` / `DENSE_RANK()` | Ties share rank |
| `LAG(x) OVER (…)` | Previous row |
| `LEAD(x, 2) OVER (…)` | 2 rows ahead |
| `FIRST_VALUE(x) OVER (…)` | First in window |
| `LAG(x) IGNORE NULLS` | Skip nulls |
| `NTILE(4)` | Quartile |
| `RATIO_TO_REPORT(x)` | Share of total |
| `CONDITIONAL_CHANGE_EVENT` | +1 each time value changes |

```sql
SUM(amt) OVER (PARTITION BY acct
  ORDER BY ts)            -- running total
AVG(amt) OVER (ORDER BY d
  ROWS BETWEEN 6 PRECEDING
   AND CURRENT ROW)       -- 7-row avg
```

With `ORDER BY` and no frame, `SUM`/`COUNT` default to `RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW`, so tied rows sum together.

## JSON / VARIANT

| Syntax | What it does |
|---|---|
| `v:user.name` | Path into a VARIANT |
| `v:user.name::STRING` | Extract as text |
| `v['user']['name']` | Bracket form |
| `v:items[0].sku` | Array index (0-based) |
| `v:"first name"` | Key with spaces |
| `PARSE_JSON(s)` | String → VARIANT |
| `TRY_PARSE_JSON(s)` | Null on bad JSON |
| `GET_PATH(v, 'a.b')` | Path as a string |
| `OBJECT_CONSTRUCT(k, v)` | Build an object |
| `ARRAY_SIZE(v:items)` | Array length |
| `TYPEOF(v:a)` | Type of a value |

`ARRAY_CONTAINS('x'::VARIANT, arr)` takes the value first. Column names are case-insensitive, but **JSON keys are case-sensitive**. Without `::STRING`, text comes back with `"quotes"`.

## FLATTEN

Turn an array (or object) into rows. Output columns: `value`, `index`, `key`, `path`, `seq`, `this`.

```sql
SELECT o.id,
  f.index,
  f.value:sku::STRING AS sku,
  f.value:qty::INT    AS qty
FROM orders o,
  LATERAL FLATTEN(input => o.v:items) f;
```

```sql
-- Keep rows whose array is empty
LATERAL FLATTEN(input => v:tags,
  OUTER => TRUE)
-- Every nested key
LATERAL FLATTEN(input => v,
  RECURSIVE => TRUE)
```

```sql
-- CSV string → rows
SELECT t.value
FROM TABLE(SPLIT_TO_TABLE('a,b,c',
  ',')) t;
```

## PIVOT & UNPIVOT

```sql
SELECT * FROM monthly_sales
  PIVOT (SUM(amount) FOR month
    IN (ANY ORDER BY month))
  ORDER BY empid;
```

```sql
PIVOT (SUM(amount) FOR quarter IN (
  '2026_Q1' AS q1, '2026_Q2' AS q2)
  DEFAULT ON NULL (0))
```

```sql
SELECT * FROM wide
  UNPIVOT (sales FOR month
    IN (jan, feb, mar));
```

## Joins

| Join | Use for |
|---|---|
| `JOIN … USING (id)` | Same-named key |
| `NATURAL JOIN` | All same-named cols |
| `LEFT JOIN … ON` | Keep all left rows |
| `FULL OUTER JOIN` | Keep both sides |
| `CROSS JOIN` | Every combination |
| `ASOF JOIN` | Nearest earlier match |

```sql
-- Price in effect at each trade
SELECT t.*, q.price
FROM trades t ASOF JOIN quotes q
  MATCH_CONDITION (t.ts >= q.ts)
  ON t.symbol = q.symbol;
```

`MATCH_CONDITION` takes `>=`, `<=`, `>`, `<`, with the left table first.

## Sampling

| Syntax | What it does |
|---|---|
| `SAMPLE (10)` | ~10% of rows |
| `SAMPLE (1000 ROWS)` | Fixed row count |
| `SAMPLE SYSTEM (1)` | ~1% of blocks, faster |
| `SAMPLE SYSTEM (1) SEED (42)` | Repeatable |

Goes after the table name: `FROM big_t SAMPLE (10)`.

## Time Travel

```sql
FROM t AT(OFFSET => -3600) -- 1 h ago
FROM t AT(TIMESTAMP =>
  '2026-09-25 09:00'::TIMESTAMP_LTZ)
FROM t BEFORE(STATEMENT =>
  '<query_id>') -- before a bad UPDATE
UNDROP TABLE t; -- restore a drop
```

```sql
-- Rows deleted or changed in the last hour
SELECT * FROM t AT(OFFSET => -3600)
MINUS
SELECT * FROM t;
```

Default retention is 1 day. Cast `TIMESTAMP` values explicitly.

## Variables & results

| Syntax | What it does |
|---|---|
| `SET d = '2026-09-01'` | Session variable |
| `SET (a, b) = (1, 2)` | Several at once |
| `WHERE ts >= $d` | Use it |
| `FROM IDENTIFIER($tbl)` | Variable as a name |
| `SHOW VARIABLES` | List them |

`RESULT_SCAN` queries a previous result (`-1` last, `-2` the one before). `SHOW` output has lower-case column names, so quote them:

```sql
SHOW TABLES;
SELECT "name", "rows"
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))
ORDER BY "rows" DESC;
```

```sql
-- Same thing with the ->> flow operator
SHOW TABLES
  ->> SELECT "name", "rows" FROM $1;
```

Results stay available for 24 hours, to the same user. Rerunning the exact same text (same case, same aliases) on unchanged data returns the cached result for free.

## Subqueries & CTEs

```sql
WITH recent AS (
  SELECT * FROM orders
  WHERE order_ts >= DATEADD(day, -7,
    CURRENT_DATE)
)
SELECT * FROM recent r
WHERE EXISTS (SELECT 1 FROM refunds f
  WHERE f.order_id = r.id);
```

Correlated subqueries (`EXISTS`, `IN`, `ANY`/`ALL`, scalar) are supported in `WHERE`. A scalar subquery must return one row and one column.

## Hierarchies

```sql
-- Org chart, top down
SELECT employee_id, title, LEVEL,
  SYS_CONNECT_BY_PATH(title, ' > ')
    AS path,
  CONNECT_BY_ROOT title AS root
FROM employees
  START WITH manager_id IS NULL
  CONNECT BY manager_id
    = PRIOR employee_id;
```

```sql
-- Same with a recursive CTE
WITH RECURSIVE tree AS (
  SELECT employee_id, 1 AS lvl
  FROM employees
  WHERE manager_id IS NULL
  UNION ALL
  SELECT e.employee_id, t.lvl + 1
  FROM employees e
  JOIN tree t
    ON e.manager_id = t.employee_id
)
SELECT * FROM tree;
```

`CONNECT BY` only self-joins; a recursive CTE can join other tables.

## Full-text search

```sql
WHERE SEARCH(msg, 'timeout db')
  -- any word (OR)
WHERE SEARCH(msg, 'timeout db',
  SEARCH_MODE => 'AND')  -- all words
WHERE SEARCH(msg, 'disk full',
  SEARCH_MODE => 'PHRASE') -- in order
WHERE SEARCH((subject, body), 'refund')
WHERE SEARCH((t.*), 'refund') -- all cols
WHERE SEARCH_IP(log, '10.0.0.1')
```

Case-insensitive; splits on spaces, dots, hyphens. Works on `VARIANT` too. Use in `WHERE` or `SELECT`.

## Time series

```sql
-- Rolling 12-hour sum (gaps OK)
SUM(mm) OVER (PARTITION BY city
  ORDER BY ts
  RANGE BETWEEN INTERVAL '12 hours'
    PRECEDING AND CURRENT ROW)
```

```sql
-- Fill missing hours, carry last value
SELECT city, ts,
  INTERPOLATE_FFILL(temp) OVER (
    PARTITION BY city ORDER BY ts)
    AS temp
FROM readings
  RESAMPLE(USING ts
    INCREMENT BY INTERVAL '1 hour'
    PARTITION BY city);
```

```sql
-- Date spine: one row per day
SELECT DATEADD(day, SEQ4(),
  '2026-01-01'::DATE) AS day
FROM TABLE(GENERATOR(ROWCOUNT => 365));
```

Also `INTERPOLATE_BFILL` and `INTERPOLATE_LINEAR`.

## Examples: dedup & latest

Most recent status per order:

```sql
SELECT order_id, status, updated_at
FROM order_events
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY order_id
  ORDER BY updated_at DESC) = 1;
```

Find duplicate keys:

```sql
SELECT email, COUNT(*) AS n
FROM users
GROUP BY email
HAVING n > 1
ORDER BY n DESC;
```

Value at the last event, no window needed:

```sql
SELECT user_id,
  MAX_BY(plan, changed_at) AS plan_now,
  MAX(changed_at) AS since
FROM plan_changes
GROUP BY ALL;
```

## Examples: over time

Daily orders and revenue, last 30 days:

```sql
SELECT order_ts::DATE AS day,
  COUNT(*) AS orders,
  SUM(amount) AS revenue
FROM orders
WHERE order_ts >= DATEADD(day, -30,
  CURRENT_DATE)
GROUP BY ALL
ORDER BY day;
```

Error rate per 15 minutes:

```sql
SELECT TIME_SLICE(ts, 15, 'MINUTE')
    AS bucket,
  COUNT(*) AS total,
  COUNT_IF(status >= 500) AS errors,
  ROUND(DIV0(errors, total) * 100, 2)
    AS err_pct
FROM requests
WHERE ts >= DATEADD(hour, -24,
  CURRENT_TIMESTAMP())
GROUP BY bucket
ORDER BY bucket;
```

Month over month growth:

```sql
SELECT DATE_TRUNC('month', order_ts)
    AS month,
  SUM(amount) AS rev,
  LAG(SUM(amount)) OVER
    (ORDER BY month) AS prev,
  ROUND((rev - prev) / prev * 100, 1)
    AS growth_pct
FROM orders
GROUP BY month
ORDER BY month;
```

## Examples: users & funnels

Daily active users:

```sql
SELECT event_ts::DATE AS day,
  COUNT(DISTINCT user_id) AS dau
FROM events
WHERE event_ts >= DATEADD(day, -30,
  CURRENT_DATE)
GROUP BY day ORDER BY day;
```

Signup → purchase within 7 days:

```sql
SELECT COUNT(DISTINCT s.user_id)
    AS signups,
  COUNT(DISTINCT p.user_id)
    AS bought,
  ROUND(bought / signups * 100, 1)
    AS conv_pct
FROM signups s
LEFT JOIN purchases p
  ON p.user_id = s.user_id
 AND p.ts BETWEEN s.ts
     AND DATEADD(day, 7, s.ts);
```

Sessions: new one after 30 min idle:

```sql
WITH gaps AS (
  SELECT user_id, ts,
    DATEDIFF(minute, LAG(ts) OVER (
      PARTITION BY user_id
      ORDER BY ts), ts) AS gap
  FROM events)
SELECT user_id, ts,
  CONDITIONAL_TRUE_EVENT(gap > 30)
    OVER (PARTITION BY user_id
          ORDER BY ts) AS session_n
FROM gaps;
```

## Examples: JSON events

Top event types from a VARIANT column:

```sql
SELECT payload:type::STRING AS type,
  COUNT(*) AS n
FROM raw_events
WHERE payload:env::STRING = 'prod'
GROUP BY type
ORDER BY n DESC
LIMIT 20;
```

Explode line items and total by SKU:

```sql
SELECT li.value:sku::STRING AS sku,
  SUM(li.value:qty::INT) AS units,
  SUM(li.value:qty::INT
    * li.value:price::NUMBER(10,2))
    AS revenue
FROM orders o,
  LATERAL FLATTEN(input =>
    o.payload:line_items) li
GROUP BY sku
ORDER BY revenue DESC;
```

Which keys appear, and how often:

```sql
SELECT f.key, COUNT(*) AS n
FROM raw_events,
  LATERAL FLATTEN(input => payload) f
GROUP BY f.key
ORDER BY n DESC;
```

## Examples: reshape & compare

Top 3 per group, with share of group total:

```sql
SELECT region, product, sales,
  RATIO_TO_REPORT(sales) OVER
    (PARTITION BY region) AS share
FROM product_sales
QUALIFY RANK() OVER (
  PARTITION BY region
  ORDER BY sales DESC) <= 3;
```

Diff two tables (rows in A not in B):

```sql
SELECT * FROM prod.sales.orders
MINUS
SELECT * FROM dev.sales.orders;
```

What changed since this morning:

```sql
SELECT * FROM orders
MINUS
SELECT * FROM orders
  AT(TIMESTAMP => DATE_TRUNC('day',
    CURRENT_TIMESTAMP())::TIMESTAMP_LTZ);
```

## Examples: query history

My failed queries today (last 7 days, instant):

```sql
SELECT query_id, start_time,
  error_message, query_text
FROM TABLE(INFORMATION_SCHEMA
  .QUERY_HISTORY_BY_USER(
    RESULT_LIMIT => 1000))
WHERE execution_status = 'FAIL'
  AND start_time >= CURRENT_DATE
ORDER BY start_time DESC;
```

Slowest queries this week (365 days, up to 45 min behind):

```sql
SELECT user_name, warehouse_name,
  total_elapsed_time / 1000 AS secs,
  bytes_scanned / POWER(1024, 3)
    AS gb_scanned,
  LEFT(query_text, 80) AS query
FROM SNOWFLAKE.ACCOUNT_USAGE
  .QUERY_HISTORY
WHERE start_time >= DATEADD(day, -7,
  CURRENT_TIMESTAMP())
ORDER BY total_elapsed_time DESC
LIMIT 20;
```

Queries that waited for a busy warehouse:

```sql
SELECT warehouse_name,
  COUNT(*) AS queued,
  AVG(queued_overload_time) / 1000
    AS avg_wait_secs
FROM SNOWFLAKE.ACCOUNT_USAGE
  .QUERY_HISTORY
WHERE start_time >= DATEADD(day, -1,
  CURRENT_TIMESTAMP())
  AND queued_overload_time > 0
GROUP BY 1
ORDER BY queued DESC;
```

`ACCOUNT_USAGE` needs access to the `SNOWFLAKE` database, which is often admin-only.

## Examples: query tuning

Queries that spilled or scanned every partition:

```sql
SELECT query_id, user_name,
  partitions_scanned,
  partitions_total,
  bytes_spilled_to_remote_storage
FROM SNOWFLAKE.ACCOUNT_USAGE
  .QUERY_HISTORY
WHERE start_time >= DATEADD(day, -1,
  CURRENT_TIMESTAMP())
  AND (bytes_spilled_to_remote_storage
       > 0
   OR (partitions_total > 100
   AND partitions_scanned
       = partitions_total))
ORDER BY bytes_spilled_to_remote_storage
  DESC;
```

Costliest repeated query shapes (same SQL, different literals):

```sql
SELECT query_parameterized_hash,
  COUNT(*) AS runs,
  SUM(total_elapsed_time) / 1000
    AS total_secs,
  ANY_VALUE(query_text) AS sample
FROM SNOWFLAKE.ACCOUNT_USAGE
  .QUERY_HISTORY
WHERE start_time >= DATEADD(day, -7,
  CURRENT_TIMESTAMP())
GROUP BY 1
ORDER BY total_secs DESC
LIMIT 20;
```

Stop a runaway query:

```sql
SELECT SYSTEM$CANCEL_QUERY('<query_id>');
```

You can cancel your own queries; others' need warehouse `OPERATE` or ownership.

## Examples: search & gaps

Log lines mentioning a phrase, last day:

```sql
SELECT ts, host, msg
FROM app_logs
WHERE ts >= DATEADD(day, -1,
    CURRENT_TIMESTAMP())
  AND SEARCH(msg, 'connection reset',
    SEARCH_MODE => 'PHRASE')
ORDER BY ts DESC;
```

Find a value in any column of a table:

```sql
SELECT * FROM customers c
WHERE SEARCH((c.*), 'acme');
```

Daily counts with zero for empty days:

```sql
WITH days AS (
  SELECT DATEADD(day, -SEQ4(),
    CURRENT_DATE) AS day
  FROM TABLE(GENERATOR(ROWCOUNT => 30))
)
SELECT d.day,
  COUNT(o.id) AS orders
FROM days d
LEFT JOIN orders o
  ON o.order_ts::DATE = d.day
GROUP BY d.day
ORDER BY d.day;
```

Top 10 values as rows, fast:

```sql
SELECT f.value[0]::STRING AS page,
  f.value[1]::INT AS hits
FROM (SELECT APPROX_TOP_K(page, 10)
        AS top FROM pageviews),
  LATERAL FLATTEN(input => top) f;
```

Hourly readings with gaps filled linearly:

```sql
SELECT sensor, ts,
  INTERPOLATE_LINEAR(val) OVER (
    PARTITION BY sensor ORDER BY ts)
    AS val
FROM readings
  RESAMPLE(USING ts
    INCREMENT BY INTERVAL '1 hour'
    PARTITION BY sensor);
```

## Examples: analytics

p50 / p95 latency per endpoint:

```sql
SELECT endpoint, COUNT(*) AS n,
  APPROX_PERCENTILE(ms, 0.5) AS p50,
  APPROX_PERCENTILE(ms, 0.95) AS p95
FROM requests
WHERE ts >= DATEADD(day, -1,
  CURRENT_TIMESTAMP())
GROUP BY endpoint
HAVING n > 100
ORDER BY p95 DESC;
```

7-day rolling average of daily revenue:

```sql
WITH daily AS (
  SELECT order_ts::DATE AS day,
    SUM(amount) AS rev
  FROM orders GROUP BY 1)
SELECT day, rev,
  AVG(rev) OVER (ORDER BY day
    RANGE BETWEEN INTERVAL '6 days'
      PRECEDING AND CURRENT ROW)
    AS rev_7d
FROM daily ORDER BY day;
```

Weekly signup cohorts, % still active:

```sql
SELECT DATE_TRUNC('week', s.ts)
    AS cohort,
  DATEDIFF(week, s.ts, e.ts) AS wk,
  COUNT(DISTINCT e.user_id)
    / ANY_VALUE(c.size) * 100 AS pct
FROM signups s
JOIN events e
  ON e.user_id = s.user_id
JOIN (SELECT DATE_TRUNC('week', ts)
        AS cohort, COUNT(*) AS size
      FROM signups GROUP BY 1) c
  ON c.cohort = DATE_TRUNC('week', s.ts)
GROUP BY 1, 2
ORDER BY 1, 2;
```

Everyone under a manager, any depth:

```sql
SELECT employee_id, title, LEVEL
FROM employees
  START WITH employee_id = 42
  CONNECT BY manager_id
    = PRIOR employee_id;
```
