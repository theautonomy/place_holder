<!-- pages: 2 -->
# Vim Cheat Sheet for Developers

A practical reference for the Vim commands, shortcuts, and habits that cover
90% of daily editing. Not a complete Vim manual — just what a working
developer actually reaches for.

## Modes, first

Everything in Vim starts with knowing which mode you're in.

| Mode | How you get there | What it's for |
|---|---|---|
| **Normal** | `Esc` (the default/home mode) | Navigating, running commands |
| **Insert** | `i`, `a`, `o`, etc. from Normal | Typing text |
| **Visual** | `v`, `V`, `Ctrl-v` from Normal | Selecting text |
| **Command-line** | `:` from Normal | Save, quit, search/replace, run `:` commands |

> **Rule of thumb:** if a command isn't doing what you expect, hit `Esc` to
> get back to Normal mode, then try again.

---

## Getting in and out

| Command | Effect |
|---|---|
| `i` | Insert before cursor |
| `a` | Insert after cursor (append) |
| `I` | Insert at start of line |
| `A` | Insert at end of line |
| `o` | Open new line below, insert |
| `O` | Open new line above, insert |
| `Esc` | Back to Normal mode |
| `:w` | Save |
| `:q` | Quit (fails if unsaved changes) |
| `:wq` or `ZZ` | Save and quit |
| `:q!` | Quit, discard changes |
| `:x` | Save and quit only if changes were made |

---

## Insert-mode escape hatches

You don't have to drop to Normal mode for small fixes — these work while
still typing.

| Command | Effect |
|---|---|
| `Ctrl-w` | Delete the word before the cursor |
| `Ctrl-u` | Delete back to the start of the line |
| `Ctrl-o` | Run **one** Normal-mode command, then return to Insert |
| `Ctrl-n` / `Ctrl-p` | Autocomplete from words already in the buffer |
| `Ctrl-x Ctrl-f` | Autocomplete a filename |
| `gi` | Resume Insert at the exact spot you last left it |

> **Tip:** `Ctrl-o` is handy for "jump to end of line, then keep typing" —
> `Ctrl-o$` moves to end of line without leaving Insert mode.

---

## Moving around

### Character / word / line

| Command | Effect |
|---|---|
| `h` `j` `k` `l` | Left, down, up, right |
| `w` | Next word start |
| `b` | Previous word start |
| `e` | End of current/next word |
| `0` | Start of line |
| `^` | First non-blank character of line |
| `$` | End of line |

### Screen / file

| Command | Effect |
|---|---|
| `gg` | Go to first line of file |
| `G` | Go to last line of file |
| `:42` or `42G` | Go to line 42 |
| `Ctrl-d` / `Ctrl-u` | Half-page down / up |
| `Ctrl-f` / `Ctrl-b` | Full page down / up |
| `H` `M` `L` | Top / middle / bottom of visible screen |
| `%` | Jump to matching `(`, `{`, `[` |
| `*` / `#` | Jump to next/previous occurrence of word under cursor |

> **Tip:** Any movement can be prefixed with a count. `5j` moves down 5
> lines, `3w` moves forward 3 words.

---

## Editing

| Command | Effect |
|---|---|
| `x` | Delete character under cursor |
| `X` | Delete character before cursor |
| `dd` | Delete (cut) current line |
| `yy` | Yank (copy) current line |
| `p` | Paste after cursor / below line |
| `P` | Paste before cursor / above line |
| `dw` | Delete to start of next word |
| `de` | Delete to end of word |
| `cw` | Change word (delete + enter Insert) |
| `cc` | Change entire line |
| `r{char}` | Replace one character |
| `~` | Toggle case of character under cursor |
| `J` | Join current line with next |
| `u` | Undo |
| `Ctrl-r` | Redo |
| `.` | Repeat last change |

> **Tip:** The `.` command is the single highest-leverage habit in Vim.
> Make one edit, then repeat it with `.` instead of retyping.

---

## Indentation & numbers

| Command | Effect |
|---|---|
| `>>` / `<<` | Indent / unindent current line |
| `==` | Auto-indent current line |
| `gg=G` | Auto-indent the entire file |
| `Ctrl-a` | Increment the number under/after the cursor |
| `Ctrl-x` | Decrement the number under/after the cursor |
| `{count}Ctrl-a` | Increment by `{count}` (e.g. `5Ctrl-a`) |

> **Tip:** Select a column of numbers with `Ctrl-v`, then `g Ctrl-a` —
> Vim increments each line sequentially (1, 2, 3, …) instead of applying
> the same increment to every line. Great for renumbering a list.

---

## Combining verbs, counts, and motions

Vim's editing commands are built from `{count}{verb}{motion/text-object}`.

- `d` = delete, `c` = change, `y` = yank
- `3dd` → delete 3 lines
- `d$` → delete to end of line
- `d0` → delete to start of line
- `dG` → delete to end of file
- `y2j` → yank current line plus 2 lines below

### Text objects (the real superpower)

| Command | Effect |
|---|---|
| `diw` | Delete inner word (cursor anywhere in word) |
| `ciw` | Change inner word |
| `di"` | Delete inside quotes |
| `ci(` or `ci)` | Change inside parentheses |
| `di{` | Delete inside braces |
| `dap` | Delete a paragraph (including trailing blank line) |
| `dip` | Delete inner paragraph |
| `dit` | Delete inside an HTML/XML tag |
| `dat` | Delete around an HTML/XML tag |

> **Tip:** You don't need to select text with your eyes first. `ci"`
> changes whatever is inside the nearest quotes no matter where the cursor
> sits inside them.

---

## Visual mode

| Command | Effect |
|---|--- |
| `v` | Character-wise visual select |
| `V` | Line-wise visual select |
| `Ctrl-v` | Block (column) visual select |
| `gv` | Reselect last visual selection |
| `>` / `<` | Indent / unindent selection |
| `d` / `y` / `c` | Delete / yank / change selection |
| `U` / `u` | Uppercase / lowercase selection |

**Column editing example:** `Ctrl-v`, select a column across lines, `I`,
type text, `Esc` — inserts that text on every selected line at once.

---

## Search and replace

| Command | Effect |
|---|---|
| `/pattern` | Search forward |
| `?pattern` | Search backward |
| `n` / `N` | Repeat search, same / opposite direction |
| `:%s/old/new/g` | Replace all `old` with `new`, whole file |
| `:%s/old/new/gc` | Same, but confirm each replacement |
| `:s/old/new/g` | Replace all on current line only |
| `:'<,'>s/old/new/g` | Replace within a visual selection |

> **Tip:** Put `set incsearch`, `set ignorecase`, and `set smartcase` in
> your `.vimrc` — search becomes live-highlighted and case-insensitive
> unless you type a capital letter.

---

## The global command (`:g`)

`:g` runs an Ex command on every line matching a pattern — the single most
powerful "bulk edit" tool in Vim.

| Command | Effect |
|---|---|
| `:g/pattern/d` | Delete every line matching `pattern` |
| `:g!/pattern/d` | Delete every line **not** matching `pattern` |
| `:g/pattern/s/old/new/g` | Substitute, but only on matching lines |
| `:g/pattern/normal @a` | Run macro `a` on every matching line |
| `:g/pattern/m$` | Move every matching line to the end of the file |

> **Tip:** Record a macro for a one-line edit, then run
> `:g/pattern/normal @a` to apply it everywhere the pattern occurs — far
> faster than a manual find-and-replace loop.

---

## Copy/paste with registers

| Command | Effect |
|---|---|
| `"ayy` | Yank line into register `a` |
| `"ap` | Paste from register `a` |
| `"+y` | Yank into the **system clipboard** |
| `"+p` | Paste from the **system clipboard** |
| `"0p` | Paste the **last yank** (unaffected by later deletes) |
| `"_d` | Delete into the **black hole register** (doesn't clobber your last yank) |
| `:put %` or `"%p` | Insert the current file's name |
| `:reg` | List all registers and their contents |

> **Tip:** If `"+y` / `"+p` don't work, your Vim build lacks clipboard
> support (`vim --version | grep clipboard`). Install `vim-gtk3` (Linux), or
> switch to Neovim — its clipboard API is built in, but on Linux it still
> needs an external provider (`xclip`, `xsel`, or `wl-clipboard` on Wayland)
> installed to actually reach the OS clipboard.
>
> **Tip:** `"_d` is the fix for "I deleted something to overwrite text, but
> it wiped out what I had yanked." Delete into the black hole register
> instead, and your last yank survives.

---

## Files, windows, buffers

| Command | Effect |
|---|---|
| `:e {file}` | Open a file |
| `:sp {file}` | Split horizontally, open file |
| `:vsp {file}` | Split vertically, open file |
| `Ctrl-w` then `h/j/k/l` | Move between splits |
| `Ctrl-w` then `w` | Cycle through splits |
| `Ctrl-w` then `q` | Close current split |
| `:ls` or `:buffers` | List open buffers |
| `:b {number\|name}` | Switch to buffer |
| `:bn` / `:bp` | Next / previous buffer |
| `:tabnew {file}` | Open file in a new tab |
| `gt` / `gT` | Next / previous tab |
| `gf` | Open the file path under the cursor (e.g. an import) |
| `Ctrl-^` or `:b#` | Toggle to the alternate (previously edited) buffer |

> **Tip:** `gf` turns Vim into a quick code-navigator — put the cursor on
> an import/include path and jump straight to that file.

---

## Marks and jumps

| Command | Effect |
|---|---|
| `ma` | Set mark `a` at cursor |
| `` `a `` | Jump to exact position of mark `a` |
| `'a` | Jump to line of mark `a` |
| `` `` `` | Jump back to position before last jump |
| `` `. `` | Jump to the exact position of the last change |
| `'.` | Jump to the line of the last change |
| `Ctrl-o` / `Ctrl-i` | Move backward / forward through jump history |

> **Tip:** `` `. `` is one of the most underused jumps in Vim — after any
> edit, save, or even reopening the file, it drops you right back where you
> last made a change.

---

## Macros (automate repetitive edits)

1. `qa` — start recording into register `a`
2. Do the edit you want to repeat
3. `q` — stop recording
4. `@a` — replay it once
5. `@@` — replay the last-used macro again
6. `10@a` — replay it 10 times

> **Tip:** Macros plus `:%normal @a` apply the macro to every line in the
> file in one shot — huge for repetitive data cleanup.

---

## Folding

| Command | Effect |
|---|---|
| `zf{motion}` | Create a fold (e.g., `zfip` folds a paragraph) |
| `zo` / `zc` | Open / close fold under cursor |
| `za` | Toggle fold under cursor |
| `zR` | Open all folds |
| `zM` | Close all folds |

---

## Diff mode (merge conflicts)

Run `vimdiff file1 file2` (or hit a merge conflict via `git mergetool`) and
these apply to the diffed windows:

| Command | Effect |
|---|---|
| `]c` / `[c` | Jump to next / previous diff |
| `do` | Diff **obtain** — pull the change from the other window into this one |
| `dp` | Diff **put** — push the change from this window into the other |
| `zo` / `zc` | Open / close a fold hiding unchanged lines |

> **Tip:** `git config merge.tool vimdiff` wires this straight into
> `git mergetool` for resolving conflicts without leaving the terminal.

---

## Essential `.vimrc` starter settings

```vim
set number relativenumber   " line numbers, relative for fast jumps
set ignorecase smartcase    " smarter search
set incsearch hlsearch      " live + highlighted search
set expandtab tabstop=2 shiftwidth=2  " spaces, not tabs
set clipboard=unnamedplus   " share system clipboard by default
set mouse=a                 " mouse support, useful mid-transition to Vim
let mapleader = " "         " space as leader key is a common, ergonomic choice
```

---

## Tips and tricks for daily use

- **Don't fight Insert mode.** Do bulk typing in Insert, then drop to Normal
  for structural edits. Constantly toggling in and out is normal at first.
- **Learn `.` before you learn macros.** It covers most "repeat this small
  edit a few times" cases without the ceremony of recording.
- **Combine counts with everything.** `3dw`, `5j`, `2p` — almost every
  command accepts a leading number.
- **`ci(` / `ci"` / `ciw` beat visual selection** for small, precise edits —
  no need to eyeball a selection.
- **Use `:noh` (or map it)** to clear search highlighting once you're done
  with a search — `set hlsearch` otherwise leaves matches lit up.
- **`Ctrl-]`  and `Ctrl-o`** support code navigation (jump to tag definition,
  jump back) if `ctags` is set up — a lightweight alternative to an IDE
  "go to definition."
- **Set `set undofile`** to keep undo history across sessions — you can undo
  changes even after closing and reopening a file.
- **Prefer relative line numbers** (`set relativenumber`) so you can read
  off the count for `5dd` or `8j` directly from the gutter.
- **When stuck, `:help {topic}`** — Vim's built-in help is thorough and
  often faster than searching the web.
- **Don't memorize everything up front.** Learn text objects and `.` first;
  the rest accretes naturally from daily use.

---

## Common beginner mistakes

- Typing text while still in Normal mode (nothing happens, or letters
  trigger commands) — check you pressed `i`/`a`/`o` first.
- Forgetting `Esc` before `:` commands.
- Fighting arrow keys instead of `hjkl` — either is fine, but `hjkl` avoids
  moving your hand off the home row.
- Trying to select-then-delete with the mouse — use `dd`, `diw`, `d$`, etc.
  instead; it's faster once it's muscle memory.
- Not using `u` liberally — Vim's undo is cheap and safe to lean on while
  learning.

---

## Where to go next

- `vimtutor` — run it from a terminal; ships with Vim, ~30 minutes, covers
  everything above interactively.
- `:help usr_02.txt` (and the rest of the `usr_*` help files) for a guided
  tour beyond this cheat sheet.
- Neovim is a drop-in modern alternative with a large plugin ecosystem
  (LSP, fuzzy finders, Treesitter) if you outgrow stock Vim.
