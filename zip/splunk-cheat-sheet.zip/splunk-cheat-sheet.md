<!-- pages: 2 -->
<!-- slug: splunk -->
# Splunk Search Cheat Sheet

Everyday SPL. A search starts with filters, then pipes through commands left to right: `index=web error | stats count by host`. Commands below go after a `|`. Filter early: `index=` and a time range make everything faster.

## Search basics

| Search | What it matches |
|---|---|
| `index=web error` | Term in an index |
| `host=server1` | By host |
| `source="/var/log/a.log"` | By source file |
| `sourcetype=syslog` | By source type |
| `status=500` | Field equals |
| `status!=200` | Field not equal |
| `uri="/api/*"` | Wildcard |
| `"connection refused"` | Exact phrase |
| `error OR warn` | Either (`AND` implied) |
| `error NOT debug` | Exclude |
| `user=admin action=login` | Several fields |

## Time range

| Modifier | Meaning |
|---|---|
| `earliest=-15m` | Last 15 minutes |
| `earliest=-1h latest=now` | Last hour |
| `earliest=-7d@d latest=@d` | Last 7 whole days |
| `earliest=@d` | Since midnight |
| `earliest=-1w@w1` | Since last Monday |

`@` snaps to a unit: `@m`, `@h`, `@d`, `@w0` (Sunday), `@mon`.

## Filter & shape

| Command | What it does |
|---|---|
| `search status=500` | Filter after a pipe |
| `where resp_ms > 1000` | Filter by expression |
| `fields host, status` | Keep only these |
| `fields - _raw` | Drop a field |
| `table _time, host, msg` | Show as a table |
| `rename src AS client` | Rename a field |
| `dedup host, service` | First per combination |
| `sort -_time` | Newest first |
| `sort - count` | Largest first |
| `head 100` / `tail 10` | First / last N |
| `fillnull value=0` | Fill empty fields |

## stats

| Command | What it does |
|---|---|
| `stats count` | Count events |
| `stats count by host` | Count per host |
| `stats dc(user)` | Distinct count |
| `stats avg(ms) by svc` | Average per group |
| `stats sum(b) max(b)` | Several at once |
| `stats values(x) by h` | Unique values |
| `stats latest(msg)` | Most recent value |
| `stats p95(ms)` | 95th percentile |
| `eventstats avg(ms)` | Stat on every event |
| `streamstats count` | Running count |

Name results with `AS`: `stats dc(user) AS users`.

## Charts & top values

| Command | What it does |
|---|---|
| `timechart count` | Events over time |
| `timechart count by status` | Split by a field |
| `timechart span=1h count` | Set the bucket size |
| `timechart avg(ms)` | Average over time |
| `chart count over a by b` | Two-way table |
| `bin _time span=5m` | Bucket timestamps |
| `top 10 user` | Most common + % |
| `rare limit=5 code` | Least common |

## eval

| Command | What it does |
|---|---|
| `eval t=a+b` | New field |
| `eval s=ms/1000` | Arithmetic |
| `eval ok=if(x<400,1,0)` | If / else |
| `eval u=coalesce(a,b)` | First non-null |
| `eval l=lower(x)` | Lower-case |
| `eval r=round(x,2)` | Round |
| `eval n=len(x)` | String length |
| `eval now=now()` | Current time |

```splunk
| eval sev=case(status>=500,"high", status>=400,"mid", true(),"low")
| eval day=strftime(_time, "%Y-%m-%d")
```

## Extract fields

| Command | What it does |
|---|---|
| `rex "id=(?<id>\d+)"` | Regex → field |
| `regex _raw="ERR.*db"` | Keep regex matches |
| `spath` | Parse JSON / XML |
| `spath path=user.id` | One JSON path |

From another field, case-insensitive, and key=value pairs:

```splunk
| rex field=uri "/v(?<ver>\d+)/"
| rex "(?i)user=(?<username>[^\s]+)"
| extract pairdelim="&" kvdelim="="
```

## Lookups & combining

| Command | What it does |
|---|---|
| `inputlookup t.csv` | Read a lookup |
| `outputlookup r.csv` | Save results |
| `join user [search …]` | Join on a field |
| `append [search …]` | Add more results |
| `transaction sid` | Group into sessions |

Enrich from a CSV, join, and filter by a subsearch's result:

```splunk
| lookup users.csv username OUTPUT department
| join user [search index=users]
index=web [search index=alerts error | return host]
```

## Quick examples

Error rate per hour:

```splunk
index=web
| timechart span=1h count AS total,
    count(eval(status>=500)) AS errors
| eval pct=round(errors/total*100, 1)
```

Slowest endpoints:

```splunk
index=web
| stats avg(resp_ms) AS avg,
    p95(resp_ms) AS p95, count by uri
| sort - p95 | head 10
```

Repeated failed logins, last day:

```splunk
index=auth action=failure earliest=-24h
| stats count by user | where count > 5
| sort - count
```

More complete searches on page 2.

## Default fields

| Field | Holds |
|---|---|
| `_time` | Event timestamp |
| `_raw` | Original event text |
| `index` | Where it's stored |
| `host` | Machine it came from |
| `source` | File / input path |
| `sourcetype` | Data format |
| `_indextime` | When it was indexed |

## Multivalue fields

| Command | What it does |
|---|---|
| `makemv delim="," tags` | Split into values |
| `mvexpand tags` | One event per value |
| `eval n=mvcount(tags)` | Number of values |
| `eval t=mvindex(tags,0)` | First value |
| `eval p=split(path,"/")` | String → multivalue |
| `eval s=mvjoin(tags,";")` | Multivalue → string |
| `nomv tags` | Show as one value |

## Reshape results

| Command | What it does |
|---|---|
| `addtotals` | Row totals |
| `addcoltotals` | Column totals |
| `transpose` | Swap rows / columns |
| `xyseries x y val` | Long → wide table |
| `untable x y val` | Wide → long |
| `convert ctime(t)` | Epoch → readable |
| `iplocation clientip` | IP → city / country |

## Fast searches

| Command | What it does |
|---|---|
| `tstats count by index` | Count from index data |
| `metadata type=hosts` | Hosts and last seen |
| `makeresults` | Fake event for testing |
| `eventcount index=*` | Events per index |

```splunk
| tstats count where index=web by _time span=1h
| makeresults | eval x="a,b,c" | makemv delim="," x
```

Speed: name the `index`, narrow the time range, avoid leading wildcards (`*err`), and use `fields` early to drop what you don't need.

## Examples: web traffic

Requests and errors by status class, every 15 min:

```splunk
index=web sourcetype=access_combined
| eval class=floor(status/100)."xx"
| timechart span=15m count by class
```

Top 404 pages and who links to them:

```splunk
index=web status=404
| stats count, values(referer) AS from
    by uri_path
| sort - count | head 20
```

Busiest clients and their share of traffic:

```splunk
index=web
| stats count AS hits, sum(bytes) AS bytes
    by clientip
| eventstats sum(hits) AS total
| eval pct=round(hits/total*100, 1)
| sort - hits | head 10
```

## Examples: performance

Endpoints slower than a 1 s SLO:

```splunk
index=web
| stats count,
    perc95(response_time) AS p95,
    count(eval(response_time>1000)) AS slow
    by uri_path
| eval slow_pct=round(slow/count*100, 1)
| where count > 100 AND slow_pct > 5
| sort - slow_pct
```

Latency trend, today vs the last 7 days:

```splunk
index=web earliest=-7d@d
| timechart span=1h avg(response_time)
| timewrap 1d
```

## Examples: errors & logs

Most common error messages:

```splunk
index=app log_level=ERROR
| rex "ERROR\s+(?<msg>[^\r\n]{1,80})"
| stats count, latest(_time) AS last
    by msg
| convert ctime(last)
| sort - count | head 15
```

Error spikes: 5-min counts over 3× normal:

```splunk
index=app log_level=ERROR earliest=-24h
| timechart span=5m count
| eventstats avg(count) AS avg,
    stdev(count) AS sd
| where count > avg + 3*sd
```

Errors per host with first and last seen:

```splunk
index=app log_level=ERROR
| stats count, min(_time) AS first,
    max(_time) AS last by host
| convert ctime(first) ctime(last)
| sort - count
```

## Examples: security

Brute force that then succeeded:

```splunk
index=auth earliest=-24h
| stats count(eval(action="failure")) AS fails,
    count(eval(action="success")) AS ok
    by user, src_ip
| where fails >= 10 AND ok > 0
```

Same user logging in from several countries:

```splunk
index=auth action=success earliest=-24h
| iplocation src_ip
| stats dc(Country) AS n,
    values(Country) AS countries by user
| where n > 1
```

Enrich with a lookup, then group:

```splunk
index=auth action=failure
| lookup users.csv user OUTPUT dept, manager
| stats count by dept, manager
| sort - count
```

## Examples: infrastructure

Hosts that stopped sending data (1 h+):

```splunk
| metadata type=hosts index=main
| eval silent_min=round((now()-lastTime)/60)
| where silent_min > 60
| convert ctime(lastTime)
| table host, lastTime, silent_min
```

Event volume by index and sourcetype, fast:

```splunk
| tstats count where index=* earliest=-24h
    by index, sourcetype
| sort - count
```

Alert when a source goes quiet (0 rows = fine):

```splunk
index=web earliest=-15m
| stats count
| where count = 0
```

## Examples: data wrangling

Pull fields out of JSON events:

```splunk
index=api sourcetype=_json
| spath path=response.status output=status
| spath path=request.user.id output=user
| stats count by status, user
```

Sessions: duration and events per visit:

```splunk
index=web
| transaction session_id maxpause=30m
| stats avg(duration) AS avg_secs,
    max(eventcount) AS max_events
```

Pivot to a wide table (hosts × status):

```splunk
index=web
| stats count by host, status
| xyseries host status count
| fillnull value=0
| addtotals
```

## Examples: reporting & time

This week vs last week:

```splunk
index=web earliest=-14d@d latest=@d
| eval week=if(_time >=
    relative_time(now(), "-7d@d"),
    "this", "last")
| stats count by week
```

Daily active users, last 30 days:

```splunk
index=app action=login earliest=-30d@d
| timechart span=1d dc(user) AS dau
```

Business hours only (9–17):

```splunk
index=web
| eval h=tonumber(strftime(_time, "%H"))
| where h >= 9 AND h < 17
| stats count by uri_path
```

Top 5 paths over time, rest as OTHER:

```splunk
index=web
| timechart span=1h count by uri_path
    limit=5 useother=true
```

Report-ready table:

```splunk
index=web status>=500 earliest=-24h
| table _time, host, status, uri_path
| rename uri_path AS "Path",
    status AS "Status"
| sort - _time
```
