<!-- pages: 3 -->
<!-- slug: datadog -->
# Datadog Query Cheat Sheet

Search syntax for APM Trace Explorer, most of which is shared with Log search. Terms are ANDed by default. Operators are upper-case, and attribute searches are case-sensitive.

## Boolean & grouping

| Query | Matches |
|---|---|
| `auth failure` | Both terms (AND implied) |
| `auth AND failure` | Both terms |
| `auth OR password` | Either term |
| `auth AND -password` | Exclude a term |
| `-service:canary` | Exclude a value |
| `(env:prod OR env:staging)` | Group with parentheses |
| `env:(prod OR staging)` | Several values, one key |

## Reserved attributes (no @)

| Attribute | Example |
|---|---|
| `service` | `service:web-store` |
| `env` | `env:prod` |
| `resource_name` | `resource_name:"GET /cart"` |
| `operation_name` | `operation_name:http.request` |
| `status` | `status:error` |
| `type` | `type:web` |
| `trace_id` / `span_id` | `trace_id:1234567890` |
| `ingestion_reason` | Why the span was kept |
| `timestamp`, `link` | Also reserved |

## Attributes & tags

| Query | Matches |
|---|---|
| `@http.status_code:500` | Span attribute (`@`) |
| `@git.commit.sha:12345` | Nested attribute |
| `@url:data*` | Attribute prefix |
| `env:prod` | Tag `key:value` |
| `hostname:web-server` | Infra tag |
| `version:1.4.2` | Deploy version tag |
| `@peer.db.system:postgres` | Uninstrumented dependency |

Span **attributes** come from instrumentation (`@http.url`); span **tags** add context such as host or container. Non-standard tags: `tags:"cluster-autoscaler.k8s.io/daffy"`.

## Wildcards & existence

| Query | Matches |
|---|---|
| `service:web*` | Starts with `web` |
| `@url:*checkout*` | Contains |
| `@user:jo?n` | One character |
| `@error.type:*` | Attribute exists |
| `-@error.type:*` | Attribute missing |
| `@http.status_code:[* TO *]` | Has any number |
| `"*test*"` | Literal `*test*` (quotes turn wildcards off) |

## Numbers, ranges & duration

| Query | Matches |
|---|---|
| `@http.response_time:>100` | Greater than |
| `@http.status_code:>=500` | At least |
| `@http.status_code:[400 TO 499]` | Inclusive range |
| `@duration:>500ms` | Slow spans |
| `@duration:>=1s @duration:<5s` | Between two durations |

Durations take units such as `ms`, `s`, `m`. Numeric search needs the attribute to be a **measure** (a facet with a number type).

## Escaping

Escape special characters with `\`, or quote the value:

| Query | Matches |
|---|---|
| `@url:*user\=JaneDoe*` | Literal `=` |
| `@my_attr:hello\:world` | Literal `:` |
| `@my_attr:"hello:world"` | Same, quoted |
| `@user.first\ name:Jane` | Space in the name |

Needs escaping: `? > < : = " ~ / \` and spaces. In Log search also `- ! ( ) { } [ ] * #` and `&&`, `||`.

## Full text, arrays & IPs (Log search)

| Query | Matches |
|---|---|
| `hello` | Message / error text |
| `*:hello` | Any attribute |
| `*:"hello world"` | Exact phrase, anywhere |
| `@user_perms:(4 6)` | Array contains 4 or 6 |
| `@user_perms:[2 TO 6]` | Array value in range |
IP in a CIDR block, one IP or a list:

```text
CIDR(@network.client.ip, 10.0.0.0/8)
CIDR(@network.ip.list, 13.0.0.0/8, 15.0.0.0/8)
```

## Trace queries (span relationships)

Label span queries `a`, `b`, `c`, then combine them in **Traces matching**:

| Operator | Traces that… |
|---|---|
| `a && b` | Contain both spans |
| `a \|\| b` | Contain either span |
| `a -> b` | Have `a` upstream of `b` |
| `a => b` | Have `a` as `b`'s direct parent |
| `a && NOT(b)` | Contain `a` but no `b` |

| Trace filter | Meaning |
|---|---|
| `span_count(a):>10` | `a` occurs 10+ times |
| `total_span_count:>1000` | Very large traces |
| `trace_duration:>5s` | End-to-end time |

```text
service:checkoutservice
  => service:shippingservice
service:web-store
  && NOT(service:payments-go)
```

## Time range

Type into the time picker:

| Entry | Meaning |
|---|---|
| `15m`, `3h`, `2d`, `1w`, `3mo` | Past N units |
| `today` / `yesterday` | Calendar day |
| `this week` / `last month` | Calendar-aligned |
| `week to date` | This week so far |
| `2 weeks ago` | A past period |
| `since Jun 1` / `from 5h` | Up to now |
| `Jan 1 - Jan 2` | Fixed range |
| `6:00 am - 1:00 pm` | Hours today |
| `1577883600 - 1578009540` | Unix seconds |

## Example searches

Errors in production for one service:

```text
service:web-store env:prod status:error
```

Slow checkout requests, excluding health checks:

```text
service:checkout @duration:>1s
  -resource_name:*health*
```

Server errors on an API route:

```text
env:prod @http.route:"/api/orders/*"
  @http.status_code:[500 TO 599]
```

Slow Postgres calls from the API:

```text
service:api @peer.db.system:postgres
  @duration:>200ms
```

Errors in production, except canary pods:

```text
env:prod status:error
  -kube_deployment:canary
```


## Common span attributes

| Attribute | Holds |
|---|---|
| `@http.method` | GET, POST, … |
| `@http.route` | Route template |
| `@http.url` | Full URL |
| `@http.status_code` | Response code |
| `@http.useragent` | Client user agent |
| `@error.type` | Exception class |
| `@error.message` | Error text |
| `@db.system` | postgres, redis, … |
| `@db.statement` | Query text |
| `@peer.service` | Downstream service |
| `@span.kind` | server, client, … |
| `@network.client.ip` | Caller IP |
| `@duration` | Span duration |

Exact names vary by tracing library; check the facet panel.

## Tips

- **Autocomplete** suggests keys and real values as you type.
- **Click a value** in a span or the facet panel to add it to the query (or exclude it).
- **Saved views** keep query, columns and time range; they appear in autocomplete.
- **Create a facet** on an attribute to filter by it; make it a **measure** for `>`, `<` and ranges.
- `status:error` is the span's error flag; `@http.status_code` is the HTTP response code. A 404 is often not an error.

## Examples: errors

One exception type, in production:

```text
env:prod status:error @error.type:*Timeout*
```

Error message contains a word:

```text
service:api status:error @error.message:*refused*
```

Errors, minus a known noisy one:

```text
service:api status:error
  -@error.type:NotFoundException
```

Errors that carry no message:

```text
status:error -@error.message:*
```

Client errors except 404s:

```text
@http.status_code:[400 TO 499]
  -@http.status_code:404
```

## Examples: latency

Slow requests on one endpoint:

```text
service:web-store resource_name:"GET /cart"
  @duration:>2s
```

Extreme outliers in production:

```text
env:prod @duration:>10s
```

Failing fast (errors under 50 ms):

```text
status:error @duration:<50ms
```

A latency band, 500 ms to 1 s:

```text
@duration:>=500ms @duration:<1s
```

## Examples: HTTP & users

Failing writes:

```text
@http.method:(POST OR PUT)
  @http.status_code:>=500
```

Everything under a route prefix:

```text
@http.route:/api/v2/*
```

Android clients only:

```text
@http.useragent:*Android*
```

One user's requests:

```text
@usr.id:12345
```

## Examples: databases & deps

Slow Postgres queries:

```text
@db.system:postgres @duration:>500ms
```

Queries touching a table (DB spans put the query in the resource):

```text
@db.system:mysql resource_name:*orders*
```

Redis errors:

```text
@db.system:redis status:error
```

Slow calls to a downstream service:

```text
@peer.service:payments @duration:>1s
```

An uninstrumented database:

```text
@peer.db.name:users @peer.db.system:postgres
```

## Examples: deploys & infra

Compare two versions:

```text
service:api status:error
  version:(1.4.2 OR 1.4.3)
```

Canary pods only:

```text
service:api kube_deployment:canary
```

One namespace and container:

```text
kube_namespace:checkout
  container_name:api-frontend
```

One host or zone:

```text
(hostname:web-01 OR availability-zone:us-east)
```

Everything outside production:

```text
service:api -env:prod
```

Spans from one commit:

```text
@git.commit.sha:12345*
```

## Examples: trace queries

Define span queries `a`, `b`, then enter the **Traces matching** line.

Frontend traces that reach a failing payment call:

```text
a: service:frontend
b: service:payments status:error
Traces matching: a -> b
```

API spans that directly call a slow database:

```text
a: service:api
b: @db.system:postgres @duration:>1s
Traces matching: a => b
```

Checkouts that skipped the fraud check:

```text
a: service:checkout
b: service:fraud-check
Traces matching: a && NOT(b)
```

Possible N+1 queries (50+ DB spans in one trace):

```text
a: @db.system:postgres
Traces matching: a
Filter: span_count(a):>50
```

Very long or very large traces:

```text
trace_duration:>10s
total_span_count:>1000
```

## Examples: Log search

A phrase anywhere in the log:

```text
*:"payment declined"
```

Web server 5xx for a service family:

```text
service:web* @http.status_code:[500 TO 599]
```

Requests from an internal network:

```text
source:nginx
  CIDR(@network.client.ip, 10.0.0.0/8)
```

All logs for one trace:

```text
trace_id:1234567890
```

Errors in prod or staging, excluding health checks:

```text
env:(prod OR staging) status:error
  -@http.url:*health*
```

## Examples: security

Failed logins for one user:

```text
@evt.name:authentication @evt.outcome:failure
  @usr.id:alice
```

Unauthorized and forbidden responses:

```text
@http.status_code:(401 OR 403)
```

Scripted clients:

```text
@http.useragent:(*curl* OR *python-requests*)
```

Firewall rejects from an IP block:

```text
source:pan.firewall evt.name:reject
  CIDR(@network.client.ip, 13.0.0.0/8)
```

Names like `@evt.outcome` follow Datadog's standard attributes; your pipelines may map them differently.

## Explorer modes & retention

| Mode | What you search |
|---|---|
| **Live Search** | Every ingested span, unsampled, last 15 min (rolling) |
| **Indexed** (custom filters) | Retained spans, 15 days |
| **Indexed** (intelligent filter) | Retained spans, 30 days |

- Pick **service entry spans**, **root spans**, or **all spans** to narrow what matches.
- Live Search can filter on attributes that aren't facets, such as `@cart.value` or `@customer_id`.
- Only **retained** (indexed) spans can be exported to dashboards and monitors.
- Spans kept by the intelligent filter are excluded from APM trace analytics monitors.
- `ingestion_reason` shows why a span was kept.

## Visualizations

| View | Use it for |
|---|---|
| **List** | Individual spans; newest first; pick and sort columns |
| **Timeseries** | A measure over time; split by up to 3 tags (1 in Live Search) |
| **Top list** | Top values of one tag, e.g. customers with errors |
| **Table** | Top values across up to 3 dimensions |
| **Request flow map** | Request paths between services, with metrics |

Measure what? Span **count**, **unique count** of a tag, or a **measure** such as `@duration` with an aggregation. Group by `@http.route` to see which endpoints are hit hardest. Set the rollup interval (e.g. `10min`) on timeseries.

## Trace view

Click a span to open its trace:

| Tab | Shows |
|---|---|
| **Flame graph** | All spans on a timeline (default) |
| **Span list** | Resources by service, span count, avg duration, % exec time |
| **Waterfall** | One row per span; durations, status codes |
| **Map** | Services in this trace and their calls |

- Flame graph: **scroll** to zoom, **drag** to pan, use the minimap; group by service, base service, host, or container; tick **Errors** to highlight error spans.
- **Focus** a span to isolate it and its descendants (flame graph and waterfall).
- Map: red borders mark failing services; nodes show % of execution time.
- Traces over **100 MB** open in preview (service entry, error, long-running and linked spans), with only **Waterfall** and **Map**.

## Span details panel

| Tab | Shows |
|---|---|
| **Span Info** | Metadata, tags, errors, stack trace, SQL |
| **Infrastructure** | Host / container CPU, memory, I/O |
| **Logs** | Service logs around the trace |
| **Processes** | Processes on the host (process collection) |
| **Network** | Dependencies, volume, TCP retransmits, RTT |
| **Security** | Attack attempts on the service |
| **Profiles** | Time spent per method |
| **Span Links** | Related spans outside the parent/child tree |

## Searching inside a trace

The trace view has its own, simpler search. **No wildcards.**

| Query | Matches |
|---|---|
| `web` | Service, resource or operation name |
| `service:web-ui` | Key:value |
| `language:(go OR python)` | Group of values |
| `service:api OR web` | Boolean |
| `duration:>200ms` | Span duration (no `@` here) |

## Tag analysis

Finds the tags and attributes that set problem spans apart (errors, latency) from normal ones, ranked by relevance. Start it from:

- A **point plot**: brush over a cluster of spans (duration × time).
- **RED metrics**: click **Analyze** next to the Errors or Latency graph.
- A **timeseries**: brush a time window; it is compared with the rest of the range.

Results list the most distinguishing tag values. From there, filter on a `key:value`, color the plot by an attribute, or open individual traces.

## Trace queries: good to know

- Searches traces kept by the **intelligent retention filter** (on by default) or **custom trace-level retention filters**.
- The trace list shows **up to 50 sample traces** per query.
- Columns come from the **root span**, so its duration is **not** the end-to-end trace duration; use `trace_duration` for that.
- Timeseries, top list and table views need you to choose which span query (`a`, `b`, …) to aggregate.

## Datadog docs

Trace Explorer, at `docs.datadoghq.com/tracing/trace_explorer`:

- [Trace Explorer](https://docs.datadoghq.com/tracing/trace_explorer/?tab=listview): `/`
- [Search spans](https://docs.datadoghq.com/tracing/trace_explorer/search/): `/search/`
- [Query syntax](https://docs.datadoghq.com/tracing/trace_explorer/query_syntax/): `/query_syntax/`
- [Trace queries](https://docs.datadoghq.com/tracing/trace_explorer/trace_queries/): `/trace_queries/`
- [Span tags & attributes](https://docs.datadoghq.com/tracing/trace_explorer/span_tags_attributes/): `/span_tags_attributes/`
- [Visualizations](https://docs.datadoghq.com/tracing/trace_explorer/visualize/): `/visualize/`
- [Trace view](https://docs.datadoghq.com/tracing/trace_explorer/trace_view/?tab=flamegraph): `/trace_view/`
- [Tag analysis](https://docs.datadoghq.com/tracing/trace_explorer/tag_analysis/): `/tag_analysis/`

Also used, at `docs.datadoghq.com`:

- [Custom time frames](https://docs.datadoghq.com/dashboards/guide/custom_time_frames/): `/dashboards/guide/custom_time_frames/`
- [Log search syntax](https://docs.datadoghq.com/logs/explorer/search_syntax/): `/logs/explorer/search_syntax/`
