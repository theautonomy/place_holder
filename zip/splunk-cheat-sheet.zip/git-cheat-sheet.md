<!-- pages: 2 -->
<!-- slug: git -->
# Git Cheat Sheet

Everyday Git for developers. `f` = a file, `b` = a branch, `<sha>` = a commit. Needs Git 2.23+ for `switch` / `restore`.

## Setup

| Command | What it does |
|---|---|
| `git init` | New repo here |
| `git clone url` | Copy a repo |
| `git config -l` | Show all settings |
| `git config --global -e` | Edit global config |

```bash
git config --global user.name "Your Name"
git config --global user.email you@example.com
```

## Status & diff

| Command | What it does |
|---|---|
| `git status -sb` | Short status + branch |
| `git diff` | Unstaged changes |
| `git diff --cached` | Staged (what commits) |
| `git diff main...b` | Changes on `b` since fork |
| `git diff --stat` | Per-file summary |

```bash
# files in the last commit / with conflicts
git diff --name-only HEAD~1
git diff --name-only --diff-filter=U
```

## Stage & commit

| Command | What it does |
|---|---|
| `git add f` | Stage a file |
| `git add -p f` | Stage hunk by hunk |
| `git add -A` | Stage everything |
| `git commit -m "msg"` | Commit staged |
| `git commit -am "msg"` | Stage tracked + commit |
| `git commit --amend` | Redo last commit |

```bash
# fold staged changes in / just reword it
git commit --amend --no-edit
git commit --amend -m "msg"
```

## Undo

| Command | What it does |
|---|---|
| `git restore f` | Discard unstaged edits |
| `git restore --staged f` | Unstage, keep edits |
| `git restore -s <sha> f` | File as of a commit |
| `git reset --soft HEAD~1` | Undo commit, keep staged |
| `git reset HEAD~1` | Undo commit, keep edits |
| `git reset --hard HEAD~1` | Undo commit, drop edits |
| `git revert <sha>` | New commit undoing one |
| `git clean -fd` | Delete untracked files |

> `reset --hard` and `clean` discard work for good. Run `git clean -n` first to preview.

## Branches

| Command | What it does |
|---|---|
| `git branch` | List local |
| `git branch -a` | Include remote |
| `git switch b` | Go to a branch |
| `git switch -c b` | Create and switch |
| `git checkout -b b` | Same, older syntax |
| `git branch -m new` | Rename current |
| `git branch -d b` | Delete (if merged) |
| `git branch -D b` | Force delete |
| `git branch -u origin/main` | Set upstream |
| `git merge b` | Merge `b` into current |

```bash
# delete all branches already merged into main
git branch --merged main | grep -v main | xargs git branch -d
```

## Remote & sync

| Command | What it does |
|---|---|
| `git remote -v` | List remotes |
| `git fetch` | Download, don't merge |
| `git pull` | Fetch + merge |
| `git pull --rebase` | Fetch + rebase |
| `git push` | Upload current branch |
| `git push -u origin b` | First push, set upstream |
| `git push --force-with-lease` | Safer force push |
| `git push origin --delete b` | Delete remote branch |
| `git fetch --prune` | Drop stale remote refs |

## Stash

| Command | What it does |
|---|---|
| `git stash push -m "wip"` | Stash with a message |
| `git stash -u` | Include untracked |
| `git stash list` | List stashes |
| `git stash pop` | Apply + drop latest |
| `git stash apply stash@{1}` | Apply, keep it |
| `git stash drop` | Discard latest |

## History & search

| Command | What it does |
|---|---|
| `git log --oneline --graph` | Compact graph |
| `git log -p f` | Changes to a file |
| `git log --follow f` | Across renames |
| `git log --author=Ann` | By author |
| `git log --since=2.weeks` | By date |
| `git log --grep="bug fix"` | Search messages |
| `git log -S "fn_name" -p` | Commits adding/removing text |
| `git show <sha>` | One commit |
| `git show <sha>:f` | File at a commit |
| `git blame f` | Who changed each line |
| `git grep "TODO"` | Search tracked files |

## Rewrite

| Command | What it does |
|---|---|
| `git rebase main` | Replay onto main |
| `git rebase -i HEAD~3` | Edit last 3 commits |
| `git rebase --continue` | After fixing conflicts |
| `git rebase --abort` | Give up, go back |
| `git cherry-pick <sha>` | Copy one commit here |
| `git merge --abort` | Cancel a merge |

In `rebase -i`: `pick`, `reword`, `edit`, `squash`, `fixup`, `drop`.

## Tags

| Command | What it does |
|---|---|
| `git tag` | List tags |
| `git tag -a v1.0 -m "msg"` | Annotated tag |
| `git push origin v1.0` | Push one tag |
| `git push --tags` | Push all tags |
| `git tag -d v1.0` | Delete locally |

## Rescue & power tools

| Command | What it does |
|---|---|
| `git reflog` | Everywhere HEAD has been |
| `git reset --hard HEAD@{2}` | Go back to a reflog entry |
| `git bisect start` | Binary-search for a bug |
| `git bisect good` / `bad` | Mark each step |
| `git bisect reset` | Finish |
| `git worktree add ../x b` | Check out `b` in another dir |
| `git shortlog -sn` | Commits per author |

## Merge & conflicts

| Command | What it does |
|---|---|
| `git merge --no-ff b` | Always make a merge commit |
| `git merge --squash b` | Squash `b` into one change |
| `git checkout --ours f` | Keep our side |
| `git checkout --theirs f` | Keep their side |
| `git mergetool` | Open a merge tool |
| `git add f` | Mark resolved |
| `git log --merge` | Commits in conflict |

## Inspect & compare

| Command | What it does |
|---|---|
| `git log main..b` | On `b`, not on main |
| `git log --stat` | Files per commit |
| `git log -L 10,20:f` | History of lines 10–20 |
| `git diff b1 b2 -- f` | A file across branches |
| `git show --stat HEAD` | Last commit's files |
| `git describe --tags` | Nearest tag + distance |
| `git ls-files` | Tracked files |

## Ignore & track

| Command | What it does |
|---|---|
| `git rm --cached f` | Stop tracking, keep file |
| `git rm f` | Delete + stage |
| `git mv a b` | Rename + stage |
| `git check-ignore -v f` | Which rule ignores `f` |
| `git status --ignored` | Show ignored files |

`.gitignore`: `*.log`, `build/`, `!keep.log` (re-include), `/root-only`.

## Handy config

```bash
git config --global init.defaultBranch main
git config --global pull.rebase true
git config --global push.autoSetupRemote true
git config --global rerere.enabled true
git config --global alias.lg "log --oneline --graph"
git config --global core.editor "code --wait"
```

## GitHub: search code

Search box on github.com, or github.com/search. Terms are ANDed.

| Query | Finds |
|---|---|
| `"exact phrase"` | Exact text |
| `repo:owner/name` | In one repo |
| `org:acme` / `user:me` | In an org / user |
| `language:python` | By language |
| `path:src/` | Under a folder |
| `path:*.yml` | By file pattern |
| `symbol:parseConfig` | Function / class definitions |
| `content:TODO` | File content only |
| `/foo\d+/` | Regular expression |
| `a OR b` | Either |
| `NOT test` | Exclude |
| `is:archived` / `is:fork` | Repo filters |

```text
repo:acme/api path:*.ts "useQuery"
org:acme language:go /func \w+Handler/
```

## GitHub: search issues & PRs

| Query | Finds |
|---|---|
| `is:issue is:open` | Open issues |
| `is:pr is:merged` | Merged PRs |
| `is:pr is:draft` | Draft PRs |
| `author:@me` | Opened by you |
| `assignee:@me` | Assigned to you |
| `review-requested:@me` | Waiting on your review |
| `involves:@me` | Any involvement |
| `mentions:ann` | Mentions a user |
| `label:bug -label:wontfix` | With / without a label |
| `no:assignee` | Unassigned |
| `in:title crash` | Word in the title |
| `created:>2026-01-01` | Created after a date |
| `updated:<2026-06-01` | Stale since a date |
| `closed:2026-01-01..2026-03-31` | Closed in a range |
| `comments:>10` | Busy threads |
| `sort:updated-desc` | Recently active first |

## GitHub: repos & commits

| Query | Finds |
|---|---|
| `stars:>1000` | Popular repos |
| `topic:cli` | By topic |
| `pushed:>2026-01-01` | Recently active |
| `archived:false` | Not archived |
| `license:mit` | By license |
| `in:readme docker` | Word in the README |
| `good-first-issues:>3` | Beginner-friendly |
| `author:ann` (commits) | Commits by a user |
| `committer-date:>2026-01-01` | Commits after a date |
| `hash:abc123` | Commit by SHA prefix |
| `merge:false` | Skip merge commits |

Pick the result type (Code, Issues, PRs, Repos, Commits) in the sidebar.

## GitHub: site shortcuts

| Key | What it does |
|---|---|
| `/` or `s` | Focus search |
| `t` | Fuzzy file finder |
| `.` | Open repo in github.dev editor |
| `y` | Permalink to this commit |
| `b` | Blame view of a file |
| `l` | Jump to a line |
| `w` | Switch branch / tag |
| `g i` / `g p` | Go to issues / PRs |
| `?` | All shortcuts |

URL tricks: `…/compare/main...b` diff two refs · `#L10-L20` highlight lines · `?w=1` hide whitespace changes · add `.patch` or `.diff` to a commit or PR URL.

## GitHub CLI: gh search

| Command | What it does |
|---|---|
| `gh search code "fn" -R o/r` | Code in a repo |
| `gh search prs --author @me` | Your PRs |
| `gh search issues --label bug` | Issues by label |
| `gh search repos --topic cli` | Repos by topic |
| `gh search commits "fix"` | Commit messages |
| `gh pr list --search "…"` | Search syntax, one repo |
| `gh browse` | Open the repo in a browser |

```bash
# PRs waiting on my review
gh search prs --review-requested @me
# issues about "crash" in one repo
gh search issues crash -R acme/api
gh search repos --language go --stars ">1000"
```

## Examples: code search

Where a function is defined, not just used:

```text
org:acme language:go symbol:NewClient
```

Hard-coded keys, skipping tests and forks:

```text
org:acme /AKIA[0-9A-Z]{16}/
  NOT path:test NOT is:fork
```

Config files that set a value:

```text
org:acme path:**/*.yml "runs-on: self-hosted"
```

Only files under `src/` at the repo root:

```text
repo:acme/web path:/src/**/*.tsx useEffect
```

TypeScript or JavaScript, not vendored:

```text
(language:typescript OR language:javascript)
  "fetch(" NOT is:vendored
```

Case-sensitive match (default ignores case):

```text
repo:acme/api /(?-i)TODO/
```

## Examples: issues & PRs

PRs ready for me to review:

```text
is:pr is:open draft:false
  review-requested:@me
```

My open PRs with failing checks:

```text
is:pr is:open author:@me status:failure
```

Approved but not yet merged:

```text
is:pr is:open review:approved
  base:main
```

PRs a teammate reviewed this month:

```text
is:pr reviewed-by:ann
  created:>=2026-09-01
```

Stale open issues nobody owns:

```text
repo:acme/api is:issue is:open
  no:assignee updated:<2026-06-01
```

Most-discussed open bugs:

```text
is:issue is:open label:bug
  interactions:>20 sort:comments-desc
```

Bug or docs label, excluding bots:

```text
repo:acme/web label:"bug,docs"
  -author:app/dependabot
```

Closed as not planned this year:

```text
is:issue is:closed reason:"not planned"
  closed:>=2026-01-01
```

Merged into a release branch in a date range:

```text
is:pr is:merged base:release/2.x
  merged:2026-07-01..2026-07-31
```

## Examples: repos & commits

Active, popular Go CLIs:

```text
topic:cli language:go stars:>500
  pushed:>2026-01-01 archived:false
```

Beginner-friendly projects to contribute to:

```text
language:python good-first-issues:>5
  help-wanted-issues:>5
```

New this year and already popular:

```text
created:>=2026-01-01 stars:>1000
```

Word in the name, not the description:

```text
in:name terraform org:acme
```

Template repos in your org:

```text
org:acme template:true
```

A teammate's commits this quarter, no merges:

```text
org:acme author:ann merge:false
  author-date:>=2026-07-01
```

Commits by an email (any GitHub account):

```text
author-email:ann@acme.com repo:acme/api
```

Commit search only covers each repo's default branch.
