---
name: upgrade-spring-boot-4
description: Upgrade a Spring Boot 3.x application to 4.0 using OpenRewrite automated migration recipes, with post-migration manual fix phases for Jackson 3, Security 7, testing infrastructure, and property changes. Supports both Maven and Gradle projects.
disable-model-invocation: true
user-invocable: true
allowed-tools: Bash(git:*) Bash(mvn:*) Bash(gradle:*) Bash(./gradlew:*) Bash(java:*) Bash(./mvnw:*) Bash(bash:*) Read Grep Glob
argument-hint: "[branch-name]"
---

# Upgrade Spring Boot to 4.0

This skill automates the migration of a Spring Boot 3.x application to Spring Boot 4.0 using the OpenRewrite community recipe, followed by manual fix phases for changes that OpenRewrite doesn't fully handle.

## What this migration covers

The OpenRewrite recipe applies these transformations:
- Spring Boot 4.0.x dependency updates
- Spring Framework 7.0, Spring Security 7.0, Hibernate 7.1.x upgrades
- Starter renames (e.g. `spring-boot-starter-web` to `spring-boot-starter-webmvc`)
- OAuth2 starter renames with `security-oauth2-` prefix
- `@MockBean`/`@SpyBean` annotation replacements
- Spring Boot properties migration to 4.0 format
- Testcontainers 2.x, SpringDoc 3.0, Spring Batch 6.0 updates
- Jackson 2 to Jackson 3 package migrations
- Jakarta EE 11 / Servlet 6.1 baseline updates

Post-OpenRewrite manual phases address:
- Jackson 3 behavioral differences and renamed annotations
- Spring Security 7 DSL changes (lambda-only, no `and()`)
- Testing infrastructure updates (MockMvc auto-configure, test starters)
- Property renames not caught by recipes
- API relocations and removed methods

## Prerequisites

- Java 17+ installed (21+ recommended)
- Maven 3.6.3+ or Gradle 8.14+
- Spring Boot 3.x project (ideally on 3.5.x latest patch)
- Clean git working tree (no uncommitted changes)

## Steps

### 1. Verify prerequisites

**Detect build tool**: Check for `build.gradle` / `build.gradle.kts` (Gradle) or `pom.xml` (Maven). Set the build tool for all subsequent steps.

**Verify toolchain versions**:

```
java -version
```

For Maven projects:
```
mvn --version
```

For Gradle projects:
```
./gradlew --version
```

Verify:
- Java is 17+ (21+ recommended)
- Maven is 3.6.3+ or Gradle is 8.14+

If toolchain versions are insufficient, warn the user and stop.

**Check git status**:
```
git status
```

If there are uncommitted changes, warn the user and ask whether to proceed or stash changes first.

**Verify Spring Boot version**: Parse `pom.xml` or `build.gradle` to confirm the current Spring Boot version is 3.x. If it is already 4.x, inform the user and stop. If it is below 3.5.x, recommend using the `/upgrade-spring-boot-3.5` skill first — see its `references/breaking-changes.md` and `references/deprecations-to-resolve.md` for 3.5-specific issues that must be resolved before attempting 4.0.

### 2. Create a new branch

Create and switch to a new branch for the upgrade. Use the argument if provided, otherwise default to `upgrade/spring-boot-4.0`:

```
git checkout -b ${branch-name:-upgrade/spring-boot-4.0}
```

### 3. Run the OpenRewrite migration recipe

Run the bundled script which auto-detects the build tool and executes the appropriate OpenRewrite recipe:

```bash
bash .claude/skills/upgrade-spring-boot-4/scripts/run-openrewrite-boot4.sh
```

This may take several minutes as it downloads recipe artifacts and analyzes the codebase.

If the command fails, report the error to the user and suggest troubleshooting steps.

### 4. Review the changes

After the recipe completes, review what was modified:

```
git diff --stat
git diff
```

Summarize the changes for the user, organized by category:
- **Build file changes**: dependency version updates, starter renames
- **Java source changes**: annotation replacements, API migrations, package renames
- **Properties changes**: property key renames/updates
- **Test changes**: test annotation updates

### 5. Post-OpenRewrite manual fixes

After reviewing OpenRewrite changes, scan for issues that OpenRewrite doesn't fully handle. For each area, read the corresponding reference file for detailed guidance.

**Jackson 3 manual changes**: Scan for remaining `com.fasterxml.jackson` imports, `@JsonComponent` annotations, and Jackson behavioral differences.
- Reference: `references/jackson3-migration.md`

**Security DSL fixes** (if Spring Security is used): Check for `and()` chaining in security DSL, removed `AuthorizationManager#check`, and `AntPathRequestMatcher` usage.
- Reference: `references/spring-security7.md`

**Testing infrastructure**: Verify `@SpringBootTest` tests have `@AutoConfigureMockMvc` where needed, check for removed `MockitoTestExecutionListener`, and verify test starters.
- Reference: `references/testing-migration.md`

**Property verification**: Cross-check `application.properties`/`application.yml` for property renames that may have been missed, especially in profile-specific files.
- Reference: `references/property-changes.md`

**API relocations**: Scan for relocated packages (`BootstrapRegistry`, `@EntityScan`, `EnvironmentPostProcessor`), removed APIs, and renamed classes.
- Reference: `references/api-changes.md`

**Build dependencies**: Verify all starters are updated to modular equivalents, check for missing new required starters (Flyway, Liquibase), and verify build plugins.
- Reference: `references/build-and-dependencies.md`

### 6. Verify the build compiles

Run a compilation check to verify the migration didn't break the build:

**Maven**:
```
mvn compile -q
```

**Gradle**:
```
./gradlew compileJava
```

If compilation fails, analyze the errors against the troubleshooting table below and the reference files. Apply fixes and re-compile until clean.

### 7. Run tests (if requested)

Only run tests if the user explicitly asks:

**Maven**:
```
mvn test
```

**Gradle**:
```
./gradlew test
```

Report any test failures with context about what may need manual fixing.

### 8. Present results

Provide the user with a summary:
- List of all files modified
- Key changes made by the recipe
- Manual fixes applied in post-OpenRewrite phases
- Any compilation or test failures that need manual attention
- Suggest next steps (review changes, fix remaining issues, commit when ready)

If there are unresolved compilation errors, reference the troubleshooting table and suggest using compatibility bridges (`spring-boot-starter-classic`, `spring-boot-jackson2`) as temporary workarounds.

Do NOT automatically commit. Let the user decide when they are satisfied with the changes.

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `ClassNotFoundException: ...autoconfigure...` | Modular starters needed | Add specific `spring-boot-starter-X` for the feature |
| `NoSuchMethodError: PropertyMapper.alwaysApplyingNotNull` | API removed in Framework 7 | Use `always()` instead |
| `Cannot resolve symbol JsonComponent` | Annotation renamed | Use `@JacksonComponent` |
| `Package com.fasterxml.jackson does not exist` | Jackson 3 uses new group | Change imports to `tools.jackson` |
| `Cannot resolve symbol MockBean` | Removed (not just deprecated) | Use `@MockitoBean` from `spring-boot-test` |
| `ClassNotFoundException: RestClientBuilderCustomizer` | Elasticsearch 5 API change | Use `Rest5ClientBuilderCustomizer` |
| `Cannot resolve symbol HttpMessageConverters` | Deprecated class | Use `ServerHttpMessageConvertersCustomizer` |
| `NoClassDefFoundError: ...undertow...` | Undertow removed | Switch to Tomcat or Jetty |
| `BeanCreationException` in tests | MockMvc not auto-configured | Add `@AutoConfigureMockMvc` to test class |
| `TestRestTemplate` not injected | Needs explicit auto-configure | Add `@AutoConfigureTestRestTemplate` |

**Quick workarounds** (for getting builds green while migrating incrementally):
- `spring-boot-starter-classic` — restores Boot 3.x auto-configuration
- `spring-boot-jackson2` — maintains Jackson 2 alongside Boot 4
- `spring-boot-starter-test-classic` — classic test infrastructure

## Official Sources

- **Migration Guide**: https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-4.0-Migration-Guide
- **Release Notes**: https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-4.0-Release-Notes
- **Upgrading Docs**: https://docs.spring.io/spring-boot/upgrading.html
- **Jackson 3 Support Blog**: https://spring.io/blog/2025/10/07/introducing-jackson-3-support-in-spring/
- **OpenRewrite Recipes**: https://www.moderne.ai/blog/spring-boot-4x-migration-guide
- **GA Announcement**: https://spring.io/blog/2025/11/20/spring-boot-4-0-0-available-now

## Migration Guide for Teams

For teams migrating manually without this skill, see `references/spring-boot-4-migration-guide.md` — a concise 8-phase walkthrough covering build changes, Jackson 3, Security 7, testing, property renames, API relocations, and troubleshooting.

## Reference File Index

Read these reference files when you encounter specific issues during migration:

| File | When to read |
|------|-------------|
| `references/breaking-changes.md` | Quick scan of all breaking changes in one place before starting |
| `references/deprecations-removed.md` | Code compiles on 3.5 but fails on 4.0 — find what was removed |
| `references/spring-boot-4-migration-guide.md` | Complete step-by-step migration guide for engineering teams |
| `references/build-and-dependencies.md` | Starter mapping issues, missing dependencies, build plugin errors |
| `references/jackson3-migration.md` | Jackson import errors, `@JsonComponent` issues, serialization behavioral changes |
| `references/spring-security7.md` | Security DSL compilation errors, `and()` chaining, request matcher issues |
| `references/testing-migration.md` | Test failures, `@MockBean` errors, MockMvc not working, Testcontainers issues |
| `references/property-changes.md` | Property not recognized warnings, configuration not applying |
| `references/api-changes.md` | Import errors, `ClassNotFoundException`, relocated or removed API usage |
