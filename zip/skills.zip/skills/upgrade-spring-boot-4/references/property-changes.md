# Property Changes — Spring Boot 4.0 Migration

All property key renames and value changes for Spring Boot 4.0.

## Spring Session Properties

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `spring.session.redis.*` | `spring.session.data.redis.*` |
| `spring.session.mongodb.*` | `spring.session.data.mongodb.*` |

## MongoDB Properties

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `spring.data.mongodb.host` | `spring.mongodb.host` |
| `spring.data.mongodb.port` | `spring.mongodb.port` |
| `spring.data.mongodb.database` | `spring.mongodb.database` |
| `spring.data.mongodb.uri` | `spring.mongodb.uri` |
| `spring.data.mongodb.username` | `spring.mongodb.username` |
| `spring.data.mongodb.password` | `spring.mongodb.password` |
| `spring.data.mongodb.authentication-database` | `spring.mongodb.authentication-database` |

Management endpoint health indicator renames:
- `mongo` health indicator → `mongodb`

## Jackson Properties

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `spring.jackson.read.*` | `spring.jackson.json.read.*` |
| `spring.jackson.write.*` | `spring.jackson.json.write.*` |

Properties like `spring.jackson.date-format`, `spring.jackson.default-property-inclusion`, `spring.jackson.time-zone` remain unchanged.

## Kafka Properties

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `spring.kafka.retry.topic.backoff.random` | `spring.kafka.retry.topic.backoff.jitter` |

## Actuator Properties

| Boot 3.x | Boot 4.0 |
|----------|----------|
| Liveness/readiness probes off by default | Enabled by default (`management.endpoint.health.probes.enabled=true`) |

## DevTools Properties

| Boot 3.x | Boot 4.0 |
|----------|----------|
| DevTools live reload enabled by default | Disabled by default |

To re-enable: `spring.devtools.livereload.enabled=true`

## Logging Properties

- Default charset for file logging is now `UTF-8`
- Console logging charset uses `Console#charset()` if available (Java 22+)
- Structured logging output format may change if you use custom patterns

## Hibernate Properties

- MongoDB UUID representation requires explicit configuration
- MongoDB BigDecimal representation requires explicit configuration
- Check `spring.jpa.properties.hibernate.*` for any deprecated Hibernate 7.1 settings

## Where to Check

Property files to scan for renames:

1. `src/main/resources/application.properties`
2. `src/main/resources/application.yml`
3. `src/main/resources/application-{profile}.properties`
4. `src/main/resources/application-{profile}.yml`
5. `src/test/resources/application*.properties` / `*.yml`
6. `@SpringBootTest(properties = ...)` annotations in test classes
7. `@TestPropertySource` annotations
8. Environment-specific configuration files

## Migration Checklist

1. Search all property files for `spring.session.redis` and `spring.session.mongodb`
2. Search for `spring.data.mongodb` properties — rename to `spring.mongodb`
3. Search for `spring.jackson.read` and `spring.jackson.write` — add `.json` prefix
4. Search for `spring.kafka.retry.topic.backoff.random` — rename to `jitter`
5. Review actuator probe defaults if you have explicit probe configuration
6. Check DevTools live reload if you rely on it being enabled
7. Verify charset settings for log files if you use non-UTF-8 encoding
