# Jackson 3 Migration — Spring Boot 4.0

Spring Boot 4.0 uses Jackson 3 as the default JSON library. Jackson 3 uses new Maven coordinates, new Java packages, and has behavioral differences.

## Package Changes

| Jackson 2 | Jackson 3 |
|-----------|-----------|
| `com.fasterxml.jackson.core` | `tools.jackson.core` |
| `com.fasterxml.jackson.databind` | `tools.jackson.databind` |
| `com.fasterxml.jackson.annotation` | `tools.jackson.annotation` |
| `com.fasterxml.jackson.dataformat.*` | `tools.jackson.dataformat.*` |
| `com.fasterxml.jackson.datatype.*` | `tools.jackson.datatype.*` |
| `com.fasterxml.jackson.module.*` | `tools.jackson.module.*` |

## Maven Coordinates

| Jackson 2 Group ID | Jackson 3 Group ID |
|--------------------|-------------------|
| `com.fasterxml.jackson.core` | `tools.jackson.core` |
| `com.fasterxml.jackson.dataformat` | `tools.jackson.dataformat` |
| `com.fasterxml.jackson.datatype` | `tools.jackson.datatype` |
| `com.fasterxml.jackson.module` | `tools.jackson.module` |

## Spring Boot Annotation Changes

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `@JsonComponent` | `@JacksonComponent` |
| `JsonObjectSerializer` | `ObjectValueSerializer` |
| `JsonObjectDeserializer` | `ObjectValueDeserializer` |
| `Jackson2ObjectMapperBuilderCustomizer` | `JsonMapperBuilderCustomizer` |

## Spring Boot Property Changes

| Boot 3.x Property | Boot 4.0 Property |
|-------------------|-------------------|
| `spring.jackson.read.*` | `spring.jackson.json.read.*` |
| `spring.jackson.write.*` | `spring.jackson.json.write.*` |

Other `spring.jackson.*` properties (like `spring.jackson.date-format`, `spring.jackson.default-property-inclusion`) remain the same.

## Key Behavioral Differences in Jackson 3

### Default changes

- **Coercion of empty strings**: Jackson 3 may handle empty string coercion differently. Test with DTOs that accept optional/nullable fields.
- **Date/time serialization**: Default date format behavior may differ. Explicitly configure `spring.jackson.date-format` if you rely on specific formats.
- **Property naming**: The default `PropertyNamingStrategies` may have subtle differences. Test your API contract.

### Removed/changed APIs

- `ObjectMapper.enable()`/`disable()` overloads may differ — check feature enum types.
- `@JsonFormat` annotations are compatible but verify `pattern` and `shape` attributes.
- Custom serializers/deserializers extending Jackson 2 base classes must be updated to Jackson 3 equivalents.

## Using the Jackson 2 Compatibility Bridge

If Jackson 3 migration is too large to do at once, use the compatibility bridge:

### Maven
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-jackson2</artifactId>
</dependency>
```

### Gradle
```groovy
implementation 'org.springframework.boot:spring-boot-jackson2'
```

This allows Jackson 2 to work alongside Boot 4 temporarily. Note: this bridge is expected to be removed in Boot 4.1 or 4.2.

## Migration Checklist

1. Find all `com.fasterxml.jackson` imports and update to `tools.jackson`
2. Find all `@JsonComponent` and rename to `@JacksonComponent`
3. Update `JsonObjectSerializer` to `ObjectValueSerializer`
4. Update `JsonObjectDeserializer` to `ObjectValueDeserializer`
5. Update `Jackson2ObjectMapperBuilderCustomizer` to `JsonMapperBuilderCustomizer`
6. Update `spring.jackson.read.*` / `spring.jackson.write.*` properties
7. Review custom serializers/deserializers for API compatibility
8. Test API responses to verify JSON output hasn't changed
