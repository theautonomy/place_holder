# Breaking Changes — Spring Boot 3.5 to 4.0

Consolidated list of all breaking changes in the Spring Boot 4.0 upgrade. For deeper detail on each topic, see the topic-specific reference files.

## Java and Toolchain

| Change | Detail |
|--------|--------|
| Java 17+ required | Java 8–16 no longer supported (21+ recommended) |
| Kotlin 2.2+ required | Earlier Kotlin versions won't compile |
| GraalVM 25+ required | For native image compilation |
| Maven Surefire 3.0+ required | Older Surefire versions dropped by JUnit 6 |

## Jakarta EE 11 Baseline

| Change | Detail |
|--------|--------|
| Servlet 6.1 required | Undertow removed (incompatible) — use Tomcat or Jetty |
| JPA 3.2 | Via Hibernate 7.1 |
| Bean Validation 3.1 | Via Hibernate Validator 9.x |

## Modular Starters (Build Files)

Spring Boot 4.0 replaces monolithic starters with focused modules:

| Removed / Renamed | Replacement |
|-------------------|-------------|
| `spring-boot-starter-web` | `spring-boot-starter-webmvc` |
| `spring-boot-starter-web-services` | `spring-boot-starter-webservices` |
| `spring-boot-starter-aop` | `spring-boot-starter-aspectj` |
| `spring-boot-starter-oauth2-*` | `spring-boot-starter-security-oauth2-*` |

Features that relied on classpath detection now require explicit starters:
- Flyway → `spring-boot-starter-flyway`
- Liquibase → `spring-boot-starter-liquibase`
- Spring Batch with DB → `spring-boot-starter-batch-jdbc`

See `build-and-dependencies.md` for full details.

## Jackson 3 (Default)

| Change | Detail |
|--------|--------|
| Package rename | `com.fasterxml.jackson.*` → `tools.jackson.*` |
| Maven coordinates | `com.fasterxml.jackson.*` → `tools.jackson.*` |
| `@JsonComponent` | Renamed to `@JacksonComponent` |
| `JsonObjectSerializer` | Renamed to `ObjectValueSerializer` |
| `JsonObjectDeserializer` | Renamed to `ObjectValueDeserializer` |
| `Jackson2ObjectMapperBuilderCustomizer` | Renamed to `JsonMapperBuilderCustomizer` |
| `spring.jackson.read/write.*` | Moved to `spring.jackson.json.read/write.*` |

See `jackson3-migration.md` for full details.

## Spring Security 7

| Change | Detail |
|--------|--------|
| `and()` chaining removed | Lambda DSL required for all security configuration |
| `AuthorizationManager#check()` | Replaced by `authorize()` |
| `AccessDecisionManager` / `AccessDecisionVoter` | Removed — use `AuthorizationManager` |
| `AntPathRequestMatcher` | Favor `PathPatternRequestMatcher` |

See `spring-security7.md` for full details.

## Testing

| Change | Detail |
|--------|--------|
| `@MockBean` removed | Use `@MockitoBean` (not deprecated — completely gone) |
| `@SpyBean` removed | Use `@MockitoSpyBean` |
| `MockitoTestExecutionListener` removed | Use `MockitoExtension` |
| `@SpringBootTest` + MockMvc | Must add `@AutoConfigureMockMvc` explicitly |
| `TestRestTemplate` | Must add `@AutoConfigureTestRestTemplate` |
| JUnit 6.0.x | Pulled in automatically — most JUnit 5 tests work unchanged |
| Testcontainers 2.x | Module API changes possible |

See `testing-migration.md` for full details.

## Package Relocations

| Class | Old Package | New Package |
|-------|------------|------------|
| `BootstrapRegistry` | `o.s.boot` | `o.s.boot.bootstrap` |
| `BootstrapRegistryInitializer` | `o.s.boot` | `o.s.boot.bootstrap` |
| `BootstrapContext` | `o.s.boot` | `o.s.boot.bootstrap` |
| `EnvironmentPostProcessor` | `o.s.boot.env` | `o.s.boot` |
| `@PropertyMapping` | `o.s.boot.test.autoconfigure.properties` | `o.s.boot.test.context` |

See `api-changes.md` for full details.

## Removed APIs

| Removed | Replacement |
|---------|-------------|
| `PropertyMapper.alwaysApplyingNotNull()` | `always()` |
| `HttpMessageConverters` | `ServerHttpMessageConvertersCustomizer` / `ClientHttpMessageConvertersCustomizer` |
| `StreamBuilderFactoryBeanCustomizer` | `StreamsBuilderFactoryBeanConfigurer` |
| `RestClientBuilderCustomizer` | `Rest5ClientBuilderCustomizer` |
| Classic uber-jar loader | Remove `CLASSIC` loader config |
| Embedded executable launch scripts | Gradle `application` plugin or systemd |

## Property Changes

| Old | New |
|-----|-----|
| `spring.session.redis.*` | `spring.session.data.redis.*` |
| `spring.session.mongodb.*` | `spring.session.data.mongodb.*` |
| `spring.data.mongodb.*` | `spring.mongodb.*` |
| `spring.jackson.read/write.*` | `spring.jackson.json.read/write.*` |
| `spring.kafka.retry.topic.backoff.random` | `spring.kafka.retry.topic.backoff.jitter` |

Default behavior changes:
- Liveness/readiness probes: now **enabled** by default
- DevTools live reload: now **disabled** by default
- Log file charset: now **UTF-8** by default

See `property-changes.md` for full details.

## Removed Features

| Feature | Reason |
|---------|--------|
| Undertow | Incompatible with Servlet 6.1 |
| Pulsar Reactive | Reactor support removed from Spring Pulsar |
| Embedded executable jar launch scripts | Use Gradle application plugin or systemd |
| Spring Session Hazelcast | Moved to vendor leadership |
| Spring Session MongoDB | Moved to vendor leadership |
| Spring Retry dependency management | Must declare explicit version |

## Nullability

| Old | New |
|-----|-----|
| `org.springframework.lang.Nullable` | `org.jspecify.annotations.Nullable` |
| `org.springframework.lang.NonNull` | `org.jspecify.annotations.NonNull` |

Primarily affects Kotlin projects where null-safety is enforced at compile time.

## Hibernate 7.1

| Change | Detail |
|--------|--------|
| `hibernate-jpamodelgen` | Replaced by `hibernate-processor` |
| MongoDB UUID representation | Requires explicit configuration |
| MongoDB BigDecimal representation | Requires explicit configuration |
| Entity mapping | Review Hibernate 7.1 migration guide for edge cases |
