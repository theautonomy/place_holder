# Deprecations Removed in Spring Boot 4.0

Everything deprecated in Spring Boot 3.x is **removed** in 4.0. If your code compiled with deprecation warnings on 3.5, those warnings are now compilation errors.

## Annotations

| Deprecated (3.x) | Removed in 4.0 | Replacement |
|------------------|----------------|-------------|
| `@MockBean` | Yes | `@MockitoBean` (`o.s.test.context.bean.override.mockito`) |
| `@SpyBean` | Yes | `@MockitoSpyBean` (`o.s.test.context.bean.override.mockito`) |
| `@JsonComponent` | Yes | `@JacksonComponent` |

## Classes

| Deprecated (3.x) | Removed in 4.0 | Replacement |
|------------------|----------------|-------------|
| `JsonObjectSerializer` | Yes | `ObjectValueSerializer` |
| `JsonObjectDeserializer` | Yes | `ObjectValueDeserializer` |
| `Jackson2ObjectMapperBuilderCustomizer` | Yes | `JsonMapperBuilderCustomizer` |
| `HttpMessageConverters` | Yes | `ServerHttpMessageConvertersCustomizer` / `ClientHttpMessageConvertersCustomizer` |
| `RestClientBuilderCustomizer` | Yes | `Rest5ClientBuilderCustomizer` |
| `StreamBuilderFactoryBeanCustomizer` | Yes | `StreamsBuilderFactoryBeanConfigurer` |
| `MockitoTestExecutionListener` | Yes | `MockitoExtension` |
| `WebSecurityConfigurerAdapter` | Yes (since 5.7) | `SecurityFilterChain` bean |
| `OAuth2ClientAutoConfiguration` (old servlet location) | Yes | New package location |
| `RequestMatcherProvider` (old location) | Yes | Actuator security package |
| `ClientsConfiguredCondition` | Yes | `@ConditionalOnOAuth2ClientRegistrationProperties` |
| `IssuerUriCondition` | Yes | `@ConditionalOnIssuerLocationJwtDecoder` |
| `KeyValueCondition` | Yes | `@ConditionalOnPublicKeyJwtDecoder` |
| `OnEnabledDevToolsCondition` | Yes | `@ConditionalOnEnabledDevTools` |

## Methods

| Deprecated (3.x) | Removed in 4.0 | Replacement |
|------------------|----------------|-------------|
| `PropertyMapper.alwaysApplyingNotNull()` | Yes | `always()` |
| `ConditionalOutcome.inverse()` | Yes | Refactor condition logic |
| `LoggingSystemProperties.getDefaultCharset()` | Yes | `getDefaultConsoleCharset()` / `getDefaultFileCharset()` |
| `HttpOption.ENABLE_REDIRECTS` | Yes | `TestRestTemplate.withRedirects()` |
| `AuthorizationManager#check()` | Yes | `authorize()` |
| Security DSL `and()` | Yes | Lambda DSL |

## Configuration Properties

| Deprecated (3.x) | Removed in 4.0 | Replacement |
|------------------|----------------|-------------|
| `spring.mvc.converters.preferred-json-mapper` | Yes | `spring.http.converters.preferred-json-mapper` |
| `spring.codec.log-request-details` | Yes | `spring.http.codecs.log-request-details` |
| `spring.codec.max-in-memory-size` | Yes | `spring.http.codecs.max-in-memory-size` |
| `spring.jackson.read.*` | Yes | `spring.jackson.json.read.*` |
| `spring.jackson.write.*` | Yes | `spring.jackson.json.write.*` |
| `spring.data.mongodb.host/port/database/...` | Yes | `spring.mongodb.host/port/database/...` |
| `spring.session.redis.*` | Yes | `spring.session.data.redis.*` |
| `spring.session.mongodb.*` | Yes | `spring.session.data.mongodb.*` |
| `spring.kafka.retry.topic.backoff.random` | Yes | `spring.kafka.retry.topic.backoff.jitter` |
| `management.prometheus.metrics.export.pushgateway.base-url` | Yes | `pushgateway.address` (host:port format) |

## Starters

| Deprecated (3.x) | Removed in 4.0 | Replacement |
|------------------|----------------|-------------|
| `spring-boot-starter-web` | Renamed | `spring-boot-starter-webmvc` |
| `spring-boot-starter-web-services` | Renamed | `spring-boot-starter-webservices` |
| `spring-boot-starter-aop` | Renamed | `spring-boot-starter-aspectj` |
| `spring-boot-starter-oauth2-authorization-server` | Renamed | `spring-boot-starter-security-oauth2-authorization-server` |
| `spring-boot-starter-oauth2-client` | Renamed | `spring-boot-starter-security-oauth2-client` |
| `spring-boot-starter-oauth2-resource-server` | Renamed | `spring-boot-starter-security-oauth2-resource-server` |

> **Note**: The old starter names still work in 4.0 via `spring-boot-starter-classic` but will be removed in 5.0.

## Features

| Deprecated / Removed | Detail |
|---------------------|--------|
| SignalFX support | Removed per Micrometer deprecation |
| Zipkin `URLConnectionSender` | Support removed |
| Undertow | Incompatible with Servlet 6.1 |
| `spring-boot-parent` module | No longer published |
| Spring Retry dependency management | Must declare explicit version |
| Embedded executable launch scripts | Use Gradle application plugin |

## How to Find Remaining Deprecations

Before upgrading to 4.0, compile on 3.5 with deprecation warnings enabled:

**Maven**:
```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <configuration>
        <showDeprecation>true</showDeprecation>
    </configuration>
</plugin>
```

**Gradle**:
```groovy
tasks.withType(JavaCompile) {
    options.deprecation = true
}
```

Fix all warnings before attempting the 4.0 upgrade.
