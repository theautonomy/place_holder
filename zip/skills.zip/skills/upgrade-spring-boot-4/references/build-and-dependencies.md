# Build and Dependencies — Spring Boot 4.0 Migration

## Starter Renames

Spring Boot 4.0 introduces modular starters. These are the key renames:

| Boot 3.x Starter | Boot 4.0 Starter |
|-------------------|------------------|
| `spring-boot-starter-web` | `spring-boot-starter-webmvc` |
| `spring-boot-starter-web-services` | `spring-boot-starter-webservices` |
| `spring-boot-starter-aop` | `spring-boot-starter-aspectj` |
| `spring-boot-starter-oauth2-authorization-server` | `spring-boot-starter-security-oauth2-authorization-server` |
| `spring-boot-starter-oauth2-client` | `spring-boot-starter-security-oauth2-client` |
| `spring-boot-starter-oauth2-resource-server` | `spring-boot-starter-security-oauth2-resource-server` |

## New Required Starters

Features that previously relied on classpath detection now require explicit starters:

| Feature | New Required Starter |
|---------|---------------------|
| Flyway | `spring-boot-starter-flyway` |
| Liquibase | `spring-boot-starter-liquibase` |
| Spring Batch (with DB) | `spring-boot-starter-batch-jdbc` |
| OpenTelemetry | `spring-boot-starter-opentelemetry` |

## Classic Starters (Compatibility Bridges)

Use these temporarily during gradual migration:

| Bridge Starter | Purpose | Expected Removal |
|----------------|---------|-----------------|
| `spring-boot-starter-classic` | Restores Boot 3.x auto-configuration | 5.0 |
| `spring-boot-starter-test-classic` | Classic test infrastructure | 5.0 |
| `spring-boot-jackson2` | Maintains Jackson 2 alongside Boot 4 | 4.1 or 4.2 |
| `spring-security-access` | Legacy AccessDecisionManager/Voter patterns | TBD |

## Maven Build Plugin Changes

### Remove classic loader

If your `pom.xml` contains `<loaderImplementation>CLASSIC</loaderImplementation>`, remove it. The classic uber-jar loader is no longer available.

**Before**:
```xml
<plugin>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-maven-plugin</artifactId>
    <configuration>
        <loaderImplementation>CLASSIC</loaderImplementation>
    </configuration>
</plugin>
```

**After**:
```xml
<plugin>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-maven-plugin</artifactId>
</plugin>
```

### Optional dependencies in uber jars

Optional dependencies are now excluded from uber jars by default. If you need them, add:

```xml
<plugin>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-maven-plugin</artifactId>
    <configuration>
        <includeOptional>true</includeOptional>
    </configuration>
</plugin>
```

## Gradle Build Plugin Changes

### CycloneDX plugin

Minimum version is now 3.0.0:

```groovy
plugins {
    id 'org.cyclonedx.bom' version '3.0.0'
}
```

### Embedded launch scripts

Embedded executable jar launch scripts are removed. Use Gradle's `application` plugin instead if you need executable distribution.

## Dependency Management Changes

### Spring Retry

Dependency management for Spring Retry has been removed. You must declare an explicit version:

```xml
<dependency>
    <groupId>org.springframework.retry</groupId>
    <artifactId>spring-retry</artifactId>
    <version>2.x.x</version>
</dependency>
```

### Spring Authorization Server

Now part of Spring Security. Override version via `spring-security.version` property instead of a separate property.

### Hibernate

Replace `hibernate-jpamodelgen` with `hibernate-processor`:

```xml
<!-- Before -->
<dependency>
    <groupId>org.hibernate.orm</groupId>
    <artifactId>hibernate-jpamodelgen</artifactId>
</dependency>

<!-- After -->
<dependency>
    <groupId>org.hibernate.orm</groupId>
    <artifactId>hibernate-processor</artifactId>
</dependency>
```

### Elasticsearch

`RestClient` replaced by `Rest5Client`. Update any customizer beans:

```java
// Before
@Bean
RestClientBuilderCustomizer customizer() { ... }

// After
@Bean
Rest5ClientBuilderCustomizer customizer() { ... }
```

## Removed Features

These are no longer available in Spring Boot 4.0:

- **Undertow** — incompatible with Servlet 6.1. Switch to Tomcat or Jetty.
- **Pulsar Reactive** — Reactor support removed from Spring Pulsar.
- **Embedded executable jar launch scripts** — use Gradle application plugin or systemd.
- **Spring Session Hazelcast & MongoDB** — moved to vendor leadership.
