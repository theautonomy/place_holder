# Testing Infrastructure Migration — Spring Boot 4.0

Spring Boot 4.0 makes significant changes to the testing framework, including removing deprecated annotations and changing auto-configuration behavior.

## `@MockBean` and `@SpyBean` Removal

These annotations are **removed** (not just deprecated) in Boot 4.0.

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `@MockBean` | `@MockitoBean` |
| `@SpyBean` | `@MockitoSpyBean` |
| `org.springframework.boot.test.mock.mockito.MockBean` | `org.springframework.test.context.bean.override.mockito.MockitoBean` |
| `org.springframework.boot.test.mock.mockito.SpyBean` | `org.springframework.test.context.bean.override.mockito.MockitoSpyBean` |

**Note**: `MockitoTestExecutionListener` is also removed. Use Mockito's `MockitoExtension` directly if needed outside of Spring test context.

## MockMvc Auto-Configuration Changes

`@SpringBootTest` **no longer** automatically provides MockMvc support. You must add explicit auto-configuration:

**Before** (Boot 3.x):
```java
@SpringBootTest
class MyControllerTest {
    @Autowired
    MockMvc mockMvc;  // May have worked implicitly
}
```

**After** (Boot 4.0):
```java
@SpringBootTest
@AutoConfigureMockMvc
class MyControllerTest {
    @Autowired
    MockMvc mockMvc;  // Requires explicit auto-configure
}
```

### HtmlUnit Configuration

HtmlUnit settings moved under the `@AutoConfigureMockMvc` annotation:

```java
@AutoConfigureMockMvc(htmlUnit = @HtmlUnit(enabled = true))
```

## TestRestTemplate Changes

`TestRestTemplate` now requires explicit auto-configuration:

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestRestTemplate
class MyIntegrationTest {
    @Autowired
    TestRestTemplate restTemplate;
}
```

## Testcontainers 2.x

Spring Boot 4.0 upgrades to Testcontainers 2.x. Module names and packages may change:

| Testcontainers 1.x | Testcontainers 2.x |
|--------------------|-------------------|
| `org.testcontainers:testcontainers` | `org.testcontainers:testcontainers` (version 2.x) |
| `org.testcontainers:postgresql` | `org.testcontainers:postgresql` (version 2.x) |

Check for breaking API changes in container configuration methods. The core API is similar but constructor signatures and configuration methods may differ.

## JUnit 6

Spring Boot 4.0 supports JUnit 6. While JUnit 5 continues to work, consider the upgrade path:

- JUnit 6 introduces new features and may deprecate some JUnit 5 APIs
- `@ExtendWith(SpringExtension.class)` scope changes — verify test class inheritance behavior
- `SpringExtension` lifecycle may behave differently for nested test classes

## Modular Test Starters

Boot 4.0 introduces modular test starters for specific technologies:

| Feature | Test Starter |
|---------|-------------|
| General testing | `spring-boot-starter-test` |
| Classic compatibility | `spring-boot-starter-test-classic` |
| Web MVC testing | `spring-boot-starter-test-webmvc` |

## Migration Checklist

1. Find all `@MockBean` annotations — replace with `@MockitoBean`
2. Find all `@SpyBean` annotations — replace with `@MockitoSpyBean`
3. Update import statements from `...boot.test.mock.mockito` to `...test.context.bean.override.mockito`
4. Find `@SpringBootTest` tests using `MockMvc` — add `@AutoConfigureMockMvc`
5. Find `@SpringBootTest` tests using `TestRestTemplate` — add `@AutoConfigureTestRestTemplate`
6. Check for `MockitoTestExecutionListener` usage — replace with `MockitoExtension`
7. Update Testcontainers dependencies to 2.x versions
8. Review HtmlUnit test configuration
9. Run full test suite and fix failures
