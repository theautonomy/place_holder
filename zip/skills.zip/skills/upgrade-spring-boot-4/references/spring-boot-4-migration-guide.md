# Spring Boot 4.0 Migration Guide

A concise, step-by-step guide for engineering teams migrating from Spring Boot 3.x to 4.0.

## Migration Overview

```mermaid
flowchart TD
    Start([Spring Boot 3.x Project]) --> Check{On 3.5.x?}
    Check -- No --> Upgrade35[Upgrade to 3.5.x first]
    Upgrade35 --> Check
    Check -- Yes --> Toolchain["Verify Toolchain<br/>Java 17+ / Maven 3.6.3+ / Gradle 8.14+"]

    Toolchain --> P1["Phase 1: Build File Migration<br/>Version bump · Starter renames<br/>New required starters · Plugin changes"]

    P1 --> P2["Phase 2: Property Migration<br/>Session · MongoDB · Jackson<br/>Kafka · Actuator · DevTools renames"]

    P2 --> P3["Phase 3: Jackson 3<br/>Packages: com.fasterxml → tools.jackson<br/>Annotations: @JsonComponent → @JacksonComponent<br/>Or use spring-boot-jackson2 bridge"]

    P3 --> P4{"Using<br/>Security?"}
    P4 -- Yes --> P4a["Phase 4: Spring Security 7<br/>Lambda DSL only · No and()<br/>PathPatternRequestMatcher<br/>AuthorizationManager"]
    P4 -- No --> P5
    P4a --> P5

    P5["Phase 5: Testing<br/>@MockBean → @MockitoBean<br/>Add @AutoConfigureMockMvc<br/>Testcontainers 2 · JUnit 6"]

    P5 --> P6["Phase 6: API Relocations<br/>BootstrapRegistry · EnvironmentPostProcessor<br/>PropertyMapper · HttpMessageConverters"]

    P6 --> P7["Phase 7: Removed Features<br/>Undertow · Pulsar Reactive<br/>Launch scripts · Session Hazelcast"]

    P7 --> P8["Phase 8: Final Verification<br/>mvn clean verify · App startup<br/>Health check · All profiles tested"]

    P8 --> Done([Migration Complete])

    style Start fill:#4a90d9,color:#fff
    style Done fill:#27ae60,color:#fff
    style P1 fill:#f0f0f0,stroke:#333
    style P2 fill:#f0f0f0,stroke:#333
    style P3 fill:#f0f0f0,stroke:#333
    style P4 fill:#fff3cd,stroke:#856404
    style P4a fill:#f0f0f0,stroke:#333
    style P5 fill:#f0f0f0,stroke:#333
    style P6 fill:#f0f0f0,stroke:#333
    style P7 fill:#f0f0f0,stroke:#333
    style P8 fill:#f0f0f0,stroke:#333
    style Toolchain fill:#e8f4fd,stroke:#2196F3
    style Upgrade35 fill:#fde8e8,stroke:#c0392b
```

---

## Before You Start

### Minimum toolchain versions

| Tool | Minimum | Recommended |
|------|---------|-------------|
| Java | 17 | 21+ |
| Maven | 3.6.3 | 3.9.x+ |
| Gradle | 8.14 | 9.x |
| Kotlin | 2.2 | 2.2.x (latest) |

### Pre-migration checklist

- [ ] Project compiles and tests pass on Spring Boot **3.5.x** (latest patch)
- [ ] Deprecated Boot 3.x APIs resolved where feasible
- [ ] Git working tree is clean
- [ ] If on Boot 3.4 or earlier, upgrade to 3.5.x first

---

## Phase 1: Build File Migration

### Update Spring Boot version

**Maven** — update `pom.xml`:
```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>4.0.2</version>
</parent>
```

**Gradle** — update `build.gradle`:
```groovy
plugins {
    id 'org.springframework.boot' version '4.0.2'
}
```

### Rename starters

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `spring-boot-starter-web` | `spring-boot-starter-webmvc` |
| `spring-boot-starter-web-services` | `spring-boot-starter-webservices` |
| `spring-boot-starter-aop` | `spring-boot-starter-aspectj` |
| `spring-boot-starter-oauth2-authorization-server` | `spring-boot-starter-security-oauth2-authorization-server` |
| `spring-boot-starter-oauth2-client` | `spring-boot-starter-security-oauth2-client` |
| `spring-boot-starter-oauth2-resource-server` | `spring-boot-starter-security-oauth2-resource-server` |

### Add new required starters

Features that previously relied on classpath detection now need explicit starters:

| Feature | Add This Starter |
|---------|-----------------|
| Flyway | `spring-boot-starter-flyway` |
| Liquibase | `spring-boot-starter-liquibase` |
| Spring Batch (with DB) | `spring-boot-starter-batch-jdbc` |
| OpenTelemetry | `spring-boot-starter-opentelemetry` |

### Update build plugins

- **Remove** `<loaderImplementation>CLASSIC</loaderImplementation>` from `spring-boot-maven-plugin` if present
- **Replace** `hibernate-jpamodelgen` with `hibernate-processor`
- **CycloneDX Gradle plugin**: minimum version is now 3.0.0
- **Spring Retry**: no longer managed — add explicit version if used

### Verify

```bash
# Maven
mvn compile -q

# Gradle
./gradlew compileJava
```

If compilation fails with `ClassNotFoundException: ...autoconfigure...`, add the specific `spring-boot-starter-X` for that feature. Or temporarily add `spring-boot-starter-classic` to unblock yourself while you migrate incrementally.

---

## Phase 2: Property Migration

Scan **all** property files (`application.properties`, `application.yml`, profile variants) and `@SpringBootTest(properties = ...)` annotations.

### Property renames

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `spring.session.redis.*` | `spring.session.data.redis.*` |
| `spring.session.mongodb.*` | `spring.session.data.mongodb.*` |
| `spring.data.mongodb.host` | `spring.mongodb.host` |
| `spring.data.mongodb.port` | `spring.mongodb.port` |
| `spring.data.mongodb.database` | `spring.mongodb.database` |
| `spring.data.mongodb.uri` | `spring.mongodb.uri` |
| `spring.data.mongodb.username` | `spring.mongodb.username` |
| `spring.data.mongodb.password` | `spring.mongodb.password` |
| `spring.jackson.read.*` | `spring.jackson.json.read.*` |
| `spring.jackson.write.*` | `spring.jackson.json.write.*` |
| `spring.kafka.retry.topic.backoff.random` | `spring.kafka.retry.topic.backoff.jitter` |

### Default behavior changes

| Setting | Boot 3.x Default | Boot 4.0 Default |
|---------|-----------------|-----------------|
| Liveness/readiness probes | Disabled | **Enabled** |
| DevTools live reload | Enabled | **Disabled** (re-enable with `spring.devtools.livereload.enabled=true`) |
| Log file charset | Platform default | **UTF-8** |

---

## Phase 3: Jackson 3 Migration

Spring Boot 4.0 uses Jackson 3 by default. This is the most impactful change for most projects.

### Package changes

All `com.fasterxml.jackson` packages become `tools.jackson`:

```
// Before
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonProperty;

// After
import tools.jackson.databind.ObjectMapper;
import tools.jackson.annotation.JsonProperty;
```

Maven group IDs change the same way: `com.fasterxml.jackson.*` → `tools.jackson.*`.

### Spring Boot annotation/class renames

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `@JsonComponent` | `@JacksonComponent` |
| `JsonObjectSerializer` | `ObjectValueSerializer` |
| `JsonObjectDeserializer` | `ObjectValueDeserializer` |
| `Jackson2ObjectMapperBuilderCustomizer` | `JsonMapperBuilderCustomizer` |

### If Jackson 3 is too big to tackle now

Add the compatibility bridge temporarily:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-jackson2</artifactId>
</dependency>
```

> **Warning**: This bridge is expected to be removed in Boot 4.1 or 4.2.

---

## Phase 4: Spring Security 7

Only relevant if your project uses `spring-boot-starter-security`.

### Lambda DSL required — no more `and()` chaining

```java
// Before (Security 6.x)
http
    .csrf().disable()
    .and()
    .authorizeHttpRequests()
        .requestMatchers("/public/**").permitAll()
        .anyRequest().authenticated()
    .and()
    .httpBasic();

// After (Security 7)
http
    .csrf(csrf -> csrf.disable())
    .authorizeHttpRequests(auth -> auth
        .requestMatchers("/public/**").permitAll()
        .anyRequest().authenticated()
    )
    .httpBasic(Customizer.withDefaults());
```

### Other Security changes

| Change | Action |
|--------|--------|
| `AntPathRequestMatcher` | Consider switching to `PathPatternRequestMatcher` |
| `AuthorizationManager#check()` | Use `authorize()` instead |
| `AccessDecisionManager` / `AccessDecisionVoter` | Migrate to `AuthorizationManager`, or add `spring-security-access` bridge |
| `WebSecurityConfigurerAdapter` | Must already be migrated (removed in Security 5.7) |

---

## Phase 5: Testing Infrastructure

### `@MockBean` and `@SpyBean` are removed

These are **removed entirely** in Boot 4.0, not just deprecated.

| Boot 3.x | Boot 4.0 |
|----------|----------|
| `@MockBean` | `@MockitoBean` |
| `@SpyBean` | `@MockitoSpyBean` |
| `o.s.boot.test.mock.mockito.MockBean` | `o.s.test.context.bean.override.mockito.MockitoBean` |

### MockMvc no longer auto-configured

`@SpringBootTest` no longer provides MockMvc automatically:

```java
// Before — may have worked without annotation
@SpringBootTest
class MyTest {
    @Autowired MockMvc mockMvc;
}

// After — explicit annotation required
@SpringBootTest
@AutoConfigureMockMvc
class MyTest {
    @Autowired MockMvc mockMvc;
}
```

### TestRestTemplate

Add `@AutoConfigureTestRestTemplate` where `TestRestTemplate` is injected.

### JUnit 6

Spring Boot 4.0 pulls in JUnit 6.0.x automatically. Most JUnit 5 tests work unchanged. Key breaking changes (if applicable):

- `MethodOrderer.Alphanumeric` removed
- `@CsvSource` / `@CsvFileSource` parsing overhaul (switched to FastCSV, `lineSeparator` attribute removed)
- `junit-platform-runner`, `junit-platform-jfr` modules removed
- Maven Surefire < 3.0 no longer supported

---

## Phase 6: API and Package Relocations

### Relocated classes

| Class | Old Package | New Package |
|-------|------------|------------|
| `BootstrapRegistry` | `org.springframework.boot` | `org.springframework.boot.bootstrap` |
| `BootstrapRegistryInitializer` | `org.springframework.boot` | `org.springframework.boot.bootstrap` |
| `BootstrapContext` | `org.springframework.boot` | `org.springframework.boot.bootstrap` |
| `EnvironmentPostProcessor` | `org.springframework.boot.env` | `org.springframework.boot` |
| `@PropertyMapping` | `o.s.boot.test.autoconfigure.properties` | `o.s.boot.test.context` |

### Removed / replaced APIs

| Removed | Replacement |
|---------|-------------|
| `PropertyMapper.alwaysApplyingNotNull()` | `always()` |
| `HttpMessageConverters` | `ServerHttpMessageConvertersCustomizer` or `ClientHttpMessageConvertersCustomizer` |
| `StreamBuilderFactoryBeanCustomizer` | `StreamsBuilderFactoryBeanConfigurer` |
| `RestClientBuilderCustomizer` | `Rest5ClientBuilderCustomizer` |
| `MockitoTestExecutionListener` | `MockitoExtension` |

### Nullability annotations

| Old | New |
|-----|-----|
| `org.springframework.lang.Nullable` | `org.jspecify.annotations.Nullable` |

Primarily impacts Kotlin projects. Java projects may see warnings but typically compile fine.

---

## Phase 7: Removed Features

Verify your project doesn't depend on any of these:

- **Undertow** — incompatible with Servlet 6.1. Switch to Tomcat or Jetty.
- **Pulsar Reactive** — Reactor support removed from Spring Pulsar.
- **Embedded executable jar launch scripts** — use Gradle `application` plugin or systemd.
- **Spring Session Hazelcast & MongoDB** — moved to vendor-led projects.

---

## Phase 8: Final Verification

```bash
# Full build
mvn clean verify          # or: ./gradlew clean build

# Application startup
mvn spring-boot:run       # or: ./gradlew bootRun

# Health check (if actuator is present)
curl localhost:8080/actuator/health
```

- [ ] Application starts without errors
- [ ] All tests pass
- [ ] Liveness/readiness probes respond (enabled by default now)
- [ ] API responses return correct JSON (Jackson 3 serialization)
- [ ] Authentication/authorization works (if Security is used)
- [ ] All Spring profiles tested

---

## Quick Reference: Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `ClassNotFoundException: ...autoconfigure...` | Modular starters needed | Add specific `spring-boot-starter-X` |
| `NoSuchMethodError: PropertyMapper.alwaysApplyingNotNull` | API removed | Use `always()` |
| `Cannot resolve symbol JsonComponent` | Renamed | Use `@JacksonComponent` |
| `Package com.fasterxml.jackson does not exist` | Jackson 3 | Change to `tools.jackson` |
| `Cannot resolve symbol MockBean` | Removed | Use `@MockitoBean` |
| `ClassNotFoundException: RestClientBuilderCustomizer` | Elasticsearch change | Use `Rest5ClientBuilderCustomizer` |
| `Cannot resolve symbol HttpMessageConverters` | Deprecated | Use `ServerHttpMessageConvertersCustomizer` |
| `NoClassDefFoundError: ...undertow...` | Removed | Switch to Tomcat or Jetty |
| `BeanCreationException` in tests | MockMvc not auto-configured | Add `@AutoConfigureMockMvc` |
| `TestRestTemplate` not injected | Needs auto-configure | Add `@AutoConfigureTestRestTemplate` |

## Quick Reference: Compatibility Bridges

Use these to unblock builds while migrating incrementally:

| Bridge | Purpose | Expected Removal |
|--------|---------|-----------------|
| `spring-boot-starter-classic` | Restores Boot 3.x auto-configuration | 5.0 |
| `spring-boot-starter-test-classic` | Classic test infrastructure | 5.0 |
| `spring-boot-jackson2` | Maintains Jackson 2 alongside Boot 4 | 4.1 or 4.2 |
| `spring-security-access` | Legacy AccessDecisionManager/Voter | TBD |

---

## Official Resources

- [Migration Guide](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-4.0-Migration-Guide)
- [Release Notes](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-4.0-Release-Notes)
- [Upgrading Docs](https://docs.spring.io/spring-boot/upgrading.html)
- [Jackson 3 Support Blog](https://spring.io/blog/2025/10/07/introducing-jackson-3-support-in-spring/)
- [OpenRewrite Recipes](https://www.moderne.ai/blog/spring-boot-4x-migration-guide)
- [GA Announcement](https://spring.io/blog/2025/11/20/spring-boot-4-0-0-available-now)
