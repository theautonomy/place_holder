# Spring Security 7 Migration — Spring Boot 4.0

Spring Boot 4.0 upgrades to Spring Security 7.0, which removes deprecated APIs and enforces the lambda DSL style.

## DSL Migration: No More `and()` Chaining

Spring Security 7 removes `and()` chaining. All security configuration must use lambda DSL.

**Before** (Security 6.x):
```java
http
    .csrf().disable()
    .and()
    .authorizeHttpRequests()
        .requestMatchers("/public/**").permitAll()
        .anyRequest().authenticated()
    .and()
    .httpBasic();
```

**After** (Security 7):
```java
http
    .csrf(csrf -> csrf.disable())
    .authorizeHttpRequests(auth -> auth
        .requestMatchers("/public/**").permitAll()
        .anyRequest().authenticated()
    )
    .httpBasic(Customizer.withDefaults());
```

## Request Matcher Changes

### `AntPathRequestMatcher` to `PathPatternRequestMatcher`

Spring Security 7 favors `PathPatternRequestMatcher` over the Ant-style matcher.

**Before**:
```java
new AntPathRequestMatcher("/api/**")
```

**After**:
```java
PathPatternRequestMatcher.withDefaults().matcher("/api/**")
```

In most cases, `requestMatchers(String...)` in the DSL already uses the appropriate matcher — only update explicit `AntPathRequestMatcher` references.

## Removed APIs

| Removed | Replacement |
|---------|-------------|
| `and()` chaining | Lambda DSL (see above) |
| `AuthorizationManager#check(Supplier, Object)` | `AuthorizationManager#authorize(Supplier, Object)` |
| `AccessDecisionManager` | `AuthorizationManager` (or use `spring-security-access` bridge) |
| `AccessDecisionVoter` | `AuthorizationManager` |
| `SecurityConfigurerAdapter.and()` | Lambda DSL |
| `WebSecurityConfigurerAdapter` | Component-based `SecurityFilterChain` bean (removed since Security 5.7) |

## SAML and OAuth2 Changes

- SAML 2.0 Jackson serialization support updated for Jackson 3
- OAuth2 token introspection and authorization server configuration may require import updates
- Spring Authorization Server is now part of Spring Security — override version via `spring-security.version`

## Using the Security Access Bridge

For legacy code using `AccessDecisionManager` or `AccessDecisionVoter` patterns:

```xml
<dependency>
    <groupId>org.springframework.security</groupId>
    <artifactId>spring-security-access</artifactId>
</dependency>
```

This bridge provides the removed `access` package temporarily.

## Migration Checklist

1. Search for `.and()` in security configuration classes — rewrite to lambda DSL
2. Search for `AntPathRequestMatcher` — evaluate if `PathPatternRequestMatcher` is needed
3. Search for `AccessDecisionManager` and `AccessDecisionVoter` — migrate to `AuthorizationManager` or add bridge
4. Search for `WebSecurityConfigurerAdapter` — must already be migrated (removed in Security 5.7)
5. Verify all `@EnableWebSecurity`, `@EnableMethodSecurity` configurations compile
6. Test authentication and authorization flows end-to-end
7. Check CORS and CSRF configurations use lambda DSL
