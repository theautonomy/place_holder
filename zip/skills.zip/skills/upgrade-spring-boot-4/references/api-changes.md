# API Changes — Spring Boot 4.0 / Spring Framework 7.0

Package relocations, removed APIs, and renamed classes.

## Package Relocations

| Class/Package | Old Location | New Location |
|---------------|-------------|-------------|
| `BootstrapRegistry` | `org.springframework.boot` | `org.springframework.boot.bootstrap` |
| `BootstrapRegistryInitializer` | `org.springframework.boot` | `org.springframework.boot.bootstrap` |
| `BootstrapContext` | `org.springframework.boot` | `org.springframework.boot.bootstrap` |
| `EnvironmentPostProcessor` | `org.springframework.boot.env` | `org.springframework.boot` |
| `@PropertyMapping` | `org.springframework.boot.test.autoconfigure.properties` | `org.springframework.boot.test.context` |
| `@EntityScan` | (verify current location) | May have moved to persistence module |

## Removed APIs

| Removed API | Replacement |
|-------------|-------------|
| `PropertyMapper.alwaysApplyingNotNull()` | Use `always()` — null values no longer trigger adapter methods |
| `HttpMessageConverters` (deprecated) | `ClientHttpMessageConvertersCustomizer` or `ServerHttpMessageConvertersCustomizer` |
| `StreamBuilderFactoryBeanCustomizer` | `StreamsBuilderFactoryBeanConfigurer` (Spring Kafka) |
| `MockitoTestExecutionListener` | `MockitoExtension` |
| Classic uber-jar loader | Use default loader (remove `CLASSIC` config) |
| Embedded executable launch scripts | Gradle `application` plugin or systemd |

## Renamed Classes

| Old Name | New Name |
|----------|----------|
| `@JsonComponent` | `@JacksonComponent` |
| `JsonObjectSerializer` | `ObjectValueSerializer` |
| `JsonObjectDeserializer` | `ObjectValueDeserializer` |
| `Jackson2ObjectMapperBuilderCustomizer` | `JsonMapperBuilderCustomizer` |
| `RestClientBuilderCustomizer` | `Rest5ClientBuilderCustomizer` |

## Nullability Annotation Changes

Spring Framework 7.0 adopts JSpecify for nullability:

| Old | New |
|-----|-----|
| `org.springframework.lang.Nullable` | `org.jspecify.annotations.Nullable` |
| `org.springframework.lang.NonNull` | `org.jspecify.annotations.NonNull` |

This primarily affects Kotlin projects where null-safety is enforced at compile time. Java projects may see warnings but typically compile without changes.

## Jakarta EE 11 Baseline

Spring Boot 4.0 requires Jakarta EE 11:
- **Servlet 6.1** (Undertow is incompatible — removed)
- **JPA 3.2** (via Hibernate 7.1)
- **Bean Validation 3.1**

Verify that any third-party libraries you use are compatible with Jakarta EE 11.

## PropertyMapper API Changes

`PropertyMapper` no longer automatically handles null values:

**Before**:
```java
map.from(source::getValue)
    .whenNonNull()
    .to(target::setValue);
```

**After** (if you need null handling):
```java
map.always()
    .from(source::getValue)
    .whenNonNull()
    .to(target::setValue);
```

## HTTP Client Changes

- `HttpMessageConverters` is deprecated — use specific customizers
- `RestClient` and `WebClient` configurations may need updates for Jackson 3 message converters
- `@HttpExchange` interfaces work but verify generated client implementations

## Persistence Module

A new `spring-boot-persistence` module contains general persistence code. If you have direct dependencies on persistence-related auto-configuration classes, verify their new package locations.

## Migration Checklist

1. Search for `org.springframework.boot.BootstrapRegistry` — update to `...bootstrap.BootstrapRegistry`
2. Search for `org.springframework.boot.env.EnvironmentPostProcessor` — update import
3. Search for `PropertyMapper.alwaysApplyingNotNull` — replace with `always()`
4. Search for `HttpMessageConverters` — migrate to customizer pattern
5. Search for `StreamBuilderFactoryBeanCustomizer` — rename to `StreamsBuilderFactoryBeanConfigurer`
6. Search for `org.springframework.lang.Nullable` — consider migrating to JSpecify (especially for Kotlin)
7. Verify all third-party libraries support Jakarta EE 11 / Servlet 6.1
8. Check `@PropertyMapping` import if used in test auto-configuration
