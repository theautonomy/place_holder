# Breaking Changes — Spring Boot 3.5

## Boolean Configuration Properties

Spring Boot 3.5 enforces strict boolean validation. Property values must be exactly `true` or `false`.

**Previously accepted** (now rejected):
- `yes`, `no`
- `on`, `off`
- `1`, `0`

Search all property files for boolean properties and ensure they use `true` or `false`.

## Profile Name Validation

Spring profiles are now validated. Allowed characters:
- Letters (`a-z`, `A-Z`)
- Digits (`0-9`)
- Dashes (`-`) and underscores (`_`) — but not at start or end
- As of 3.5.1: `.`, `+`, `@` are also allowed

If validation causes issues, it can be disabled with `spring.profiles.validate=false` (not recommended long-term).

## TaskExecutor Bean Rename

Only `applicationTaskExecutor` is auto-configured. Code referencing `taskExecutor` by name will fail.

**Before**:
```java
@Qualifier("taskExecutor")
private TaskExecutor executor;
```

**After**:
```java
@Qualifier("applicationTaskExecutor")
private TaskExecutor executor;
```

If you need the old alias, register a `BeanFactoryPostProcessor`:
```java
@Bean
static BeanFactoryPostProcessor taskExecutorAlias() {
    return factory -> factory.registerAlias("applicationTaskExecutor", "taskExecutor");
}
```

## Actuator Heapdump Endpoint

The heapdump endpoint now defaults to `access=NONE`. Both exposure **and** access must be configured:

```properties
management.endpoint.heapdump.access=UNRESTRICTED
management.endpoints.web.exposure.include=heapdump
```

## TestRestTemplate Redirect Behavior

`TestRestTemplate` now aligns with standard `RestTemplate` redirect settings.

| Deprecated | Replacement |
|-----------|-------------|
| `HttpOption.ENABLE_REDIRECTS` | `TestRestTemplate.withRedirects()` |

Tests relying on specific redirect behavior may need updating.

## Redis URL + Database Property

When `spring.data.redis.url` is set, `spring.data.redis.database` is now **ignored**. The database must be specified in the URL:

```properties
# Before (database property worked alongside url)
spring.data.redis.url=redis://localhost:6379
spring.data.redis.database=2

# After (include database in URL)
spring.data.redis.url=redis://localhost:6379/2
```

## Prometheus Pushgateway

Coordinates and property names changed:

| Before | After |
|--------|-------|
| `io.prometheus:simpleclient_pushgateway` | `io.prometheus:prometheus-metrics-exporter-pushgateway` |
| `management.prometheus.metrics.export.pushgateway.base-url` | `management.prometheus.metrics.export.pushgateway.address` |

The `address` property format is `host:port` (not a full URL).

## spring-boot-parent Module Removed

`spring-boot-parent` is no longer published. If your project uses it as a parent POM, switch to `spring-boot-starter-parent` or manage dependencies directly.

## ECS Structured Logging Format

The ECS structured logging JSON output has been updated to a nested format. If you have log parsing pipelines that depend on the exact JSON structure, they may need updating.
