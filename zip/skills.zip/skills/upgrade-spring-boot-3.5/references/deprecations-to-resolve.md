# Deprecations to Resolve in Spring Boot 3.5

Resolving these deprecations in 3.5 is critical preparation for Spring Boot 4.0, which removes all APIs deprecated in Boot 3.x.

## Annotations Removed in 4.0

| Deprecated in 3.x | Replacement (use now) |
|-------------------|----------------------|
| `@MockBean` | `@MockitoBean` (`o.s.test.context.bean.override.mockito`) |
| `@SpyBean` | `@MockitoSpyBean` (`o.s.test.context.bean.override.mockito`) |

These were deprecated in 3.4 and **removed entirely** in 4.0. Fix them now while both work.

## Classes and Conditions

| Deprecated | Replacement |
|-----------|-------------|
| `ConditionalOutcome.inverse()` | No direct replacement — refactor condition logic |
| `o.s.boot.autoconfigure.security.servlet.RequestMatcherProvider` | `o.s.boot.actuate.autoconfigure.security.servlet.RequestMatcherProvider` |
| `ClientsConfiguredCondition` | `@ConditionalOnOAuth2ClientRegistrationProperties` |
| `IssuerUriCondition` | `@ConditionalOnIssuerLocationJwtDecoder` |
| `KeyValueCondition` | `@ConditionalOnPublicKeyJwtDecoder` |
| `OnEnabledDevToolsCondition` | `@ConditionalOnEnabledDevTools` |
| `OAuth2ClientAutoConfiguration` (servlet package) | `o.s.boot.autoconfigure.security.oauth2.client.OAuth2ClientAutoConfiguration` |

## Configuration Properties

| Deprecated Property | Replacement |
|--------------------|-------------|
| `spring.mvc.converters.preferred-json-mapper` | `spring.http.converters.preferred-json-mapper` |
| `spring.codec.log-request-details` | `spring.http.codecs.log-request-details` |
| `spring.codec.max-in-memory-size` | `spring.http.codecs.max-in-memory-size` |

## Methods and APIs

| Deprecated | Replacement |
|-----------|-------------|
| `LoggingSystemProperties.getDefaultCharset()` | `getDefaultConsoleCharset()` or `getDefaultFileCharset()` |
| `ThreadPoolTaskSchedulerBuilder` multi-param constructor | Use default constructor with fluent setters |
| `KafkaConnectionDetails` bootstrap server methods | Use chained method calls |
| `ConnectionDetailsFactories` default constructor | Use constructor accepting `ClassLoader` |
| `HttpOption.ENABLE_REDIRECTS` | `TestRestTemplate.withRedirects()` |

## Removed Features

These are gone in 3.5 (not just deprecated):

- **SignalFX support** — deprecated per Micrometer deprecation
- **Zipkin `URLConnectionSender`** — support removed

## Why This Matters

Spring Boot 4.0 removes everything deprecated in 3.x. If you skip deprecation cleanup:
- Code that compiles on 3.5 with warnings will **fail to compile** on 4.0
- Properties that work with warnings on 3.5 will be **silently ignored** on 4.0

Fix all deprecation warnings on 3.5 before attempting the 4.0 upgrade.
