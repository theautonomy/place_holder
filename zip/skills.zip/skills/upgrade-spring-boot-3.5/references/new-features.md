# New Features — Spring Boot 3.5

Notable new features available after upgrading. These are optional to adopt but worth knowing about.

## Servlet and Filter Registration Annotations

New `@ServletRegistration` and `@FilterRegistration` annotations provide a cleaner alternative to registration beans:

```java
@FilterRegistration(urlPatterns = "/api/*")
public class MyFilter implements Filter { ... }
```

## Multi-property Environment Variable Loading

Load multiple properties from a single environment variable:

```properties
spring.config.import=env:MY_CONFIGURATION
```

The environment variable can contain properties or YAML format content.

## WebClient Configuration Properties

Global timeout and redirect settings are now configurable via properties:

```properties
spring.http.client.connect-timeout=5s
spring.http.client.read-timeout=30s
```

Follow redirects is enabled by default for WebClient (aligning with blocking clients).

## Bean Background Initialization

Auto-configured `bootstrapExecutor` enables bean background initialization out of the box, improving startup time for applications with slow-initializing beans.

## Structured Logging Improvements

New properties to control stack trace output in structured logging:

```properties
logging.structured.json.stacktrace.max-length=4096
logging.structured.json.stacktrace.root-first=true
```

## SSL Bundle Metrics

New metrics for monitoring SSL certificate expiry:

- `ssl.chains` — certificate chain counts and status
- `ssl.chain.expiry` — seconds until certificate expiration

Useful for alerting on certificate renewal.

## Quartz Job Triggering via Actuator

Jobs can now be triggered via HTTP POST:

```
POST /actuator/quartz/jobs/{groupName}/{jobName}
```

## OpenTelemetry Enhancements

- Support for `OTEL_RESOURCE_ATTRIBUTES` and `OTEL_SERVICE_NAME` environment variables
- `service.namespace` resource attribute from `spring.application.group`
- Custom `BatchSpanProcessor` bean support
- Span export configuration properties

## Conditional Annotation Improvements

- `@ConditionalOnBooleanProperty` annotation for boolean property checks
- `@ConditionalOnProperty` and `@ConditionalOnBooleanProperty` are now `@Repeatable`
- `@ConditionalOnBean` / `@ConditionalOnMissingBean` support generic return types

## Redis ReadFrom Configuration

```properties
spring.data.redis.lettuce.read-from=REPLICA_PREFERRED
```

## Docker Compose and Testcontainers

- LLdap container support (`lldap/lldap`)
- Service Connection SSL support for Cassandra, Couchbase, Elasticsearch, Kafka, MongoDB, RabbitMQ, Redis

## Cloud Native Buildpacks

- Default builder switched to `paketobuildpacks/builder-noble-java-tiny`
- Docker `config.json` authentication support with credential helpers
