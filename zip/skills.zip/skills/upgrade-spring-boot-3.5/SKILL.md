---
name: upgrade-spring-boot-3.5
description: Upgrade a Spring Boot 3.x application to 3.5 (latest patch) using OpenRewrite automated migration recipes, with post-migration manual fixes for breaking changes. Supports both Maven and Gradle projects. Use this as a preparation step before migrating to Spring Boot 4.0.
disable-model-invocation: true
user-invocable: true
allowed-tools: Bash(git:*) Bash(mvn:*) Bash(gradle:*) Bash(./gradlew:*) Bash(java:*) Bash(./mvnw:*) Bash(bash:*) Read Grep Glob
argument-hint: "[branch-name]"
---

# Upgrade Spring Boot to 3.5

This skill automates the migration of a Spring Boot 3.0–3.4 application to Spring Boot 3.5 (latest patch) using the OpenRewrite community recipe, followed by manual fixes for breaking changes. This is the recommended preparation step before migrating to Spring Boot 4.0.

## What this migration covers

The OpenRewrite recipe (`UpgradeSpringBoot_3_5`) applies these transformations:
- Spring Boot 3.5.x dependency updates (parent, plugins, starters)
- Spring Framework 6.2, Spring Security 6.5, Spring Data 2025.0 upgrades
- Spring Boot properties migration to 3.5 format
- Spring Cloud 2025 compatibility updates
- Prometheus Pushgateway coordinate migration
- Deprecated API replacements

## Prerequisites

- Java 17+ installed
- Maven 3.6.3+ or Gradle 7.6+
- Spring Boot 3.0–3.4 project
- Clean git working tree (no uncommitted changes)

## Steps

### 1. Verify prerequisites

**Detect build tool**: Check for `build.gradle` / `build.gradle.kts` (Gradle) or `pom.xml` (Maven). Set the build tool for all subsequent steps.

**Verify toolchain versions**:

```
java -version
```

For Maven projects:
```
mvn --version
```

For Gradle projects:
```
./gradlew --version
```

Verify:
- Java is 17+
- Maven is 3.6.3+ or Gradle is 7.6+

If toolchain versions are insufficient, warn the user and stop.

**Check git status**:
```
git status
```

If there are uncommitted changes, warn the user and ask whether to proceed or stash changes first.

**Verify Spring Boot version**: Parse `pom.xml` or `build.gradle` to confirm the current Spring Boot version is 3.0–3.4. If it is already 3.5+, inform the user and stop. If it is already 4.x, suggest using the `upgrade-spring-boot-4` skill instead.

### 2. Create a new branch

Create and switch to a new branch for the upgrade. Use the argument if provided, otherwise default to `upgrade/spring-boot-3.5`:

```
git checkout -b ${branch-name:-upgrade/spring-boot-3.5}
```

### 3. Run the OpenRewrite migration recipe

Run the bundled script which auto-detects the build tool and executes the appropriate OpenRewrite recipe:

```bash
bash .claude/skills/upgrade-spring-boot-3.5/scripts/run-openrewrite-boot35.sh
```

This may take several minutes as it downloads recipe artifacts and analyzes the codebase.

If the command fails, report the error to the user and suggest troubleshooting steps.

### 4. Review the changes

After the recipe completes, review what was modified:

```
git diff --stat
git diff
```

Summarize the changes for the user, organized by category:
- **Build file changes**: dependency version updates, plugin updates
- **Java source changes**: deprecated API replacements
- **Properties changes**: property key renames/updates
- **Test changes**: test-related updates

### 5. Post-OpenRewrite manual fixes

After reviewing OpenRewrite changes, scan for issues that OpenRewrite doesn't fully handle.

**Boolean configuration properties**: Search for boolean properties that use values other than `true` or `false` (e.g. `yes`, `on`, `1`). Boot 3.5 enforces strict `true`/`false` validation.

```
# Scan application properties for potential boolean issues
```

**Profile name validation**: Check for Spring profiles containing characters other than letters, digits, dashes, and underscores. Profiles cannot start or end with `-` or `_`. (As of 3.5.1, `.`, `+`, and `@` are also allowed.)

**TaskExecutor bean name**: If your code references a bean named `taskExecutor`, update it to `applicationTaskExecutor`. Only `applicationTaskExecutor` is auto-configured in 3.5.

```
# Search for taskExecutor bean references
```

**Actuator heapdump endpoint**: If you use the heapdump endpoint, note that it now defaults to `access=NONE`. You must configure both exposure and access:

```properties
management.endpoint.heapdump.access=UNRESTRICTED
management.endpoints.web.exposure.include=heapdump
```

**TestRestTemplate redirect behavior**: If tests rely on `TestRestTemplate` redirect handling, check for `HttpOption.ENABLE_REDIRECTS` usage — it is deprecated. Use `TestRestTemplate.withRedirects()` instead.

**Redis URL + database property**: If you set both `spring.data.redis.url` and `spring.data.redis.database`, note that `database` is now ignored when `url` is set. Include the database in the URL instead.

**Prometheus Pushgateway** (if used): Replace `io.prometheus:simpleclient_pushgateway` with `io.prometheus:prometheus-metrics-exporter-pushgateway`. Update property `management.prometheus.metrics.export.pushgateway.base-url` to `pushgateway.address` (format: `host:port`).

**Property renames**: Verify these renames were applied:

| Boot 3.4 | Boot 3.5 |
|----------|----------|
| `spring.mvc.converters.preferred-json-mapper` | `spring.http.converters.preferred-json-mapper` |
| `spring.codec.*` | `spring.http.codecs.*` |

**spring-boot-parent removal**: If your project uses `spring-boot-parent` as a parent POM (not `spring-boot-starter-parent`), note that `spring-boot-parent` is no longer published. Replace with your own dependency management.

### 6. Verify the build compiles

Run a compilation check to verify the migration didn't break the build:

**Maven**:
```
mvn compile -q
```

**Gradle**:
```
./gradlew compileJava
```

If compilation fails, analyze the errors against the troubleshooting table below. Apply fixes and re-compile until clean.

### 7. Run tests (if requested)

Only run tests if the user explicitly asks:

**Maven**:
```
mvn test
```

**Gradle**:
```
./gradlew test
```

Report any test failures with context about what may need manual fixing.

### 8. Present results

Provide the user with a summary:
- List of all files modified
- Key changes made by the recipe
- Manual fixes applied in post-OpenRewrite phases
- Any compilation or test failures that need manual attention
- Suggest next steps (review changes, fix remaining issues, commit when ready)
- If the goal is to migrate to Boot 4.0, mention the `upgrade-spring-boot-4` skill as the next step

Do NOT automatically commit. Let the user decide when they are satisfied with the changes.

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `InvalidConfigurationPropertyValueException` for booleans | Strict boolean validation in 3.5 | Change property values to `true` or `false` |
| `InvalidProfileException` | Profile name contains invalid characters | Rename profile to use only letters, digits, `-`, `_` |
| `NoSuchBeanDefinitionException: taskExecutor` | Bean renamed in 3.5 | Use `applicationTaskExecutor` instead |
| `TestRestTemplate` redirect failures | Redirect behavior changed | Use `TestRestTemplate.withRedirects()` |
| Heapdump endpoint returns 404 | Now defaults to `access=NONE` | Set `management.endpoint.heapdump.access=UNRESTRICTED` |
| Redis database not selected | `database` property ignored when `url` is set | Include database in the URL (e.g. `redis://host:6379/2`) |
| `ClassNotFoundException: simpleclient_pushgateway` | Prometheus coordinates changed | Use `prometheus-metrics-exporter-pushgateway` |
| `spring-boot-parent` not found | Module no longer published | Switch to `spring-boot-starter-parent` or manage dependencies directly |

## Notable Dependency Updates in 3.5

| Dependency | Version |
|-----------|---------|
| Spring Framework | 6.2.x |
| Spring Security | 6.5.x |
| Spring Data | 2025.0.x |
| Micrometer | 1.15.x |
| JUnit | 5.12.x |
| Testcontainers | 1.21.x |
| Liquibase | 4.31.x |
| Elasticsearch Client | 8.17.x |
| Kafka Client | 3.9.x |
| MongoDB Driver | 5.4.x |

## Official Sources

- **Release Notes**: https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-3.5-Release-Notes
- **OpenRewrite Recipe**: https://docs.openrewrite.org/recipes/java/spring/boot3/upgradespringboot_3_5-community-edition
- **Upgrading Docs**: https://docs.spring.io/spring-boot/upgrading.html

## Reference File Index

Read these reference files when you encounter specific issues during the upgrade:

| File | When to read |
|------|-------------|
| `references/breaking-changes.md` | Boolean validation errors, profile name issues, taskExecutor failures, Redis/Prometheus changes |
| `references/deprecations-to-resolve.md` | Preparing for Boot 4.0 — all deprecated APIs, properties, and classes to fix now |
| `references/new-features.md` | After upgrade — optional new features available in 3.5 |

## Next Step

After successfully upgrading to 3.5 and resolving all deprecation warnings, your project is ready for Spring Boot 4.0 migration. Use the `/upgrade-spring-boot-4` skill for that step.
