#!/usr/bin/env bash
#
# Run the OpenRewrite Spring Boot 3.5 upgrade recipe.
#
# Usage:
#   ./scripts/run-openrewrite.sh
#
# Requires: Maven project with pom.xml in current directory.

set -euo pipefail

RECIPE="org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_5"
RECIPE_ARTIFACT="org.openrewrite.recipe:rewrite-spring:RELEASE"

echo "Running OpenRewrite recipe: ${RECIPE}"
echo ""

if [ -f "pom.xml" ]; then
    echo "Detected Maven project"
    mvn -U org.openrewrite.maven:rewrite-maven-plugin:run \
        -Drewrite.recipeArtifactCoordinates="${RECIPE_ARTIFACT}" \
        -Drewrite.activeRecipes="${RECIPE}" \
        -Drewrite.exportDatatables=true
elif [ -f "build.gradle" ] || [ -f "build.gradle.kts" ]; then
    echo "Detected Gradle project"
    echo ""
    echo "Add the following to build.gradle temporarily, then run: ./gradlew rewriteRun"
    echo ""
    echo '  plugins {'
    echo '      id("org.openrewrite.rewrite") version("latest.release")'
    echo '  }'
    echo '  rewrite {'
    echo "      activeRecipe(\"${RECIPE}\")"
    echo '  }'
    echo '  dependencies {'
    echo '      rewrite("org.openrewrite.recipe:rewrite-spring:latest.release")'
    echo '  }'
    exit 0
else
    echo "ERROR: No pom.xml or build.gradle found in current directory."
    exit 1
fi

echo ""
echo "Done. Review changes with: git diff --stat"
