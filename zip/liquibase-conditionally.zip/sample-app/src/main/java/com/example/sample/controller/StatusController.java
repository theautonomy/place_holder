package com.example.sample.controller;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import com.example.liquibase.starter.service.LiquibaseChangesetChecker;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class StatusController {

    private final DataSource dataSource;
    private final LiquibaseChangesetChecker changesetChecker;

    public StatusController(DataSource dataSource, LiquibaseChangesetChecker changesetChecker) {
        this.dataSource = dataSource;
        this.changesetChecker = changesetChecker;
    }

    @GetMapping("/status")
    public Map<String, Object> getStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("hasNewChangesets", changesetChecker.hasNewChangesets());
        status.put("databaseTables", getDatabaseTables());
        status.put("message", "Sample application using Liquibase Conditional Starter");
        return status;
    }

    private List<String> getDatabaseTables() {
        List<String> tables = new ArrayList<>();
        try (Connection connection = dataSource.getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            ResultSet resultSet = metaData.getTables(null, null, "%", new String[] {"TABLE"});

            while (resultSet.next()) {
                String tableName = resultSet.getString("TABLE_NAME");
                if (!tableName.startsWith("DATABASECHANGELOG")) {
                    tables.add(tableName);
                }
            }
        } catch (Exception e) {
            tables.add("Error retrieving tables: " + e.getMessage());
        }
        return tables;
    }
}
