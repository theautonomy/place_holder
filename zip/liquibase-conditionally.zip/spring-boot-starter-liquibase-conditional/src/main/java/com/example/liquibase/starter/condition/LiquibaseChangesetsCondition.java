package com.example.liquibase.starter.condition;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import liquibase.Contexts;
import liquibase.LabelExpression;
import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;
import liquibase.resource.ResourceAccessor;

public class LiquibaseChangesetsCondition extends SpringBootCondition {

    @Override
    public ConditionOutcome getMatchOutcome(
            ConditionContext context, AnnotatedTypeMetadata metadata) {
        try {
            // Try to get the primary DataSource (more flexible approach)
            DataSource dataSource;
            try {
                dataSource = context.getBeanFactory().getBean(DataSource.class);
            } catch (Exception e) {
                // If no primary DataSource available yet, we can't check changesets
                return ConditionOutcome.noMatch(
                        "Primary DataSource not available yet: " + e.getMessage());
            }

            String changeLogFile =
                    context.getEnvironment().getProperty("spring.liquibase.change-log");

            if (changeLogFile == null) {
                return ConditionOutcome.noMatch("No Liquibase changelog configured");
            }

            try (Connection connection = dataSource.getConnection()) {
                Database database =
                        DatabaseFactory.getInstance()
                                .findCorrectDatabaseImplementation(new JdbcConnection(connection));

                ResourceAccessor resourceAccessor =
                        new ClassLoaderResourceAccessor(
                                Thread.currentThread().getContextClassLoader());
                String changelogPath =
                        changeLogFile.startsWith("classpath:")
                                ? changeLogFile.substring(10)
                                : changeLogFile;

                @SuppressWarnings("deprecation")
                Liquibase liquibase = new Liquibase(changelogPath, resourceAccessor, database);

                int unrunChangeSets =
                        liquibase.listUnrunChangeSets(new Contexts(), new LabelExpression()).size();

                if (unrunChangeSets > 0) {
                    return ConditionOutcome.match("Found " + unrunChangeSets + " unrun changesets");
                } else {
                    return ConditionOutcome.noMatch("No unrun changesets found");
                }
            }
        } catch (Exception e) {
            return ConditionOutcome.noMatch("Error checking for changesets: " + e.getMessage());
        }
    }
}
