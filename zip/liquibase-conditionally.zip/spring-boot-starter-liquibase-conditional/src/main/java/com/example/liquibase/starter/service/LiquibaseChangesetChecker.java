package com.example.liquibase.starter.service;

import java.sql.Connection;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import liquibase.Contexts;
import liquibase.LabelExpression;
import liquibase.Liquibase;
import liquibase.changelog.ChangeSet;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ClassLoaderResourceAccessor;
import liquibase.resource.ResourceAccessor;

@Service
public class LiquibaseChangesetChecker {

    private static final Logger logger = LoggerFactory.getLogger(LiquibaseChangesetChecker.class);

    @Value("${spring.liquibase.change-log}")
    private String changeLogFile;

    private final DataSource dataSource;

    public LiquibaseChangesetChecker(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @SuppressWarnings("deprecation")
    public boolean hasNewChangesets() {
        try (Connection connection = dataSource.getConnection()) {
            Database database =
                    DatabaseFactory.getInstance()
                            .findCorrectDatabaseImplementation(new JdbcConnection(connection));

            ResourceAccessor resourceAccessor =
                    new ClassLoaderResourceAccessor(Thread.currentThread().getContextClassLoader());
            String changelogPath =
                    changeLogFile.startsWith("classpath:")
                            ? changeLogFile.substring(10)
                            : changeLogFile;

            Liquibase liquibase = new Liquibase(changelogPath, resourceAccessor, database);

            // Using deprecated method but suppressed warning since it's still the primary API
            java.util.List<ChangeSet> unrunChangeSets =
                    liquibase.listUnrunChangeSets(new Contexts(), new LabelExpression());

            logger.info("Found {} unrun changesets", unrunChangeSets.size());

            return !unrunChangeSets.isEmpty();

        } catch (Exception e) {
            logger.error("Error checking for new changesets", e);
            return false;
        }
    }
}
