package com.example.liquibase.starter.autoconfigure;

import javax.sql.DataSource;

import com.example.liquibase.starter.condition.ConditionalOnLiquibaseChangesets;
import com.example.liquibase.starter.service.LiquibaseChangesetChecker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import liquibase.integration.spring.SpringLiquibase;

@AutoConfiguration(before = LiquibaseAutoConfiguration.class)
@EnableConfigurationProperties(LiquibaseConditionalProperties.class)
public class LiquibaseConditionalAutoConfiguration {

    private static final Logger logger =
            LoggerFactory.getLogger(LiquibaseConditionalAutoConfiguration.class);

    @Value("${spring.liquibase.change-log}")
    private String changeLogFile;

    @Bean
    @Primary
    @ConditionalOnLiquibaseChangesets
    public SpringLiquibase liquibase(
            DataSource primaryDataSource,
            @Autowired(required = false) @Qualifier("liquibaseDataSource")
                    DataSource liquibaseDataSource) {

        logger.info("New changesets found, enabling Liquibase auto-configuration");
        SpringLiquibase liquibase = new SpringLiquibase();
        // Use liquibase DataSource if available, otherwise fall back to primary DataSource
        liquibase.setDataSource(
                liquibaseDataSource != null ? liquibaseDataSource : primaryDataSource);
        liquibase.setChangeLog(changeLogFile);
        liquibase.setShouldRun(true);
        return liquibase;
    }

    @Bean
    @Primary
    @ConditionalOnMissingBean(SpringLiquibase.class)
    public SpringLiquibase noOpLiquibase(DataSource primaryDataSource) {
        logger.info("No new changesets found, disabling Liquibase auto-configuration");
        SpringLiquibase liquibase = new SpringLiquibase();
        liquibase.setDataSource(primaryDataSource);
        liquibase.setChangeLog(changeLogFile);
        liquibase.setShouldRun(false);
        return liquibase;
    }

    @Bean
    public LiquibaseChangesetChecker liquibaseChangesetChecker(DataSource primaryDataSource) {
        return new LiquibaseChangesetChecker(primaryDataSource);
    }
}
