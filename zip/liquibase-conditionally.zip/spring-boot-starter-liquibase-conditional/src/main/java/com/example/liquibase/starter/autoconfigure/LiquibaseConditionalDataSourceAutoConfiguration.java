package com.example.liquibase.starter.autoconfigure;

import javax.sql.DataSource;

import com.example.liquibase.starter.condition.ConditionalOnLiquibaseChangesets;
import com.zaxxer.hikari.HikariDataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(LiquibaseConditionalProperties.class)
public class LiquibaseConditionalDataSourceAutoConfiguration {

    @Bean
    @Qualifier("liquibaseDataSource")
    @ConditionalOnLiquibaseChangesets
    @ConditionalOnProperty(prefix = "liquibase.conditional.datasource", name = "url")
    public DataSource liquibaseDataSource(LiquibaseConditionalProperties properties) {

        LiquibaseConditionalProperties.DataSourceProperties dsProps = properties.getDatasource();

        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl(dsProps.getUrl());
        dataSource.setUsername(dsProps.getUsername());
        dataSource.setPassword(dsProps.getPassword());
        dataSource.setDriverClassName(dsProps.getDriverClassName());

        return dataSource;
    }
}
