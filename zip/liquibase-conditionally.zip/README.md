# Spring Boot Starter - Liquibase Conditional

A reusable Spring Boot starter that conditionally enables Liquibase based on changeset availability. This starter automatically disables Liquibase when there are no new changesets to execute, improving application startup performance.

## Project Structure

```
liquibase-conditionally/
├── spring-boot-starter-liquibase-conditional/    # The reusable starter library
└── sample-app/                                   # Example application using the starter
```

## Features

- **Conditional Liquibase Execution**: Automatically checks for new changesets before running Liquibase
- **Optional Separate DataSource**: Configure dedicated DataSource for Liquibase operations 
- **Spring Boot Auto-Configuration**: Zero configuration required, works out of the box
- **Performance Optimization**: Skips Liquibase initialization when no changesets need to run
- **Production Ready**: Handles edge cases and provides proper logging

## How to Use This Starter

### 1. Add Dependency

Add the starter to your Spring Boot application:

**Maven:**
```xml
<dependency>
    <groupId>com.example</groupId>
    <artifactId>spring-boot-starter-liquibase-conditional</artifactId>
    <version>1.0.0</version>
</dependency>
```

**Gradle:**
```gradle
implementation 'com.example:spring-boot-starter-liquibase-conditional:1.0.0'
```

### 2. Basic Configuration

The starter works with minimal configuration. Just ensure you have your standard Liquibase setup:

```yaml
spring:
  # Your primary DataSource
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    username: sa
    password: password
  
  # Standard Liquibase configuration
  liquibase:
    change-log: classpath:db/changelog/db.changelog-master.xml
```

### 3. Optional: Separate Liquibase DataSource

For enhanced security or different database credentials:

```yaml
spring:
  # Your primary DataSource (for application use)
  datasource:
    url: jdbc:h2:file:./data/myapp
    driver-class-name: org.h2.Driver
    username: app_user
    password: app_password
  
  liquibase:
    change-log: classpath:db/changelog/db.changelog-master.xml

# Optional: Dedicated Liquibase DataSource
liquibase:
  conditional:
    datasource:
      url: jdbc:h2:file:./data/myapp
      driver-class-name: org.h2.Driver
      username: liquibase_user
      password: liquibase_password
```

### 4. Usage in Your Application

The starter provides a service to check changeset status:

```java
@RestController
public class StatusController {
    
    @Autowired
    private LiquibaseChangesetChecker changesetChecker;
    
    @GetMapping("/api/liquibase-status")
    public Map<String, Object> getLiquibaseStatus() {
        return Map.of(
            "hasNewChangesets", changesetChecker.hasNewChangesets(),
            "message", "Liquibase conditional starter is active"
        );
    }
}
```

### 5. Behavior

The starter automatically:

- **First run** (or when new changesets exist): Liquibase runs normally, applies all changesets
- **Subsequent runs** (when no new changesets): Liquibase is disabled, faster startup

**Logs when changesets found:**
```
INFO - New changesets found, enabling Liquibase auto-configuration
INFO - Running Changeset: db/changelog/changes/001-initial-schema.xml
```

**Logs when no changesets:**
```
INFO - No new changesets found, disabling Liquibase auto-configuration  
INFO - Liquibase did not run because 'shouldRun' property was set to false
```

## How It Works

1. **Auto-Configuration**: Spring Boot automatically detects and configures the starter
2. **Condition Evaluation**: Before Liquibase runs, checks for unrun changesets
3. **Conditional Beans**: Creates appropriate Liquibase bean (enabled/disabled) based on changeset availability
4. **DataSource Management**: Optionally uses separate DataSource for Liquibase operations

## Sample Application

This repository includes a sample application (`sample-app/`) that demonstrates the starter in action.

### Running the Sample

1. **Build the entire project:**
   ```bash
   mvn clean install
   ```

2. **Run the sample application:**
   ```bash
   cd sample-app
   mvn spring-boot:run
   ```

3. **Test the API:**
   ```bash
   curl http://localhost:8082/api/status
   ```

### Testing Conditional Behavior

#### First Run (New Changesets Available)
```bash
# Delete database files to start fresh
cd sample-app
rm -rf sample-data/
mvn spring-boot:run
```
**Expected**: Liquibase will detect 2 new changesets and execute them.

#### Second Run (No New Changesets)
```bash
# Start the application again
mvn spring-boot:run
```
**Expected**: Liquibase will be disabled as no new changesets are available.

### Sample Application Features

- **REST API**: `/api/status` endpoint showing changeset status
- **H2 Console**: Available at `http://localhost:8082/h2-console`
- **Database**: File-based H2 database (`./sample-data/testdb`)
- **Sample Data**: Includes user table with sample records

## Development

### Building from Source

```bash
git clone <repository-url>
cd liquibase-conditionally
mvn clean install
```

### Using in Your Maven Build

Install to local repository:
```bash
mvn clean install
```

Then add the dependency to your project as shown in the usage section above.

## Requirements

- Java 17+
- Spring Boot 3.2.0+
- Liquibase 4.x

## License

[Add your license information here]
