<template>
  <div class="layout-default">
    <div class="top-accent" />
    <div class="content">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.layout-default {
  position: relative;
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-accent {
  height: 3px;
  background: linear-gradient(90deg, #22d3ee, #3b82f6, transparent);
  flex-shrink: 0;
}

.content {
  flex: 1;
  padding: 1.8rem 2.8rem;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.content :deep(h1) {
  font-family: 'Inter', sans-serif;
  font-size: 2rem;
  font-weight: 700;
  letter-spacing: -0.02em;
  color: #e6edf3;
  margin-bottom: 0.2rem;
  padding-bottom: 0.7rem;
  border-bottom: 1px solid #21262d;
}

/* Highlight the first word after # as cyan */
.content :deep(h1 em) {
  color: #22d3ee;
  font-style: normal;
}

.content :deep(h2) {
  font-size: 1.1rem;
  font-weight: 600;
  color: #22d3ee;
  margin-top: 1.2rem;
  margin-bottom: 0.4rem;
  font-family: 'Inter', sans-serif;
}

.content :deep(h3) {
  font-size: 0.75rem;
  font-weight: 600;
  font-family: 'JetBrains Mono', monospace;
  color: #7d8590;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin-top: 1rem;
  margin-bottom: 0.3rem;
}

/* Make pre/code blocks a bit more compact */
.content :deep(pre) {
  margin: 0.6rem 0 !important;
}
</style>
