<!--
  code-demo layout
  Left (60%): slide title + code block  (default slot)
  Right (40%): explanation / output     (::right:: slot)
-->
<template>
  <div class="layout-code-demo">
    <div class="top-accent" />
    <div class="inner">
      <!-- Code pane -->
      <div class="code-pane">
        <slot />
      </div>

      <!-- Explanation pane -->
      <div class="explain-pane">
        <div class="explain-header">
          <span class="explain-dot" />
          <span class="explain-label">{{ label }}</span>
        </div>
        <div class="explain-body">
          <slot name="right" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({ paneLabel: { default: 'Output / Notes' } })
const label = computed(() => props.paneLabel)
</script>

<style scoped>
.layout-code-demo {
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-accent {
  height: 3px;
  background: linear-gradient(90deg, #22d3ee, #3b82f6, transparent);
  flex-shrink: 0;
}

.inner {
  flex: 1;
  display: flex;
  min-height: 0;
}

/* ── Code pane (left 60%) ── */
.code-pane {
  flex: 0 0 60%;
  min-height: 0;
  padding: 1.2rem 1rem 1.2rem 2rem;
  display: flex;
  flex-direction: column;
  border-right: 1px solid #21262d;
  overflow: hidden;
}

.code-pane :deep(h1) {
  font-family: 'Inter', sans-serif;
  font-size: 1.4rem;
  font-weight: 700;
  color: #e6edf3;
  letter-spacing: -0.02em;
  margin-bottom: 0.6rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid #21262d;
  flex-shrink: 0;
}
.code-pane :deep(h2) {
  font-size: 0.85rem;
  font-weight: 600;
  color: #22d3ee;
  margin-top: 0.6rem;
  margin-bottom: 0.2rem;
  flex-shrink: 0;
}

/* Stretch all Slidev/Shiki wrappers so the pre can fill remaining height */
.code-pane :deep(.slidev-code),
.code-pane :deep(.slidev-code-wrapper),
.code-pane :deep(.shiki-container) {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.code-pane :deep(pre) {
  flex: 1;
  min-height: 0;
  margin: 0 !important;
  font-size: 0.78rem !important;
  line-height: 1.55 !important;
  overflow-y: auto !important;
  overflow-x: auto !important;
}

/* ── Explain pane (right 40%) ── */
.explain-pane {
  flex: 0 0 40%;
  display: flex;
  flex-direction: column;
  background: #161b22;
  overflow: hidden;
}

.explain-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.55rem 1.2rem;
  background: #1c2128;
  border-bottom: 1px solid #21262d;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.72rem;
  color: #7d8590;
  flex-shrink: 0;
}
.explain-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #22d3ee;
  flex-shrink: 0;
}
.explain-label { color: #e6edf3; }

.explain-body {
  flex: 1;
  padding: 1.2rem 1.5rem;
  overflow: auto;
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}

.explain-body :deep(h2) {
  font-size: 0.85rem;
  font-weight: 600;
  font-family: 'JetBrains Mono', monospace;
  color: #22d3ee;
  margin: 0.8rem 0 0.3rem;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}
.explain-body :deep(h2:first-child) { margin-top: 0; }

.explain-body :deep(p) {
  font-size: 0.88rem;
  color: #7d8590;
  margin: 0 0 0.4rem;
  line-height: 1.6;
}
.explain-body :deep(ul) { margin: 0.3rem 0; }
.explain-body :deep(ul li) {
  font-size: 0.86rem;
  color: #e6edf3;
  margin-bottom: 0.3rem;
}
.explain-body :deep(pre) {
  font-size: 0.76rem !important;
  margin: 0.4rem 0 !important;
  background: #0d1117 !important;
}
.explain-body :deep(strong) { color: #e6edf3; }
</style>
