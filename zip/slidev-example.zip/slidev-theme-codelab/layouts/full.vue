<!-- Full-bleed layout — ideal for diagrams, charts, and large visuals -->
<template>
  <div class="layout-full">
    <div class="top-accent" />
    <div class="title-bar" v-if="$slots.title">
      <slot name="title" />
    </div>
    <div class="content">
      <FitDiagram>
        <slot />
      </FitDiagram>
    </div>
  </div>
</template>

<style scoped>
.layout-full {
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-accent {
  height: 3px;
  background: linear-gradient(90deg, #22d3ee, #3b82f6, transparent);
  flex-shrink: 0;
}

.title-bar {
  padding: 0.6rem 2rem;
  border-bottom: 1px solid #21262d;
  flex-shrink: 0;
}
.title-bar :deep(h1) {
  font-size: 1rem;
  font-weight: 600;
  font-family: 'JetBrains Mono', monospace;
  color: #7d8590;
  margin: 0;
}
.title-bar :deep(h1 em) { color: #22d3ee; font-style: normal; }

.content {
  flex: 1;
  padding: 0.8rem 1rem;
  display: flex;
  min-height: 0;
  overflow: hidden;
}
</style>
