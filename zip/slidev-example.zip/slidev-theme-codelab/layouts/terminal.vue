<!--
  terminal layout — the entire slide looks like a terminal window
-->
<template>
  <div class="layout-terminal">
    <div class="window">
      <!-- Title bar -->
      <div class="titlebar">
        <span class="dot dot-red" />
        <span class="dot dot-yellow" />
        <span class="dot dot-green" />
        <span class="title">{{ title }}</span>
        <span class="shell-info">{{ shell }}</span>
      </div>

      <!-- Terminal body -->
      <div class="body">
        <div class="prompt-line" v-if="prompt">
          <span class="prompt-user">{{ user }}</span>
          <span class="prompt-sep">@</span>
          <span class="prompt-host">{{ host }}</span>
          <span class="prompt-path"> {{ path }}</span>
          <span class="prompt-symbol"> $ </span>
          <span class="prompt-cmd">{{ prompt }}</span>
        </div>
        <slot />
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  title:  { default: 'Terminal' },
  shell:  { default: 'zsh — 120×36' },
  user:   { default: 'dev' },
  host:   { default: 'machine' },
  path:   { default: '~/project' },
  prompt: { default: '' },
})
</script>

<style scoped>
.layout-terminal {
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.8rem;
}

.window {
  width: 100%;
  height: 100%;
  border-radius: 10px;
  border: 1px solid #30363d;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  box-shadow: 0 25px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(34,211,238,0.06);
}

/* ── Title bar ── */
.titlebar {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.6rem 1rem;
  background: #161b22;
  border-bottom: 1px solid #21262d;
  flex-shrink: 0;
}
.dot { width: 11px; height: 11px; border-radius: 50%; }
.dot-red    { background: #f85149; }
.dot-yellow { background: #e3b341; }
.dot-green  { background: #3fb950; }
.title {
  flex: 1;
  text-align: center;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.75rem;
  color: #7d8590;
  margin-left: -3rem;
}
.shell-info {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.7rem;
  color: #484f58;
}

/* ── Terminal body ── */
.body {
  flex: 1;
  background: #0d1117;
  padding: 1.2rem 1.5rem;
  overflow: auto;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.85rem;
  line-height: 1.65;
}

/* ── Prompt ── */
.prompt-line {
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 0.6rem;
  font-size: 0.87rem;
}
.prompt-user   { color: #3fb950; font-weight: 600; }
.prompt-sep    { color: #484f58; }
.prompt-host   { color: #22d3ee; font-weight: 600; }
.prompt-path   { color: #7d8590; }
.prompt-symbol { color: #484f58; }
.prompt-cmd    { color: #e6edf3; }

/* ── Slot content styles ── */
.body :deep(h1) {
  font-family: 'JetBrains Mono', monospace;
  font-size: 1.1rem;
  font-weight: 600;
  color: #22d3ee;
  margin: 0.8rem 0 0.4rem;
  letter-spacing: 0;
}
.body :deep(h1::before) { content: '# '; color: #484f58; }

.body :deep(h2) {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.88rem;
  font-weight: 600;
  color: #e3b341;
  margin: 0.6rem 0 0.3rem;
}
.body :deep(h2::before) { content: '## '; color: #484f58; }

.body :deep(p) {
  color: #e6edf3;
  margin: 0.2rem 0;
  opacity: 0.85;
}

.body :deep(ul) { margin: 0.3rem 0; }
.body :deep(ul li) { color: #e6edf3; opacity: 0.85; margin-bottom: 0.2rem; }
.body :deep(ul li::before) { content: '  ▸ '; color: #3fb950; position: static; }

.body :deep(pre) {
  background: #161b22 !important;
  border: 1px solid #21262d !important;
  border-radius: 6px !important;
  font-size: 0.82rem !important;
  margin: 0.6rem 0 !important;
}

.body :deep(strong) { color: #3fb950; font-weight: 600; }
.body :deep(em)     { color: #f97316; font-style: normal; }

/* Output / success line */
.body :deep(blockquote) {
  border-left: 2px solid #3fb950;
  padding: 0.4em 0.8em;
  background: rgba(63,185,80,0.08);
  border-radius: 0 4px 4px 0;
  color: #3fb950;
  font-size: 0.85rem;
  margin: 0.4rem 0;
}
.body :deep(blockquote p) { color: #3fb950; opacity: 1; margin: 0; }
</style>
