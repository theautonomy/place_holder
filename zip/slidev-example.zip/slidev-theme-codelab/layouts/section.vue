<template>
  <div class="layout-section">
    <div class="grid-bg" />
    <div class="glow" />
    <div class="content">
      <div class="section-label">
        <span class="hash">#</span> {{ label }}
      </div>
      <slot />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({ sectionNumber: String })
const label = computed(() => props.sectionNumber || 'section')
</script>

<style scoped>
.layout-section {
  position: relative;
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.grid-bg {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(34,211,238,0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(34,211,238,0.05) 1px, transparent 1px);
  background-size: 48px 48px;
  pointer-events: none;
}

.glow {
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse at center, rgba(34,211,238,0.1) 0%, transparent 65%);
  pointer-events: none;
}

.content {
  position: relative;
  z-index: 1;
  text-align: center;
  padding: 2rem 4rem;
}

.section-label {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.8rem;
  color: #484f58;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  margin-bottom: 1rem;
}
.hash { color: #22d3ee; margin-right: 0.3em; }

.content :deep(h1) {
  font-family: 'Inter', sans-serif;
  font-size: 3rem;
  font-weight: 800;
  letter-spacing: -0.03em;
  color: #e6edf3;
  line-height: 1.1;
  margin-bottom: 0.6rem;
}
.content :deep(h1 em) {
  color: #22d3ee;
  font-style: normal;
}

.content :deep(h2) {
  font-family: 'JetBrains Mono', monospace;
  font-size: 1rem;
  font-weight: 400;
  color: #7d8590;
  margin-top: 0.4rem;
}

.content :deep(p) {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.9rem;
  color: #484f58;
  margin-top: 0.8rem;
}
</style>
