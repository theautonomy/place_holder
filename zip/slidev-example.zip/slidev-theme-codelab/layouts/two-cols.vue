<template>
  <div class="layout-two-cols">
    <div class="top-accent" />
    <div class="inner">
      <div class="col col-left">
        <slot />
      </div>
      <div class="divider" />
      <div class="col col-right">
        <slot name="right" />
      </div>
    </div>
  </div>
</template>

<style scoped>
.layout-two-cols {
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-accent {
  height: 3px;
  background: linear-gradient(90deg, #22d3ee, #3b82f6, transparent);
  flex-shrink: 0;
}

.inner {
  flex: 1;
  display: flex;
  padding: 1.2rem 1.5rem;
  gap: 0;
  min-height: 0;
  overflow: hidden;
}

.col {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
}
.col-left  { padding-right: 1.2rem; }
.col-right { padding-left: 1.2rem; }

.divider {
  width: 1px;
  background: linear-gradient(180deg, transparent 5%, #30363d 30%, #30363d 70%, transparent 95%);
  flex-shrink: 0;
}

.col :deep(h1) {
  font-family: 'Inter', sans-serif;
  font-size: 1.4rem;
  font-weight: 700;
  color: #e6edf3;
  letter-spacing: -0.02em;
  margin: 0 0 0.5rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid #21262d;
  flex-shrink: 0;
}
.col :deep(h2) {
  font-size: 0.9rem;
  font-weight: 600;
  color: #22d3ee;
  margin: 0.7rem 0 0.3rem;
  flex-shrink: 0;
}
.col :deep(h3) {
  font-size: 0.72rem;
  font-family: 'JetBrains Mono', monospace;
  color: #7d8590;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin: 0.6rem 0 0.2rem;
  flex-shrink: 0;
}
.col :deep(pre) {
  margin: 0.4rem 0 !important;
  font-size: 0.76rem !important;
  line-height: 1.5 !important;
}
.col :deep(table) { font-size: 0.78rem; }
.col :deep(thead th) { padding: 0.35em 0.7em; }
.col :deep(tbody td) { padding: 0.3em 0.7em; }
.col :deep(p) { margin: 0.25rem 0; font-size: 0.88rem; }
.col :deep(ul li) { margin-bottom: 0.25rem; font-size: 0.88rem; }
</style>
