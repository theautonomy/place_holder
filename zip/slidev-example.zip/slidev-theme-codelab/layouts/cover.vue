<template>
  <div class="layout-cover">
    <!-- Circuit grid background -->
    <div class="grid-bg" />
    <div class="grid-fade" />

    <!-- Cyan glow -->
    <div class="glow" />

    <!-- Top bar — file path breadcrumb -->
    <div class="top-bar">
      <span class="dot dot-red" /><span class="dot dot-yellow" /><span class="dot dot-green" />
      <span class="filepath">
        <span class="path-dim">~/</span>{{ $slidev.configs.repo || 'presentation' }}<span class="path-dim">/</span><span class="path-file">README.md</span>
      </span>
    </div>

    <!-- Main content -->
    <div class="content">
      <div class="tag-row" v-if="$slidev.configs.tags">
        <span v-for="tag in ($slidev.configs.tags || [])" :key="tag" class="tag">{{ tag }}</span>
      </div>
      <slot />
      <div class="meta-row">
        <span class="cursor">▋</span>
        <span v-if="$slidev.configs.author" class="meta">{{ $slidev.configs.author }}</span>
        <span v-if="$slidev.configs.date" class="meta-dim">{{ $slidev.configs.date }}</span>
      </div>
    </div>

    <!-- Bottom status bar -->
    <div class="status-bar">
      <span class="status-item status-branch">
        <span class="icon">⎇</span> {{ $slidev.configs.branch || 'main' }}
      </span>
      <span class="status-item" v-if="$slidev.configs.version">v{{ $slidev.configs.version }}</span>
      <span class="status-spacer" />
      <span class="status-item">{{ $slidev.configs.lang || 'TypeScript' }}</span>
      <span class="status-item status-accent">SLIDES</span>
    </div>
  </div>
</template>

<script setup>
defineProps({ background: String })
</script>

<style scoped>
.layout-cover {
  position: relative;
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* ── Circuit grid ── */
.grid-bg {
  position: absolute;
  inset: 0;
  background-image:
    linear-gradient(rgba(34,211,238,0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(34,211,238,0.06) 1px, transparent 1px);
  background-size: 48px 48px;
  pointer-events: none;
}
.grid-fade {
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse at 70% 40%, transparent 40%, #0d1117 75%);
  pointer-events: none;
}

/* ── Glow ── */
.glow {
  position: absolute;
  top: -10%;
  left: -5%;
  width: 55%;
  height: 65%;
  background: radial-gradient(ellipse, rgba(34,211,238,0.12) 0%, transparent 70%);
  filter: blur(60px);
  pointer-events: none;
}

/* ── Top bar ── */
.top-bar {
  position: relative;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.8rem 1.5rem;
  background: rgba(22,27,34,0.9);
  border-bottom: 1px solid #21262d;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.78rem;
}
.dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
.dot-red    { background: #f85149; }
.dot-yellow { background: #e3b341; }
.dot-green  { background: #3fb950; }
.filepath { margin-left: 0.8rem; color: #7d8590; }
.path-dim  { color: #484f58; }
.path-file { color: #e6edf3; font-weight: 500; }

/* ── Main content ── */
.content {
  position: relative;
  z-index: 2;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 1.5rem 3.5rem;
}

.tag-row {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1.2rem;
  flex-wrap: wrap;
}
.tag {
  display: inline-block;
  padding: 0.2em 0.7em;
  border-radius: 4px;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.72rem;
  font-weight: 500;
  background: rgba(34,211,238,0.1);
  border: 1px solid rgba(34,211,238,0.25);
  color: #22d3ee;
}

.content :deep(h1) {
  font-family: 'Inter', sans-serif;
  font-size: 3.2rem;
  font-weight: 800;
  line-height: 1.1;
  letter-spacing: -0.03em;
  color: #e6edf3;
  margin-bottom: 0.8rem;
}
.content :deep(h1 em) {
  color: #22d3ee;
  font-style: normal;
}

.content :deep(h2) {
  font-size: 1.2rem;
  font-weight: 400;
  color: #7d8590;
  margin-top: 0;
  font-family: 'JetBrains Mono', monospace;
}

.content :deep(p) {
  font-size: 1rem;
  color: #7d8590;
  margin-top: 0.6rem;
  font-family: 'JetBrains Mono', monospace;
}

.meta-row {
  display: flex;
  align-items: center;
  gap: 0.8rem;
  margin-top: 1.8rem;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.82rem;
}
.cursor {
  color: #22d3ee;
  animation: blink 1.2s step-end infinite;
}
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
.meta     { color: #e6edf3; }
.meta-dim { color: #484f58; }

/* ── Status bar ── */
.status-bar {
  position: relative;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 0;
  padding: 0.3rem 1rem;
  background: #22d3ee;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.72rem;
  font-weight: 500;
  color: #0d1117;
}
.status-item { padding: 0 0.7rem; }
.status-branch { background: rgba(0,0,0,0.15); }
.status-accent { background: rgba(0,0,0,0.2); margin-left: auto; }
.status-spacer { flex: 1; }
.icon { font-style: normal; }
</style>
