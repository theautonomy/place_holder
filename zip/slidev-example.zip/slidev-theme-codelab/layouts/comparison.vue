<!--
  comparison layout — side-by-side before/after code diff
  Default slot  = "Before" (left)
  ::right::     = "After"  (right)
-->
<template>
  <div class="layout-comparison">
    <div class="top-accent" />

    <!-- Optional heading above both panes -->
    <div class="header" v-if="$slots.header">
      <slot name="header" />
    </div>

    <div class="panes">
      <!-- Before pane -->
      <div class="pane pane-before">
        <div class="pane-titlebar">
          <span class="pane-icon pane-icon-bad">✕</span>
          <span class="pane-label">{{ beforeLabel }}</span>
        </div>
        <div class="pane-body">
          <slot />
        </div>
      </div>

      <!-- After pane -->
      <div class="pane pane-after">
        <div class="pane-titlebar">
          <span class="pane-icon pane-icon-good">✓</span>
          <span class="pane-label">{{ afterLabel }}</span>
        </div>
        <div class="pane-body">
          <slot name="right" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  beforeLabel: { default: 'Before' },
  afterLabel:  { default: 'After' },
})
</script>

<style scoped>
.layout-comparison {
  width: 100%;
  height: 100%;
  background: #0d1117;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-accent {
  height: 3px;
  background: linear-gradient(90deg, #f85149, #f97316, #22d3ee, #3fb950);
  flex-shrink: 0;
}

.header {
  padding: 0.8rem 2.5rem 0;
  flex-shrink: 0;
}
.header :deep(h1) {
  font-family: 'Inter', sans-serif;
  font-size: 1.6rem;
  font-weight: 700;
  color: #e6edf3;
  letter-spacing: -0.02em;
  margin: 0 0 0.5rem;
}

.panes {
  flex: 1;
  display: flex;
  gap: 1rem;
  padding: 0.8rem 1.2rem 1.2rem;
  min-height: 0;
}

.pane {
  flex: 1;
  border-radius: 8px;
  border: 1px solid #30363d;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* Before pane — red tint */
.pane-before { border-color: rgba(248,81,73,0.3); }
.pane-before .pane-titlebar { background: rgba(248,81,73,0.1); border-bottom-color: rgba(248,81,73,0.2); }

/* After pane — green tint */
.pane-after  { border-color: rgba(63,185,80,0.3); }
.pane-after .pane-titlebar  { background: rgba(63,185,80,0.1);  border-bottom-color: rgba(63,185,80,0.2); }

.pane-titlebar {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.45rem 1rem;
  border-bottom: 1px solid;
  flex-shrink: 0;
}
.pane-icon {
  font-size: 0.75rem;
  font-weight: 700;
}
.pane-icon-bad  { color: #f85149; }
.pane-icon-good { color: #3fb950; }
.pane-label {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.75rem;
  font-weight: 600;
  color: #e6edf3;
}

.pane-body {
  flex: 1;
  padding: 0.8rem 1rem;
  overflow: auto;
  background: #161b22;
}

.pane-body :deep(h2) {
  font-size: 0.78rem;
  font-family: 'JetBrains Mono', monospace;
  color: #7d8590;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  margin: 0.6rem 0 0.3rem;
}
.pane-body :deep(p) {
  font-size: 0.85rem;
  color: #7d8590;
  margin: 0.2rem 0 0.5rem;
}
.pane-body :deep(pre) {
  font-size: 0.78rem !important;
  margin: 0 !important;
  background: #0d1117 !important;
  border: none !important;
}
.pane-body :deep(ul) { margin: 0.3rem 0; }
.pane-body :deep(ul li) { font-size: 0.84rem; margin-bottom: 0.25rem; }
</style>
