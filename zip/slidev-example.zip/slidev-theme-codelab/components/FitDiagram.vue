<template>
  <div ref="root" class="fit-diagram">
    <slot />
  </div>
</template>

<!--
  Strategy: avoid manual scale calculations entirely.
  1. CSS makes the .mermaid shadow host fill whatever space remains after headings.
  2. JS removes the SVG's fixed width/height attributes and injects
     "width:100%; height:100%" into the shadow root so the SVG fills the host.
  3. The SVG's preserveAspectRatio="xMidYMid meet" (Mermaid's default) fits the
     diagram inside that box while keeping its aspect ratio — no JS math needed.
-->
<script setup>
import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue'

const root = ref(null)

let lightObserver  = null
let shadowObserver = null

function fixSvg(host) {
  const shadowRoot = host.shadowRoot
  if (!shadowRoot) return false

  const svg = shadowRoot.querySelector('svg')
  if (!svg) return false

  // Remove Mermaid's fixed pixel dimensions so CSS takes over
  svg.removeAttribute('width')
  svg.removeAttribute('height')
  svg.style.cssText = ''   // clears inline max-width etc.

  // Inject a <style> into the shadow root (runs inside the shadow so no scoping issues)
  if (!shadowRoot.querySelector('style[data-fit]')) {
    const s = document.createElement('style')
    s.setAttribute('data-fit', '')
    s.textContent = `
      :host { display: flex; width: 100%; height: 100%; }
      svg   { width: 100% !important; height: 100% !important; max-width: none !important; }
    `
    shadowRoot.appendChild(s)
  }

  return true
}

function watchHost(host) {
  if (fixSvg(host)) return   // SVG already present

  // Shadow root exists but SVG not yet inserted
  const sr = host.shadowRoot
  if (!sr) return

  shadowObserver?.disconnect()
  shadowObserver = new MutationObserver(() => {
    if (fixSvg(host)) {
      shadowObserver.disconnect()
      shadowObserver = null
    }
  })
  shadowObserver.observe(sr, { childList: true, subtree: true })
}

function init() {
  const host = root.value?.querySelector('.mermaid')
  if (host) { watchHost(host); return }

  // .mermaid host not in light DOM yet — wait for it
  lightObserver?.disconnect()
  lightObserver = new MutationObserver(() => {
    const h = root.value?.querySelector('.mermaid')
    if (h) {
      lightObserver.disconnect()
      lightObserver = null
      watchHost(h)
    }
  })
  if (root.value) lightObserver.observe(root.value, { childList: true, subtree: true })
}

onMounted(async () => { await nextTick(); init() })
onBeforeUnmount(() => { lightObserver?.disconnect(); shadowObserver?.disconnect() })
</script>

<style scoped>
/* Flex column: headings take their natural height, .mermaid fills the rest */
.fit-diagram {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* Any heading / paragraph above the diagram stays at its natural height */
.fit-diagram :deep(h1),
.fit-diagram :deep(h2),
.fit-diagram :deep(p) {
  flex-shrink: 0;
}

/* The Mermaid shadow host expands to fill remaining vertical space */
.fit-diagram :deep(.mermaid) {
  flex: 1;
  min-height: 0;
  min-width: 0;
  width: 100%;
}
</style>
