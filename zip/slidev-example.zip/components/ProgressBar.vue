<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  value: number
  label?: string
  color?: string
}>(), { color: '#3b82f6' })

const pct = computed(() => `${Math.min(100, Math.max(0, props.value))}%`)
</script>

<template>
  <div style="margin: 0.4rem 0">
    <div v-if="label" style="font-size: 0.85em; margin-bottom: 0.3rem; opacity: 0.75">
      {{ label }} <span style="float: right; font-variant-numeric: tabular-nums">{{ value }}%</span>
    </div>
    <div style="background: #e5e7eb; border-radius: 9999px; height: 1rem; overflow: hidden">
      <div :style="{
        width: pct,
        height: '100%',
        background: color,
        borderRadius: '9999px',
        transition: 'width 0.6s ease',
      }" />
    </div>
  </div>
</template>
