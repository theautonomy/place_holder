<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { codeToHtml } from 'shiki'

const props = defineProps<{
  theme: string
  lang?: string
}>()

const html = ref('')

// A snippet that exercises many token types:
// keywords, types, strings, template literals,
// numbers, async/await, generics, comments
const SAMPLE = `\
import { ref, computed } from 'vue'

interface User {
  id: number
  name: string
  role: 'admin' | 'user'
}

// Fetch users from the API
async function getUsers(page = 1) {
  const url = \`/api/users?page=\${page}\`
  const res = await fetch(url)
  if (!res.ok) throw new Error(\`HTTP \${res.status}\`)
  return res.json() as Promise<User[]>
}

const count = ref(0)
const doubled = computed(() => count.value * 2)`

async function render() {
  html.value = await codeToHtml(SAMPLE, {
    lang: props.lang ?? 'typescript',
    theme: props.theme,
  })
}

onMounted(render)
watch(() => props.theme, render)
</script>

<template>
  <div class="theme-demo">
    <div class="label">{{ theme }}</div>
    <div v-if="!html" class="skeleton" />
    <div v-else class="body" v-html="html" />
  </div>
</template>

<style scoped>
.theme-demo {
  border-radius: 6px;
  overflow: hidden;
  box-shadow: 0 3px 16px rgba(0, 0, 0, 0.35);
  display: flex;
  flex-direction: column;
  height: 100%;
}

.label {
  font-family: ui-monospace, 'Cascadia Code', 'Fira Code', monospace;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.06em;
  padding: 4px 10px;
  background: rgba(0, 0, 0, 0.55);
  color: rgba(255, 255, 255, 0.9);
  flex-shrink: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.skeleton {
  flex: 1;
  background: linear-gradient(135deg, #1a1b26 0%, #24283b 100%);
  animation: pulse 1.2s ease-in-out infinite alternate;
}

@keyframes pulse {
  from { opacity: 0.5; }
  to   { opacity: 0.85; }
}

.body {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

.body :deep(pre) {
  margin: 0 !important;
  padding: 8px 12px !important;
  font-size: 9px !important;
  line-height: 1.65 !important;
  flex: 1;
  overflow: hidden;
  border-radius: 0 !important;
}

.body :deep(code) {
  font-family: ui-monospace, 'Cascadia Code', 'Fira Code', monospace !important;
  font-size: inherit !important;
}
</style>
