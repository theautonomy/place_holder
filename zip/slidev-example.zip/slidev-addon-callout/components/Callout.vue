<script setup lang="ts">
const props = withDefaults(defineProps<{
  type?: 'info' | 'tip' | 'warning' | 'danger'
  title?: string
}>(), { type: 'info' })

const config = {
  info:    { icon: 'ℹ️',  border: '#3b82f6', bg: '#eff6ff', title: '#1d4ed8' },
  tip:     { icon: '💡', border: '#22c55e', bg: '#f0fdf4', title: '#15803d' },
  warning: { icon: '⚠️',  border: '#f59e0b', bg: '#fffbeb', title: '#b45309' },
  danger:  { icon: '🚨', border: '#ef4444', bg: '#fef2f2', title: '#b91c1c' },
}

const c = computed(() => config[props.type])
</script>

<script lang="ts">
import { computed } from 'vue'
</script>

<template>
  <div :style="{
    borderLeft: `4px solid ${c.border}`,
    background: c.bg,
    borderRadius: '0 6px 6px 0',
    padding: '0.75rem 1rem',
    margin: '0.5rem 0',
  }">
    <div :style="{ color: c.title, fontWeight: 600, marginBottom: '0.25rem' }">
      {{ c.icon }} {{ title ?? type.charAt(0).toUpperCase() + type.slice(1) }}
    </div>
    <div style="color: #374151; font-size: 0.95em; line-height: 1.5">
      <slot />
    </div>
  </div>
</template>
