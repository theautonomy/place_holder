---
theme: seriph
background: https://cover.sli.dev
title: Slidev Built-in Components Demo
author: Your Name
info: Demonstrates every built-in component in Slidev.
transition: slide-left
routerMode: hash
---

# Slidev Built-in Components

A tour of all built-in components

<div class="pt-8 text-gray-400">
  See <a href="https://sli.dev/builtin/components" class="underline">sli.dev/builtin/components</a>
</div>

---
layout: section
---

# Navigation & Info
`SlideCurrentNo` · `SlidesTotal` · `Link` · `Toc` · `TitleRenderer`

---

# SlideCurrentNo & SlidesTotal

Display the current slide number and total count.

```html
Slide <SlideCurrentNo /> of <SlidesTotal />
```

<div class="mt-8 text-4xl font-mono text-center">
  Slide <SlideCurrentNo /> of <SlidesTotal />
</div>

---

# Link

Navigate to any slide by number or named route.

```html
<Link to="3">Back to slide 3</Link>
<Link to="42" title="Jump to end" />
```

<div class="mt-8 flex gap-6 justify-center text-xl">
  <Link to="1">Go to slide 1</Link>
  <Link to="2">Go to slide 2</Link>
</div>

---

# Toc

Generates a navigable table of contents from slide headings.

```html
<Toc minDepth="1" maxDepth="1" />
```

<div class="mt-4 overflow-auto max-h-80">
  <Toc minDepth="1" maxDepth="1" />
</div>

---

# TitleRenderer

Renders the parsed title of any slide by its number.

```html
<!-- Render the title of slide 1 -->
<TitleRenderer no="1" />

<!-- Render the title of slide 6 -->
<TitleRenderer no="6" />
```

<div class="mt-8 space-y-4 text-2xl">
  <div>Slide 1 title: <b><TitleRenderer no="1" /></b></div>
  <div>Slide 6 title: <b><TitleRenderer no="6" /></b></div>
</div>

---
layout: section
---

# Drawing & Layout
`Arrow` · `VDragArrow` · `Transform`

---

# Arrow

Draw an arrow between two points using absolute coordinates.

```html
<Arrow x1="50" y1="180" x2="300" y2="180" />
<Arrow x1="50" y1="280" x2="300" y2="180" color="#e74c3c" :width="3" />
<Arrow x1="50" y1="180" x2="300" y2="280" color="#2ecc71" two-way />
```

<div class="relative mt-8 h-60 border border-gray-200 rounded">
  <span class="absolute" style="left:30px;top:155px">A</span>
  <span class="absolute" style="left:305px;top:155px">B</span>
  <span class="absolute" style="left:30px;top:255px">C</span>
  <Arrow x1="60" y1="170" x2="310" y2="170" />
  <Arrow x1="60" y1="270" x2="310" y2="170" color="#e74c3c" :width="3" />
  <Arrow x1="60" y1="170" x2="310" y2="270" color="#2ecc71" two-way />
</div>

---

# VDragArrow

An Arrow that can be repositioned by dragging in presenter mode.

```html
<VDragArrow x1="100" y1="100" x2="400" y2="300" color="#3498db" />
```

<div class="relative mt-8 h-60 border border-gray-200 rounded bg-gray-50">
  <div class="absolute text-sm opacity-50 bottom-2 right-2">
    Drag the arrow in edit/presenter mode
  </div>
  <VDragArrow id="drag-arrow-1" x1="100" y1="50" x2="400" y2="180" color="#3498db" :width="3" />
</div>

---

# Transform

Scale or transform any element without affecting surrounding layout.

```html
<!-- Scale down to 50% -->
<Transform :scale="0.5">
  <div class="border p-4">Half size</div>
</Transform>

<!-- Scale up to 150% from top-left -->
<Transform :scale="1.5" origin="top left">
  <div class="border p-4">1.5× size</div>
</Transform>
```

<div class="mt-8 flex gap-12 items-start">
  <div>
    <div class="text-sm opacity-50 mb-2">scale: 0.5</div>
    <Transform :scale="0.5" origin="top left">
      <div class="border-2 border-blue-400 p-4 text-xl w-48">Half size content</div>
    </Transform>
  </div>
  <div>
    <div class="text-sm opacity-50 mb-2">scale: 1 (normal)</div>
    <div class="border-2 border-green-400 p-4 text-xl w-48">Normal size</div>
  </div>
</div>

---
layout: section
---

# Click Animations
`VClick` · `VClicks` · `VAfter` · `VSwitch`

---

# VClick

Reveal an element on the next click.

```html
<VClick>Appears on click 1</VClick>
<VClick>Appears on click 2</VClick>
```

<div class="mt-8 space-y-4 text-xl">
  <div class="p-3 bg-blue-100 rounded">Always visible</div>
  <VClick>
    <div class="p-3 bg-green-100 rounded">Appears on click 1</div>
  </VClick>
  <VClick>
    <div class="p-3 bg-yellow-100 rounded">Appears on click 2</div>
  </VClick>
  <VClick>
    <div class="p-3 bg-red-100 rounded">Appears on click 3</div>
  </VClick>
</div>

---

# VClicks

Apply click animations to every direct child automatically.

```html
<VClicks>
  <div>Item 1</div>
  <div>Item 2</div>
  <div>Item 3</div>
</VClicks>
```

<div class="mt-8">
  <VClicks class="space-y-3 text-xl">
    <div class="p-3 bg-purple-100 rounded">Item 1 — revealed on click 1</div>
    <div class="p-3 bg-purple-100 rounded">Item 2 — revealed on click 2</div>
    <div class="p-3 bg-purple-100 rounded">Item 3 — revealed on click 3</div>
  </VClicks>
</div>

---

# VAfter

Reveal together with the previous `v-click` element (same click step).

```html
<VClick>Main point</VClick>
<VAfter>Supporting detail — shown at the same time</VAfter>
```

<div class="mt-8 space-y-3 text-xl">
  <div class="p-3 bg-gray-100 rounded">Always visible</div>
  <VClick>
    <div class="p-3 bg-blue-100 rounded">Main point (click 1)</div>
  </VClick>
  <VAfter>
    <div class="p-3 bg-blue-50 rounded text-base opacity-80">↑ Supporting detail — same click step</div>
  </VAfter>
  <VClick>
    <div class="p-3 bg-green-100 rounded">Next point (click 2)</div>
  </VClick>
</div>

---

# VSwitch

Show one slot at a time, switching with each click.

```html
<VSwitch>
  <template #1>Step one</template>
  <template #2>Step two</template>
  <template #3>Step three</template>
</VSwitch>
```

<div class="mt-8 text-xl">
  <VSwitch>
    <template #1>
      <div class="p-6 bg-blue-100 rounded text-center text-2xl">Step 1 — Initial state</div>
    </template>
    <template #2>
      <div class="p-6 bg-green-100 rounded text-center text-2xl">Step 2 — After first click</div>
    </template>
    <template #3>
      <div class="p-6 bg-yellow-100 rounded text-center text-2xl">Step 3 — After second click</div>
    </template>
  </VSwitch>
</div>

---
layout: section
---

# Theming & Context
`LightOrDark` · `RenderWhen`

---

# LightOrDark

Render different content depending on the active colour theme.

```html
<LightOrDark>
  <template #light>Shown in light mode ☀️</template>
  <template #dark>Shown in dark mode 🌙</template>
</LightOrDark>
```

<div class="mt-8 text-xl p-6 border rounded">
  <LightOrDark>
    <template #light>
      <div class="text-yellow-600 font-bold">☀️ You are in Light Mode</div>
    </template>
    <template #dark>
      <div class="text-blue-300 font-bold">🌙 You are in Dark Mode</div>
    </template>
  </LightOrDark>
</div>

---

# RenderWhen

Render content only in specific view contexts.

```html
<!-- Only visible in presenter view -->
<RenderWhen context="presenter">
  Speaker notes panel content
</RenderWhen>

<!-- Visible in both main and overview -->
<RenderWhen :context="['main', 'overview']">
  Shown in slide view and overview
</RenderWhen>
```

Available contexts: `main` · `presenter` · `overview` · `previewLeft` · `previewRight` · `print`

<div class="mt-6 space-y-3">
  <RenderWhen context="main">
    <div class="p-3 bg-green-100 rounded">✅ Visible in <b>main</b> view (you see this now)</div>
  </RenderWhen>
  <RenderWhen context="presenter">
    <div class="p-3 bg-blue-100 rounded">🎤 Only visible in <b>presenter</b> view</div>
  </RenderWhen>
</div>

---
layout: section
---

# Text & Media
`AutoFitText` · `Youtube` · `SlidevVideo` · `Tweet`

---

# AutoFitText

Automatically shrinks or grows text to fill the container.

```html
<AutoFitText :max="80" :min="20" modelValue="Auto-sized!" />
```

<div class="mt-6 space-y-6">
  <div class="border rounded p-2 h-20">
    <AutoFitText :max="80" :min="20" modelValue="Short" />
  </div>
  <div class="border rounded p-2 h-20">
    <AutoFitText :max="80" :min="20" modelValue="Much longer text that needs to shrink to fit" />
  </div>
  <div class="border rounded p-2 h-20">
    <AutoFitText :max="80" :min="20" modelValue="Extremely long sentence that will be scaled down even further to fit inside this fixed-height container" />
  </div>
</div>

---

# Youtube

Embed a YouTube video by its video ID.

```html
<Youtube id="eW7Twd85m2g" />
<Youtube id="eW7Twd85m2g" width="400" height="225" />
```

<div class="flex justify-center mt-4">
  <Youtube id="eW7Twd85m2g" width="560" height="315" />
</div>

---

# SlidevVideo

Embed a local or remote video with playback controls.

```html
<SlidevVideo controls autoplay loop>
  <source src="https://sli.dev/demo.mp4" type="video/mp4" />
</SlidevVideo>
```

Props: `controls` · `autoplay` · `loop` · `autoreset` (`slide`|`click`) · `poster` · `timestamp`

<div class="mt-6 p-4 bg-gray-100 rounded text-sm font-mono">
&lt;SlidevVideo controls&gt;<br>
&nbsp;&nbsp;&lt;source src="/your-video.mp4" type="video/mp4" /&gt;<br>
&lt;/SlidevVideo&gt;
</div>

<div class="mt-4 text-sm opacity-60">
  A video file is required — no public demo video is embedded here.
</div>

---

# Tweet

Embed a tweet by its numeric ID.

```html
<Tweet id="1390115482657726468" />
<Tweet id="1390115482657726468" scale="0.65" />
```

<div class="flex justify-center mt-4">
  <Tweet id="1390115482657726468" scale="0.65" />
</div>

---
layout: section
---

# Utility
`VDrag` · `PoweredBySlidev`

---

# VDrag

Make any element draggable on the slide.

```html
<VDrag>
  <div class="p-4 bg-blue-200 rounded shadow cursor-move">
    Drag me around!
  </div>
</VDrag>
```

<div class="relative mt-8 h-60 border border-dashed rounded">
  <VDrag id="drag-box-1">
    <div class="p-4 bg-blue-200 rounded shadow cursor-move w-fit">
      🖱️ Drag me around!
    </div>
  </VDrag>
  <VDrag id="drag-box-2">
    <div class="p-4 bg-green-200 rounded shadow cursor-move w-fit">
      🖱️ I'm draggable too!
    </div>
  </VDrag>
</div>

---

# PoweredBySlidev

A simple attribution badge that links back to Slidev.

```html
<PoweredBySlidev />
```

<div class="mt-12 flex justify-center">
  <PoweredBySlidev />
</div>

---
layout: section
---

# Custom Components
Drop a `.vue` file in `components/` — Slidev auto-imports it

---
layout: two-cols
---

# ProgressBar — Live

```html
<ProgressBar :value="72" label="TypeScript" />
<ProgressBar :value="90" label="Vue" color="#22c55e" />
<ProgressBar :value="55" label="Rust" color="#f97316" />
<ProgressBar :value="40" label="Go" color="#06b6d4" />
```

<div class="mt-8 space-y-3">
  <ProgressBar :value="72" label="TypeScript" />
  <ProgressBar :value="90" label="Vue" color="#22c55e" />
  <ProgressBar :value="55" label="Rust" color="#f97316" />
  <ProgressBar :value="40" label="Go" color="#06b6d4" />
</div>

::right::

# ProgressBar — Source

```vue
<!-- components/ProgressBar.vue -->
<script setup lang="ts">
import { computed } from 'vue'

const props = withDefaults(defineProps<{
  value: number
  label?: string
  color?: string
}>(), { color: '#3b82f6' })

const pct = computed(() =>
  `${Math.min(100, Math.max(0, props.value))}%`
)
</script>

<template>
  <div>
    <div v-if="label" style="font-size:0.85em">
      {{ label }}
      <span style="float:right">{{ value }}%</span>
    </div>
    <div style="background:#e5e7eb;border-radius:9999px;
                height:1rem;overflow:hidden">
      <div :style="{
        width: pct, height: '100%',
        background: color, borderRadius: '9999px',
        transition: 'width 0.6s ease',
      }" />
    </div>
  </div>
</template>
```

---
layout: cover
background: https://cover.sli.dev
---

# All Components Covered

| Category | Components |
|----------|-----------|
| Navigation & Info | `SlideCurrentNo` `SlidesTotal` `Link` `Toc` `TitleRenderer` |
| Drawing & Layout | `Arrow` `VDragArrow` `Transform` |
| Click Animations | `VClick` `VClicks` `VAfter` `VSwitch` |
| Theming & Context | `LightOrDark` `RenderWhen` |
| Text & Media | `AutoFitText` `Youtube` `SlidevVideo` `Tweet` |
| Utility | `VDrag` `PoweredBySlidev` |
| Custom | `ProgressBar` |

<div class="mt-4 text-sm text-gray-300">
  <a href="https://sli.dev/builtin/components" class="underline">sli.dev/builtin/components</a>
</div>
