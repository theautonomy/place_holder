<template>
  <div class="absolute bottom-4 left-6 text-sm opacity-50">
    {{ $slidev.configs.author }} · {{ $slidev.configs.title }}
  </div>
  <div class="absolute bottom-4 right-6 text-sm opacity-50 font-mono">
    <SlideCurrentNo /> / <SlidesTotal />
  </div>
</template>
