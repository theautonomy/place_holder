<!--
  changelog layout — side-by-side before / after comparison
  Named slots:
    before  — old code / old approach
    after   — new code / new approach
  Props:
    beforeLabel  — header text for left panel  (default "Before")
    afterLabel   — header text for right panel (default "After")
    title        — optional slide title shown above both panels
-->
<template>
  <div class="layout-changelog">
    <div class="top-rule" />

    <div class="title-bar" v-if="title">
      <span class="title-text">{{ title }}</span>
    </div>

    <div class="panels">
      <!-- Before -->
      <div class="panel panel-before">
        <div class="panel-header">
          <span class="panel-icon">✕</span>
          <span>{{ beforeLabel }}</span>
        </div>
        <div class="panel-body">
          <slot name="before" />
        </div>
      </div>

      <!-- After -->
      <div class="panel panel-after">
        <div class="panel-header">
          <span class="panel-icon">✓</span>
          <span>{{ afterLabel }}</span>
        </div>
        <div class="panel-body">
          <slot name="after" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  title:       { default: '' },
  beforeLabel: { default: 'Before' },
  afterLabel:  { default: 'After'  },
})
</script>

<style scoped>
.layout-changelog {
  width: 100%;
  height: 100%;
  background: var(--dv-bg);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-rule {
  height: 3px;
  background: linear-gradient(90deg, var(--dv-red), var(--dv-teal));
  flex-shrink: 0;
}

.title-bar {
  flex-shrink: 0;
  padding: 0.5rem 2rem 0.4rem;
  border-bottom: 1px solid var(--dv-surface0);
}
.title-text {
  font-size: 0.95rem;
  font-weight: 700;
  color: var(--dv-text);
  letter-spacing: -0.01em;
}

.panels {
  flex: 1;
  display: grid;
  grid-template-columns: 1fr 1fr;
  min-height: 0;
}

/* ── Shared panel ── */
.panel {
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.panel-before {
  border-right: 1px solid var(--dv-surface0);
  background: rgba(243, 139, 168, 0.03);
}
.panel-after {
  background: rgba(148, 226, 213, 0.03);
}

.panel-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.45rem 1.2rem;
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.72rem;
  font-weight: 600;
  letter-spacing: 0.05em;
  flex-shrink: 0;
}
.panel-before .panel-header {
  background: rgba(243, 139, 168, 0.08);
  border-bottom: 1px solid rgba(243, 139, 168, 0.2);
  color: var(--dv-red);
}
.panel-after .panel-header {
  background: rgba(148, 226, 213, 0.08);
  border-bottom: 1px solid rgba(148, 226, 213, 0.2);
  color: var(--dv-teal);
}

.panel-icon {
  font-size: 0.75rem;
  font-weight: 700;
}

.panel-body {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  padding: 0.8rem 1rem;
  overflow: hidden;
}

/* Make code blocks fill the panel */
.panel-body :deep(.slidev-code),
.panel-body :deep(.slidev-code-wrapper),
.panel-body :deep(.shiki-container) {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.panel-body :deep(pre) {
  flex: 1;
  min-height: 0;
  margin: 0 !important;
  font-size: 0.78rem !important;
  line-height: 1.6 !important;
  border-radius: 6px !important;
  overflow: auto !important;
}
</style>
