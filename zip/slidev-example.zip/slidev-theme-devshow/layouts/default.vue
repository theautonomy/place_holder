<!--
  default layout — clean dark slide
  Slot: default content
  Frontmatter props: none (uses h1 from content as title)
-->
<template>
  <div class="layout-default">
    <div class="top-accent" />
    <div class="content">
      <slot />
    </div>
    <div class="slide-num">{{ $slidev?.nav?.currentPage }}</div>
  </div>
</template>

<style scoped>
.layout-default {
  width: 100%;
  height: 100%;
  background: var(--dv-bg);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;
}

.top-accent {
  height: 3px;
  background: linear-gradient(90deg, var(--dv-mauve), var(--dv-teal), transparent 70%);
  flex-shrink: 0;
}

.content {
  flex: 1;
  min-height: 0;
  padding: 1.4rem 2.5rem 1.2rem;
  overflow: auto;
}

/* Title styling */
.content :deep(h1) {
  font-size: 1.9rem;
  font-weight: 800;
  color: var(--dv-text);
  letter-spacing: -0.025em;
  line-height: 1.2;
  margin: 0 0 0.2rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid var(--dv-surface0);
}

.content :deep(h1 em) {
  font-style: normal;
  color: var(--dv-mauve);
}

.slide-num {
  position: absolute;
  bottom: 0.6rem;
  right: 1rem;
  font-size: 0.65rem;
  color: var(--dv-surface1);
  font-family: 'JetBrains Mono', monospace;
}
</style>
