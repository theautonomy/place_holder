<!--
  diagram layout — full-height mermaid or excalidraw diagram
  Named slots:
    default  — the diagram (mermaid code block or <Excalidraw>)
    title    — optional slide title (h1)
    caption  — optional caption below the diagram
  Props:
    pad  — inset around diagram area (default "1rem 2rem")
-->
<template>
  <div class="layout-diagram">
    <div class="top-rule" />

    <div class="title-bar" v-if="$slots.title">
      <slot name="title" />
    </div>

    <div class="diagram-area" :style="{ padding: pad }">
      <slot />
    </div>

    <div class="caption-bar" v-if="$slots.caption">
      <slot name="caption" />
    </div>
  </div>
</template>

<script setup>
defineProps({
  pad: { default: '0.6rem 2rem' },
})
</script>

<style scoped>
.layout-diagram {
  width: 100%;
  height: 100%;
  background: var(--dv-bg);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-rule {
  height: 3px;
  background: linear-gradient(90deg, var(--dv-mauve), var(--dv-teal), transparent 70%);
  flex-shrink: 0;
}

/* ── Title bar ── */
.title-bar {
  flex-shrink: 0;
  padding: 0.6rem 2rem 0.3rem;
  border-bottom: 1px solid var(--dv-surface0);
}
.title-bar :deep(h1) {
  font-size: 1.3rem !important;
  font-weight: 700 !important;
  color: var(--dv-text) !important;
  margin: 0 !important;
  letter-spacing: -0.02em !important;
}
.title-bar :deep(h1 em) {
  font-style: normal;
  color: var(--dv-mauve);
}

/* ── Diagram area ── */
.diagram-area {
  flex: 1;
  min-height: 0;
  overflow: hidden;
  position: relative;   /* anchor for absolute children */
}

/*
  Mermaid and Excalidraw wrappers are absolutely positioned so they
  have a DEFINITE height — the positioned ancestor's inset height.
  max-height / max-width on the SVG inside then resolves correctly.
*/
.diagram-area :deep(.mermaid),
.diagram-area :deep(.w-full),
.diagram-area :deep([class*="w-["]) {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

.diagram-area :deep(svg) {
  max-height: 100%;
  max-width: 100%;
  height: auto;
  width: auto;
}

/* ── Caption ── */
.caption-bar {
  flex-shrink: 0;
  padding: 0.4rem 2rem 0.5rem;
  border-top: 1px solid var(--dv-surface0);
  font-size: 0.75rem;
  color: var(--dv-muted);
  font-style: italic;
}
</style>
