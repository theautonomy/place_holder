<!--
  feature layout — hero for introducing a single API / concept mid-deck
  Left (40%): badge row, feature name, description, bullet points
  Right (60%): code block or diagram (default slot)

  Named slots:
    name    — the feature name (h1)
    desc    — short description paragraph
    badges  — badge row
    default — code/diagram panel (right side)
-->
<template>
  <div class="layout-feature">
    <div class="top-rule" />

    <div class="inner">
      <!-- Left: identity panel -->
      <div class="identity">
        <div class="badge-row" v-if="$slots.badges">
          <slot name="badges" />
        </div>

        <h1 v-if="$slots.name">
          <slot name="name" />
        </h1>
        <h1 v-else>{{ title }}</h1>

        <p class="desc" v-if="$slots.desc">
          <slot name="desc" />
        </p>

        <div class="extra" v-if="$slots.extra">
          <slot name="extra" />
        </div>
      </div>

      <!-- Divider -->
      <div class="divider" />

      <!-- Right: code / diagram -->
      <div class="demo-panel">
        <slot name="right" />
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  title: { default: '' },
})
</script>

<style scoped>
.layout-feature {
  width: 100%;
  height: 100%;
  background: var(--dv-bg);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-rule {
  height: 3px;
  background: linear-gradient(90deg, var(--dv-mauve), var(--dv-teal), transparent 70%);
  flex-shrink: 0;
}

.inner {
  flex: 1;
  display: flex;
  min-height: 0;
}

/* ── Identity (left) ── */
.identity {
  flex: 0 0 38%;
  padding: 1.6rem 2rem 1.6rem 2.5rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  background: var(--dv-mantle);
  overflow: hidden;
}

.badge-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
  margin-bottom: 0.9rem;
}

h1 {
  font-size: 1.9rem !important;
  font-weight: 800 !important;
  color: var(--dv-text) !important;
  line-height: 1.15 !important;
  letter-spacing: -0.025em !important;
  margin: 0 0 0.7rem !important;
}

h1 :deep(em) {
  font-style: normal;
  background: linear-gradient(135deg, var(--dv-mauve), var(--dv-teal));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

h1 :deep(code) {
  font-size: 0.9em !important;
  background: var(--dv-surface0) !important;
  color: var(--dv-sky) !important;
  border: 1px solid var(--dv-surface1) !important;
  border-radius: 4px !important;
  padding: 0.05em 0.3em !important;
  -webkit-text-fill-color: initial;
}

.desc {
  font-size: 0.9rem;
  color: var(--dv-muted);
  line-height: 1.65;
  margin: 0 0 0.8rem;
}

.extra {
  font-size: 0.88rem;
}
.extra :deep(ul) { padding: 0; }
.extra :deep(li) { font-size: 0.88rem; margin-bottom: 0.3rem; }

/* ── Divider ── */
.divider {
  width: 1px;
  background: var(--dv-surface0);
  flex-shrink: 0;
}

/* ── Demo panel (right) ── */
.demo-panel {
  flex: 1;
  min-width: 0;
  min-height: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 1rem 1.5rem 1rem 1.2rem;
}

/* Make code blocks stretch to fill the panel */
.demo-panel :deep(.slidev-code),
.demo-panel :deep(.slidev-code-wrapper),
.demo-panel :deep(.shiki-container) {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.demo-panel :deep(pre) {
  flex: 1;
  min-height: 0;
  margin: 0 !important;
  border-radius: 8px !important;
  font-size: 0.8rem !important;
  line-height: 1.6 !important;
  overflow: auto !important;
}

/* Mermaid / Excalidraw inside the panel — absolute for definite height */
.demo-panel {
  position: relative;
}
.demo-panel :deep(.mermaid),
.demo-panel :deep(.w-full),
.demo-panel :deep([class*="w-["]) {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}
.demo-panel :deep(.mermaid svg),
.demo-panel :deep([class*="w-"] svg) {
  max-height: 100%;
  max-width: 100%;
  height: auto;
  width: auto;
}
</style>
