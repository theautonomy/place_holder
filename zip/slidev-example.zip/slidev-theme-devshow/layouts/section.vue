<!--
  section layout — chapter divider
  Slots: default (section title), description (optional sub-text)
  Props: number — chapter number shown as large background glyph
-->
<template>
  <div class="layout-section">
    <div class="top-rule" />
    <div class="bg-num" v-if="number">{{ number }}</div>
    <div class="inner">
      <div class="label">{{ label }}</div>
      <h1><slot /></h1>
      <p class="desc" v-if="$slots.description">
        <slot name="description" />
      </p>
    </div>
  </div>
</template>

<script setup>
defineProps({
  number:    { default: '' },
  label:     { default: 'Chapter' },
})
</script>

<style scoped>
.layout-section {
  width: 100%;
  height: 100%;
  background: var(--dv-mantle);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: 3rem 4rem;
  overflow: hidden;
  position: relative;
}

.top-rule {
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--dv-mauve), var(--dv-teal), transparent 70%);
}

/* Ghost chapter number */
.bg-num {
  position: absolute;
  right: 3rem;
  top: 50%;
  transform: translateY(-50%);
  font-size: 14rem;
  font-weight: 800;
  color: var(--dv-surface0);
  line-height: 1;
  letter-spacing: -0.05em;
  user-select: none;
  pointer-events: none;
}

.inner {
  position: relative;
  z-index: 1;
  max-width: 60%;
}

.label {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.72rem;
  font-weight: 600;
  color: var(--dv-mauve);
  text-transform: uppercase;
  letter-spacing: 0.12em;
  margin-bottom: 0.7rem;
}

h1 {
  font-size: 3rem !important;
  font-weight: 800 !important;
  color: var(--dv-text) !important;
  line-height: 1.1 !important;
  letter-spacing: -0.03em !important;
  margin: 0 0 0.8rem !important;
}

h1 :deep(em) {
  font-style: normal;
  background: linear-gradient(135deg, var(--dv-mauve), var(--dv-teal));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.desc {
  font-size: 1rem;
  color: var(--dv-muted);
  line-height: 1.6;
  margin: 0;
}
</style>
