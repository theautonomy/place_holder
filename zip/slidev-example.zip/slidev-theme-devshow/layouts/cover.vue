<!--
  cover layout — feature-announcement hero
  Slots:
    default  — feature title (h1)
    subtitle — one-liner tagline
    badges   — badge row (ecosystem, version, status)
    code     — optional code teaser on the right half
-->
<template>
  <div class="layout-cover">
    <!-- Top gradient rule -->
    <div class="top-rule" />

    <div class="inner">
      <!-- Left: identity -->
      <div class="left">
        <div class="badges" v-if="$slots.badges">
          <slot name="badges" />
        </div>

        <h1><slot /></h1>

        <p class="tagline" v-if="$slots.subtitle">
          <slot name="subtitle" />
        </p>

        <div class="meta">
          <span v-if="$slidev?.configs?.author">{{ $slidev.configs.author }}</span>
          <span v-if="$slidev?.configs?.date" class="date">{{ $slidev.configs.date }}</span>
        </div>
      </div>

      <!-- Right: optional code teaser -->
      <div class="right" v-if="$slots.code">
        <div class="code-window">
          <div class="window-bar">
            <span class="dot red" /><span class="dot yellow" /><span class="dot green" />
            <span class="window-title">{{ $slidev?.configs?.title ?? 'demo.ts' }}</span>
          </div>
          <div class="window-body">
            <slot name="code" />
          </div>
        </div>
      </div>
    </div>

    <!-- Bottom footer -->
    <div class="footer">
      <span v-if="$slidev?.configs?.repo" class="repo">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="currentColor">
          <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"/>
        </svg>
        {{ $slidev.configs.repo }}
      </span>
    </div>
  </div>
</template>

<script setup>
// No props — all content via slots and $slidev.configs
</script>

<style scoped>
.layout-cover {
  width: 100%;
  height: 100%;
  background: var(--dv-crust);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;
}

.top-rule {
  height: 3px;
  background: linear-gradient(90deg, var(--dv-mauve), var(--dv-teal), transparent 80%);
  flex-shrink: 0;
}

.inner {
  flex: 1;
  display: flex;
  align-items: center;
  min-height: 0;
  gap: 2.5rem;
  padding: 2rem 3rem;
}

/* ── Left: identity ── */
.left {
  flex: 0 0 42%;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.badges {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
  margin-bottom: 1rem;
}

h1 {
  font-size: 3.2rem !important;
  font-weight: 800 !important;
  line-height: 1.08 !important;
  letter-spacing: -0.03em !important;
  color: var(--dv-text) !important;
  margin: 0 0 0.8rem !important;
}

/* em in title gets accent gradient */
h1 :deep(em) {
  font-style: normal;
  background: linear-gradient(135deg, var(--dv-mauve), var(--dv-teal));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.tagline {
  font-size: 1.05rem;
  color: var(--dv-muted);
  line-height: 1.5;
  margin: 0 0 1.4rem;
}

.meta {
  display: flex;
  gap: 1rem;
  font-size: 0.78rem;
  color: var(--dv-overlay);
  border-top: 1px solid var(--dv-surface0);
  padding-top: 0.7rem;
}
.date { color: var(--dv-overlay); }

/* ── Right: code window ── */
.right {
  flex: 1;
  min-width: 0;
  height: 100%;
  display: flex;
  align-items: center;
}

.code-window {
  width: 100%;
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid var(--dv-surface0);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
}

.window-bar {
  display: flex;
  align-items: center;
  gap: 0.35rem;
  background: var(--dv-mantle);
  padding: 0.5rem 0.8rem;
  border-bottom: 1px solid var(--dv-surface0);
}

.dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}
.dot.red    { background: #f38ba8; }
.dot.yellow { background: #f9e2af; }
.dot.green  { background: #a6e3a1; }

.window-title {
  font-family: 'JetBrains Mono', monospace;
  font-size: 0.68rem;
  color: var(--dv-overlay);
  margin-left: 0.3rem;
}

.window-body {
  overflow: hidden;
}
.window-body :deep(pre) {
  margin: 0 !important;
  border-radius: 0 !important;
  border: none !important;
  font-size: 0.75rem !important;
  line-height: 1.55 !important;
  max-height: 340px;
  overflow: auto;
}

/* ── Footer ── */
.footer {
  flex-shrink: 0;
  padding: 0.5rem 3rem;
  border-top: 1px solid var(--dv-surface0);
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: 0.72rem;
  color: var(--dv-overlay);
}
.repo {
  display: flex;
  align-items: center;
  gap: 0.3rem;
}
</style>
