<!--
  split layout — two panels side by side (code | diagram, text | code, etc.)
  Named slots:
    default  — left panel content
    right    — right panel content
    title    — optional title bar spanning both panels
  Props:
    left  — left column width  (CSS fr or px, default "1fr")
    right — right column width (CSS fr or px, default "1fr")
-->
<template>
  <div class="layout-split">
    <div class="top-rule" />

    <div class="title-bar" v-if="$slots.title">
      <slot name="title" />
    </div>

    <div class="body" :style="{ gridTemplateColumns: `${leftW} ${rightW}` }">
      <div class="pane pane-left">
        <slot name="left" />
      </div>
      <div class="pane pane-right">
        <slot name="right" />
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  leftW:  { default: '1fr' },
  rightW: { default: '1fr' },
})
</script>

<style scoped>
.layout-split {
  width: 100%;
  height: 100%;
  background: var(--dv-bg);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.top-rule {
  height: 3px;
  background: linear-gradient(90deg, var(--dv-mauve), var(--dv-teal), transparent 70%);
  flex-shrink: 0;
}

.title-bar {
  flex-shrink: 0;
  padding: 0.55rem 2rem 0.4rem;
  border-bottom: 1px solid var(--dv-surface0);
}
.title-bar :deep(h1) {
  font-size: 1.4rem !important;
  font-weight: 700 !important;
  color: var(--dv-text) !important;
  margin: 0 !important;
  letter-spacing: -0.02em !important;
}
.title-bar :deep(h1 em) {
  font-style: normal;
  color: var(--dv-mauve);
}

.body {
  flex: 1;
  display: grid;
  min-height: 0;
}

.pane {
  display: flex;
  flex-direction: column;
  min-height: 0;
  overflow: hidden;
  padding: 1rem 1.5rem;
}
.pane-left  { border-right: 1px solid var(--dv-surface0); }

/* Code blocks fill the pane */
.pane :deep(.slidev-code),
.pane :deep(.slidev-code-wrapper),
.pane :deep(.shiki-container) {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.pane :deep(pre) {
  flex: 1;
  min-height: 0;
  margin: 0 !important;
  font-size: 0.79rem !important;
  line-height: 1.6 !important;
  border-radius: 8px !important;
  overflow: auto !important;
}

/* Mermaid / Excalidraw inside a pane — absolute so SVG gets definite height */
.pane {
  position: relative;
}
.pane :deep(.mermaid),
.pane :deep(.w-full),
.pane :deep([class*="w-["]) {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}
.pane :deep(.mermaid svg),
.pane :deep([class*="w-"] svg) {
  max-height: 100%;
  max-width: 100%;
  height: auto;
  width: auto;
}
</style>
