<script setup lang="ts">
defineProps<{
  noteTitle?: string
  noteColor?: string  // CSS background for the note panel
}>()
</script>

<template>
  <div class="slidev-layout side-note">
    <main>
      <slot />
    </main>
    <aside :style="{ background: $props.noteColor ?? '#fef9c3' }">
      <div v-if="$props.noteTitle" class="note-title">{{ $props.noteTitle }}</div>
      <slot name="note" />
    </aside>
  </div>
</template>

<style scoped>
.side-note {
  display: grid;
  grid-template-columns: 1fr 0.45fr;
  height: 100%;
  overflow: hidden;
}

main {
  padding: 2rem 2.5rem;
  overflow: auto;
}

aside {
  padding: 1.5rem 1.4rem;
  border-left: 3px solid rgba(0, 0, 0, 0.08);
  font-size: 0.88em;
  line-height: 1.55;
  overflow: auto;
}

.note-title {
  font-weight: 700;
  font-size: 0.8em;
  letter-spacing: 0.07em;
  text-transform: uppercase;
  opacity: 0.55;
  margin-bottom: 0.6rem;
}
</style>
