<template>
  <div class="layout-section">
    <div class="glow glow-1" />
    <div class="glow glow-2" />
    <div class="dot-grid" />
    <div class="content">
      <div class="accent-line" />
      <slot />
    </div>
  </div>
</template>

<style scoped>
.layout-section {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.glow {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
  filter: blur(80px);
}
.glow-1 {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 70%;
  height: 70%;
  background: radial-gradient(ellipse, rgba(99,102,241,0.22) 0%, transparent 65%);
}
.glow-2 {
  bottom: -20%;
  right: -10%;
  width: 50%;
  height: 60%;
  background: radial-gradient(ellipse, rgba(236,72,153,0.12) 0%, transparent 70%);
}

.dot-grid {
  position: absolute;
  inset: 0;
  background-image: radial-gradient(circle, rgba(99,102,241,0.15) 1px, transparent 1px);
  background-size: 36px 36px;
  pointer-events: none;
}

.content {
  position: relative;
  z-index: 1;
  text-align: center;
  padding: 2rem 4rem;
  max-width: 80%;
}

.accent-line {
  width: 4rem;
  height: 3px;
  background: linear-gradient(90deg, #6366f1, #ec4899);
  border-radius: 2px;
  margin: 0 auto 1.5rem;
}

.content :deep(h1) {
  font-family: 'Outfit', sans-serif;
  font-size: 3.2rem;
  font-weight: 900;
  letter-spacing: -0.03em;
  line-height: 1.1;
  background: linear-gradient(135deg, #a5b4fc 0%, #c084fc 50%, #f9a8d4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 0.8rem;
}

.content :deep(h2) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.5rem;
  font-weight: 400;
  color: rgba(226,232,240,0.55);
  margin-top: 0.3rem;
}

.content :deep(p) {
  font-size: 1rem;
  color: rgba(226,232,240,0.5);
  margin-top: 0.8rem;
}
</style>
