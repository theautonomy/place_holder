<template>
  <div class="layout-quote">
    <div class="glow" />
    <div class="content">
      <div class="quote-mark">"</div>
      <slot />
    </div>
  </div>
</template>

<style scoped>
.layout-quote {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.glow {
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse at 30% 50%, rgba(99,102,241,0.14) 0%, transparent 60%);
  pointer-events: none;
}

.content {
  position: relative;
  z-index: 1;
  max-width: 78%;
  padding: 2rem 3.5rem;
}

.quote-mark {
  font-family: 'Outfit', sans-serif;
  font-size: 8rem;
  font-weight: 900;
  line-height: 0.6;
  margin-bottom: 1.2rem;
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  user-select: none;
}

.content :deep(p) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.8rem;
  font-weight: 500;
  line-height: 1.5;
  color: #e8eaf4;
  font-style: italic;
  margin: 0 0 1.5rem;
}

.content :deep(p:last-child) {
  font-family: 'Inter', sans-serif;
  font-size: 0.9rem;
  font-style: normal;
  font-weight: 500;
  color: #a5b4fc;
  letter-spacing: 0.05em;
  margin: 0;
  padding-top: 0.8rem;
  border-top: 1px solid rgba(99,102,241,0.2);
}
</style>
