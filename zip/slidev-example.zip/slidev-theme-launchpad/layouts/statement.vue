<template>
  <div class="layout-statement">
    <div class="glow" />
    <div class="content">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.layout-statement {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.glow {
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse at center, rgba(99,102,241,0.18) 0%, transparent 60%);
  pointer-events: none;
}

.content {
  position: relative;
  z-index: 1;
  text-align: center;
  padding: 2rem 5rem;
  max-width: 90%;
}

.content :deep(h1),
.content :deep(h2),
.content :deep(p) {
  font-family: 'Outfit', sans-serif;
  font-size: 3rem;
  font-weight: 800;
  line-height: 1.2;
  letter-spacing: -0.025em;
  background: linear-gradient(135deg, #a5b4fc 0%, #c084fc 40%, #f9a8d4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
}

.content :deep(em) {
  font-style: normal;
  background: linear-gradient(135deg, #f59e0b 0%, #ef4444 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
</style>
