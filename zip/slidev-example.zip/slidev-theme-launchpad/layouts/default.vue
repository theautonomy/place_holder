<template>
  <div class="layout-default">
    <div class="glow" />
    <div class="accent-bar" />
    <div class="content">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.layout-default {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  overflow: hidden;
}

.glow {
  position: absolute;
  top: -30%;
  right: -10%;
  width: 60%;
  height: 70%;
  background: radial-gradient(ellipse, rgba(99,102,241,0.1) 0%, transparent 70%);
  pointer-events: none;
  filter: blur(60px);
}

.accent-bar {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background: linear-gradient(180deg, #6366f1 0%, #8b5cf6 50%, #ec4899 100%);
  border-radius: 0 2px 2px 0;
}

.content {
  position: relative;
  z-index: 1;
  flex: 1;
  padding: 2.5rem 3rem 2.5rem 3.5rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}

.content :deep(h1) {
  font-family: 'Outfit', sans-serif;
  font-size: 2.4rem;
  font-weight: 800;
  line-height: 1.15;
  letter-spacing: -0.02em;
  margin-bottom: 1.2rem;
  padding-bottom: 0.8rem;
  background: linear-gradient(135deg, #818cf8 0%, #c084fc 60%, #f472b6 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  border-bottom: 1px solid rgba(99,102,241,0.2);
}

.content :deep(h2) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.4rem;
  font-weight: 700;
  color: #e2e8f0;
  margin-top: 1.2rem;
  margin-bottom: 0.5rem;
}

.content :deep(h3) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.1rem;
  font-weight: 600;
  color: #a5b4fc;
  margin-top: 1rem;
  margin-bottom: 0.4rem;
}
</style>
