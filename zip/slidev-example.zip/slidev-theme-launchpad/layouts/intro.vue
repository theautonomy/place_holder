<template>
  <div class="layout-intro">
    <div class="glow glow-left" />
    <div class="glow glow-right" />
    <div class="accent-bar" />
    <div class="content">
      <!-- Left: avatar + identity -->
      <div class="identity">
        <div class="avatar-ring">
          <div class="avatar" v-if="$slidev.configs.avatar">
            <img :src="$slidev.configs.avatar" alt="avatar" />
          </div>
          <div class="avatar-placeholder" v-else>
            {{ initials }}
          </div>
        </div>
        <div class="name-block">
          <div class="name">{{ $slidev.configs.author || 'Your Name' }}</div>
          <div class="role" v-if="$slidev.configs.role">{{ $slidev.configs.role }}</div>
          <div class="company-tag" v-if="$slidev.configs.company">{{ $slidev.configs.company }}</div>
        </div>
      </div>

      <!-- Divider -->
      <div class="col-divider" />

      <!-- Right: bio / slot content -->
      <div class="bio">
        <slot />
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({ $slidev: Object })

const initials = computed(() => {
  const name = props.$slidev?.configs?.author || 'YN'
  return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
})
</script>

<style scoped>
.layout-intro {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  overflow: hidden;
}

.glow {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  pointer-events: none;
}
.glow-left {
  left: -10%;
  top: 20%;
  width: 45%;
  height: 60%;
  background: radial-gradient(ellipse, rgba(99,102,241,0.18) 0%, transparent 70%);
}
.glow-right {
  right: -5%;
  top: -10%;
  width: 45%;
  height: 60%;
  background: radial-gradient(ellipse, rgba(236,72,153,0.1) 0%, transparent 70%);
}

.accent-bar {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background: linear-gradient(180deg, #6366f1 0%, #8b5cf6 50%, #ec4899 100%);
}

.content {
  position: relative;
  z-index: 1;
  flex: 1;
  display: flex;
  align-items: center;
  padding: 2.5rem 3rem 2.5rem 3.5rem;
  gap: 0;
}

/* Identity column */
.identity {
  width: 42%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 1.4rem;
  padding-right: 2.5rem;
  text-align: center;
}

.avatar-ring {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  padding: 3px;
  background: linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899);
}
.avatar, .avatar-placeholder {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  overflow: hidden;
  background: #0d0d28;
}
.avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.avatar-placeholder {
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: 'Outfit', sans-serif;
  font-size: 2.2rem;
  font-weight: 800;
  background: linear-gradient(135deg, #818cf8, #c084fc);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.name-block {
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
  align-items: center;
}
.name {
  font-family: 'Outfit', sans-serif;
  font-size: 1.6rem;
  font-weight: 800;
  background: linear-gradient(135deg, #818cf8 0%, #c084fc 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  line-height: 1.2;
}
.role {
  font-size: 0.95rem;
  color: rgba(226,232,240,0.65);
  font-weight: 500;
}
.company-tag {
  display: inline-block;
  padding: 0.2em 0.8em;
  border-radius: 999px;
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  background: rgba(99,102,241,0.15);
  border: 1px solid rgba(99,102,241,0.3);
  color: #a5b4fc;
  margin-top: 0.2rem;
}

/* Column divider */
.col-divider {
  width: 1px;
  align-self: stretch;
  background: linear-gradient(180deg, transparent, rgba(99,102,241,0.4) 20%, rgba(139,92,246,0.4) 80%, transparent);
  flex-shrink: 0;
}

/* Bio column */
.bio {
  flex: 1;
  padding-left: 2.5rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.bio :deep(h1),
.bio :deep(h2) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.3rem;
  font-weight: 700;
  color: #a5b4fc;
  margin-top: 0;
  margin-bottom: 0.5rem;
}
.bio :deep(p) {
  font-size: 0.95rem;
  color: rgba(226,232,240,0.7);
  margin-bottom: 0.5rem;
  line-height: 1.7;
}
.bio :deep(ul) {
  font-size: 0.9rem;
}
</style>
