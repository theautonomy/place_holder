<template>
  <div class="layout-image-left">
    <div class="glow" />

    <!-- Image pane -->
    <div class="image-col" :style="imageColStyle">
      <div class="image-overlay" />
    </div>

    <!-- Content pane -->
    <div class="content-col">
      <slot />
    </div>

    <!-- Accent bar on right edge of image -->
    <div class="accent-bar" />
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({
  image: String,
  backgroundSize: { default: 'cover' },
})
const imageColStyle = computed(() => ({
  backgroundImage: props.image ? `url(${props.image})` : 'none',
  backgroundSize: props.backgroundSize,
  backgroundPosition: 'center',
}))
</script>

<style scoped>
.layout-image-left {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  overflow: hidden;
}

.glow {
  position: absolute;
  top: -20%;
  right: 5%;
  width: 50%;
  height: 70%;
  background: radial-gradient(ellipse, rgba(99,102,241,0.1) 0%, transparent 70%);
  filter: blur(60px);
  pointer-events: none;
}

.image-col {
  position: relative;
  width: 42%;
  flex-shrink: 0;
  background-color: #0d0d28;
  background-size: cover;
  background-position: center;
}

.image-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(90deg, transparent 60%, #06061a 100%);
}

.accent-bar {
  position: absolute;
  left: 42%;
  top: 0;
  bottom: 0;
  width: 4px;
  background: linear-gradient(180deg, #6366f1 0%, #8b5cf6 50%, #ec4899 100%);
  z-index: 2;
}

.content-col {
  position: relative;
  z-index: 1;
  flex: 1;
  padding: 2.5rem 3rem 2.5rem 3rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  overflow: hidden;
}

.content-col :deep(h1) {
  font-family: 'Outfit', sans-serif;
  font-size: 2.2rem;
  font-weight: 800;
  line-height: 1.15;
  letter-spacing: -0.02em;
  margin-bottom: 1.2rem;
  padding-bottom: 0.8rem;
  background: linear-gradient(135deg, #818cf8 0%, #c084fc 60%, #f472b6 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  border-bottom: 1px solid rgba(99,102,241,0.2);
}

.content-col :deep(h2) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.2rem;
  font-weight: 700;
  color: #a5b4fc;
  margin-top: 1rem;
  margin-bottom: 0.5rem;
}
</style>
