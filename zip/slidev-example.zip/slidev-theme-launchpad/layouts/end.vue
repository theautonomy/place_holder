<template>
  <div class="layout-end">
    <div class="glow glow-1" />
    <div class="glow glow-2" />
    <div class="dot-grid" />
    <div class="content">
      <div class="logo-ring">
        <span class="logo-initials">{{ initials }}</span>
      </div>
      <slot />
      <div class="bottom-bar-gradient" />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
const props = defineProps({ $slidev: Object })
const initials = computed(() => {
  const c = props.$slidev?.configs?.company || props.$slidev?.configs?.author || 'LP'
  return c.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
})
</script>

<style scoped>
.layout-end {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.glow {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
  filter: blur(80px);
}
.glow-1 {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 75%;
  height: 75%;
  background: radial-gradient(ellipse, rgba(99,102,241,0.22) 0%, transparent 65%);
}
.glow-2 {
  bottom: -10%;
  right: -5%;
  width: 40%;
  height: 40%;
  background: radial-gradient(ellipse, rgba(236,72,153,0.12) 0%, transparent 70%);
}

.dot-grid {
  position: absolute;
  inset: 0;
  background-image: radial-gradient(circle, rgba(99,102,241,0.15) 1px, transparent 1px);
  background-size: 36px 36px;
  pointer-events: none;
}

.content {
  position: relative;
  z-index: 1;
  text-align: center;
  padding: 2rem 4rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
}

.logo-ring {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  padding: 2.5px;
  background: linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899);
}
.logo-initials {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: #0d0d28;
  font-family: 'Outfit', sans-serif;
  font-weight: 900;
  font-size: 1.4rem;
  background: linear-gradient(135deg, #818cf8, #c084fc);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.content :deep(h1) {
  font-family: 'Outfit', sans-serif;
  font-size: 3rem;
  font-weight: 900;
  letter-spacing: -0.03em;
  background: linear-gradient(135deg, #a5b4fc 0%, #c084fc 50%, #f9a8d4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
}

.content :deep(p) {
  font-size: 1rem;
  color: rgba(226,232,240,0.5);
  margin: 0;
}

.content :deep(a) {
  color: #a5b4fc;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.2s;
}
.content :deep(a:hover) {
  color: #c084fc;
}

.bottom-bar-gradient {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, #6366f1, #8b5cf6, #ec4899, transparent);
}
</style>
