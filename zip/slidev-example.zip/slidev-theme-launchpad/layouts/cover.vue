<template>
  <div class="layout-cover">
    <!-- Background image (optional) -->
    <div v-if="background" class="bg-image" :style="{ backgroundImage: `url(${background})` }" />
    <div class="bg-overlay" />
    <!-- Glow orbs -->
    <div class="glow glow-1" />
    <div class="glow glow-2" />
    <div class="glow glow-3" />
    <!-- Dot grid -->
    <div class="dot-grid" />

    <!-- Top bar -->
    <div class="top-bar">
      <span v-if="$slidev.configs.company" class="company-name">
        {{ $slidev.configs.company }}
      </span>
    </div>

    <!-- Main content -->
    <div class="content">
      <slot />
    </div>

    <!-- Bottom bar -->
    <div class="bottom-bar">
      <span v-if="$slidev.configs.author" class="meta-item">{{ $slidev.configs.author }}</span>
      <span v-if="$slidev.configs.author && $slidev.configs.date" class="dot">·</span>
      <span v-if="$slidev.configs.date" class="meta-item">{{ $slidev.configs.date }}</span>
      <div class="bottom-bar-gradient" />
    </div>
  </div>
</template>

<script setup>
defineProps({ background: String })
</script>

<style scoped>
.layout-cover {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #06061a;
  overflow: hidden;
}

/* ── Background image ── */
.bg-image {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  opacity: 0.25;
  pointer-events: none;
}
.bg-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(6,6,26,0.7) 0%, rgba(6,6,26,0.4) 100%);
  pointer-events: none;
}

/* ── Background glow orbs ── */
.glow {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
  filter: blur(90px);
}
.glow-1 {
  top: -15%;
  left: 50%;
  transform: translateX(-50%);
  width: 70%;
  height: 55%;
  background: radial-gradient(ellipse, rgba(99,102,241,0.25) 0%, transparent 70%);
}
.glow-2 {
  bottom: 10%;
  left: -10%;
  width: 45%;
  height: 45%;
  background: radial-gradient(ellipse, rgba(139,92,246,0.15) 0%, transparent 70%);
}
.glow-3 {
  top: 20%;
  right: -5%;
  width: 35%;
  height: 40%;
  background: radial-gradient(ellipse, rgba(236,72,153,0.12) 0%, transparent 70%);
}

/* ── Dot grid ── */
.dot-grid {
  position: absolute;
  inset: 0;
  background-image: radial-gradient(circle, rgba(99,102,241,0.18) 1px, transparent 1px);
  background-size: 36px 36px;
  pointer-events: none;
}

/* ── Top bar ── */
.top-bar {
  position: relative;
  z-index: 2;
  padding: 1.4rem 2.5rem;
  display: flex;
  align-items: center;
}
.company-name {
  font-family: 'Outfit', sans-serif;
  font-weight: 700;
  font-size: 0.85rem;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  background: linear-gradient(135deg, #818cf8 0%, #c084fc 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

/* ── Main content ── */
.content {
  position: relative;
  z-index: 2;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 1rem 3.5rem 1rem;
}

/* Heading styles injected into slot */
.content :deep(h1) {
  font-family: 'Outfit', sans-serif;
  font-size: 3.8rem;
  font-weight: 900;
  line-height: 1.1;
  letter-spacing: -0.03em;
  background: linear-gradient(135deg, #a5b4fc 0%, #c084fc 40%, #f9a8d4 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 1rem;
}

.content :deep(h2) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.45rem;
  font-weight: 400;
  color: rgba(226,232,240,0.65);
  margin-top: 0;
  line-height: 1.5;
  letter-spacing: 0;
}

.content :deep(p) {
  font-size: 1.05rem;
  color: rgba(226,232,240,0.6);
  margin-top: 0.5rem;
}

/* Gradient divider that appears after h1 */
.content :deep(h1::after) {
  content: '';
  display: block;
  width: 5rem;
  height: 3px;
  margin-top: 1.2rem;
  background: linear-gradient(90deg, #6366f1, #ec4899, transparent);
  border-radius: 2px;
}

/* ── Bottom bar ── */
.bottom-bar {
  position: relative;
  z-index: 2;
  padding: 1rem 2.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.bottom-bar-gradient {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, #6366f1, #8b5cf6, #ec4899, transparent);
}
.meta-item {
  font-size: 0.8rem;
  color: rgba(226,232,240,0.4);
  font-family: 'Inter', sans-serif;
}
.dot {
  color: rgba(226,232,240,0.25);
  font-size: 0.8rem;
}
</style>
