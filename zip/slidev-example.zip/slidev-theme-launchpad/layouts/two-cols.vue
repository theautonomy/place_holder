<template>
  <div class="layout-two-cols">
    <div class="glow" />
    <div class="accent-bar" />
    <div class="content">
      <div class="header" v-if="$slots.header">
        <slot name="header" />
      </div>
      <div class="cols">
        <div class="col col-left">
          <slot />
        </div>
        <div class="divider" />
        <div class="col col-right">
          <slot name="right" />
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.layout-two-cols {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  overflow: hidden;
}

.glow {
  position: absolute;
  top: -20%;
  right: -5%;
  width: 55%;
  height: 65%;
  background: radial-gradient(ellipse, rgba(99,102,241,0.1) 0%, transparent 70%);
  filter: blur(60px);
  pointer-events: none;
}

.accent-bar {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background: linear-gradient(180deg, #6366f1 0%, #8b5cf6 50%, #ec4899 100%);
}

.content {
  position: relative;
  z-index: 1;
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 2.5rem 2.5rem 2.5rem 3.5rem;
  gap: 1rem;
}

.header :deep(h1) {
  font-family: 'Outfit', sans-serif;
  font-size: 2rem;
  font-weight: 800;
  letter-spacing: -0.02em;
  background: linear-gradient(135deg, #818cf8 0%, #c084fc 60%, #f472b6 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  padding-bottom: 0.8rem;
  border-bottom: 1px solid rgba(99,102,241,0.2);
  margin: 0 0 0.5rem;
}

.cols {
  flex: 1;
  display: flex;
  gap: 0;
  min-height: 0;
}

.col {
  flex: 1;
  overflow: hidden;
}

.col-left {
  padding-right: 1.5rem;
}
.col-right {
  padding-left: 1.5rem;
}

.divider {
  width: 1px;
  background: linear-gradient(180deg, transparent, rgba(99,102,241,0.4) 20%, rgba(139,92,246,0.4) 80%, transparent);
  flex-shrink: 0;
}

.col :deep(h1),
.col :deep(h2) {
  font-family: 'Outfit', sans-serif;
  font-size: 1.3rem;
  font-weight: 700;
  color: #a5b4fc;
  margin-top: 0;
  margin-bottom: 0.7rem;
}

.col :deep(h3) {
  font-family: 'Outfit', sans-serif;
  font-size: 1rem;
  font-weight: 600;
  color: #c084fc;
  margin-top: 0.8rem;
  margin-bottom: 0.4rem;
}
</style>
