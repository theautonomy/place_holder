<template>
  <div class="layout-fact">
    <div class="glow" />
    <div class="ring" />
    <div class="content">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.layout-fact {
  position: relative;
  width: 100%;
  height: 100%;
  background: #06061a;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.glow {
  position: absolute;
  inset: 0;
  background: radial-gradient(ellipse at center, rgba(139,92,246,0.2) 0%, transparent 60%);
  pointer-events: none;
}

.ring {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 340px;
  height: 340px;
  border-radius: 50%;
  border: 1px solid rgba(99,102,241,0.15);
  box-shadow: 0 0 60px rgba(99,102,241,0.08), inset 0 0 60px rgba(99,102,241,0.05);
  pointer-events: none;
}

.content {
  position: relative;
  z-index: 1;
  text-align: center;
  padding: 2rem 3rem;
}

/* The big number/stat — h1 or h2 */
.content :deep(h1),
.content :deep(h2) {
  font-family: 'Outfit', sans-serif;
  font-size: 5.5rem;
  font-weight: 900;
  letter-spacing: -0.04em;
  line-height: 1;
  background: linear-gradient(135deg, #818cf8 0%, #c084fc 50%, #f472b6 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 0.6rem;
}

/* Caption / label — p tag */
.content :deep(p) {
  font-family: 'Inter', sans-serif;
  font-size: 1.2rem;
  font-weight: 500;
  color: rgba(226,232,240,0.55);
  letter-spacing: 0.06em;
  text-transform: uppercase;
  margin: 0;
}
</style>
