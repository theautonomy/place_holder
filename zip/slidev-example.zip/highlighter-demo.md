---
theme: default
title: Shiki Syntax Themes
#highlight: tokyo-night
highlight: github-dark 
colorSchema: dark
transition: fade
routerMode: hash
---

<div class="cover-layout">
  <div class="cover-left">
    <p class="cover-pretitle">67 Bundled Themes</p>
    <h1 class="cover-title">Shiki<br>Syntax<br>Themes</h1>
    <p class="cover-sub">
      Beautiful, accurate, fast —<br>
      every theme ready for Slidev.
    </p>
    <a class="cover-link" href="https://shiki.style/themes" target="_blank">shiki.style/themes →</a>
  </div>
  <div class="cover-right">
    <ThemeDemo theme="tokyo-night" />
  </div>
</div>

<style>
.cover-layout {
  display: grid;
  grid-template-columns: 1fr 1.6fr;
  gap: 2rem;
  height: 100%;
  align-items: center;
  padding: 2rem 2.5rem;
}
.cover-pretitle {
  font-size: 0.85rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: #7aa2f7;
  margin-bottom: 0.6rem;
  font-weight: 600;
}
.cover-title {
  font-size: 3rem;
  font-weight: 800;
  line-height: 1.1;
  color: #c0caf5;
  margin: 0 0 1rem;
}
.cover-sub {
  font-size: 0.95rem;
  color: #9aa5ce;
  line-height: 1.6;
  margin-bottom: 1.2rem;
}
.cover-link {
  display: inline-block;
  font-size: 0.85rem;
  color: #7aa2f7;
  text-decoration: none;
  border-bottom: 1px solid rgba(122, 162, 247, 0.4);
  padding-bottom: 1px;
}
.cover-link:hover { border-color: #7aa2f7; }
.cover-right {
  height: 100%;
}
</style>

---

# `highlight: tokyo-night`

```typescript {all|1|3-7|9-14|16-17|all}
import { ref, computed } from 'vue'

interface User {
  id: number
  name: string
  role: 'admin' | 'user'
}

async function getUsers(page = 1) {
  const url = `/api/users?page=${page}`
  const res = await fetch(url)
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return res.json() as Promise<User[]>
}

const count = ref(0)
const doubled = computed(() => count.value * 2)
```

---

# Community Favorites

<div class="theme-grid">
  <ThemeDemo theme="tokyo-night" />
  <ThemeDemo theme="one-dark-pro" />
  <ThemeDemo theme="dracula" />
  <ThemeDemo theme="github-dark" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---

# Catppuccin

<div class="theme-grid">
  <ThemeDemo theme="catppuccin-mocha" />
  <ThemeDemo theme="catppuccin-macchiato" />
  <ThemeDemo theme="catppuccin-frappe" />
  <ThemeDemo theme="catppuccin-latte" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---

# GitHub Family

<div class="theme-grid">
  <ThemeDemo theme="github-dark-default" />
  <ThemeDemo theme="github-dark-dimmed" />
  <ThemeDemo theme="github-light-default" />
  <ThemeDemo theme="github-light-high-contrast" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---

# Material Design

<div class="theme-grid">
  <ThemeDemo theme="material-theme" />
  <ThemeDemo theme="material-theme-ocean" />
  <ThemeDemo theme="material-theme-palenight" />
  <ThemeDemo theme="material-theme-lighter" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---

# Kanagawa & Nord

<div class="theme-grid">
  <ThemeDemo theme="kanagawa-wave" />
  <ThemeDemo theme="kanagawa-dragon" />
  <ThemeDemo theme="kanagawa-lotus" />
  <ThemeDemo theme="nord" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---

# Rose Pine & Gruvbox

<div class="theme-grid">
  <ThemeDemo theme="rose-pine" />
  <ThemeDemo theme="rose-pine-moon" />
  <ThemeDemo theme="gruvbox-dark-hard" />
  <ThemeDemo theme="gruvbox-light-medium" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---

# Bold & Vibrant

<div class="theme-grid">
  <ThemeDemo theme="synthwave-84" />
  <ThemeDemo theme="poimandres" />
  <ThemeDemo theme="laserwave" />
  <ThemeDemo theme="andromeeda" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---

# Light Themes

<div class="theme-grid">
  <ThemeDemo theme="one-light" />
  <ThemeDemo theme="solarized-light" />
  <ThemeDemo theme="rose-pine-dawn" />
  <ThemeDemo theme="vitesse-light" />
</div>

<style>
.theme-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
  height: calc(100% - 3rem);
  margin-top: 0.5rem;
}
</style>

---
layout: center
class: px-8
---

# All 67 Themes

<div class="all-themes">
  <div class="col">
    <p class="col-head">🌙 Dark</p>
    <span class="chip dark">andromeeda</span>
    <span class="chip dark">aurora-x</span>
    <span class="chip dark">ayu-dark</span>
    <span class="chip dark">ayu-mirage</span>
    <span class="chip dark">catppuccin-frappe</span>
    <span class="chip dark">catppuccin-macchiato</span>
    <span class="chip dark">catppuccin-mocha</span>
    <span class="chip dark">dark-plus</span>
    <span class="chip dark">dracula</span>
    <span class="chip dark">dracula-soft</span>
    <span class="chip dark">everforest-dark</span>
    <span class="chip dark">github-dark</span>
    <span class="chip dark">github-dark-default</span>
    <span class="chip dark">github-dark-dimmed</span>
    <span class="chip dark">github-dark-high-contrast</span>
    <span class="chip dark">gruvbox-dark-hard</span>
    <span class="chip dark">gruvbox-dark-medium</span>
    <span class="chip dark">gruvbox-dark-soft</span>
    <span class="chip dark">horizon</span>
    <span class="chip dark">houston</span>
    <span class="chip dark">kanagawa-dragon</span>
    <span class="chip dark">kanagawa-wave</span>
    <span class="chip dark">laserwave</span>
    <span class="chip dark">material-theme</span>
    <span class="chip dark">material-theme-darker</span>
    <span class="chip dark">material-theme-ocean</span>
    <span class="chip dark">material-theme-palenight</span>
    <span class="chip dark">min-dark</span>
    <span class="chip dark">monokai</span>
    <span class="chip dark">night-owl</span>
    <span class="chip dark">nord</span>
    <span class="chip dark">one-dark-pro</span>
    <span class="chip dark">plastic</span>
    <span class="chip dark">poimandres</span>
    <span class="chip dark">red</span>
    <span class="chip dark">rose-pine</span>
    <span class="chip dark">rose-pine-moon</span>
    <span class="chip dark">slack-dark</span>
    <span class="chip dark">solarized-dark</span>
    <span class="chip dark">synthwave-84</span>
    <span class="chip dark">tokyo-night</span>
    <span class="chip dark">vesper</span>
    <span class="chip dark">vitesse-black</span>
    <span class="chip dark">vitesse-dark</span>
  </div>
  <div class="col">
    <p class="col-head">☀️ Light</p>
    <span class="chip light">ayu-light</span>
    <span class="chip light">catppuccin-latte</span>
    <span class="chip light">everforest-light</span>
    <span class="chip light">github-light</span>
    <span class="chip light">github-light-default</span>
    <span class="chip light">github-light-high-contrast</span>
    <span class="chip light">gruvbox-light-hard</span>
    <span class="chip light">gruvbox-light-medium</span>
    <span class="chip light">gruvbox-light-soft</span>
    <span class="chip light">horizon-bright</span>
    <span class="chip light">kanagawa-lotus</span>
    <span class="chip light">light-plus</span>
    <span class="chip light">material-theme-lighter</span>
    <span class="chip light">min-light</span>
    <span class="chip light">night-owl-light</span>
    <span class="chip light">one-light</span>
    <span class="chip light">rose-pine-dawn</span>
    <span class="chip light">slack-ochin</span>
    <span class="chip light">snazzy-light</span>
    <span class="chip light">solarized-light</span>
    <span class="chip light">vitesse-light</span>
  </div>
</div>

<style>
.all-themes {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin-top: 0.8rem;
}
.col-head {
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: #9aa5ce;
  margin-bottom: 0.5rem;
}
.chip {
  display: inline-block;
  font-family: ui-monospace, monospace;
  font-size: 0.6rem;
  padding: 1px 7px;
  border-radius: 3px;
  margin: 2px 2px;
  font-weight: 500;
  letter-spacing: 0.02em;
}
.chip.dark {
  background: rgba(122, 162, 247, 0.12);
  color: #7aa2f7;
  border: 1px solid rgba(122, 162, 247, 0.3);
}
.chip.light {
  background: rgba(255, 214, 69, 0.1);
  color: #e0af68;
  border: 1px solid rgba(224, 175, 104, 0.3);
}
</style>
