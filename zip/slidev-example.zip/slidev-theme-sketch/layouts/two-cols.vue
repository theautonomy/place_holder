<template>
  <div class="layout-two-cols">
    <div class="notebook-bg" />
    <div class="inner">
      <div class="col col-left">
        <slot />
      </div>

      <!-- Hand-drawn divider -->
      <div class="divider">
        <svg viewBox="0 0 20 400" preserveAspectRatio="none" class="divider-svg">
          <path
            d="M10,0 C8,40 12,80 10,120 C8,160 12,200 10,240 C8,280 12,320 10,360 C8,380 10,400 10,400"
            fill="none" stroke="#d4d8e8" stroke-width="2" stroke-linecap="round"/>
        </svg>
      </div>

      <div class="col col-right">
        <slot name="right" />
      </div>
    </div>
  </div>
</template>

<style scoped>
.layout-two-cols {
  width: 100%;
  height: 100%;
  background: #fdf8ef;
  display: flex;
  flex-direction: column;
  position: relative;
  overflow: hidden;
}

.notebook-bg {
  position: absolute;
  inset: 0;
  pointer-events: none;
  background-image: repeating-linear-gradient(
    0deg,
    transparent,
    transparent calc(2.5rem - 1px),
    rgba(180, 190, 220, 0.25) calc(2.5rem - 1px),
    rgba(180, 190, 220, 0.25) calc(2.5rem)
  );
}

.inner {
  flex: 1;
  min-height: 0;
  display: flex;
  padding: 1.4rem 2rem;
  gap: 0;
  position: relative;
  z-index: 1;
  overflow: hidden;
}

.col {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
}
.col-left  { padding-right: 1.2rem; }
.col-right { padding-left:  1.2rem; }

/* Wavy SVG divider */
.divider {
  flex-shrink: 0;
  width: 20px;
  align-self: stretch;
}
.divider-svg {
  width: 100%;
  height: 100%;
}

/* Column content styles */
.col :deep(h1) {
  font-size: 2.4rem;
  font-weight: 700;
  color: #1e1e2e;
  margin: 0 0 0.4rem;
  border-bottom: 2px dashed #d4d8e8;
  padding-bottom: 0.3rem;
}
.col :deep(h2) {
  font-size: 1.7rem;
  font-weight: 700;
  color: #3b5bdb;
  margin: 0.7rem 0 0.2rem;
}
.col :deep(h3) {
  font-size: 1.35rem;
  color: #64637a;
  margin: 0.4rem 0 0.15rem;
}
.col :deep(p)  { margin: 0.25rem 0; font-size: 1.35rem; }
.col :deep(li) { margin-bottom: 0.2rem; font-size: 1.35rem; }
.col :deep(pre) {
  font-size: 0.95rem !important;
  margin: 0.4rem 0 !important;
  line-height: 1.55 !important;
}
</style>
