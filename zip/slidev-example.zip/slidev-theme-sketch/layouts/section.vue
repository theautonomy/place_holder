<template>
  <div class="layout-section">
    <div class="paper-lines" />

    <div class="inner">
      <!-- Hand-drawn circled section number -->
      <div class="section-num" v-if="sectionNumber">
        <svg viewBox="0 0 80 80" class="circle-svg">
          <!-- Imperfect circle — slightly irregular path -->
          <path
            d="M40,8 C58,6 74,22 74,40 C74,59 58,73 40,72 C22,73 6,58 7,40 C6,22 22,6 40,8 Z"
            fill="none" stroke="#3b5bdb" stroke-width="2.5" stroke-linecap="round"/>
        </svg>
        <span class="num-text">{{ sectionNumber }}</span>
      </div>

      <div class="title-block">
        <h1><slot /></h1>

        <!-- Wavy underline -->
        <svg class="wavy" viewBox="0 0 300 14" preserveAspectRatio="none">
          <path
            d="M0,7 Q25,1 50,7 Q75,13 100,7 Q125,1 150,7 Q175,13 200,7 Q225,1 250,7 Q275,13 300,7"
            fill="none" stroke="#3b5bdb" stroke-width="2.5" stroke-linecap="round"/>
        </svg>

        <p class="subtitle" v-if="$slots.default && subtitle">{{ subtitle }}</p>
        <div class="subtitle" v-if="$slots.subtitle">
          <slot name="subtitle" />
        </div>
      </div>
    </div>

    <!-- Scattered decorations -->
    <span class="deco d1">✦</span>
    <span class="deco d2">✶</span>
    <span class="deco d3">○</span>
  </div>
</template>

<script setup>
defineProps({
  sectionNumber: { default: '' },
  subtitle:      { default: '' },
})
</script>

<style scoped>
.layout-section {
  width: 100%;
  height: 100%;
  background: #fdf8ef;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
}

.paper-lines {
  position: absolute;
  inset: 0;
  background-image: repeating-linear-gradient(
    0deg,
    transparent,
    transparent calc(2.5rem - 1px),
    rgba(180, 190, 220, 0.2) calc(2.5rem - 1px),
    rgba(180, 190, 220, 0.2) calc(2.5rem)
  );
  pointer-events: none;
}

.inner {
  display: flex;
  align-items: center;
  gap: 2.5rem;
  position: relative;
  z-index: 1;
}

/* Circled number */
.section-num {
  position: relative;
  width: 90px;
  height: 90px;
  flex-shrink: 0;
}
.circle-svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}
.num-text {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: 'Caveat', cursive;
  font-size: 2.4rem;
  font-weight: 700;
  color: #3b5bdb;
  line-height: 1;
}

.title-block {
  flex: 1;
}

h1 {
  font-family: 'Caveat', cursive;
  font-size: 3.2rem;
  font-weight: 700;
  color: #1e1e2e;
  margin: 0 0 0.1rem;
  line-height: 1.1;
}

/* Italic/em inside title gets accent colour */
h1 :deep(em) {
  color: #3b5bdb;
  font-style: italic;
}

.wavy {
  display: block;
  width: 100%;
  max-width: 400px;
  height: 14px;
  margin: 0.25rem 0 0.4rem;
}

.subtitle {
  font-family: 'Caveat', cursive;
  font-size: 1.4rem;
  color: #64637a;
  margin-top: 0.3rem;
  font-style: italic;
}

/* Scattered decorations */
.deco {
  position: absolute;
  color: #3b5bdb;
  opacity: 0.12;
  pointer-events: none;
}
.d1 { top: 12%;    right: 8%;   font-size: 3rem; transform: rotate(20deg);  }
.d2 { bottom: 12%; right: 15%;  font-size: 2rem; transform: rotate(-10deg); }
.d3 { bottom: 20%; left:  8%;   font-size: 4rem; transform: rotate(5deg);   }
</style>
