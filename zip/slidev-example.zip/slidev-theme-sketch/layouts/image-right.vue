<template>
  <div class="layout-image-right">
    <!-- Notebook ruled lines + margin line on the left pane -->
    <div class="notebook-bg" />

    <div class="content">
      <slot />
    </div>

    <div
      class="image-pane"
      :style="{
        backgroundImage: `url(${image})`,
        backgroundSize: imageSize,
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }"
    />
  </div>
</template>

<script setup>
defineProps({
  image: {
    type: String,
    required: true,
  },
  imageSize: {
    type: String,
    default: 'cover',
  },
})
</script>

<style scoped>
.layout-image-right {
  width: 100%;
  height: 100%;
  background: #fdf8ef;
  position: relative;
  display: flex;
  overflow: hidden;
}

/* Notebook paper texture: horizontal rules + red margin line (left pane only) */
.notebook-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 55%;
  bottom: 0;
  pointer-events: none;
  background-image:
    /* horizontal ruled lines */
    repeating-linear-gradient(
      0deg,
      transparent,
      transparent calc(2.5rem - 1px),
      rgba(180, 190, 220, 0.3) calc(2.5rem - 1px),
      rgba(180, 190, 220, 0.3) calc(2.5rem)
    ),
    /* red margin line */
    linear-gradient(
      90deg,
      transparent 4.8rem,
      rgba(224, 49, 49, 0.2) 4.8rem,
      rgba(224, 49, 49, 0.2) calc(4.8rem + 2px),
      transparent calc(4.8rem + 2px)
    );
}

.content {
  flex: 0 0 55%;
  min-height: 0;
  padding: 1.4rem 2.2rem 1.4rem 5.6rem;
  overflow-y: auto;
  position: relative;
  z-index: 1;
}

.image-pane {
  flex: 0 0 45%;
  min-height: 0;
  position: relative;
  border-left: 2.5px solid #d4d8e8;
  box-shadow: inset 4px 0 12px rgba(59, 91, 219, 0.06);
  /* Slightly desaturate the photo so it blends with the paper palette */
  filter: sepia(15%) saturate(90%);
}

/* Heading styles matching default.vue */
.content :deep(h1) {
  font-size: 2.6rem;
  font-weight: 700;
  color: #1e1e2e;
  margin: 0 0 0.3rem;
  padding-bottom: 0.25rem;
  border-bottom: 2.5px solid #1e1e2e;
  display: inline-block;
  width: 100%;
}

.content :deep(h2) {
  font-size: 1.9rem;
  font-weight: 700;
  color: #3b5bdb;
  margin: 0.8rem 0 0.3rem;
}

.content :deep(h3) {
  font-size: 1.45rem;
  color: #64637a;
  font-weight: 600;
  margin: 0.5rem 0 0.2rem;
}

.content :deep(p) {
  margin: 0.3rem 0;
}

.content :deep(pre) {
  margin: 0.6rem 0 !important;
  font-size: 1rem !important;
  line-height: 1.6 !important;
}

.content :deep(ul),
.content :deep(ol) {
  margin: 0.3rem 0;
}
</style>
