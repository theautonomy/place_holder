<!--
  whiteboard layout — dot-grid background for diagrams, Mermaid charts, free-form notes.
  Optional named slot "title" for a small heading above the canvas.

  Excalidraw SVG sizing:
    The Excalidraw addon sets inline "max-width:100%; height:auto" on the SVG.
    For inline SVG with a viewBox, constraining width via the wrapper class (e.g.
    class="w-[600px]") makes max-width:100% kick in, and height:auto then scales
    proportionally — the same way <img> behaves.  Using w-full (960px) is too wide
    to trigger the constraint on a 670px-wide drawing, so always pass an explicit
    width class to <Excalidraw> inside this layout.
-->
<template>
  <div class="layout-whiteboard">
    <div class="dot-grid" />

    <div class="title-bar" v-if="$slots.title">
      <slot name="title" />
    </div>

    <div class="canvas">
      <div class="fit-box">
        <slot />
      </div>
    </div>
  </div>
</template>

<script setup>
// No JavaScript needed — sizing is handled entirely via CSS.
// See comment above for Excalidraw width guidance.
</script>

<style scoped>
.layout-whiteboard {
  width: 100%;
  height: 100%;
  background: #fffef9;
  display: flex;
  flex-direction: column;
  position: relative;
  overflow: hidden;
}

/* Dot grid — classic whiteboard/graph paper */
.dot-grid {
  position: absolute;
  inset: 0;
  pointer-events: none;
  background-image: radial-gradient(circle, #b8c0cc 1px, transparent 1px);
  background-size: 28px 28px;
  opacity: 0.4;
}

/* Optional title bar */
.title-bar {
  position: relative;
  z-index: 1;
  flex-shrink: 0;
  padding: 0.5rem 1.8rem 0;
  border-bottom: 1.5px dashed rgba(180, 190, 220, 0.6);
}

.title-bar :deep(h1) {
  font-family: 'Caveat', cursive;
  font-size: 1.6rem;
  font-weight: 700;
  color: #64637a;
  margin: 0;
}

.title-bar :deep(h1 em) {
  color: #3b5bdb;
  font-style: italic;
}

/* Canvas — flex:1 fills remaining height; position:relative anchors fit-box */
.canvas {
  flex: 1;
  min-height: 0;
  position: relative;
  z-index: 1;
  overflow: hidden;
}

/*
  fit-box: absolutely positioned inside .canvas (position:relative).
  With explicit top/right/bottom/left the browser gives it a DEFINITE height —
  unlike flex:1 or height:100% which CSS percentage resolution treats as
  indefinite for children outside the flex algorithm.
*/
.fit-box {
  position: absolute;
  inset: 0.6rem 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

/*
  Give the Excalidraw wrapper (.w-full) an explicit height so the SVG inside
  can resolve max-height:100% against a real number.
  height:100% on a flex item resolves against the flex container's height —
  and .fit-box's height IS definite (from inset:0.6rem 1rem above).
*/
.fit-box :deep(.w-full) {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

/*
  SVG constraint: max-height:100% now resolves against .w-full's definite height.
  The SVG's existing inline "height:auto" is kept — the browser starts from the
  intrinsic 525 px, clamps it to the canvas height (~480 px), and proportionally
  adjusts the width via the SVG's intrinsic aspect ratio.
  width:auto overrides the width="670" presentation attribute for that adjustment.
  No !important needed — there is no competing inline max-height or width style.
*/
.fit-box :deep(.w-full svg) {
  max-height: 100%;
  width: auto;
}

/* Mermaid diagrams get a clean white card — selector still works via :deep */
.fit-box :deep(.mermaid) {
  background: rgba(255, 255, 251, 0.9);
  border-radius: 8px 4px 6px 3px / 3px 6px 4px 8px;
  padding: 0.8rem;
  box-shadow: 3px 4px 0 rgba(180, 190, 220, 0.4);
}
</style>
