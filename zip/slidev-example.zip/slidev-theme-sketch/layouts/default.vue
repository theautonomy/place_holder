<template>
  <div class="layout-default">
    <!-- Notebook ruled lines + margin line -->
    <div class="notebook-bg" />

    <div class="content">
      <slot />
    </div>
  </div>
</template>

<style scoped>
.layout-default {
  width: 100%;
  height: 100%;
  background: #fdf8ef;
  position: relative;
  display: flex;
  overflow: hidden;
}

/* Notebook paper: horizontal rules + red margin line */
.notebook-bg {
  position: absolute;
  inset: 0;
  pointer-events: none;
  background-image:
    /* horizontal ruled lines */
    repeating-linear-gradient(
      0deg,
      transparent,
      transparent calc(2.5rem - 1px),
      rgba(180, 190, 220, 0.3) calc(2.5rem - 1px),
      rgba(180, 190, 220, 0.3) calc(2.5rem)
    ),
    /* red margin line */
    linear-gradient(
      90deg,
      transparent 4.8rem,
      rgba(224, 49, 49, 0.2) 4.8rem,
      rgba(224, 49, 49, 0.2) calc(4.8rem + 2px),
      transparent calc(4.8rem + 2px)
    );
}

.content {
  flex: 1;
  min-height: 0;
  padding: 1.4rem 2.2rem 1.4rem 5.6rem;
  overflow-y: auto;
  position: relative;
  z-index: 1;
}

/* Heading styles inside default layout */
.content :deep(h1) {
  font-size: 2.6rem;
  font-weight: 700;
  color: #1e1e2e;
  margin: 0 0 0.3rem;
  padding-bottom: 0.25rem;
  /* Hand-written underline using box-shadow trick */
  border-bottom: 2.5px solid #1e1e2e;
  display: inline-block;
  width: 100%;
}

.content :deep(h2) {
  font-size: 1.9rem;
  font-weight: 700;
  color: #3b5bdb;
  margin: 0.8rem 0 0.3rem;
}

.content :deep(h3) {
  font-size: 1.45rem;
  color: #64637a;
  font-weight: 600;
  margin: 0.5rem 0 0.2rem;
}

.content :deep(p) {
  margin: 0.3rem 0;
}

.content :deep(pre) {
  margin: 0.6rem 0 !important;
  font-size: 1rem !important;
  line-height: 1.6 !important;
}

.content :deep(ul),
.content :deep(ol) {
  margin: 0.3rem 0;
}
</style>
