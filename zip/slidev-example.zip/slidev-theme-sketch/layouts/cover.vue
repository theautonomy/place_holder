<template>
  <div class="layout-cover">
    <!-- Optional Unsplash / background photo — rendered at low opacity behind the card -->
    <div v-if="image" class="bg-photo" :style="{ backgroundImage: `url(${image})` }" />

    <!-- Subtle ruled lines as texture -->
    <div class="paper-lines" />

    <!-- Corner doodles -->
    <span class="doodle doodle-tl">✦</span>
    <span class="doodle doodle-tr">✦</span>
    <span class="doodle doodle-bl">✶</span>
    <span class="doodle doodle-br">✶</span>

    <!-- Main card -->
    <div class="card">
      <!-- Wavy colour bar at top of card -->
      <svg class="wave-bar" viewBox="0 0 360 12" preserveAspectRatio="none">
        <path d="M0,6 Q30,0 60,6 Q90,12 120,6 Q150,0 180,6 Q210,12 240,6 Q270,0 300,6 Q330,12 360,6"
              fill="none" stroke="#3b5bdb" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M0,6 Q30,12 60,6 Q90,0 120,6 Q150,12 180,6 Q210,0 240,6 Q270,12 300,6 Q330,0 360,6"
              fill="none" stroke="#e03131" stroke-width="1.5" stroke-linecap="round" opacity="0.5"/>
      </svg>

      <div class="card-body">
        <p class="pretitle" v-if="$slots.pretitle || pretitle">
          <slot name="pretitle">{{ pretitle }}</slot>
        </p>

        <h1><slot /></h1>

        <!-- Marker underline under title -->
        <div class="title-underline" />

        <div class="subtitle" v-if="$slots.subtitle">
          <slot name="subtitle" />
        </div>

        <div class="meta">
          <span v-if="$slidev?.configs?.author" class="author">
            ✏ {{ $slidev.configs.author }}
          </span>
          <span v-if="$slidev?.configs?.date" class="date">
            {{ $slidev.configs.date }}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  pretitle: { default: '' },
  image:    { default: '' },   // Unsplash URL rendered faintly behind the card
})
</script>

<style scoped>
.layout-cover {
  width: 100%;
  height: 100%;
  background: #fdf8ef;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
}

/* Optional background photo — washed out so it feels like aged paper */
.bg-photo {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  opacity: 0.12;
  filter: sepia(40%) saturate(80%);
}

/* Faint ruled-line texture */
.paper-lines {
  position: absolute;
  inset: 0;
  background-image: repeating-linear-gradient(
    0deg,
    transparent,
    transparent calc(2.4em - 1px),
    rgba(180, 190, 220, 0.25) calc(2.4em - 1px),
    rgba(180, 190, 220, 0.25) calc(2.4em)
  );
  pointer-events: none;
}

/* Corner star doodles */
.doodle {
  position: absolute;
  font-size: 1.4rem;
  color: #3b5bdb;
  opacity: 0.2;
  pointer-events: none;
}
.doodle-tl { top: 1.4rem;    left: 1.6rem;  transform: rotate(-20deg); }
.doodle-tr { top: 1.4rem;    right: 1.6rem; transform: rotate(15deg);  }
.doodle-bl { bottom: 1.4rem; left: 1.6rem;  transform: rotate(10deg);  }
.doodle-br { bottom: 1.4rem; right: 1.6rem; transform: rotate(-15deg); }

/* Card with hand-drawn border illusion */
.card {
  position: relative;
  width: min(72%, 680px);
  background: rgba(255, 255, 251, 0.75);
  border: 2.5px solid #1e1e2e;
  /* Irregular corners — each corner gets a unique radius */
  border-radius: 4px 14px 4px 12px / 12px 4px 14px 4px;
  box-shadow:
    5px 6px 0 rgba(30, 30, 46, 0.07),
    -2px -2px 0 rgba(30, 30, 46, 0.04);
  overflow: hidden;
}

/* Wavy accent line at top of card */
.wave-bar {
  display: block;
  width: 100%;
  height: 12px;
  flex-shrink: 0;
}

.card-body {
  padding: 1.6rem 2.8rem 2rem;
}

/* Optional pre-title / category label */
.pretitle {
  font-family: 'Caveat', cursive;
  font-size: 1.1rem;
  color: #3b5bdb;
  margin: 0 0 0.2rem;
  letter-spacing: 0.08em;
}

h1 {
  font-family: 'Caveat', cursive;
  font-size: 3.4rem;
  font-weight: 700;
  color: #1e1e2e;
  line-height: 1.1;
  margin: 0;
}

/* Multi-colour marker underline */
.title-underline {
  height: 4px;
  margin: 0.6rem 0 0.8rem;
  border-radius: 2px;
  background: linear-gradient(
    90deg,
    #3b5bdb 0%,
    #3b5bdb 40%,
    #e03131 40%,
    #e03131 65%,
    #2f9e44 65%,
    #2f9e44 85%,
    #ffd43b 85%,
    #ffd43b 100%
  );
  opacity: 0.75;
}

.subtitle {
  font-family: 'Caveat', cursive;
  font-size: 1.5rem;
  color: #64637a;
  margin-bottom: 1.2rem;
  line-height: 1.4;
}

.meta {
  display: flex;
  gap: 1.4rem;
  font-family: 'Caveat', cursive;
  font-size: 1.05rem;
  color: #9a98b0;
  border-top: 1.5px dashed #d4d8e8;
  padding-top: 0.6rem;
  margin-top: 0.4rem;
}

.author { color: #64637a; }
.date   { color: #9a98b0; }
</style>
