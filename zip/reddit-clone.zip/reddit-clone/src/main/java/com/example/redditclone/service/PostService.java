package com.example.redditclone.service;

import java.util.List;

import com.example.redditclone.entity.Post;
import com.example.redditclone.entity.User;
import com.example.redditclone.repository.PostRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class PostService {

    @Autowired private PostRepository postRepository;

    public Post createPost(String title, String content, String url, User author) {
        Post post = new Post(title, content, url, author);
        return postRepository.save(post);
    }

    public Page<Post> getAllPosts(Pageable pageable) {
        return postRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    public Page<Post> getPopularPosts(Pageable pageable) {
        return postRepository.findAllOrderByVoteCountDesc(pageable);
    }

    public Post getPostById(Long id) {
        return postRepository.findById(id).orElse(null);
    }

    public List<Post> getPostsByAuthor(Long authorId) {
        return postRepository.findByAuthorIdOrderByCreatedAtDesc(authorId);
    }

    public Post updatePost(Post post) {
        return postRepository.save(post);
    }

    public void deletePost(Long id) {
        postRepository.deleteById(id);
    }
}
