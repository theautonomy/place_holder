package com.example.redditclone.controller;

import java.util.List;

import com.example.redditclone.entity.Comment;
import com.example.redditclone.entity.Post;
import com.example.redditclone.entity.User;
import com.example.redditclone.service.CommentService;
import com.example.redditclone.service.PostService;
import com.example.redditclone.service.VoteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/post")
public class PostController {

    @Autowired private PostService postService;

    @Autowired private CommentService commentService;

    @Autowired private VoteService voteService;

    @GetMapping("/submit")
    public String submitForm() {
        return "post/submit";
    }

    @PostMapping("/submit")
    public String submitPost(
            @RequestParam String title,
            @RequestParam(required = false) String content,
            @RequestParam(required = false) String url,
            Authentication auth,
            RedirectAttributes redirectAttributes) {

        if (title.trim().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Title is required");
            return "redirect:/post/submit";
        }

        User user = (User) auth.getPrincipal();
        Post post = postService.createPost(title, content, url, user);

        return "redirect:/post/" + post.getId();
    }

    @GetMapping("/{id}")
    public String viewPost(@PathVariable Long id, Model model, Authentication auth) {
        Post post = postService.getPostById(id);
        if (post == null) {
            return "redirect:/";
        }

        List<Comment> comments = commentService.getTopLevelComments(id);

        model.addAttribute("post", post);
        model.addAttribute("comments", comments);

        if (auth != null) {
            User user = (User) auth.getPrincipal();
            model.addAttribute("currentUser", user);
        }

        return "post/detail";
    }

    @PostMapping("/{id}/comment")
    public String addComment(
            @PathVariable Long id,
            @RequestParam String content,
            @RequestParam(required = false) Long parentId,
            Authentication auth,
            RedirectAttributes redirectAttributes) {

        if (content.trim().isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Comment content is required");
            return "redirect:/post/" + id;
        }

        Post post = postService.getPostById(id);
        User user = (User) auth.getPrincipal();
        Comment parent = parentId != null ? commentService.getCommentById(parentId) : null;

        commentService.createComment(content, user, post, parent);

        return "redirect:/post/" + id;
    }
}
