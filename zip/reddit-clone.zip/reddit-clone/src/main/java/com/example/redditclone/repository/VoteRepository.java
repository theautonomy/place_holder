package com.example.redditclone.repository;

import java.util.Optional;

import com.example.redditclone.entity.Vote;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface VoteRepository extends JpaRepository<Vote, Long> {
    Optional<Vote> findByUserIdAndPostId(Long userId, Long postId);

    Optional<Vote> findByUserIdAndCommentId(Long userId, Long commentId);

    @Query("SELECT COUNT(v) FROM Vote v WHERE v.post.id = :postId AND v.voteType = 'UPVOTE'")
    long countUpvotesByPostId(@Param("postId") Long postId);

    @Query("SELECT COUNT(v) FROM Vote v WHERE v.post.id = :postId AND v.voteType = 'DOWNVOTE'")
    long countDownvotesByPostId(@Param("postId") Long postId);

    @Query("SELECT COUNT(v) FROM Vote v WHERE v.comment.id = :commentId AND v.voteType = 'UPVOTE'")
    long countUpvotesByCommentId(@Param("commentId") Long commentId);

    @Query(
            "SELECT COUNT(v) FROM Vote v WHERE v.comment.id = :commentId AND v.voteType = 'DOWNVOTE'")
    long countDownvotesByCommentId(@Param("commentId") Long commentId);
}
