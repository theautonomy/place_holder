package com.example.redditclone.controller;

import com.example.redditclone.entity.Post;
import com.example.redditclone.service.PostService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @Autowired private PostService postService;

    @GetMapping("/")
    public String home(
            Model model,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "new") String sort) {

        Pageable pageable = PageRequest.of(page, 10);
        Page<Post> posts;

        if ("hot".equals(sort)) {
            posts = postService.getPopularPosts(pageable);
        } else {
            posts = postService.getAllPosts(pageable);
        }

        model.addAttribute("posts", posts);
        model.addAttribute("currentSort", sort);
        model.addAttribute("currentPage", page);

        return "home";
    }
}
