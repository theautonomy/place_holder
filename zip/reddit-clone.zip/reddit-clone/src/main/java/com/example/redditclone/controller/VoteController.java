package com.example.redditclone.controller;

import com.example.redditclone.entity.User;
import com.example.redditclone.entity.Vote;
import com.example.redditclone.service.VoteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/vote")
public class VoteController {

    @Autowired private VoteService voteService;

    @PostMapping("/post/{postId}")
    public ResponseEntity<?> voteOnPost(
            @PathVariable Long postId, @RequestParam String type, Authentication auth) {

        User user = (User) auth.getPrincipal();
        Vote.VoteType voteType = "up".equals(type) ? Vote.VoteType.UPVOTE : Vote.VoteType.DOWNVOTE;

        voteService.voteOnPost(user, postId, voteType);

        return ResponseEntity.ok().build();
    }

    @PostMapping("/comment/{commentId}")
    public ResponseEntity<?> voteOnComment(
            @PathVariable Long commentId, @RequestParam String type, Authentication auth) {

        User user = (User) auth.getPrincipal();
        Vote.VoteType voteType = "up".equals(type) ? Vote.VoteType.UPVOTE : Vote.VoteType.DOWNVOTE;

        voteService.voteOnComment(user, commentId, voteType);

        return ResponseEntity.ok().build();
    }
}
