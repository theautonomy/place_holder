package com.example.redditclone.config;

import com.example.redditclone.entity.Comment;
import com.example.redditclone.entity.Post;
import com.example.redditclone.entity.User;
import com.example.redditclone.entity.Vote;
import com.example.redditclone.service.CommentService;
import com.example.redditclone.service.PostService;
import com.example.redditclone.service.UserService;
import com.example.redditclone.service.VoteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired private UserService userService;

    @Autowired private PostService postService;

    @Autowired private CommentService commentService;

    @Autowired private VoteService voteService;

    @Override
    public void run(String... args) throws Exception {
        // Create sample users
        User user1 = userService.registerUser("john_doe", "john@example.com", "password");
        User user2 = userService.registerUser("jane_smith", "jane@example.com", "password");
        User user3 = userService.registerUser("reddit_user", "reddit@example.com", "password");

        // Create sample posts
        Post post1 =
                postService.createPost(
                        "Welcome to our Reddit Clone!",
                        "This is a sample post to demonstrate the functionality of our Reddit clone. You can upvote, downvote, and comment on posts just like the real Reddit!",
                        null,
                        user1);

        Post post2 =
                postService.createPost(
                        "Check out this awesome Spring Boot tutorial",
                        null,
                        "https://spring.io/guides/gs/spring-boot/",
                        user2);

        Post post3 =
                postService.createPost(
                        "What do you think about Java 17?",
                        "Java 17 introduced some great features like sealed classes, pattern matching for instanceof, and text blocks. What's your favorite new feature?",
                        null,
                        user3);

        // Create sample comments
        Comment comment1 =
                commentService.createComment(
                        "Great work on this Reddit clone! The UI looks really clean.",
                        user2,
                        post1,
                        null);

        Comment comment2 =
                commentService.createComment(
                        "I love the voting system. Very responsive!", user3, post1, null);

        Comment comment3 =
                commentService.createComment(
                        "Thanks! We used Spring Boot and JTE templating for this.",
                        user1,
                        post1,
                        comment1);

        Comment comment4 =
                commentService.createComment(
                        "Spring Boot is amazing for rapid development. Thanks for sharing!",
                        user1,
                        post2,
                        null);

        Comment comment5 =
                commentService.createComment(
                        "Text blocks are my favorite! They make multiline strings so much cleaner.",
                        user1,
                        post3,
                        null);

        Comment comment6 =
                commentService.createComment(
                        "I agree! Pattern matching is also really useful for reducing boilerplate code.",
                        user2,
                        post3,
                        null);

        // Add some votes
        voteService.voteOnPost(user2, post1.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnPost(user3, post1.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnPost(user1, post2.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnPost(user3, post2.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnPost(user1, post3.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnPost(user2, post3.getId(), Vote.VoteType.UPVOTE);

        voteService.voteOnComment(user1, comment1.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnComment(user3, comment1.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnComment(user1, comment2.getId(), Vote.VoteType.UPVOTE);
        voteService.voteOnComment(user2, comment4.getId(), Vote.VoteType.UPVOTE);

        System.out.println("Sample data initialized successfully!");
    }
}
