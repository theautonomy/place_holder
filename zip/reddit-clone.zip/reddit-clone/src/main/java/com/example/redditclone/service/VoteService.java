package com.example.redditclone.service;

import com.example.redditclone.entity.Comment;
import com.example.redditclone.entity.Post;
import com.example.redditclone.entity.User;
import com.example.redditclone.entity.Vote;
import com.example.redditclone.repository.VoteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class VoteService {

    @Autowired private VoteRepository voteRepository;

    @Autowired private PostService postService;

    @Autowired private CommentService commentService;

    @Transactional
    public void voteOnPost(User user, Long postId, Vote.VoteType voteType) {
        Post post = postService.getPostById(postId);
        if (post == null) return;

        Vote existingVote = voteRepository.findByUserIdAndPostId(user.getId(), postId).orElse(null);

        if (existingVote != null) {
            if (existingVote.getVoteType() == voteType) {
                voteRepository.delete(existingVote);
            } else {
                existingVote.setVoteType(voteType);
                voteRepository.save(existingVote);
            }
        } else {
            Vote newVote = new Vote(user, post, voteType);
            voteRepository.save(newVote);
        }

        updatePostVoteCount(post);
    }

    @Transactional
    public void voteOnComment(User user, Long commentId, Vote.VoteType voteType) {
        Comment comment = commentService.getCommentById(commentId);
        if (comment == null) return;

        Vote existingVote =
                voteRepository.findByUserIdAndCommentId(user.getId(), commentId).orElse(null);

        if (existingVote != null) {
            if (existingVote.getVoteType() == voteType) {
                voteRepository.delete(existingVote);
            } else {
                existingVote.setVoteType(voteType);
                voteRepository.save(existingVote);
            }
        } else {
            Vote newVote = new Vote(user, comment, voteType);
            voteRepository.save(newVote);
        }

        updateCommentVoteCount(comment);
    }

    private void updatePostVoteCount(Post post) {
        long upvotes = voteRepository.countUpvotesByPostId(post.getId());
        long downvotes = voteRepository.countDownvotesByPostId(post.getId());
        post.setVoteCount((int) (upvotes - downvotes));
        postService.updatePost(post);
    }

    private void updateCommentVoteCount(Comment comment) {
        long upvotes = voteRepository.countUpvotesByCommentId(comment.getId());
        long downvotes = voteRepository.countDownvotesByCommentId(comment.getId());
        comment.setVoteCount((int) (upvotes - downvotes));
        commentService.updateComment(comment);
    }

    public Vote getUserVoteForPost(Long userId, Long postId) {
        return voteRepository.findByUserIdAndPostId(userId, postId).orElse(null);
    }

    public Vote getUserVoteForComment(Long userId, Long commentId) {
        return voteRepository.findByUserIdAndCommentId(userId, commentId).orElse(null);
    }
}
