package gg.jte.generated.ondemand.components;
import com.example.redditclone.entity.Comment;
import com.example.redditclone.entity.User;
import java.time.format.DateTimeFormatter;
@SuppressWarnings("unchecked")
public final class JtecommentGenerated {
	public static final String JTE_NAME = "components/comment.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,4,4,4,4,9,9,9,9,9,10,10,10,10,12,14,14,15,15,15,15,21,21,22,22,22,23,23,24,24,24,24,30,30,33,35,37,37,37,39,39,39,42,44,44,44,47,49,49,50,50,50,50,57,57,74,75,75,76,76,76,76,77,77,77,77,78,78,78,78,78,78,78,78,78,83,83,83,83,94,94,99,100,100,102,102,103,103,104,104,106,106,109,109,119,119,119,119,4,5,6,7,7,7,7};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, Comment comment, User currentUser, Long postId, int depth) {
		jteOutput.writeContent("\n<div class=\"");
		if (depth > 0) {
			jteOutput.writeContent("ml-4 border-l-2 border-reddit-light-gray pl-4");
		}
		jteOutput.writeContent("\">\n    <div class=\"py-3 ");
		if (depth == 0) {
			jteOutput.writeContent("border-b border-reddit-light-gray");
		}
		jteOutput.writeContent("\">\n        <div class=\"flex items-start space-x-2\">\n            ");
		jteOutput.writeContent("\n            <div class=\"flex flex-col items-center\">\n                ");
		if (currentUser != null) {
			jteOutput.writeContent("\n                    <button onclick=\"vote(&quot;up&quot;, &quot;comment&quot;, ");
			jteOutput.setContext("button", "onclick");
			jteOutput.writeUserContent(comment.getId());
			jteOutput.setContext("button", null);
			jteOutput.writeContent(")\" \n                            class=\"p-0.5 hover:bg-reddit-light-gray rounded text-reddit-gray hover:text-reddit-orange transition-colors\">\n                        <svg class=\"w-4 h-4\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                            <path d=\"M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z\"/>\n                        </svg>\n                    </button>\n                ");
		}
		jteOutput.writeContent("\n                <span class=\"text-xs font-bold text-gray-900 py-0.5\">");
		jteOutput.setContext("span", null);
		jteOutput.writeUserContent(comment.getVoteCount());
		jteOutput.writeContent("</span>\n                ");
		if (currentUser != null) {
			jteOutput.writeContent("\n                    <button onclick=\"vote(&quot;down&quot;, &quot;comment&quot;, ");
			jteOutput.setContext("button", "onclick");
			jteOutput.writeUserContent(comment.getId());
			jteOutput.setContext("button", null);
			jteOutput.writeContent(")\" \n                            class=\"p-0.5 hover:bg-reddit-light-gray rounded text-reddit-gray hover:text-blue-600 transition-colors\">\n                        <svg class=\"w-4 h-4\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                            <path d=\"M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z\"/>\n                        </svg>\n                    </button>\n                ");
		}
		jteOutput.writeContent("\n            </div>\n\n            ");
		jteOutput.writeContent("\n            <div class=\"flex-1 min-w-0\">\n                ");
		jteOutput.writeContent("\n                <div class=\"flex items-center text-xs text-reddit-gray mb-1\">\n                    <a href=\"#\" class=\"font-bold text-reddit-blue hover:underline\">u/");
		jteOutput.setContext("a", null);
		jteOutput.writeUserContent(comment.getAuthor().getUsername());
		jteOutput.writeContent("</a>\n                    <span class=\"mx-1\">•</span>\n                    <span>");
		jteOutput.setContext("span", null);
		jteOutput.writeUserContent(comment.getCreatedAt().format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")));
		jteOutput.writeContent("</span>\n                </div>\n\n                ");
		jteOutput.writeContent("\n                <div class=\"text-sm text-gray-900 mb-2 leading-relaxed\">\n                    <p class=\"whitespace-pre-wrap break-words\">");
		jteOutput.setContext("p", null);
		jteOutput.writeUserContent(comment.getContent());
		jteOutput.writeContent("</p>\n                </div>\n\n                ");
		jteOutput.writeContent("\n                <div class=\"flex items-center space-x-3 text-xs font-bold text-reddit-gray\">\n                    ");
		if (currentUser != null) {
			jteOutput.writeContent("\n                        <button onclick=\"toggleReplyForm(");
			jteOutput.setContext("button", "onclick");
			jteOutput.writeUserContent(comment.getId());
			jteOutput.setContext("button", null);
			jteOutput.writeContent(")\" \n                                class=\"hover:bg-gray-100 px-2 py-1 rounded transition-colors\">\n                            <svg class=\"w-3 h-3 inline mr-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                <path fill-rule=\"evenodd\" d=\"M7.707 3.293a1 1 0 010 1.414L5.414 7H11a7 7 0 017 7v2a1 1 0 11-2 0v-2a5 5 0 00-5-5H5.414l2.293 2.293a1 1 0 11-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z\" clip-rule=\"evenodd\"/>\n                            </svg>\n                            Reply\n                        </button>\n                    ");
		}
		jteOutput.writeContent("\n                    \n                    <button class=\"hover:bg-gray-100 px-2 py-1 rounded transition-colors\">\n                        <svg class=\"w-3 h-3 inline mr-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                            <path d=\"M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z\"/>\n                        </svg>\n                        Share\n                    </button>\n                    \n                    <button class=\"hover:bg-gray-100 px-2 py-1 rounded transition-colors\">\n                        <svg class=\"w-3 h-3 inline mr-1\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">\n                            <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z\"/>\n                        </svg>\n                        Save\n                    </button>\n                </div>\n\n                ");
		jteOutput.writeContent("\n                ");
		if (currentUser != null) {
			jteOutput.writeContent("\n                    <div id=\"reply-form-");
			jteOutput.setContext("div", "id");
			jteOutput.writeUserContent(comment.getId());
			jteOutput.setContext("div", null);
			jteOutput.writeContent("\" class=\"hidden mt-3 bg-gray-50 rounded p-3\">\n                        <form action=\"/post/");
			jteOutput.setContext("form", "action");
			jteOutput.writeUserContent(postId);
			jteOutput.setContext("form", null);
			jteOutput.writeContent("/comment\" method=\"post\">\n                            <input type=\"hidden\" name=\"parentId\"");
			var __jte_html_attribute_0 = comment.getId();
			if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
				jteOutput.writeContent(" value=\"");
				jteOutput.setContext("input", "value");
				jteOutput.writeUserContent(__jte_html_attribute_0);
				jteOutput.setContext("input", null);
				jteOutput.writeContent("\"");
			}
			jteOutput.writeContent(">\n                            <textarea name=\"content\" rows=\"3\" placeholder=\"What are your thoughts?\"\n                                      class=\"w-full px-3 py-2 border border-gray-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-reddit-blue focus:border-reddit-blue mb-2 resize-none\"\n                                      required></textarea>\n                            <div class=\"flex justify-end space-x-2\">\n                                <button type=\"button\" onclick=\"toggleReplyForm(");
			jteOutput.setContext("button", "onclick");
			jteOutput.writeUserContent(comment.getId());
			jteOutput.setContext("button", null);
			jteOutput.writeContent(")\"\n                                        class=\"px-3 py-1 text-xs text-reddit-gray hover:text-gray-800 rounded\">\n                                    Cancel\n                                </button>\n                                <button type=\"submit\" \n                                        class=\"px-3 py-1 bg-reddit-blue text-white text-xs font-bold rounded-full hover:bg-blue-700 transition-colors\">\n                                    REPLY\n                                </button>\n                            </div>\n                        </form>\n                    </div>\n                ");
		}
		jteOutput.writeContent("\n            </div>\n        </div>\n    </div>\n\n    ");
		jteOutput.writeContent("\n    ");
		if (comment.getReplies() != null && !comment.getReplies().isEmpty()) {
			jteOutput.writeContent("\n        <div class=\"mt-2\">\n            ");
			for (Comment reply : comment.getReplies()) {
				jteOutput.writeContent("\n                ");
				gg.jte.generated.ondemand.components.JtecommentGenerated.render(jteOutput, jteHtmlInterceptor, reply, currentUser, postId, depth + 1);
				jteOutput.writeContent("\n            ");
			}
			jteOutput.writeContent("\n        </div>\n    ");
		}
		jteOutput.writeContent("\n</div>\n\n");
		if (depth == 0) {
			jteOutput.writeContent("\n    <script>\n        function toggleReplyForm(commentId) {\n            const form = document.getElementById(&quot;reply-form-&quot; + commentId);\n            form.classList.toggle(&quot;hidden&quot;);\n            if (!form.classList.contains(&quot;hidden&quot;)) {\n                form.querySelector(&quot;textarea&quot;).focus();\n            }\n        }\n    </script>\n");
		}
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		Comment comment = (Comment)params.get("comment");
		User currentUser = (User)params.getOrDefault("currentUser", null);
		Long postId = (Long)params.get("postId");
		int depth = (int)params.getOrDefault("depth", 0);
		render(jteOutput, jteHtmlInterceptor, comment, currentUser, postId, depth);
	}
}
