package gg.jte.generated.ondemand.post;
import com.example.redditclone.entity.Post;
import com.example.redditclone.entity.Comment;
import com.example.redditclone.entity.User;
import java.time.format.DateTimeFormatter;
import java.util.List;
@SuppressWarnings("unchecked")
public final class JtedetailGenerated {
	public static final String JTE_NAME = "post/detail.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,3,4,6,6,6,6,10,10,13,13,14,17,19,19,20,20,20,20,26,26,27,27,27,28,28,29,29,29,29,35,35,38,40,45,45,45,47,47,47,50,51,51,51,53,54,54,56,56,56,56,56,56,56,56,56,57,57,57,64,64,66,66,68,68,68,70,70,72,78,78,78,99,100,100,102,102,102,102,114,114,116,118,118,126,126,129,129,129,133,133,134,134,135,135,137,137,139,139,139,139,139,6,7,8,8,8,8};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, Post post, List<Comment> comments, User currentUser) {
		jteOutput.writeContent("\n");
		gg.jte.generated.ondemand.layout.JtebaseGenerated.render(jteOutput, jteHtmlInterceptor, new gg.jte.html.HtmlContent() {
			public void writeTo(gg.jte.html.HtmlTemplateOutput jteOutput) {
				jteOutput.writeContent("\n        ");
				jteOutput.writeContent("\n        <article class=\"bg-white border border-reddit-light-gray rounded mb-4\">\n            <div class=\"flex\">\n                ");
				jteOutput.writeContent("\n                <div class=\"w-10 bg-gray-50 flex flex-col items-center py-3 px-1 rounded-l\">\n                    ");
				if (currentUser != null) {
					jteOutput.writeContent("\n                        <button onclick=\"vote(&quot;up&quot;, &quot;post&quot;, ");
					jteOutput.setContext("button", "onclick");
					jteOutput.writeUserContent(post.getId());
					jteOutput.setContext("button", null);
					jteOutput.writeContent(")\" \n                                class=\"p-1 hover:bg-reddit-light-gray rounded text-reddit-gray hover:text-reddit-orange transition-colors\">\n                            <svg class=\"w-6 h-6\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                <path d=\"M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z\"/>\n                            </svg>\n                        </button>\n                    ");
				}
				jteOutput.writeContent("\n                    <span class=\"text-sm font-bold text-gray-900 py-1\">");
				jteOutput.setContext("span", null);
				jteOutput.writeUserContent(post.getVoteCount());
				jteOutput.writeContent("</span>\n                    ");
				if (currentUser != null) {
					jteOutput.writeContent("\n                        <button onclick=\"vote(&quot;down&quot;, &quot;post&quot;, ");
					jteOutput.setContext("button", "onclick");
					jteOutput.writeUserContent(post.getId());
					jteOutput.setContext("button", null);
					jteOutput.writeContent(")\" \n                                class=\"p-1 hover:bg-reddit-light-gray rounded text-reddit-gray hover:text-blue-600 transition-colors\">\n                            <svg class=\"w-6 h-6\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                <path d=\"M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z\"/>\n                            </svg>\n                        </button>\n                    ");
				}
				jteOutput.writeContent("\n                </div>\n\n                ");
				jteOutput.writeContent("\n                <div class=\"flex-1 p-4\">\n                    ");
				jteOutput.writeContent("\n                    <div class=\"flex items-center text-xs text-reddit-gray mb-2\">\n                        <span class=\"text-gray-900 font-bold\">r/all</span>\n                        <span class=\"mx-1\">•</span>\n                        <span>Posted by</span>\n                        <a href=\"#\" class=\"mx-1 hover:underline font-medium text-reddit-blue\">u/");
				jteOutput.setContext("a", null);
				jteOutput.writeUserContent(post.getAuthor().getUsername());
				jteOutput.writeContent("</a>\n                        <span class=\"mx-1\">•</span>\n                        <span>");
				jteOutput.setContext("span", null);
				jteOutput.writeUserContent(post.getCreatedAt().format(DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm")));
				jteOutput.writeContent("</span>\n                    </div>\n\n                    ");
				jteOutput.writeContent("\n                    <h1 class=\"text-xl font-medium text-gray-900 mb-4 leading-tight\">");
				jteOutput.setContext("h1", null);
				jteOutput.writeUserContent(post.getTitle());
				jteOutput.writeContent("</h1>\n\n                    ");
				jteOutput.writeContent("\n                    ");
				if (post.getUrl() != null && !post.getUrl().isEmpty()) {
					jteOutput.writeContent("\n                        <div class=\"mb-4 p-4 bg-gray-50 border border-reddit-light-gray rounded\">\n                            <a");
					var __jte_html_attribute_0 = post.getUrl();
					if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
						jteOutput.writeContent(" href=\"");
						jteOutput.setContext("a", "href");
						jteOutput.writeUserContent(__jte_html_attribute_0);
						jteOutput.setContext("a", null);
						jteOutput.writeContent("\"");
					}
					jteOutput.writeContent(" target=\"_blank\" class=\"text-reddit-blue hover:underline break-all font-medium\">\n                                ");
					jteOutput.setContext("a", null);
					jteOutput.writeUserContent(post.getUrl());
					jteOutput.writeContent("\n                                <svg class=\"inline w-4 h-4 ml-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                    <path fill-rule=\"evenodd\" d=\"M4.25 5.5a.75.75 0 00-.75.75v8.5c0 .414.336.75.75.75h8.5a.75.75 0 00.75-.75v-4a.75.75 0 011.5 0v4A2.25 2.25 0 0112.75 17h-8.5A2.25 2.25 0 012 14.75v-8.5A2.25 2.25 0 014.25 4h5a.75.75 0 010 1.5h-5z\"/>\n                                    <path fill-rule=\"evenodd\" d=\"M6.194 12.753a.75.75 0 001.06.053L16.5 4.44v2.81a.75.75 0 001.5 0V3a.75.75 0 00-.75-.75H13a.75.75 0 000 1.5h2.69l-9.243 8.306a.75.75 0 00-.053 1.06z\"/>\n                                </svg>\n                            </a>\n                        </div>\n                    ");
				}
				jteOutput.writeContent("\n\n                    ");
				if (post.getContent() != null && !post.getContent().isEmpty()) {
					jteOutput.writeContent("\n                        <div class=\"mb-4\">\n                            <p class=\"text-gray-800 leading-relaxed whitespace-pre-wrap\">");
					jteOutput.setContext("p", null);
					jteOutput.writeUserContent(post.getContent());
					jteOutput.writeContent("</p>\n                        </div>\n                    ");
				}
				jteOutput.writeContent("\n\n                    ");
				jteOutput.writeContent("\n                    <div class=\"flex items-center space-x-4 text-xs font-bold text-reddit-gray pt-2 border-t border-reddit-light-gray\">\n                        <button class=\"flex items-center hover:bg-gray-100 px-2 py-1 rounded\">\n                            <svg class=\"w-4 h-4 mr-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                <path fill-rule=\"evenodd\" d=\"M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z\" clip-rule=\"evenodd\"/>\n                            </svg>\n                            ");
				jteOutput.setContext("button", null);
				jteOutput.writeUserContent(comments.size());
				jteOutput.writeContent(" Comments\n                        </button>\n                        \n                        <button class=\"flex items-center hover:bg-gray-100 px-2 py-1 rounded\">\n                            <svg class=\"w-4 h-4 mr-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                <path d=\"M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z\"/>\n                            </svg>\n                            Share\n                        </button>\n                        \n                        <button class=\"flex items-center hover:bg-gray-100 px-2 py-1 rounded\">\n                            <svg class=\"w-4 h-4 mr-1\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">\n                                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z\"/>\n                            </svg>\n                            Save\n                        </button>\n                    </div>\n                </div>\n            </div>\n        </article>\n\n        ");
				jteOutput.writeContent("\n        ");
				if (currentUser != null) {
					jteOutput.writeContent("\n            <div class=\"bg-white border border-reddit-light-gray rounded p-4 mb-4\">\n                <form action=\"/post/");
					jteOutput.setContext("form", "action");
					jteOutput.writeUserContent(post.getId());
					jteOutput.setContext("form", null);
					jteOutput.writeContent("/comment\" method=\"post\">\n                    <textarea name=\"content\" rows=\"4\" placeholder=\"What are your thoughts?\"\n                              class=\"w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-reddit-blue focus:border-reddit-blue mb-3 resize-none\"\n                              required></textarea>\n                    <div class=\"flex justify-end\">\n                        <button type=\"submit\" \n                                class=\"px-4 py-1 bg-reddit-blue text-white text-sm font-bold rounded-full hover:bg-blue-700 transition-colors\">\n                            COMMENT\n                        </button>\n                    </div>\n                </form>\n            </div>\n        ");
				}
				jteOutput.writeContent("\n\n        ");
				jteOutput.writeContent("\n        <div class=\"bg-white border border-reddit-light-gray rounded\">\n            ");
				if (comments.isEmpty()) {
					jteOutput.writeContent("\n                <div class=\"p-8 text-center text-reddit-gray\">\n                    <svg class=\"mx-auto h-12 w-12 text-gray-300 mb-4\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">\n                        <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z\"/>\n                    </svg>\n                    <h3 class=\"text-lg font-medium text-gray-900 mb-2\">No Comments Yet</h3>\n                    <p>Be the first to share what you think!</p>\n                </div>\n            ");
				} else {
					jteOutput.writeContent("\n                <div class=\"border-b border-reddit-light-gray p-4\">\n                    <h3 class=\"font-bold text-sm text-gray-900\">\n                        Comments (");
					jteOutput.setContext("h3", null);
					jteOutput.writeUserContent(comments.size());
					jteOutput.writeContent(")\n                    </h3>\n                </div>\n                <div class=\"divide-y divide-reddit-light-gray\">\n                    ");
					for (Comment comment : comments) {
						jteOutput.writeContent("\n                        ");
						gg.jte.generated.ondemand.components.JtecommentGenerated.render(jteOutput, jteHtmlInterceptor, comment, currentUser, post.getId(), 0);
						jteOutput.writeContent("\n                    ");
					}
					jteOutput.writeContent("\n                </div>\n            ");
				}
				jteOutput.writeContent("\n        </div>\n    ");
			}
		}, post.getTitle() + " - Reddit Clone");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		Post post = (Post)params.get("post");
		List<Comment> comments = (List<Comment>)params.get("comments");
		User currentUser = (User)params.getOrDefault("currentUser", null);
		render(jteOutput, jteHtmlInterceptor, post, comments, currentUser);
	}
}
