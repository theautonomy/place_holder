package gg.jte.generated.ondemand;
import com.example.redditclone.entity.Post;
import org.springframework.data.domain.Page;
import java.time.format.DateTimeFormatter;
@SuppressWarnings("unchecked")
public final class JtehomeGenerated {
	public static final String JTE_NAME = "home.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,4,4,4,4,8,8,8,8,9,12,12,19,19,26,26,27,27,34,34,41,41,45,45,52,53,53,60,60,62,62,64,64,67,69,69,69,69,75,75,75,76,76,76,76,84,86,91,91,91,92,92,92,95,97,97,97,97,98,98,98,102,103,103,105,105,105,105,105,105,105,105,105,106,106,106,113,113,115,115,116,116,116,116,116,116,117,117,119,121,121,121,121,125,125,125,145,145,148,149,149,151,151,152,152,152,152,152,152,152,152,156,156,159,159,160,160,161,161,161,162,162,163,163,163,163,163,163,163,163,164,164,164,165,165,166,166,168,168,170,170,173,173,174,174,174,174,174,174,174,174,178,178,180,180,181,181,182,182,182,182,182,4,5,6,6,6,6};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, Page<Post> posts, String currentSort, int currentPage) {
		jteOutput.writeContent("\n");
		gg.jte.generated.ondemand.layout.JtebaseGenerated.render(jteOutput, jteHtmlInterceptor, new gg.jte.html.HtmlContent() {
			public void writeTo(gg.jte.html.HtmlTemplateOutput jteOutput) {
				jteOutput.writeContent("\n    ");
				jteOutput.writeContent("\n    <div class=\"bg-white rounded border border-reddit-light-gray mb-4\">\n        <div class=\"flex border-b border-reddit-light-gray\">\n            ");
				if ("hot".equals(currentSort)) {
					jteOutput.writeContent("\n                <a href=\"/?sort=hot\" class=\"flex items-center px-4 py-3 text-sm font-medium text-reddit-blue border-b-2 border-reddit-blue bg-blue-50\">\n                    <svg class=\"w-4 h-4 mr-2\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                        <path fill-rule=\"evenodd\" d=\"M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z\" clip-rule=\"evenodd\"/>\n                    </svg>\n                    Hot\n                </a>\n            ");
				} else {
					jteOutput.writeContent("\n                <a href=\"/?sort=hot\" class=\"flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:text-reddit-blue hover:bg-gray-50\">\n                    <svg class=\"w-4 h-4 mr-2\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                        <path fill-rule=\"evenodd\" d=\"M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z\" clip-rule=\"evenodd\"/>\n                    </svg>\n                    Hot\n                </a>\n            ");
				}
				jteOutput.writeContent("\n            ");
				if ("new".equals(currentSort)) {
					jteOutput.writeContent("\n                <a href=\"/?sort=new\" class=\"flex items-center px-4 py-3 text-sm font-medium text-reddit-blue border-b-2 border-reddit-blue bg-blue-50\">\n                    <svg class=\"w-4 h-4 mr-2\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                        <path fill-rule=\"evenodd\" d=\"M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 10-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L4.414 9H17a1 1 0 100-2H4.414l1.879-1.293z\" clip-rule=\"evenodd\"/>\n                    </svg>\n                    New\n                </a>\n            ");
				} else {
					jteOutput.writeContent("\n                <a href=\"/?sort=new\" class=\"flex items-center px-4 py-3 text-sm font-medium text-gray-700 hover:text-reddit-blue hover:bg-gray-50\">\n                    <svg class=\"w-4 h-4 mr-2\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                        <path fill-rule=\"evenodd\" d=\"M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 10-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L4.414 9H17a1 1 0 100-2H4.414l1.879-1.293z\" clip-rule=\"evenodd\"/>\n                    </svg>\n                    New\n                </a>\n            ");
				}
				jteOutput.writeContent("\n        </div>\n    </div>\n\n    ");
				if (posts.isEmpty()) {
					jteOutput.writeContent("\n        <div class=\"bg-white rounded border border-reddit-light-gray p-12 text-center\">\n            <svg class=\"mx-auto h-12 w-12 text-gray-400 mb-4\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">\n                <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9.5a2 2 0 00-2-2h-2m0 0V7a2 2 0 00-2-2\"/>\n            </svg>\n            <h3 class=\"text-lg font-medium text-gray-900 mb-2\">No posts yet</h3>\n            <p class=\"text-gray-500 mb-6\">Be the first to share something interesting with the community!</p>\n            ");
					if (org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication().isAuthenticated() && 
                !"anonymousUser".equals(org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication().getName())) {
						jteOutput.writeContent("\n                <a href=\"/post/submit\" class=\"inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-full text-white bg-reddit-blue hover:bg-blue-700\">\n                    <svg class=\"w-4 h-4 mr-2\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                        <path fill-rule=\"evenodd\" d=\"M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z\" clip-rule=\"evenodd\"/>\n                    </svg>\n                    Create Post\n                </a>\n            ");
					}
					jteOutput.writeContent("\n        </div>\n    ");
				} else {
					jteOutput.writeContent("\n        <div class=\"space-y-0\">\n            ");
					for (Post post : posts.getContent()) {
						jteOutput.writeContent("\n                <article class=\"bg-white border border-reddit-light-gray hover:border-gray-400 transition-colors\">\n                    <div class=\"flex\">\n                        ");
						jteOutput.writeContent("\n                        <div class=\"w-10 bg-gray-50 flex flex-col items-center py-2 px-1\">\n                            <button onclick=\"vote(&quot;up&quot;, &quot;post&quot;, ");
						jteOutput.setContext("button", "onclick");
						jteOutput.writeUserContent(post.getId());
						jteOutput.setContext("button", null);
						jteOutput.writeContent(")\" \n                                    class=\"p-1 hover:bg-reddit-light-gray rounded text-reddit-gray hover:text-reddit-orange transition-colors\">\n                                <svg class=\"w-5 h-5\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                    <path d=\"M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z\"/>\n                                </svg>\n                            </button>\n                            <span class=\"text-xs font-bold text-gray-900 py-0.5\">");
						jteOutput.setContext("span", null);
						jteOutput.writeUserContent(post.getVoteCount());
						jteOutput.writeContent("</span>\n                            <button onclick=\"vote(&quot;down&quot;, &quot;post&quot;, ");
						jteOutput.setContext("button", "onclick");
						jteOutput.writeUserContent(post.getId());
						jteOutput.setContext("button", null);
						jteOutput.writeContent(")\" \n                                    class=\"p-1 hover:bg-reddit-light-gray rounded text-reddit-gray hover:text-blue-600 transition-colors\">\n                                <svg class=\"w-5 h-5\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                    <path d=\"M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z\"/>\n                                </svg>\n                            </button>\n                        </div>\n\n                        ");
						jteOutput.writeContent("\n                        <div class=\"flex-1 p-2 pr-4\">\n                            ");
						jteOutput.writeContent("\n                            <div class=\"flex items-center text-xs text-reddit-gray mb-1\">\n                                <span class=\"text-gray-900 font-bold\">r/all</span>\n                                <span class=\"mx-1\">•</span>\n                                <span>Posted by</span>\n                                <a href=\"#\" class=\"mx-1 hover:underline font-medium\">u/");
						jteOutput.setContext("a", null);
						jteOutput.writeUserContent(post.getAuthor().getUsername());
						jteOutput.writeContent("</a>\n                                <span>");
						jteOutput.setContext("span", null);
						jteOutput.writeUserContent(post.getCreatedAt().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")));
						jteOutput.writeContent("</span>\n                            </div>\n\n                            ");
						jteOutput.writeContent("\n                            <h2 class=\"text-lg font-medium text-gray-900 mb-2 leading-tight\">\n                                <a href=\"/post/");
						jteOutput.setContext("a", "href");
						jteOutput.writeUserContent(post.getId());
						jteOutput.setContext("a", null);
						jteOutput.writeContent("\" class=\"hover:text-reddit-blue\">\n                                    ");
						jteOutput.setContext("a", null);
						jteOutput.writeUserContent(post.getTitle());
						jteOutput.writeContent("\n                                </a>\n                            </h2>\n\n                            ");
						jteOutput.writeContent("\n                            ");
						if (post.getUrl() != null && !post.getUrl().isEmpty()) {
							jteOutput.writeContent("\n                                <div class=\"mb-3\">\n                                    <a");
							var __jte_html_attribute_0 = post.getUrl();
							if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
								jteOutput.writeContent(" href=\"");
								jteOutput.setContext("a", "href");
								jteOutput.writeUserContent(__jte_html_attribute_0);
								jteOutput.setContext("a", null);
								jteOutput.writeContent("\"");
							}
							jteOutput.writeContent(" target=\"_blank\" class=\"text-sm text-reddit-blue hover:underline break-all\">\n                                        ");
							jteOutput.setContext("a", null);
							jteOutput.writeUserContent(post.getUrl());
							jteOutput.writeContent("\n                                        <svg class=\"inline w-3 h-3 ml-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                            <path fill-rule=\"evenodd\" d=\"M4.25 5.5a.75.75 0 00-.75.75v8.5c0 .414.336.75.75.75h8.5a.75.75 0 00.75-.75v-4a.75.75 0 011.5 0v4A2.25 2.25 0 0112.75 17h-8.5A2.25 2.25 0 012 14.75v-8.5A2.25 2.25 0 014.25 4h5a.75.75 0 010 1.5h-5z\"/>\n                                            <path fill-rule=\"evenodd\" d=\"M6.194 12.753a.75.75 0 001.06.053L16.5 4.44v2.81a.75.75 0 001.5 0V3a.75.75 0 00-.75-.75H13a.75.75 0 000 1.5h2.69l-9.243 8.306a.75.75 0 00-.053 1.06z\"/>\n                                        </svg>\n                                    </a>\n                                </div>\n                            ");
						}
						jteOutput.writeContent("\n\n                            ");
						if (post.getContent() != null && !post.getContent().isEmpty()) {
							jteOutput.writeContent("\n                                <p class=\"text-sm text-gray-800 mb-3 leading-relaxed max-w-none\">");
							jteOutput.setContext("p", null);
							jteOutput.writeUserContent(post.getContent().substring(0, Math.min(post.getContent().length(), 300)));
							if (post.getContent().length() > 300) {
								jteOutput.writeContent("...");
							}
							jteOutput.writeContent("</p>\n                            ");
						}
						jteOutput.writeContent("\n\n                            ");
						jteOutput.writeContent("\n                            <div class=\"flex items-center space-x-4 text-xs font-bold text-reddit-gray\">\n                                <a href=\"/post/");
						jteOutput.setContext("a", "href");
						jteOutput.writeUserContent(post.getId());
						jteOutput.setContext("a", null);
						jteOutput.writeContent("\" class=\"flex items-center hover:bg-gray-100 px-2 py-1 rounded\">\n                                    <svg class=\"w-4 h-4 mr-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                        <path fill-rule=\"evenodd\" d=\"M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z\" clip-rule=\"evenodd\"/>\n                                    </svg>\n                                    ");
						jteOutput.setContext("a", null);
						jteOutput.writeUserContent(post.getComments() != null ? post.getComments().size() : 0);
						jteOutput.writeContent(" Comments\n                                </a>\n                                \n                                <button class=\"flex items-center hover:bg-gray-100 px-2 py-1 rounded\">\n                                    <svg class=\"w-4 h-4 mr-1\" fill=\"currentColor\" viewBox=\"0 0 20 20\">\n                                        <path d=\"M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z\"/>\n                                    </svg>\n                                    Share\n                                </button>\n                                \n                                <button class=\"flex items-center hover:bg-gray-100 px-2 py-1 rounded\">\n                                    <svg class=\"w-4 h-4 mr-1\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\">\n                                        <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z\"/>\n                                    </svg>\n                                    Save\n                                </button>\n                            </div>\n                        </div>\n                    </div>\n                </article>\n            ");
					}
					jteOutput.writeContent("\n        </div>\n\n        ");
					jteOutput.writeContent("\n        ");
					if (posts.getTotalPages() > 1) {
						jteOutput.writeContent("\n            <div class=\"flex justify-center items-center space-x-2 mt-6 bg-white rounded border border-reddit-light-gray p-4\">\n                ");
						if (posts.hasPrevious()) {
							jteOutput.writeContent("\n                    <a href=\"/?page=");
							jteOutput.setContext("a", "href");
							jteOutput.writeUserContent(currentPage - 1);
							jteOutput.setContext("a", null);
							jteOutput.writeContent("&sort=");
							jteOutput.setContext("a", "href");
							jteOutput.writeUserContent(currentSort);
							jteOutput.setContext("a", null);
							jteOutput.writeContent("\" \n                       class=\"px-3 py-1 text-sm font-medium text-reddit-blue hover:bg-blue-50 rounded\">\n                        ← Previous\n                    </a>\n                ");
						}
						jteOutput.writeContent("\n                \n                <div class=\"flex space-x-1\">\n                    ");
						for (int i = 0; i < Math.min(posts.getTotalPages(), 10); i++) {
							jteOutput.writeContent("\n                        ");
							if (i == currentPage) {
								jteOutput.writeContent("\n                            <span class=\"px-3 py-1 text-sm font-medium rounded bg-reddit-blue text-white\">");
								jteOutput.setContext("span", null);
								jteOutput.writeUserContent(i + 1);
								jteOutput.writeContent("</span>\n                        ");
							} else {
								jteOutput.writeContent("\n                            <a href=\"/?page=");
								jteOutput.setContext("a", "href");
								jteOutput.writeUserContent(i);
								jteOutput.setContext("a", null);
								jteOutput.writeContent("&sort=");
								jteOutput.setContext("a", "href");
								jteOutput.writeUserContent(currentSort);
								jteOutput.setContext("a", null);
								jteOutput.writeContent("\" \n                               class=\"px-3 py-1 text-sm font-medium rounded text-reddit-blue hover:bg-blue-50\">");
								jteOutput.setContext("a", null);
								jteOutput.writeUserContent(i + 1);
								jteOutput.writeContent("</a>\n                        ");
							}
							jteOutput.writeContent("\n                    ");
						}
						jteOutput.writeContent("\n                    \n                    ");
						if (posts.getTotalPages() > 10) {
							jteOutput.writeContent("\n                        <span class=\"px-2 text-reddit-gray\">...</span>\n                    ");
						}
						jteOutput.writeContent("\n                </div>\n                \n                ");
						if (posts.hasNext()) {
							jteOutput.writeContent("\n                    <a href=\"/?page=");
							jteOutput.setContext("a", "href");
							jteOutput.writeUserContent(currentPage + 1);
							jteOutput.setContext("a", null);
							jteOutput.writeContent("&sort=");
							jteOutput.setContext("a", "href");
							jteOutput.writeUserContent(currentSort);
							jteOutput.setContext("a", null);
							jteOutput.writeContent("\" \n                       class=\"px-3 py-1 text-sm font-medium text-reddit-blue hover:bg-blue-50 rounded\">\n                        Next →\n                    </a>\n                ");
						}
						jteOutput.writeContent("\n            </div>\n        ");
					}
					jteOutput.writeContent("\n    ");
				}
				jteOutput.writeContent("\n");
			}
		}, "Reddit Clone");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		Page<Post> posts = (Page<Post>)params.get("posts");
		String currentSort = (String)params.get("currentSort");
		int currentPage = (int)params.get("currentPage");
		render(jteOutput, jteHtmlInterceptor, posts, currentSort, currentPage);
	}
}
