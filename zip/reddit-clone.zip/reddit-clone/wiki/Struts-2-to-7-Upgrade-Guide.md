# Struts 2.5.33 to Struts 7 Upgrade Guide

## Overview

This guide covers the migration from Apache Struts 2.5.33 to Struts 7.0.x, including breaking changes, new features, and migration strategies.

## Key Changes in Struts 7

### Major Breaking Changes

#### 1. Jakarta EE Migration
- **Namespace Change**: `javax.*` → `jakarta.*`
- **Servlet API**: Jakarta Servlet 5.0+ required
- **JSP API**: Jakarta Pages 3.0+ required
- **JSTL**: Jakarta Standard Tag Library 2.0+ required

#### 2. Minimum Requirements
- **Java**: Java 11+ (recommended Java 17+)
- **Servlet Container**: Jakarta EE 9+ compatible
- **Maven**: 3.6.0+

#### 3. Removed Features
- **Tiles Plugin**: No longer supported (migrate to alternatives)
- **Dojo Plugin**: Removed (migrate to modern JavaScript frameworks)
- **Deprecated Interceptors**: Several legacy interceptors removed
- **Old Configuration Methods**: Some XML configuration patterns deprecated

### New Features & Improvements

#### 1. Performance Enhancements
- Improved action caching mechanisms
- Optimized reflection usage
- Enhanced memory management

#### 2. Security Improvements
- Updated OGNL expression evaluation
- Enhanced input validation
- Improved CSRF protection

#### 3. Modern Development Support
- Better annotation support
- Enhanced REST plugin capabilities
- Improved JSON handling

## Migration Strategy

### Phase 1: Pre-Migration Assessment

#### Inventory Current Usage
```bash
# Find all Struts-related imports
grep -r "import org.apache.struts2" src/
grep -r "import com.opensymphony" src/

# Find all struts.xml files
find . -name "struts*.xml"

# Check for deprecated features
grep -r "@Results\|@Result\|@Action" src/
```

#### Dependency Analysis
```xml
<!-- Current dependencies (example) -->
<dependency>
    <groupId>org.apache.struts</groupId>
    <artifactId>struts2-core</artifactId>
    <version>2.5.33</version>
</dependency>
```

### Phase 2: Environment Preparation

#### Maven Dependencies Update
```xml
<properties>
    <struts2.version>7.0.0-M7</struts2.version>
    <jakarta.servlet.version>5.0.0</jakarta.servlet.version>
    <jakarta.jsp.version>3.0.0</jakarta.jsp.version>
</properties>

<dependencies>
    <!-- Core Struts 7 Dependencies -->
    <dependency>
        <groupId>org.apache.struts</groupId>
        <artifactId>struts2-core</artifactId>
        <version>${struts2.version}</version>
    </dependency>
    
    <!-- Jakarta EE Dependencies -->
    <dependency>
        <groupId>jakarta.servlet</groupId>
        <artifactId>jakarta.servlet-api</artifactId>
        <version>${jakarta.servlet.version}</version>
        <scope>provided</scope>
    </dependency>
    
    <dependency>
        <groupId>jakarta.servlet.jsp</groupId>
        <artifactId>jakarta.servlet.jsp-api</artifactId>
        <version>${jakarta.jsp.version}</version>
        <scope>provided</scope>
    </dependency>
    
    <!-- Additional Struts 7 Plugins -->
    <dependency>
        <groupId>org.apache.struts</groupId>
        <artifactId>struts2-convention-plugin</artifactId>
        <version>${struts2.version}</version>
    </dependency>
    
    <dependency>
        <groupId>org.apache.struts</groupId>
        <artifactId>struts2-json-plugin</artifactId>
        <version>${struts2.version}</version>
    </dependency>
</dependencies>
```

### Phase 3: Code Migration

#### 1. Namespace Migration

**Before (javax):**
```java
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

public class UserAction extends ActionSupport {
    private HttpServletRequest request;
    private HttpServletResponse response;
}
```

**After (jakarta):**
```java
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletContext;

public class UserAction extends ActionSupport {
    private HttpServletRequest request;
    private HttpServletResponse response;
}
```

#### 2. Action Class Updates

**Enhanced Action Support:**
```java
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.convention.annotation.Results;

@Results({
    @Result(name = "success", location = "/user/profile.jsp"),
    @Result(name = "error", location = "/user/error.jsp")
})
public class UserProfileAction extends ActionSupport {
    
    @Action("profile")
    public String execute() {
        return SUCCESS;
    }
}
```

#### 3. Interceptor Updates

**Custom Interceptor Migration:**
```java
// Update package imports
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class CustomSecurityInterceptor extends AbstractInterceptor {
    
    @Override
    public String intercept(ActionInvocation invocation) throws Exception {
        // Updated implementation with new API patterns
        return invocation.invoke();
    }
}
```

### Phase 4: Configuration Updates

#### 1. struts.xml Updates

**Modern Configuration:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE struts PUBLIC
    "-//Apache Software Foundation//DTD Struts Configuration 7.0//EN"
    "https://struts.apache.org/dtds/struts-7.0.dtd">

<struts>
    <!-- Enhanced constant configuration -->
    <constant name="struts.devMode" value="false" />
    <constant name="struts.enable.DynamicMethodInvocation" value="false" />
    <constant name="struts.mapper.alwaysSelectFullNamespace" value="false" />
    
    <!-- Updated security settings -->
    <constant name="struts.ognl.allowStaticMethodAccess" value="false" />
    <constant name="struts.ognl.expressionMaxLength" value="256" />
    
    <package name="default" namespace="/" extends="struts-default">
        <interceptors>
            <interceptor-stack name="secureStack">
                <interceptor-ref name="exception"/>
                <interceptor-ref name="alias"/>
                <interceptor-ref name="servletConfig"/>
                <interceptor-ref name="i18n"/>
                <interceptor-ref name="prepare"/>
                <interceptor-ref name="chain"/>
                <interceptor-ref name="modelDriven"/>
                <interceptor-ref name="fileUpload">
                    <param name="maximumSize">10485760</param>
                </interceptor-ref>
                <interceptor-ref name="params">
                    <param name="excludeParams">dojo\..*,^struts\..*</param>
                </interceptor-ref>
                <interceptor-ref name="conversionError"/>
                <interceptor-ref name="validation"/>
                <interceptor-ref name="workflow"/>
            </interceptor-stack>
        </interceptors>
        
        <default-interceptor-ref name="secureStack"/>
    </package>
</struts>
```

#### 2. web.xml Updates

**Jakarta EE Namespace:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee
         https://jakarta.ee/xml/ns/jakartaee/web-app_5_0.xsd"
         version="5.0">

    <display-name>Legacy Application - Struts 7</display-name>
    
    <filter>
        <filter-name>struts2</filter-name>
        <filter-class>org.apache.struts2.dispatcher.filter.StrutsPrepareAndExecuteFilter</filter-class>
    </filter>
    
    <filter-mapping>
        <filter-name>struts2</filter-name>
        <url-pattern>/*</url-pattern>
    </filter-mapping>
    
</web-app>
```

### Phase 5: Testing & Validation

#### Unit Testing Updates

**Test Dependencies:**
```xml
<dependency>
    <groupId>org.apache.struts</groupId>
    <artifactId>struts2-junit-plugin</artifactId>
    <version>${struts2.version}</version>
    <scope>test</scope>
</dependency>
```

**Updated Test Class:**
```java
import org.apache.struts2.StrutsJUnit4TestCase;
import org.junit.Test;

public class UserActionTest extends StrutsJUnit4TestCase {
    
    @Test
    public void testProfileAction() throws Exception {
        UserProfileAction action = new UserProfileAction();
        String result = action.execute();
        assertEquals("success", result);
    }
}
```

## Migration Checklist

### Pre-Migration
- [ ] Complete dependency inventory
- [ ] Identify deprecated features
- [ ] Create migration test plan
- [ ] Set up parallel development environment

### Code Changes
- [ ] Update all javax.* imports to jakarta.*
- [ ] Migrate action classes
- [ ] Update interceptors
- [ ] Modify JSP pages (if using JSTL)
- [ ] Update custom plugins

### Configuration Changes
- [ ] Update struts.xml configuration
- [ ] Migrate web.xml to Jakarta EE
- [ ] Update Maven/Gradle dependencies
- [ ] Configure new security settings

### Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Performance tests show no regression
- [ ] Security scanning complete

### Deployment
- [ ] Deploy to test environment
- [ ] Validate all functionality
- [ ] Performance testing
- [ ] User acceptance testing

## Common Issues & Solutions

### Issue 1: Package Import Errors
```java
// Error: package javax.servlet does not exist
// Solution: Replace with jakarta.servlet
import jakarta.servlet.http.HttpServletRequest;
```

### Issue 2: Plugin Compatibility
```xml
<!-- Some plugins may not be compatible with Struts 7 -->
<!-- Check plugin documentation for Struts 7 versions -->
<dependency>
    <groupId>org.apache.struts</groupId>
    <artifactId>struts2-spring-plugin</artifactId>
    <version>${struts2.version}</version>
</dependency>
```

### Issue 3: OGNL Expression Issues
```java
// Enhanced security may block some OGNL expressions
// Update struts.xml with appropriate OGNL configurations
<constant name="struts.ognl.allowStaticMethodAccess" value="false" />
```

## Performance Considerations

### Memory Usage
- Monitor heap usage during migration
- Profile application startup time
- Check for memory leaks in action lifecycle

### Response Times
- Benchmark critical user paths
- Monitor database connection pooling
- Validate caching mechanisms

## Security Enhancements

### Updated Security Practices
1. **Input Validation**: Enhanced validation interceptors
2. **CSRF Protection**: Improved token handling
3. **OGNL Security**: Restricted expression evaluation
4. **File Upload**: Enhanced security controls

## Next Steps

1. Complete environment setup with Struts 7
2. Execute phase-by-phase migration
3. Conduct comprehensive testing
4. Deploy to staging environment
5. Perform production deployment

---

**References:**
- [Struts 7 Migration Guide](https://struts.apache.org/getting-started/migration-guide.html)
- [Jakarta EE Migration](https://jakarta.ee/resources/JakartaEE-8-to-9-Migration-Guide.pdf)
- [Struts 7 Security Guide](https://struts.apache.org/security/)

**Last Updated**: 2025-08-26
**Version**: 1.0