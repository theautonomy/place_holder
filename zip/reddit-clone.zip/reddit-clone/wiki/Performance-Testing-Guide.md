# Performance Testing Guide

## Overview

This comprehensive performance testing guide covers the strategy, implementation, and validation of performance requirements for our legacy Java EE application upgrade from Struts 2.5.33/Spring 5.3/Tomcat 9 to Struts 7/Spring 6/Tomcat 10. The guide ensures the upgraded system meets or exceeds current performance benchmarks.

## Performance Testing Strategy

### Testing Objectives

#### Primary Goals
- **Validate Performance**: Ensure upgraded system meets current SLAs
- **Identify Bottlenecks**: Discover performance issues before production
- **Establish Baselines**: Create performance benchmarks for future releases
- **Optimize Resources**: Ensure efficient resource utilization

#### Success Criteria
- **Response Time**: ≤ current baseline + 10%
- **Throughput**: ≥ current capacity requirements  
- **Resource Usage**: Memory ≤ baseline + 15%, CPU ≤ baseline + 10%
- **Scalability**: Support planned growth (25% increase in users)
- **Stability**: Zero memory leaks, stable under sustained load

### Performance Testing Types

#### 1. Load Testing
**Purpose**: Validate system behavior under expected normal load

**Scenarios**:
- Normal business hours traffic patterns
- Expected concurrent user volumes
- Typical transaction mix

**Tools**: JMeter, Gatling, K6

#### 2. Stress Testing  
**Purpose**: Determine system breaking point and behavior beyond normal capacity

**Scenarios**:
- Peak traffic conditions (2x normal load)
- Resource exhaustion scenarios
- Cascading failure testing

**Tools**: JMeter, Artillery, NBomber

#### 3. Volume Testing
**Purpose**: Validate system performance with large amounts of data

**Scenarios**:
- Large dataset processing
- Bulk data operations
- Database performance under load

**Tools**: Custom scripts, JMeter, database profilers

#### 4. Spike Testing
**Purpose**: Test system response to sudden load increases

**Scenarios**:
- Flash sales, promotional events
- Sudden traffic spikes
- Recovery after load spikes

**Tools**: JMeter, Gatling, K6

#### 5. Endurance Testing
**Purpose**: Validate system stability over extended periods

**Scenarios**:
- 24-hour sustained load
- Memory leak detection
- Resource degradation over time

**Tools**: JMeter, Custom monitoring scripts

## Performance Testing Environment

### Environment Setup

#### Infrastructure Configuration
```yaml
# Docker Compose for Performance Testing Environment
version: '3.8'

services:
  app-server:
    image: tomcat:10-jdk17
    ports:
      - "8080:8080"
    environment:
      - JAVA_OPTS=-Xms2g -Xmx4g -XX:+UseG1GC
      - CATALINA_OPTS=-server
    volumes:
      - ./target/app.war:/usr/local/tomcat/webapps/app.war
    depends_on:
      - postgres
      - redis
    
  postgres:
    image: postgres:13
    environment:
      POSTGRES_DB: perftest
      POSTGRES_USER: perfuser
      POSTGRES_PASSWORD: perfpass
    ports:
      - "5432:5432"
    command: >
      postgres
      -c shared_preload_libraries=pg_stat_statements
      -c pg_stat_statements.track=all
      -c max_connections=200
      -c shared_buffers=256MB
    
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    command: redis-server --maxmemory 256mb --maxmemory-policy allkeys-lru
    
  monitoring:
    image: prom/prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      
  grafana:
    image: grafana/grafana
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
```

#### JVM Performance Tuning
```bash
#!/bin/bash
# JVM tuning for performance testing

export JAVA_OPTS="
-server
-Xms2048m
-Xmx4096m
-XX:MetaspaceSize=256m
-XX:MaxMetaspaceSize=512m
-XX:+UseG1GC
-XX:G1HeapRegionSize=16m
-XX:+UseStringDeduplication
-XX:+OptimizeStringConcat
-XX:+UseCompressedOops
-XX:+UseCompressedClassPointers
-XX:+TieredCompilation
-XX:TieredStopAtLevel=4
-XX:+UseBiasedLocking
-XX:BiasedLockingStartupDelay=0
-Djava.awt.headless=true
-Dfile.encoding=UTF-8
-Duser.timezone=UTC
"

# GC Logging for analysis
export JAVA_OPTS="$JAVA_OPTS
-Xloggc:gc.log
-XX:+PrintGC
-XX:+PrintGCDetails
-XX:+PrintGCTimeStamps
-XX:+PrintGCApplicationStoppedTime
-XX:+UseGCLogFileRotation
-XX:NumberOfGCLogFiles=5
-XX:GCLogFileSize=10M
"

# JFR (Java Flight Recorder) for profiling
export JAVA_OPTS="$JAVA_OPTS
-XX:+FlightRecorder
-XX:+UnlockCommercialFeatures
-XX:StartFlightRecording=duration=300s,filename=perf-test.jfr
"
```

### Database Performance Configuration

#### PostgreSQL Tuning
```sql
-- PostgreSQL performance settings for testing
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;
ALTER SYSTEM SET random_page_cost = 1.1;
ALTER SYSTEM SET effective_io_concurrency = 200;
ALTER SYSTEM SET work_mem = '8MB';
ALTER SYSTEM SET min_wal_size = '1GB';
ALTER SYSTEM SET max_wal_size = '4GB';

-- Enable query performance monitoring
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- Reload configuration
SELECT pg_reload_conf();
```

#### Connection Pool Configuration
```java
@Configuration
public class PerformanceDataSourceConfig {
    
    @Bean
    @Primary
    public DataSource performanceDataSource() {
        HikariConfig config = new HikariConfig();
        
        // Database connection settings
        config.setJdbcUrl("jdbc:postgresql://localhost:5432/perftest");
        config.setUsername("perfuser");
        config.setPassword("perfpass");
        config.setDriverClassName("org.postgresql.Driver");
        
        // Connection pool settings optimized for performance testing
        config.setMaximumPoolSize(50);           // Increased for load testing
        config.setMinimumIdle(10);               // Maintain baseline connections
        config.setConnectionTimeout(30000);      // 30 seconds
        config.setIdleTimeout(600000);           // 10 minutes
        config.setMaxLifetime(1800000);          // 30 minutes
        config.setLeakDetectionThreshold(60000); // 1 minute
        
        // Performance optimizations
        config.setAutoCommit(false);             // Explicit transaction control
        config.setReadOnly(false);
        config.setCachePrepStmts(true);
        config.setPrepStmtCacheSize(250);
        config.setPrepStmtCacheSqlLimit(2048);
        
        // Validation settings
        config.setValidationTimeout(5000);
        config.setConnectionTestQuery("SELECT 1");
        
        return new HikariDataSource(config);
    }
}
```

## Performance Test Implementation

### JMeter Test Plans

#### User Registration Load Test
```xml
<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan version="1.2" properties="5.0" jmeter="5.6.2">
  <hashTree>
    <TestPlan guiclass="TestPlanGui" testclass="TestPlan" testname="User Registration Load Test">
      <stringProp name="TestPlan.comments">Load test for user registration endpoint</stringProp>
      <boolProp name="TestPlan.functional_mode">false</boolProp>
      <boolProp name="TestPlan.serialize_threadgroups">false</boolProp>
      <elementProp name="TestPlan.arguments" elementType="Arguments" guiclass="ArgumentsPanel">
        <collectionProp name="Arguments.arguments"/>
      </elementProp>
      <stringProp name="TestPlan.user_define_classpath"></stringProp>
    </TestPlan>
    
    <hashTree>
      <!-- Thread Group Configuration -->
      <ThreadGroup guiclass="ThreadGroupGui" testclass="ThreadGroup" testname="Registration Users">
        <stringProp name="ThreadGroup.on_sample_error">continue</stringProp>
        <elementProp name="ThreadGroup.main_controller" elementType="LoopController">
          <boolProp name="LoopController.continue_forever">false</boolProp>
          <stringProp name="LoopController.loops">5</stringProp>
        </elementProp>
        <stringProp name="ThreadGroup.num_threads">50</stringProp>
        <stringProp name="ThreadGroup.ramp_time">60</stringProp>
      </ThreadGroup>
      
      <hashTree>
        <!-- HTTP Request for User Registration -->
        <HTTPSamplerProxy guiclass="HttpTestSampleGui" testclass="HTTPSamplerProxy" testname="Register User">
          <elementProp name="HTTPsampler.Arguments" elementType="Arguments">
            <collectionProp name="Arguments.arguments">
              <elementProp name="" elementType="HTTPArgument">
                <boolProp name="HTTPArgument.always_encode">false</boolProp>
                <stringProp name="Argument.value">{
  "username": "loadtest_user_${__threadNum}_${__time()}",
  "email": "loadtest${__threadNum}${__time()}@example.com",
  "password": "LoadTestPassword123!"
}</stringProp>
                <stringProp name="Argument.metadata">=</stringProp>
              </elementProp>
            </collectionProp>
          </elementProp>
          <stringProp name="HTTPSampler.domain">localhost</stringProp>
          <stringProp name="HTTPSampler.port">8080</stringProp>
          <stringProp name="HTTPSampler.protocol">http</stringProp>
          <stringProp name="HTTPSampler.path">/api/users/register</stringProp>
          <stringProp name="HTTPSampler.method">POST</stringProp>
          <boolProp name="HTTPSampler.follow_redirects">true</boolProp>
          <boolProp name="HTTPSampler.auto_redirects">false</boolProp>
          <boolProp name="HTTPSampler.use_keepalive">true</boolProp>
          <boolProp name="HTTPSampler.DO_MULTIPART_POST">false</boolProp>
        </HTTPSamplerProxy>
        
        <!-- Response Assertions -->
        <ResponseAssertion guiclass="AssertionGui" testclass="ResponseAssertion" testname="Success Response Assertion">
          <collectionProp name="Asserion.test_strings">
            <stringProp name="49586">200</stringProp>
          </collectionProp>
          <stringProp name="Assertion.test_field">Assertion.response_code</stringProp>
          <boolProp name="Assertion.assume_success">false</boolProp>
          <intProp name="Assertion.test_type">1</intProp>
        </ResponseAssertion>
        
        <!-- Response Time Assertion -->
        <DurationAssertion guiclass="DurationAssertionGui" testclass="DurationAssertion" testname="Response Time Assertion">
          <stringProp name="DurationAssertion.duration">2000</stringProp>
        </DurationAssertion>
      </hashTree>
    </hashTree>
  </hashTree>
</jmeterTestPlan>
```

#### Database Performance Test Script
```java
@Component
public class DatabasePerformanceTest {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    private final Logger logger = LoggerFactory.getLogger(DatabasePerformanceTest.class);
    
    public void runDatabasePerformanceTest() {
        // Test data insertion performance
        testBulkInsertPerformance();
        
        // Test query performance
        testQueryPerformance();
        
        // Test concurrent access
        testConcurrentDatabaseAccess();
        
        // Test connection pool under load
        testConnectionPoolPerformance();
    }
    
    private void testBulkInsertPerformance() {
        int batchSize = 1000;
        int totalRecords = 10000;
        
        Stopwatch stopwatch = Stopwatch.createStarted();
        
        for (int i = 0; i < totalRecords / batchSize; i++) {
            List<User> users = createTestUsers(batchSize, i * batchSize);
            userRepository.saveAll(users);
        }
        
        stopwatch.stop();
        long durationMs = stopwatch.elapsed(TimeUnit.MILLISECONDS);
        double recordsPerSecond = (double) totalRecords / (durationMs / 1000.0);
        
        logger.info("Bulk insert performance: {} records in {}ms ({} records/sec)", 
                   totalRecords, durationMs, recordsPerSecond);
        
        // Assert performance criteria
        assert recordsPerSecond >= 500 : "Bulk insert performance below threshold";
    }
    
    private void testQueryPerformance() {
        // Test different query patterns
        testSimpleQuery();
        testComplexQuery();
        testPaginationQuery();
    }
    
    private void testSimpleQuery() {
        Stopwatch stopwatch = Stopwatch.createStarted();
        
        for (int i = 0; i < 1000; i++) {
            Optional<User> user = userRepository.findById((long) (i % 100) + 1);
        }
        
        stopwatch.stop();
        long avgQueryTime = stopwatch.elapsed(TimeUnit.MILLISECONDS) / 1000;
        
        logger.info("Average simple query time: {}ms", avgQueryTime);
        assert avgQueryTime <= 5 : "Simple query performance degraded";
    }
    
    private void testComplexQuery() {
        String complexQuery = """
            SELECT u.*, p.* FROM users u 
            LEFT JOIN profiles p ON u.id = p.user_id 
            WHERE u.active = true 
            AND u.created_at > ? 
            ORDER BY u.created_at DESC 
            LIMIT 100
        """;
        
        Stopwatch stopwatch = Stopwatch.createStarted();
        
        jdbcTemplate.query(complexQuery, 
                          (rs, rowNum) -> mapUserWithProfile(rs),
                          LocalDateTime.now().minusDays(30));
                          
        stopwatch.stop();
        long queryTime = stopwatch.elapsed(TimeUnit.MILLISECONDS);
        
        logger.info("Complex query execution time: {}ms", queryTime);
        assert queryTime <= 100 : "Complex query performance degraded";
    }
    
    private void testConcurrentDatabaseAccess() {
        int threadCount = 20;
        int operationsPerThread = 100;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch latch = new CountDownLatch(threadCount);
        
        Stopwatch stopwatch = Stopwatch.createStarted();
        
        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    for (int j = 0; j < operationsPerThread; j++) {
                        // Mix of read and write operations
                        if (j % 3 == 0) {
                            User user = createTestUser("concurrent_" + threadId + "_" + j);
                            userRepository.save(user);
                        } else {
                            userRepository.findByUsernameContaining("concurrent");
                        }
                    }
                } finally {
                    latch.countDown();
                }
            });
        }
        
        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        stopwatch.stop();
        long totalTime = stopwatch.elapsed(TimeUnit.MILLISECONDS);
        double operationsPerSecond = (double) (threadCount * operationsPerThread) / (totalTime / 1000.0);
        
        logger.info("Concurrent database access: {} ops/sec", operationsPerSecond);
        executor.shutdown();
    }
    
    private List<User> createTestUsers(int count, int startIndex) {
        return IntStream.range(startIndex, startIndex + count)
                .mapToObj(i -> User.builder()
                    .username("perftest_user_" + i)
                    .email("perftest" + i + "@example.com")
                    .password("encoded_password")
                    .active(true)
                    .createdAt(LocalDateTime.now())
                    .build())
                .collect(Collectors.toList());
    }
}
```

### Gatling Performance Tests

#### User Journey Load Test
```scala
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class UserJourneyLoadTest extends Simulation {

  val httpProtocol = http
    .baseUrl("http://localhost:8080")
    .acceptHeader("application/json")
    .contentTypeHeader("application/json")
    .userAgentHeader("Gatling Load Test")

  val registrationScenario = scenario("User Registration Journey")
    .exec(
      http("Register User")
        .post("/api/users/register")
        .body(StringBody("""{"username":"gatling_${randomUuid()}","email":"gatling_${randomUuid()}@example.com","password":"GatlingPassword123!"}"""))
        .check(status.is(201))
        .check(jsonPath("$.id").saveAs("userId"))
    )
    .pause(2.seconds)
    .exec(
      http("Login User")
        .post("/api/auth/login")
        .body(StringBody("""{"username":"gatling_${randomUuid()}","password":"GatlingPassword123!"}"""))
        .check(status.is(200))
        .check(jsonPath("$.token").saveAs("authToken"))
    )
    .pause(1.second)
    .exec(
      http("Get User Profile")
        .get("/api/users/${userId}")
        .header("Authorization", "Bearer ${authToken}")
        .check(status.is(200))
        .check(responseTimeInMillis.lte(500))
    )

  val browsingScenario = scenario("User Browsing Journey")
    .exec(
      http("Get Dashboard")
        .get("/api/dashboard")
        .check(status.is(200))
        .check(responseTimeInMillis.lte(1000))
    )
    .pause(3.seconds)
    .repeat(5) {
      exec(
        http("Browse Content")
          .get("/api/content?page=${randomInt(1, 10)}")
          .check(status.is(200))
          .check(responseTimeInMillis.lte(800))
      )
      .pause(2.seconds)
    }

  setUp(
    registrationScenario.inject(
      rampUsersPerSec(1) to 10 during 2.minutes,
      constantUsersPerSec(10) during 5.minutes,
      rampUsersPerSec(10) to 1 during 2.minutes
    ),
    browsingScenario.inject(
      rampUsersPerSec(5) to 50 during 3.minutes,
      constantUsersPerSec(50) during 10.minutes,
      rampUsersPerSec(50) to 5 during 3.minutes
    )
  ).protocols(httpProtocol)
   .maxDuration(20.minutes)
   .assertions(
     global.responseTime.max.lt(5000),
     global.responseTime.mean.lt(1000),
     global.successfulRequests.percent.gt(95)
   )
}
```

## Memory & Resource Testing

### Memory Leak Detection

#### JVM Memory Analysis
```java
@Service
public class MemoryProfilerService {
    
    private final MemoryMXBean memoryMXBean = ManagementFactory.getMemoryMXBean();
    private final List<GarbageCollectorMXBean> gcBeans = ManagementFactory.getGarbageCollectorMXBeans();
    private final Logger logger = LoggerFactory.getLogger(MemoryProfilerService.class);
    
    @Scheduled(fixedRate = 30000) // Every 30 seconds
    public void logMemoryUsage() {
        MemoryUsage heapUsage = memoryMXBean.getHeapMemoryUsage();
        MemoryUsage nonHeapUsage = memoryMXBean.getNonHeapMemoryUsage();
        
        logger.info("Memory Usage - Heap: {}/{} MB, Non-Heap: {}/{} MB",
                   heapUsage.getUsed() / 1024 / 1024,
                   heapUsage.getMax() / 1024 / 1024,
                   nonHeapUsage.getUsed() / 1024 / 1024,
                   nonHeapUsage.getMax() / 1024 / 1024);
                   
        // Check for potential memory leaks
        if (heapUsage.getUsed() > heapUsage.getMax() * 0.9) {
            logger.warn("High heap memory usage detected: {}%", 
                       (heapUsage.getUsed() * 100) / heapUsage.getMax());
        }
    }
    
    @Scheduled(fixedRate = 60000) // Every minute
    public void logGCStats() {
        for (GarbageCollectorMXBean gcBean : gcBeans) {
            logger.info("GC {} - Collections: {}, Time: {}ms",
                       gcBean.getName(),
                       gcBean.getCollectionCount(),
                       gcBean.getCollectionTime());
        }
    }
    
    public MemoryReport generateMemoryReport() {
        return MemoryReport.builder()
            .heapUsage(memoryMXBean.getHeapMemoryUsage())
            .nonHeapUsage(memoryMXBean.getNonHeapMemoryUsage())
            .gcStats(collectGCStats())
            .timestamp(LocalDateTime.now())
            .build();
    }
    
    private List<GCStats> collectGCStats() {
        return gcBeans.stream()
            .map(gcBean -> GCStats.builder()
                .name(gcBean.getName())
                .collectionCount(gcBean.getCollectionCount())
                .collectionTime(gcBean.getCollectionTime())
                .build())
            .collect(Collectors.toList());
    }
}
```

#### Memory Stress Test
```java
@Component
public class MemoryStressTest {
    
    private final Logger logger = LoggerFactory.getLogger(MemoryStressTest.class);
    private final List<byte[]> memoryHogger = new ArrayList<>();
    
    public void runMemoryStressTest() {
        logger.info("Starting memory stress test...");
        
        try {
            // Gradually increase memory usage
            for (int i = 0; i < 100; i++) {
                // Allocate 10MB chunks
                byte[] chunk = new byte[10 * 1024 * 1024];
                Arrays.fill(chunk, (byte) i);
                memoryHogger.add(chunk);
                
                if (i % 10 == 0) {
                    Runtime runtime = Runtime.getRuntime();
                    long usedMemory = runtime.totalMemory() - runtime.freeMemory();
                    logger.info("Memory stress test iteration {}: {} MB used", 
                               i, usedMemory / 1024 / 1024);
                }
                
                Thread.sleep(100);
            }
        } catch (OutOfMemoryError e) {
            logger.error("Out of memory during stress test", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            // Cleanup
            memoryHogger.clear();
            System.gc();
            logger.info("Memory stress test completed and cleaned up");
        }
    }
    
    public void runMemoryLeakSimulation() {
        Map<String, List<String>> leakyMap = new HashMap<>();
        
        for (int i = 0; i < 10000; i++) {
            String key = "key_" + (i % 100);
            leakyMap.computeIfAbsent(key, k -> new ArrayList<>())
                    .add("Large string data that could cause memory leaks " +
                         "if not properly managed in the application " + i);
        }
        
        // Intentionally not clearing the map to simulate leak
        logger.warn("Memory leak simulation created {} entries", leakyMap.size());
    }
}
```

## Application Performance Monitoring

### Custom Metrics Collection

#### Performance Metrics Service
```java
@Service
public class PerformanceMetricsService {
    
    private final MeterRegistry meterRegistry;
    private final Timer requestTimer;
    private final Counter errorCounter;
    private final Gauge memoryGauge;
    private final Counter databaseConnectionCounter;
    
    public PerformanceMetricsService(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        
        this.requestTimer = Timer.builder("app.request.duration")
            .description("Request processing time")
            .register(meterRegistry);
            
        this.errorCounter = Counter.builder("app.errors.total")
            .description("Total application errors")
            .register(meterRegistry);
            
        this.memoryGauge = Gauge.builder("app.memory.used")
            .description("Used heap memory in bytes")
            .register(meterRegistry, this, PerformanceMetricsService::getUsedMemory);
            
        this.databaseConnectionCounter = Counter.builder("app.db.connections")
            .description("Database connections created")
            .register(meterRegistry);
    }
    
    public Timer.Sample startRequestTimer() {
        return Timer.start(meterRegistry);
    }
    
    public void recordRequestTime(Timer.Sample sample, String endpoint, String method) {
        sample.stop(Timer.builder("app.request.duration")
            .tag("endpoint", endpoint)
            .tag("method", method)
            .register(meterRegistry));
    }
    
    public void incrementErrorCount(String errorType) {
        errorCounter.increment(Tags.of("type", errorType));
    }
    
    public void recordDatabaseConnection() {
        databaseConnectionCounter.increment();
    }
    
    private double getUsedMemory() {
        return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();
    }
    
    @EventListener
    public void handlePerformanceEvent(PerformanceEvent event) {
        Timer.builder("app.operation.duration")
            .tag("operation", event.getOperationType())
            .register(meterRegistry)
            .record(event.getDuration(), TimeUnit.MILLISECONDS);
    }
}
```

#### Performance Interceptor
```java
@Component
@Aspect
public class PerformanceMonitoringAspect {
    
    private final PerformanceMetricsService metricsService;
    private final Logger logger = LoggerFactory.getLogger(PerformanceMonitoringAspect.class);
    
    public PerformanceMonitoringAspect(PerformanceMetricsService metricsService) {
        this.metricsService = metricsService;
    }
    
    @Around("@annotation(Monitored)")
    public Object monitorPerformance(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        String className = joinPoint.getTarget().getClass().getSimpleName();
        
        Timer.Sample sample = metricsService.startRequestTimer();
        Stopwatch stopwatch = Stopwatch.createStarted();
        
        try {
            Object result = joinPoint.proceed();
            
            stopwatch.stop();
            long duration = stopwatch.elapsed(TimeUnit.MILLISECONDS);
            
            metricsService.recordRequestTime(sample, className + "." + methodName, "METHOD");
            
            if (duration > 1000) {
                logger.warn("Slow method execution: {}.{} took {}ms", 
                           className, methodName, duration);
            }
            
            return result;
        } catch (Exception e) {
            metricsService.incrementErrorCount(e.getClass().getSimpleName());
            throw e;
        }
    }
    
    @Around("execution(* com.company.app.controller.*.*(..))")
    public Object monitorControllerMethods(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        Timer.Sample sample = metricsService.startRequestTimer();
        
        try {
            return joinPoint.proceed();
        } finally {
            metricsService.recordRequestTime(sample, methodName, "CONTROLLER");
        }
    }
}

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Monitored {
}
```

### Database Performance Monitoring

#### Database Metrics Collector
```java
@Component
public class DatabaseMetricsCollector {
    
    private final DataSource dataSource;
    private final MeterRegistry meterRegistry;
    private final Logger logger = LoggerFactory.getLogger(DatabaseMetricsCollector.class);
    
    public DatabaseMetricsCollector(DataSource dataSource, MeterRegistry meterRegistry) {
        this.dataSource = dataSource;
        this.meterRegistry = meterRegistry;
        
        // Register custom database metrics
        Gauge.builder("db.connections.active")
            .description("Active database connections")
            .register(meterRegistry, this, DatabaseMetricsCollector::getActiveConnections);
            
        Gauge.builder("db.connections.idle")
            .description("Idle database connections")
            .register(meterRegistry, this, DatabaseMetricsCollector::getIdleConnections);
    }
    
    @Scheduled(fixedRate = 30000)
    public void collectSlowQueries() {
        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement()) {
            
            String slowQuerySQL = """
                SELECT query, mean_exec_time, calls, rows 
                FROM pg_stat_statements 
                WHERE mean_exec_time > 1000 
                ORDER BY mean_exec_time DESC 
                LIMIT 10
            """;
            
            ResultSet rs = statement.executeQuery(slowQuerySQL);
            
            while (rs.next()) {
                String query = rs.getString("query");
                double meanTime = rs.getDouble("mean_exec_time");
                long calls = rs.getLong("calls");
                
                logger.warn("Slow query detected: {} ms average, {} calls: {}", 
                           meanTime, calls, query.substring(0, Math.min(query.length(), 100)));
                           
                // Record metric
                Timer.builder("db.query.slow")
                    .tag("query_type", extractQueryType(query))
                    .register(meterRegistry)
                    .record((long) meanTime, TimeUnit.MILLISECONDS);
            }
        } catch (SQLException e) {
            logger.error("Error collecting slow query metrics", e);
        }
    }
    
    private double getActiveConnections() {
        if (dataSource instanceof HikariDataSource) {
            HikariDataSource hikari = (HikariDataSource) dataSource;
            return hikari.getHikariPoolMXBean().getActiveConnections();
        }
        return 0;
    }
    
    private double getIdleConnections() {
        if (dataSource instanceof HikariDataSource) {
            HikariDataSource hikari = (HikariDataSource) dataSource;
            return hikari.getHikariPoolMXBean().getIdleConnections();
        }
        return 0;
    }
    
    private String extractQueryType(String query) {
        String upperQuery = query.toUpperCase().trim();
        if (upperQuery.startsWith("SELECT")) return "SELECT";
        if (upperQuery.startsWith("INSERT")) return "INSERT";
        if (upperQuery.startsWith("UPDATE")) return "UPDATE";
        if (upperQuery.startsWith("DELETE")) return "DELETE";
        return "OTHER";
    }
}
```

## Performance Test Automation

### Maven Integration

#### Performance Test Profile
```xml
<profile>
    <id>performance-test</id>
    <properties>
        <skipTests>true</skipTests>
        <skipUnitTests>true</skipUnitTests>
    </properties>
    
    <build>
        <plugins>
            <!-- JMeter Maven Plugin -->
            <plugin>
                <groupId>com.lazerycode.jmeter</groupId>
                <artifactId>jmeter-maven-plugin</artifactId>
                <version>3.7.0</version>
                <executions>
                    <execution>
                        <id>configuration</id>
                        <goals>
                            <goal>configure</goal>
                        </goals>
                    </execution>
                    <execution>
                        <id>jmeter-tests</id>
                        <goals>
                            <goal>jmeter</goal>
                        </goals>
                        <configuration>
                            <testFilesIncluded>
                                <jMeterTestFile>UserLoadTest.jmx</jMeterTestFile>
                                <jMeterTestFile>DatabasePerformanceTest.jmx</jMeterTestFile>
                            </testFilesIncluded>
                            <resultsFileFormat>xml</resultsFileFormat>
                        </configuration>
                    </execution>
                    <execution>
                        <id>jmeter-check-results</id>
                        <goals>
                            <goal>results</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
            
            <!-- Gatling Maven Plugin -->
            <plugin>
                <groupId>io.gatling</groupId>
                <artifactId>gatling-maven-plugin</artifactId>
                <version>4.3.7</version>
                <configuration>
                    <simulationClass>com.company.app.perf.UserJourneyLoadTest</simulationClass>
                </configuration>
            </plugin>
            
            <!-- Performance Test Reporting -->
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <version>3.1.0</version>
                <executions>
                    <execution>
                        <id>generate-performance-report</id>
                        <phase>post-integration-test</phase>
                        <goals>
                            <goal>java</goal>
                        </goals>
                        <configuration>
                            <mainClass>com.company.app.perf.PerformanceReportGenerator</mainClass>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</profile>
```

### CI/CD Performance Pipeline

#### GitHub Actions Performance Workflow
```yaml
name: Performance Testing

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]
  schedule:
    - cron: '0 2 * * 1-5'  # Weekday nights

jobs:
  performance-test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:13
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: perftest
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432
          
      redis:
        image: redis:7-alpine
        ports:
          - 6379:6379
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Java 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
        
    - name: Cache Maven dependencies
      uses: actions/cache@v3
      with:
        path: ~/.m2
        key: ${{ runner.os }}-m2-${{ hashFiles('**/pom.xml') }}
        
    - name: Build application
      run: mvn clean package -DskipTests
      
    - name: Start application
      run: |
        java -jar target/app.jar \
          --spring.profiles.active=performance-test \
          --server.port=8080 &
        sleep 30
        
    - name: Health check
      run: |
        curl -f http://localhost:8080/actuator/health || exit 1
        
    - name: Run JMeter performance tests
      run: mvn jmeter:jmeter -Pperformance-test
      
    - name: Run Gatling performance tests
      run: mvn gatling:test -Pperformance-test
      
    - name: Analyze performance results
      run: mvn exec:java@generate-performance-report
      
    - name: Upload performance reports
      uses: actions/upload-artifact@v3
      if: always()
      with:
        name: performance-reports
        path: |
          target/jmeter/reports/
          target/gatling/
          target/performance-reports/
          
    - name: Performance regression check
      run: |
        # Compare with baseline performance metrics
        python scripts/check-performance-regression.py \
          --baseline performance-baselines/main-branch.json \
          --current target/performance-reports/metrics.json \
          --threshold 10
```

## Performance Analysis & Reporting

### Performance Report Generation

#### Report Generator Service
```java
@Service
public class PerformanceReportGenerator {
    
    private final Logger logger = LoggerFactory.getLogger(PerformanceReportGenerator.class);
    
    public void generatePerformanceReport(String testResults, String outputPath) {
        try {
            PerformanceData data = parseTestResults(testResults);
            PerformanceReport report = createReport(data);
            
            // Generate HTML report
            generateHtmlReport(report, outputPath + "/performance-report.html");
            
            // Generate JSON metrics for CI/CD
            generateJsonMetrics(report, outputPath + "/metrics.json");
            
            // Generate CSV for analysis
            generateCsvData(data, outputPath + "/raw-data.csv");
            
            logger.info("Performance report generated at: {}", outputPath);
            
        } catch (Exception e) {
            logger.error("Failed to generate performance report", e);
            throw new RuntimeException("Performance report generation failed", e);
        }
    }
    
    private PerformanceData parseTestResults(String testResults) {
        // Parse JMeter/Gatling results
        return PerformanceDataParser.parse(testResults);
    }
    
    private PerformanceReport createReport(PerformanceData data) {
        return PerformanceReport.builder()
            .timestamp(LocalDateTime.now())
            .testDuration(data.getTestDuration())
            .totalRequests(data.getTotalRequests())
            .successfulRequests(data.getSuccessfulRequests())
            .failedRequests(data.getFailedRequests())
            .averageResponseTime(data.getAverageResponseTime())
            .minResponseTime(data.getMinResponseTime())
            .maxResponseTime(data.getMaxResponseTime())
            .percentile90(data.getPercentile90())
            .percentile95(data.getPercentile95())
            .percentile99(data.getPercentile99())
            .throughput(data.getThroughput())
            .errorRate(data.getErrorRate())
            .memoryUsage(data.getMemoryUsage())
            .gcStats(data.getGcStats())
            .databaseStats(data.getDatabaseStats())
            .build();
    }
    
    private void generateHtmlReport(PerformanceReport report, String filePath) {
        String htmlTemplate = loadTemplate("performance-report-template.html");
        String html = processTemplate(htmlTemplate, report);
        
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(html);
        } catch (IOException e) {
            throw new RuntimeException("Failed to write HTML report", e);
        }
    }
    
    private void generateJsonMetrics(PerformanceReport report, String filePath) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        
        try {
            mapper.writeValue(new File(filePath), report);
        } catch (IOException e) {
            throw new RuntimeException("Failed to write JSON metrics", e);
        }
    }
}
```

### Performance Baseline Management

#### Baseline Comparison Service
```java
@Service
public class PerformanceBaselineService {
    
    private final Logger logger = LoggerFactory.getLogger(PerformanceBaselineService.class);
    private static final double REGRESSION_THRESHOLD = 0.1; // 10% degradation threshold
    
    public ComparisonResult compareWithBaseline(PerformanceReport current, PerformanceReport baseline) {
        List<RegressionDetection> regressions = new ArrayList<>();
        
        // Compare response times
        if (isRegression(current.getAverageResponseTime(), baseline.getAverageResponseTime())) {
            regressions.add(RegressionDetection.builder()
                .metric("Average Response Time")
                .currentValue(current.getAverageResponseTime())
                .baselineValue(baseline.getAverageResponseTime())
                .regressionPercent(calculateRegressionPercent(
                    current.getAverageResponseTime(), baseline.getAverageResponseTime()))
                .build());
        }
        
        // Compare throughput
        if (isRegression(baseline.getThroughput(), current.getThroughput())) {
            regressions.add(RegressionDetection.builder()
                .metric("Throughput")
                .currentValue(current.getThroughput())
                .baselineValue(baseline.getThroughput())
                .regressionPercent(calculateRegressionPercent(
                    baseline.getThroughput(), current.getThroughput()))
                .build());
        }
        
        // Compare memory usage
        if (isRegression(current.getMemoryUsage().getMaxHeapUsed(), 
                         baseline.getMemoryUsage().getMaxHeapUsed())) {
            regressions.add(RegressionDetection.builder()
                .metric("Memory Usage")
                .currentValue(current.getMemoryUsage().getMaxHeapUsed())
                .baselineValue(baseline.getMemoryUsage().getMaxHeapUsed())
                .regressionPercent(calculateRegressionPercent(
                    current.getMemoryUsage().getMaxHeapUsed(),
                    baseline.getMemoryUsage().getMaxHeapUsed()))
                .build());
        }
        
        return ComparisonResult.builder()
            .hasRegressions(!regressions.isEmpty())
            .regressions(regressions)
            .comparisonTimestamp(LocalDateTime.now())
            .build();
    }
    
    private boolean isRegression(double currentValue, double baselineValue) {
        double regressionPercent = (currentValue - baselineValue) / baselineValue;
        return regressionPercent > REGRESSION_THRESHOLD;
    }
    
    private double calculateRegressionPercent(double currentValue, double baselineValue) {
        return ((currentValue - baselineValue) / baselineValue) * 100;
    }
    
    public void updateBaseline(PerformanceReport newBaseline) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            
            String baselinePath = "performance-baselines/current-baseline.json";
            mapper.writeValue(new File(baselinePath), newBaseline);
            
            logger.info("Performance baseline updated successfully");
        } catch (IOException e) {
            logger.error("Failed to update performance baseline", e);
            throw new RuntimeException("Baseline update failed", e);
        }
    }
}
```

## Performance Monitoring Dashboard

### Grafana Dashboard Configuration
```json
{
  "dashboard": {
    "id": null,
    "title": "Application Performance Dashboard",
    "tags": ["performance", "monitoring"],
    "timezone": "browser",
    "panels": [
      {
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(app_request_duration_seconds_bucket[5m]))",
            "legendFormat": "95th Percentile"
          },
          {
            "expr": "histogram_quantile(0.50, rate(app_request_duration_seconds_bucket[5m]))",
            "legendFormat": "50th Percentile"
          }
        ],
        "yAxes": [
          {
            "label": "Response Time (seconds)",
            "min": 0
          }
        ]
      },
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(app_request_duration_seconds_count[5m])",
            "legendFormat": "Requests per second"
          }
        ]
      },
      {
        "title": "Error Rate",
        "type": "stat",
        "targets": [
          {
            "expr": "rate(app_errors_total[5m]) / rate(app_request_duration_seconds_count[5m]) * 100",
            "legendFormat": "Error Rate %"
          }
        ],
        "fieldConfig": {
          "defaults": {
            "unit": "percent",
            "thresholds": {
              "steps": [
                {"color": "green", "value": 0},
                {"color": "yellow", "value": 1},
                {"color": "red", "value": 5}
              ]
            }
          }
        }
      },
      {
        "title": "Memory Usage",
        "type": "graph",
        "targets": [
          {
            "expr": "app_memory_used",
            "legendFormat": "Heap Memory Used"
          },
          {
            "expr": "app_memory_max",
            "legendFormat": "Max Heap Memory"
          }
        ]
      }
    ],
    "refresh": "5s",
    "time": {
      "from": "now-1h",
      "to": "now"
    }
  }
}
```

## Performance Testing Best Practices

### Test Design Principles

1. **Realistic Test Data**
   - Use production-like data volumes
   - Maintain data relationships and constraints
   - Include edge cases and boundary conditions

2. **Gradual Load Increase**
   - Ramp up load gradually to identify breaking points
   - Use realistic user behavior patterns
   - Include think time between operations

3. **Environment Consistency**
   - Use dedicated performance test environments
   - Maintain consistent hardware specifications
   - Minimize external dependencies during testing

4. **Comprehensive Monitoring**
   - Monitor all system layers (application, database, infrastructure)
   - Collect metrics before, during, and after tests
   - Set up automated alerting for anomalies

### Performance Test Checklist

#### Pre-Test Preparation
- [ ] Test environment provisioned and configured
- [ ] Baseline performance metrics established
- [ ] Test data prepared and validated
- [ ] Monitoring systems configured
- [ ] Test scripts validated in lower environments

#### During Test Execution
- [ ] Real-time monitoring active
- [ ] Test progress tracking
- [ ] Resource utilization monitoring
- [ ] Error rate monitoring
- [ ] Response time tracking

#### Post-Test Analysis
- [ ] Performance results analyzed
- [ ] Bottlenecks identified
- [ ] Regression analysis completed
- [ ] Performance report generated
- [ ] Recommendations documented

## Continuous Performance Testing

### Performance Testing Pipeline Integration

```bash
#!/bin/bash
# Continuous performance testing script

BRANCH_NAME=$1
BASELINE_FILE="performance-baselines/${BRANCH_NAME}-baseline.json"

echo "Starting continuous performance testing for branch: $BRANCH_NAME"

# Start application
java -jar target/app.jar --spring.profiles.active=performance-test &
APP_PID=$!

# Wait for application startup
sleep 30

# Run lightweight performance tests
mvn gatling:test -Dgatling.simulationClass=QuickPerformanceTest

# Stop application
kill $APP_PID

# Compare with baseline
if [ -f "$BASELINE_FILE" ]; then
    python scripts/compare-performance.py \
        --current target/gatling/results/metrics.json \
        --baseline "$BASELINE_FILE" \
        --threshold 15
else
    echo "No baseline found for branch $BRANCH_NAME, creating new baseline"
    cp target/gatling/results/metrics.json "$BASELINE_FILE"
fi

echo "Continuous performance testing completed"
```

## Troubleshooting Performance Issues

### Common Performance Problems

#### 1. Slow Database Queries
**Symptoms**: High response times, database connection pool exhaustion
**Investigation**:
- Check slow query logs
- Analyze query execution plans
- Monitor connection pool metrics

**Solutions**:
- Add database indexes
- Optimize query patterns
- Implement query result caching

#### 2. Memory Leaks
**Symptoms**: Increasing memory usage over time, frequent GC
**Investigation**:
- Heap dump analysis
- GC log analysis
- Memory profiling

**Solutions**:
- Fix object lifecycle management
- Implement proper resource cleanup
- Optimize collection usage

#### 3. Thread Contention
**Symptoms**: High CPU usage, poor concurrent performance
**Investigation**:
- Thread dump analysis
- Lock contention monitoring
- Concurrent access patterns

**Solutions**:
- Optimize synchronization
- Use concurrent collections
- Implement lock-free algorithms

## Next Steps

1. **Environment Setup**: Configure performance testing infrastructure
2. **Test Implementation**: Develop comprehensive test suites
3. **Baseline Establishment**: Create performance benchmarks
4. **Monitoring Setup**: Implement continuous performance monitoring
5. **Integration**: Integrate with CI/CD pipeline

---

**Last Updated**: 2025-08-26
**Version**: 1.0
**Reviewed By**: Performance Engineering Team