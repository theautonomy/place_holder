# Confluence Migration Guide

## Overview

This guide provides step-by-step instructions for migrating the legacy Java EE application upgrade wiki pages from Markdown format to Confluence wiki pages. The migration ensures all technical documentation, code examples, and project structure are preserved and enhanced with Confluence-specific features.

## Migration Options

### Option 1: Manual Copy & Paste (Recommended)

**Best for**: High-quality migration with full control over formatting and Confluence features.

#### Advantages
- Full control over formatting and layout
- Ability to add Confluence-specific macros and enhancements
- Proper handling of code blocks and syntax highlighting
- Custom page linking and navigation structure
- Quality assurance during migration process

#### Steps
1. **Create Confluence Space**
   ```
   Space Name: Legacy Java EE Upgrade Project
   Space Key: LJEEU
   Description: Documentation for upgrading legacy Java EE application from Struts 2.5/Spring 5.3/Tomcat 9 to Struts 7/Spring 6/Tomcat 10
   ```

2. **Set up Page Hierarchy** (see structure below)

3. **Migrate Each Page**:
   - Copy Markdown content from source file
   - Paste into Confluence editor
   - Review and adjust formatting
   - Add Confluence macros where appropriate
   - Create proper inter-page links

4. **Quality Review**:
   - Verify all code blocks display correctly
   - Test all internal and external links
   - Ensure proper table formatting
   - Validate macro functionality

### Option 2: Confluence Import Feature

**Best for**: Quick bulk migration with automatic conversion.

#### Steps
1. **Prepare Files**:
   - Ensure all .md files are in a single directory
   - Verify file naming conventions
   - Remove any problematic characters from filenames

2. **Import Process**:
   - Navigate to Space Settings → Content Tools → Import
   - Select "Markdown" as the import format
   - Upload your .md files (can be zipped)
   - Configure import settings:
     ```
     ☑ Create page hierarchy from file structure
     ☑ Convert code blocks to Code Block macro
     ☑ Convert tables to Table macro
     ☑ Preserve heading structure
     ```

3. **Post-Import Cleanup**:
   - Review imported pages for formatting issues
   - Fix broken internal links
   - Add missing Confluence macros
   - Organize page hierarchy

### Option 3: Pandoc Conversion

**Best for**: Automated conversion with custom formatting rules.

#### Prerequisites
```bash
# Install pandoc
# Windows (using Chocolatey)
choco install pandoc

# macOS (using Homebrew)
brew install pandoc

# Ubuntu/Debian
sudo apt-get install pandoc
```

#### Conversion Script
```bash
#!/bin/bash
# confluence-conversion.sh

INPUT_DIR="wiki"
OUTPUT_DIR="confluence-pages"

mkdir -p "$OUTPUT_DIR"

echo "Converting wiki pages to Confluence format..."

# Convert each markdown file
for file in "$INPUT_DIR"/*.md; do
    filename=$(basename "$file" .md)
    echo "Converting $filename..."
    
    pandoc -f markdown -t confluence \
           --wrap=none \
           --reference-links \
           "$file" -o "$OUTPUT_DIR/${filename}.confluence"
done

echo "Conversion complete. Files saved to $OUTPUT_DIR/"
```

#### Upload Converted Files
```bash
# Using confluence-cli (if available in your organization)
for file in confluence-pages/*.confluence; do
    confluence --action storePage \
               --space "LJEEU" \
               --title "$(basename "$file" .confluence)" \
               --file "$file"
done
```

### Option 4: REST API Automation

**Best for**: Organizations with API access and automation requirements.

#### Python Script Example
```python
import requests
import base64
import json
from pathlib import Path

class ConfluenceUploader:
    def __init__(self, base_url, username, api_token, space_key):
        self.base_url = base_url
        self.auth = (username, api_token)
        self.space_key = space_key
        self.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    
    def create_page(self, title, content, parent_id=None):
        url = f"{self.base_url}/rest/api/content"
        
        page_data = {
            "type": "page",
            "title": title,
            "space": {"key": self.space_key},
            "body": {
                "storage": {
                    "value": content,
                    "representation": "storage"
                }
            }
        }
        
        if parent_id:
            page_data["ancestors"] = [{"id": parent_id}]
        
        response = requests.post(url, 
                               json=page_data, 
                               headers=self.headers, 
                               auth=self.auth)
        
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error creating page: {response.text}")
            return None
    
    def upload_markdown_files(self, wiki_dir):
        wiki_path = Path(wiki_dir)
        
        for md_file in wiki_path.glob("*.md"):
            title = md_file.stem.replace("-", " ")
            content = self.convert_markdown_to_storage(md_file.read_text())
            
            print(f"Uploading: {title}")
            result = self.create_page(title, content)
            
            if result:
                print(f"✓ Created page: {result['_links']['webui']}")
            else:
                print(f"✗ Failed to create page: {title}")
    
    def convert_markdown_to_storage(self, markdown_content):
        # Convert markdown to Confluence storage format
        # This is a simplified example - you might want to use pandoc or a library
        storage_content = markdown_content
        
        # Basic conversions
        storage_content = storage_content.replace("```", "<ac:structured-macro ac:name=\"code\"><ac:plain-text-body><![CDATA[")
        storage_content = storage_content.replace("```", "]]></ac:plain-text-body></ac:structured-macro>")
        
        return storage_content

# Usage
uploader = ConfluenceUploader(
    base_url="https://your-domain.atlassian.net",
    username="your-email@company.com",
    api_token="your-api-token",
    space_key="LJEEU"
)

uploader.upload_markdown_files("wiki/")
```

## Recommended Confluence Space Structure

### Page Hierarchy
```
📁 Legacy Java EE Upgrade Project (Space Home)
├── 📄 Project Overview
│   ├── Project Scope and Objectives
│   ├── Timeline and Milestones
│   ├── Success Criteria
│   └── Risk Management
├── 📁 Technical Upgrade Guides
│   ├── 📄 Struts 2.5 to Struts 7 Migration
│   │   ├── Breaking Changes Analysis
│   │   ├── Code Migration Examples
│   │   └── Configuration Updates
│   ├── 📄 Spring 5.3 to Spring 6 Upgrade
│   │   ├── Jakarta EE Migration
│   │   ├── Dependency Updates
│   │   └── Configuration Changes
│   └── 📄 Tomcat 9 to Tomcat 10 Migration
│       ├── Environment Setup
│       ├── Configuration Migration
│       └── Performance Tuning
├── 📁 Architecture & Design
│   ├── 📄 Architecture Design Considerations
│   │   ├── Current State Assessment
│   │   ├── Target Architecture
│   │   └── Migration Strategy
│   └── 📄 Implementation Strategy
│       ├── Phase-by-Phase Approach
│       ├── Quality Gates
│       └── Risk Mitigation
└── 📁 Testing & Quality Assurance
    ├── 📄 Testing Strategy
    │   ├── Test Types and Coverage
    │   ├── Test Automation
    │   └── Quality Gates
    └── 📄 Performance Testing Guide
        ├── Performance Requirements
        ├── Test Implementation
        └── Monitoring Strategy
```

### Confluence Space Settings
```json
{
  "spaceSettings": {
    "theme": "documentation-theme",
    "homepageLayout": "blog-style",
    "navigation": "tree-view",
    "permissions": {
      "viewSpace": ["project-team", "stakeholders"],
      "editPages": ["development-team", "project-leads"],
      "administerSpace": ["project-manager", "tech-lead"]
    },
    "apps": {
      "enableCodeMacro": true,
      "enableTableMacro": true,
      "enableTaskMacro": true,
      "enableStatusMacro": true,
      "enableInfoMacro": true
    }
  }
}
```

## Confluence Enhancement Recommendations

### Essential Macros to Add

#### 1. Table of Contents Macro
Add to each major page:
```confluence
{toc:printable=true|style=disc|maxLevel=3|minLevel=1|type=list|outline=clear|include=.*}
```

#### 2. Code Block Macro
Replace markdown code blocks:
```confluence
{code:language=java|title=User Service Implementation|collapse=false}
@Service
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {
    // Implementation code here
}
{code}
```

#### 3. Info/Warning/Note Macros
For callouts and important information:
```confluence
{info:title=Important Migration Note}
All javax.* imports must be updated to jakarta.* before upgrading to Spring 6.
{info}

{warning:title=Breaking Change}
Struts 7 removes support for the Tiles plugin. Alternative solutions must be implemented.
{warning}

{tip:title=Performance Tip}
Use connection pooling with HikariCP for optimal database performance.
{tip}
```

#### 4. Status Macro
For project phases and task status:
```confluence
{status:colour=Green|title=Completed}
{status:colour=Yellow|title=In Progress}
{status:colour=Red|title=Not Started}
```

#### 5. Task List Macro
For checklists and action items:
```confluence
{task-list}
[] Environment setup completed
[] Dependencies updated
[x] Code migration finished
[] Testing validation pending
{task-list}
```

#### 6. Expand Macro
For detailed technical sections:
```confluence
{expand:title=Click to view detailed configuration}
<!-- Detailed configuration content here -->
{expand}
```

### Page Templates

#### Technical Guide Template
```confluence
{toc}

h1. Overview
Brief description of the technical guide purpose and scope.

{info:title=Prerequisites}
List of prerequisites and dependencies
{info}

h1. Migration Steps

h2. Step 1: Preparation
{code:language=bash}
# Preparation commands
{code}

h2. Step 2: Implementation
{code:language=java}
// Implementation code
{code}

h1. Validation
{task-list}
[] Validation step 1
[] Validation step 2
{task-list}

h1. Troubleshooting
Common issues and solutions.

h1. Next Steps
Links to related documentation and follow-up tasks.
```

#### Testing Guide Template
```confluence
{toc}

h1. Testing Objective
Clear statement of testing goals and success criteria.

h1. Test Scenarios

h2. Scenario 1: [Name]
|| Test Step || Expected Result || Status ||
| Step 1 | Expected outcome | {status:colour=Green|title=Pass} |
| Step 2 | Expected outcome | {status:colour=Yellow|title=In Progress} |

h1. Test Data Requirements
{code:language=sql}
-- Test data setup
{code}

h1. Automation
{code:language=java}
// Test automation code
{code}
```

## Migration Checklist

### Pre-Migration
- [ ] Confluence space created with proper permissions
- [ ] Page hierarchy planned and documented
- [ ] Team access and roles configured
- [ ] Backup of original markdown files created

### During Migration
- [ ] **Project Overview** page migrated and enhanced
- [ ] **Struts Upgrade Guide** converted with proper code highlighting
- [ ] **Spring Upgrade Guide** migrated with configuration examples
- [ ] **Tomcat Migration Guide** converted with deployment scripts
- [ ] **Architecture Considerations** migrated with diagrams
- [ ] **Implementation Strategy** converted with timeline macros
- [ ] **Testing Strategy** migrated with task lists
- [ ] **Performance Testing Guide** converted with monitoring dashboards

### Post-Migration
- [ ] All internal links verified and working
- [ ] Code syntax highlighting validated
- [ ] Table formatting confirmed
- [ ] Confluence macros functioning properly
- [ ] Search indexing completed
- [ ] Team training on Confluence navigation
- [ ] Feedback collection and iteration

### Quality Assurance
- [ ] All pages accessible by intended audience
- [ ] Mobile responsiveness verified
- [ ] Print-friendly formatting confirmed
- [ ] Export functionality tested
- [ ] Version history and change tracking enabled

## Best Practices

### Content Organization
1. **Use consistent naming conventions** for pages and spaces
2. **Create logical page hierarchies** that match project structure
3. **Implement cross-references** between related documentation
4. **Use labels and categories** for easy content discovery

### Visual Enhancement
1. **Add diagrams and flowcharts** using Confluence drawing tools
2. **Use consistent formatting** for code blocks and examples
3. **Implement status indicators** for project phases
4. **Create visual dashboards** for project tracking

### Collaboration Features
1. **Enable comments and feedback** on technical guides
2. **Set up page notifications** for stakeholders
3. **Use @mentions** for specific team member attention
4. **Implement approval workflows** for critical documentation

### Maintenance Strategy
1. **Establish update procedures** for living documentation
2. **Assign page owners** for ongoing maintenance
3. **Schedule regular reviews** of technical accuracy
4. **Archive outdated content** systematically

## Troubleshooting Common Issues

### Code Block Formatting
**Issue**: Code blocks not displaying properly after migration
**Solution**: 
```confluence
{code:language=java|title=Fixed Code Block}
// Your code here
{code}
```

### Broken Internal Links
**Issue**: Links between pages not working
**Solution**: Use Confluence link macro
```confluence
[Link Text|Page Title]
or
[Link Text|spacekey:Page Title]
```

### Table Formatting Issues
**Issue**: Complex tables not converting correctly
**Solution**: Recreate using Confluence Table macro with proper formatting

### Image and Diagram Migration
**Issue**: Images not displaying after migration
**Solution**: 
1. Upload images to Confluence
2. Use Image macro for proper display
3. Consider recreating diagrams using Confluence drawing tools

## Support and Training

### Training Resources
- **Confluence User Guide**: Internal link to Confluence training materials
- **Macro Reference**: Link to Confluence macro documentation
- **Video Tutorials**: Team-specific training recordings
- **Office Hours**: Weekly Q&A sessions for Confluence usage

### Support Contacts
- **Primary Contact**: Technical Writing Team Lead
- **Secondary Contact**: Confluence Administrator  
- **Escalation**: IT Support Team

---

**Document Status**: Draft
**Last Updated**: 2025-08-26
**Next Review**: 2025-09-26
**Owner**: Documentation Team