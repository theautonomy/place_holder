# Spring Framework 5.3 to Spring 6 Upgrade Guide

## Overview

This guide covers the migration from Spring Framework 5.3.x to Spring Framework 6.x, including Jakarta EE migration, new features, and breaking changes.

## Key Changes in Spring 6

### Major Breaking Changes

#### 1. Jakarta EE Migration
- **Namespace Change**: Complete migration from `javax.*` to `jakarta.*`
- **Servlet API**: Jakarta Servlet 5.0+ required
- **JPA**: Jakarta Persistence 3.0+ required
- **Bean Validation**: Jakarta Bean Validation 3.0+ required
- **JMS**: Jakarta Messaging 3.0+ required

#### 2. Minimum Requirements
- **Java**: Java 17+ (minimum baseline)
- **Jakarta EE**: Version 9+ APIs
- **Tomcat**: 10.0+ for full compatibility
- **Maven**: 3.6.3+

#### 3. Removed Features
- **Commons Logging**: Replaced with direct SLF4J integration
- **Legacy Spring Web MVC Features**: Some deprecated MVC patterns removed
- **Older Configuration Patterns**: XML-heavy configurations discouraged

### New Features & Enhancements

#### 1. Native Compilation Support
- GraalVM native image support
- Ahead-of-time (AOT) compilation
- Improved startup times

#### 2. Enhanced Observability
- Micrometer integration improvements
- Better metrics and tracing support
- Health indicator enhancements

#### 3. Modern Java Support
- Records and pattern matching support
- Enhanced functional programming features
- Improved annotation processing

## Migration Strategy

### Phase 1: Environment Assessment

#### Current Dependencies Audit
```bash
# Find Spring-related dependencies
mvn dependency:tree | grep spring

# Check for Jakarta vs javax usage
grep -r "javax\." src/ | grep -E "(servlet|persistence|validation|jms)"
```

#### Version Compatibility Matrix
```xml
<!-- Current Spring 5.3 setup -->
<spring.version>5.3.23</spring.version>
<hibernate.version>5.6.15.Final</hibernate.version>
<jackson.version>2.13.4</jackson.version>

<!-- Target Spring 6 setup -->
<spring.version>6.1.0</spring.version>
<hibernate.version>6.4.0.Final</hibernate.version>
<jackson.version>2.16.0</jackson.version>
```

### Phase 2: Dependency Migration

#### Core Spring Dependencies
```xml
<properties>
    <java.version>17</java.version>
    <spring.version>6.1.0</spring.version>
    <spring.boot.version>3.2.0</spring.boot.version>
    <jakarta.servlet.version>5.0.0</jakarta.servlet.version>
    <jakarta.persistence.version>3.1.0</jakarta.persistence.version>
    <jakarta.validation.version>3.0.2</jakarta.validation.version>
</properties>

<dependencies>
    <!-- Core Spring Framework -->
    <dependency>
        <groupId>org.springframework</groupId>
        <artifactId>spring-context</artifactId>
        <version>${spring.version}</version>
    </dependency>
    
    <dependency>
        <groupId>org.springframework</groupId>
        <artifactId>spring-webmvc</artifactId>
        <version>${spring.version}</version>
    </dependency>
    
    <!-- Jakarta EE APIs -->
    <dependency>
        <groupId>jakarta.servlet</groupId>
        <artifactId>jakarta.servlet-api</artifactId>
        <version>${jakarta.servlet.version}</version>
        <scope>provided</scope>
    </dependency>
    
    <dependency>
        <groupId>jakarta.persistence</groupId>
        <artifactId>jakarta.persistence-api</artifactId>
        <version>${jakarta.persistence.version}</version>
    </dependency>
    
    <!-- Spring Data JPA with Jakarta -->
    <dependency>
        <groupId>org.springframework.data</groupId>
        <artifactId>spring-data-jpa</artifactId>
        <version>3.2.0</version>
    </dependency>
    
    <!-- Hibernate 6 for Jakarta -->
    <dependency>
        <groupId>org.hibernate.orm</groupId>
        <artifactId>hibernate-core</artifactId>
        <version>6.4.0.Final</version>
    </dependency>
</dependencies>
```

### Phase 3: Code Migration

#### 1. Package Import Updates

**Before (javax):**
```java
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class User {
    @Id
    @GeneratedValue
    private Long id;
    
    @NotNull
    private String username;
}
```

**After (jakarta):**
```java
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

@Entity
public class User {
    @Id
    @GeneratedValue
    private Long id;
    
    @NotNull
    private String username;
}
```

#### 2. Configuration Class Updates

**Modern Configuration:**
```java
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.company.app")
public class WebConfig implements WebMvcConfigurer {
    
    @Bean
    public DataSource dataSource() {
        // Updated with Jakarta namespace configurations
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setJdbcUrl("jdbc:postgresql://localhost/app");
        return dataSource;
    }
}
```

#### 3. JPA Configuration Updates

**Entity Manager Configuration:**
```java
import jakarta.persistence.EntityManagerFactory;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

@Configuration
@EnableJpaRepositories(basePackages = "com.company.app.repository")
public class JpaConfig {
    
    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        em.setPackagesToScan("com.company.app.model");
        
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        
        Properties properties = new Properties();
        properties.setProperty("hibernate.hbm2ddl.auto", "validate");
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.PostgreSQLDialect");
        em.setJpaProperties(properties);
        
        return em;
    }
}
```

#### 4. Repository Layer Updates

**Spring Data JPA Repository:**
```java
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserRepository extends JpaRepository<User, Long> {
    
    @Query("SELECT u FROM User u WHERE u.username = :username")
    Optional<User> findByUsername(@Param("username") String username);
}

@Repository
public class CustomUserRepository {
    
    @PersistenceContext
    private EntityManager entityManager;
    
    public List<User> findActiveUsers() {
        return entityManager
            .createQuery("SELECT u FROM User u WHERE u.active = true", User.class)
            .getResultList();
    }
}
```

### Phase 4: Web Layer Migration

#### 1. Controller Updates

**Modern Spring MVC Controller:**
```java
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    
    @GetMapping("/{id}")
    public ResponseEntity<User> getUser(@PathVariable Long id) {
        User user = userService.findById(id);
        return ResponseEntity.ok(user);
    }
    
    @PostMapping
    public ResponseEntity<User> createUser(@Valid @RequestBody CreateUserRequest request) {
        User user = userService.create(request);
        return ResponseEntity.ok(user);
    }
}
```

#### 2. Exception Handling

**Global Exception Handler:**
```java
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.http.ResponseEntity;
import jakarta.validation.ConstraintViolationException;

@ControllerAdvice
public class GlobalExceptionHandler {
    
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleValidation(ConstraintViolationException ex) {
        ErrorResponse error = new ErrorResponse("Validation failed", ex.getMessage());
        return ResponseEntity.badRequest().body(error);
    }
}
```

### Phase 5: Testing Updates

#### Test Dependencies
```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-test</artifactId>
    <version>${spring.version}</version>
    <scope>test</scope>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-test-autoconfigure</artifactId>
    <version>${spring.boot.version}</version>
    <scope>test</scope>
</dependency>
```

#### Integration Tests
```java
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
class UserControllerTest {
    
    @Autowired
    private MockMvc mockMvc;
    
    @Test
    void shouldReturnUser() throws Exception {
        mockMvc.perform(get("/api/users/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(1));
    }
}
```

## Configuration Migration

### applicationContext.xml Updates

**Before (Spring 5 + javax):**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:jpa="http://www.springframework.org/schema/data/jpa">
    
    <context:component-scan base-package="com.company.app"/>
    <jpa:repositories base-package="com.company.app.repository"/>
</beans>
```

**After (Spring 6 + jakarta):**
```java
@Configuration
@EnableJpaRepositories(basePackages = "com.company.app.repository")
@ComponentScan(basePackages = "com.company.app")
public class ApplicationConfig {
    
    @Bean
    public DataSource dataSource() {
        return new HikariDataSource();
    }
}
```

### Properties Configuration

**application.properties Updates:**
```properties
# Database configuration with Jakarta
spring.datasource.url=jdbc:postgresql://localhost:5432/app_db
spring.datasource.driver-class-name=org.postgresql.Driver

# JPA/Hibernate configuration
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.show-sql=false

# Logging configuration
logging.level.org.springframework=INFO
logging.level.org.hibernate.SQL=DEBUG
```

## Migration Checklist

### Pre-Migration
- [ ] Java 17+ environment verified
- [ ] Dependency compatibility assessment complete
- [ ] Current application functionality documented
- [ ] Migration test plan created

### Code Changes
- [ ] All javax.* imports updated to jakarta.*
- [ ] Spring configuration classes updated
- [ ] JPA entities and repositories migrated
- [ ] Web controllers updated
- [ ] Service layer validated
- [ ] Custom components tested

### Configuration
- [ ] Maven/Gradle dependencies updated
- [ ] Application properties migrated
- [ ] Database configuration validated
- [ ] Security configuration updated
- [ ] Logging configuration verified

### Testing
- [ ] Unit tests updated and passing
- [ ] Integration tests validated
- [ ] End-to-end tests successful
- [ ] Performance benchmarks established

## Common Migration Issues

### Issue 1: Hibernate 6 Changes
```java
// Old Hibernate 5 approach
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
}

// Updated for Hibernate 6
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // Hibernate 6 may require explicit column definitions
    @Column(name = "username", nullable = false)
    private String username;
}
```

### Issue 2: Spring Boot Auto-Configuration
```java
// Ensure proper Spring Boot 3.x configuration
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
```

### Issue 3: Bean Definition Changes
```java
// Some bean definition patterns need updates
@Configuration
public class ServiceConfig {
    
    @Bean
    @Primary
    public UserService userService() {
        return new UserServiceImpl();
    }
}
```

## Performance Considerations

### Memory Usage
- Monitor heap usage with new Spring 6 features
- Validate garbage collection patterns
- Test application startup time

### Database Performance
- Validate Hibernate 6 query generation
- Monitor connection pool behavior
- Test transaction management

## Security Updates

### Spring Security Integration
```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/public/**").permitAll()
                .anyRequest().authenticated()
            );
        return http.build();
    }
}
```

## Observability Enhancements

### Micrometer Integration
```java
@Configuration
public class MetricsConfig {
    
    @Bean
    public MeterRegistry meterRegistry() {
        return new SimpleMeterRegistry();
    }
}
```

## Next Steps

1. Complete Spring 6 environment setup
2. Execute systematic code migration
3. Update all configuration files
4. Conduct thorough testing
5. Performance validation
6. Production deployment planning

---

**References:**
- [Spring Framework 6.0 Migration Guide](https://github.com/spring-projects/spring-framework/wiki/Upgrading-to-Spring-Framework-6.x)
- [Jakarta EE Migration Guide](https://jakarta.ee/resources/JakartaEE-8-to-9-Migration-Guide.pdf)
- [Spring Boot 3.0 Migration Guide](https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-3.0-Migration-Guide)

**Last Updated**: 2025-08-26
**Version**: 1.0