# Tomcat 9 to Tomcat 10 Migration Guide

## Overview

This guide covers the migration from Apache Tomcat 9.x to Apache Tomcat 10.x, focusing on Jakarta EE namespace migration and configuration updates required for our legacy Java EE application.

## Key Changes in Tomcat 10

### Major Breaking Changes

#### 1. Jakarta EE Implementation
- **Complete Namespace Migration**: All `javax.*` packages renamed to `jakarta.*`
- **Servlet API**: Jakarta Servlet 5.0 implementation
- **JSP API**: Jakarta Pages 3.0 implementation
- **EL API**: Jakarta Expression Language 4.0
- **WebSocket**: Jakarta WebSocket 2.0

#### 2. Minimum Requirements
- **Java**: Java 11+ (Java 17+ recommended)
- **Memory**: Increased base memory requirements
- **SSL**: Enhanced TLS support requirements

#### 3. Removed Features
- **Legacy Connectors**: Some deprecated connector configurations removed
- **Old Security Realms**: Certain legacy realm implementations deprecated
- **Deprecated Valves**: Some older valve implementations removed

### Version Compatibility

| Component | Tomcat 9 | Tomcat 10 |
|-----------|----------|-----------|
| Java Version | 8+ | 11+ |
| Servlet API | 4.0 (javax) | 5.0 (jakarta) |
| JSP API | 2.3 (javax) | 3.0 (jakarta) |
| EL API | 3.0 (javax) | 4.0 (jakarta) |
| WebSocket | 1.1 (javax) | 2.0 (jakarta) |
| JSTL | 1.2 (javax) | 2.0 (jakarta) |

## Migration Strategy

### Phase 1: Environment Preparation

#### System Requirements Validation
```bash
# Verify Java version
java -version
# Should show Java 11+ (preferably Java 17+)

# Check current Tomcat installation
./catalina.sh version

# Verify memory availability
free -m
# Tomcat 10 may require additional memory
```

#### Download and Setup
```bash
# Download Tomcat 10
wget https://downloads.apache.org/tomcat/tomcat-10/v10.1.15/bin/apache-tomcat-10.1.15.tar.gz

# Extract and prepare
tar -xzf apache-tomcat-10.1.15.tar.gz
mv apache-tomcat-10.1.15 /opt/tomcat10

# Set permissions
chmod +x /opt/tomcat10/bin/*.sh
```

### Phase 2: Configuration Migration

#### 1. server.xml Configuration

**Enhanced server.xml for Tomcat 10:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<Server port="8005" shutdown="SHUTDOWN">
  <Listener className="org.apache.catalina.startup.VersionLoggerListener" />
  <Listener className="org.apache.catalina.core.AprLifecycleListener" SSLEngine="on" />
  <Listener className="org.apache.catalina.core.JreMemoryLeakPreventionListener" />
  <Listener className="org.apache.catalina.mbeans.GlobalResourcesLifecycleListener" />
  <Listener className="org.apache.catalina.core.ThreadLocalLeakPreventionListener" />

  <GlobalNamingResources>
    <Resource name="UserDatabase" auth="Container"
              type="org.apache.catalina.UserDatabase"
              description="User database that can be updated and saved"
              factory="org.apache.catalina.users.MemoryUserDatabaseFactory"
              pathname="conf/tomcat-users.xml" />
  </GlobalNamingResources>

  <Service name="Catalina">
    
    <!-- HTTP Connector -->
    <Connector port="8080" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443"
               maxParameterCount="1000" />
               
    <!-- HTTPS Connector (recommended) -->
    <Connector port="8443" protocol="org.apache.coyote.http11.Http11NioProtocol"
               maxThreads="150" SSLEnabled="true"
               maxParameterCount="1000">
        <UpgradeProtocol className="org.apache.coyote.http2.Http2Protocol" />
        <SSLHostConfig>
            <Certificate certificateKeystoreFile="conf/localhost-rsa.jks"
                         type="RSA" />
        </SSLHostConfig>
    </Connector>

    <Engine name="Catalina" defaultHost="localhost">
      <Realm className="org.apache.catalina.realm.LockOutRealm">
        <Realm className="org.apache.catalina.realm.UserDatabaseRealm"
               resourceName="UserDatabase"/>
      </Realm>

      <Host name="localhost" appBase="webapps"
            unpackWARs="true" autoDeploy="true">
        
        <!-- Access Log Valve -->
        <Valve className="org.apache.catalina.valves.AccessLogValve" 
               directory="logs"
               prefix="localhost_access_log" suffix=".txt"
               pattern="%h %l %u %t &quot;%r&quot; %s %b" />
               
        <!-- Enhanced Security Headers -->
        <Valve className="org.apache.catalina.valves.HttpHeaderSecurityFilter"
               antiClickJackingEnabled="true"
               antiClickJackingOption="DENY"
               hstsEnabled="true"
               hstsMaxAgeSeconds="31536000" />
      </Host>
    </Engine>
  </Service>
</Server>
```

#### 2. context.xml Updates

**Application Context Configuration:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<Context>
    <!-- Database Connection Pool -->
    <Resource name="jdbc/AppDS" 
              auth="Container"
              type="javax.sql.DataSource"
              maxTotal="20" 
              maxIdle="10"
              maxWaitMillis="-1"
              username="app_user" 
              password="app_password"
              driverClassName="org.postgresql.Driver"
              url="jdbc:postgresql://localhost:5432/app_db"
              testOnBorrow="true"
              validationQuery="SELECT 1" />
              
    <!-- JMS Connection Factory (if using JMS) -->
    <Resource name="jms/ConnectionFactory"
              auth="Container"
              type="jakarta.jms.ConnectionFactory"
              factory="org.apache.activemq.jndi.JNDIReferenceFactory"
              brokerURL="tcp://localhost:61616" />
              
    <!-- Enhanced Security Configuration -->
    <CookieProcessor className="org.apache.tomcat.util.http.Rfc6265CookieProcessor"
                     sameSiteCookies="strict" />
</Context>
```

#### 3. web.xml Application Updates

**Jakarta EE Namespace:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee
                           https://jakarta.ee/xml/ns/jakartaee/web-app_5_0.xsd"
         version="5.0">
         
    <display-name>Legacy Application</display-name>
    
    <!-- Security Configuration -->
    <security-constraint>
        <web-resource-collection>
            <web-resource-name>Secure Content</web-resource-name>
            <url-pattern>/secure/*</url-pattern>
        </web-resource-collection>
        <auth-constraint>
            <role-name>user</role-name>
        </auth-constraint>
        <user-data-constraint>
            <transport-guarantee>CONFIDENTIAL</transport-guarantee>
        </user-data-constraint>
    </security-constraint>
    
    <login-config>
        <auth-method>FORM</auth-method>
        <form-login-config>
            <form-login-page>/login.jsp</form-login-page>
            <form-error-page>/login-error.jsp</form-error-page>
        </form-login-config>
    </login-config>
    
    <security-role>
        <role-name>user</role-name>
    </security-role>
    
</web-app>
```

### Phase 3: Application Updates

#### 1. JSP Page Updates

**JSTL and JSP Updates:**
```jsp
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Welcome, <c:out value="${user.username}"/></h1>
    
    <c:if test="${not empty user.email}">
        <p>Email: <c:out value="${user.email}"/></p>
    </c:if>
    
    <fmt:formatDate value="${user.lastLogin}" pattern="yyyy-MM-dd HH:mm:ss"/>
</body>
</html>
```

#### 2. Servlet Updates

**Jakarta Servlet Implementation:**
```java
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "UserServlet", urlPatterns = {"/user/*"})
public class UserServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
        response.setContentType("text/html;charset=UTF-8");
        
        String pathInfo = request.getPathInfo();
        if (pathInfo != null && pathInfo.equals("/profile")) {
            request.getRequestDispatcher("/WEB-INF/jsp/profile.jsp")
                   .forward(request, response);
        }
    }
}
```

#### 3. Filter Updates

**Jakarta Filter Implementation:**
```java
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebFilter(filterName = "SecurityFilter", urlPatterns = {"/*"})
public class SecurityFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization logic
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, 
                        FilterChain chain) throws IOException, ServletException {
                        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // Add security headers
        httpResponse.setHeader("X-Content-Type-Options", "nosniff");
        httpResponse.setHeader("X-Frame-Options", "DENY");
        httpResponse.setHeader("X-XSS-Protection", "1; mode=block");
        
        chain.doFilter(request, response);
    }
    
    @Override
    public void destroy() {
        // Cleanup logic
    }
}
```

### Phase 4: Database Integration

#### JNDI DataSource Configuration

**Tomcat 10 JNDI Setup:**
```xml
<!-- In context.xml or server.xml -->
<Resource name="jdbc/AppDatabase"
          auth="Container"
          type="javax.sql.DataSource"
          maxTotal="100"
          maxIdle="30"
          maxWaitMillis="10000"
          username="db_user"
          password="db_password"
          driverClassName="org.postgresql.Driver"
          url="jdbc:postgresql://localhost:5432/app_db"
          testOnBorrow="true"
          testOnReturn="false"
          testWhileIdle="true"
          validationQuery="SELECT 1"
          validationQueryTimeout="30"
          timeBetweenEvictionRunsMillis="30000"
          minEvictableIdleTimeMillis="60000" />
```

**Application Usage:**
```java
import jakarta.annotation.Resource;
import jakarta.servlet.ServletException;
import javax.sql.DataSource;

@WebServlet("/data")
public class DataServlet extends HttpServlet {
    
    @Resource(lookup = "java:comp/env/jdbc/AppDatabase")
    private DataSource dataSource;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            
        try (Connection conn = dataSource.getConnection()) {
            // Database operations
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
}
```

### Phase 5: Performance Optimization

#### Memory Configuration

**setenv.sh Configuration:**
```bash
#!/bin/bash
export JAVA_OPTS="-Xms2048m -Xmx4096m -XX:MetaspaceSize=256m -XX:MaxMetaspaceSize=512m"
export JAVA_OPTS="$JAVA_OPTS -XX:+UseG1GC -XX:G1HeapRegionSize=16m"
export JAVA_OPTS="$JAVA_OPTS -XX:+UseStringDeduplication"
export JAVA_OPTS="$JAVA_OPTS -Djava.awt.headless=true"
export JAVA_OPTS="$JAVA_OPTS -Dfile.encoding=UTF-8"

# JMX Configuration (optional)
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote"
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote.port=9999"
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote.ssl=false"
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote.authenticate=false"
```

#### Connector Tuning

**Optimized Connector Configuration:**
```xml
<Connector port="8080" 
           protocol="HTTP/1.1"
           maxThreads="200"
           minSpareThreads="25"
           maxSpareThreads="75"
           acceptCount="100"
           connectionTimeout="20000"
           keepAliveTimeout="15000"
           maxKeepAliveRequests="100"
           compression="on"
           compressibleMimeType="text/html,text/xml,text/plain,text/css,text/javascript,application/javascript,application/json"
           compressionMinSize="2048" />
```

## Migration Checklist

### Pre-Migration
- [ ] Java 11+ environment verified
- [ ] Current Tomcat 9 configuration documented
- [ ] Application dependencies identified
- [ ] Performance baseline established

### Environment Setup
- [ ] Tomcat 10 downloaded and installed
- [ ] Directory structure configured
- [ ] File permissions set correctly
- [ ] SSL certificates migrated (if applicable)

### Configuration Migration
- [ ] server.xml updated for Tomcat 10
- [ ] context.xml migrated
- [ ] web.xml namespace updated
- [ ] JNDI resources configured
- [ ] Security realms updated

### Application Updates
- [ ] JSP pages namespace updated
- [ ] Servlet classes migrated to Jakarta
- [ ] Filter implementations updated
- [ ] Listener classes verified

### Testing & Validation
- [ ] Application deploys successfully
- [ ] All functionality verified
- [ ] Performance testing completed
- [ ] Security testing validated
- [ ] Load testing performed

## Common Migration Issues

### Issue 1: ClassLoader Problems
```bash
# Clear work directory
rm -rf $CATALINA_HOME/work/Catalina/localhost/app

# Check for conflicting JARs
# Ensure no javax.servlet-api JARs in WEB-INF/lib
```

### Issue 2: JNDI Lookup Issues
```java
// Updated JNDI lookup pattern
Context initContext = new InitialContext();
Context envContext = (Context) initContext.lookup("java:comp/env");
DataSource ds = (DataSource) envContext.lookup("jdbc/AppDatabase");
```

### Issue 3: JSP Compilation Errors
```xml
<!-- Update JSP compiler configuration in web.xml -->
<servlet>
    <servlet-name>jsp</servlet-name>
    <servlet-class>org.apache.jasper.servlet.JspServlet</servlet-class>
    <init-param>
        <param-name>compilerTargetVM</param-name>
        <param-value>11</param-value>
    </init-param>
    <init-param>
        <param-name>compilerSourceVM</param-name>
        <param-value>11</param-value>
    </init-param>
</servlet>
```

## Security Enhancements

### Enhanced Security Configuration
```xml
<!-- Security Headers Valve -->
<Valve className="org.apache.catalina.valves.HttpHeaderSecurityFilter"
       antiClickJackingEnabled="true"
       antiClickJackingOption="SAMEORIGIN"
       hstsEnabled="true"
       hstsMaxAgeSeconds="31536000"
       hstsIncludeSubdomains="true" />

<!-- Remote IP Valve for Load Balancer -->
<Valve className="org.apache.catalina.valves.RemoteIpValve"
       remoteIpHeader="X-Forwarded-For"
       protocolHeader="X-Forwarded-Proto" />
```

## Monitoring & Logging

### Enhanced Logging Configuration

**logging.properties:**
```properties
# Root logger configuration
.handlers = 1catalina.org.apache.juli.AsyncFileHandler, java.util.logging.ConsoleHandler

# Handler configurations
1catalina.org.apache.juli.AsyncFileHandler.level = FINE
1catalina.org.apache.juli.AsyncFileHandler.directory = ${catalina.base}/logs
1catalina.org.apache.juli.AsyncFileHandler.prefix = catalina.
1catalina.org.apache.juli.AsyncFileHandler.maxDays = 90

# Application-specific logging
com.company.app.level = INFO
com.company.app.handlers = 2localhost.org.apache.juli.AsyncFileHandler
```

### JMX Monitoring
```bash
# Enable JMX monitoring
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote"
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote.port=9999"
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote.ssl=false"
export JAVA_OPTS="$JAVA_OPTS -Dcom.sun.management.jmxremote.authenticate=false"
```

## Performance Testing

### Load Testing Script
```bash
#!/bin/bash
# Basic load testing with Apache Bench
ab -n 1000 -c 10 http://localhost:8080/app/

# Memory usage monitoring
jstat -gc -t $(pgrep java) 5s

# Thread monitoring
jstack $(pgrep java) > thread_dump.txt
```

## Deployment Strategy

### Blue-Green Deployment
1. **Prepare Tomcat 10 Environment** (Green)
2. **Deploy Application to Green Environment**
3. **Validate Green Environment**
4. **Switch Load Balancer to Green**
5. **Monitor and Validate**
6. **Keep Blue Environment as Rollback**

### Rollback Plan
```bash
#!/bin/bash
# Quick rollback script
TOMCAT9_HOME="/opt/tomcat9"
TOMCAT10_HOME="/opt/tomcat10"

# Stop Tomcat 10
$TOMCAT10_HOME/bin/shutdown.sh

# Start Tomcat 9
$TOMCAT9_HOME/bin/startup.sh

# Update load balancer configuration
# (Implementation specific)
```

## Next Steps

1. Set up Tomcat 10 development environment
2. Migrate application configuration files
3. Update all JSP and Servlet code
4. Conduct comprehensive testing
5. Execute performance validation
6. Plan production deployment

---

**References:**
- [Tomcat 10 Migration Guide](https://tomcat.apache.org/migration-10.html)
- [Jakarta EE 9 Specification](https://jakarta.ee/specifications/platform/9/)
- [Tomcat 10 Configuration Reference](https://tomcat.apache.org/tomcat-10.0-doc/config/)

**Last Updated**: 2025-08-26
**Version**: 1.0