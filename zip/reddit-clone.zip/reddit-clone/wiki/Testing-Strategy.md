# Testing Strategy

## Overview

This document outlines the comprehensive testing strategy for the legacy Java EE application upgrade from Struts 2.5.33/Spring 5.3/Tomcat 9 to Struts 7/Spring 6/Tomcat 10. The strategy ensures zero functionality regression, maintains performance standards, and validates security requirements throughout the migration process.

## Testing Approach & Philosophy

### Core Testing Principles

#### 1. Comprehensive Coverage
- **Functional Testing**: 100% critical path coverage
- **Non-Functional Testing**: Performance, security, usability
- **Regression Testing**: Automated validation of existing functionality
- **Integration Testing**: End-to-end system validation

#### 2. Risk-Based Testing
- **Critical Business Functions**: Maximum test coverage
- **High-Risk Areas**: Enhanced validation scenarios
- **New Components**: Comprehensive unit and integration testing
- **Legacy Compatibility**: Backward compatibility validation

#### 3. Continuous Validation
- **Shift-Left Testing**: Early testing in development cycle
- **Automated Pipeline**: CI/CD integrated test execution
- **Continuous Monitoring**: Real-time validation in production
- **Feedback Loops**: Rapid issue identification and resolution

## Test Strategy Framework

### Testing Pyramid Structure

```
                    ┌─────────────────────┐
                    │   Manual Testing    │ ← 5%
                    │  (Exploratory, UAT) │
                    └─────────────────────┘
                  ┌───────────────────────────┐
                  │    Integration Tests      │ ← 15%
                  │ (API, Database, E2E)      │
                  └───────────────────────────┘
              ┌─────────────────────────────────────┐
              │           Unit Tests                │ ← 80%
              │  (Service Layer, Utilities, etc.)   │
              └─────────────────────────────────────┘
```

### Test Categories & Coverage Targets

| Test Category | Coverage Target | Automation Level | Risk Level |
|---------------|-----------------|------------------|------------|
| Unit Tests | 90%+ | 100% Automated | Low |
| Integration Tests | 80%+ | 95% Automated | Medium |
| System Tests | 70%+ | 85% Automated | High |
| Performance Tests | Key Scenarios | 100% Automated | High |
| Security Tests | Critical Paths | 90% Automated | Critical |
| User Acceptance | Core Workflows | 20% Automated | Medium |

## Unit Testing Strategy

### Framework & Tools Configuration

#### Test Framework Setup
```xml
<dependencies>
    <!-- JUnit 5 -->
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.9.2</version>
        <scope>test</scope>
    </dependency>
    
    <!-- Mockito for mocking -->
    <dependency>
        <groupId>org.mockito</groupId>
        <artifactId>mockito-core</artifactId>
        <version>4.11.0</version>
        <scope>test</scope>
    </dependency>
    
    <!-- AssertJ for fluent assertions -->
    <dependency>
        <groupId>org.assertj</groupId>
        <artifactId>assertj-core</artifactId>
        <version>3.24.2</version>
        <scope>test</scope>
    </dependency>
    
    <!-- Spring Test -->
    <dependency>
        <groupId>org.springframework</groupId>
        <artifactId>spring-test</artifactId>
        <version>6.1.0</version>
        <scope>test</scope>
    </dependency>
    
    <!-- Testcontainers for database testing -->
    <dependency>
        <groupId>org.testcontainers</groupId>
        <artifactId>postgresql</artifactId>
        <version>1.19.3</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

#### Unit Test Template
```java
@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    
    @Mock
    private UserRepository userRepository;
    
    @Mock
    private PasswordEncoder passwordEncoder;
    
    @Mock
    private EmailService emailService;
    
    @InjectMocks
    private UserServiceImpl userService;
    
    @Nested
    @DisplayName("User Creation Tests")
    class UserCreationTests {
        
        @Test
        @DisplayName("Should create user successfully with valid data")
        void shouldCreateUserSuccessfully() {
            // Given
            CreateUserRequest request = CreateUserRequest.builder()
                .username("newuser")
                .email("user@example.com")
                .password("SecurePassword123!")
                .build();
                
            User expectedUser = User.builder()
                .id(1L)
                .username("newuser")
                .email("user@example.com")
                .active(true)
                .build();
                
            when(userRepository.existsByUsername("newuser")).thenReturn(false);
            when(userRepository.existsByEmail("user@example.com")).thenReturn(false);
            when(passwordEncoder.encode("SecurePassword123!")).thenReturn("encoded-password");
            when(userRepository.save(any(User.class))).thenReturn(expectedUser);
            
            // When
            User result = userService.createUser(request);
            
            // Then
            assertThat(result).isNotNull();
            assertThat(result.getUsername()).isEqualTo("newuser");
            assertThat(result.getEmail()).isEqualTo("user@example.com");
            assertThat(result.isActive()).isTrue();
            
            verify(userRepository).existsByUsername("newuser");
            verify(userRepository).existsByEmail("user@example.com");
            verify(passwordEncoder).encode("SecurePassword123!");
            verify(userRepository).save(any(User.class));
            verify(emailService).sendWelcomeEmail(expectedUser);
        }
        
        @Test
        @DisplayName("Should throw exception when username already exists")
        void shouldThrowExceptionWhenUsernameExists() {
            // Given
            CreateUserRequest request = CreateUserRequest.builder()
                .username("existinguser")
                .email("user@example.com")
                .password("password")
                .build();
                
            when(userRepository.existsByUsername("existinguser")).thenReturn(true);
            
            // When & Then
            assertThatThrownBy(() -> userService.createUser(request))
                .isInstanceOf(UserAlreadyExistsException.class)
                .hasMessage("User already exists with username: existinguser");
                
            verify(userRepository).existsByUsername("existinguser");
            verifyNoMoreInteractions(userRepository, passwordEncoder, emailService);
        }
        
        @Test
        @DisplayName("Should validate email format")
        void shouldValidateEmailFormat() {
            // Given
            CreateUserRequest request = CreateUserRequest.builder()
                .username("testuser")
                .email("invalid-email")
                .password("password")
                .build();
                
            // When & Then
            assertThatThrownBy(() -> userService.createUser(request))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("Invalid email format");
        }
    }
    
    @Nested
    @DisplayName("User Retrieval Tests")
    class UserRetrievalTests {
        
        @Test
        @DisplayName("Should find user by ID")
        void shouldFindUserById() {
            // Given
            Long userId = 1L;
            User expectedUser = User.builder()
                .id(userId)
                .username("testuser")
                .email("test@example.com")
                .build();
                
            when(userRepository.findById(userId)).thenReturn(Optional.of(expectedUser));
            
            // When
            Optional<User> result = userService.findById(userId);
            
            // Then
            assertThat(result).isPresent();
            assertThat(result.get().getUsername()).isEqualTo("testuser");
            
            verify(userRepository).findById(userId);
        }
        
        @Test
        @DisplayName("Should return empty when user not found")
        void shouldReturnEmptyWhenUserNotFound() {
            // Given
            Long userId = 999L;
            when(userRepository.findById(userId)).thenReturn(Optional.empty());
            
            // When
            Optional<User> result = userService.findById(userId);
            
            // Then
            assertThat(result).isEmpty();
            
            verify(userRepository).findById(userId);
        }
    }
}
```

### Test Data Management

#### Test Data Builder Pattern
```java
public class UserTestDataBuilder {
    
    private Long id = 1L;
    private String username = "testuser";
    private String email = "test@example.com";
    private String password = "password123";
    private boolean active = true;
    private LocalDateTime createdAt = LocalDateTime.now();
    
    public static UserTestDataBuilder aUser() {
        return new UserTestDataBuilder();
    }
    
    public UserTestDataBuilder withId(Long id) {
        this.id = id;
        return this;
    }
    
    public UserTestDataBuilder withUsername(String username) {
        this.username = username;
        return this;
    }
    
    public UserTestDataBuilder withEmail(String email) {
        this.email = email;
        return this;
    }
    
    public UserTestDataBuilder inactive() {
        this.active = false;
        return this;
    }
    
    public User build() {
        return User.builder()
            .id(id)
            .username(username)
            .email(email)
            .password(password)
            .active(active)
            .createdAt(createdAt)
            .build();
    }
    
    public CreateUserRequest buildRequest() {
        return CreateUserRequest.builder()
            .username(username)
            .email(email)
            .password(password)
            .build();
    }
}

// Usage in tests
User testUser = UserTestDataBuilder.aUser()
    .withUsername("specificuser")
    .withEmail("specific@example.com")
    .inactive()
    .build();
```

## Integration Testing Strategy

### Database Integration Tests

#### Testcontainers Setup
```java
@SpringBootTest
@Testcontainers
@Transactional
class UserRepositoryIntegrationTest {
    
    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:13")
            .withDatabaseName("testdb")
            .withUsername("test")
            .withPassword("test");
            
    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private TestEntityManager entityManager;
    
    @Test
    void shouldSaveAndRetrieveUser() {
        // Given
        User user = User.builder()
            .username("integrationuser")
            .email("integration@example.com")
            .password("encoded-password")
            .active(true)
            .createdAt(LocalDateTime.now())
            .build();
            
        // When
        User savedUser = userRepository.save(user);
        entityManager.flush();
        entityManager.clear();
        
        // Then
        Optional<User> retrievedUser = userRepository.findById(savedUser.getId());
        assertThat(retrievedUser).isPresent();
        assertThat(retrievedUser.get().getUsername()).isEqualTo("integrationuser");
        assertThat(retrievedUser.get().getEmail()).isEqualTo("integration@example.com");
    }
    
    @Test
    void shouldFindUsersByActiveStatus() {
        // Given
        User activeUser = UserTestDataBuilder.aUser()
            .withUsername("active")
            .build();
        User inactiveUser = UserTestDataBuilder.aUser()
            .withUsername("inactive")
            .inactive()
            .build();
            
        entityManager.persistAndFlush(activeUser);
        entityManager.persistAndFlush(inactiveUser);
        entityManager.clear();
        
        // When
        List<User> activeUsers = userRepository.findByActiveTrue();
        
        // Then
        assertThat(activeUsers).hasSize(1);
        assertThat(activeUsers.get(0).getUsername()).isEqualTo("active");
    }
}
```

### Web Layer Integration Tests

#### REST API Testing
```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestPropertySource(locations = "classpath:application-integration.properties")
class UserControllerIntegrationTest {
    
    @Autowired
    private TestRestTemplate restTemplate;
    
    @Autowired
    private UserRepository userRepository;
    
    @Test
    void shouldCreateUserViaRestApi() {
        // Given
        CreateUserRequest request = CreateUserRequest.builder()
            .username("apiuser")
            .email("api@example.com")
            .password("ApiPassword123!")
            .build();
            
        // When
        ResponseEntity<User> response = restTemplate.postForEntity(
            "/api/users", request, User.class);
            
        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getUsername()).isEqualTo("apiuser");
        assertThat(response.getBody().getEmail()).isEqualTo("api@example.com");
        
        // Verify persistence
        Optional<User> persistedUser = userRepository.findByUsername("apiuser");
        assertThat(persistedUser).isPresent();
    }
    
    @Test
    void shouldReturnValidationErrorForInvalidData() {
        // Given
        CreateUserRequest invalidRequest = CreateUserRequest.builder()
            .username("") // Invalid: empty username
            .email("invalid-email") // Invalid: malformed email
            .password("123") // Invalid: too short
            .build();
            
        // When
        ResponseEntity<ErrorResponse> response = restTemplate.postForEntity(
            "/api/users", invalidRequest, ErrorResponse.class);
            
        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody().getErrorCode()).isEqualTo("VALIDATION_ERROR");
        assertThat(response.getBody().getMessage()).contains("Username cannot be empty");
    }
}
```

### Struts Action Integration Tests

#### Action Testing Framework
```java
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TestApplicationConfig.class)
class UserProfileActionIntegrationTest {
    
    @Autowired
    private UserService userService;
    
    private UserProfileAction action;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;
    private Map<String, Object> session;
    
    @BeforeEach
    void setUp() {
        action = new UserProfileAction();
        action.setUserService(userService);
        
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        session = new HashMap<>();
        
        ServletActionContext.setRequest(request);
        ServletActionContext.setResponse(response);
        action.setSession(session);
    }
    
    @Test
    void shouldDisplayUserProfile() {
        // Given
        User testUser = UserTestDataBuilder.aUser()
            .withUsername("profileuser")
            .build();
        User savedUser = userService.createUser(testUser.toCreateRequest());
        session.put("userId", savedUser.getId());
        
        // When
        String result = action.viewProfile();
        
        // Then
        assertThat(result).isEqualTo(ActionSupport.SUCCESS);
        assertThat(action.getUser()).isNotNull();
        assertThat(action.getUser().getUsername()).isEqualTo("profileuser");
    }
    
    @Test
    void shouldUpdateUserProfile() {
        // Given
        User testUser = UserTestDataBuilder.aUser().build();
        User savedUser = userService.createUser(testUser.toCreateRequest());
        session.put("userId", savedUser.getId());
        
        // Update user data
        savedUser.setEmail("updated@example.com");
        action.setUser(savedUser);
        
        // When
        String result = action.editProfile();
        
        // Then
        assertThat(result).isEqualTo(ActionSupport.SUCCESS);
        assertThat(action.getActionMessages()).containsExactly("Profile updated successfully");
        
        // Verify update
        User updatedUser = userService.findById(savedUser.getId()).orElseThrow();
        assertThat(updatedUser.getEmail()).isEqualTo("updated@example.com");
    }
}
```

## System & End-to-End Testing

### Selenium-based UI Testing

#### E2E Test Framework Setup
```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@TestMethodOrder(OrderAnnotation.class)
class UserWorkflowE2ETest {
    
    private static WebDriver driver;
    private static WebDriverWait wait;
    
    @BeforeAll
    static void setupDriver() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    @AfterAll
    static void tearDownDriver() {
        if (driver != null) {
            driver.quit();
        }
    }
    
    @Test
    @Order(1)
    void shouldRegisterNewUser() {
        // Navigate to registration page
        driver.get("http://localhost:8080/register");
        
        // Verify page loaded
        wait.until(ExpectedConditions.titleContains("Register"));
        
        // Fill registration form
        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement emailField = driver.findElement(By.id("email"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement confirmPasswordField = driver.findElement(By.id("confirmPassword"));
        
        usernameField.sendKeys("e2euser");
        emailField.sendKeys("e2e@example.com");
        passwordField.sendKeys("E2ePassword123!");
        confirmPasswordField.sendKeys("E2ePassword123!");
        
        // Submit form
        WebElement submitButton = driver.findElement(By.id("registerButton"));
        submitButton.click();
        
        // Verify successful registration
        wait.until(ExpectedConditions.urlContains("/dashboard"));
        assertThat(driver.getCurrentUrl()).contains("/dashboard");
        
        WebElement welcomeMessage = wait.until(
            ExpectedConditions.presenceOfElementLocated(By.id("welcomeMessage"))
        );
        assertThat(welcomeMessage.getText()).contains("Welcome, e2euser");
    }
    
    @Test
    @Order(2)
    void shouldNavigateToProfilePage() {
        // Click on profile link
        WebElement profileLink = driver.findElement(By.id("profileLink"));
        profileLink.click();
        
        // Verify profile page loaded
        wait.until(ExpectedConditions.urlContains("/profile"));
        
        WebElement usernameDisplay = driver.findElement(By.id("displayUsername"));
        assertThat(usernameDisplay.getText()).isEqualTo("e2euser");
    }
    
    @Test
    @Order(3)
    void shouldUpdateUserProfile() {
        // Navigate to edit profile
        driver.get("http://localhost:8080/profile/edit");
        
        // Update email
        WebElement emailField = wait.until(
            ExpectedConditions.presenceOfElementLocated(By.id("email"))
        );
        emailField.clear();
        emailField.sendKeys("updated-e2e@example.com");
        
        // Submit changes
        WebElement saveButton = driver.findElement(By.id("saveButton"));
        saveButton.click();
        
        // Verify success message
        WebElement successMessage = wait.until(
            ExpectedConditions.presenceOfElementLocated(By.id("successMessage"))
        );
        assertThat(successMessage.getText()).contains("Profile updated successfully");
    }
}
```

### API Contract Testing

#### Contract Testing with Pact
```java
@ExtendWith(PactConsumerTestExt.class)
@PactTestFor(providerName = "user-service")
class UserServiceContractTest {
    
    @Pact(consumer = "web-application")
    public RequestResponsePact createUserPact(PactDslWithProvider builder) {
        return builder
            .given("user service is available")
            .uponReceiving("a request to create a new user")
            .path("/api/users")
            .method("POST")
            .body(new PactDslJsonBody()
                .stringType("username", "contractuser")
                .stringType("email", "contract@example.com")
                .stringType("password", "ContractPassword123!")
            )
            .willRespondWith()
            .status(201)
            .headers(Map.of("Content-Type", "application/json"))
            .body(new PactDslJsonBody()
                .numberType("id", 1)
                .stringType("username", "contractuser")
                .stringType("email", "contract@example.com")
                .booleanType("active", true)
            )
            .toPact();
    }
    
    @Test
    @PactTestFor(pactMethod = "createUserPact")
    void shouldCreateUserAccordingToContract(MockServer mockServer) {
        // Given
        RestTemplate restTemplate = new RestTemplate();
        CreateUserRequest request = CreateUserRequest.builder()
            .username("contractuser")
            .email("contract@example.com")
            .password("ContractPassword123!")
            .build();
            
        // When
        ResponseEntity<User> response = restTemplate.postForEntity(
            mockServer.getUrl() + "/api/users", request, User.class);
            
        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        assertThat(response.getBody().getUsername()).isEqualTo("contractuser");
        assertThat(response.getBody().getEmail()).isEqualTo("contract@example.com");
    }
}
```

## Security Testing Strategy

### Authentication & Authorization Testing

#### Security Test Framework
```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class SecurityIntegrationTest {
    
    @Autowired
    private TestRestTemplate restTemplate;
    
    @Autowired
    private UserRepository userRepository;
    
    @Test
    void shouldRequireAuthenticationForProtectedEndpoints() {
        // When - accessing protected endpoint without authentication
        ResponseEntity<String> response = restTemplate.getForEntity(
            "/api/users/profile", String.class);
            
        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }
    
    @Test
    void shouldAllowAccessWithValidAuthentication() {
        // Given - create and authenticate user
        CreateUserRequest request = CreateUserRequest.builder()
            .username("authuser")
            .email("auth@example.com")
            .password("AuthPassword123!")
            .build();
            
        restTemplate.postForEntity("/api/users/register", request, User.class);
        
        // Login to get authentication
        LoginRequest loginRequest = new LoginRequest("authuser", "AuthPassword123!");
        ResponseEntity<AuthResponse> loginResponse = restTemplate.postForEntity(
            "/api/auth/login", loginRequest, AuthResponse.class);
            
        String token = loginResponse.getBody().getToken();
        
        // When - accessing protected endpoint with valid token
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        
        ResponseEntity<User> response = restTemplate.exchange(
            "/api/users/profile", HttpMethod.GET, entity, User.class);
            
        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getUsername()).isEqualTo("authuser");
    }
    
    @Test
    void shouldPreventAccessToOtherUsersData() {
        // Given - two users
        CreateUserRequest user1Request = CreateUserRequest.builder()
            .username("user1")
            .email("user1@example.com")
            .password("Password123!")
            .build();
            
        CreateUserRequest user2Request = CreateUserRequest.builder()
            .username("user2")
            .email("user2@example.com")
            .password("Password123!")
            .build();
            
        ResponseEntity<User> user1Response = restTemplate.postForEntity(
            "/api/users/register", user1Request, User.class);
        ResponseEntity<User> user2Response = restTemplate.postForEntity(
            "/api/users/register", user2Request, User.class);
            
        // Login as user1
        LoginRequest loginRequest = new LoginRequest("user1", "Password123!");
        ResponseEntity<AuthResponse> loginResponse = restTemplate.postForEntity(
            "/api/auth/login", loginRequest, AuthResponse.class);
            
        String user1Token = loginResponse.getBody().getToken();
        Long user2Id = user2Response.getBody().getId();
        
        // When - user1 tries to access user2's data
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(user1Token);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        
        ResponseEntity<String> response = restTemplate.exchange(
            "/api/users/" + user2Id, HttpMethod.GET, entity, String.class);
            
        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
    }
}
```

### Input Validation & XSS Testing

#### Security Validation Tests
```java
@SpringBootTest
class InputValidationSecurityTest {
    
    @Autowired
    private UserService userService;
    
    @ParameterizedTest
    @ValueSource(strings = {
        "<script>alert('xss')</script>",
        "javascript:alert('xss')",
        "<img src=x onerror=alert('xss')>",
        "';DROP TABLE users;--"
    })
    void shouldRejectMaliciousUsernameInput(String maliciousInput) {
        // Given
        CreateUserRequest request = CreateUserRequest.builder()
            .username(maliciousInput)
            .email("test@example.com")
            .password("ValidPassword123!")
            .build();
            
        // When & Then
        assertThatThrownBy(() -> userService.createUser(request))
            .isInstanceOf(ValidationException.class)
            .hasMessageContaining("Invalid characters in username");
    }
    
    @Test
    void shouldSanitizeHtmlContent() {
        // Given
        String unsafeHtml = "<script>alert('xss')</script><p>Safe content</p>";
        
        // When
        String sanitizedHtml = inputSanitizer.sanitizeHtml(unsafeHtml);
        
        // Then
        assertThat(sanitizedHtml).doesNotContain("<script>");
        assertThat(sanitizedHtml).contains("<p>Safe content</p>");
    }
}
```

## Test Data Management

### Test Database Strategy

#### Database Test Configuration
```properties
# application-test.properties
spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
spring.datasource.driver-class-name=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=

spring.jpa.hibernate.ddl-auto=create-drop
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true

logging.level.org.springframework.web=DEBUG
logging.level.org.hibernate.SQL=DEBUG
logging.level.org.hibernate.type.descriptor.sql.BasicBinder=TRACE
```

#### Test Data Setup
```java
@TestConfiguration
public class TestDataConfiguration {
    
    @Bean
    @Primary
    public TestDataService testDataService() {
        return new TestDataService();
    }
}

@Service
public class TestDataService {
    
    public void setupTestData() {
        // Create test users
        createTestUser("admin", "admin@example.com", "ADMIN");
        createTestUser("user1", "user1@example.com", "USER");
        createTestUser("user2", "user2@example.com", "USER");
        
        // Create test data relationships
        setupTestProfiles();
        setupTestPreferences();
    }
    
    public void cleanupTestData() {
        // Clean up test data after tests
        userRepository.deleteAll();
        profileRepository.deleteAll();
    }
    
    private User createTestUser(String username, String email, String role) {
        User user = User.builder()
            .username(username)
            .email(email)
            .password(passwordEncoder.encode("TestPassword123!"))
            .active(true)
            .createdAt(LocalDateTime.now())
            .build();
            
        return userRepository.save(user);
    }
}
```

## Test Automation & CI/CD Integration

### Maven Test Configuration

#### Maven Surefire Plugin
```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-surefire-plugin</artifactId>
    <version>3.0.0-M9</version>
    <configuration>
        <includes>
            <include>**/*Test.java</include>
            <include>**/*Tests.java</include>
        </includes>
        <excludes>
            <exclude>**/*IntegrationTest.java</exclude>
            <exclude>**/*E2ETest.java</exclude>
        </excludes>
        <systemPropertyVariables>
            <spring.profiles.active>test</spring.profiles.active>
        </systemPropertyVariables>
    </configuration>
</plugin>

<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-failsafe-plugin</artifactId>
    <version>3.0.0-M9</version>
    <configuration>
        <includes>
            <include>**/*IntegrationTest.java</include>
            <include>**/*E2ETest.java</include>
        </includes>
        <systemPropertyVariables>
            <spring.profiles.active>integration-test</spring.profiles.active>
        </systemPropertyVariables>
    </configuration>
    <executions>
        <execution>
            <goals>
                <goal>integration-test</goal>
                <goal>verify</goal>
            </goals>
        </execution>
    </executions>
</plugin>
```

### CI/CD Pipeline Test Integration

#### GitHub Actions Test Workflow
```yaml
name: Test Pipeline

on:
  push:
    branches: [ main, develop, migration/* ]
  pull_request:
    branches: [ main, develop ]

jobs:
  unit-tests:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Java 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
        
    - name: Cache Maven dependencies
      uses: actions/cache@v3
      with:
        path: ~/.m2
        key: ${{ runner.os }}-m2-${{ hashFiles('**/pom.xml') }}
        
    - name: Run unit tests
      run: mvn clean test
      
    - name: Generate test report
      uses: dorny/test-reporter@v1
      if: success() || failure()
      with:
        name: Unit Test Results
        path: target/surefire-reports/*.xml
        reporter: java-junit

  integration-tests:
    runs-on: ubuntu-latest
    needs: unit-tests
    
    services:
      postgres:
        image: postgres:13
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: testdb
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432
          
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Java 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
        
    - name: Run integration tests
      run: mvn clean verify -Pintegration-test
      env:
        SPRING_DATASOURCE_URL: jdbc:postgresql://localhost:5432/testdb
        SPRING_DATASOURCE_USERNAME: postgres
        SPRING_DATASOURCE_PASSWORD: postgres

  e2e-tests:
    runs-on: ubuntu-latest
    needs: integration-tests
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Java 17
      uses: actions/setup-java@v3
      with:
        java-version: '17'
        distribution: 'temurin'
        
    - name: Start application
      run: |
        mvn clean package -DskipTests
        java -jar target/app.jar &
        sleep 30
        
    - name: Run E2E tests
      run: mvn test -Pe2e-test
      
    - name: Upload test artifacts
      uses: actions/upload-artifact@v3
      if: failure()
      with:
        name: e2e-screenshots
        path: target/screenshots/
```

## Test Reporting & Metrics

### Test Coverage Analysis

#### JaCoCo Configuration
```xml
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>0.8.8</version>
    <executions>
        <execution>
            <goals>
                <goal>prepare-agent</goal>
            </goals>
        </execution>
        <execution>
            <id>report</id>
            <phase>test</phase>
            <goals>
                <goal>report</goal>
            </goals>
        </execution>
        <execution>
            <id>check</id>
            <goals>
                <goal>check</goal>
            </goals>
            <configuration>
                <rules>
                    <rule>
                        <element>PACKAGE</element>
                        <limits>
                            <limit>
                                <counter>LINE</counter>
                                <value>COVEREDRATIO</value>
                                <minimum>0.80</minimum>
                            </limit>
                        </limits>
                    </rule>
                </rules>
            </configuration>
        </execution>
    </executions>
</plugin>
```

### Test Quality Gates

#### Quality Gate Configuration
```java
@Component
public class TestQualityGateValidator {
    
    private static final double MIN_COVERAGE_THRESHOLD = 0.80;
    private static final int MAX_FAILED_TESTS = 0;
    private static final Duration MAX_TEST_DURATION = Duration.ofMinutes(30);
    
    public void validateQualityGates(TestResults results) {
        validateCoverage(results.getCoverage());
        validateFailures(results.getFailedTests());
        validateDuration(results.getDuration());
    }
    
    private void validateCoverage(double coverage) {
        if (coverage < MIN_COVERAGE_THRESHOLD) {
            throw new QualityGateException(
                String.format("Code coverage %.2f%% below threshold %.2f%%", 
                    coverage * 100, MIN_COVERAGE_THRESHOLD * 100));
        }
    }
    
    private void validateFailures(int failedTests) {
        if (failedTests > MAX_FAILED_TESTS) {
            throw new QualityGateException(
                String.format("%d test(s) failed. All tests must pass.", failedTests));
        }
    }
    
    private void validateDuration(Duration duration) {
        if (duration.compareTo(MAX_TEST_DURATION) > 0) {
            throw new QualityGateException(
                String.format("Test execution took %s, exceeding maximum %s", 
                    duration, MAX_TEST_DURATION));
        }
    }
}
```

## Migration-Specific Testing

### Regression Testing Strategy

#### Migration Validation Tests
```java
@SpringBootTest
@TestPropertySource(locations = "classpath:application-migration-test.properties")
class MigrationRegressionTest {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private DataMigrationService dataMigrationService;
    
    @Test
    void shouldMaintainAllExistingFunctionality() {
        // Test all critical business functions still work
        testUserRegistration();
        testUserAuthentication();
        testProfileManagement();
        testDataRetrieval();
        testReporting();
    }
    
    @Test
    void shouldPreserveDataIntegrityAfterMigration() {
        // Given - pre-migration data setup
        List<User> originalUsers = createTestUsers();
        
        // When - run migration
        dataMigrationService.migrateToJakartaEE();
        
        // Then - verify data integrity
        List<User> migratedUsers = userRepository.findAll();
        assertThat(migratedUsers).hasSize(originalUsers.size());
        
        for (User original : originalUsers) {
            User migrated = migratedUsers.stream()
                .filter(u -> u.getId().equals(original.getId()))
                .findFirst()
                .orElseThrow();
                
            assertThat(migrated.getUsername()).isEqualTo(original.getUsername());
            assertThat(migrated.getEmail()).isEqualTo(original.getEmail());
            assertThat(migrated.isActive()).isEqualTo(original.isActive());
        }
    }
    
    private void testUserRegistration() {
        CreateUserRequest request = CreateUserRequest.builder()
            .username("regressionuser")
            .email("regression@example.com")
            .password("RegressionPassword123!")
            .build();
            
        User user = userService.createUser(request);
        assertThat(user).isNotNull();
        assertThat(user.getUsername()).isEqualTo("regressionuser");
    }
    
    // Additional regression test methods...
}
```

## Test Environment Management

### Environment Configuration

#### Test Environment Setup
```bash
#!/bin/bash
# Test environment setup script

echo "Setting up test environments..."

# Development test environment
docker-compose -f docker-compose.test.yml up -d postgres-test redis-test

# Wait for services to be ready
sleep 10

# Run database migrations
mvn flyway:migrate -Dflyway.configFiles=src/test/resources/flyway.conf

# Load test data
mvn exec:java -Dexec.mainClass="com.company.app.TestDataLoader"

echo "Test environment setup complete."
```

#### Test Data Cleanup
```java
@TestMethodOrder(OrderAnnotation.class)
abstract class BaseIntegrationTest {
    
    @Autowired
    protected TestDataService testDataService;
    
    @BeforeEach
    void setUpTestData() {
        testDataService.setupTestData();
    }
    
    @AfterEach
    void cleanUpTestData() {
        testDataService.cleanupTestData();
    }
    
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.AFTER_METHOD)
    protected void requiresCleanContext() {
        // Method-level context cleanup for tests that modify application context
    }
}
```

## Test Execution Strategy

### Test Execution Timeline

| Phase | Duration | Test Types | Coverage Goal |
|-------|----------|------------|---------------|
| Unit Testing | 2 weeks | Unit tests | 90%+ |
| Integration Testing | 2 weeks | Component integration | 80%+ |
| System Testing | 1 week | End-to-end scenarios | 70%+ |
| Performance Testing | 1 week | Load, stress, volume | Key scenarios |
| Security Testing | 3 days | Auth, validation, XSS | Critical paths |
| User Acceptance | 1 week | Business workflows | Core features |

### Parallel Execution Strategy

```xml
<!-- Parallel test execution configuration -->
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-surefire-plugin</artifactId>
    <configuration>
        <parallel>methods</parallel>
        <threadCount>4</threadCount>
        <forkCount>2</forkCount>
        <reuseForks>true</reuseForks>
    </configuration>
</plugin>
```

## Success Criteria & Exit Criteria

### Test Completion Criteria

#### Must-Have Criteria
- [ ] Unit test coverage ≥ 90%
- [ ] All integration tests passing
- [ ] Zero critical defects
- [ ] Performance within acceptable limits
- [ ] Security tests all passing
- [ ] User acceptance sign-off

#### Nice-to-Have Criteria
- [ ] Mutation testing score ≥ 80%
- [ ] Code quality metrics improved
- [ ] Test execution time optimized
- [ ] Comprehensive test documentation

### Quality Metrics Dashboard

#### Key Performance Indicators
- **Test Coverage**: Line, branch, and method coverage
- **Test Reliability**: Pass/fail rates over time
- **Defect Detection**: Bugs found per test phase
- **Performance Impact**: Test execution duration trends
- **Code Quality**: Cyclomatic complexity, maintainability index

## Next Steps

1. **Test Framework Setup**: Configure all testing tools and frameworks
2. **Test Data Preparation**: Create comprehensive test datasets
3. **Test Execution**: Execute all test phases according to timeline
4. **Results Analysis**: Analyze test results and coverage metrics
5. **Issue Resolution**: Address any identified defects or gaps

---

**Last Updated**: 2025-08-26
**Version**: 1.0
**Reviewed By**: QA Team Lead