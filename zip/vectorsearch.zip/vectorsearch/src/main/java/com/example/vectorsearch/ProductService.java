package com.example.vectorsearch;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired private ProductRepository productRepository;

    @Autowired private VectorService vectorService;

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    public Product saveProduct(Product product) {
        Product saved = productRepository.save(product);
        // Automatically add to vector store
        vectorService.saveProductToVectorStore(saved);
        return saved;
    }

    public void deleteProduct(Long id) {
        vectorService.deleteProductFromVectorStore(id.toString());
        productRepository.deleteById(id);
    }

    public List<Product> searchProducts(String query) {
        return productRepository.findByNameContainingIgnoreCase(query);
    }

    public List<String> getCategories() {
        return productRepository.findDistinctCategories();
    }

    public void syncAllProductsToVectorStore() {
        List<Product> products = productRepository.findAll();
        vectorService.saveAllProductsToVectorStore(products);
    }
}
