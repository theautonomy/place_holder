package com.example.vectorsearch;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash("vector_documents")
public class VectorDocument {
    @Id private String id;
    private String content;
    private String sourceId;
    private String sourceType;
    private String metadata;

    public VectorDocument() {}

    public VectorDocument(String content, String sourceId, String sourceType, String metadata) {
        this.content = content;
        this.sourceId = sourceId;
        this.sourceType = sourceType;
        this.metadata = metadata;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getMetadata() {
        return metadata;
    }

    public void setMetadata(String metadata) {
        this.metadata = metadata;
    }
}
