package com.example.vectorsearch;

import java.util.List;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import org.springframework.ai.document.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class VectorController {

    @Autowired private VectorService vectorService;

    @Autowired private ProductService productService;

    @Autowired private VectorDocumentRepository vectorDocumentRepository;

    private ObjectMapper objectMapper;

    public VectorController() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        return "index";
    }

    @GetMapping("/search")
    public String searchPage() {
        return "search";
    }

    @PostMapping("/search")
    @ResponseBody
    public String search(@RequestParam String query, @RequestParam(defaultValue = "5") int limit)
            throws JacksonException {
        List<Document> results = vectorService.searchSimilar(query, limit);

        StringBuilder html = new StringBuilder();
        html.append("<div class='search-results'>");

        if (results.isEmpty()) {
            html.append("<div class='alert alert-info'>No similar products found.</div>");
        } else {
            html.append("<h4>Similar Products Found:</h4>");
            for (Document doc : results) {
                // String productId = doc.getMetadata().get("id").toString();

                System.out.println("===================");
                System.out.println("===================");
                System.out.println("===================");
                System.out.println(doc.getText());
                System.out.println(doc.getScore());

                // Product product = objectMapper.readValue(doc.getText(), Product.class);

                // VectorDocument vectorDoc =
                // vectorDocumentRepository.findBySourceId(doc.getId()).getFirst();
                // VectorDocument vectorDoc =
                // vectorDocumentRepository.findBySourceId(product.getId().toString()).getFirst();

                // String name = doc.getMetadata().get("name").toString();
                // String category = doc.getMetadata().get("category").toString();
                // String price = doc.getMetadata().get("price").toString();
                // String brand = doc.getMetadata().get("brand").toString();

                // String name = product.getName();
                // String category = product.getCategory();
                // String price = product.getPrice().toString();
                // String brand = product.getBrand();

                String name = "Unknown";
                String category = "Unknown";
                String price = "Unknown";
                String brand = "Unknown";


                html.append("<div class='card mb-3'>")
                        .append("<div class='card-body'>")
                        .append("<h5 class='card-title'>")
                        .append(name)
                        .append("</h5>")
                        .append("<p class='card-text'>")
                        .append(doc.getText())
                        .append("</p>")
                        .append("<p class='card-text'>")
                        .append("<small class='text-muted'>Category: ")
                        .append(category)
                        .append(" | ")
                        .append("Brand: ")
                        .append(brand)
                        .append(" | ")
                        .append("Price: $")
                        .append(price)
                        .append("</small>")
                        .append("</p>")
                        .append("</div>")
                        .append("</div>");
            }
        }

        html.append("</div>");
        return html.toString();
    }
}
