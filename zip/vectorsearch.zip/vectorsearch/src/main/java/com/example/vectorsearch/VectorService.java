package com.example.vectorsearch;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@Service
public class VectorService {

    @Autowired private VectorStore vectorStore;

    @Autowired private VectorDocumentRepository vectorDocumentRepository;

    private ObjectMapper objectMapper;

    public VectorService() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    public void saveProductToVectorStore(Product product) {
        String content = product.getSearchableText();
        /*
        try {
            content = objectMapper.writeValueAsString(product);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
            */

        Map<String, Object> metadata =
                Map.of(
                        "id", product.getId().toString(),
                        "name", product.getName(),
                        "category", product.getCategory(),
                        "price", product.getPrice().toString(),
                        "brand", product.getBrand(),
                        "sourceType", "product");

        Document document = new Document(content, metadata);
        vectorStore.add(List.of(document));

        // Also save to Redis for tracking
        VectorDocument vectorDoc =
                new VectorDocument(
                        content, product.getId().toString(), "product", metadata.toString());
        vectorDocumentRepository.save(vectorDoc);
    }

    public void saveAllProductsToVectorStore(List<Product> products) {
        // vectorStore.delete("embedding:*");


        List<Document> documents =
                products.stream()
                        .map(
                                product -> {
                                    String content = product.getSearchableText();
                                    try {
                                        content = objectMapper.writeValueAsString(product);
                                    } catch (JsonProcessingException e) {
                                        e.printStackTrace();
                                    }
                                    Map<String, Object> metadata =
                                            Map.of(
                                                    "id", product.getId().toString(),
                                                    "name", product.getName(),
                                                    "category", product.getCategory(),
                                                    "price", product.getPrice().toString(),
                                                    "brand", product.getBrand(),
                                                    "sourceType", "product");
                                    return new Document(content, metadata);
                                })
                        .collect(Collectors.toList());

        vectorStore.add(documents);

        // Save tracking documents
        products.forEach(
                product -> {
                    VectorDocument vectorDoc =
                            new VectorDocument(
                                    product.getSearchableText(),
                                    product.getId().toString(),
                                    "product",
                                    "Product vector document");
                    vectorDocumentRepository.save(vectorDoc);
                });
    }

    public List<Document> searchSimilar(String query, int limit) {
        SearchRequest searchRequest =
                SearchRequest.builder().query(query).topK(limit).similarityThreshold(0.5).build();

        return vectorStore.similaritySearch(searchRequest);
    }

    public void deleteProductFromVectorStore(String productId) {
        vectorStore.delete(List.of(productId));
        vectorDocumentRepository
                .findBySourceId(productId)
                .forEach(vectorDocumentRepository::delete);
    }

    public List<VectorDocument> getAllVectorDocuments() {
        return (List<VectorDocument>) vectorDocumentRepository.findAll();
    }
}
