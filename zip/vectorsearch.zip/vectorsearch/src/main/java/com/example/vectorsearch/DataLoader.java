package com.example.vectorsearch;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired private ProductService productService;

    @Override
    public void run(String... args) throws Exception {
        // Load sample data if database is empty
        if (productService.getAllProducts().isEmpty()) {
            loadSampleData();
        }
    }

    private void loadSampleData() {
        List<Product> sampleProducts =
                Arrays.asList(
                        new Product(
                                "MacBook Pro 16-inch",
                                "Powerful laptop with M2 chip, perfect for professional work and creative tasks",
                                "Electronics",
                                2499.99,
                                "Apple"),
                        new Product(
                                "Sony WH-1000XM4",
                                "Premium noise-canceling wireless headphones with exceptional sound quality",
                                "Electronics",
                                349.99,
                                "Sony"),
                        new Product(
                                "Gaming Mechanical Keyboard",
                                "RGB backlit mechanical keyboard designed for gaming enthusiasts",
                                "Electronics",
                                129.99,
                                "Corsair"),
                        new Product(
                                "Running Shoes Air Max",
                                "Comfortable athletic shoes perfect for running and everyday wear",
                                "Sports",
                                139.99,
                                "Nike"),
                        new Product(
                                "Yoga Mat Premium",
                                "High-quality non-slip yoga mat for home workouts and studio sessions",
                                "Sports",
                                49.99,
                                "Liforme"),
                        new Product(
                                "Smart Coffee Maker",
                                "WiFi-enabled coffee maker with programmable brewing schedules",
                                "Home & Garden",
                                199.99,
                                "Keurig"),
                        new Product(
                                "Organic Cotton T-Shirt",
                                "Sustainable and comfortable basic t-shirt made from organic cotton",
                                "Clothing",
                                29.99,
                                "Patagonia"),
                        new Product(
                                "Wireless Charging Pad",
                                "Fast wireless charger compatible with all Qi-enabled devices",
                                "Electronics",
                                39.99,
                                "Belkin"),
                        new Product(
                                "Himalayan Salt Lamp",
                                "Natural pink salt lamp that creates ambient lighting and purifies air",
                                "Home & Garden",
                                24.99,
                                "Levoit"),
                        new Product(
                                "Bluetooth Speaker Portable",
                                "Waterproof portable speaker with rich bass and 12-hour battery life",
                                "Electronics",
                                79.99,
                                "JBL"));

        sampleProducts.forEach(productService::saveProduct);
        System.out.println("Sample data loaded successfully!");
    }
}
