package com.example.vectorsearch;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VectorDocumentRepository extends CrudRepository<VectorDocument, String> {
    List<VectorDocument> findBySourceType(String sourceType);

    List<VectorDocument> findBySourceId(String sourceId);
}
