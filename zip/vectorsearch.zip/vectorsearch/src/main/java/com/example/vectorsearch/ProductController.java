package com.example.vectorsearch;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/products")
public class ProductController {

    @Autowired private ProductService productService;

    @GetMapping
    public String products(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        model.addAttribute("categories", productService.getCategories());
        return "products";
    }

    @PostMapping
    @ResponseBody
    public String addProduct(@ModelAttribute Product product) {
        productService.saveProduct(product);
        List<Product> products = productService.getAllProducts();

        StringBuilder html = new StringBuilder();
        for (Product p : products) {
            html.append("<tr>")
                    .append("<td>")
                    .append(p.getName())
                    .append("</td>")
                    .append("<td>")
                    .append(p.getDescription())
                    .append("</td>")
                    .append("<td>")
                    .append(p.getCategory())
                    .append("</td>")
                    .append("<td>$")
                    .append(p.getPrice())
                    .append("</td>")
                    .append("<td>")
                    .append(p.getBrand())
                    .append("</td>")
                    .append("<td>")
                    .append("<button hx-delete='/products/")
                    .append(p.getId())
                    .append("' ")
                    .append(
                            "hx-target='#products-table' class='btn btn-danger btn-sm'>Delete</button>")
                    .append("</td>")
                    .append("</tr>");
        }

        return html.toString();
    }

    @DeleteMapping("/{id}")
    @ResponseBody
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        List<Product> products = productService.getAllProducts();

        StringBuilder html = new StringBuilder();
        for (Product p : products) {
            html.append("<tr>")
                    .append("<td>")
                    .append(p.getName())
                    .append("</td>")
                    .append("<td>")
                    .append(p.getDescription())
                    .append("</td>")
                    .append("<td>")
                    .append(p.getCategory())
                    .append("</td>")
                    .append("<td>$")
                    .append(p.getPrice())
                    .append("</td>")
                    .append("<td>")
                    .append(p.getBrand())
                    .append("</td>")
                    .append("<td>")
                    .append("<button hx-delete='/products/")
                    .append(p.getId())
                    .append("' ")
                    .append(
                            "hx-target='#products-table' class='btn btn-danger btn-sm'>Delete</button>")
                    .append("</td>")
                    .append("</tr>");
        }

        return html.toString();
    }

    @PostMapping("/sync")
    @ResponseBody
    public String syncToVectorStore() {
        productService.syncAllProductsToVectorStore();
        return "<div class='alert alert-success'>All products synced to vector store!</div>";
    }
}
