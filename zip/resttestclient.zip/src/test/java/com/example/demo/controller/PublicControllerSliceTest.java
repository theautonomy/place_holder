package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Message;
import com.example.demo.service.MessageService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.client.RestTestClient;

/**
 * Web layer slice test using @WebMvcTest annotation. This annotation loads only the web layer
 * (controllers) and allows mocking of service dependencies with @MockBean. This is faster
 * than @SpringBootTest because it doesn't load the full application context.
 *
 * <p>Pattern based on Dan Vega's TodoControllerMockMvcTest:
 * https://github.com/danvega/rest-test-client/blob/master/src/test/java/dev/danvega/resttest/TodoControllerMockMvcTest.java
 */
@WebMvcTest(PublicController.class)
class PublicControllerSliceTest {

    @Autowired MockMvc mockMvc;

    @MockitoBean MessageService messageService;

    RestTestClient client;

    @BeforeEach
    void setup() {
        client = RestTestClient.bindTo(mockMvc).build();
    }

    @Test
    @DisplayName("Should find all messages using @WebMvcTest")
    void findAllMessages() {
        // Arrange: Configure mock behavior
        when(messageService.findAll())
                .thenReturn(
                        List.of(
                                new Message(1L, "First Message", "Author1"),
                                new Message(2L, "Second Message", "Author2")));

        // Act & Assert
        List<Message> messages =
                client.get()
                        .uri("/api/public/messages")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(new ParameterizedTypeReference<List<Message>>() {})
                        .returnResult()
                        .getResponseBody();

        assertEquals(2, messages.size());
        assertEquals("First Message", messages.get(0).content());

        verify(messageService).findAll();
    }

    @Test
    @DisplayName("Should find message by ID using @WebMvcTest")
    void findMessageById() {
        when(messageService.findById(1L))
                .thenReturn(Optional.of(new Message(1L, "Test Message", "Test Author")));

        Message message =
                client.get()
                        .uri("/api/public/messages/1")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals(1L, message.id());
        assertEquals("Test Message", message.content());

        verify(messageService).findById(1L);
    }

    @Test
    @DisplayName("Should return 404 for non-existent message using @WebMvcTest")
    void shouldReturn404() {
        when(messageService.findById(999L)).thenReturn(Optional.empty());

        client.get().uri("/api/public/messages/999").exchange().expectStatus().isNotFound();

        verify(messageService).findById(999L);
    }

    @Test
    @DisplayName("Should create message using @WebMvcTest")
    void shouldCreateMessage() {
        Message inputMessage = new Message(null, "New Message", "New Author");
        Message createdMessage = new Message(1L, "New Message", "New Author");

        when(messageService.create(inputMessage)).thenReturn(createdMessage);

        Message result =
                client.post()
                        .uri("/api/public/messages")
                        .body(inputMessage)
                        .exchange()
                        .expectStatus()
                        .isCreated()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals(1L, result.id());
        assertEquals("New Message", result.content());

        verify(messageService).create(inputMessage);
    }

    @Test
    @DisplayName("Should validate JSON response structure using @WebMvcTest")
    void shouldValidateJsonStructure() {
        when(messageService.findAll()).thenReturn(List.of(new Message(1L, "Test", "Author")));

        client.get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody()
                .jsonPath("$")
                .isArray()
                .jsonPath("$[0].id")
                .exists()
                .jsonPath("$[0].content")
                .exists()
                .jsonPath("$[0].author")
                .exists();
    }

    @Test
    @DisplayName("Should perform health check using @WebMvcTest")
    void shouldPerformHealthCheck() {
        when(messageService.getHealthStatus()).thenReturn("API is healthy");

        String health =
                client.get()
                        .uri("/api/public/health")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(String.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals("API is healthy", health);
        verify(messageService).getHealthStatus();
    }
}
