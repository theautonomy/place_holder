package com.example.demo.controller;

import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;

import java.util.Base64;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.client.RestTestClient;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
class SecuredControllerWithBasicAuthTest {

    @Autowired private WebApplicationContext webApplicationContext;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        MockMvc mockMvc =
                MockMvcBuilders.webAppContextSetup(webApplicationContext)
                        .apply(springSecurity())
                        .build();

        restTestClient = RestTestClient.bindTo(mockMvc).build();
    }

    private String createBasicAuthHeader(String username, String password) {
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes());
        return "Basic " + new String(encodedAuth);
    }

    @Test
    @DisplayName("Should authenticate with USER credentials using Basic Auth")
    void shouldAuthenticateWithUserCredentials() {
        restTestClient
                .get()
                .uri("/api/secured/messages")
                .header(HttpHeaders.AUTHORIZATION, createBasicAuthHeader("user", "password"))
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON);
    }

    @Test
    @DisplayName("Should authenticate with MANAGER credentials using Basic Auth")
    void shouldAuthenticateWithManagerCredentials() {
        String requestBody =
                """
                {
                    "content": "Manager created message",
                    "author": "Manager"
                }
                """;

        restTestClient
                .post()
                .uri("/api/secured/messages")
                .header(HttpHeaders.AUTHORIZATION, createBasicAuthHeader("manager", "password"))
                .contentType(MediaType.APPLICATION_JSON)
                .body(requestBody)
                .exchange()
                .expectStatus()
                .isCreated();
    }

    @Test
    @DisplayName("Should authenticate with ADMIN credentials using Basic Auth")
    void shouldAuthenticateWithAdminCredentials() {
        restTestClient
                .get()
                .uri("/api/secured/admin-only")
                .header(HttpHeaders.AUTHORIZATION, createBasicAuthHeader("admin", "password"))
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody(String.class)
                .isEqualTo("This is an admin-only endpoint");
    }

    @Test
    @DisplayName("Should deny access with invalid credentials")
    void shouldDenyAccessWithInvalidCredentials() {
        restTestClient
                .get()
                .uri("/api/secured/messages")
                .header(HttpHeaders.AUTHORIZATION, createBasicAuthHeader("user", "wrongpassword"))
                .exchange()
                .expectStatus()
                .isUnauthorized();
    }

    @Test
    @DisplayName("Should enforce role-based access with Basic Auth")
    void shouldEnforceRoleBasedAccessWithBasicAuth() {
        // USER should not be able to access admin endpoint
        restTestClient
                .get()
                .uri("/api/secured/admin-only")
                .header(HttpHeaders.AUTHORIZATION, createBasicAuthHeader("user", "password"))
                .exchange()
                .expectStatus()
                .isForbidden();

        // ADMIN should be able to access admin endpoint
        restTestClient
                .get()
                .uri("/api/secured/admin-only")
                .header(HttpHeaders.AUTHORIZATION, createBasicAuthHeader("admin", "password"))
                .exchange()
                .expectStatus()
                .isOk();
    }
}
