package com.example.demo.controller;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.demo.model.Message;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.client.RestTestClient;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class PublicControllerTest {

    private RestTestClient restTestClient;

    @Autowired private PublicController publicController;

    @BeforeEach
    void setUp() {
        // Unit test approach: bind directly to controller
        restTestClient = RestTestClient.bindToController(publicController).build();
    }

    @Test
    @DisplayName("Should get all public messages")
    void shouldGetAllPublicMessages() {
        restTestClient
                .get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.length()")
                .isEqualTo(3)
                .jsonPath("$[0].id")
                .isEqualTo(1)
                .jsonPath("$[0].content")
                .isEqualTo("Welcome to the public API")
                .jsonPath("$[0].author")
                .isEqualTo("System");
    }

    @Test
    @DisplayName("Should get message by ID")
    void shouldGetMessageById() {
        restTestClient
                .get()
                .uri("/api/public/messages/1")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody()
                .jsonPath("$.id")
                .isEqualTo(1)
                .jsonPath("$.content")
                .isEqualTo("Welcome to the public API");
    }

    @Test
    @DisplayName("Should return 404 for non-existent message")
    void shouldReturn404ForNonExistentMessage() {
        restTestClient.get().uri("/api/public/messages/999").exchange().expectStatus().isNotFound();
    }

    @Test
    @DisplayName("Should create new message")
    void shouldCreateNewMessage() {
        Message newMessage = new Message(null, "Test message", "Tester");

        restTestClient
                .post()
                .uri("/api/public/messages")
                .contentType(MediaType.APPLICATION_JSON)
                .body(newMessage)
                .exchange()
                .expectStatus()
                .isCreated()
                .expectBody()
                .jsonPath("$.id")
                .isEqualTo(4)
                .jsonPath("$.content")
                .isEqualTo("Test message")
                .jsonPath("$.author")
                .isEqualTo("Tester");
    }

    @Test
    @DisplayName("Should perform health check")
    void shouldPerformHealthCheck() {
        restTestClient
                .get()
                .uri("/api/public/health")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody(String.class)
                .isEqualTo("Public API is running");
    }

    @Test
    @DisplayName("Should decode response body to Message object")
    void shouldDecodeResponseToObject() {
        Message message =
                restTestClient
                        .get()
                        .uri("/api/public/messages/1")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertThat(message).isNotNull();
        assertThat(message.id()).isEqualTo(1L);
        assertThat(message.content()).isEqualTo("Welcome to the public API");
        assertThat(message.author()).isEqualTo("System");
    }
}
