package com.example.demo.controller;

import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;

import com.example.demo.model.Message;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.client.RestTestClient;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
class SecuredControllerTest {

    @Autowired private WebApplicationContext webApplicationContext;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        MockMvc mockMvc =
                MockMvcBuilders.webAppContextSetup(webApplicationContext)
                        .apply(springSecurity())
                        .build();

        restTestClient = RestTestClient.bindTo(mockMvc).build();
    }

    @Test
    @DisplayName("Should deny access without authentication")
    void shouldDenyAccessWithoutAuthentication() {
        restTestClient
                .get()
                .uri("/api/secured/messages")
                .exchange()
                .expectStatus()
                .isUnauthorized();
    }

    @Test
    @WithMockUser(
            username = "user",
            roles = {"USER"})
    @DisplayName("Should allow USER role to get all messages")
    void shouldAllowUserRoleToGetAllMessages() {
        restTestClient
                .get()
                .uri("/api/secured/messages")
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.length()")
                .isEqualTo(2);
    }

    @Test
    @WithMockUser(
            username = "user",
            roles = {"USER"})
    @DisplayName("Should allow USER role to get message by ID")
    void shouldAllowUserRoleToGetMessageById() {
        restTestClient
                .get()
                .uri("/api/secured/messages/1")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody()
                .jsonPath("$.id")
                .isEqualTo(1)
                .jsonPath("$.content")
                .isEqualTo("Confidential message");
    }

    @Test
    @WithMockUser(
            username = "user",
            roles = {"USER"})
    @DisplayName("Should deny USER role from creating messages")
    void shouldDenyUserRoleFromCreatingMessages() {
        Message newMessage = new Message(null, "Unauthorized message", "User");

        restTestClient
                .post()
                .uri("/api/secured/messages")
                .contentType(MediaType.APPLICATION_JSON)
                .body(newMessage)
                .exchange()
                .expectStatus()
                .isForbidden();
    }

    @Test
    @WithMockUser(
            username = "manager",
            roles = {"MANAGER"})
    @DisplayName("Should allow MANAGER role to create messages")
    void shouldAllowManagerRoleToCreateMessages() {
        Message newMessage = new Message(null, "Manager message", "Manager");

        restTestClient
                .post()
                .uri("/api/secured/messages")
                .contentType(MediaType.APPLICATION_JSON)
                .body(newMessage)
                .exchange()
                .expectStatus()
                .isCreated()
                .expectBody()
                .jsonPath("$.content")
                .isEqualTo("Manager message")
                .jsonPath("$.author")
                .isEqualTo("Manager");
    }

    @Test
    @WithMockUser(
            username = "manager",
            roles = {"MANAGER"})
    @DisplayName("Should deny MANAGER role from deleting messages")
    void shouldDenyManagerRoleFromDeletingMessages() {
        restTestClient
                .delete()
                .uri("/api/secured/messages/1")
                .exchange()
                .expectStatus()
                .isForbidden();
    }

    @Test
    @WithMockUser(
            username = "admin",
            roles = {"ADMIN"})
    @DisplayName("Should allow ADMIN role to delete messages")
    void shouldAllowAdminRoleToDeleteMessages() {
        restTestClient
                .delete()
                .uri("/api/secured/messages/1")
                .exchange()
                .expectStatus()
                .isNoContent();
    }

    @Test
    @WithMockUser(
            username = "admin",
            roles = {"ADMIN"})
    @DisplayName("Should allow ADMIN role to access admin-only endpoint")
    void shouldAllowAdminRoleToAccessAdminOnlyEndpoint() {
        restTestClient
                .get()
                .uri("/api/secured/admin-only")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody(String.class)
                .isEqualTo("This is an admin-only endpoint");
    }

    @Test
    @WithMockUser(
            username = "manager",
            roles = {"MANAGER"})
    @DisplayName("Should deny MANAGER role from accessing admin-only endpoint")
    void shouldDenyManagerRoleFromAccessingAdminOnlyEndpoint() {
        restTestClient.get().uri("/api/secured/admin-only").exchange().expectStatus().isForbidden();
    }

    @Test
    @WithMockUser(
            username = "manager",
            roles = {"MANAGER"})
    @DisplayName("Should allow MANAGER role to access manager-only endpoint")
    void shouldAllowManagerRoleToAccessManagerOnlyEndpoint() {
        restTestClient
                .get()
                .uri("/api/secured/manager-only")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody(String.class)
                .isEqualTo("This is a manager-only endpoint");
    }

    @Test
    @WithMockUser(
            username = "user",
            roles = {"USER"})
    @DisplayName("Should deny USER role from accessing manager-only endpoint")
    void shouldDenyUserRoleFromAccessingManagerOnlyEndpoint() {
        restTestClient
                .get()
                .uri("/api/secured/manager-only")
                .exchange()
                .expectStatus()
                .isForbidden();
    }
}
