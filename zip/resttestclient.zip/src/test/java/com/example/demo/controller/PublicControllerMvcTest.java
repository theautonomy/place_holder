package com.example.demo.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.client.RestTestClient;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class PublicControllerMvcTest {

    @Autowired private WebApplicationContext webApplicationContext;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        // MVC test approach: bind to MockMvc
        MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        restTestClient = RestTestClient.bindTo(mockMvc).build();
    }

    @Test
    @DisplayName("Should get all messages with MockMvc")
    void shouldGetAllMessagesWithMockMvc() {
        restTestClient
                .get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.length()")
                .isEqualTo(3);
    }

    @Test
    @DisplayName("Should validate JSON response structure")
    void shouldValidateJsonResponseStructure() {
        restTestClient
                .get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody()
                .jsonPath("$")
                .isArray()
                .jsonPath("$[0].id")
                .exists()
                .jsonPath("$[0].content")
                .exists()
                .jsonPath("$[0].author")
                .exists();
    }
}
