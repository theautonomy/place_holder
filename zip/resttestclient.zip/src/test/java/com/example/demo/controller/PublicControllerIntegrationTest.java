package com.example.demo.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.client.RestTestClient;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
class PublicControllerIntegrationTest {

    @Autowired private WebApplicationContext webApplicationContext;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        // Integration test approach: bind to ApplicationContext
        restTestClient = RestTestClient.bindToApplicationContext(webApplicationContext).build();
    }

    @Test
    @DisplayName("Should access public endpoints without authentication")
    void shouldAccessPublicEndpointsWithoutAuthentication() {
        restTestClient
                .get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.length()")
                .isEqualTo(3);
    }

    @Test
    @DisplayName("Should create message through full application context")
    void shouldCreateMessageThroughFullContext() {
        String requestBody =
                """
                {
                    "content": "Integration test message",
                    "author": "Integration Tester"
                }
                """;

        restTestClient
                .post()
                .uri("/api/public/messages")
                .contentType(MediaType.APPLICATION_JSON)
                .body(requestBody)
                .exchange()
                .expectStatus()
                .isCreated()
                .expectBody()
                .jsonPath("$.content")
                .isEqualTo("Integration test message")
                .jsonPath("$.author")
                .isEqualTo("Integration Tester");
    }
}
