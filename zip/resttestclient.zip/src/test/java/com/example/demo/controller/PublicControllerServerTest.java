package com.example.demo.controller;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import com.example.demo.model.Message;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.client.RestTestClient;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class PublicControllerServerTest {

    @LocalServerPort private int port;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        // Server test approach: bind to actual running server
        restTestClient = RestTestClient.bindToServer().baseUrl("http://localhost:" + port).build();
    }

    @Test
    @DisplayName("Should get all public messages from running server")
    void shouldGetAllPublicMessagesFromServer() {
        restTestClient
                .get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus()
                .isOk()
                .expectHeader()
                .contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.length()")
                .isEqualTo(3)
                .jsonPath("$[0].id")
                .isEqualTo(1)
                .jsonPath("$[0].content")
                .isEqualTo("Welcome to the public API");
    }

    @Test
    @DisplayName("Should get message by ID from running server")
    void shouldGetMessageByIdFromServer() {
        restTestClient
                .get()
                .uri("/api/public/messages/1")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody()
                .jsonPath("$.id")
                .isEqualTo(1)
                .jsonPath("$.content")
                .isEqualTo("Welcome to the public API")
                .jsonPath("$.author")
                .isEqualTo("System");
    }

    @Test
    @DisplayName("Should return 404 for non-existent message from server")
    void shouldReturn404ForNonExistentMessageFromServer() {
        restTestClient.get().uri("/api/public/messages/999").exchange().expectStatus().isNotFound();
    }

    @Test
    @DisplayName("Should create new message on running server")
    void shouldCreateNewMessageOnServer() {
        String requestBody =
                """
                {
                    "content": "Server test message",
                    "author": "Server Tester"
                }
                """;

        restTestClient
                .post()
                .uri("/api/public/messages")
                .contentType(MediaType.APPLICATION_JSON)
                .body(requestBody)
                .exchange()
                .expectStatus()
                .isCreated()
                .expectBody()
                .jsonPath("$.id")
                .isEqualTo(4)
                .jsonPath("$.content")
                .isEqualTo("Server test message")
                .jsonPath("$.author")
                .isEqualTo("Server Tester");
    }

    @Test
    @DisplayName("Should perform health check on running server")
    void shouldPerformHealthCheckOnServer() {
        restTestClient
                .get()
                .uri("/api/public/health")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody(String.class)
                .isEqualTo("Public API is running");
    }

    @Test
    @DisplayName("Should decode response body to Message object from server")
    void shouldDecodeResponseToObjectFromServer() {
        Message message =
                restTestClient
                        .get()
                        .uri("/api/public/messages/1")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertThat(message).isNotNull();
        assertThat(message.id()).isEqualTo(1L);
        assertThat(message.content()).isEqualTo("Welcome to the public API");
        assertThat(message.author()).isEqualTo("System");
    }

    @Test
    @DisplayName("Should get all messages and deserialize to List from server")
    void shouldGetAllMessagesAsListFromServer() {
        List<Message> messages =
                restTestClient
                        .get()
                        .uri("/api/public/messages")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(new ParameterizedTypeReference<List<Message>>() {})
                        .returnResult()
                        .getResponseBody();

        assertThat(messages).isNotNull();
        assertThat(messages).hasSize(3);
        assertThat(messages.get(0).content()).isEqualTo("Welcome to the public API");
        assertThat(messages.get(1).content()).isEqualTo("No authentication required");
        assertThat(messages.get(2).content()).isEqualTo("Free access for everyone");
    }
}
