package com.example.demo.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import com.example.demo.model.Message;
import com.example.demo.service.MessageService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.web.servlet.client.RestTestClient;

/**
 * Simple unit test without any Spring annotations. Tests controller in complete isolation with real
 * service instance. Fastest possible test execution.
 */
class PublicControllerSimpleTest {

    RestTestClient client;

    @BeforeEach
    void setup() {
        // Create real service and controller instances - no Spring involved
        MessageService messageService = new MessageService();
        PublicController controller = new PublicController(messageService);

        // Bind RestTestClient directly to controller
        client = RestTestClient.bindToController(controller).build();
    }

    @Test
    @DisplayName("Should find all messages")
    void findAllMessages() {
        List<Message> messages =
                client.get()
                        .uri("/api/public/messages")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(new ParameterizedTypeReference<List<Message>>() {})
                        .returnResult()
                        .getResponseBody();

        assertEquals(3, messages.size());
        assertEquals("Welcome to the public API", messages.get(0).content());
    }

    @Test
    @DisplayName("Should find message by ID")
    void findMessageById() {
        Message message =
                client.get()
                        .uri("/api/public/messages/1")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals(1L, message.id());
        assertEquals("Welcome to the public API", message.content());
    }

    @Test
    @DisplayName("Should find message by ID using AssertJ")
    void findMessageByIdAssertJ() {
        Message message =
                client.get()
                        .uri("/api/public/messages/1")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertThat(message).isNotNull();
        assertThat(message.id()).isEqualTo(1L);
        assertThat(message.content()).isEqualTo("Welcome to the public API");
        assertThat(message.author()).isEqualTo("System");
    }

    @Test
    @DisplayName("Should find message by ID using JsonPath")
    void findMessageByIdJsonPath() {
        client.get()
                .uri("/api/public/messages/2")
                .exchange()
                .expectStatus()
                .isOk()
                .expectBody()
                .jsonPath("$.id")
                .isEqualTo(2)
                .jsonPath("$.content")
                .isEqualTo("No authentication required")
                .jsonPath("$.author")
                .isEqualTo("System");
    }

    @Test
    @DisplayName("Should return 404 for non-existent message")
    void shouldReturn404ForNonExistentMessage() {
        client.get().uri("/api/public/messages/999").exchange().expectStatus().isNotFound();
    }

    @Test
    @DisplayName("Should perform health check")
    void shouldPerformHealthCheck() {
        String health =
                client.get()
                        .uri("/api/public/health")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(String.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals("Public API is running", health);
    }
}
