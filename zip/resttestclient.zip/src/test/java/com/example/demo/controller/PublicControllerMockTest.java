package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Message;
import com.example.demo.service.MessageService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.web.servlet.client.RestTestClient;

/**
 * Unit test with mocked dependencies using Mockito. No Spring annotations - pure unit testing.
 * Demonstrates testing controller in isolation with mocked service.
 */
class PublicControllerMockTest {

    RestTestClient client;
    MessageService messageService;

    @BeforeEach
    void setup() {
        // Mock the service without Spring involvement
        messageService = Mockito.mock(MessageService.class);

        // Configure mock behavior
        when(messageService.findAll())
                .thenReturn(
                        List.of(
                                new Message(1L, "Mock message 1", "Mock Author"),
                                new Message(2L, "Mock message 2", "Mock Author")));

        when(messageService.findById(1L))
                .thenReturn(Optional.of(new Message(1L, "Mock message 1", "Mock Author")));

        when(messageService.getHealthStatus()).thenReturn("Mocked health status");

        // Create controller with mocked service
        PublicController controller = new PublicController(messageService);

        // Bind RestTestClient to controller
        client = RestTestClient.bindToController(controller).build();
    }

    @Test
    @DisplayName("Should find all messages from mocked service")
    void findAllMessages() {
        List<Message> messages =
                client.get()
                        .uri("/api/public/messages")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(new ParameterizedTypeReference<List<Message>>() {})
                        .returnResult()
                        .getResponseBody();

        assertEquals(2, messages.size());
        assertEquals("Mock message 1", messages.get(0).content());
        assertEquals("Mock Author", messages.get(0).author());

        // Verify service method was called
        verify(messageService).findAll();
    }

    @Test
    @DisplayName("Should find message by ID from mocked service")
    void findMessageById() {
        Message message =
                client.get()
                        .uri("/api/public/messages/1")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals(1L, message.id());
        assertEquals("Mock message 1", message.content());

        // Verify service method was called with correct parameter
        verify(messageService).findById(1L);
    }

    @Test
    @DisplayName("Should return 404 when service returns empty")
    void shouldReturn404WhenServiceReturnsEmpty() {
        // Configure mock to return empty for specific ID
        when(messageService.findById(999L)).thenReturn(Optional.empty());

        client.get().uri("/api/public/messages/999").exchange().expectStatus().isNotFound();

        verify(messageService).findById(999L);
    }

    @Test
    @DisplayName("Should create message using mocked service")
    void shouldCreateMessage() {
        Message inputMessage = new Message(null, "New message", "Test Author");
        Message createdMessage = new Message(3L, "New message", "Test Author");

        when(messageService.create(inputMessage)).thenReturn(createdMessage);

        Message result =
                client.post()
                        .uri("/api/public/messages")
                        .body(inputMessage)
                        .exchange()
                        .expectStatus()
                        .isCreated()
                        .expectBody(Message.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals(3L, result.id());
        assertEquals("New message", result.content());

        verify(messageService).create(inputMessage);
    }

    @Test
    @DisplayName("Should get health status from mocked service")
    void shouldGetHealthStatus() {
        String health =
                client.get()
                        .uri("/api/public/health")
                        .exchange()
                        .expectStatus()
                        .isOk()
                        .expectBody(String.class)
                        .returnResult()
                        .getResponseBody();

        assertEquals("Mocked health status", health);
        verify(messageService).getHealthStatus();
    }
}
