package com.example.demo.model;

public record Message(Long id, String content, String author) {}
