package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.demo.model.Message;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/secured")
public class SecuredController {

    private final List<Message> secureMessages = new ArrayList<>();

    public SecuredController() {
        secureMessages.add(new Message(1L, "Confidential message", "Admin"));
        secureMessages.add(new Message(2L, "Restricted access data", "Manager"));
    }

    @GetMapping("/messages")
    public ResponseEntity<List<Message>> getAllSecureMessages() {
        return ResponseEntity.ok(secureMessages);
    }

    @GetMapping("/messages/{id}")
    public ResponseEntity<Message> getSecureMessageById(@PathVariable Long id) {
        Optional<Message> message =
                secureMessages.stream().filter(m -> m.id().equals(id)).findFirst();
        return message.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/messages")
    public ResponseEntity<Message> createSecureMessage(@RequestBody Message message) {
        Message newMessage =
                new Message(
                        (long) (secureMessages.size() + 1), message.content(), message.author());
        secureMessages.add(newMessage);
        return ResponseEntity.status(HttpStatus.CREATED).body(newMessage);
    }

    @DeleteMapping("/messages/{id}")
    public ResponseEntity<Void> deleteSecureMessage(@PathVariable Long id) {
        boolean removed = secureMessages.removeIf(m -> m.id().equals(id));
        if (removed) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/admin-only")
    public ResponseEntity<String> adminOnlyEndpoint() {
        return ResponseEntity.ok("This is an admin-only endpoint");
    }

    @GetMapping("/manager-only")
    public ResponseEntity<String> managerOnlyEndpoint() {
        return ResponseEntity.ok("This is a manager-only endpoint");
    }
}
