package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(
                        auth ->
                                auth
                                        // Public endpoints - no authentication required
                                        .requestMatchers("/api/public/**")
                                        .permitAll()

                                        // Secured endpoints - role-based access control
                                        // GET /api/secured/messages - accessible by USER, MANAGER,
                                        // ADMIN
                                        .requestMatchers(HttpMethod.GET, "/api/secured/messages")
                                        .hasAnyRole("USER", "MANAGER", "ADMIN")
                                        .requestMatchers(HttpMethod.GET, "/api/secured/messages/**")
                                        .hasAnyRole("USER", "MANAGER", "ADMIN")

                                        // POST /api/secured/messages - accessible by MANAGER, ADMIN
                                        .requestMatchers(HttpMethod.POST, "/api/secured/messages")
                                        .hasAnyRole("MANAGER", "ADMIN")

                                        // DELETE /api/secured/messages/{id} - accessible by ADMIN
                                        // only
                                        .requestMatchers(
                                                HttpMethod.DELETE, "/api/secured/messages/**")
                                        .hasRole("ADMIN")

                                        // /api/secured/admin-only - accessible by ADMIN only
                                        .requestMatchers("/api/secured/admin-only")
                                        .hasRole("ADMIN")

                                        // /api/secured/manager-only - accessible by MANAGER only
                                        .requestMatchers("/api/secured/manager-only")
                                        .hasRole("MANAGER")

                                        // All other requests require authentication
                                        .anyRequest()
                                        .authenticated())
                .httpBasic(Customizer.withDefaults())
                .csrf(csrf -> csrf.disable());

        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails user =
                User.builder()
                        .username("user")
                        .password(passwordEncoder().encode("password"))
                        .roles("USER")
                        .build();

        UserDetails manager =
                User.builder()
                        .username("manager")
                        .password(passwordEncoder().encode("password"))
                        .roles("MANAGER")
                        .build();

        UserDetails admin =
                User.builder()
                        .username("admin")
                        .password(passwordEncoder().encode("password"))
                        .roles("ADMIN")
                        .build();

        return new InMemoryUserDetailsManager(user, manager, admin);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
