package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.demo.model.Message;

import org.springframework.stereotype.Service;

@Service
public class MessageService {

    private final List<Message> messages = new ArrayList<>();

    public MessageService() {
        messages.add(new Message(1L, "Welcome to the public API", "System"));
        messages.add(new Message(2L, "No authentication required", "System"));
        messages.add(new Message(3L, "Free access for everyone", "System"));
    }

    public List<Message> findAll() {
        return new ArrayList<>(messages);
    }

    public Optional<Message> findById(Long id) {
        return messages.stream().filter(m -> m.id().equals(id)).findFirst();
    }

    public Message create(Message message) {
        Message newMessage =
                new Message((long) (messages.size() + 1), message.content(), message.author());
        messages.add(newMessage);
        return newMessage;
    }

    public String getHealthStatus() {
        return "Public API is running";
    }
}
