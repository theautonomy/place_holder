# RestTestClient Demo - Comprehensive Testing Guide

A complete demonstration of Spring Framework 7's **RestTestClient** feature, showcasing all binding strategies and test patterns from lightweight unit tests to end-to-end integration tests.

## Table of Contents

- [Overview](#overview)
- [Test Strategy](#test-strategy)
- [Binding Strategies](#binding-strategies)
- [Lightweight Unit Tests](#lightweight-unit-tests)
- [Spring Boot Integration Tests](#spring-boot-integration-tests)
- [Quick Start](#quick-start)
- [API Endpoints](#api-endpoints)
- [Running Tests](#running-tests)
- [Key Technical Notes](#key-technical-notes)

---

## Overview

This project demonstrates **7 different test approaches** for REST API testing, ranging from pure unit tests (no Spring) to full end-to-end server tests:

### Test Distribution (50 Total Tests ✅)

```
Lightweight Unit Tests (No @SpringBootTest): 17 tests (34%)
├── PublicControllerSimpleTest    (Real instances)         6 tests ⚡⚡⚡⚡
├── PublicControllerMockTest      (Mockito mocks)          5 tests ⚡⚡⚡⚡
└── PublicControllerWebMvcTest    (Manual MockMvc)         6 tests ⚡⚡⚡

Spring Boot Integration Tests: 33 tests (66%)
├── PublicControllerTest          (bindToController)       6 tests
├── PublicControllerMvcTest       (bindTo MockMvc)         2 tests
├── PublicControllerIntegrationTest (bindToApplicationContext) 2 tests
├── PublicControllerServerTest    (bindToServer)           7 tests
├── SecuredControllerTest         (@WithMockUser)         11 tests
└── SecuredControllerWithBasicAuthTest (Basic Auth)        5 tests
```

---

## Test Strategy

### The Test Pyramid

Following industry best practices, tests are distributed across the pyramid:

```
           /\
          /E2\        7 tests  (14%) - End-to-end (bindToServer)
         /----\
        / Int  \      2 tests  (4%)  - Integration (bindToApplicationContext)
       /--------\
      /   MVC    \   15 tests (30%) - MVC layer (bindTo MockMvc)
     /------------\
    /    Unit      \  26 tests (52%) - Pure unit + controller tests
   /----------------\
```

### When to Use Each Test Type

| Test Type | Speed | Use When | Example |
|-----------|-------|----------|---------|
| **Simple Unit** | ⚡⚡⚡⚡ | Testing controller logic with real lightweight services | PublicControllerSimpleTest |
| **Mock Unit** | ⚡⚡⚡⚡ | Testing controller logic with mocked dependencies | PublicControllerMockTest |
| **WebMvc Unit** | ⚡⚡⚡ | Testing HTTP layer without Spring context | PublicControllerWebMvcTest |
| **bindToController** | ⚡⚡⚡ | Unit testing controllers with Spring context | PublicControllerTest |
| **bindTo(MockMvc)** | ⚡⚡ | Testing with Spring MVC features & security | SecuredControllerTest |
| **bindToApplicationContext** | ⚡ | Integration testing with full Spring context | PublicControllerIntegrationTest |
| **bindToServer** | ⚡ | End-to-end testing with real HTTP server | PublicControllerServerTest |

---

## Binding Strategies

RestTestClient provides **four binding methods** representing a progression from unit to end-to-end testing:

### 1. bindToController() - Pure Unit Testing

**Purpose:** Test controller methods in complete isolation

**Setup:**
```java
@SpringBootTest
class PublicControllerTest {
    @Autowired
    private PublicController publicController;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        // Bind directly to controller instance
        restTestClient = RestTestClient.bindToController(publicController).build();
    }
}
```

**Characteristics:**
- ✅ Fastest - No server, minimal overhead
- ✅ Highly isolated - Tests only controller logic
- ✅ Mock dependencies - Can inject mocked services
- ❌ No HTTP validation - Doesn't test actual HTTP layer
- ❌ No Spring MVC features - No validation, converters

**When to Use:**
- Fast feedback during TDD
- Testing controller business logic
- Unit testing with mocked dependencies

---

### 2. bindTo(MockMvc) - MVC Integration Testing

**Purpose:** Test with Spring MVC infrastructure without starting a server

**Setup:**
```java
@SpringBootTest
class PublicControllerMvcTest {
    @Autowired
    private WebApplicationContext webApplicationContext;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        MockMvc mockMvc = MockMvcBuilders
                .webAppContextSetup(webApplicationContext)
                .apply(springSecurity())  // Enable @WithMockUser
                .build();

        restTestClient = RestTestClient.bindTo(mockMvc).build();
    }
}
```

**Characteristics:**
- ✅ Fast - No server startup required
- ✅ Spring MVC features - Validation, converters, interceptors
- ✅ Security testing - Can use `@WithMockUser`
- ✅ Full Spring context - All beans available
- ❌ No real HTTP - Simulated HTTP layer

**When to Use:**
- Testing HTTP layer with Spring MVC features
- Testing validation and data binding
- Testing security with `@WithMockUser`
- Integration testing without server overhead

---

### 3. bindToApplicationContext() - Full Integration Testing

**Purpose:** Integration testing with full Spring application context

**Setup:**
```java
@SpringBootTest
class PublicControllerIntegrationTest {
    @Autowired
    private WebApplicationContext webApplicationContext;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        restTestClient = RestTestClient.bindToApplicationContext(webApplicationContext)
                .build();
    }
}
```

**Characteristics:**
- ✅ Full context - All beans, services, repositories loaded
- ✅ Real dependencies - Tests actual service implementations
- ✅ Database integration - Can test with real or test database
- ✅ Complete wiring - All Spring configuration applied
- ❌ Slower - Full context startup
- ❌ No real HTTP - Still simulated

**When to Use:**
- Integration testing with real services
- Testing database interactions
- Testing transaction management
- Verifying bean wiring and configuration

---

### 4. bindToServer() - End-to-End Testing

**Purpose:** End-to-end testing against a real running HTTP server

**Setup:**
```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class PublicControllerServerTest {
    @LocalServerPort
    private int port;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        restTestClient = RestTestClient.bindToServer()
                .baseUrl("http://localhost:" + port)
                .build();
    }
}
```

**Characteristics:**
- ✅ Real HTTP - Actual HTTP requests over network
- ✅ Complete E2E - Tests entire request/response cycle
- ✅ Server behavior - Tests timeouts, connection handling
- ✅ Most realistic - Closest to production environment
- ❌ Slowest - Server startup + HTTP overhead
- ❌ Resource intensive - Uses actual ports and sockets

**When to Use:**
- End-to-end testing
- Testing HTTP-specific behavior
- Smoke tests before deployment
- API contract verification

---

## Lightweight Unit Tests

Following [Dan Vega's example patterns](https://github.com/danvega/rest-test-client), we have three types of **lightweight unit tests** that don't require `@SpringBootTest`:

### 1. PublicControllerSimpleTest - Real Instances

**Pattern:** No Spring, no mocks - pure unit test with real instances

```java
class PublicControllerSimpleTest {
    RestTestClient client;

    @BeforeEach
    void setup() {
        // Create real instances - no Spring, no mocks
        MessageService messageService = new MessageService();
        PublicController controller = new PublicController(messageService);

        // Bind directly to controller
        client = RestTestClient.bindToController(controller).build();
    }

    @Test
    void findAllMessages() {
        List<Message> messages = client.get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus().isOk()
                .expectBody(new ParameterizedTypeReference<List<Message>>() {})
                .returnResult()
                .getResponseBody();

        assertEquals(3, messages.size());
    }
}
```

**When to Use:**
- Pure unit testing of controller logic
- Testing with real lightweight services
- No need for mocking
- Maximum speed during TDD

**Tests (6):**
- ✅ Should find all messages
- ✅ Should find message by ID
- ✅ Should find message by ID using AssertJ
- ✅ Should find message by ID using JsonPath
- ✅ Should return 404 for non-existent message
- ✅ Should perform health check

---

### 2. PublicControllerMockTest - Mockito Mocks

**Pattern:** No Spring, with Mockito mocks for dependencies

```java
class PublicControllerMockTest {
    RestTestClient client;
    MessageService messageService;

    @BeforeEach
    void setup() {
        // Mock the service using Mockito
        messageService = Mockito.mock(MessageService.class);

        // Configure mock behavior
        when(messageService.findAll()).thenReturn(
                List.of(new Message(1L, "Mock message", "Mock Author"))
        );

        // Create controller with mocked service
        PublicController controller = new PublicController(messageService);
        client = RestTestClient.bindToController(controller).build();
    }

    @Test
    void findAllMessages() {
        List<Message> messages = client.get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus().isOk()
                .expectBody(new ParameterizedTypeReference<List<Message>>() {})
                .returnResult()
                .getResponseBody();

        assertEquals(1, messages.size());

        // Verify service was called
        verify(messageService).findAll();
    }
}
```

**When to Use:**
- Testing controller logic with mocked dependencies
- Isolating controller from service implementation
- Verifying interactions between controller and service
- Testing edge cases (empty results, errors)

**Tests (5):**
- ✅ Should find all messages from mocked service
- ✅ Should find message by ID from mocked service
- ✅ Should return 404 when service returns empty
- ✅ Should create message using mocked service
- ✅ Should get health status from mocked service

---

### 3. PublicControllerWebMvcTest - Manual MockMvc

**Pattern:** No Spring Boot, manually configured MockMvc

```java
class PublicControllerWebMvcTest {
    MockMvc mockMvc;
    MessageService messageService;
    RestTestClient client;

    @BeforeEach
    void setup() {
        // Mock the service
        messageService = Mockito.mock(MessageService.class);

        // Create controller
        PublicController controller = new PublicController(messageService);

        // Manually build MockMvc - no Spring context needed
        // Note: standaloneSetup automatically configures Jackson converters
        mockMvc = MockMvcBuilders
                .standaloneSetup(controller)
                .build();

        // Bind RestTestClient to MockMvc
        client = RestTestClient.bindTo(mockMvc).build();
    }

    @Test
    void findAllMessages() {
        when(messageService.findAll()).thenReturn(
                List.of(new Message(1L, "Test", "Author"))
        );

        List<Message> messages = client.get()
                .uri("/api/public/messages")
                .exchange()
                .expectStatus().isOk()
                .expectBody(new ParameterizedTypeReference<List<Message>>() {})
                .returnResult()
                .getResponseBody();

        assertEquals(1, messages.size());
        verify(messageService).findAll();
    }
}
```

**When to Use:**
- Testing HTTP layer without full Spring context
- Testing request/response processing
- Testing JSON serialization/deserialization
- Faster alternative to `@WebMvcTest`

**Tests (6):**
- ✅ Should find all messages via MockMvc
- ✅ Should find message by ID via MockMvc
- ✅ Should return 404 for non-existent message
- ✅ Should create message via MockMvc
- ✅ Should validate JSON response structure
- ✅ Should perform health check via MockMvc

---

## Spring Boot Integration Tests

### Security Testing with @WithMockUser

Tests secured endpoints using Spring Security test annotations:

```java
@SpringBootTest
class SecuredControllerTest {
    @Autowired
    private WebApplicationContext webApplicationContext;

    private RestTestClient restTestClient;

    @BeforeEach
    void setUp() {
        MockMvc mockMvc = MockMvcBuilders
                .webAppContextSetup(webApplicationContext)
                .apply(springSecurity())  // Critical for @WithMockUser!
                .build();

        restTestClient = RestTestClient.bindTo(mockMvc).build();
    }

    @Test
    @WithMockUser(username = "user", roles = {"USER"})
    void shouldAllowUserRoleToGetAllMessages() {
        restTestClient.get()
                .uri("/api/secured/messages")
                .exchange()
                .expectStatus().isOk();
    }
}
```

**Tests (11):** Role-based access control validation

---

### Security Testing with Basic Auth

Tests secured endpoints using HTTP Basic Authentication:

```java
@SpringBootTest
class SecuredControllerWithBasicAuthTest {
    private String createBasicAuthHeader(String username, String password) {
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes());
        return "Basic " + new String(encodedAuth);
    }

    @Test
    void shouldAuthenticateWithUserCredentials() {
        restTestClient.get()
                .uri("/api/secured/messages")
                .header(HttpHeaders.AUTHORIZATION, createBasicAuthHeader("user", "password"))
                .exchange()
                .expectStatus().isOk();
    }
}
```

**Tests (5):** Authentication and authorization validation

---

## Quick Start

### Running the Application

```bash
# Build the project
./mvnw clean install

# Run all tests (50 tests)
./mvnw test

# Run only lightweight unit tests (17 tests, < 1 second)
./mvnw test -Dtest=PublicControllerSimpleTest,PublicControllerMockTest,PublicControllerWebMvcTest

# Run specific binding strategy
./mvnw test -Dtest=PublicControllerServerTest

# Start the application
./mvnw spring-boot:run
```

### Testing Endpoints Manually

```bash
# Public endpoint (no auth required)
curl http://localhost:8080/api/public/messages

# Secured endpoint (auth required)
curl -u user:password http://localhost:8080/api/secured/messages

# Admin-only endpoint
curl -u admin:password http://localhost:8080/api/secured/admin-only
```

---

## API Endpoints

### Public Endpoints (No Authentication)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/public/messages` | Get all public messages |
| GET | `/api/public/messages/{id}` | Get message by ID |
| POST | `/api/public/messages` | Create new message |
| GET | `/api/public/health` | Health check |

### Secured Endpoints (Role-Based)

| Method | Endpoint | Required Role | Description |
|--------|----------|---------------|-------------|
| GET | `/api/secured/messages` | USER, MANAGER, ADMIN | Get all secure messages |
| GET | `/api/secured/messages/{id}` | USER, MANAGER, ADMIN | Get secure message by ID |
| POST | `/api/secured/messages` | MANAGER, ADMIN | Create secure message |
| DELETE | `/api/secured/messages/{id}` | ADMIN | Delete secure message |
| GET | `/api/secured/admin-only` | ADMIN | Admin-only endpoint |
| GET | `/api/secured/manager-only` | MANAGER | Manager-only endpoint |

### User Credentials

| Username | Password | Role |
|----------|----------|------|
| user | password | USER |
| manager | password | MANAGER |
| admin | password | ADMIN |

---

## Running Tests

### Performance Comparison

| Test Class | Tests | Avg Time | Context Startup |
|------------|-------|----------|-----------------|
| PublicControllerSimpleTest | 6 | ~0.01s/test | None |
| PublicControllerMockTest | 5 | ~0.01s/test | None |
| PublicControllerWebMvcTest | 6 | ~0.01s/test | None |
| **Lightweight Subtotal** | **17** | **~0.1s total** | **0s** ⚡ |
| PublicControllerTest | 6 | ~0.5s/test | 3-5s |
| PublicControllerMvcTest | 2 | ~0.4s/test | Shared |
| PublicControllerIntegrationTest | 2 | ~2.4s/test | Shared |
| PublicControllerServerTest | 7 | ~0.8s/test | 3-5s |
| SecuredControllerTest | 11 | ~0.05s/test | Shared |
| SecuredControllerWithBasicAuthTest | 5 | ~0.12s/test | Shared |
| **Spring Boot Subtotal** | **33** | **~15-20s total** | **6-10s** |
| **TOTAL** | **50** | **~15-20s** | **6-10s** |

### Run Specific Test Types

```bash
# Unit tests only (fastest)
./mvnw test -Dtest=*SimpleTest,*MockTest,*WebMvcTest

# Integration tests only
./mvnw test -Dtest=*IntegrationTest

# Security tests only
./mvnw test -Dtest=SecuredController*

# E2E tests only
./mvnw test -Dtest=*ServerTest
```

---

## Key Technical Notes

### 1. RestTestClient Package

The correct import for RestTestClient in Spring Framework 7:

```java
import org.springframework.test.web.servlet.client.RestTestClient;
```

**NOT** `org.springframework.test.web.client.RestTestClient`

---

### 2. Request Body Method

Use `.body()` instead of `.bodyValue()`:

```java
// Correct ✅
restTestClient.post()
    .uri("/api/messages")
    .contentType(MediaType.APPLICATION_JSON)
    .body(myObject)
    .exchange();

// Wrong ❌ (bodyValue is WebTestClient API)
restTestClient.post()
    .uri("/api/messages")
    .bodyValue(myObject)  // This will fail
    .exchange();
```

---

### 3. Application Context Type

When using `bindToApplicationContext()`, inject `WebApplicationContext` not `ApplicationContext`:

```java
// Correct ✅
@Autowired
private WebApplicationContext webApplicationContext;

RestTestClient client = RestTestClient.bindToApplicationContext(webApplicationContext).build();

// Wrong ❌
@Autowired
private ApplicationContext applicationContext;  // Type mismatch
```

---

### 4. Security Testing Configuration

When using `@WithMockUser`, MockMvc must be configured with `springSecurity()`:

```java
// Correct ✅
MockMvc mockMvc = MockMvcBuilders
        .webAppContextSetup(webApplicationContext)
        .apply(springSecurity())  // Critical!
        .build();

// Wrong ❌ - @WithMockUser won't work
MockMvc mockMvc = MockMvcBuilders
        .webAppContextSetup(webApplicationContext)
        .build();
```

---

### 5. State Management in Tests

Use `@DirtiesContext` when tests modify shared state:

```java
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class PublicControllerServerTest {
    // Tests that create/modify data
}
```

---

### 6. MockMvc Standalone Setup

`MockMvcBuilders.standaloneSetup()` automatically configures Jackson converters:

```java
// Correct ✅ - No need to configure Jackson manually
mockMvc = MockMvcBuilders.standaloneSetup(controller).build();

// Wrong ❌ - Don't add converters manually
mockMvc = MockMvcBuilders.standaloneSetup(controller)
        .setMessageConverters(new MappingJackson2HttpMessageConverter())  // Unnecessary
        .build();
```

---

## Project Structure

```
src/main/java/com/example/demo/
├── RestTestClientDemoApplication.java   # Main application
├── config/
│   └── SecurityConfig.java              # Centralized security configuration
├── controller/
│   ├── PublicController.java            # Public endpoints
│   └── SecuredController.java           # Secured endpoints with roles
├── service/
│   └── MessageService.java              # Business logic layer
└── model/
    └── Message.java                      # Domain model

src/test/java/com/example/demo/controller/
├── PublicControllerSimpleTest.java                # No Spring, real instances
├── PublicControllerMockTest.java                  # No Spring, Mockito mocks
├── PublicControllerWebMvcTest.java                # No Spring, manual MockMvc
├── PublicControllerTest.java                      # bindToController
├── PublicControllerMvcTest.java                   # bindTo(MockMvc)
├── PublicControllerIntegrationTest.java           # bindToApplicationContext
├── PublicControllerServerTest.java                # bindToServer
├── SecuredControllerTest.java                     # @WithMockUser
└── SecuredControllerWithBasicAuthTest.java        # Basic Auth
```

---

## Architecture Decisions

### Dependency Injection for Testability

Controllers use constructor injection to enable proper unit testing:

```java
// Controller with dependency injection
@RestController
@RequestMapping("/api/public")
public class PublicController {
    private final MessageService messageService;

    public PublicController(MessageService messageService) {
        this.messageService = messageService;
    }

    // Controller methods...
}
```

**Benefits:**
- ✅ Testable with mocks
- ✅ Follows SOLID principles
- ✅ Easier to maintain
- ✅ Service logic separated from controller

---

### Centralized Security Configuration

All authorization rules are centralized in `SecurityConfig.java` using HTTP method-specific `requestMatchers()`:

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(auth -> auth
            .requestMatchers("/api/public/**").permitAll()

            // GET operations - USER, MANAGER, ADMIN
            .requestMatchers(HttpMethod.GET, "/api/secured/messages").hasAnyRole("USER", "MANAGER", "ADMIN")

            // POST operations - MANAGER, ADMIN
            .requestMatchers(HttpMethod.POST, "/api/secured/messages").hasAnyRole("MANAGER", "ADMIN")

            // DELETE operations - ADMIN only
            .requestMatchers(HttpMethod.DELETE, "/api/secured/messages/**").hasRole("ADMIN")

            // Role-specific endpoints
            .requestMatchers("/api/secured/admin-only").hasRole("ADMIN")
            .requestMatchers("/api/secured/manager-only").hasRole("MANAGER")

            .anyRequest().authenticated()
        )
        .httpBasic(Customizer.withDefaults())
        .csrf(csrf -> csrf.disable());

        return http.build();
    }
}
```

**Benefits:**
- ✅ No `@PreAuthorize` annotations on controllers
- ✅ No `@EnableMethodSecurity` required
- ✅ All security rules in one place
- ✅ Easier to audit and maintain

---

## Common Patterns

### Deserializing Responses

```java
// Single object
Message message = restTestClient.get()
    .uri("/api/messages/1")
    .exchange()
    .expectStatus().isOk()
    .expectBody(Message.class)
    .returnResult()
    .getResponseBody();

// List of objects
List<Message> messages = restTestClient.get()
    .uri("/api/messages")
    .exchange()
    .expectStatus().isOk()
    .expectBody(new ParameterizedTypeReference<List<Message>>() {})
    .returnResult()
    .getResponseBody();
```

### JSON Path Assertions

```java
restTestClient.get()
    .uri("/api/messages")
    .exchange()
    .expectStatus().isOk()
    .expectBody()
    .jsonPath("$").isArray()
    .jsonPath("$.length()").isEqualTo(3)
    .jsonPath("$[0].id").exists()
    .jsonPath("$[0].content").isNotEmpty();
```

### POST Requests with JSON

```java
String requestBody = """
        {
            "content": "New message",
            "author": "Author"
        }
        """;

restTestClient.post()
    .uri("/api/messages")
    .contentType(MediaType.APPLICATION_JSON)
    .body(requestBody)
    .exchange()
    .expectStatus().isCreated()
    .expectBody()
    .jsonPath("$.id").exists();
```

---

## Best Practices

### 1. Follow the Test Pyramid

- **70%** Unit tests (Simple, Mock, WebMvc, bindToController)
- **20%** Integration tests (bindTo MockMvc)
- **7%** Full integration (bindToApplicationContext)
- **3%** E2E tests (bindToServer)

### 2. Start with Fast Tests

Begin with lightweight unit tests (`PublicControllerSimpleTest` pattern) for:
- TDD and fast feedback
- Testing controller logic
- Maximum development speed

### 3. Add MVC Tests for HTTP Features

Use `PublicControllerWebMvcTest` or `bindTo(MockMvc)` for:
- Request/response processing
- JSON serialization
- HTTP-specific features

### 4. Reserve Integration Tests

Only use `@SpringBootTest` when:
- Testing multiple components together
- Need actual Spring configuration
- Testing security integration
- End-to-end scenarios

### 5. Minimize E2E Tests

Use `bindToServer()` sparingly for:
- Smoke tests before deployment
- Critical user journeys
- API contract verification

---

## Dependencies

```xml
<dependencies>
    <!-- Spring Boot 4.0.0 includes Spring Framework 7 -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-security</artifactId>
    </dependency>

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>

    <dependency>
        <groupId>org.springframework.security</groupId>
        <artifactId>spring-security-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

---

## References

- [Spring RestTestClient Documentation](https://docs.spring.io/spring-framework/reference/testing/resttestclient.html)
- [Dan Vega's RestTestClient Guide](https://www.danvega.dev/blog/spring-framework-7-rest-test-client)
- [Reference Example Repository](https://github.com/danvega/rest-test-client)
- [Spring Security Testing](https://docs.spring.io/spring-security/reference/servlet/test/index.html)
- [Testing Spring Boot Applications](https://docs.spring.io/spring-boot/reference/testing/index.html)

---

## License

This is a demo project for educational purposes.
