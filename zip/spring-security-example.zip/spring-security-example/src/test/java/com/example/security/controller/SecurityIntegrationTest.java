package com.example.security.controller;

import static org.hamcrest.Matchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.example.security.test.WithMockCustomUser;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class SecurityIntegrationTest {

    @Autowired private MockMvc mockMvc;

    // Public endpoint tests
    @Test
    void publicEndpoint_WithoutAuthentication_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/public/welcome"))
                .andExpect(status().isOk())
                .andExpect(content().string("Welcome! This endpoint is publicly accessible"));
    }

    @Test
    void publicInfo_WithoutAuthentication_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/public/info"))
                .andExpect(status().isOk())
                .andExpect(
                        content()
                                .string(
                                        containsString(
                                                "Application info - No authentication required")));
    }

    // User endpoint tests
    @Test
    void userEndpoint_WithoutAuthentication_ReturnsUnauthorized() throws Exception {
        mockMvc.perform(get("/api/user/profile")).andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(roles = "USER")
    void userProfile_WithUserRole_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/user/profile"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("User profile for:")));
    }

    @Test
    @WithMockUser(roles = "USER")
    void userAuthorities_WithUserRole_ReturnsAuthorities() throws Exception {
        mockMvc.perform(get("/api/user/authorities"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Current user authorities:")));
    }

    // Admin endpoint tests
    @Test
    @WithMockUser(roles = "USER")
    void adminEndpoint_WithUserRole_ReturnsForbidden() throws Exception {
        mockMvc.perform(get("/api/admin/data")).andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void adminData_WithAdminRole_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/admin/data"))
                .andExpect(status().isOk())
                .andExpect(
                        content()
                                .string(
                                        containsString(
                                                "Admin data - accessible only to administrators")));
    }

    @Test
    @WithMockCustomUser(
            roles = {"ADMIN"},
            authorities = {"MANAGE_USERS"})
    void adminUsers_WithManageUsersPermission_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/admin/users"))
                .andExpect(status().isOk())
                .andExpect(
                        content()
                                .string(
                                        containsString(
                                                "Managing users - requires MANAGE_USERS permission")));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void adminUsers_WithoutManageUsersPermission_ReturnsForbidden() throws Exception {
        mockMvc.perform(get("/api/admin/users")).andExpect(status().isForbidden());
    }

    // Manager endpoint tests
    @Test
    @WithMockUser(roles = "MANAGER")
    void managerData_WithManagerRole_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/manager/data"))
                .andExpect(status().isOk())
                .andExpect(
                        content()
                                .string(
                                        containsString(
                                                "Management data - accessible to admins or managers")));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void managerData_WithAdminRole_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/manager/data"))
                .andExpect(status().isOk())
                .andExpect(
                        content()
                                .string(
                                        containsString(
                                                "Management data - accessible to admins or managers")));
    }

    @Test
    @WithMockUser(roles = "USER")
    void managerData_WithUserRole_ReturnsForbidden() throws Exception {
        mockMvc.perform(get("/api/manager/data")).andExpect(status().isForbidden());
    }

    // Moderator endpoint tests
    @Test
    @WithMockUser(roles = "MODERATOR")
    void moderatorContent_WithModeratorRole_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/moderator/content"))
                .andExpect(status().isOk())
                .andExpect(
                        content()
                                .string(
                                        containsString(
                                                "Moderated content - accessible to admins and moderators")));
    }

    // Demo endpoint tests
    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    void demoEndpoints_WithAuthentication_ReturnsEndpointsList() throws Exception {
        mockMvc.perform(get("/api/demo/endpoints"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", is(instanceOf(java.util.Map.class))))
                .andExpect(
                        jsonPath("$.['GET /api/public/welcome']", is("Public - No auth required")));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    void demoCurrentUser_WithAuthentication_ReturnsUserInfo() throws Exception {
        mockMvc.perform(get("/api/demo/current-user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username", is("testuser")))
                .andExpect(jsonPath("$.authenticated", is(true)))
                .andExpect(jsonPath("$.authorities", hasSize(greaterThan(0))));
    }

    // Basic Auth tests
    @Test
    void userEndpoint_WithBasicAuth_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/user/profile").with(httpBasic("user", "password")))
                .andExpect(status().isOk());
    }

    @Test
    void adminEndpoint_WithBasicAuthAdmin_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/api/admin/data").with(httpBasic("admin", "admin")))
                .andExpect(status().isOk());
    }

    @Test
    void adminEndpoint_WithBasicAuthUser_ReturnsForbidden() throws Exception {
        mockMvc.perform(get("/api/admin/data").with(httpBasic("user", "password")))
                .andExpect(status().isForbidden());
    }

    // Web UI endpoint tests
    @Test
    void loginPage_WithoutAuthentication_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/login")).andExpect(status().isOk()).andExpect(view().name("login"));
    }

    @Test
    @WithMockCustomUser
    void dashboard_WithAuthentication_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/dashboard"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"));
    }

    @Test
    void dashboard_WithoutAuthentication_ReturnsUnauthorized() throws Exception {
        mockMvc.perform(get("/dashboard")).andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockCustomUser
    void shipments_WithAuthentication_ReturnsSuccess() throws Exception {
        mockMvc.perform(get("/shipments"))
                .andExpect(status().isOk())
                .andExpect(view().name("shipments"));
    }

    // Error handling tests
    @Test
    void nonExistentEndpoint_ReturnsUnauthorized() throws Exception {
        mockMvc.perform(get("/api/nonexistent")).andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(roles = "USER")
    void unauthorizedMethodCall_ReturnsForbidden() throws Exception {
        mockMvc.perform(post("/api/admin/data")).andExpect(status().isForbidden());
    }
}
