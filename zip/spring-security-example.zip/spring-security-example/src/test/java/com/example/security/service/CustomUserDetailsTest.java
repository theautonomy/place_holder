package com.example.security.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Collection;
import java.util.Set;

import com.example.security.model.Permission;
import com.example.security.model.Role;
import com.example.security.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

class CustomUserDetailsTest {

    private User user;
    private Collection<GrantedAuthority> authorities;
    private CustomUserDetails customUserDetails;

    @BeforeEach
    void setUp() {
        user =
                new User(
                        "testuser",
                        "password123",
                        Set.of(Role.USER, Role.ADMIN),
                        Set.of(Permission.READ, Permission.WRITE),
                        "corp.example.com");

        authorities =
                Set.of(
                        new SimpleGrantedAuthority("ROLE_USER"),
                        new SimpleGrantedAuthority("ROLE_ADMIN"),
                        new SimpleGrantedAuthority("READ"),
                        new SimpleGrantedAuthority("WRITE"));

        customUserDetails = new CustomUserDetails(user, authorities);
    }

    @Test
    void getUser_ReturnsCorrectUser() {
        // When
        User result = customUserDetails.getUser();

        // Then
        assertSame(user, result);
    }

    @Test
    void getCompanyDomain_ReturnsCorrectDomain() {
        // When
        String result = customUserDetails.getCompanyDomain();

        // Then
        assertEquals("corp.example.com", result);
    }

    @Test
    void getCompanyDomain_WithNullDomain_ReturnsNull() {
        // Given
        User userWithNullDomain =
                new User(
                        "testuser",
                        "password123",
                        Set.of(Role.USER),
                        Set.of(Permission.READ),
                        null);
        CustomUserDetails userDetailsWithNullDomain =
                new CustomUserDetails(userWithNullDomain, authorities);

        // When
        String result = userDetailsWithNullDomain.getCompanyDomain();

        // Then
        assertNull(result);
    }

    @Test
    void getAuthorities_ReturnsCorrectAuthorities() {
        // When
        Collection<? extends GrantedAuthority> result = customUserDetails.getAuthorities();

        // Then
        assertEquals(authorities, result);
        assertTrue(result.contains(new SimpleGrantedAuthority("ROLE_USER")));
        assertTrue(result.contains(new SimpleGrantedAuthority("ROLE_ADMIN")));
        assertTrue(result.contains(new SimpleGrantedAuthority("READ")));
        assertTrue(result.contains(new SimpleGrantedAuthority("WRITE")));
    }

    @Test
    void getPassword_ReturnsCorrectPassword() {
        // When
        String result = customUserDetails.getPassword();

        // Then
        assertEquals("password123", result);
    }

    @Test
    void getUsername_ReturnsCorrectUsername() {
        // When
        String result = customUserDetails.getUsername();

        // Then
        assertEquals("testuser", result);
    }

    @Test
    void isAccountNonExpired_ReturnsTrue() {
        // When
        boolean result = customUserDetails.isAccountNonExpired();

        // Then
        assertTrue(result);
    }

    @Test
    void isAccountNonLocked_ReturnsTrue() {
        // When
        boolean result = customUserDetails.isAccountNonLocked();

        // Then
        assertTrue(result);
    }

    @Test
    void isCredentialsNonExpired_ReturnsTrue() {
        // When
        boolean result = customUserDetails.isCredentialsNonExpired();

        // Then
        assertTrue(result);
    }

    @Test
    void isEnabled_WhenUserIsEnabled_ReturnsTrue() {
        // Given
        user.setEnabled(true);

        // When
        boolean result = customUserDetails.isEnabled();

        // Then
        assertTrue(result);
    }

    @Test
    void isEnabled_WhenUserIsDisabled_ReturnsFalse() {
        // Given
        user.setEnabled(false);

        // When
        boolean result = customUserDetails.isEnabled();

        // Then
        assertFalse(result);
    }

    @Test
    void constructor_WithNullUser_DoesNotThrowException() {
        // When & Then
        assertDoesNotThrow(() -> new CustomUserDetails(null, authorities));
    }

    @Test
    void constructor_WithNullAuthorities_DoesNotThrowException() {
        // When & Then
        assertDoesNotThrow(() -> new CustomUserDetails(user, null));
    }

    @Test
    void getCompanyDomain_WithNullUser_ThrowsNullPointerException() {
        // Given
        CustomUserDetails userDetailsWithNullUser = new CustomUserDetails(null, authorities);

        // When & Then
        assertThrows(NullPointerException.class, userDetailsWithNullUser::getCompanyDomain);
    }
}
