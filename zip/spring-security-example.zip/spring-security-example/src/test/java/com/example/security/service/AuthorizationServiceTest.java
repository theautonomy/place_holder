package com.example.security.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Set;

import com.example.security.model.Permission;
import com.example.security.model.Role;
import com.example.security.model.User;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
class AuthorizationServiceTest {

    @InjectMocks private AuthorizationService authorizationService;

    private SecurityContext securityContext;
    private Authentication authentication;
    private CustomUserDetails customUserDetails;
    private User user;

    @BeforeEach
    void setUp() {
        securityContext = mock(SecurityContext.class);
        authentication = mock(Authentication.class);
        user =
                new User(
                        "admin",
                        "password",
                        Set.of(Role.USER),
                        Set.of(Permission.READ),
                        "corp.example.com");
        customUserDetails = new CustomUserDetails(user, Set.of());
    }

    @Test
    void getCurrentUserDomain_WithValidUser_ReturnsUserDomain() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(true);
            when(authentication.getName()).thenReturn("admin");

            // When
            String result = authorizationService.getCurrentUserDomain();

            // Then
            assertEquals("corp.example.com", result);
        }
    }

    @Test
    void getCurrentUserDomain_WithUnauthenticatedUser_ReturnsUnknownDomain() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(false);

            // When
            String result = authorizationService.getCurrentUserDomain();

            // Then
            assertEquals("unknown.com", result);
        }
    }

    @Test
    void getCurrentUserDomain_WithNullAuthentication_ReturnsUnknownDomain() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(null);

            // When
            String result = authorizationService.getCurrentUserDomain();

            // Then
            assertEquals("unknown.com", result);
        }
    }

    @Test
    void hasAllowedDomain_WithMatchingDomain_ReturnsTrue() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(true);
            when(authentication.getName()).thenReturn("admin");

            String[] allowedDomains = {"corp.example.com", "example.com"};

            // When
            boolean result = authorizationService.hasAllowedDomain(allowedDomains);

            // Then
            assertTrue(result);
        }
    }

    @Test
    void hasAllowedDomain_WithNonMatchingDomain_ReturnsFalse() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(true);
            when(authentication.getName()).thenReturn("admin");

            String[] allowedDomains = {"other.com", "example.com"};

            // When
            boolean result = authorizationService.hasAllowedDomain(allowedDomains);

            // Then
            assertFalse(result);
        }
    }

    @Test
    void hasAllowedDomain_WithUnknownUser_ReturnsFalse() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(true);
            when(authentication.getName()).thenReturn("unknownuser");

            String[] allowedDomains = {"corp.example.com", "example.com"};

            // When
            boolean result = authorizationService.hasAllowedDomain(allowedDomains);

            // Then
            assertFalse(result);
        }
    }

    @Test
    void hasAllowedDomain_WithEmptyAllowedDomains_ReturnsFalse() {
        // Given
        String[] allowedDomains = {};

        // When
        boolean result = authorizationService.hasAllowedDomain(allowedDomains);

        // Then
        assertFalse(result);
    }

    @Test
    void hasAllowedDomain_WithNullAllowedDomains_ReturnsFalse() {
        // When
        boolean result = authorizationService.hasAllowedDomain(null);

        // Then
        assertFalse(result);
    }

    @Test
    void hasAllowedDomain_ExactDomainMatch_ReturnsTrue() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(true);
            when(authentication.getName()).thenReturn("admin");

            String[] allowedDomains = {"corp.example.com"};

            // When
            boolean result = authorizationService.hasAllowedDomain(allowedDomains);

            // Then
            assertTrue(result);
        }
    }

    @Test
    void canAccessResource_WithMatchingDomain_ReturnsTrue() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(true);
            when(authentication.getName()).thenReturn("admin");

            // When
            boolean result = authorizationService.canAccessResource("corp.example.com");

            // Then
            assertTrue(result);
        }
    }

    @Test
    void canAccessResource_WithNonMatchingDomain_ReturnsFalse() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.isAuthenticated()).thenReturn(true);
            when(authentication.getName()).thenReturn("admin");

            // When
            boolean result = authorizationService.canAccessResource("other.com");

            // Then
            assertFalse(result);
        }
    }
}
