package com.example.security.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.example.security.model.Permission;
import com.example.security.model.Role;
import com.example.security.model.User;
import com.example.security.service.CustomUserDetails;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.test.context.support.WithSecurityContextFactory;

public class WithMockCustomUserSecurityContextFactory
        implements WithSecurityContextFactory<WithMockCustomUser> {

    @Override
    public SecurityContext createSecurityContext(WithMockCustomUser annotation) {
        SecurityContext context = SecurityContextHolder.createEmptyContext();

        // Create roles from annotation
        Set<Role> roles =
                Arrays.stream(annotation.roles()).map(Role::valueOf).collect(Collectors.toSet());

        // Create permissions (simplified - just use READ for basic tests)
        Set<Permission> permissions = new HashSet<>();
        permissions.add(Permission.READ);
        if (roles.contains(Role.ADMIN)) {
            permissions.addAll(Arrays.asList(Permission.values()));
        }

        // Create User entity
        User user =
                new User(
                        annotation.username(),
                        annotation.password(),
                        roles,
                        permissions,
                        annotation.companyDomain());

        // Create authorities for Spring Security
        List<GrantedAuthority> authorities = new ArrayList<>();

        // Add role authorities
        for (Role role : roles) {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role.name()));
        }

        // Add permission authorities
        for (Permission permission : permissions) {
            authorities.add(new SimpleGrantedAuthority(permission.name()));
        }

        // Add custom authorities from annotation
        for (String authority : annotation.authorities()) {
            authorities.add(new SimpleGrantedAuthority(authority));
        }

        // Create CustomUserDetails
        CustomUserDetails userDetails = new CustomUserDetails(user, new HashSet<>(authorities));

        // Create authentication
        Authentication auth =
                new UsernamePasswordAuthenticationToken(
                        userDetails, annotation.password(), authorities);

        context.setAuthentication(auth);
        return context;
    }
}
