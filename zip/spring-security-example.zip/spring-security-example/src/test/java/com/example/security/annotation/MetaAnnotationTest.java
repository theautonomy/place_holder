package com.example.security.annotation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import com.example.security.model.Permission;
import com.example.security.model.Role;
import com.example.security.model.Shipment;
import com.example.security.model.User;
import com.example.security.repository.ShipmentRepositoryV2;
import com.example.security.service.AuthorizationService;
import com.example.security.service.CustomUserDetails;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringBootTest
@SpringJUnitConfig
class MetaAnnotationTest {

    @MockBean private AuthorizationService authorizationService;

    @Autowired private ShipmentRepositoryV2 shipmentRepositoryV2;

    private SecurityContext securityContext;
    private Authentication authentication;
    private CustomUserDetails adminUserDetails;
    private CustomUserDetails managerUserDetails;
    private CustomUserDetails moderatorUserDetails;

    @BeforeEach
    void setUp() {
        securityContext = mock(SecurityContext.class);
        authentication = mock(Authentication.class);

        User adminUser =
                new User(
                        "admin",
                        "password",
                        Set.of(Role.ADMIN),
                        Set.of(Permission.READ),
                        "corp.example.com");
        User managerUser =
                new User(
                        "manager",
                        "password",
                        Set.of(Role.MANAGER),
                        Set.of(Permission.READ),
                        "example.com");
        User moderatorUser =
                new User(
                        "moderator",
                        "password",
                        Set.of(Role.MODERATOR),
                        Set.of(Permission.READ),
                        "other.com");

        adminUserDetails = new CustomUserDetails(adminUser, Set.of());
        managerUserDetails = new CustomUserDetails(managerUser, Set.of());
        moderatorUserDetails = new CustomUserDetails(moderatorUser, Set.of());
    }

    @Test
    void allDomainsAnnotation_ReflectionCheck_HasCorrectPreAuthorize()
            throws NoSuchMethodException {
        // Given
        Method method = TestService.class.getMethod("allDomainsMethod");

        // When
        AllDomains annotation = method.getAnnotation(AllDomains.class);

        // Then
        assertNotNull(annotation);

        // Check if the annotation has the PreAuthorize meta-annotation
        assertTrue(
                AllDomains.class.isAnnotationPresent(
                        org.springframework.security.access.prepost.PreAuthorize.class));
    }

    @Test
    void corporateOnlyAnnotation_ReflectionCheck_HasCorrectPreAuthorize()
            throws NoSuchMethodException {
        // Given
        Method method = TestService.class.getMethod("corporateOnlyMethod");

        // When
        CorporateOnly annotation = method.getAnnotation(CorporateOnly.class);

        // Then
        assertNotNull(annotation);
        assertTrue(
                CorporateOnly.class.isAnnotationPresent(
                        org.springframework.security.access.prepost.PreAuthorize.class));
    }

    @Test
    void exampleComOnlyAnnotation_ReflectionCheck_HasCorrectPreAuthorize()
            throws NoSuchMethodException {
        // Given
        Method method = TestService.class.getMethod("exampleComOnlyMethod");

        // When
        ExampleComOnly annotation = method.getAnnotation(ExampleComOnly.class);

        // Then
        assertNotNull(annotation);
        assertTrue(
                ExampleComOnly.class.isAnnotationPresent(
                        org.springframework.security.access.prepost.PreAuthorize.class));
    }

    @Test
    void otherComOnlyAnnotation_ReflectionCheck_HasCorrectPreAuthorize()
            throws NoSuchMethodException {
        // Given
        Method method = TestService.class.getMethod("otherComOnlyMethod");

        // When
        OtherComOnly annotation = method.getAnnotation(OtherComOnly.class);

        // Then
        assertNotNull(annotation);
        assertTrue(
                OtherComOnly.class.isAnnotationPresent(
                        org.springframework.security.access.prepost.PreAuthorize.class));
    }

    @Test
    void findAllWithHasDomainMeta_WithAuthorizedUser_ReturnsShipments() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getPrincipal()).thenReturn(adminUserDetails);
            when(authorizationService.hasAllowedDomain(
                            new String[] {"corp.example.com", "example.com"}))
                    .thenReturn(true);

            // When
            List<Shipment> result = shipmentRepositoryV2.findAllWithHasDomainMeta();

            // Then
            assertNotNull(result);
            assertFalse(result.isEmpty());
            verify(authorizationService)
                    .hasAllowedDomain(new String[] {"corp.example.com", "example.com"});
        }
    }

    @Test
    void findCorporateOnlyWithHasDomainMeta_WithCorporateUser_ReturnsShipments() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getPrincipal()).thenReturn(adminUserDetails);
            when(authorizationService.hasAllowedDomain(new String[] {"corp.example.com"}))
                    .thenReturn(true);

            // When
            List<Shipment> result = shipmentRepositoryV2.findCorporateOnlyWithHasDomainMeta();

            // Then
            assertNotNull(result);
            // Should only contain corporate shipments
            assertTrue(
                    result.stream().allMatch(s -> "corp.example.com".equals(s.getCompanyDomain())));
            verify(authorizationService).hasAllowedDomain(new String[] {"corp.example.com"});
        }
    }

    @Test
    void findCorporateOnlyWithHasDomainMeta_WithNonCorporateUser_ThrowsAccessDeniedException() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getPrincipal()).thenReturn(managerUserDetails);
            when(authorizationService.hasAllowedDomain(new String[] {"corp.example.com"}))
                    .thenReturn(false);

            // When & Then
            assertThrows(
                    AccessDeniedException.class,
                    () -> {
                        shipmentRepositoryV2.findCorporateOnlyWithHasDomainMeta();
                    });

            verify(authorizationService).hasAllowedDomain(new String[] {"corp.example.com"});
        }
    }

    @Test
    void findExampleComOnlyWithHasDomainMeta_WithExampleComUser_ReturnsShipments() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getPrincipal()).thenReturn(managerUserDetails);
            when(authorizationService.hasAllowedDomain(new String[] {"example.com"}))
                    .thenReturn(true);

            // When
            List<Shipment> result = shipmentRepositoryV2.findExampleComOnlyWithHasDomainMeta();

            // Then
            assertNotNull(result);
            assertTrue(result.stream().allMatch(s -> "example.com".equals(s.getCompanyDomain())));
            verify(authorizationService).hasAllowedDomain(new String[] {"example.com"});
        }
    }

    @Test
    void findOtherComOnlyWithHasDomainMeta_WithOtherComUser_ReturnsShipments() {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getPrincipal()).thenReturn(moderatorUserDetails);
            when(authorizationService.hasAllowedDomain(new String[] {"other.com"}))
                    .thenReturn(true);

            // When
            List<Shipment> result = shipmentRepositoryV2.findOtherComOnlyWithHasDomainMeta();

            // Then
            assertNotNull(result);
            assertTrue(result.stream().allMatch(s -> "other.com".equals(s.getCompanyDomain())));
            verify(authorizationService).hasAllowedDomain(new String[] {"other.com"});
        }
    }

    @Test
    void metaAnnotations_CorrectSpELExpressions_ArePresent() {
        // Check AllDomains
        org.springframework.security.access.prepost.PreAuthorize allDomainsPreAuth =
                AllDomains.class.getAnnotation(
                        org.springframework.security.access.prepost.PreAuthorize.class);
        assertEquals(
                "@authorizationService.hasAllowedDomain({'corp.example.com', 'example.com'})",
                allDomainsPreAuth.value());

        // Check CorporateOnly
        org.springframework.security.access.prepost.PreAuthorize corpPreAuth =
                CorporateOnly.class.getAnnotation(
                        org.springframework.security.access.prepost.PreAuthorize.class);
        assertEquals(
                "@authorizationService.hasAllowedDomain({'corp.example.com'})",
                corpPreAuth.value());

        // Check ExampleComOnly
        org.springframework.security.access.prepost.PreAuthorize examplePreAuth =
                ExampleComOnly.class.getAnnotation(
                        org.springframework.security.access.prepost.PreAuthorize.class);
        assertEquals(
                "@authorizationService.hasAllowedDomain({'example.com'})", examplePreAuth.value());

        // Check OtherComOnly
        org.springframework.security.access.prepost.PreAuthorize otherPreAuth =
                OtherComOnly.class.getAnnotation(
                        org.springframework.security.access.prepost.PreAuthorize.class);
        assertEquals("@authorizationService.hasAllowedDomain({'other.com'})", otherPreAuth.value());
    }

    // Test service to verify annotation reflection
    public static class TestService {
        @AllDomains
        public void allDomainsMethod() {}

        @CorporateOnly
        public void corporateOnlyMethod() {}

        @ExampleComOnly
        public void exampleComOnlyMethod() {}

        @OtherComOnly
        public void otherComOnlyMethod() {}
    }
}
