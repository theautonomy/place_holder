package com.example.security.aspect;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

import com.example.security.annotation.HasDomain;
import com.example.security.handler.NullAuthorizationHandler;
import com.example.security.model.Shipment;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
class DomainSecurityAspectTest {

    @Mock private NullAuthorizationHandler nullHandler;

    @Mock private ProceedingJoinPoint joinPoint;

    @Mock private MethodSignature methodSignature;

    @Mock private HasDomain hasDomain;

    @Mock private SecurityContext securityContext;

    @Mock private Authentication authentication;

    private DomainSecurityAspect domainSecurityAspect;

    private List<Shipment> testShipments;

    @BeforeEach
    void setUp() {
        domainSecurityAspect = new DomainSecurityAspect(nullHandler);
        testShipments =
                Arrays.asList(
                        new Shipment(
                                "TRK001",
                                "New York",
                                "Los Angeles",
                                "SHIPPED",
                                "corp.example.com",
                                "admin"),
                        new Shipment(
                                "TRK002",
                                "Chicago",
                                "Miami",
                                "DELIVERED",
                                "example.com",
                                "manager"),
                        new Shipment(
                                "TRK003",
                                "Seattle",
                                "Denver",
                                "IN_TRANSIT",
                                "other.com",
                                "moderator"));
    }

    @Test
    void checkDomain_WithAuthorizedUser_ProceedsAndReturnsResult() throws Throwable {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            String[] allowedDomains = {"corp.example.com", "example.com"};
            when(hasDomain.domains()).thenReturn(allowedDomains);
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("admin");
            when(joinPoint.proceed()).thenReturn(testShipments);
            when(joinPoint.getSignature()).thenReturn(methodSignature);
            when(methodSignature.getName()).thenReturn("getAllShipments");
            when(joinPoint.getTarget()).thenReturn(new TestService());
            when(joinPoint.getArgs()).thenReturn(new Object[0]);

            // When
            Object result = domainSecurityAspect.checkDomain(joinPoint, hasDomain);

            // Then
            assertEquals(testShipments, result);
            verify(joinPoint).proceed();
        }
    }

    @Test
    void checkDomain_WithUnauthorizedUser_ThrowsAccessDeniedException() throws Throwable {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            String[] allowedDomains = {"corp.example.com"};
            when(hasDomain.domains()).thenReturn(allowedDomains);
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("moderator"); // other.com domain
            when(joinPoint.getSignature()).thenReturn(methodSignature);
            when(methodSignature.getName()).thenReturn("getAllShipments");
            when(joinPoint.getTarget()).thenReturn(new TestService());
            when(joinPoint.getArgs()).thenReturn(new Object[0]);

            // When & Then
            assertThrows(
                    AccessDeniedException.class,
                    () -> {
                        domainSecurityAspect.checkDomain(joinPoint, hasDomain);
                    });

            verify(joinPoint, never()).proceed();
        }
    }

    @Test
    void checkDomain_WithEmptyDomains_ThrowsAccessDeniedException() throws Throwable {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            String[] allowedDomains = {};
            when(hasDomain.domains()).thenReturn(allowedDomains);
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("admin");
            when(joinPoint.getSignature()).thenReturn(methodSignature);
            when(methodSignature.getName()).thenReturn("getAllShipments");
            when(joinPoint.getTarget()).thenReturn(new TestService());
            when(joinPoint.getArgs()).thenReturn(new Object[0]);

            // When & Then
            assertThrows(
                    AccessDeniedException.class,
                    () -> {
                        domainSecurityAspect.checkDomain(joinPoint, hasDomain);
                    });

            verify(joinPoint, never()).proceed();
        }
    }

    @Test
    void checkDomain_WhenJoinPointThrowsException_PropagatesException() throws Throwable {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given
            String[] allowedDomains = {"corp.example.com"};
            when(hasDomain.domains()).thenReturn(allowedDomains);
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("admin");

            RuntimeException expectedException = new RuntimeException("Test exception");
            when(joinPoint.proceed()).thenThrow(expectedException);

            // When & Then
            RuntimeException actualException =
                    assertThrows(
                            RuntimeException.class,
                            () -> {
                                domainSecurityAspect.checkDomain(joinPoint, hasDomain);
                            });

            assertEquals(expectedException, actualException);
            verify(joinPoint).proceed();
        }
    }

    @Test
    void checkDomain_WithAuthorizationAndFiltering_AppliesCorrectLogic() throws Throwable {
        try (MockedStatic<SecurityContextHolder> mockedSecurityContextHolder =
                mockStatic(SecurityContextHolder.class)) {
            // Given - Test the complete flow
            String[] allowedDomains = {"corp.example.com"};
            when(hasDomain.domains()).thenReturn(allowedDomains);
            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
            when(securityContext.getAuthentication()).thenReturn(authentication);
            when(authentication.getName()).thenReturn("admin");
            when(joinPoint.proceed()).thenReturn(testShipments);
            when(joinPoint.getSignature()).thenReturn(methodSignature);
            when(methodSignature.getName()).thenReturn("getAllShipments");
            when(joinPoint.getTarget()).thenReturn(new TestService());
            when(joinPoint.getArgs()).thenReturn(new Object[0]);

            // When
            Object result = domainSecurityAspect.checkDomain(joinPoint, hasDomain);

            // Then
            assertNotNull(result);
            verify(joinPoint).proceed();
        }
    }

    // Helper class for test method resolution
    public static class TestService {
        public Object getAllShipments() {
            return null;
        }
    }

    @Test
    void extractDomainFromUsername_WithEmailFormat_ExtractsDomain() throws Exception {
        // This test uses reflection to access the private method for testing
        Method extractDomainMethod =
                DomainSecurityAspect.class.getDeclaredMethod(
                        "extractDomainFromUsername", String.class);
        extractDomainMethod.setAccessible(true);

        // When
        String result =
                (String) extractDomainMethod.invoke(domainSecurityAspect, "user@corp.example.com");

        // Then
        assertEquals("corp.example.com", result);
    }

    @Test
    void extractDomainFromUsername_WithAdminUser_ReturnsCorrectDomain() throws Exception {
        // This test uses reflection to access the private method for testing
        Method extractDomainMethod =
                DomainSecurityAspect.class.getDeclaredMethod(
                        "extractDomainFromUsername", String.class);
        extractDomainMethod.setAccessible(true);

        // When
        String result = (String) extractDomainMethod.invoke(domainSecurityAspect, "admin");

        // Then
        assertEquals("corp.example.com", result);
    }

    @Test
    void extractDomainFromUsername_WithManagerUser_ReturnsCorrectDomain() throws Exception {
        // This test uses reflection to access the private method for testing
        Method extractDomainMethod =
                DomainSecurityAspect.class.getDeclaredMethod(
                        "extractDomainFromUsername", String.class);
        extractDomainMethod.setAccessible(true);

        // When
        String result = (String) extractDomainMethod.invoke(domainSecurityAspect, "manager");

        // Then
        assertEquals("example.com", result);
    }

    @Test
    void extractDomainFromUsername_WithUnknownUser_ReturnsUnknownDomain() throws Exception {
        // This test uses reflection to access the private method for testing
        Method extractDomainMethod =
                DomainSecurityAspect.class.getDeclaredMethod(
                        "extractDomainFromUsername", String.class);
        extractDomainMethod.setAccessible(true);

        // When
        String result = (String) extractDomainMethod.invoke(domainSecurityAspect, "unknown");

        // Then
        assertEquals("unknown.com", result);
    }

    @Test
    void filterResultByDomain_WithShipmentList_FiltersCorrectly() throws Exception {
        // This test uses reflection to access the private method for testing
        Method filterMethod =
                DomainSecurityAspect.class.getDeclaredMethod(
                        "filterResultByDomain", Object.class, String.class);
        filterMethod.setAccessible(true);

        // When
        @SuppressWarnings("unchecked")
        List<Shipment> result =
                (List<Shipment>)
                        filterMethod.invoke(
                                domainSecurityAspect, testShipments, "corp.example.com");

        // Then
        assertEquals(1, result.size());
        assertEquals("corp.example.com", result.get(0).getCompanyDomain());
    }
}
