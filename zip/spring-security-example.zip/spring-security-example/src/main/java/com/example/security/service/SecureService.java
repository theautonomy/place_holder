package com.example.security.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import jakarta.annotation.security.RolesAllowed;

@Service
public class SecureService {

    @PreAuthorize("hasRole('USER')")
    public String getUserData() {
        return "User data - accessible to users with USER role";
    }

    @PreAuthorize("hasRole('ADMIN')")
    public String getAdminData() {
        return "Admin data - accessible only to administrators";
    }

    @PreAuthorize("hasAuthority('MANAGE_USERS')")
    public String manageUsers() {
        return "Managing users - requires MANAGE_USERS permission";
    }

    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String getManagementData() {
        return "Management data - accessible to admins or managers";
    }

    @Secured({"ROLE_ADMIN", "ROLE_MODERATOR"})
    public String getModeratedContent() {
        return "Moderated content - accessible to admins and moderators using @Secured";
    }

    @RolesAllowed({"ADMIN", "MANAGER"})
    public String getExecutiveData() {
        return "Executive data - accessible using JSR-250 @RolesAllowed";
    }

    @PreAuthorize("hasAuthority('READ')")
    @PostAuthorize("returnObject.contains(authentication.name)")
    public String getPersonalData() {
        return "Personal data for user: " + getCurrentUsername();
    }

    @PreAuthorize("hasAuthority('VIEW_REPORTS') and hasRole('MANAGER')")
    public List<String> getReports() {
        return Arrays.asList("Q1 Sales Report", "Q2 Performance Report", "Annual Review");
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER') and hasAuthority('EXPORT_DATA')")
    public String exportData() {
        return "Data exported successfully - requires admin/manager role AND export permission";
    }

    @PreAuthorize("authentication.name == #username")
    public String getOwnProfile(String username) {
        return "Profile data for: " + username;
    }

    @PreAuthorize("#request.userId == authentication.principal.id")
    public String processRequest(UserRequest request) {
        return "Processing request for user: " + request.getUserId();
    }

    private String getCurrentUsername() {
        return org.springframework.security.core.context.SecurityContextHolder.getContext()
                .getAuthentication()
                .getName();
    }

    public static class UserRequest {
        private Long userId;
        private String data;

        public UserRequest(Long userId, String data) {
            this.userId = userId;
            this.data = data;
        }

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }

        public String getData() {
            return data;
        }

        public void setData(String data) {
            this.data = data;
        }
    }
}
