package com.example.security.controller;

import java.security.Principal;

import com.example.security.service.SecureService;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final SecureService secureService;

    public UserController(SecureService secureService) {
        this.secureService = secureService;
    }

    @GetMapping("/profile")
    public String getUserProfile(Principal principal) {
        return "User profile for: " + principal.getName();
    }

    @GetMapping("/data")
    public String getUserData() {
        return secureService.getUserData();
    }

    @GetMapping("/personal")
    public String getPersonalData() {
        return secureService.getPersonalData();
    }

    @GetMapping("/profile/{username}")
    public String getOwnProfile(@PathVariable String username) {
        return secureService.getOwnProfile(username);
    }

    @GetMapping("/authorities")
    public String getUserAuthorities() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return "Current user authorities: " + auth.getAuthorities().toString();
    }

    @PostMapping("/request")
    public String processUserRequest(@RequestBody SecureService.UserRequest request) {
        return secureService.processRequest(request);
    }
}
