package com.example.security.handler;

import org.springframework.stereotype.Component;

@Component
public class NullAuthorizationHandler {

    public Object handle() {
        return null;
    }

    public Long handleCount() {
        return 0L;
    }
}
