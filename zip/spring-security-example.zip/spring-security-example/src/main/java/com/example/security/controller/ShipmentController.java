package com.example.security.controller;

import java.util.List;
import java.util.Optional;

import com.example.security.model.Shipment;
import com.example.security.repository.ShipmentRepository;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/shipments")
public class ShipmentController {

    private final ShipmentRepository shipmentRepository;

    public ShipmentController(ShipmentRepository shipmentRepository) {
        this.shipmentRepository = shipmentRepository;
    }

    @GetMapping
    public List<Shipment> getAllShipments() {
        return shipmentRepository.findAll();
    }

    @GetMapping("/count")
    public Long getShipmentCount() {
        return shipmentRepository.count();
    }

    @GetMapping("/corporate")
    public List<Shipment> getCorporateShipments() {
        return shipmentRepository.findCorporateShipments();
    }

    @GetMapping("/{trackingNumber}")
    public Optional<Shipment> getShipmentByTracking(@PathVariable String trackingNumber) {
        return shipmentRepository.findByTrackingNumber(trackingNumber);
    }

    @GetMapping("/status/{status}")
    public List<Shipment> getShipmentsByStatus(@PathVariable String status) {
        return shipmentRepository.findByStatus(status);
    }

    @GetMapping("/owner/{ownerId}")
    public List<Shipment> getShipmentsByOwner(@PathVariable String ownerId) {
        return shipmentRepository.findByOwnerId(ownerId);
    }
}
