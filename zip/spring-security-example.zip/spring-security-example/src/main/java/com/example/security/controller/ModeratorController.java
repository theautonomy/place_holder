package com.example.security.controller;

import com.example.security.service.SecureService;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/moderator")
public class ModeratorController {

    private final SecureService secureService;

    public ModeratorController(SecureService secureService) {
        this.secureService = secureService;
    }

    @GetMapping("/content")
    @Secured({"ROLE_MODERATOR", "ROLE_ADMIN"})
    public String getModeratedContent() {
        return secureService.getModeratedContent();
    }

    @GetMapping("/review")
    @Secured("ROLE_MODERATOR")
    public String reviewContent() {
        return "Content review interface - Moderator access required";
    }
}
