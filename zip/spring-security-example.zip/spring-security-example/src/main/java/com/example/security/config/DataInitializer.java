package com.example.security.config;

import java.util.Set;

import com.example.security.model.Permission;
import com.example.security.model.Role;
import com.example.security.model.User;
import com.example.security.repository.UserRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            createUsers();
        }
    }

    private void createUsers() {
        // Regular user - corp.example.com domain
        User regularUser =
                new User(
                        "user",
                        passwordEncoder.encode("password"),
                        Set.of(Role.USER),
                        Set.of(Permission.READ),
                        "corp.example.com");

        // Admin user - corp.example.com domain
        User adminUser =
                new User(
                        "admin",
                        passwordEncoder.encode("admin"),
                        Set.of(Role.ADMIN, Role.USER),
                        Set.of(
                                Permission.READ,
                                Permission.WRITE,
                                Permission.DELETE,
                                Permission.CREATE,
                                Permission.UPDATE,
                                Permission.MANAGE_USERS,
                                Permission.VIEW_REPORTS,
                                Permission.EXPORT_DATA),
                        "corp.example.com");

        // Manager user - example.com domain
        User managerUser =
                new User(
                        "manager",
                        passwordEncoder.encode("manager"),
                        Set.of(Role.MANAGER, Role.USER),
                        Set.of(
                                Permission.READ,
                                Permission.WRITE,
                                Permission.UPDATE,
                                Permission.VIEW_REPORTS,
                                Permission.EXPORT_DATA),
                        "example.com");

        // Moderator user - other.com domain
        User moderatorUser =
                new User(
                        "moderator",
                        passwordEncoder.encode("moderator"),
                        Set.of(Role.MODERATOR, Role.USER),
                        Set.of(Permission.READ, Permission.WRITE, Permission.UPDATE),
                        "other.com");

        userRepository.save(regularUser);
        userRepository.save(adminUser);
        userRepository.save(managerUser);
        userRepository.save(moderatorUser);

        System.out.println("Sample users created:");
        System.out.println(
                "user/password - Role: USER, Domain: corp.example.com, Permissions: READ");
        System.out.println(
                "admin/admin - Role: ADMIN+USER, Domain: corp.example.com, Permissions: ALL");
        System.out.println(
                "manager/manager - Role: MANAGER+USER, Domain: example.com, Permissions: READ,WRITE,UPDATE,VIEW_REPORTS,EXPORT_DATA");
        System.out.println(
                "moderator/moderator - Role: MODERATOR+USER, Domain: other.com, Permissions: READ,WRITE,UPDATE");
    }
}
