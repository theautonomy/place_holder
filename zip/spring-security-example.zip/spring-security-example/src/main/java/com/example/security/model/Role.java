package com.example.security.model;

public enum Role {
    USER,
    ADMIN,
    MANAGER,
    MODERATOR
}
