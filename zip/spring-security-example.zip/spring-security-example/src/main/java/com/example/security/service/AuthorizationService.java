package com.example.security.service;

import java.util.Arrays;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service("authorizationService")
public class AuthorizationService {

    public boolean hasAllowedDomain(String[] domains) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return false;
        }

        if (domains == null || domains.length == 0) {
            return false;
        }

        String username = authentication.getName();
        String userDomain = extractDomainFromUsername(username);

        return Arrays.asList(domains).contains(userDomain);
    }

    public boolean canAccessResource(String resourceDomain) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return false;
        }

        String username = authentication.getName();
        String userDomain = extractDomainFromUsername(username);

        return userDomain.equals(resourceDomain);
    }

    public String getCurrentUserDomain() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return "unknown.com";
        }

        return extractDomainFromUsername(authentication.getName());
    }

    public boolean hasAllowedDomainForMethod(java.lang.reflect.Method method) {
        // Get the HasDomainMeta annotation from the method
        com.example.security.annotation.HasDomainMeta annotation =
                method.getAnnotation(com.example.security.annotation.HasDomainMeta.class);

        if (annotation == null) {
            return false; // No annotation, deny access
        }

        // Extract domains from annotation and check authorization
        return hasAllowedDomain(annotation.domains());
    }

    private String extractDomainFromUsername(String username) {
        if (username.contains("@")) {
            return username.substring(username.indexOf("@") + 1);
        }

        // Default domain mapping for demo users
        switch (username) {
            case "admin":
                return "corp.example.com";
            case "manager":
                return "example.com";
            case "user":
                return "corp.example.com";
            case "moderator":
                return "other.com";
            default:
                return "unknown.com";
        }
    }
}
