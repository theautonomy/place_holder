package com.example.security.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/public")
public class PublicController {

    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome! This endpoint is publicly accessible";
    }

    @GetMapping("/info")
    public String info() {
        return "Application info - No authentication required";
    }
}
