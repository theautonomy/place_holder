package com.example.security.controller;

import java.util.List;

import com.example.security.model.Shipment;
import com.example.security.repository.ShipmentRepositoryV2;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/shipments")
public class ShipmentControllerV2 {

    private final ShipmentRepositoryV2 shipmentRepositoryV2;

    public ShipmentControllerV2(ShipmentRepositoryV2 shipmentRepositoryV2) {
        this.shipmentRepositoryV2 = shipmentRepositoryV2;
    }

    @GetMapping
    public List<Shipment> getAllShipmentsMetaAnnotation() {
        return shipmentRepositoryV2.findAllWithMetaAnnotation();
    }

    @GetMapping("/corporate")
    public List<Shipment> getCorporateShipmentsMetaAnnotation() {
        return shipmentRepositoryV2.findCorporateOnlyWithMetaAnnotation();
    }

    @GetMapping("/example-com")
    public List<Shipment> getExampleComShipmentsMetaAnnotation() {
        return shipmentRepositoryV2.findExampleComOnlyWithMetaAnnotation();
    }

    // HasDomainMeta endpoints
    @GetMapping("/meta")
    public List<Shipment> getAllShipmentsWithHasDomainMeta() {
        return shipmentRepositoryV2.findAllWithHasDomainMeta();
    }

    @GetMapping("/meta/corporate")
    public List<Shipment> getCorporateShipmentsWithHasDomainMeta() {
        return shipmentRepositoryV2.findCorporateOnlyWithHasDomainMeta();
    }

    @GetMapping("/meta/example-com")
    public List<Shipment> getExampleComShipmentsWithHasDomainMeta() {
        return shipmentRepositoryV2.findExampleComOnlyWithHasDomainMeta();
    }

    @GetMapping("/meta/other-com")
    public List<Shipment> getOtherComShipmentsWithHasDomainMeta() {
        return shipmentRepositoryV2.findOtherComOnlyWithHasDomainMeta();
    }
}
