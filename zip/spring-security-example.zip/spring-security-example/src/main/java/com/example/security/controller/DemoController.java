package com.example.security.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/demo")
public class DemoController {

    @GetMapping("/endpoints")
    public Map<String, String> getAllEndpoints() {
        Map<String, String> endpoints = new HashMap<>();

        // Public endpoints
        endpoints.put("GET /api/public/welcome", "Public - No auth required");
        endpoints.put("GET /api/public/info", "Public - No auth required");

        // User endpoints
        endpoints.put("GET /api/user/profile", "User role required");
        endpoints.put("GET /api/user/data", "User role + method security");
        endpoints.put("GET /api/user/authorities", "Shows current user authorities");

        // Admin endpoints
        endpoints.put("GET /api/admin/data", "Admin role required");
        endpoints.put("GET /api/admin/users", "Admin + MANAGE_USERS permission");
        endpoints.put("GET /api/admin/export", "Admin + EXPORT_DATA permission");

        // Manager endpoints
        endpoints.put("GET /api/manager/data", "Manager or Admin role");
        endpoints.put("GET /api/manager/reports", "Manager + VIEW_REPORTS permission");
        endpoints.put("GET /api/manager/executive", "JSR-250 @RolesAllowed demo");

        // Moderator endpoints
        endpoints.put("GET /api/moderator/content", "@Secured annotation demo");
        endpoints.put("GET /api/moderator/review", "Moderator-only access");

        // Shipment endpoints - Custom authorization demos
        endpoints.put(
                "GET /api/shipments",
                "Domain-based authorization with data filtering (AOP approach)");
        endpoints.put("GET /api/shipments/count", "Admin-only with custom handler");
        endpoints.put("GET /api/shipments/corporate", "Corporate domain access only");
        endpoints.put("GET /api/shipments/owner/{id}", "Owner-specific access");

        // Shipment V2 endpoints - Meta-annotation approach
        endpoints.put(
                "GET /api/v2/shipments",
                "Domain-based authorization (@PreAuthorize meta-annotation)");
        endpoints.put("GET /api/v2/shipments/corporate", "Corporate domain only (meta-annotation)");
        endpoints.put(
                "GET /api/v2/shipments/example-com", "Example.com domain only (meta-annotation)");

        // HasDomainMeta endpoints - True meta-annotation pattern
        endpoints.put("GET /api/v2/shipments/meta", "All domains (@HasDomainMeta annotation)");
        endpoints.put(
                "GET /api/v2/shipments/meta/corporate",
                "Corporate only (@HasDomainMeta annotation)");
        endpoints.put(
                "GET /api/v2/shipments/meta/example-com",
                "Example.com only (@HasDomainMeta annotation)");
        endpoints.put(
                "GET /api/v2/shipments/meta/other-com",
                "Other.com only (@HasDomainMeta annotation)");

        return endpoints;
    }

    @GetMapping("/current-user")
    public Map<String, Object> getCurrentUser(Authentication authentication) {
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("username", authentication.getName());
        userInfo.put("authorities", authentication.getAuthorities());
        userInfo.put("authenticated", authentication.isAuthenticated());
        return userInfo;
    }
}
