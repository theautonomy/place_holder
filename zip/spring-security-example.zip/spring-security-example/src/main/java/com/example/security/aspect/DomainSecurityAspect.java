package com.example.security.aspect;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.example.security.annotation.AuthorizeReturnObject;
import com.example.security.annotation.HandleAuthorizationDenied;
import com.example.security.annotation.HasDomain;
import com.example.security.handler.NullAuthorizationHandler;
import com.example.security.model.Shipment;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class DomainSecurityAspect {

    private final NullAuthorizationHandler nullHandler;

    public DomainSecurityAspect(NullAuthorizationHandler nullHandler) {
        this.nullHandler = nullHandler;
    }

    @Around("@annotation(hasDomain)")
    public Object checkDomain(ProceedingJoinPoint joinPoint, HasDomain hasDomain) throws Throwable {
        String currentUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        String userDomain = extractDomainFromUsername(currentUsername);

        String[] allowedDomains = hasDomain.domains();
        boolean hasAccess = Arrays.asList(allowedDomains).contains(userDomain);

        if (!hasAccess) {
            Method method = getMethod(joinPoint);
            HandleAuthorizationDenied handler =
                    method.getAnnotation(HandleAuthorizationDenied.class);

            if (handler != null && handler.handlerClass() == NullAuthorizationHandler.class) {
                if (method.getReturnType() == Long.class) {
                    return nullHandler.handleCount();
                }
                return nullHandler.handle();
            }

            throw new AccessDeniedException(
                    "Access denied - domain "
                            + userDomain
                            + " not in allowed domains: "
                            + Arrays.toString(allowedDomains));
        }

        Object result = joinPoint.proceed();

        // Apply @AuthorizeReturnObject filtering if present
        Method method = getMethod(joinPoint);
        if (method.isAnnotationPresent(AuthorizeReturnObject.class)) {
            result = filterResultByDomain(result, userDomain);
        }

        return result;
    }

    private Method getMethod(ProceedingJoinPoint joinPoint) throws NoSuchMethodException {
        String methodName = joinPoint.getSignature().getName();
        Class<?> targetClass = joinPoint.getTarget().getClass();
        Class<?>[] parameterTypes =
                Arrays.stream(joinPoint.getArgs()).map(Object::getClass).toArray(Class[]::new);

        try {
            return targetClass.getMethod(methodName, parameterTypes);
        } catch (NoSuchMethodException e) {
            // Try with no parameters for parameterless methods
            return targetClass.getMethod(methodName);
        }
    }

    private String extractDomainFromUsername(String username) {
        if (username.contains("@")) {
            return username.substring(username.indexOf("@") + 1);
        }
        // Default domain mapping for demo users
        switch (username) {
            case "admin":
                return "corp.example.com";
            case "manager":
                return "example.com";
            case "user":
                return "corp.example.com";
            case "moderator":
                return "other.com";
            default:
                return "unknown.com";
        }
    }

    private Object filterResultByDomain(Object result, String userDomain) {
        if (result instanceof List) {
            @SuppressWarnings("unchecked")
            List<Object> list = (List<Object>) result;
            return list.stream()
                    .filter(
                            item -> {
                                if (item instanceof Shipment) {
                                    Shipment shipment = (Shipment) item;
                                    return userDomain.equals(shipment.getCompanyDomain());
                                }
                                return true;
                            })
                    .collect(Collectors.toList());
        }
        return result;
    }
}
