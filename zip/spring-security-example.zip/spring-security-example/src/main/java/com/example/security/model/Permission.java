package com.example.security.model;

public enum Permission {
    READ,
    WRITE,
    DELETE,
    CREATE,
    UPDATE,
    MANAGE_USERS,
    VIEW_REPORTS,
    EXPORT_DATA
}
