package com.example.security.controller;

import java.util.List;

import com.example.security.service.SecureService;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/manager")
public class ManagerController {

    private final SecureService secureService;

    public ManagerController(SecureService secureService) {
        this.secureService = secureService;
    }

    @GetMapping("/data")
    @PreAuthorize("hasRole('MANAGER') or hasRole('ADMIN')")
    public String getManagementData() {
        return secureService.getManagementData();
    }

    @GetMapping("/reports")
    @PreAuthorize("hasRole('MANAGER') and hasAuthority('VIEW_REPORTS')")
    public List<String> getReports() {
        return secureService.getReports();
    }

    @GetMapping("/executive")
    public String getExecutiveData() {
        return secureService.getExecutiveData();
    }

    @GetMapping("/team")
    @PreAuthorize("hasAnyRole('MANAGER', 'ADMIN')")
    public String getTeamInfo() {
        return "Team information - Manager or Admin access required";
    }
}
