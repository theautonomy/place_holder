package com.example.security.repository;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.security.annotation.AllDomains;
import com.example.security.annotation.CorporateOnly;
import com.example.security.annotation.ExampleComOnly;
import com.example.security.annotation.HasDomainMeta;
import com.example.security.annotation.OtherComOnly;
import com.example.security.model.Shipment;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Repository;

import jakarta.annotation.PostConstruct;

@Repository
public class ShipmentRepositoryV2 {

    private final List<Shipment> shipments = new ArrayList<>();

    @PostConstruct
    public void init() {
        shipments.add(
                new Shipment(
                        "TRK001",
                        "New York",
                        "Los Angeles",
                        "SHIPPED",
                        "corp.example.com",
                        "admin"));
        shipments.add(
                new Shipment("TRK002", "Chicago", "Miami", "DELIVERED", "example.com", "manager"));
        shipments.add(
                new Shipment(
                        "TRK003", "Seattle", "Denver", "IN_TRANSIT", "corp.example.com", "user"));
        shipments.add(
                new Shipment("TRK004", "Boston", "Austin", "PENDING", "other.com", "moderator"));
        shipments.add(
                new Shipment("TRK005", "Portland", "Phoenix", "SHIPPED", "example.com", "manager"));
        shipments.add(
                new Shipment(
                        "TRK006", "Atlanta", "Dallas", "DELIVERED", "corp.example.com", "admin"));
    }

    // Meta-annotation approach using @PreAuthorize directly
    @PreAuthorize("@authorizationService.hasAllowedDomain({'corp.example.com', 'example.com'})")
    public List<Shipment> findAllWithMetaAnnotation() {
        return filterByCurrentUserDomain(shipments);
    }

    @PreAuthorize("@authorizationService.hasAllowedDomain({'corp.example.com'})")
    public List<Shipment> findCorporateOnlyWithMetaAnnotation() {
        return filterByDomain(shipments, "corp.example.com");
    }

    @PreAuthorize("@authorizationService.hasAllowedDomain({'example.com'})")
    public List<Shipment> findExampleComOnlyWithMetaAnnotation() {
        return filterByDomain(shipments, "example.com");
    }

    // HasDomainMeta approach - working meta-annotations
    @AllDomains
    public List<Shipment> findAllWithHasDomainMeta() {
        return new ArrayList<>(shipments);
    }

    @CorporateOnly
    public List<Shipment> findCorporateOnlyWithHasDomainMeta() {
        return filterByDomain(shipments, "corp.example.com");
    }

    @ExampleComOnly
    public List<Shipment> findExampleComOnlyWithHasDomainMeta() {
        return filterByDomain(shipments, "example.com");
    }

    @OtherComOnly
    public List<Shipment> findOtherComOnlyWithHasDomainMeta() {
        return filterByDomain(shipments, "other.com");
    }

    // Method to get domains for current method (for complex SpEL expressions)
    public String[] getDomainList(Method method) {
        HasDomainMeta annotation = method.getAnnotation(HasDomainMeta.class);
        return annotation != null ? annotation.domains() : new String[0];
    }

    private List<Shipment> filterByCurrentUserDomain(List<Shipment> allShipments) {
        // This would be filtered by the AuthorizationService based on user domain
        // For now, return all and let the service handle domain filtering in a real implementation
        return new ArrayList<>(allShipments);
    }

    private List<Shipment> filterByDomain(List<Shipment> allShipments, String domain) {
        return allShipments.stream()
                .filter(shipment -> domain.equals(shipment.getCompanyDomain()))
                .toList();
    }

    public Optional<Shipment> findByTrackingNumber(String trackingNumber) {
        return shipments.stream()
                .filter(shipment -> shipment.getTrackingNumber().equals(trackingNumber))
                .findFirst();
    }
}
