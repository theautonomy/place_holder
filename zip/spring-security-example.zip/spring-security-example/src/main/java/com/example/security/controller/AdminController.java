package com.example.security.controller;

import com.example.security.service.SecureService;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final SecureService secureService;

    public AdminController(SecureService secureService) {
        this.secureService = secureService;
    }

    @GetMapping("/data")
    public String getAdminData() {
        return secureService.getAdminData();
    }

    @GetMapping("/users")
    @PreAuthorize("hasAuthority('MANAGE_USERS')")
    public String manageUsers() {
        return secureService.manageUsers();
    }

    @GetMapping("/export")
    @PreAuthorize("hasAuthority('EXPORT_DATA')")
    public String exportData() {
        return secureService.exportData();
    }

    @GetMapping("/system")
    public String getSystemInfo() {
        return "System information - Admin access required";
    }
}
