package com.example.security.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.security.annotation.AuthorizeReturnObject;
import com.example.security.annotation.HandleAuthorizationDenied;
import com.example.security.annotation.HasDomain;
import com.example.security.handler.NullAuthorizationHandler;
import com.example.security.model.Shipment;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Repository;

import jakarta.annotation.PostConstruct;

@Repository
public class ShipmentRepository {

    private final List<Shipment> shipments = new ArrayList<>();

    @PostConstruct
    public void init() {
        shipments.add(
                new Shipment(
                        "TRK001",
                        "New York",
                        "Los Angeles",
                        "SHIPPED",
                        "corp.example.com",
                        "admin"));
        shipments.add(
                new Shipment("TRK002", "Chicago", "Miami", "DELIVERED", "example.com", "manager"));
        shipments.add(
                new Shipment(
                        "TRK003", "Seattle", "Denver", "IN_TRANSIT", "corp.example.com", "user"));
        shipments.add(
                new Shipment("TRK004", "Boston", "Austin", "PENDING", "other.com", "moderator"));
        shipments.add(
                new Shipment("TRK005", "Portland", "Phoenix", "SHIPPED", "example.com", "manager"));
        shipments.add(
                new Shipment(
                        "TRK006", "Atlanta", "Dallas", "DELIVERED", "corp.example.com", "admin"));
    }

    @HasDomain(domains = {"corp.example.com", "example.com"})
    @AuthorizeReturnObject
    public List<Shipment> findAll() {
        return new ArrayList<>(shipments);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @HandleAuthorizationDenied(handlerClass = NullAuthorizationHandler.class)
    public Long count() {
        return (long) shipments.size();
    }

    public Optional<Shipment> findByTrackingNumber(String trackingNumber) {
        return shipments.stream()
                .filter(shipment -> shipment.getTrackingNumber().equals(trackingNumber))
                .findFirst();
    }

    @HasDomain(domains = {"corp.example.com", "example.com"})
    public List<Shipment> findByStatus(String status) {
        return shipments.stream().filter(shipment -> shipment.getStatus().equals(status)).toList();
    }

    @PreAuthorize("authentication.name == #ownerId or hasRole('ADMIN')")
    public List<Shipment> findByOwnerId(String ownerId) {
        return shipments.stream()
                .filter(shipment -> shipment.getOwnerId().equals(ownerId))
                .toList();
    }

    @HasDomain(domains = {"corp.example.com"})
    @AuthorizeReturnObject
    public List<Shipment> findCorporateShipments() {
        return shipments.stream()
                .filter(shipment -> "corp.example.com".equals(shipment.getCompanyDomain()))
                .toList();
    }
}
