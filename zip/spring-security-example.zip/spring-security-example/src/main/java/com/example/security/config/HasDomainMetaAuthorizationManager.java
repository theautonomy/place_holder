package com.example.security.config;

import java.lang.reflect.Method;
import java.util.function.Supplier;

import com.example.security.annotation.HasDomainMeta;
import com.example.security.service.AuthorizationService;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationManager;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

@Component
public class HasDomainMetaAuthorizationManager implements AuthorizationManager<MethodInvocation> {

    private final AuthorizationService authorizationService;

    public HasDomainMetaAuthorizationManager(AuthorizationService authorizationService) {
        this.authorizationService = authorizationService;
    }

    @Override
    public AuthorizationDecision check(
            Supplier<Authentication> authenticationSupplier, MethodInvocation methodInvocation) {
        Method method = methodInvocation.getMethod();
        HasDomainMeta annotation = method.getAnnotation(HasDomainMeta.class);

        if (annotation == null) {
            return new AuthorizationDecision(true); // No annotation, allow access
        }

        String[] allowedDomains = annotation.domains();
        boolean hasAccess = authorizationService.hasAllowedDomain(allowedDomains);

        return new AuthorizationDecision(hasAccess);
    }
}
