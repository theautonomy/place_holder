# Spring Security Authorization Demo - Implementation Summary

This document summarizes the comprehensive Spring Security authorization features implemented in this demonstration application.

## Overview

This Spring Boot application demonstrates advanced Spring Security authorization patterns including:
- Role-Based Access Control (RBAC)
- Permission-Based Authorization
- Domain-Based Data Filtering
- Method-Level Security
- Aspect-Oriented Programming (AOP) Authorization
- Custom Meta-Annotations
- Web UI Integration with Thymeleaf

## Application Architecture

### Core Components
- **Spring Boot 3.2.1** with Spring Security 6.2.1
- **H2 In-Memory Database** for demo data
- **Thymeleaf** for web UI templates
- **AspectJ** for AOP-based authorization
- **JPA/Hibernate** for data persistence

### Security Configuration
- **Form-based authentication** and **HTTP Basic Authentication**
- **Custom UserDetailsService** with domain information
- **Method-level security** enabled (`@EnableMethodSecurity`)
- **AOP enabled** (`@EnableAspectJAutoProxy`)

## 1. User Model & Domain-Based Security

### User Entity
```java
@Entity
public class User {
    private String username;
    private String password;
    private String companyDomain;  // Key field for domain-based authorization
    private Set<Role> roles;
    private Set<Permission> permissions;
    private boolean enabled;
}
```

### Demo Users
| Username | Password | Domain | Roles | Purpose |
|----------|----------|---------|-------|---------|
| admin | admin | corp.example.com | ADMIN, USER | Corporate admin access |
| user | password | corp.example.com | USER | Corporate user access |
| manager | manager | example.com | MANAGER, USER | Standard domain manager |
| moderator | moderator | other.com | MODERATOR, USER | Restricted domain user |

### Custom UserDetails Implementation
```java
public class CustomUserDetails implements UserDetails {
    private final User user;

    public String getCompanyDomain() {
        return user.getCompanyDomain();
    }
    // ... other UserDetails methods
}
```

## 2. Authorization Patterns Implemented

### A. Role-Based Access Control (RBAC)

#### Roles Hierarchy
- **ADMIN**: Full system access
- **MANAGER**: Department-level access
- **MODERATOR**: Content moderation access
- **USER**: Basic authenticated access

#### URL-Level Security
```java
@Configuration
public class SecurityConfig {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) {
        return http.authorizeHttpRequests(authz -> authz
            .requestMatchers("/api/admin/**").hasRole("ADMIN")
            .requestMatchers("/api/manager/**").hasAnyRole("MANAGER", "ADMIN")
            .requestMatchers("/api/moderator/**").hasAnyRole("MODERATOR", "ADMIN")
            .requestMatchers("/api/user/**").hasRole("USER")
            .anyRequest().authenticated())
            // ... other configuration
            .build();
    }
}
```

### B. Permission-Based Authorization

#### Permission Enum
```java
public enum Permission {
    READ, WRITE, DELETE, CREATE, UPDATE,
    MANAGE_USERS, VIEW_REPORTS, EXPORT_DATA
}
```

#### Method-Level Permission Checks
```java
@PreAuthorize("hasAuthority('MANAGE_USERS')")
public List<User> getAllUsers() { ... }

@PreAuthorize("hasAuthority('EXPORT_DATA')")
public byte[] exportData() { ... }
```

### C. Domain-Based Data Filtering

#### Core Concept
Users only see data belonging to their assigned company domain:
- **corp.example.com**: Corporate users see corporate shipments
- **example.com**: Standard users see example.com shipments
- **other.com**: Restricted domain with limited access

#### AuthorizationService
```java
@Service
public class AuthorizationService {
    public boolean hasAllowedDomain(String[] allowedDomains) {
        String userDomain = getCurrentUserDomain();
        return Arrays.asList(allowedDomains).contains(userDomain);
    }

    public String getCurrentUserDomain() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getPrincipal() instanceof CustomUserDetails userDetails) {
            return userDetails.getCompanyDomain();
        }
        return null;
    }
}
```

## 3. Three Authorization Implementation Approaches

### Approach 1: Aspect-Oriented Programming (AOP)

#### Custom Annotations
```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface HasDomain {
    String[] domains();
}

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface AuthorizeReturnObject {
}
```

#### AOP Aspect Implementation
```java
@Aspect
@Component
public class DomainSecurityAspect {

    @Around("@annotation(hasDomain)")
    public Object checkDomain(ProceedingJoinPoint joinPoint, HasDomain hasDomain) {
        // 1. Check user's domain against allowed domains
        // 2. If authorized, proceed and filter return data
        // 3. If not authorized, throw AccessDeniedException
    }

    @AfterReturning(pointcut = "@annotation(AuthorizeReturnObject)", returning = "result")
    public void filterReturnObject(Object result) {
        // Filter returned data based on user's domain
    }
}
```

#### Usage Example
```java
@Repository
public class ShipmentRepository {

    @HasDomain(domains = {"corp.example.com", "example.com"})
    @AuthorizeReturnObject
    public List<Shipment> findAll() {
        return new ArrayList<>(shipments);
    }

    @HasDomain(domains = {"corp.example.com"})
    @AuthorizeReturnObject
    public List<Shipment> findCorporateShipments() {
        return shipments.stream()
            .filter(s -> "corp.example.com".equals(s.getCompanyDomain()))
            .toList();
    }
}
```

### Approach 2: Direct @PreAuthorize with Custom Service

#### Implementation
```java
@Repository
public class ShipmentRepositoryV2 {

    @PreAuthorize("@authorizationService.hasAllowedDomain({'corp.example.com', 'example.com'})")
    public List<Shipment> findAllWithMetaAnnotation() {
        return filterByCurrentUserDomain(shipments);
    }

    @PreAuthorize("@authorizationService.hasAllowedDomain({'corp.example.com'})")
    public List<Shipment> findCorporateOnlyWithMetaAnnotation() {
        return filterByDomain(shipments, "corp.example.com");
    }
}
```

#### Benefits
- Clear, explicit authorization rules
- Direct integration with Spring Security
- Easy to understand and maintain

### Approach 3: Meta-Annotations Pattern

#### Meta-Annotation Definitions
```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@PreAuthorize("@authorizationService.hasAllowedDomain({'corp.example.com', 'example.com'})")
public @interface AllDomains {
}

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@PreAuthorize("@authorizationService.hasAllowedDomain({'corp.example.com'})")
public @interface CorporateOnly {
}

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@PreAuthorize("@authorizationService.hasAllowedDomain({'example.com'})")
public @interface ExampleComOnly {
}
```

#### Usage Example
```java
@Repository
public class ShipmentRepositoryV2 {

    @AllDomains
    public List<Shipment> findAllWithHasDomainMeta() {
        return new ArrayList<>(shipments);
    }

    @CorporateOnly
    public List<Shipment> findCorporateOnlyWithHasDomainMeta() {
        return filterByDomain(shipments, "corp.example.com");
    }
}
```

#### Benefits
- Reusable security patterns
- Domain-specific annotations
- Combines custom logic with Spring Security
- Clean, readable code

## 4. Method-Level Security Annotations

### Standard Spring Security Annotations

#### @PreAuthorize
```java
@PreAuthorize("hasRole('ADMIN')")
public void adminOnlyMethod() { ... }

@PreAuthorize("authentication.name == #username or hasRole('ADMIN')")
public User getUserData(String username) { ... }

@PreAuthorize("@authorizationService.hasAllowedDomain({'corp.example.com'})")
public List<Shipment> getCorporateData() { ... }
```

#### @PostAuthorize
```java
@PostAuthorize("returnObject.owner == authentication.name or hasRole('ADMIN')")
public Shipment getShipment(String id) { ... }
```

#### @Secured (Simple role checking)
```java
@Secured("ROLE_MODERATOR")
public void moderateContent() { ... }
```

#### @RolesAllowed (JSR-250 standard)
```java
@RolesAllowed({"MANAGER", "ADMIN"})
public void managerOperation() { ... }
```

## 5. Web UI Integration with Thymeleaf

### Security Integration
```html
<!-- Conditional content based on roles -->
<div sec:authorize="hasRole('ADMIN')">
    <h3>Admin Panel</h3>
    <a href="/api/admin/users">Manage Users</a>
</div>

<!-- Display current user information -->
<span sec:authentication="name">Username</span>
<span sec:authentication="principal.authorities">Roles</span>
<span th:text="${#authentication.principal.companyDomain}">Domain</span>
```

### Pages Implemented
- **Login Page**: Custom form with demo user credentials
- **Dashboard**: Role-based feature display
- **Shipments Page**: Interactive domain authorization demo

### JavaScript Integration
```javascript
// Load shipments via AJAX with proper authentication
function loadAopShipments() {
    fetch('/api/shipments')
        .then(response => response.json())
        .then(data => displayShipments(data))
        .catch(error => handleAuthorizationError(error));
}
```

## 6. Error Handling & Access Denial

### Custom Authorization Handler
```java
@Component
public class NullAuthorizationHandler implements AuthorizationDeniedHandler {
    @Override
    public Object handle(MethodInvocation invocation, AccessDeniedException ex) {
        // Return empty list instead of throwing exception
        return Collections.emptyList();
    }
}
```

### Usage with Custom Handler
```java
@PreAuthorize("hasRole('ADMIN')")
@HandleAuthorizationDenied(handlerClass = NullAuthorizationHandler.class)
public Long getShipmentCount() {
    return (long) shipments.size();
}
```

## 7. REST API Endpoints

### Public Endpoints
- `GET /api/public/welcome` - No authentication required
- `GET /api/public/info` - Public information

### Role-Based Endpoints
- `GET /api/admin/**` - Admin role required
- `GET /api/manager/**` - Manager or Admin role
- `GET /api/moderator/**` - Moderator role
- `GET /api/user/**` - User role required

### Domain-Based Authorization Endpoints
- `GET /api/shipments` - AOP approach, domain filtered
- `GET /api/shipments/corporate` - Corporate domain only (AOP)
- `GET /api/v2/shipments` - Direct @PreAuthorize approach
- `GET /api/v2/shipments/meta` - Meta-annotation approach
- `GET /api/v2/shipments/meta/corporate` - Corporate meta-annotation

### Demo & Utility Endpoints
- `GET /api/demo/endpoints` - List all available endpoints
- `GET /api/demo/current-user` - Current user information

## 8. Testing & Verification

### Test Script
The application includes `test-domain-authorization.bat` which tests:
1. AOP Approach authorization
2. Direct @PreAuthorize approach
3. Meta-annotation approach
4. Corporate-only endpoints
5. Demo endpoints

### Expected Behavior
| User | Domain | Can Access Corporate | Sees Shipments |
|------|--------|---------------------|----------------|
| admin | corp.example.com | ✅ Yes | Corporate shipments (TRK001, TRK003, TRK006) |
| user | corp.example.com | ✅ Yes | Corporate shipments (TRK001, TRK003, TRK006) |
| manager | example.com | ❌ 403 Forbidden | Example.com shipments (TRK002, TRK005) |
| moderator | other.com | ❌ 403 Forbidden | Blocked from most endpoints |

## 9. Key Security Features Demonstrated

### Authentication
- ✅ Form-based login with custom templates
- ✅ HTTP Basic Authentication for API access
- ✅ Session management
- ✅ Logout functionality

### Authorization
- ✅ Role-Based Access Control (RBAC)
- ✅ Permission-Based Authorization
- ✅ Method-Level Security
- ✅ URL-Level Security
- ✅ Domain-Based Data Filtering
- ✅ Custom Authorization Logic

### Advanced Patterns
- ✅ Aspect-Oriented Programming (AOP) Security
- ✅ Custom Security Annotations
- ✅ Meta-Annotation Patterns
- ✅ Custom Authorization Handlers
- ✅ SpEL (Spring Expression Language) Integration

### Web Integration
- ✅ Thymeleaf Security Integration
- ✅ Conditional Content Rendering
- ✅ AJAX with Authentication
- ✅ User Context Display

## 10. Technical Implementation Notes

### SpEL Expression Challenges
During implementation, we encountered limitations with Spring Security's SpEL expressions:
- `#root.method` and `#root.methodName` are not available in method security context
- Solution: Use service-based authorization or direct domain arrays in expressions

### AOP vs Method Security
- **AOP Approach**: More flexible, custom error handling, data filtering
- **Method Security**: Simpler, direct integration, better performance
- **Meta-annotations**: Reusable patterns, clean code, domain-specific

### Performance Considerations
- Domain filtering happens at application level, not database level
- For production, consider database-level row security or query modification
- Aspect overhead is minimal for the demonstrated use cases

## 11. Running the Application

### Prerequisites
- Java 17+
- Maven 3.6+

### Start Application
```bash
mvn spring-boot:run
```

### Access Points
- **Web UI**: http://localhost:8086/
- **H2 Console**: http://localhost:8086/h2-console
- **API Base**: http://localhost:8086/api/

### Test All Features
```bash
# Run comprehensive test suite
./test-domain-authorization.bat
```

## Conclusion

This implementation demonstrates a comprehensive approach to Spring Security authorization, showcasing multiple patterns and techniques that can be applied in real-world applications. The combination of role-based, permission-based, and domain-based authorization provides a robust security model suitable for multi-tenant or department-based applications.

The three different implementation approaches (AOP, Direct @PreAuthorize, Meta-annotations) show the flexibility of Spring Security and allow developers to choose the best approach for their specific use case and architectural preferences.
