# Spring Security Authorization Demo

This Spring Boot application demonstrates key concepts in Spring Security authorization including:

## Key Features Demonstrated

### 1. Authentication vs Authorization
- **Authentication**: Verifying user identity (who you are)
- **Authorization**: Determining what authenticated users can access (what you can do)

### 2. Role-Based Access Control (RBAC)
- **Roles**: USER, ADMIN, MANAGER, MODERATOR
- URL-level security configuration in `SecurityConfig.java`
- Method-level role checking with `@PreAuthorize`

### 3. Permission-Based Authorization
- **Permissions**: READ, WRITE, DELETE, CREATE, UPDATE, MANAGE_USERS, VIEW_REPORTS, EXPORT_DATA
- Fine-grained access control beyond simple roles
- Combined role and permission checks

### 4. Method-Level Security Annotations
- `@PreAuthorize` - Check conditions before method execution
- `@PostAuthorize` - Check conditions after method execution
- `@Secured` - Simple role-based method security
- `@RolesAllowed` - JSR-250 standard annotation

### 5. URL-Based Security Configuration
- Public endpoints (`/api/public/**`)
- Role-protected endpoints (`/api/admin/**`, `/api/manager/**`)
- Hierarchical access patterns

## Sample Users

The application creates these sample users on startup:

| Username  | Password  | Roles           | Permissions |
|-----------|-----------|-----------------|-------------|
| user      | password  | USER            | READ |
| admin     | admin     | ADMIN, USER     | ALL |
| manager   | manager   | MANAGER, USER   | READ, WRITE, UPDATE, VIEW_REPORTS, EXPORT_DATA |
| moderator | moderator | MODERATOR, USER | READ, WRITE, UPDATE |

## API Endpoints

### Public Endpoints (No Authentication)
- `GET /api/public/welcome` - Welcome message
- `GET /api/public/info` - Application info

### User Endpoints (USER role required)
- `GET /api/user/profile` - User profile
- `GET /api/user/data` - User data with method security
- `GET /api/user/authorities` - Shows current user authorities

### Admin Endpoints (ADMIN role required)
- `GET /api/admin/data` - Admin data
- `GET /api/admin/users` - User management (requires MANAGE_USERS permission)
- `GET /api/admin/export` - Data export (requires EXPORT_DATA permission)

### Manager Endpoints
- `GET /api/manager/data` - Management data (MANAGER or ADMIN role)
- `GET /api/manager/reports` - Reports (MANAGER + VIEW_REPORTS permission)
- `GET /api/manager/executive` - Executive data (JSR-250 demo)

### Moderator Endpoints
- `GET /api/moderator/content` - Moderated content (@Secured demo)
- `GET /api/moderator/review` - Content review (MODERATOR only)

### Demo Endpoints
- `GET /api/demo/endpoints` - Lists all available endpoints
- `GET /api/demo/current-user` - Shows current user info

### Shipment Endpoints (Custom Authorization Demo)
- `GET /api/shipments` - Domain-based authorization with data filtering
- `GET /api/shipments/count` - Admin-only with custom authorization handler
- `GET /api/shipments/corporate` - Corporate domain access only
- `GET /api/shipments/{trackingNumber}` - Get shipment by tracking number
- `GET /api/shipments/status/{status}` - Get shipments by status (domain-filtered)
- `GET /api/shipments/owner/{ownerId}` - Owner-specific access control

## Running the Application

1. Run the application:
```bash
mvn spring-boot:run
```

2. Access endpoints using HTTP Basic Authentication:
```bash
# Public endpoint (no auth)
curl http://localhost:8081/api/public/welcome

# User endpoint
curl -u user:password http://localhost:8081/api/user/profile

# Admin endpoint
curl -u admin:admin http://localhost:8081/api/admin/data

# Manager endpoint
curl -u manager:manager http://localhost:8081/api/manager/reports

# Domain-based shipment access
curl -u admin:admin http://localhost:8081/api/shipments
curl -u manager:manager http://localhost:8081/api/shipments
```

3. View H2 Database Console:
- URL: http://localhost:8081/h2-console
- JDBC URL: jdbc:h2:mem:testdb
- Username: sa
- Password: (empty)

## Custom Domain-Based Authorization

This application now includes **the same advanced authorization concept** from the referenced repository:

### Domain-Based Data Access Control
- **Custom Annotations**: `@HasDomain`, `@AuthorizeReturnObject`, `@HandleAuthorizationDenied`
- **Aspect-Oriented Programming**: `DomainSecurityAspect` intercepts method calls
- **Data Filtering**: Returns only data belonging to user's domain
- **Custom Handlers**: Graceful handling of authorization failures

### Domain Mapping
- **admin** → `corp.example.com`
- **user** → `corp.example.com`
- **manager** → `example.com`
- **moderator** → `other.com`

### Example Results
```bash
# Admin sees only corp.example.com shipments
curl -u admin:admin http://localhost:8081/api/shipments
# Returns: TRK001, TRK003, TRK006 (corp.example.com only)

# Manager sees only example.com shipments
curl -u manager:manager http://localhost:8081/api/shipments
# Returns: TRK002, TRK005 (example.com only)

# Moderator is denied access (other.com not in allowed domains)
curl -u moderator:moderator http://localhost:8081/api/shipments
# Returns: 403 Forbidden
```

## Authorization Concepts Demonstrated

### SpEL (Spring Expression Language)
```java
@PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
@PreAuthorize("hasAuthority('READ') and hasRole('USER')")
@PreAuthorize("authentication.name == #username")
```

### Multiple Security Approaches
1. **URL-based** security in `SecurityConfig`
2. **Method-based** security with annotations
3. **Mixed approach** combining both for defense in depth

### Access Decision Process
1. URL-level security check (if configured)
2. Method-level security check (if annotated)
3. Both must pass for access to be granted

This demonstrates how Spring Security provides flexible, multi-layered authorization mechanisms for securing Spring Boot applications.
