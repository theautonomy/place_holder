package com.example.beanregistrar_example.service;

public interface NotificationService {
    void sendNotification(String recipient, String message);

    String getProviderName();
}
