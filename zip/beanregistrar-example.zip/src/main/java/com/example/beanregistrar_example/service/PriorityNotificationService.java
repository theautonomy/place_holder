package com.example.beanregistrar_example.service;

public class PriorityNotificationService implements NotificationService {

    @Override
    public void sendNotification(String recipient, String message) {
        System.out.println("⚡ Sending PRIORITY notification to: " + recipient);
        System.out.println("   Message: " + message);
        System.out.println("   [HIGH PRIORITY - IMMEDIATE DELIVERY]");
    }

    @Override
    public String getProviderName() {
        return "Priority Notification Provider (Primary)";
    }
}
