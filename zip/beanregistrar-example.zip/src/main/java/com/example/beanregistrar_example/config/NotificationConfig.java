package com.example.beanregistrar_example.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(NotificationServiceRegistrar.class)
public class NotificationConfig {
    // The @Import annotation activates the BeanRegistrar
    // This is the key to enabling programmatic bean registration
}
