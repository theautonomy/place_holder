package com.example.beanregistrar_example.config;

import com.example.beanregistrar_example.service.*;

import org.springframework.beans.factory.BeanRegistrar;
import org.springframework.beans.factory.BeanRegistry;
import org.springframework.core.env.Environment;

public class NotificationServiceRegistrar implements BeanRegistrar {

    @Override
    public void register(BeanRegistry registry, Environment environment) {
        // Read configuration property to determine which notification provider(s) to register
        String notificationProvider = environment.getProperty("app.notification.provider", "email");

        System.out.println("🔧 BeanRegistrar is registering notification services...");
        System.out.println("   Provider configured: " + notificationProvider);

        // Register the appropriate notification service based on configuration
        switch (notificationProvider.toLowerCase()) {
            case "email" -> {
                registry.registerBean(
                        "notificationService",
                        EmailNotificationService.class,
                        spec ->
                                spec.description(
                                        "Email notification service registered via BeanRegistrar"));
                System.out.println("   ✅ Registered EmailNotificationService");
            }
            case "sms" -> {
                registry.registerBean(
                        "notificationService",
                        SmsNotificationService.class,
                        spec ->
                                spec.description(
                                        "SMS notification service registered via BeanRegistrar"));
                System.out.println("   ✅ Registered SmsNotificationService");
            }
            case "push" -> {
                registry.registerBean(
                        "notificationService",
                        PushNotificationService.class,
                        spec ->
                                spec.description(
                                        "Push notification service registered via BeanRegistrar"));
                System.out.println("   ✅ Registered PushNotificationService");
            }
            case "priority" -> {
                // Demonstrate advanced customization: primary bean, lazy init, and description
                registry.registerBean(
                        "priorityNotificationService",
                        PriorityNotificationService.class,
                        spec ->
                                spec.description(
                                                "High-priority notification service with advanced configuration")
                                        .primary() // Mark as primary bean (default choice for
                                        // autowiring)
                                        .lazyInit()); // Enable lazy initialization

                // Also register email as a fallback (non-primary)
                registry.registerBean(
                        "emailNotificationService",
                        EmailNotificationService.class,
                        spec -> spec.description("Fallback email notification service"));

                System.out.println("   ✅ Registered PriorityNotificationService as PRIMARY");
                System.out.println("   ✅ Registered EmailNotificationService as fallback");
            }
            case "all" -> {
                // Register all implementations with different bean names
                registry.registerBean(
                        "emailNotificationService",
                        EmailNotificationService.class,
                        spec ->
                                spec.description(
                                        "Email notification service - part of multi-provider setup"));
                registry.registerBean(
                        "smsNotificationService",
                        SmsNotificationService.class,
                        spec ->
                                spec.description(
                                        "SMS notification service - part of multi-provider setup"));
                registry.registerBean(
                        "pushNotificationService",
                        PushNotificationService.class,
                        spec ->
                                spec.description(
                                        "Push notification service - part of multi-provider setup"));
                System.out.println("   ✅ Registered all notification services");
            }
            default -> {
                // Default to email if unknown provider
                registry.registerBean("notificationService", EmailNotificationService.class);
                System.out.println(
                        "   ⚠️  Unknown provider, defaulting to EmailNotificationService");
            }
        }

        // Example: Conditional registration based on Spring profile
        if (environment.matchesProfiles("dev")) {
            System.out.println(
                    "   ℹ️  Running in 'dev' profile - additional dev-specific beans could be registered here");
        }
    }
}
