package com.example.beanregistrar_example.service;

public class PushNotificationService implements NotificationService {

    @Override
    public void sendNotification(String recipient, String message) {
        System.out.println("🔔 Sending PUSH notification to: " + recipient);
        System.out.println("   Message: " + message);
    }

    @Override
    public String getProviderName() {
        return "Push Notification Provider";
    }
}
