package com.example.beanregistrar_example;

import java.util.Map;

import com.example.beanregistrar_example.service.NotificationService;

import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class BeanregistrarExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(BeanregistrarExampleApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(ApplicationContext context) {
        return args -> {
            System.out.println("\n" + "=".repeat(70));
            System.out.println("🚀 BEAN REGISTRAR DEMO - Spring Framework 7");
            System.out.println("=".repeat(70) + "\n");

            // Get all NotificationService beans
            Map<String, NotificationService> notificationServices =
                    context.getBeansOfType(NotificationService.class);

            System.out.println(
                    "📦 Registered NotificationService beans: " + notificationServices.size());
            // Get bean factory to check primary status
            ConfigurableListableBeanFactory beanFactory =
                    ((ConfigurableApplicationContext) context).getBeanFactory();

            notificationServices.forEach(
                    (beanName, service) -> {
                        // Check if this bean is marked as primary
                        boolean isPrimary = beanFactory.getBeanDefinition(beanName).isPrimary();
                        String primaryLabel = isPrimary ? " [PRIMARY]" : "";
                        System.out.println(
                                "   - Bean name: '"
                                        + beanName
                                        + "' -> "
                                        + service.getClass().getSimpleName()
                                        + primaryLabel);
                    });

            System.out.println("\n" + "-".repeat(70));
            System.out.println("💬 Sending test notifications:");
            System.out.println("-".repeat(70) + "\n");

            // If we have a single notificationService bean (when provider is email/sms/push)
            if (context.containsBean("notificationService")) {
                NotificationService service =
                        context.getBean("notificationService", NotificationService.class);
                System.out.println("Using provider: " + service.getProviderName() + "\n");
                service.sendNotification("user@example.com", "Hello from BeanRegistrar!");
            }
            // If we have all services registered (when provider is 'all')
            else if (notificationServices.size() > 1) {
                System.out.println("Multiple providers registered. Testing each:\n");
                notificationServices.forEach(
                        (beanName, service) -> {
                            System.out.println("Provider: " + service.getProviderName());
                            service.sendNotification(
                                    "user@example.com",
                                    "Hello from " + service.getProviderName() + "!");
                            System.out.println();
                        });
            }

            System.out.println("=".repeat(70));
            System.out.println("✅ Demo completed successfully!");
            System.out.println("=".repeat(70) + "\n");

            System.out.println(
                    "💡 Try changing the 'app.notification.provider' property in application.properties");
            System.out.println("   Valid values: email, sms, push, priority, all\n");
        };
    }
}
