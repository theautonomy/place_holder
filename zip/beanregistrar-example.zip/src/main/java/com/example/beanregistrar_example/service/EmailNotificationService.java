package com.example.beanregistrar_example.service;

public class EmailNotificationService implements NotificationService {

    @Override
    public void sendNotification(String recipient, String message) {
        System.out.println("📧 Sending EMAIL to: " + recipient);
        System.out.println("   Message: " + message);
    }

    @Override
    public String getProviderName() {
        return "Email Provider";
    }
}
