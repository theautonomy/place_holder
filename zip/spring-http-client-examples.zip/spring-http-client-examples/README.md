# Spring HTTP Client Examples

This Spring Boot application demonstrates **all** the different ways to call external services using Spring Framework's HTTP client options with various underlying HTTP libraries, aligned with the official Spring Framework documentation.

## 🎯 Complete HTTP Client Matrix

All Spring HTTP clients are implemented with all supported underlying HTTP libraries:

| Client Type | JDK 11+ | Simple | Apache | Jetty | Netty |
|-------------|---------|--------|---------|--------|--------|
| **RestTemplate** | ✅ | ✅ | ✅ | ✅ | ✅ |
| **WebClient** (Reactive) | ✅ | ✅ | ✅ | ✅ | ✅ |
| **RestClient** (Spring 6.1+) | ✅ | ✅ | ✅ | ✅ | ✅ |
| **HTTP Interface** | ✅ | ✅ | ✅ | ✅ | ✅ |

### Official Spring HTTP Client Factories Used:
- `JdkClientHttpRequestFactory` (Java 11+, HTTP/2 support)
- `SimpleClientHttpRequestFactory` (Basic implementation)
- `HttpComponentsClientHttpRequestFactory` (Apache HttpClient 5)
- `JettyClientHttpRequestFactory` (Jetty HttpClient)
- `ReactorClientHttpRequestFactory` (Reactor Netty)

## 🚀 API Endpoints

### RestTemplate Examples
- `GET /api/resttemplate/{client-type}` - Get all posts
- `GET /api/resttemplate/{client-type}/{id}` - Get post by ID
- `POST /api/resttemplate/{client-type}` - Create new post

**Client types**: `jdk`, `simple`, `apache`, `jetty`, `netty`

### WebClient Examples (Reactive)
- `GET /api/webclient/{client-type}` - Get all posts as List
- `GET /api/webclient/{client-type}/stream` - Get all posts as Flux (streaming)
- `GET /api/webclient/{client-type}/{id}` - Get post by ID (Mono)
- `POST /api/webclient/{client-type}` - Create new post (Mono)
- `DELETE /api/webclient/{client-type}/{id}` - Delete post

**Client types**: `netty`, `jetty`, `jdk`, `simple`, `apache`

### RestClient Examples (Spring 6.1+)
- `GET /api/restclient/{client-type}` - Get all posts
- `GET /api/restclient/{client-type}/{id}` - Get post by ID
- `POST /api/restclient/{client-type}` - Create new post
- `PUT /api/restclient/{client-type}/{id}` - Update post
- `DELETE /api/restclient/{client-type}/{id}` - Delete post

**Client types**: `jdk`, `simple`, `apache`, `jetty`, `netty`

### HTTP Interface Examples (Declarative)

**Synchronous (RestClient-based):**
- `GET /api/httpinterface/restclient/{client-type}` - Get all posts
- `GET /api/httpinterface/restclient/{client-type}/{id}` - Get post by ID
- `POST /api/httpinterface/restclient/{client-type}` - Create new post

**Reactive (WebClient-based):**
- `GET /api/httpinterface/webclient/{client-type}` - Get all posts as Flux
- `GET /api/httpinterface/webclient/{client-type}/{id}` - Get post by ID as Mono
- `POST /api/httpinterface/webclient/{client-type}` - Create new post as Mono

**Client types**: `jdk`, `simple`, `apache`, `jetty`, `netty`

## 📊 Performance Analysis Tools

### Built-in Performance API
- `GET /api/performance/compare/get` - Compare GET request performance across all clients
- `GET /api/performance/compare/post` - Compare POST request performance across all clients
- `GET /api/performance/analysis` - Get detailed performance bottleneck analysis

### Performance Analysis Features
- Real-time performance measurement for all HTTP client combinations
- Detailed bottleneck analysis explaining why POST requests might be slower
- Connection pooling effectiveness testing
- HTTP client performance comparison

## 🧪 Testing Scripts

### Windows Batch Scripts
```bash
# Quick functionality test
.\test-endpoints-simple.bat

# Comprehensive endpoint testing with performance metrics
.\test-endpoints.bat

# Simple timing test
.\test.bat

# Direct API performance comparison (bypasses Spring)
.\direct-curl-test.bat

# Detailed POST performance diagnosis
.\post-performance-diagnosis.bat

# Quick baseline test
.\quick-curl-test.bat

# Compare Spring app vs direct API calls
.\spring-vs-direct-comparison.bat

# Verify POST test correctness
.\verify-post-test.bat
```

### PowerShell Script
```powershell
# Comprehensive performance analysis with proper error handling
.\performance-test.ps1
```

## 🏃‍♂️ Running the Application

```bash
# Start the application
mvn spring-boot:run

# Or compile and run
mvn clean compile
java -jar target/spring-http-client-examples-1.0.0.jar
```

The application will start on port 8080 with health check at `/actuator/health`.

## 💡 Example Usage

### Basic GET/POST Operations
```bash
# Get a post using RestTemplate with Apache HttpClient
curl http://localhost:8080/api/resttemplate/apache/1

# Create a post using WebClient with Netty (reactive)
curl -X POST http://localhost:8080/api/webclient/netty \
  -H "Content-Type: application/json" \
  -d '{"userId": 1, "title": "Test Post", "body": "This is a test post"}'

# Get all posts using RestClient with JDK HttpClient
curl http://localhost:8080/api/restclient/jdk

# Test HTTP Interface with Simple HttpClient
curl http://localhost:8080/api/httpinterface/restclient/simple/1
```

### Performance Testing
```bash
# Get performance analysis
curl http://localhost:8080/api/performance/analysis

# Compare GET performance across all clients
curl http://localhost:8080/api/performance/compare/get

# Compare POST performance across all clients
curl http://localhost:8080/api/performance/compare/post
```

### Streaming Examples (WebClient)
```bash
# Get streaming response (Flux)
curl http://localhost:8080/api/webclient/netty/stream

# Reactive HTTP Interface streaming
curl http://localhost:8080/api/httpinterface/webclient/netty
```

## 🔧 Key Features Demonstrated

### 1. **Complete HTTP Library Coverage**
- All 5 official Spring HTTP client factories implemented
- Every client type (RestTemplate, WebClient, RestClient, HTTP Interface) supports all underlying libraries
- Production-ready configurations with connection pooling and timeouts

### 2. **Performance Optimization**
- Connection pooling configuration for Apache HttpClient (200 total, 50 per route)
- Proper timeout settings (5s connect, 30s read)
- HTTP/2 support for JDK HttpClient
- Reactor Netty connection provider configuration

### 3. **Reactive Programming**
- WebClient Mono/Flux operations
- Reactive streaming endpoints
- Non-blocking HTTP Interface examples
- Backpressure handling

### 4. **Real-World Configuration**
- Production-ready connection pool settings
- Timeout configurations per client type
- Keep-alive and connection reuse optimization
- Error handling and retry policies

### 5. **Performance Analysis**
- Built-in performance measurement tools
- POST vs GET performance comparison
- Connection reuse effectiveness testing
- Bottleneck identification and solutions

### 6. **Comprehensive Testing**
- Automated test scripts for all client combinations
- Performance benchmarking tools
- Connection warmup testing
- Payload size impact analysis

## 📈 Performance Characteristics

### Expected Response Times (to JSONPlaceholder API)
- **GET requests**: 100-300ms (network dependent)
- **POST requests**: 120-400ms (includes request body processing)
- **First request**: Higher due to connection establishment
- **Subsequent requests**: Lower with connection reuse

### Client Performance Ranking
1. **Netty (ReactorClientHttpRequestFactory)** - Best for high concurrency/reactive apps
2. **Apache HttpClient** - Best general purpose with proper configuration
3. **JDK HttpClient** - Good balance, HTTP/2 support, Java 11+ built-in
4. **Jetty HttpClient** - Good for specific use cases, lightweight
5. **Simple HttpClient** - Basic implementation, suitable for low-volume apps

## 🛠️ Dependencies

The project includes all necessary HTTP client libraries:

```xml
<!-- Spring Boot Web & WebFlux -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-webflux</artifactId>
</dependency>

<!-- Apache HttpComponents (modern and legacy) -->
<dependency>
    <groupId>org.apache.httpcomponents.client5</groupId>
    <artifactId>httpclient5</artifactId>
</dependency>

<!-- Jetty HttpClient -->
<dependency>
    <groupId>org.eclipse.jetty</groupId>
    <artifactId>jetty-client</artifactId>
</dependency>
<dependency>
    <groupId>org.eclipse.jetty</groupId>
    <artifactId>jetty-reactive-httpclient</artifactId>
</dependency>

<!-- Reactor Netty (included with WebFlux) -->
<!-- JDK HttpClient (built into Java 11+) -->
```

## 🔍 Troubleshooting POST Performance

If POST requests are slower than expected, use the analysis tools:

```bash
# Get detailed performance analysis
curl http://localhost:8080/api/performance/analysis

# Run comprehensive diagnosis
.\post-performance-diagnosis.bat

# Compare with direct API calls
.\spring-vs-direct-comparison.bat
```

Common issues and solutions are documented in `POST-PERFORMANCE-ANALYSIS.md`.

## 📚 Documentation

- `POST-PERFORMANCE-ANALYSIS.md` - Detailed POST performance optimization guide
- `httpie-performance-test.md` - HTTPie testing examples
- Test scripts include detailed analysis and troubleshooting steps

---

This project demonstrates the complete flexibility of Spring Framework's HTTP client abstractions, showing how you can switch between different underlying implementations based on your specific requirements for performance, reactive programming, or compatibility.

## 🕐 curl Performance Timing

### From Command Line
```bash
# Basic timing (includes response output)
curl -s -w "time: %{time_total}" http://localhost:8080/api/restclient/jdk/1

# Silent timing (no response output)
curl -s -o /dev/null -w "time: %{time_total}" http://localhost:8080/api/restclient/jdk/1

# Detailed timing breakdown
curl -s -o /dev/null -w "
Total: %{time_total}s
DNS: %{time_namelookup}s
Connect: %{time_connect}s
TLS: %{time_appconnect}s
Transfer: %{time_starttransfer}s
" http://localhost:8080/api/restclient/jdk/1
```

### From Windows Batch Script
```batch
@REM Note: Use double %% to escape in batch files
curl -s -o /dev/null -w "time: %%{time_total}" http://localhost:8080/api/restclient/jdk/1

@REM Performance comparison loop
for /l %%i in (1,1,5) do (
    echo Request %%i:
    curl -s -o /dev/null -w "JDK: %%{time_total}s\n" %BASE_URL%/api/restclient/jdk/1
    curl -s -o /dev/null -w "Apache: %%{time_total}s\n" %BASE_URL%/api/restclient/apache/1
    curl -s -o /dev/null -w "Netty: %%{time_total}s\n" %BASE_URL%/api/restclient/netty/1
)
```

### Testing Different HTTP Methods
```bash
# GET vs POST timing comparison
curl -s -o /dev/null -w "GET: %{time_total}s\n" http://localhost:8080/api/restclient/jdk/1

curl -s -o /dev/null -w "POST: %{time_total}s\n" \
  -X POST -H "Content-Type: application/json" \
  -d '{"userId": 1, "title": "Test", "body": "Test"}' \
  http://localhost:8080/api/restclient/jdk

# Connection reuse test
for i in {1..3}; do
  echo "Request $i:"
  curl -s -o /dev/null -w "  Time: %{time_total}s | Connect: %{time_connect}s\n" \
    http://localhost:8080/api/restclient/apache/1
done
```

### Common Timing Variables
- `%{time_total}` - Total transaction time
- `%{time_connect}` - Connection establishment time
- `%{time_namelookup}` - DNS lookup time
- `%{time_appconnect}` - TLS handshake time
- `%{time_starttransfer}` - Time to first byte
- `%{time_pretransfer}` - Time before file transfer
- `%{speed_download}` - Download speed (bytes/sec)
- `%{response_code}` - HTTP response code

### Performance Analysis Tips
```bash
# Check if connection pooling is working (connect time should be ~0 after first request)
curl -s -o /dev/null -w "Connect: %{time_connect}s\n" http://localhost:8080/api/restclient/apache/1

# Compare all HTTP clients quickly
echo "JDK:" && curl -s -o /dev/null -w "%{time_total}s\n" http://localhost:8080/api/restclient/jdk/1
echo "Simple:" && curl -s -o /dev/null -w "%{time_total}s\n" http://localhost:8080/api/restclient/simple/1
echo "Apache:" && curl -s -o /dev/null -w "%{time_total}s\n" http://localhost:8080/api/restclient/apache/1
echo "Jetty:" && curl -s -o /dev/null -w "%{time_total}s\n" http://localhost:8080/api/restclient/jetty/1
echo "Netty:" && curl -s -o /dev/null -w "%{time_total}s\n" http://localhost:8080/api/restclient/netty/1
```
