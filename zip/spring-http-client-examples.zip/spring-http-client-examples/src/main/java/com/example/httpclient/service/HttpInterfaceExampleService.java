package com.example.httpclient.service;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class HttpInterfaceExampleService {

    private final JsonPlaceholderHttpInterface httpInterfaceRestClientJdk;
    private final JsonPlaceholderHttpInterface httpInterfaceRestClientSimple;
    private final JsonPlaceholderHttpInterface httpInterfaceRestClientApache;
    private final JsonPlaceholderHttpInterface httpInterfaceRestClientJetty;
    private final JsonPlaceholderHttpInterface httpInterfaceRestClientNetty;
    private final JsonPlaceholderHttpInterface httpInterfaceWebClientNetty;
    private final JsonPlaceholderHttpInterface httpInterfaceWebClientJetty;

    public HttpInterfaceExampleService(
            @Qualifier("httpInterfaceWithRestClientJdk")
                    JsonPlaceholderHttpInterface httpInterfaceRestClientJdk,
            @Qualifier("httpInterfaceWithRestClientSimple")
                    JsonPlaceholderHttpInterface httpInterfaceRestClientSimple,
            @Qualifier("httpInterfaceWithRestClientApache")
                    JsonPlaceholderHttpInterface httpInterfaceRestClientApache,
            @Qualifier("httpInterfaceWithRestClientJetty")
                    JsonPlaceholderHttpInterface httpInterfaceRestClientJetty,
            @Qualifier("httpInterfaceWithRestClientNetty")
                    JsonPlaceholderHttpInterface httpInterfaceRestClientNetty,
            @Qualifier("httpInterfaceWithWebClientNetty")
                    JsonPlaceholderHttpInterface httpInterfaceWebClientNetty,
            @Qualifier("httpInterfaceWithWebClientJetty")
                    JsonPlaceholderHttpInterface httpInterfaceWebClientJetty) {
        this.httpInterfaceRestClientJdk = httpInterfaceRestClientJdk;
        this.httpInterfaceRestClientSimple = httpInterfaceRestClientSimple;
        this.httpInterfaceRestClientApache = httpInterfaceRestClientApache;
        this.httpInterfaceRestClientJetty = httpInterfaceRestClientJetty;
        this.httpInterfaceRestClientNetty = httpInterfaceRestClientNetty;
        this.httpInterfaceWebClientNetty = httpInterfaceWebClientNetty;
        this.httpInterfaceWebClientJetty = httpInterfaceWebClientJetty;
    }

    public JsonPlaceholderPost getPostWithRestClientJdk(Long id) {
        return httpInterfaceRestClientJdk.getPost(id);
    }

    public JsonPlaceholderPost getPostWithRestClientSimple(Long id) {
        return httpInterfaceRestClientSimple.getPost(id);
    }

    public JsonPlaceholderPost getPostWithRestClientApache(Long id) {
        return httpInterfaceRestClientApache.getPost(id);
    }

    public JsonPlaceholderPost getPostWithRestClientJetty(Long id) {
        return httpInterfaceRestClientJetty.getPost(id);
    }

    public List<JsonPlaceholderPost> getAllPostsWithRestClientJdk() {
        return httpInterfaceRestClientJdk.getAllPosts();
    }

    public List<JsonPlaceholderPost> getAllPostsWithRestClientSimple() {
        return httpInterfaceRestClientSimple.getAllPosts();
    }

    public List<JsonPlaceholderPost> getAllPostsWithRestClientApache() {
        return httpInterfaceRestClientApache.getAllPosts();
    }

    public List<JsonPlaceholderPost> getAllPostsWithRestClientJetty() {
        return httpInterfaceRestClientJetty.getAllPosts();
    }

    public Mono<JsonPlaceholderPost> getPostReactiveWithWebClientNetty(Long id) {
        return httpInterfaceWebClientNetty.getPostReactive(id);
    }

    public Mono<JsonPlaceholderPost> getPostReactiveWithWebClientJetty(Long id) {
        return httpInterfaceWebClientJetty.getPostReactive(id);
    }

    public Flux<JsonPlaceholderPost> getAllPostsReactiveWithWebClientNetty() {
        return httpInterfaceWebClientNetty.getAllPostsReactive();
    }

    public Flux<JsonPlaceholderPost> getAllPostsReactiveWithWebClientJetty() {
        return httpInterfaceWebClientJetty.getAllPostsReactive();
    }

    public JsonPlaceholderPost createPostWithRestClientJdk(JsonPlaceholderPost post) {
        return httpInterfaceRestClientJdk.createPost(post);
    }

    public JsonPlaceholderPost createPostWithRestClientSimple(JsonPlaceholderPost post) {
        return httpInterfaceRestClientSimple.createPost(post);
    }

    public JsonPlaceholderPost createPostWithRestClientApache(JsonPlaceholderPost post) {
        return httpInterfaceRestClientApache.createPost(post);
    }

    public JsonPlaceholderPost createPostWithRestClientJetty(JsonPlaceholderPost post) {
        return httpInterfaceRestClientJetty.createPost(post);
    }

    public Mono<JsonPlaceholderPost> createPostReactiveWithWebClientNetty(
            JsonPlaceholderPost post) {
        return httpInterfaceWebClientNetty.createPostReactive(post);
    }

    public Mono<JsonPlaceholderPost> createPostReactiveWithWebClientJetty(
            JsonPlaceholderPost post) {
        return httpInterfaceWebClientJetty.createPostReactive(post);
    }

    public JsonPlaceholderPost getPostWithRestClientNetty(Long id) {
        return httpInterfaceRestClientNetty.getPost(id);
    }

    public List<JsonPlaceholderPost> getAllPostsWithRestClientNetty() {
        return httpInterfaceRestClientNetty.getAllPosts();
    }

    public JsonPlaceholderPost createPostWithRestClientNetty(JsonPlaceholderPost post) {
        return httpInterfaceRestClientNetty.createPost(post);
    }
}
