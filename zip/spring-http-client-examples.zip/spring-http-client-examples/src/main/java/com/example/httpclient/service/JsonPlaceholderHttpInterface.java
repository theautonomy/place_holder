package com.example.httpclient.service;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.service.annotation.DeleteExchange;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;
import org.springframework.web.service.annotation.PostExchange;
import org.springframework.web.service.annotation.PutExchange;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@HttpExchange("https://jsonplaceholder.typicode.com")
public interface JsonPlaceholderHttpInterface {

    @GetExchange("/posts/{id}")
    JsonPlaceholderPost getPost(@PathVariable Long id);

    @GetExchange("/posts")
    List<JsonPlaceholderPost> getAllPosts();

    @GetExchange("/posts/{id}")
    Mono<JsonPlaceholderPost> getPostReactive(@PathVariable Long id);

    @GetExchange("/posts")
    Flux<JsonPlaceholderPost> getAllPostsReactive();

    @PostExchange("/posts")
    JsonPlaceholderPost createPost(@RequestBody JsonPlaceholderPost post);

    @PostExchange("/posts")
    Mono<JsonPlaceholderPost> createPostReactive(@RequestBody JsonPlaceholderPost post);

    @PutExchange("/posts/{id}")
    JsonPlaceholderPost updatePost(@PathVariable Long id, @RequestBody JsonPlaceholderPost post);

    @PutExchange("/posts/{id}")
    Mono<JsonPlaceholderPost> updatePostReactive(
            @PathVariable Long id, @RequestBody JsonPlaceholderPost post);

    @DeleteExchange("/posts/{id}")
    void deletePost(@PathVariable Long id);

    @DeleteExchange("/posts/{id}")
    Mono<Void> deletePostReactive(@PathVariable Long id);
}
