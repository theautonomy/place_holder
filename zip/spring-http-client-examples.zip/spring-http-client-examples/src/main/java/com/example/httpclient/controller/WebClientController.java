package com.example.httpclient.controller;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;
import com.example.httpclient.service.WebClientExampleService;

import org.springframework.web.bind.annotation.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/webclient")
public class WebClientController {

    private final WebClientExampleService webClientService;

    public WebClientController(WebClientExampleService webClientService) {
        this.webClientService = webClientService;
    }

    @GetMapping("/netty/{id}")
    public Mono<JsonPlaceholderPost> getPostWithNetty(@PathVariable Long id) {
        return webClientService.getPostWithNetty(id);
    }

    @GetMapping("/jetty/{id}")
    public Mono<JsonPlaceholderPost> getPostWithJetty(@PathVariable Long id) {
        return webClientService.getPostWithJetty(id);
    }

    @GetMapping("/jdk/{id}")
    public Mono<JsonPlaceholderPost> getPostWithJdk(@PathVariable Long id) {
        return webClientService.getPostWithJdk(id);
    }

    @GetMapping("/apache/{id}")
    public Mono<JsonPlaceholderPost> getPostWithApache(@PathVariable Long id) {
        return webClientService.getPostWithApache(id);
    }

    @GetMapping("/netty/stream")
    public Flux<JsonPlaceholderPost> getAllPostsStreamWithNetty() {
        return webClientService.getAllPostsWithNetty();
    }

    @GetMapping("/jetty/stream")
    public Flux<JsonPlaceholderPost> getAllPostsStreamWithJetty() {
        return webClientService.getAllPostsWithJetty();
    }

    @GetMapping("/jdk/stream")
    public Flux<JsonPlaceholderPost> getAllPostsStreamWithJdk() {
        return webClientService.getAllPostsWithJdk();
    }

    @GetMapping("/apache/stream")
    public Flux<JsonPlaceholderPost> getAllPostsStreamWithApache() {
        return webClientService.getAllPostsWithApache();
    }

    @GetMapping("/netty")
    public Mono<List<JsonPlaceholderPost>> getAllPostsWithNetty() {
        return webClientService.getAllPostsAsListWithNetty();
    }

    @GetMapping("/jetty")
    public Mono<List<JsonPlaceholderPost>> getAllPostsWithJetty() {
        return webClientService.getAllPostsAsListWithJetty();
    }

    @GetMapping("/jdk")
    public List<JsonPlaceholderPost> getAllPostsWithJdk() {
        return webClientService.getAllPostsAsListWithJdk();
    }

    @GetMapping("/apache")
    public List<JsonPlaceholderPost> getAllPostsWithApache() {
        return webClientService.getAllPostsAsListWithApache();
    }

    @PostMapping("/netty")
    public Mono<JsonPlaceholderPost> createPostWithNetty(@RequestBody JsonPlaceholderPost post) {
        return webClientService.createPostWithNetty(post);
    }

    @PostMapping("/jetty")
    public Mono<JsonPlaceholderPost> createPostWithJetty(@RequestBody JsonPlaceholderPost post) {
        return webClientService.createPostWithJetty(post);
    }

    @PostMapping("/jdk")
    public Mono<JsonPlaceholderPost> createPostWithJdk(@RequestBody JsonPlaceholderPost post) {
        return webClientService.createPostWithJdk(post);
    }

    @PostMapping("/apache")
    public Mono<JsonPlaceholderPost> createPostWithApache(@RequestBody JsonPlaceholderPost post) {
        return webClientService.createPostWithApache(post);
    }

    @DeleteMapping("/netty/{id}")
    public Mono<Void> deletePostWithNetty(@PathVariable Long id) {
        return webClientService.deletePostWithNetty(id);
    }

    @DeleteMapping("/jetty/{id}")
    public Mono<Void> deletePostWithJetty(@PathVariable Long id) {
        return webClientService.deletePostWithJetty(id);
    }

    @DeleteMapping("/jdk/{id}")
    public Mono<Void> deletePostWithJdk(@PathVariable Long id) {
        return webClientService.deletePostWithJdk(id);
    }

    @DeleteMapping("/apache/{id}")
    public Mono<Void> deletePostWithApache(@PathVariable Long id) {
        return webClientService.deletePostWithApache(id);
    }
}
