package com.example.httpclient.controller;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;
import com.example.httpclient.service.RestClientExampleService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/restclient")
public class RestClientController {

    private final RestClientExampleService restClientService;

    public RestClientController(RestClientExampleService restClientService) {
        this.restClientService = restClientService;
    }

    @GetMapping("/jdk/{id}")
    public JsonPlaceholderPost getPostWithJdk(@PathVariable Long id) {
        return restClientService.getPostWithJdkHttpClient(id);
    }

    @GetMapping("/simple/{id}")
    public JsonPlaceholderPost getPostWithSimple(@PathVariable Long id) {
        return restClientService.getPostWithSimpleHttpClient(id);
    }

    @GetMapping("/apache/{id}")
    public JsonPlaceholderPost getPostWithApache(@PathVariable Long id) {
        return restClientService.getPostWithApacheHttpClient(id);
    }

    @GetMapping("/jetty/{id}")
    public JsonPlaceholderPost getPostWithJetty(@PathVariable Long id) {
        return restClientService.getPostWithJettyHttpClient(id);
    }

    @GetMapping("/jdk")
    public List<JsonPlaceholderPost> getAllPostsWithJdk() {
        return restClientService.getAllPostsWithJdkHttpClient();
    }

    @GetMapping("/simple")
    public List<JsonPlaceholderPost> getAllPostsWithSimple() {
        return restClientService.getAllPostsWithSimpleHttpClient();
    }

    @GetMapping("/apache")
    public List<JsonPlaceholderPost> getAllPostsWithApache() {
        return restClientService.getAllPostsWithApacheHttpClient();
    }

    @GetMapping("/jetty")
    public List<JsonPlaceholderPost> getAllPostsWithJetty() {
        return restClientService.getAllPostsWithJettyHttpClient();
    }

    @PostMapping("/jdk")
    public JsonPlaceholderPost createPostWithJdk(@RequestBody JsonPlaceholderPost post) {
        return restClientService.createPostWithJdkHttpClient(post);
    }

    @PostMapping("/simple")
    public JsonPlaceholderPost createPostWithSimple(@RequestBody JsonPlaceholderPost post) {
        return restClientService.createPostWithSimpleHttpClient(post);
    }

    @PostMapping("/apache")
    public JsonPlaceholderPost createPostWithApache(@RequestBody JsonPlaceholderPost post) {
        return restClientService.createPostWithApacheHttpClient(post);
    }

    @PostMapping("/jetty")
    public JsonPlaceholderPost createPostWithJetty(@RequestBody JsonPlaceholderPost post) {
        return restClientService.createPostWithJettyHttpClient(post);
    }

    @PutMapping("/jdk/{id}")
    public JsonPlaceholderPost updatePostWithJdk(
            @PathVariable Long id, @RequestBody JsonPlaceholderPost post) {
        return restClientService.updatePostWithJdkHttpClient(id, post);
    }

    @PutMapping("/simple/{id}")
    public JsonPlaceholderPost updatePostWithSimple(
            @PathVariable Long id, @RequestBody JsonPlaceholderPost post) {
        return restClientService.updatePostWithSimpleHttpClient(id, post);
    }

    @PutMapping("/apache/{id}")
    public JsonPlaceholderPost updatePostWithApache(
            @PathVariable Long id, @RequestBody JsonPlaceholderPost post) {
        return restClientService.updatePostWithApacheHttpClient(id, post);
    }

    @PutMapping("/jetty/{id}")
    public JsonPlaceholderPost updatePostWithJetty(
            @PathVariable Long id, @RequestBody JsonPlaceholderPost post) {
        return restClientService.updatePostWithJettyHttpClient(id, post);
    }

    @DeleteMapping("/jdk/{id}")
    public ResponseEntity<Void> deletePostWithJdk(@PathVariable Long id) {
        return restClientService.deletePostWithJdkHttpClient(id);
    }

    @DeleteMapping("/simple/{id}")
    public ResponseEntity<Void> deletePostWithSimple(@PathVariable Long id) {
        return restClientService.deletePostWithSimpleHttpClient(id);
    }

    @DeleteMapping("/apache/{id}")
    public ResponseEntity<Void> deletePostWithApache(@PathVariable Long id) {
        return restClientService.deletePostWithApacheHttpClient(id);
    }

    @DeleteMapping("/jetty/{id}")
    public ResponseEntity<Void> deletePostWithJetty(@PathVariable Long id) {
        return restClientService.deletePostWithJettyHttpClient(id);
    }

    @GetMapping("/netty/{id}")
    public JsonPlaceholderPost getPostWithNetty(@PathVariable Long id) {
        return restClientService.getPostWithNettyHttpClient(id);
    }

    @GetMapping("/netty")
    public List<JsonPlaceholderPost> getAllPostsWithNetty() {
        return restClientService.getAllPostsWithNettyHttpClient();
    }

    @PostMapping("/netty")
    public JsonPlaceholderPost createPostWithNetty(@RequestBody JsonPlaceholderPost post) {
        return restClientService.createPostWithNettyHttpClient(post);
    }

    @PutMapping("/netty/{id}")
    public JsonPlaceholderPost updatePostWithNetty(
            @PathVariable Long id, @RequestBody JsonPlaceholderPost post) {
        return restClientService.updatePostWithNettyHttpClient(id, post);
    }

    @DeleteMapping("/netty/{id}")
    public ResponseEntity<Void> deletePostWithNetty(@PathVariable Long id) {
        return restClientService.deletePostWithNettyHttpClient(id);
    }
}
