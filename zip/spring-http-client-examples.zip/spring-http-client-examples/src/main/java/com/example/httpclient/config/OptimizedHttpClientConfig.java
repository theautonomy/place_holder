package com.example.httpclient.config;

import java.time.Duration;

import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.apache.hc.client5.http.impl.async.HttpAsyncClients;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.io.HttpClientConnectionManager;
import org.apache.hc.core5.util.Timeout;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.http.client.JettyClientHttpRequestFactory;
import org.springframework.http.client.ReactorClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.client.reactive.HttpComponentsClientHttpConnector;
import org.springframework.http.client.reactive.JdkClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import io.netty.channel.ChannelOption;

@Configuration
@Profile("optimized")
public class OptimizedHttpClientConfig {

    // Optimized JDK HTTP Client
    @Bean("optimizedRestTemplateWithJdkHttpClient")
    public RestTemplate optimizedRestTemplateWithJdkHttpClient() {
        JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory();
        // Note: JdkClientHttpRequestFactory timeouts are configured via the underlying HttpClient
        return new RestTemplate(factory);
    }

    // Optimized Simple HTTP Client
    @Bean("optimizedRestTemplateWithSimpleHttpClient")
    public RestTemplate optimizedRestTemplateWithSimpleHttpClient() {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(5000);
        factory.setReadTimeout(30000);
        // Enable connection pooling for Simple HTTP client
        // factory.setBufferRequestBody(false); // Deprecated method
        return new RestTemplate(factory);
    }

    // Optimized Apache HTTP Client with better configuration
    @Bean("optimizedRestTemplateWithApacheHttpClient5")
    public RestTemplate optimizedRestTemplateWithApacheHttpClient5() {
        // Enhanced connection manager
        HttpClientConnectionManager connectionManager =
                PoolingHttpClientConnectionManagerBuilder.create()
                        .setMaxConnTotal(200) // Increased total connections
                        .setMaxConnPerRoute(50) // Increased connections per route
                        .build();

        // Request configuration for timeouts
        RequestConfig requestConfig =
                RequestConfig.custom()
                        .setConnectionRequestTimeout(Timeout.ofSeconds(30))
                        .setResponseTimeout(org.apache.hc.core5.util.Timeout.ofSeconds(30))
                        .build();

        CloseableHttpClient httpClient =
                HttpClients.custom()
                        .setConnectionManager(connectionManager)
                        .setDefaultRequestConfig(requestConfig)
                        .build();

        HttpComponentsClientHttpRequestFactory factory =
                new HttpComponentsClientHttpRequestFactory(httpClient);
        factory.setConnectTimeout(5000);
        factory.setReadTimeout(30000);

        return new RestTemplate(factory);
    }

    // Optimized Jetty HTTP Client
    @Bean("optimizedRestTemplateWithJettyHttpClient")
    public RestTemplate optimizedRestTemplateWithJettyHttpClient() throws Exception {
        org.eclipse.jetty.client.HttpClient jettyHttpClient =
                new org.eclipse.jetty.client.HttpClient();

        // Enhanced Jetty configuration
        jettyHttpClient.setConnectTimeout(5000);
        jettyHttpClient.setIdleTimeout(30000);
        jettyHttpClient.setMaxConnectionsPerDestination(50);
        jettyHttpClient.setMaxRequestsQueuedPerDestination(100);

        jettyHttpClient.start();

        JettyClientHttpRequestFactory factory = new JettyClientHttpRequestFactory(jettyHttpClient);
        // Timeouts configured on the underlying Jetty client

        return new RestTemplate(factory);
    }

    // Optimized Netty HTTP Client
    @Bean("optimizedRestTemplateWithNettyHttpClient")
    public RestTemplate optimizedRestTemplateWithNettyHttpClient() {
        reactor.netty.http.client.HttpClient reactorHttpClient =
                reactor.netty.http.client.HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(30))
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                        .option(ChannelOption.SO_KEEPALIVE, true)
                        .option(ChannelOption.SO_REUSEADDR, true);

        ReactorClientHttpRequestFactory factory =
                new ReactorClientHttpRequestFactory(reactorHttpClient);

        return new RestTemplate(factory);
    }

    // Optimized WebClient configurations
    @Bean("optimizedWebClientWithNetty")
    public WebClient optimizedWebClientWithNetty() {
        reactor.netty.http.client.HttpClient reactorHttpClient =
                reactor.netty.http.client.HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(30))
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                        .option(ChannelOption.SO_KEEPALIVE, true)
                        .option(ChannelOption.SO_REUSEADDR, true);

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(reactorHttpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .codecs(
                        configurer ->
                                configurer
                                        .defaultCodecs()
                                        .maxInMemorySize(1024 * 1024)) // 1MB buffer
                .build();
    }

    @Bean("optimizedWebClientWithJdkHttpClient")
    public WebClient optimizedWebClientWithJdkHttpClient() {
        java.net.http.HttpClient httpClient =
                java.net.http.HttpClient.newBuilder()
                        .connectTimeout(Duration.ofSeconds(5))
                        .version(
                                java.net.http.HttpClient.Version
                                        .HTTP_2) // Use HTTP/2 for better performance
                        .build();

        return WebClient.builder()
                .clientConnector(new JdkClientHttpConnector(httpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(1024 * 1024))
                .build();
    }

    @Bean("optimizedWebClientWithApacheHttpClient")
    public WebClient optimizedWebClientWithApacheHttpClient() {
        RequestConfig requestConfig =
                RequestConfig.custom()
                        .setConnectionRequestTimeout(org.apache.hc.core5.util.Timeout.ofSeconds(5))
                        .setResponseTimeout(org.apache.hc.core5.util.Timeout.ofSeconds(30))
                        .build();

        CloseableHttpAsyncClient apacheHttpClient =
                HttpAsyncClients.custom().setDefaultRequestConfig(requestConfig).build();

        HttpComponentsClientHttpConnector connector =
                new HttpComponentsClientHttpConnector(apacheHttpClient);

        return WebClient.builder()
                .clientConnector(connector)
                .baseUrl("https://jsonplaceholder.typicode.com")
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(1024 * 1024))
                .build();
    }

    // Optimized RestClient configurations
    @Bean("optimizedRestClientWithJdkHttpClient")
    public RestClient optimizedRestClientWithJdkHttpClient() {
        JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory();
        // Timeouts configured via underlying HttpClient

        return RestClient.builder()
                .requestFactory(factory)
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("optimizedRestClientWithNettyHttpClient")
    public RestClient optimizedRestClientWithNettyHttpClient() {
        reactor.netty.http.client.HttpClient reactorHttpClient =
                reactor.netty.http.client.HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(30))
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000)
                        .option(ChannelOption.SO_KEEPALIVE, true)
                        .option(ChannelOption.SO_REUSEADDR, true);

        return RestClient.builder()
                .requestFactory(new ReactorClientHttpRequestFactory(reactorHttpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }
}
