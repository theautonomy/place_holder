package com.example.httpclient.controller;

import java.util.Map;

import com.example.httpclient.service.PerformanceAnalysisService;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/performance")
public class PerformanceController {

    private final PerformanceAnalysisService performanceService;

    public PerformanceController(PerformanceAnalysisService performanceService) {
        this.performanceService = performanceService;
    }

    @GetMapping("/compare/get")
    public Map<String, Long> compareGetPerformance() {
        return performanceService.compareGetPerformance();
    }

    @GetMapping("/compare/post")
    public Map<String, Long> comparePostPerformance() {
        return performanceService.comparePostPerformance();
    }

    @GetMapping("/analysis")
    public String getPerformanceAnalysis() {
        return performanceService.analyzePerformanceBottlenecks();
    }
}
