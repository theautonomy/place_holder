package com.example.httpclient.config;

import java.time.Duration;

import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.apache.hc.client5.http.impl.async.HttpAsyncClients;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.io.HttpClientConnectionManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.http.client.JettyClientHttpRequestFactory;
import org.springframework.http.client.ReactorClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.client.reactive.HttpComponentsClientHttpConnector;
import org.springframework.http.client.reactive.JdkClientHttpConnector;
import org.springframework.http.client.reactive.JettyClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import io.netty.channel.ChannelOption;

@Configuration
public class HttpClientConfig {

    @Bean("restTemplateWithJdkHttpClient")
    public RestTemplate restTemplateWithJdkHttpClient() {
        return new RestTemplate(new JdkClientHttpRequestFactory());
    }

    @Bean("restTemplateWithSimpleHttpClient")
    public RestTemplate restTemplateWithSimpleHttpClient() {
        return new RestTemplate(new SimpleClientHttpRequestFactory());
    }

    @Bean("restTemplateWithApacheHttpClient5")
    public RestTemplate restTemplateWithApacheHttpClient5() {
        HttpClientConnectionManager connectionManager =
                PoolingHttpClientConnectionManagerBuilder.create()
                        .setMaxConnTotal(100)
                        .setMaxConnPerRoute(20)
                        .build();

        CloseableHttpClient httpClient =
                HttpClients.custom().setConnectionManager(connectionManager).build();

        return new RestTemplate(new HttpComponentsClientHttpRequestFactory(httpClient));
    }

    @Bean("restTemplateWithJettyHttpClient")
    public RestTemplate restTemplateWithJettyHttpClient() throws Exception {
        org.eclipse.jetty.client.HttpClient jettyHttpClient =
                new org.eclipse.jetty.client.HttpClient();
        jettyHttpClient.setConnectTimeout(10000);
        jettyHttpClient.start();

        return new RestTemplate(new JettyClientHttpRequestFactory(jettyHttpClient));
    }

    @Bean("restTemplateWithNettyHttpClient")
    public RestTemplate restTemplateWithNettyHttpClient() {
        reactor.netty.http.client.HttpClient reactorHttpClient =
                reactor.netty.http.client.HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(30))
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000);

        return new RestTemplate(new ReactorClientHttpRequestFactory(reactorHttpClient));
    }

    @Bean("webClientWithNetty")
    public WebClient webClientWithNetty() {
        reactor.netty.http.client.HttpClient reactorHttpClient =
                reactor.netty.http.client.HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(30))
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000);

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(reactorHttpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("webClientWithJetty")
    public WebClient webClientWithJetty() throws Exception {
        org.eclipse.jetty.client.HttpClient jettyHttpClient =
                new org.eclipse.jetty.client.HttpClient();
        jettyHttpClient.start();

        return WebClient.builder()
                .clientConnector(new JettyClientHttpConnector(jettyHttpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("webClientWithJdkHttpClient")
    public WebClient webClientWithJdkHttpClient() {
        java.net.http.HttpClient httpClient =
                java.net.http.HttpClient.newBuilder()
                        .connectTimeout(
                                Duration.ofSeconds(10)) // Sets a 10-second connection timeout
                        .build();

        return WebClient.builder()
                .clientConnector(new JdkClientHttpConnector(httpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("webClientWithApacheHttpClient")
    public WebClient webClientWithApacheHttpClient() {
        CloseableHttpAsyncClient apacheHttpClient = HttpAsyncClients.createDefault();

        HttpComponentsClientHttpConnector connector =
                new HttpComponentsClientHttpConnector(apacheHttpClient);

        /*
        HttpAsyncClientBuilder clientBuilder = HttpAsyncClients.custom();
        clientBuilder.setDefaultRequestConfig(...);
        CloseableHttpAsyncClient client = clientBuilder.build();
        ClientHttpConnector connector = new HttpComponentsClientHttpConnector(client);

        WebClient webClient = WebClient.builder().clientConnector(connector).build();
        */

        return WebClient.builder()
                .clientConnector(connector)
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("restClientWithJdkHttpClient")
    public RestClient restClientWithJdkHttpClient() {
        return RestClient.builder()
                .requestFactory(new JdkClientHttpRequestFactory())
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("restClientWithSimpleHttpClient")
    public RestClient restClientWithSimpleHttpClient() {
        return RestClient.builder()
                .requestFactory(new SimpleClientHttpRequestFactory())
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("restClientWithApacheHttpClient5")
    public RestClient restClientWithApacheHttpClient5() {
        HttpClientConnectionManager connectionManager =
                PoolingHttpClientConnectionManagerBuilder.create()
                        .setMaxConnTotal(100)
                        .setMaxConnPerRoute(20)
                        .build();

        CloseableHttpClient httpClient =
                HttpClients.custom().setConnectionManager(connectionManager).build();

        return RestClient.builder()
                .requestFactory(new HttpComponentsClientHttpRequestFactory(httpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("restClientWithJettyHttpClient")
    public RestClient restClientWithJettyHttpClient() throws Exception {
        org.eclipse.jetty.client.HttpClient jettyHttpClient =
                new org.eclipse.jetty.client.HttpClient();
        jettyHttpClient.setConnectTimeout(10000);
        jettyHttpClient.start();

        return RestClient.builder()
                .requestFactory(new JettyClientHttpRequestFactory(jettyHttpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }

    @Bean("restClientWithNettyHttpClient")
    public RestClient restClientWithNettyHttpClient() {
        reactor.netty.http.client.HttpClient reactorHttpClient =
                reactor.netty.http.client.HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(30))
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000);

        return RestClient.builder()
                .requestFactory(new ReactorClientHttpRequestFactory(reactorHttpClient))
                .baseUrl("https://jsonplaceholder.typicode.com")
                .build();
    }
}
