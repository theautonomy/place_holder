package com.example.httpclient.service;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RestTemplateExampleService {

    private final RestTemplate restTemplateJdk;
    private final RestTemplate restTemplateSimple;
    private final RestTemplate restTemplateApache;
    private final RestTemplate restTemplateJetty;
    private final RestTemplate restTemplateNetty;

    private static final String BASE_URL = "https://jsonplaceholder.typicode.com";

    public RestTemplateExampleService(
            @Qualifier("restTemplateWithJdkHttpClient") RestTemplate restTemplateJdk,
            @Qualifier("restTemplateWithSimpleHttpClient") RestTemplate restTemplateSimple,
            @Qualifier("restTemplateWithApacheHttpClient5") RestTemplate restTemplateApache,
            @Qualifier("restTemplateWithJettyHttpClient") RestTemplate restTemplateJetty,
            @Qualifier("restTemplateWithNettyHttpClient") RestTemplate restTemplateNetty) {
        this.restTemplateJdk = restTemplateJdk;
        this.restTemplateSimple = restTemplateSimple;
        this.restTemplateApache = restTemplateApache;
        this.restTemplateJetty = restTemplateJetty;
        this.restTemplateNetty = restTemplateNetty;
    }

    public JsonPlaceholderPost getPostWithJdkHttpClient(Long id) {
        return restTemplateJdk.getForObject(
                BASE_URL + "/posts/{id}", JsonPlaceholderPost.class, id);
    }

    public JsonPlaceholderPost getPostWithSimpleHttpClient(Long id) {
        return restTemplateSimple.getForObject(
                BASE_URL + "/posts/{id}", JsonPlaceholderPost.class, id);
    }

    public JsonPlaceholderPost getPostWithApacheHttpClient(Long id) {
        return restTemplateApache.getForObject(
                BASE_URL + "/posts/{id}", JsonPlaceholderPost.class, id);
    }

    public JsonPlaceholderPost getPostWithJettyHttpClient(Long id) {
        return restTemplateJetty.getForObject(
                BASE_URL + "/posts/{id}", JsonPlaceholderPost.class, id);
    }

    public List<JsonPlaceholderPost> getAllPostsWithJdkHttpClient() {
        return restTemplateJdk
                .exchange(
                        BASE_URL + "/posts",
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {})
                .getBody();
    }

    public List<JsonPlaceholderPost> getAllPostsWithSimpleHttpClient() {
        return restTemplateSimple
                .exchange(
                        BASE_URL + "/posts",
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {})
                .getBody();
    }

    public List<JsonPlaceholderPost> getAllPostsWithApacheHttpClient() {
        return restTemplateApache
                .exchange(
                        BASE_URL + "/posts",
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {})
                .getBody();
    }

    public List<JsonPlaceholderPost> getAllPostsWithJettyHttpClient() {
        return restTemplateJetty
                .exchange(
                        BASE_URL + "/posts",
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {})
                .getBody();
    }

    public JsonPlaceholderPost createPostWithJdkHttpClient(JsonPlaceholderPost post) {
        return restTemplateJdk.postForObject(BASE_URL + "/posts", post, JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost createPostWithSimpleHttpClient(JsonPlaceholderPost post) {
        return restTemplateSimple.postForObject(
                BASE_URL + "/posts", post, JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost createPostWithApacheHttpClient(JsonPlaceholderPost post) {
        return restTemplateApache.postForObject(
                BASE_URL + "/posts", post, JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost createPostWithJettyHttpClient(JsonPlaceholderPost post) {
        return restTemplateJetty.postForObject(
                BASE_URL + "/posts", post, JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost getPostWithNettyHttpClient(Long id) {
        return restTemplateNetty.getForObject(
                BASE_URL + "/posts/{id}", JsonPlaceholderPost.class, id);
    }

    public List<JsonPlaceholderPost> getAllPostsWithNettyHttpClient() {
        return restTemplateNetty
                .exchange(
                        BASE_URL + "/posts",
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {})
                .getBody();
    }

    public JsonPlaceholderPost createPostWithNettyHttpClient(JsonPlaceholderPost post) {
        return restTemplateNetty.postForObject(
                BASE_URL + "/posts", post, JsonPlaceholderPost.class);
    }
}
