package com.example.httpclient.controller;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;
import com.example.httpclient.service.HttpInterfaceExampleService;

import org.springframework.web.bind.annotation.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/httpinterface")
public class HttpInterfaceController {

    private final HttpInterfaceExampleService httpInterfaceService;

    public HttpInterfaceController(HttpInterfaceExampleService httpInterfaceService) {
        this.httpInterfaceService = httpInterfaceService;
    }

    @GetMapping("/restclient/jdk/{id}")
    public JsonPlaceholderPost getPostWithRestClientJdk(@PathVariable Long id) {
        return httpInterfaceService.getPostWithRestClientJdk(id);
    }

    @GetMapping("/restclient/simple/{id}")
    public JsonPlaceholderPost getPostWithRestClientSimple(@PathVariable Long id) {
        return httpInterfaceService.getPostWithRestClientSimple(id);
    }

    @GetMapping("/restclient/apache/{id}")
    public JsonPlaceholderPost getPostWithRestClientApache(@PathVariable Long id) {
        return httpInterfaceService.getPostWithRestClientApache(id);
    }

    @GetMapping("/restclient/jetty/{id}")
    public JsonPlaceholderPost getPostWithRestClientJetty(@PathVariable Long id) {
        return httpInterfaceService.getPostWithRestClientJetty(id);
    }

    @GetMapping("/restclient/jdk")
    public List<JsonPlaceholderPost> getAllPostsWithRestClientJdk() {
        return httpInterfaceService.getAllPostsWithRestClientJdk();
    }

    @GetMapping("/restclient/simple")
    public List<JsonPlaceholderPost> getAllPostsWithRestClientSimple() {
        return httpInterfaceService.getAllPostsWithRestClientSimple();
    }

    @GetMapping("/restclient/apache")
    public List<JsonPlaceholderPost> getAllPostsWithRestClientApache() {
        return httpInterfaceService.getAllPostsWithRestClientApache();
    }

    @GetMapping("/restclient/jetty")
    public List<JsonPlaceholderPost> getAllPostsWithRestClientJetty() {
        return httpInterfaceService.getAllPostsWithRestClientJetty();
    }

    @GetMapping("/webclient/netty/{id}")
    public Mono<JsonPlaceholderPost> getPostReactiveWithWebClientNetty(@PathVariable Long id) {
        return httpInterfaceService.getPostReactiveWithWebClientNetty(id);
    }

    @GetMapping("/webclient/jetty/{id}")
    public Mono<JsonPlaceholderPost> getPostReactiveWithWebClientJetty(@PathVariable Long id) {
        return httpInterfaceService.getPostReactiveWithWebClientJetty(id);
    }

    @GetMapping("/webclient/netty")
    public Flux<JsonPlaceholderPost> getAllPostsReactiveWithWebClientNetty() {
        return httpInterfaceService.getAllPostsReactiveWithWebClientNetty();
    }

    @GetMapping("/webclient/jetty")
    public Flux<JsonPlaceholderPost> getAllPostsReactiveWithWebClientJetty() {
        return httpInterfaceService.getAllPostsReactiveWithWebClientJetty();
    }

    @PostMapping("/restclient/jdk")
    public JsonPlaceholderPost createPostWithRestClientJdk(@RequestBody JsonPlaceholderPost post) {
        return httpInterfaceService.createPostWithRestClientJdk(post);
    }

    @PostMapping("/restclient/simple")
    public JsonPlaceholderPost createPostWithRestClientSimple(
            @RequestBody JsonPlaceholderPost post) {
        return httpInterfaceService.createPostWithRestClientSimple(post);
    }

    @PostMapping("/restclient/apache")
    public JsonPlaceholderPost createPostWithRestClientApache(
            @RequestBody JsonPlaceholderPost post) {
        return httpInterfaceService.createPostWithRestClientApache(post);
    }

    @PostMapping("/restclient/jetty")
    public JsonPlaceholderPost createPostWithRestClientJetty(
            @RequestBody JsonPlaceholderPost post) {
        return httpInterfaceService.createPostWithRestClientJetty(post);
    }

    @PostMapping("/webclient/netty")
    public Mono<JsonPlaceholderPost> createPostReactiveWithWebClientNetty(
            @RequestBody JsonPlaceholderPost post) {
        return httpInterfaceService.createPostReactiveWithWebClientNetty(post);
    }

    @PostMapping("/webclient/jetty")
    public Mono<JsonPlaceholderPost> createPostReactiveWithWebClientJetty(
            @RequestBody JsonPlaceholderPost post) {
        return httpInterfaceService.createPostReactiveWithWebClientJetty(post);
    }

    @GetMapping("/restclient/netty/{id}")
    public JsonPlaceholderPost getPostWithRestClientNetty(@PathVariable Long id) {
        return httpInterfaceService.getPostWithRestClientNetty(id);
    }

    @GetMapping("/restclient/netty")
    public List<JsonPlaceholderPost> getAllPostsWithRestClientNetty() {
        return httpInterfaceService.getAllPostsWithRestClientNetty();
    }

    @PostMapping("/restclient/netty")
    public JsonPlaceholderPost createPostWithRestClientNetty(
            @RequestBody JsonPlaceholderPost post) {
        return httpInterfaceService.createPostWithRestClientNetty(post);
    }
}
