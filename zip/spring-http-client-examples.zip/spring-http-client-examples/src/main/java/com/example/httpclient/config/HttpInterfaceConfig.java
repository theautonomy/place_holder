package com.example.httpclient.config;

import java.time.Duration;

import com.example.httpclient.service.JsonPlaceholderHttpInterface;

import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.io.HttpClientConnectionManager;
import org.eclipse.jetty.client.HttpClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.http.client.JettyClientHttpRequestFactory;
import org.springframework.http.client.ReactorClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.client.reactive.JettyClientHttpConnector;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.support.RestClientAdapter;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.support.WebClientAdapter;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;

import io.netty.channel.ChannelOption;

@Configuration
public class HttpInterfaceConfig {

    @Bean("httpInterfaceWithRestClientJdk")
    public JsonPlaceholderHttpInterface httpInterfaceWithRestClientJdk() {
        RestClient restClient =
                RestClient.builder().requestFactory(new JdkClientHttpRequestFactory()).build();

        RestClientAdapter adapter = RestClientAdapter.create(restClient);
        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(adapter).build();

        return factory.createClient(JsonPlaceholderHttpInterface.class);
    }

    @Bean("httpInterfaceWithRestClientSimple")
    public JsonPlaceholderHttpInterface httpInterfaceWithRestClientSimple() {
        RestClient restClient =
                RestClient.builder().requestFactory(new SimpleClientHttpRequestFactory()).build();

        RestClientAdapter adapter = RestClientAdapter.create(restClient);
        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(adapter).build();

        return factory.createClient(JsonPlaceholderHttpInterface.class);
    }

    @Bean("httpInterfaceWithRestClientApache")
    public JsonPlaceholderHttpInterface httpInterfaceWithRestClientApache() {
        HttpClientConnectionManager connectionManager =
                PoolingHttpClientConnectionManagerBuilder.create()
                        .setMaxConnTotal(100)
                        .setMaxConnPerRoute(20)
                        .build();

        CloseableHttpClient httpClient =
                HttpClients.custom().setConnectionManager(connectionManager).build();

        RestClient restClient =
                RestClient.builder()
                        .requestFactory(new HttpComponentsClientHttpRequestFactory(httpClient))
                        .build();

        RestClientAdapter adapter = RestClientAdapter.create(restClient);
        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(adapter).build();

        return factory.createClient(JsonPlaceholderHttpInterface.class);
    }

    @Bean("httpInterfaceWithRestClientJetty")
    public JsonPlaceholderHttpInterface httpInterfaceWithRestClientJetty() throws Exception {
        HttpClient jettyHttpClient = new HttpClient();
        jettyHttpClient.setConnectTimeout(10000);
        jettyHttpClient.start();

        RestClient restClient =
                RestClient.builder()
                        .requestFactory(new JettyClientHttpRequestFactory(jettyHttpClient))
                        .build();

        RestClientAdapter adapter = RestClientAdapter.create(restClient);
        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(adapter).build();

        return factory.createClient(JsonPlaceholderHttpInterface.class);
    }

    @Bean("httpInterfaceWithWebClientNetty")
    public JsonPlaceholderHttpInterface httpInterfaceWithWebClientNetty() {
        WebClient webClient = WebClient.builder().build();

        WebClientAdapter adapter = WebClientAdapter.create(webClient);
        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(adapter).build();

        return factory.createClient(JsonPlaceholderHttpInterface.class);
    }

    @Bean("httpInterfaceWithWebClientJetty")
    public JsonPlaceholderHttpInterface httpInterfaceWithWebClientJetty() throws Exception {
        HttpClient jettyHttpClient = new HttpClient();
        jettyHttpClient.start();

        WebClient webClient =
                WebClient.builder()
                        .clientConnector(new JettyClientHttpConnector(jettyHttpClient))
                        .build();

        WebClientAdapter adapter = WebClientAdapter.create(webClient);
        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(adapter).build();

        return factory.createClient(JsonPlaceholderHttpInterface.class);
    }

    @Bean("httpInterfaceWithRestClientNetty")
    public JsonPlaceholderHttpInterface httpInterfaceWithRestClientNetty() {
        reactor.netty.http.client.HttpClient reactorHttpClient =
                reactor.netty.http.client.HttpClient.create()
                        .responseTimeout(Duration.ofSeconds(30))
                        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000);

        RestClient restClient =
                RestClient.builder()
                        .requestFactory(new ReactorClientHttpRequestFactory(reactorHttpClient))
                        .build();

        RestClientAdapter adapter = RestClientAdapter.create(restClient);
        HttpServiceProxyFactory factory = HttpServiceProxyFactory.builderFor(adapter).build();

        return factory.createClient(JsonPlaceholderHttpInterface.class);
    }
}
