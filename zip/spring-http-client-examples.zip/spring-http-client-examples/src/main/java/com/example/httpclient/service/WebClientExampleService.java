package com.example.httpclient.service;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class WebClientExampleService {

    private final WebClient webClientNetty;
    private final WebClient webClientJetty;
    private final WebClient webClientJdk;
    private final WebClient webClientApache;

    public WebClientExampleService(
            @Qualifier("webClientWithNetty") WebClient webClientNetty,
            @Qualifier("webClientWithJetty") WebClient webClientJetty,
            @Qualifier("webClientWithJdkHttpClient") WebClient webClientJdk,
            @Qualifier("webClientWithApacheHttpClient") WebClient webClientApache) {
        this.webClientNetty = webClientNetty;
        this.webClientJetty = webClientJetty;
        this.webClientJdk = webClientJdk;
        this.webClientApache = webClientApache;
    }

    public Mono<JsonPlaceholderPost> getPostWithNetty(Long id) {
        return webClientNetty
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Mono<JsonPlaceholderPost> getPostWithJetty(Long id) {
        return webClientJetty
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Flux<JsonPlaceholderPost> getAllPostsWithNetty() {
        return webClientNetty.get().uri("/posts").retrieve().bodyToFlux(JsonPlaceholderPost.class);
    }

    public Flux<JsonPlaceholderPost> getAllPostsWithJetty() {
        return webClientJetty.get().uri("/posts").retrieve().bodyToFlux(JsonPlaceholderPost.class);
    }

    public Mono<List<JsonPlaceholderPost>> getAllPostsAsListWithNetty() {
        return webClientNetty
                .get()
                .uri("/posts")
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {});
    }

    public Mono<List<JsonPlaceholderPost>> getAllPostsAsListWithJetty() {
        return webClientJetty
                .get()
                .uri("/posts")
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {});
    }

    public Mono<JsonPlaceholderPost> createPostWithNetty(JsonPlaceholderPost post) {
        return webClientNetty
                .post()
                .uri("/posts")
                .bodyValue(post)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Mono<JsonPlaceholderPost> createPostWithJetty(JsonPlaceholderPost post) {
        return webClientJetty
                .post()
                .uri("/posts")
                .bodyValue(post)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Mono<Void> deletePostWithNetty(Long id) {
        return webClientNetty.delete().uri("/posts/{id}", id).retrieve().bodyToMono(Void.class);
    }

    public Mono<Void> deletePostWithJetty(Long id) {
        return webClientJetty.delete().uri("/posts/{id}", id).retrieve().bodyToMono(Void.class);
    }

    // JDK HTTP Client methods
    public Mono<JsonPlaceholderPost> getPostWithJdk(Long id) {
        return webClientJdk
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Flux<JsonPlaceholderPost> getAllPostsWithJdk() {
        return webClientJdk.get().uri("/posts").retrieve().bodyToFlux(JsonPlaceholderPost.class);
    }

    public List<JsonPlaceholderPost> getAllPostsAsListWithJdk() {
        return webClientJdk
                .get()
                .uri("/posts")
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {})
                .block();
    }

    public Mono<JsonPlaceholderPost> createPostWithJdk(JsonPlaceholderPost post) {
        return webClientJdk
                .post()
                .uri("/posts")
                .bodyValue(post)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Mono<Void> deletePostWithJdk(Long id) {
        return webClientJdk.delete().uri("/posts/{id}", id).retrieve().bodyToMono(Void.class);
    }

    // Apache HTTP Client methods
    public Mono<JsonPlaceholderPost> getPostWithApache(Long id) {
        return webClientApache
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Flux<JsonPlaceholderPost> getAllPostsWithApache() {
        return webClientApache.get().uri("/posts").retrieve().bodyToFlux(JsonPlaceholderPost.class);
    }

    public List<JsonPlaceholderPost> getAllPostsAsListWithApache() {
        return webClientApache
                .get()
                .uri("/posts")
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {})
                .block();
    }

    public Mono<JsonPlaceholderPost> createPostWithApache(JsonPlaceholderPost post) {
        return webClientApache
                .post()
                .uri("/posts")
                .bodyValue(post)
                .retrieve()
                .bodyToMono(JsonPlaceholderPost.class);
    }

    public Mono<Void> deletePostWithApache(Long id) {
        return webClientApache.delete().uri("/posts/{id}", id).retrieve().bodyToMono(Void.class);
    }
}
