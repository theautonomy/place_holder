package com.example.httpclient.controller;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;
import com.example.httpclient.service.RestTemplateExampleService;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/resttemplate")
public class RestTemplateController {

    private final RestTemplateExampleService restTemplateService;

    public RestTemplateController(RestTemplateExampleService restTemplateService) {
        this.restTemplateService = restTemplateService;
    }

    @GetMapping("/jdk/{id}")
    public JsonPlaceholderPost getPostWithJdk(@PathVariable Long id) {
        return restTemplateService.getPostWithJdkHttpClient(id);
    }

    @GetMapping("/simple/{id}")
    public JsonPlaceholderPost getPostWithSimple(@PathVariable Long id) {
        return restTemplateService.getPostWithSimpleHttpClient(id);
    }

    @GetMapping("/apache/{id}")
    public JsonPlaceholderPost getPostWithApache(@PathVariable Long id) {
        return restTemplateService.getPostWithApacheHttpClient(id);
    }

    @GetMapping("/jetty/{id}")
    public JsonPlaceholderPost getPostWithJetty(@PathVariable Long id) {
        return restTemplateService.getPostWithJettyHttpClient(id);
    }

    @GetMapping("/netty/{id}")
    public JsonPlaceholderPost getPostWithNetty(@PathVariable Long id) {
        return restTemplateService.getPostWithNettyHttpClient(id);
    }

    @GetMapping("/jdk")
    public List<JsonPlaceholderPost> getAllPostsWithJdk() {
        return restTemplateService.getAllPostsWithJdkHttpClient();
    }

    @GetMapping("/apache")
    public List<JsonPlaceholderPost> getAllPostsWithApache() {
        return restTemplateService.getAllPostsWithApacheHttpClient();
    }

    @GetMapping("/simple")
    public List<JsonPlaceholderPost> getAllPostsWithSimple() {
        return restTemplateService.getAllPostsWithSimpleHttpClient();
    }

    @GetMapping("/jetty")
    public List<JsonPlaceholderPost> getAllPostsWithJetty() {
        return restTemplateService.getAllPostsWithJettyHttpClient();
    }

    @GetMapping("/netty")
    public List<JsonPlaceholderPost> getAllPostsWithNetty() {
        return restTemplateService.getAllPostsWithNettyHttpClient();
    }

    @PostMapping("/jdk")
    public JsonPlaceholderPost createPostWithJdk(@RequestBody JsonPlaceholderPost post) {
        return restTemplateService.createPostWithJdkHttpClient(post);
    }

    @PostMapping("/simple")
    public JsonPlaceholderPost createPostWithSimple(@RequestBody JsonPlaceholderPost post) {
        return restTemplateService.createPostWithSimpleHttpClient(post);
    }

    @PostMapping("/apache")
    public JsonPlaceholderPost createPostWithApache(@RequestBody JsonPlaceholderPost post) {
        return restTemplateService.createPostWithApacheHttpClient(post);
    }

    @PostMapping("/jetty")
    public JsonPlaceholderPost createPostWithJetty(@RequestBody JsonPlaceholderPost post) {
        return restTemplateService.createPostWithJettyHttpClient(post);
    }

    @PostMapping("/netty")
    public JsonPlaceholderPost createPostWithNetty(@RequestBody JsonPlaceholderPost post) {
        return restTemplateService.createPostWithNettyHttpClient(post);
    }
}
