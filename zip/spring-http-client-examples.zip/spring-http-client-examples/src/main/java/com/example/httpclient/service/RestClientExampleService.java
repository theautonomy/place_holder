package com.example.httpclient.service;

import java.util.List;

import com.example.httpclient.model.JsonPlaceholderPost;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
public class RestClientExampleService {

    private final RestClient restClientJdk;
    private final RestClient restClientSimple;
    private final RestClient restClientApache;
    private final RestClient restClientJetty;
    private final RestClient restClientNetty;

    public RestClientExampleService(
            @Qualifier("restClientWithJdkHttpClient") RestClient restClientJdk,
            @Qualifier("restClientWithSimpleHttpClient") RestClient restClientSimple,
            @Qualifier("restClientWithApacheHttpClient5") RestClient restClientApache,
            @Qualifier("restClientWithJettyHttpClient") RestClient restClientJetty,
            @Qualifier("restClientWithNettyHttpClient") RestClient restClientNetty) {
        this.restClientJdk = restClientJdk;
        this.restClientSimple = restClientSimple;
        this.restClientApache = restClientApache;
        this.restClientJetty = restClientJetty;
        this.restClientNetty = restClientNetty;
    }

    public JsonPlaceholderPost getPostWithJdkHttpClient(Long id) {
        return restClientJdk
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost getPostWithSimpleHttpClient(Long id) {
        return restClientSimple
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost getPostWithApacheHttpClient(Long id) {
        return restClientApache
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost getPostWithJettyHttpClient(Long id) {
        return restClientJetty
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public List<JsonPlaceholderPost> getAllPostsWithJdkHttpClient() {
        return restClientJdk
                .get()
                .uri("/posts")
                .retrieve()
                .body(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {});
    }

    public List<JsonPlaceholderPost> getAllPostsWithSimpleHttpClient() {
        return restClientSimple
                .get()
                .uri("/posts")
                .retrieve()
                .body(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {});
    }

    public List<JsonPlaceholderPost> getAllPostsWithApacheHttpClient() {
        return restClientApache
                .get()
                .uri("/posts")
                .retrieve()
                .body(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {});
    }

    public List<JsonPlaceholderPost> getAllPostsWithJettyHttpClient() {
        return restClientJetty
                .get()
                .uri("/posts")
                .retrieve()
                .body(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {});
    }

    public JsonPlaceholderPost createPostWithJdkHttpClient(JsonPlaceholderPost post) {
        return restClientJdk
                .post()
                .uri("/posts")
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost createPostWithSimpleHttpClient(JsonPlaceholderPost post) {
        return restClientSimple
                .post()
                .uri("/posts")
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost createPostWithApacheHttpClient(JsonPlaceholderPost post) {
        return restClientApache
                .post()
                .uri("/posts")
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost createPostWithJettyHttpClient(JsonPlaceholderPost post) {
        return restClientJetty
                .post()
                .uri("/posts")
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public ResponseEntity<Void> deletePostWithJdkHttpClient(Long id) {
        return restClientJdk.delete().uri("/posts/{id}", id).retrieve().toBodilessEntity();
    }

    public ResponseEntity<Void> deletePostWithSimpleHttpClient(Long id) {
        return restClientSimple.delete().uri("/posts/{id}", id).retrieve().toBodilessEntity();
    }

    public ResponseEntity<Void> deletePostWithApacheHttpClient(Long id) {
        return restClientApache.delete().uri("/posts/{id}", id).retrieve().toBodilessEntity();
    }

    public ResponseEntity<Void> deletePostWithJettyHttpClient(Long id) {
        return restClientJetty.delete().uri("/posts/{id}", id).retrieve().toBodilessEntity();
    }

    public JsonPlaceholderPost updatePostWithJdkHttpClient(Long id, JsonPlaceholderPost post) {
        return restClientJdk
                .put()
                .uri("/posts/{id}", id)
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost updatePostWithSimpleHttpClient(Long id, JsonPlaceholderPost post) {
        return restClientSimple
                .put()
                .uri("/posts/{id}", id)
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost updatePostWithApacheHttpClient(Long id, JsonPlaceholderPost post) {
        return restClientApache
                .put()
                .uri("/posts/{id}", id)
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost updatePostWithJettyHttpClient(Long id, JsonPlaceholderPost post) {
        return restClientJetty
                .put()
                .uri("/posts/{id}", id)
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public JsonPlaceholderPost getPostWithNettyHttpClient(Long id) {
        return restClientNetty
                .get()
                .uri("/posts/{id}", id)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public List<JsonPlaceholderPost> getAllPostsWithNettyHttpClient() {
        return restClientNetty
                .get()
                .uri("/posts")
                .retrieve()
                .body(new ParameterizedTypeReference<List<JsonPlaceholderPost>>() {});
    }

    public JsonPlaceholderPost createPostWithNettyHttpClient(JsonPlaceholderPost post) {
        return restClientNetty
                .post()
                .uri("/posts")
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }

    public ResponseEntity<Void> deletePostWithNettyHttpClient(Long id) {
        return restClientNetty.delete().uri("/posts/{id}", id).retrieve().toBodilessEntity();
    }

    public JsonPlaceholderPost updatePostWithNettyHttpClient(Long id, JsonPlaceholderPost post) {
        return restClientNetty
                .put()
                .uri("/posts/{id}", id)
                .body(post)
                .retrieve()
                .body(JsonPlaceholderPost.class);
    }
}
