package com.example.httpclient.service;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.example.httpclient.model.JsonPlaceholderPost;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class PerformanceAnalysisService {

    private static final Logger logger = LoggerFactory.getLogger(PerformanceAnalysisService.class);

    private final RestTemplate restTemplateJdk;
    private final RestTemplate restTemplateSimple;
    private final RestTemplate restTemplateApache;
    private final RestTemplate restTemplateJetty;
    private final RestTemplate restTemplateNetty;

    private final WebClient webClientNetty;
    private final WebClient webClientJdk;
    private final WebClient webClientApache;

    public PerformanceAnalysisService(
            @Qualifier("restTemplateWithJdkHttpClient") RestTemplate restTemplateJdk,
            @Qualifier("restTemplateWithSimpleHttpClient") RestTemplate restTemplateSimple,
            @Qualifier("restTemplateWithApacheHttpClient5") RestTemplate restTemplateApache,
            @Qualifier("restTemplateWithJettyHttpClient") RestTemplate restTemplateJetty,
            @Qualifier("restTemplateWithNettyHttpClient") RestTemplate restTemplateNetty,
            @Qualifier("webClientWithNetty") WebClient webClientNetty,
            @Qualifier("webClientWithJdkHttpClient") WebClient webClientJdk,
            @Qualifier("webClientWithApacheHttpClient") WebClient webClientApache) {
        this.restTemplateJdk = restTemplateJdk;
        this.restTemplateSimple = restTemplateSimple;
        this.restTemplateApache = restTemplateApache;
        this.restTemplateJetty = restTemplateJetty;
        this.restTemplateNetty = restTemplateNetty;
        this.webClientNetty = webClientNetty;
        this.webClientJdk = webClientJdk;
        this.webClientApache = webClientApache;
    }

    public Map<String, Long> compareGetPerformance() {
        Map<String, Long> results = new ConcurrentHashMap<>();
        String baseUrl = "https://jsonplaceholder.typicode.com";

        // Test GET requests
        results.put("RestTemplate-JDK-GET", measureRestTemplateGet(restTemplateJdk, baseUrl));
        results.put("RestTemplate-Simple-GET", measureRestTemplateGet(restTemplateSimple, baseUrl));
        results.put("RestTemplate-Apache-GET", measureRestTemplateGet(restTemplateApache, baseUrl));
        results.put("RestTemplate-Jetty-GET", measureRestTemplateGet(restTemplateJetty, baseUrl));
        results.put("RestTemplate-Netty-GET", measureRestTemplateGet(restTemplateNetty, baseUrl));

        results.put("WebClient-Netty-GET", measureWebClientGet(webClientNetty));
        results.put("WebClient-JDK-GET", measureWebClientGet(webClientJdk));
        results.put("WebClient-Apache-GET", measureWebClientGet(webClientApache));

        return results;
    }

    public Map<String, Long> comparePostPerformance() {
        Map<String, Long> results = new ConcurrentHashMap<>();
        String baseUrl = "https://jsonplaceholder.typicode.com";
        JsonPlaceholderPost testPost =
                new JsonPlaceholderPost(1L, "Test Post", "This is a performance test post");

        // Test POST requests
        results.put(
                "RestTemplate-JDK-POST",
                measureRestTemplatePost(restTemplateJdk, baseUrl, testPost));
        results.put(
                "RestTemplate-Simple-POST",
                measureRestTemplatePost(restTemplateSimple, baseUrl, testPost));
        results.put(
                "RestTemplate-Apache-POST",
                measureRestTemplatePost(restTemplateApache, baseUrl, testPost));
        results.put(
                "RestTemplate-Jetty-POST",
                measureRestTemplatePost(restTemplateJetty, baseUrl, testPost));
        results.put(
                "RestTemplate-Netty-POST",
                measureRestTemplatePost(restTemplateNetty, baseUrl, testPost));

        results.put("WebClient-Netty-POST", measureWebClientPost(webClientNetty, testPost));
        results.put("WebClient-JDK-POST", measureWebClientPost(webClientJdk, testPost));
        results.put("WebClient-Apache-POST", measureWebClientPost(webClientApache, testPost));

        return results;
    }

    public String analyzePerformanceBottlenecks() {
        StringBuilder analysis = new StringBuilder();

        analysis.append("=== POST Performance Analysis ===\n\n");

        analysis.append("Common reasons why POST requests are slower than GET:\n\n");

        analysis.append("1. Request Body Serialization:\n");
        analysis.append("   - POST requests need to serialize JSON request body\n");
        analysis.append("   - Jackson serialization adds 1-5ms per request\n");
        analysis.append("   - Solution: Use streaming or pre-serialize large payloads\n\n");

        analysis.append("2. Connection Management:\n");
        analysis.append("   - Many HTTP clients don't reuse connections by default\n");
        analysis.append("   - Each new connection requires TCP handshake (1-3 RTT)\n");
        analysis.append("   - Solution: Enable connection pooling and keep-alive\n\n");

        analysis.append("3. Missing Timeouts:\n");
        analysis.append("   - Default timeouts are often too long (30s-60s)\n");
        analysis.append("   - Client waits for server response unnecessarily long\n");
        analysis.append("   - Solution: Set appropriate connect (5s) and read (30s) timeouts\n\n");

        analysis.append("4. Buffer Configuration:\n");
        analysis.append("   - Some clients buffer entire request/response in memory\n");
        analysis.append("   - Large payloads cause memory pressure and GC pauses\n");
        analysis.append("   - Solution: Use streaming for large payloads\n\n");

        analysis.append("5. HTTP Version:\n");
        analysis.append("   - HTTP/1.1 requires separate connections for parallel requests\n");
        analysis.append("   - HTTP/2 allows multiplexing but needs proper configuration\n");
        analysis.append("   - Solution: Configure clients to use HTTP/2 when available\n\n");

        analysis.append("6. Client-Specific Issues:\n");
        analysis.append("   - SimpleClientHttpRequestFactory: Basic implementation, no pooling\n");
        analysis.append(
                "   - JdkClientHttpRequestFactory: Good performance but needs timeout config\n");
        analysis.append("   - Apache HttpClient: Excellent but needs proper connection manager\n");
        analysis.append("   - Jetty: Fast but needs proper client configuration\n");
        analysis.append(
                "   - Netty: Excellent for high concurrency, needs connection provider\n\n");

        return analysis.toString();
    }

    private long measureRestTemplateGet(RestTemplate restTemplate, String baseUrl) {
        try {
            Instant start = Instant.now();
            restTemplate.getForObject(baseUrl + "/posts/1", JsonPlaceholderPost.class);
            Instant end = Instant.now();
            return Duration.between(start, end).toMillis();
        } catch (Exception e) {
            logger.error("Error measuring RestTemplate GET performance", e);
            return -1;
        }
    }

    private long measureRestTemplatePost(
            RestTemplate restTemplate, String baseUrl, JsonPlaceholderPost post) {
        try {
            Instant start = Instant.now();
            restTemplate.postForObject(baseUrl + "/posts", post, JsonPlaceholderPost.class);
            Instant end = Instant.now();
            return Duration.between(start, end).toMillis();
        } catch (Exception e) {
            logger.error("Error measuring RestTemplate POST performance", e);
            return -1;
        }
    }

    private long measureWebClientGet(WebClient webClient) {
        try {
            Instant start = Instant.now();
            webClient
                    .get()
                    .uri("/posts/1")
                    .retrieve()
                    .bodyToMono(JsonPlaceholderPost.class)
                    .block();
            Instant end = Instant.now();
            return Duration.between(start, end).toMillis();
        } catch (Exception e) {
            logger.error("Error measuring WebClient GET performance", e);
            return -1;
        }
    }

    private long measureWebClientPost(WebClient webClient, JsonPlaceholderPost post) {
        try {
            Instant start = Instant.now();
            webClient
                    .post()
                    .uri("/posts")
                    .bodyValue(post)
                    .retrieve()
                    .bodyToMono(JsonPlaceholderPost.class)
                    .block();
            Instant end = Instant.now();
            return Duration.between(start, end).toMillis();
        } catch (Exception e) {
            logger.error("Error measuring WebClient POST performance", e);
            return -1;
        }
    }
}
