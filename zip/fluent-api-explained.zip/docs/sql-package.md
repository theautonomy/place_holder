# The `sql` Package Explained

The `sql` package (`src/main/java/com/example/fluentapi/sql/`) builds SQL query strings using a **"ping-pong" fluent style**: the main builder hands off to small, single-purpose "clause" objects for compound operations, and each clause object hands control back to the main builder once it's done.

## The four classes

**`SqlBuilder`** — the central builder holding all query state (`selectColumns`, `fromTable`, `joins`, `whereConditions`, `groupByColumns`, `havingConditions`, `orderByColumns`, `limitValue`). Entry point is the static factory `SqlBuilder.select(...)`. Methods like `from()`, `groupBy()`, `limit()` return `this` directly (simple chaining), but `where()`, `having()`, and `orderBy()` instead return a dedicated **clause object**:

```java
public WhereCondition where(String column) {
    return new WhereCondition(this, column, false);
}
```

**`WhereCondition`** — captures a pending column name (and whether it needs an `AND`/`OR` connector), then exposes operator methods (`isEqual`, `greaterThan`, `lessThan`). Calling one of those appends the finished condition back onto the parent `SqlBuilder` via a package-private callback (`addWhereCondition`) and **returns the `SqlBuilder`**, not itself — so the chain continues from there.

**`HavingCondition`** and **`OrderByClause`** follow the identical shape: they hold the column name in a small immutable holder, expose the handful of valid follow-up methods (`greaterThan` / `ascending()`, `descending()`), then call back into `SqlBuilder` and return it.

**`build()`** just concatenates the accumulated pieces into a SQL string in clause order (`SELECT ... FROM ... JOIN ... WHERE ... GROUP BY ... HAVING ... ORDER BY ... LIMIT`).

```mermaid
classDiagram
    class SqlBuilder {
        +where(column) WhereCondition
        +having(column) HavingCondition
        +orderBy(column) OrderByClause
        +build() String
        ~addWhereCondition(clause)
        ~addHavingCondition(clause)
        ~addOrderBy(clause)
    }
    class WhereCondition {
        +greaterThan(value) SqlBuilder
        +isEqual(value) SqlBuilder
    }
    class HavingCondition {
        +greaterThan(value) SqlBuilder
    }
    class OrderByClause {
        +ascending() SqlBuilder
        +descending() SqlBuilder
    }

    SqlBuilder ..> WhereCondition : where()/and()/or() create
    SqlBuilder ..> HavingCondition : having() creates
    SqlBuilder ..> OrderByClause : orderBy() creates
    WhereCondition --> SqlBuilder : operator method returns
    HavingCondition --> SqlBuilder : operator method returns
    OrderByClause --> SqlBuilder : ascending()/descending() return
```

Every clause object's operator method returns `SqlBuilder`, not itself — that's the whole trick drawn as a diagram: the arrows out of `SqlBuilder` create a clause object, and every arrow back in from a clause object lands on `SqlBuilder` again, never on another clause object.

## Why the ping-pong matters

This is the pattern's teaching point: `where("age").greaterThan(18)` is two method calls on **two different objects** (`SqlBuilder` → `WhereCondition` → back to `SqlBuilder`), but it *reads* as one continuous sentence. It lets the API force a grammar — you can't call `.greaterThan()` without first naming a column via `.where()`/`.and()`/`.or()`, because `greaterThan` only exists on `WhereCondition`, not on `SqlBuilder`.

## Walking the demo query

From `FluentApiDemo.demonstrateSqlBuilder()`:

```java
SqlBuilder.select("name", "email", "age")   // SqlBuilder
    .from("users")                          // SqlBuilder
    .where("age")                           // -> WhereCondition("age", useConnector=false)
    .greaterThan(18)                        // appends "age > 18", back to SqlBuilder
    .and("status")                          // -> WhereCondition("status", useConnector=true)
    .isEqual("active")                      // appends "AND status = 'active'"
    .orderBy("name")                        // -> OrderByClause("name")
    .ascending()                            // appends "name ASC", back to SqlBuilder
    .limit(10)                              // SqlBuilder
    .build();                               // -> String
```

produces:

```sql
SELECT name, email, age FROM users WHERE age > 18 AND status = 'active' ORDER BY name ASC LIMIT 10
```

```mermaid
sequenceDiagram
    participant Caller
    participant Builder as SqlBuilder
    participant Where as WhereCondition

    Caller->>Builder: where("age")
    Builder-->>Caller: new WhereCondition(this, "age")

    Caller->>Where: greaterThan(18)
    Where->>Builder: addWhereCondition("age > 18")
    Where-->>Caller: return parent (SqlBuilder)

    Caller->>Builder: and("status")
    Builder-->>Caller: new WhereCondition(this, "status", useConnector=true)

    Caller->>Where: isEqual("active")
    Where->>Builder: addWhereCondition("AND status = 'active'")
    Where-->>Caller: return parent (SqlBuilder)
```

Each rung of the ladder is two hops: out to a fresh clause object, then straight back to the same `SqlBuilder` — never object-to-object, and never accumulating a chain of clause objects.

The join example additionally shows `.innerJoin("orders o").on("u.id = o.user_id")` — `on()` mutates the *last* entry in the `joins` list rather than adding a new one, which is how it attaches the condition to the join clause it immediately follows.

## Caveat

Note this is a teaching example, not production-safe SQL building: `WhereCondition.formatValue()` inlines values as string literals rather than using bind parameters, so it's vulnerable to SQL injection if ever fed untrusted input. Worth keeping in mind if this code is ever adapted beyond the demo.
