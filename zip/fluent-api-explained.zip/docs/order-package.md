# The order Package Explained

The `order` package (`src/main/java/com/example/fluentapi/order/`) is the project's flagship example of a "staged fluent builder" — an attempt to use interfaces to enforce a valid call order at compile time, inspired by jOOQ's crash-course pattern.

## The pieces

**`OrderApi`** — entry point:
```java
public static CustomerStep startOrder() {
    return new OrderBuilder();
}
```
It returns the narrow `CustomerStep` interface, not the full builder, so the *only* thing you can call first is `withCustomer(...)`.

**`CustomerStep`** — a one-method interface: `withCustomer(String) -> OrderSteps`. This is the actual "staged" part of the state machine.

**`OrderSteps`** — a much wider interface with everything else: `addItem`, `addDrink`, `withPrice`, `setDelivery`/`setPickup`, `withAddress`, `withDeliveryTime`/`withPickupTime`, `applyDiscount`, and the terminal `complete()`. Every method (except `complete()`) returns `OrderSteps` again.

**`OrderBuilder`** — the single concrete class implementing both interfaces. It holds all the order state and accumulates it as methods are called, staging one "current" item (`currentItemName`/`currentQuantity`) between `addItem`/`addDrink` and `withPrice`.

**`Order`** / **`OrderItem`** — plain Java records (immutable value objects) representing the finished result. `Order`'s compact constructor defensively copies the items list; `toString()` renders a receipt-style summary with computed totals.

## The chain

```java
Order order = OrderApi.startOrder()               // CustomerStep
    .withCustomer("John Doe")                      // -> OrderSteps
    .addItem("Burger", 2)                           // OrderSteps (stages currentItemName="Burger", currentQuantity=2)
    .withPrice(BigDecimal.valueOf(12.99))            // OrderSteps (flushes into items list)
    .addItem("Fries", 1)                            // OrderSteps
    .withPrice(BigDecimal.valueOf(4.99))             // OrderSteps
    .addDrink("Cola", DrinkSize.LARGE)               // OrderSteps
    .withPrice(BigDecimal.valueOf(2.99))             // OrderSteps
    .applyDiscount(BigDecimal.valueOf(2.00))         // OrderSteps
    .setDelivery()                                   // OrderSteps (no-op flag, see caveats below)
    .withAddress("123 Main St")                      // OrderSteps
    .withDeliveryTime(LocalDateTime.now().plusHours(1)) // OrderSteps
    .complete();                                     // -> Order
```

`addItem`/`addDrink` don't immediately create an `OrderItem` — they just remember the pending name/quantity as builder fields. `withPrice()` is what actually constructs the `OrderItem` and appends it to the list. That's why the pairing always reads `addItem(...).withPrice(...)`.

## Where the state machine is weaker than it looks

```mermaid
stateDiagram-v2
    [*] --> CustomerStep: startOrder()
    CustomerStep --> OrderSteps: withCustomer(name)
    OrderSteps --> OrderSteps: addItem() / addDrink() / withPrice()\nwithAddress() / withDeliveryTime()\nsetDelivery() / setPickup() / applyDiscount()
    OrderSteps --> [*]: complete()

    note right of CustomerStep
        Only withCustomer() is callable here.
        Real compile-time enforcement.
    end note
    note right of OrderSteps
        Everything else lives in this one state,
        callable any number of times, in any order,
        including zero times before complete().
    end note
```

This is the actual shape: two states, not a multi-step machine. `complete()` is reachable directly from `OrderSteps` with zero intervening calls — there's no "must have at least one item" state, no "must set delivery before delivery time" state. For contrast, here's what genuine per-stage enforcement would require (**not** implemented anywhere in this repo — a hypothetical, for comparison only):

```mermaid
stateDiagram-v2
    [*] --> CustomerStage: startOrder()
    CustomerStage --> ItemStage: withCustomer(name)
    ItemStage --> PendingPriceStage: addItem()/addDrink()
    PendingPriceStage --> ItemStage: withPrice()
    ItemStage --> DeliveryStage: setDelivery()/setPickup()
    DeliveryStage --> CompletableStage: withAddress()/withDeliveryTime()
    CompletableStage --> [*]: complete()
```

Each arrow above would need its *own* narrow interface (the way `CustomerStep` narrows the very first call) — a different return type per stage, each exposing only the methods legal from that stage. `OrderBuilder` only ever does this once, at the very start.

Worth being honest about this, since it's the project's teaching centerpiece:

- **Only the first step is actually enforced.** `startOrder()` returning `CustomerStep` means you *must* call `withCustomer()` first — that's real compile-time safety. But every method after that lives on the single flat `OrderSteps` interface and returns `OrderSteps` again, so there's no compiler-level ordering after that point. You can legally write `OrderApi.startOrder().withCustomer("Jane").complete()` — an order with no items — or call `withPrice()` before ever calling `addItem()` (using stale/default `currentItemName`/`currentQuantity` fields), or call `withDeliveryTime()` without ever calling `setDelivery()`.
- **`setDelivery()`/`setPickup()` are no-ops.** They just `return this` — they don't set any flag. Whether an order prints as "delivery" or "pickup" in `Order.toString()` is inferred purely from whether `deliveryAddress`/`pickupTime` got set, not from which of `setDelivery()`/`setPickup()` was called.

So this package is best understood as showing the *idea* of a staged fluent interface (narrow the interface at the entry point to force a first call), while illustrating — deliberately or not — that fully enforcing a multi-step state machine this way requires a *different* interface per stage (like `CustomerStep` was for the first step), not one big shared `OrderSteps` interface. Contrast this with the `assertion` package, which does properly narrow the interface at every step.
