# Notes: Poutsma's "Crafting Fluent APIs" Series

Reading notes on a four-part blog series by Arjen Poutsma (poutsma-principles.com, May–June 2025) on designing fluent Java APIs. Worth keeping alongside this repo's docs because Poutsma is the `@author` credited on Spring Framework's actual `RestClient`/`DefaultRestClient` — the same source this repo's `restclient` package was built from. The series is effectively his own explanation of the design philosophy behind the exact technique `restclient` and `cache` reverse-engineer from the source code.

## 1. [Designing for Ctrl + Space](https://poutsma-principles.com/blog/2025/05/15/designing-for-short-completion-menus/) (May 15, 2025)

Central claim: for most developers, the real "surface" of an API is whatever their IDE's autocomplete popup shows, not the Javadoc. A flat API with many overloaded methods (his example: `RestTemplate`) produces a long, undifferentiated completion menu at every step. A staged API narrows the return type after each call, so the menu only ever shows the handful of methods that make sense *right now*. He frames this as reducing cognitive load through guided navigation rather than raw expressiveness.

**Already represented here:** this is the whole premise behind splitting `restclient`'s spec interfaces (`UriSpec`, `RequestHeadersSpec`, `RequestBodySpec`, ...) instead of one flat interface — see `docs/restclient-package.md`'s "Option A / Option B" comparison, which independently arrives at the same conclusion.

## 2. [Fluent APIs Are More Than Just Chaining](https://poutsma-principles.com/blog/2025/05/20/method-chaining/) (May 20, 2025)

Argues that chaining by itself (every method just `return this`) doesn't prevent misuse — it only makes misuse read nicely, e.g. calling a body-setting method on a GET request. His fix is **narrowing or changing the return type at each step** so the invalid call isn't just discouraged, it doesn't compile. His concrete example is Spring's `RequestEntity`, where GET-style requests get back a `HeadersBuilder` and POST-style requests get back a `BodyBuilder` that extends it.

**Already represented here:** this is `restclient-package.md`'s central thesis almost verbatim — `RequestHeadersUriSpec` (no body) vs. `RequestBodyUriSpec` (adds body) is the same `HeadersBuilder`/`BodyBuilder` shape under different names. `cache-package.md` reapplies the identical idea (`KeyOperationSpec` vs. `ValueOperationSpec`) to a different domain.

## 3. [Responding to Real World Usage](https://poutsma-principles.com/blog/2025/05/28/responding-to-real-world-usage/) (May 28, 2025)

A design-process argument rather than a code pattern: API design should be corrected by watching how developers actually use a pre-release API, not just by theorizing about correct usage upfront. His case study is `WebClient`'s original required `uri(...)` argument — at a conference demo, developers were seen passing an empty string just to satisfy the type system, which was the signal to make the URI argument optional before release. He frames the window for this kind of correction as narrow — an API's ergonomics mostly freeze once it ships.

**Not represented here.** Every package in this repo is a finished snapshot demonstrating a settled technique; none of them show the *iteration* that produced that settlement. There isn't really a "code pattern" to extract from this one — it's a process lesson (watch real usage before the release window closes), which doesn't map cleanly onto a `demonstrateX()` method the way the other three posts do.

## 4. [Fluent Internals](https://poutsma-principles.com/blog/2025/06/03/fluent-internals/) (June 3, 2025)

The internals piece, naming the two techniques directly:
- **Self-referencing (F-bounded) generics** — his example is literally `RequestHeadersUriSpec<S extends RequestHeadersSpec<S>>` — so a method declared once returns whichever concrete subtype the caller is actually holding, not a generic supertype.
- **Interface composition** — splitting URI/headers/body into separate small interfaces that get recombined differently per verb, rather than one interface with every method or several interfaces duplicating shared methods.

His framing: all of this generic/interface machinery exists solely so it can stay invisible — the only thing a caller should ever notice is a short, correct autocomplete list at each step.

**Already represented here:** this is the entire subject of `restclient-package.md`'s "Why this shape matters" section and `cache-package.md`'s "Design rationale" section (including the empirically-verified subtlety that `ValueSpec` must extend `OperationSpec<ValueSpec>`, and that `.key(...)` must be called before `.region(...)` because of how wildcard capture resolves against a self-bounded type parameter).

## Summary

Posts 1, 2, and 4 describe, from the original author's perspective, exactly the technique this repo's `restclient` and `cache` packages were built to teach — narrowed/composed return types driven by self-bounded generics, all in service of a short autocomplete menu. Post 3 is the odd one out: a real-usage-driven iteration process, not yet mirrored by any package here.
