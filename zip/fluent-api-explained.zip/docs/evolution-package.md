# The `evolution` Package Explained

Every other package in this repo teaches a *structural* technique — a shape you could apply once and settle on. The `evolution` package (`src/main/java/com/example/fluentapi/evolution/`) is different: it's not a technique at all, it's a **process** — Arjen Poutsma's ["Responding to Real World Usage"](https://poutsma-principles.com/blog/2025/05/28/responding-to-real-world-usage/) post argues that good fluent API design comes from watching how developers actually use a pre-release API, not from getting the design "right" on paper up front. This package models that arc directly: a v1 API, evidence that v1 has friction, and a v2 API that responds to it.

## The two classes

**`SimpleClientV1`** — `create(baseUrl)` then `uri(path)` returning a `Request`, whose `retrieve()` is the only way to get a result. `uri(...)` is **required** — there's no way to get a `Request` (and therefore no way to call `retrieve()`) without it, even if the base URL alone is already everything you want to request.

**`SimpleClientV2`** — identical `uri(path)` method, but with one addition: `retrieve()` is now also a method directly on the client itself, implemented as `uri("").retrieve()` internally. The fix isn't a new concept — it's recognizing that the base URL alone is a legitimate, complete request, and giving it a direct path instead of forcing a call through `uri(...)` to get there.

Both are deliberately minimal — no headers, no body, no HTTP verbs — because the point isn't a rich client, it's the single ergonomic gap between the two versions.

## Walking the demo

From `FluentApiDemo.demonstrateApiEvolution()`, in four steps:

```java
// Step 1: what got observed in the wild against v1 (conference demos, GitHub scans, ...)
List<String> observedV1Usage = List.of(
        "client.uri(\"/users/1\").retrieve()",
        "client.uri(\"/orders\").retrieve()",
        "client.uri(\"\").retrieve()",
        "client.uri(\"\").retrieve()");

long awkwardCount = observedV1Usage.stream().filter(snippet -> snippet.contains("uri(\"\")")).count();
// -> 2 of 4 recorded call sites are the workaround
```

This is a deliberately simple stand-in for the actual observation step Poutsma describes (watching a conference demo, scanning GitHub) — a small list of recorded call-site strings, filtered for the telltale `uri("")` pattern. It's the "evidence" half of the arc: half the recorded usage is a workaround, which is the signal a real API team would act on.

```java
// Step 2: v1 requires uri(...) even when there's nothing to add to the base URL
String v1Result = SimpleClientV1.create("https://api.example.com").uri("").retrieve();

// Step 3: v2 responds to that friction by making uri(...) optional
String v2Result = SimpleClientV2.create("https://api.example.com").retrieve();

// Step 4: same behavior, workaround eliminated
v1Result.equals(v2Result); // -> true
```

Both client versions are exercised for real — the demo doesn't just describe the workaround, it writes `.uri("")` against `SimpleClientV1` exactly the way an affected developer would have, then shows `SimpleClientV2` reaching the identical result without it.

## Why this one doesn't fit the "structural technique" mold

Every other doc in this repo answers some version of "what's the trick, and how does the type system enforce it?" This package has no type-system trick — `v2.retrieve()` is a one-line method that just calls `uri("")` internally. The teaching point is upstream of the code: **you don't arrive at that one-liner by reasoning about generics or interfaces, you arrive at it by noticing that developers keep writing the same awkward workaround.** The `observedV1Usage` list is the part of this package that doesn't exist in any other package here — a (deliberately toy) stand-in for the real feedback loop Poutsma describes, without which "make `uri()` optional" would just be a guess instead of a response to evidence.

## Caveats

- `observedV1Usage` is a hardcoded list of four strings, not real telemetry, a real GitHub scan, or a real conference demo — it exists purely to make the "we noticed a pattern" step something the demo can actually run and count, rather than just asserting it in prose.
- Unlike `restclient`/`cache`, there's no compile-time enforcement angle here at all — `SimpleClientV1.uri("")` compiles just as easily as `SimpleClientV1.uri("/users/1")`. The friction being solved is ergonomic (an unnecessary, meaningless call you're forced to write), not a category of misuse the type system could have prevented.
