# The `retry` Package Explained

The `retry` package (`src/main/java/com/example/fluentapi/retry/`) is different from every other package in this repo in one specific way: it isn't a simplified stand-in for something else. `http`, `email`, `sql`, `config`, `client`, and `restclient` all fake their backend (no real network, no real database, no real SQL) so the demo can run deterministically offline. `retry` has no backend to fake — `RetryPolicy.execute(...)` really sleeps (`Thread.sleep`), really catches real exceptions, and really computes exponential backoff. It's an original design, not modeled on a specific library, built to be a genuinely useful building block on its own.

## The three classes

**`RetryAttempt`** — a small record (`attemptNumber`, `maxAttempts`, `nextDelay`, `failure`) describing one failed-and-about-to-retry attempt. It's the payload handed to the `onRetry` callback.

**`RetryPolicyBuilder`** — the classic single-class builder shape already used by `http`/`email` in this repo: `RetryPolicyBuilder.create()` is the entry point, every setter (`maxAttempts`, `initialDelay`, `backoffMultiplier`, `maxDelay`, `retryOn`, `onRetry`) returns `this`, and `build()` freezes everything into an immutable `RetryPolicy` record. `maxAttempts(...)` fails fast on an invalid value (`< 1`), the same "validate early" habit `EmailBuilder.build()` demonstrates elsewhere in this repo.

**`RetryPolicy`** — the record `build()` produces, and also where the actual behavior lives:

```java
public <T> T execute(Callable<T> action) throws Exception {
    Duration delay = initialDelay;
    for (int attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
            return action.call();
        } catch (Exception failure) {
            if (!isRetryable(failure) || attempt == maxAttempts) {
                throw failure;
            }
            onRetry.accept(new RetryAttempt(attempt, maxAttempts, delay, failure));
            sleep(delay);
            delay = nextDelay(delay);
        }
    }
    ...
}
```

Three things make this "real" rather than simulated:
- It genuinely retries the exact `Callable<T>` passed in — no indirection through a fake store.
- `sleep(delay)` genuinely blocks the thread between attempts using `Thread.sleep`, with `delay` genuinely growing each time via `nextDelay()` (multiplied by `backoffMultiplier`, capped at `maxDelay`).
- `retryOn(...)` genuinely inspects the *runtime type* of each thrown exception (`type.isInstance(failure)`) to decide whether to retry at all — an exception type not listed propagates on the very first attempt.

Compact-constructor validation on the record (`retryableExceptions = List.copyOf(retryableExceptions)`, defaulting a `null` `onRetry` to a no-op) mirrors the repo's convention that terminal record types freeze and validate their own invariants, independent of whatever built them.

```mermaid
flowchart TD
    Start(["execute(action)<br/>delay = initialDelay"]) --> Call["action.call()"]
    Call -->|success| Return(["return result"])
    Call -->|throws failure| Check{"retryable AND<br/>attempt < maxAttempts?"}
    Check -->|no| Throw(["throw failure"])
    Check -->|yes| Notify["onRetry.accept(RetryAttempt)"]
    Notify --> Sleep["Thread.sleep(delay)"]
    Sleep --> Backoff["delay = min(delay * backoffMultiplier, maxDelay)"]
    Backoff --> Increment["attempt++"] --> Call
```

Every box on this diagram is a real, observable side effect when the demo runs — `Thread.sleep(delay)` really blocks, `delay = min(...)` really produces the `10ms -> 20ms` progression printed by the demo, and the `Check` diamond is a genuine runtime decision (`retryOn(...)` type check, attempt counter), not a fixed script.

## Why this shape matters

Every other package in this repo teaches a *structural* trick for chaining method calls — ping-pong handoff, terminal fan-out, F-bounded generics, staged interfaces. `retry` intentionally uses the plainest possible shape (`http`/`email`'s classic mutable builder) because the interesting part here isn't the chaining mechanics, it's that the object the chain produces does real, observable work: three different runs of the demo produce three genuinely different, timing-dependent outcomes, not three canned responses from an in-memory table.

## Walking the demo

From `FluentApiDemo.demonstrateRetryPolicy()`, three scenarios exercise the policy against a real flaky operation:

```java
RetryPolicy flaky = RetryPolicyBuilder.create()          // -> RetryPolicyBuilder
        .maxAttempts(5)                                   // RetryPolicyBuilder
        .initialDelay(Duration.ofMillis(10))               // RetryPolicyBuilder
        .backoffMultiplier(2.0)                            // RetryPolicyBuilder
        .retryOn(IOException.class)                        // RetryPolicyBuilder
        .onRetry(attempt -> System.out.println("  attempt " + attempt.attemptNumber() + "/"
                + attempt.maxAttempts() + " failed (" + attempt.failure().getMessage()
                + "), retrying after " + attempt.nextDelay().toMillis() + "ms"))  // RetryPolicyBuilder
        .build();                                          // -> RetryPolicy

String result = flaky.execute(() -> {                     // -> String (the Callable<T>'s T)
    if (attempts.incrementAndGet() <= 2) {
        throw new IOException("connection reset (attempt " + attempts.get() + ")");
    }
    return "connected on attempt " + attempts.get();
});
```

This fails twice (`10ms` then `20ms` delay — backoff doubling in action) before succeeding on the third attempt. A second scenario uses an operation that *always* throws, so all 3 configured attempts are consumed and the final failure propagates out of `execute(...)`. A third scenario throws `IllegalStateException` against a policy scoped to `retryOn(IOException.class)` — since the thrown type isn't in the retryable set, it fails on attempt 1 with no retries at all, and the `onRetry` callback never fires.

## Caveats

- `execute(...)` declares `throws Exception` and sleeps the calling thread directly — fine for a teaching example, but a production version would likely want a checked/unchecked exception split and a way to retry without blocking the caller's thread (e.g. a scheduled executor).
- There's no jitter on the backoff delay, so concurrent callers retrying against the same failing dependency would all retry in lockstep ("thundering herd") — real resilience libraries typically randomize delay slightly to avoid this.
