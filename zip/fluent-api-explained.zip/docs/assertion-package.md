# The assertion Package Explained

The `assertion` package (`src/main/java/com/example/fluentapi/assertion/`) is a small fluent-assertion library — a mini version of AssertJ. Its trick is **type narrowing through chaining**: you start generic and cast down into type-specific assertion classes as you go.

## The five classes

**`FluentAssert`** — the sole entry point, a static factory:
```java
public static <T> AssertThat<T> assertThat(T actual) {
    return new AssertThat<>(actual);
}
```

**`AssertThat<T>`** — a generic wrapper around any value. It has two kinds of methods:
- **Terminal checks** that apply to any type and return `this` for further chaining: `isNotNull()`, `isEqualTo(T expected)`.
- **Type-narrowing methods** — `asString()`, `asNumber()`, `asCollection()` — that runtime-check the wrapped value's type and hand off to a specialized assertion object (`StringAssert`, `NumberAssert`, `CollectionAssert`), throwing `IllegalStateException` if the value isn't actually that type.

**`StringAssert`**, **`NumberAssert`**, **`CollectionAssert`** — each wraps a specific type and exposes assertions relevant only to that type (e.g. `contains`/`startsWith`/`hasLength` for strings, `isGreaterThan`/`isBetween` for numbers, `hasSize`/`isEmpty` for collections). Every method either returns `this` (to keep chaining within that specialized class) or throws `AssertionError` on failure.

```mermaid
flowchart LR
    A["AssertThat&lt;T&gt;<br/>.isNotNull() / .isEqualTo()"]
    A -->|".asString()"| S["StringAssert<br/>.contains() .startsWith() .hasLength()"]
    A -->|".asNumber()"| N["NumberAssert<br/>.isGreaterThan() .isLessThan() .isBetween()"]
    A -->|".asCollection()"| C["CollectionAssert<br/>.hasSize() .contains() .isEmpty()"]

    S -.->|"not a String"| X["IllegalStateException"]
    N -.->|"not a Number"| X
    C -.->|"not a Collection"| X
```

`AssertThat<T>` is the single fork point: three methods runtime-check `actual`'s type and hand off to a specialized class exposing only type-appropriate assertions — there's no path back from `StringAssert` to `NumberAssert`, and no method exists to get there even if there were.

## Why this shape matters

This is the same "ping-pong" idea as the `sql` package, but used to enforce **capability narrowing** instead of grammar: once you call `.asNumber()`, the compiler only lets you call number-appropriate methods next — `.asNumber().contains(...)` simply doesn't compile, because `contains` doesn't exist on `NumberAssert`. It demonstrates that fluent APIs can encode "what operations make sense right now" directly in the type system, catching a class of misuse errors at compile time rather than at runtime.

## Walking the demo

From `FluentApiDemo.demonstrateAdvancedFluentApi()`:

```java
FluentAssert.assertThat("Hello World")   // AssertThat<String>
    .isNotNull()                         // AssertThat<String>
    .asString()                          // -> StringAssert
    .contains("World")                   // StringAssert
    .startsWith("Hello")                 // StringAssert
    .hasLength(11);                      // StringAssert

FluentAssert.assertThat(42)              // AssertThat<Integer>
    .isNotNull()                         // AssertThat<Integer>
    .asNumber()                          // -> NumberAssert
    .isGreaterThan(0)                    // NumberAssert
    .isLessThan(100)                     // NumberAssert
    .isBetween(40, 50);                  // NumberAssert

FluentAssert.assertThat(names)           // AssertThat<List<String>>
    .isNotNull()                         // AssertThat<List<String>>
    .asCollection()                      // -> CollectionAssert
    .hasSize(3)                          // CollectionAssert
    .contains("Bob");                    // CollectionAssert
```

Each block reads like a natural-language spec ("assert that Hello World, as a string, contains World..."), and any failed check throws immediately with a descriptive `AssertionError`, which is why the demo wraps the whole thing in a try/catch.
