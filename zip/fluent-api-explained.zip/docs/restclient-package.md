# The `restclient` Package Explained

The `restclient` package (`src/main/java/com/example/fluentapi/restclient/`) is modeled on Spring Framework's `RestClient`/`DefaultRestClient`/`DefaultRestClientBuilder`. Its trick is **compile-time capability restriction through self-bounded generic interfaces**, not runtime checks: `get()`/`delete()` return a spec type that has no `body(...)` method at all, while `post()`/`put()` return one that does — even though the exact same concrete object implements every verb underneath.

## The five classes

**`RestClient`** — the public facade. `RestClient.builder()` returns a `Builder`; the interface nests every supporting spec type, mirroring Spring's structure closely:

- **`UriSpec<S extends RequestHeadersSpec<?>>`** — `uri(path)` returning `S`.
- **`RequestHeadersSpec<S extends RequestHeadersSpec<S>>`** — an **F-bounded (self-referencing) generic**: `header(name, value)` returns `S`, so chaining preserves whatever concrete spec type you started from. Terminal method: `retrieve()` → `ResponseSpec`.
- **`RequestBodySpec extends RequestHeadersSpec<RequestBodySpec>`** — adds `body(Object)`.
- **`RequestHeadersUriSpec<S extends RequestHeadersSpec<S>> extends UriSpec<S>, RequestHeadersSpec<S>`** — URI + headers, no body. This is what `get()`/`delete()` return.
- **`RequestBodyUriSpec extends RequestBodySpec, RequestHeadersUriSpec<RequestBodySpec>`** — URI + headers + body. This is what `post()`/`put()` return.

```mermaid
classDiagram
    class UriSpec {
        <<interface>>
        +uri(path) S
    }
    class RequestHeadersSpec {
        <<interface>>
        +header(name, value) S
        +retrieve() ResponseSpec
    }
    class RequestBodySpec {
        <<interface>>
        +body(body) RequestBodySpec
    }
    class RequestHeadersUriSpec {
        <<interface>>
    }
    class RequestBodyUriSpec {
        <<interface>>
    }
    class DefaultRequestBodyUriSpec {
        -String method
        -String path
        -Map~String,String~ headers
        -Object body
    }

    RequestHeadersSpec <|-- RequestBodySpec
    UriSpec <|-- RequestHeadersUriSpec
    RequestHeadersSpec <|-- RequestHeadersUriSpec
    RequestBodySpec <|-- RequestBodyUriSpec
    RequestHeadersUriSpec <|-- RequestBodyUriSpec
    RequestBodyUriSpec <|.. DefaultRequestBodyUriSpec

    note for RequestHeadersSpec "self-bounded: S extends RequestHeadersSpec~S~"
    note for UriSpec "S extends RequestHeadersSpec~?~ (wildcard, not self-bound)"
```

`get()`/`delete()` return the `RequestHeadersUriSpec` branch (no `RequestBodySpec` in its ancestry, so `body(...)` is unreachable); `post()`/`put()` return the `RequestBodyUriSpec` branch, which pulls `RequestBodySpec` in alongside it. One concrete class, `DefaultRequestBodyUriSpec`, realizes the richest interface and is handed out through whichever narrower declared type each verb promises — the `cache` package's `CacheClient` reapplies this exact shape (see `docs/cache-package.md`).

**`DefaultRestClientBuilder`** — a classic single-object builder (`baseUrl()`, `defaultHeader()`, `server()` all return `this`), terminal `build()` constructs a `DefaultRestClient`. It also carries the three functional-interface-based configuration methods described below (`defaultHeaders(Consumer<...>)`, `defaultStatusHandler(Predicate<...>, Consumer<...>)`, `apply(Consumer<Builder>)`), plus a small `StatusHandler` record pairing a stored predicate with its handler.

**`DefaultRestClient`** — implements `RestClient`. All four verb methods construct the *same* private inner class, `DefaultRequestBodyUriSpec`, which implements the richest interface, `RequestBodyUriSpec`:

```java
@Override
public RequestHeadersUriSpec<?> get() {
    return new DefaultRequestBodyUriSpec("GET");   // same class as post()/put() use
}

@Override
public RequestBodyUriSpec post() {
    return new DefaultRequestBodyUriSpec("POST");
}
```

**`FakeServer`** — an in-memory stand-in for a remote HTTP server (a map from `"METHOD /path"` to a canned status code + body), so the demo can `retrieve()` a real result without any network dependency.

## Why this shape matters

The `order` package's `CustomerStep`/`OrderSteps` split is the closest thing already in this repo to "restrict what's callable next," but it only constrains the *first* call — everything after `withCustomer()` lives on one flat interface. `RestClient` does the equivalent restriction on **every** verb, permanently: `client.get().body(...)` is not a runtime error, it's not an option — the method doesn't exist on `RequestHeadersUriSpec`, so it's a compile error. Yet there's only one implementation class (`DefaultRequestBodyUriSpec`) doing the actual work for both GET and POST. The interfaces are pure compile-time views onto the same object — the runtime has no idea the restriction exists at all.

This is achieved by combining two techniques:
1. **F-bounded polymorphism** (`RequestHeadersSpec<S extends RequestHeadersSpec<S>>`) so that chained header/URI calls keep returning the specific spec type you're already holding, not a generic supertype.
2. **Multiple interface inheritance** to compose "URI + headers" and "URI + headers + body" as two distinct named types (`RequestHeadersUriSpec` vs `RequestBodyUriSpec`) from the same smaller building blocks, so a verb method can declare exactly the capability set it wants to expose.

```mermaid
sequenceDiagram
    participant Client as DefaultRestClient
    participant GetSpec as "DefaultRequestBodyUriSpec (GET)"
    participant PostSpec as "DefaultRequestBodyUriSpec (POST)"

    Client->>GetSpec: new DefaultRequestBodyUriSpec("GET")
    Note right of GetSpec: handed back as wildcard RequestHeadersUriSpec -- .body(...) not visible at this declared type

    Client->>PostSpec: new DefaultRequestBodyUriSpec("POST")
    Note right of PostSpec: handed back as RequestBodyUriSpec -- .body(...) is visible
```

Same class, constructed the same way, differing only in the declared return type of the method that handed it out — that's the entire mechanism.

## Configuring via `Consumer`/`Predicate`, not just setters

The real `DefaultRestClientBuilder` doesn't only expose `withX(value)`-style setters — several `Builder` methods take a `Consumer<T>` or a `Predicate<T>` instead, and `Builder.this` extends that with a `Consumer<Builder>` overload. `RestClient.Builder` here reimplements three of them, each demonstrating a different reason to prefer a functional-interface parameter over a plain value:

**`defaultHeaders(Consumer<Map<String, String>> headersConsumer)`** — modeled directly on the real builder's `messageConverters(Consumer<List<HttpMessageConverter<?>>>)`:

```java
@Override
public RestClient.Builder defaultHeaders(Consumer<Map<String, String>> headersConsumer) {
    headersConsumer.accept(defaultHeaders);
    return this;
}
```

Instead of one method call per header (`defaultHeader(name, value)`, which still exists alongside it), this hands the caller the **live, mutable map itself** — so several headers can be added, replaced, or removed in a single call, using `Map`'s full API (`putAll`, `remove`, `computeIfAbsent`, ...) rather than whatever narrow surface a builder's own setters happen to expose.

**`defaultStatusHandler(Predicate<Integer> statusPredicate, Consumer<Integer> handler)`** — modeled on the real builder's `defaultStatusHandler(Predicate<HttpStatusCode>, ErrorHandler)`:

```java
@Override
public RestClient.Builder defaultStatusHandler(
        Predicate<Integer> statusPredicate, Consumer<Integer> handler) {
    statusHandlers.add(new StatusHandler(statusPredicate, handler));
    return this;
}
```

**This is deliberately not called `errorHandler`.** The real `ErrorHandler` almost always exists to *throw*, converting a bad status into a meaningful exception before the caller ever reaches the body. A plain `Consumer<Integer>` can't do that — it can only observe the matched status code (log it, count it, whatever), and `retrieve()`/`body(...)` proceed normally afterward regardless of what it does. Naming it `handler` rather than `errorHandler` is intentional, so the name doesn't promise more than a `Consumer` can deliver.

The predicate isn't tested at the point it's registered — there's no status code yet to test it against. It's stored (paired with its handler, in a `StatusHandler` record) and evaluated **later**, once `retrieve()` actually has a real response:

```java
public ResponseSpec retrieve() {
    FakeServer.Response response = server.handle(method, path);
    for (StatusHandler statusHandler : statusHandlers) {
        if (statusHandler.predicate().test(response.statusCode())) {
            statusHandler.handler().accept(response.statusCode());
            break;
        }
    }
    return new DefaultResponseSpec(response);
}
```

This is the same shape `bufferContent(BiPredicate<URI, HttpMethod>)` uses in the real builder — a rule captured at configuration time, evaluated against context that doesn't exist until later.

**`apply(Consumer<Builder> builderConsumer)`** — modeled on the real builder's `apply(Consumer<Builder>)`:

```java
@Override
public RestClient.Builder apply(Consumer<RestClient.Builder> builderConsumer) {
    builderConsumer.accept(this);
    return this;
}
```

The one-line implementation is deceptively simple — the value is entirely in what it enables. A `Consumer<Builder>` bundles several other `Builder` calls into a single reusable value, so a shared customization (tracing headers, a standard error handler, ...) can be written once and dropped into any builder chain with `.apply(thatConsumer)`, instead of copy-pasting the same sequence of calls everywhere it's needed.

## Walking the demo

From `FluentApiDemo.demonstrateRestClient()`:

```java
// Consumer<Builder>: a reusable "recipe" bundling several builder calls into one unit
Consumer<RestClient.Builder> withTracingAndErrorLogging =
        builder -> builder
                // Consumer<Map<String, String>>: bulk edit on the live headers map
                .defaultHeaders(headers -> {
                    headers.put("X-Trace-Id", "trace-999");
                    headers.put("X-Client", "fluent-api-demo");
                })
                // Predicate<Integer> + Consumer<Integer>: a rule stored now, evaluated later
                .defaultStatusHandler(
                        status -> status >= 400,
                        status -> System.out.println("  status handler fired for " + status));

RestClient client = RestClient.builder()                 // -> Builder
        .baseUrl("https://api.example.com")               // Builder
        .defaultHeader("Accept", "application/json")      // Builder
        .server(server)                                   // Builder
        .apply(withTracingAndErrorLogging)                // Builder, recipe runs against this
        .build();                                          // -> RestClient

// get() -> RequestHeadersUriSpec<?>: .body(...) isn't visible on this declared type
User fetched = client.get()                               // -> RequestHeadersUriSpec<?>
        .uri("/users/1")                                   // -> RequestHeadersSpec<?> (uri() consumed; no .body() from here)
        .header("X-Trace-Id", "abc-123")                    // -> RequestHeadersSpec<?> (still no .body())
        .retrieve()                                         // -> ResponseSpec
        .body(User.class);                                  // -> User

// post() -> RequestBodyUriSpec: same chain shape, plus .body(...)
User created = client.post()                              // -> RequestBodyUriSpec
        .uri("/users")                                     // -> RequestBodySpec (uri() consumed; .body() still available)
        .header("Content-Type", "application/json")        // -> RequestBodySpec (same)
        .body(new User(0, "Alan Turing"))                   // -> RequestBodySpec
        .retrieve()                                         // -> ResponseSpec
        .body(User.class);                                  // -> User

// No route registered -> FakeServer's default 404 -> the defaultStatusHandler above fires for real
User missing = client.get().uri("/missing").retrieve().body(User.class);
```

Both chains start identically (`.uri(...).header(...)`), but only the `post()` chain can also call `.body(...)` — try adding `.body(...)` after `client.get()...` and it won't compile. The final line's 404 is genuinely produced by `FakeServer.handle(...)`'s "no matching route" fallback, not a canned value — the `defaultStatusHandler` predicate registered earlier is tested against that real status code.

## Q&A

**Q: What does the generic bound on `UriSpec` (`interface UriSpec<S extends RequestHeadersSpec<?>>`) mean, and why isn't it self-bounded like `RequestHeadersSpec`?**

`UriSpec<S extends RequestHeadersSpec<?>>` says "`S` must be *some* `RequestHeadersSpec`" — the `?` wildcard means the type argument to `RequestHeadersSpec` doesn't matter, just that `S` has the shape (`.header(...)`, `.retrieve()`). That's all `uri(path)` needs to hand back.

Compare that to `RequestHeadersSpec<S extends RequestHeadersSpec<S>>`, which *is* self-bounded (F-bounded): `header(...)` returns `S`, and the whole point is that calling `.header(...)` on a `RequestBodyUriSpec` keeps returning `RequestBodyUriSpec` — not some generic supertype — so `.body(...)` is still callable next. That guarantee only holds if `S` is pinned to "whatever concrete type you started from," which only a self-bound enforces.

`UriSpec` doesn't need that guarantee itself; it just needs *a* spec-shaped return type and inherits the strictness from whoever combines it. That combination happens in:

```java
interface RequestHeadersUriSpec<S extends RequestHeadersSpec<S>>
        extends UriSpec<S>, RequestHeadersSpec<S>
```

Here `S` is self-bounded (satisfying `RequestHeadersSpec`'s strict requirement), and that same `S` is passed into `UriSpec<S>`, which accepts it because `RequestHeadersSpec<S>` trivially satisfies the looser `RequestHeadersSpec<?>` bound. The wildcard lets `UriSpec` ask for less than it could, keeping the self-binding requirement scoped to only where it's actually needed.

**Q: Where is `UriSpec` actually implemented?**

Not just `UriSpec` — every request-side spec interface (`UriSpec`, `RequestHeadersSpec`, `RequestBodySpec`, `RequestHeadersUriSpec`, `RequestBodyUriSpec`) is implemented by exactly one class: `DefaultRestClient.DefaultRequestBodyUriSpec`. None of them are implemented separately. `uri(...)` is just one method of many that class provides:

```java
public RequestBodyUriSpec uri(String path) {
    this.path = path;
    return this;
}
```

This falls out of the interface chain: `DefaultRequestBodyUriSpec implements RequestBodyUriSpec`, and `RequestBodyUriSpec extends RequestBodySpec, RequestHeadersUriSpec<RequestBodySpec>`, and `RequestHeadersUriSpec<S> extends UriSpec<S>, RequestHeadersSpec<S>`. Implementing the most specific interface (`RequestBodyUriSpec`) means being on the hook for every abstract method in that whole ancestry at once — `uri` from `UriSpec`, `header`/`retrieve` from `RequestHeadersSpec`, `body` from `RequestBodySpec` — and `DefaultRequestBodyUriSpec` provides all of them in one place, none redeclared lower down. It's the only implementation in the package of any of those five interfaces; the same instance is what `get()`, `post()`, `put()`, and `delete()` all construct, just typed differently (`RequestHeadersUriSpec<?>` vs `RequestBodyUriSpec`) on the way out. The only *other* implementing class in the file is `DefaultResponseSpec`, which implements the one interface `DefaultRequestBodyUriSpec` doesn't: `ResponseSpec`.

**Q: Why are `DefaultRequestBodyUriSpec` and `DefaultResponseSpec` nested inside `DefaultRestClient.java` instead of being their own top-level files?**

Because of whether they need access to `DefaultRestClient`'s instance state:

```java
private final class DefaultRequestBodyUriSpec implements RequestBodyUriSpec {
    private final Map<String, String> headers = new LinkedHashMap<>(defaultHeaders);  // outer field
    ...
    public ResponseSpec retrieve() {
        FakeServer.Response response = server.handle(method, path);   // outer field
        return new DefaultResponseSpec(response);
    }
}

private static final class DefaultResponseSpec implements ResponseSpec {
    // no reference to DefaultRestClient at all
}
```

- `DefaultRequestBodyUriSpec` is a **non-static** inner class because it reads `server` and `defaultHeaders` straight off the enclosing `DefaultRestClient` instance. A non-static inner class implicitly holds a reference to its enclosing instance (`DefaultRestClient.this`), so it gets that access for free instead of needing it threaded through a constructor. Nesting also means it can only ever be created by `DefaultRestClient` itself — `get()`/`post()`/`put()`/`delete()` are the sole call sites of `new DefaultRequestBodyUriSpec(...)`.
- `DefaultResponseSpec` is `static` because it never touches a `DefaultRestClient` field — it only needs the `FakeServer.Response` passed into its constructor. It's nested purely for scoping/visibility, not for state sharing.

`DefaultRestClientBuilder`, by contrast, *is* its own top-level file, because it logically exists **before** any `DefaultRestClient` does — it accumulates `baseUrl`/`defaultHeaders`/`server` and then constructs one (`return new DefaultRestClient(...)`). There's no enclosing instance for it to nest inside yet. This mirrors the real Spring `DefaultRestClient`, where the request-spec classes are nested private classes for the same reach-back-into-outer-state reason, while `DefaultRestClientBuilder` is its own file.

**Q: Why does `RestClient.java` need this many interfaces, if only one class (`DefaultRequestBodyUriSpec`) ever implements most of them?**

The interfaces exist to create distinct *compile-time capability views*, not to enable multiple implementations. Two simpler designs both fail to do that job:

*Option A — two flat, unrelated interfaces* (no shared base):

```java
interface NoBodySpec {
    NoBodySpec uri(String path);
    NoBodySpec header(String name, String value);
    ResponseSpec retrieve();
}
interface BodySpec {
    BodySpec uri(String path);
    BodySpec header(String name, String value);
    BodySpec body(Object body);
    ResponseSpec retrieve();
}
```

`uri`/`header`/`retrieve` get declared twice, verbatim, with no common ancestor. Any change to one (say, adding `cookie(...)`) has to be made in both, and there's no single type to write generic code against for "a request I can add a header to, regardless of whether it also supports a body." That's a real need in the original — Spring's actual `RestClient.Builder.defaultRequest(Consumer<RequestHeadersSpec<?>>)` is exactly a callback that customizes *any* request, GET or POST, uniformly.

*Option B — one merged interface with `body()` always present*:

```java
interface RequestSpec {
    RequestSpec uri(String path);
    RequestSpec header(String name, String value);
    RequestSpec body(Object body);
    ResponseSpec retrieve();
}
```

This defeats the entire point — `.body()` would compile on a GET chain too, exactly what the pattern exists to prevent.

So the design splits into small, single-responsibility interfaces and recombines them instead:

- `UriSpec<S>` — owns only `uri(...)`.
- `RequestHeadersSpec<S extends RequestHeadersSpec<S>>` — owns `header(...)` and the terminal `retrieve()`. Self-bounded so that when it's mixed into a richer type, `.header(...)` still returns that richer type, not a downgraded common ancestor.
- `RequestBodySpec extends RequestHeadersSpec<RequestBodySpec>` — adds `body(...)` on top, declared exactly once.
- `RequestHeadersUriSpec<S>` and `RequestBodyUriSpec` — the two verb-facing *compositions*, assembled from the pieces above via multiple inheritance rather than duplicating method signatures.

Each method contract (`uri`, `header`, `retrieve`, `body`) is written exactly once, in the smallest interface that owns it; everything above that is composition, not new methods. That buys three things simultaneously: no duplicated signatures, a common ancestor (`RequestHeadersSpec<?>`) to write capability-agnostic code against, and — via the composed leaf types — a different visible method set per verb at compile time. One implementation class can satisfy all of it because interfaces only constrain what's *visible*, not how many classes provide it.

## Caveats (intentional simplifications vs. the real `RestClient`)

- `FakeServer` is an in-memory route table, not a real HTTP transport — no actual network I/O, serialization, or JSON parsing happens; `ResponseSpec.body(Class<T>)` just casts the pre-registered response object.
- `baseUrl` is stored on the client but never actually prepended to the request path — `FakeServer` matches routes by path alone, since there's no real URI resolution layer here.
- `defaultStatusHandler` only stores a flat `List<StatusHandler>`, checked in registration order with the first match winning — the real builder's status handlers interact with per-request `onStatus(...)` handlers and a default 4xx/5xx exception, none of which is reproduced here.
- The real `RestClient` also supports interceptors, request/response observation, cookies, API versioning, `exchange()` for raw response access, and configurable message converters — all omitted here to keep the self-bounded-generics trick and the `Consumer`/`Predicate` configuration technique the focus.
