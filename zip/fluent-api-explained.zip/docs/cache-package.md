# The `cache` Package Explained

The `cache` package (`src/main/java/com/example/fluentapi/cache/`) reapplies `restclient`'s technique — **compile-time capability restriction through self-bounded generic interfaces** — to a different, self-designed domain: an in-process TTL cache. Like `retry`, it has no fake backend: `get()`/`put()`/`evict()` really store, really expire (against the real clock), and really evict entries, backed by a real `ConcurrentHashMap`.

## The shape, renamed from `restclient`

Every interface here has a direct counterpart in `restclient`:

| `restclient` | `cache` | Role |
|---|---|---|
| `UriSpec<S extends RequestHeadersSpec<?>>` | `KeySpec<S extends OperationSpec<?>>` | owns the one URI-like/key-like setter |
| `RequestHeadersSpec<S extends RequestHeadersSpec<S>>` | `OperationSpec<S extends OperationSpec<S>>` | self-bounded; owns shared options + the terminal call |
| `RequestBodySpec extends RequestHeadersSpec<RequestBodySpec>` | `ValueSpec extends OperationSpec<ValueSpec>` | adds the "only some verbs get this" capability |
| `RequestHeadersUriSpec<S> extends UriSpec<S>, RequestHeadersSpec<S>` | `KeyOperationSpec<S> extends KeySpec<S>, OperationSpec<S>` | composed view with no extra capability — returned by `get()`/`evict()` |
| `RequestBodyUriSpec extends RequestBodySpec, RequestHeadersUriSpec<RequestBodySpec>` | `ValueOperationSpec extends ValueSpec, KeyOperationSpec<ValueSpec>` | composed view with the extra capability — returned by `put()` |

`DefaultCacheClient.DefaultOperationSpec` is the single implementation behind all three verbs, exactly like `DefaultRestClient.DefaultRequestBodyUriSpec` — `get()`/`evict()` hand out a reference to it typed as `KeyOperationSpec<?>` (no `.value(...)`/`.ttl(...)`), `put()` hands out the same class typed as `ValueOperationSpec` (adds both).

```mermaid
classDiagram
    class KeySpec {
        <<interface>>
        +key(key) S
    }
    class OperationSpec {
        <<interface>>
        +region(region) S
        +execute() Optional
        +execute(type) Optional
    }
    class ValueSpec {
        <<interface>>
        +value(value) ValueSpec
        +ttl(ttl) ValueSpec
    }
    class KeyOperationSpec {
        <<interface>>
    }
    class ValueOperationSpec {
        <<interface>>
    }
    class DefaultOperationSpec {
        -Operation operation
        -String key
        -String region
        -Object value
        -Duration ttl
    }

    OperationSpec <|-- ValueSpec
    KeySpec <|-- KeyOperationSpec
    OperationSpec <|-- KeyOperationSpec
    ValueSpec <|-- ValueOperationSpec
    KeyOperationSpec <|-- ValueOperationSpec
    ValueOperationSpec <|.. DefaultOperationSpec

    note for OperationSpec "self-bounded: S extends OperationSpec~S~"
    note for KeySpec "S extends OperationSpec~?~ (wildcard, not self-bound)"
```

`get()`/`evict()` return the `KeyOperationSpec` branch (no `ValueSpec` in its ancestry, so `value`/`ttl` are unreachable); `put()` returns the `ValueOperationSpec` branch, which pulls in `ValueSpec` alongside it. One concrete class, `DefaultOperationSpec`, realizes the richest interface and is handed out through whichever narrower declared type each verb promises.

## Design rationale

### Why three interfaces instead of one or two

The same reasoning `restclient` uses applies here, replayed against the cache domain. A single flat interface with every method —

```java
interface Operation {
    Operation key(String key);
    Operation region(String region);
    Operation value(Object value);
    Operation ttl(Duration ttl);
    Optional<Object> execute();
}
```

— would let `.value(...)`/`.ttl(...)` compile on a `get()`/`evict()` chain, which is exactly what this package exists to prevent: calling `cache.get().value("x")` should be a compile error, not a call that silently does nothing (or worse, an `IllegalStateException` discovered at runtime). Two unrelated flat interfaces (a `key`+`region`+`execute`-only one for `get`/`evict`, a separate `key`+`region`+`value`+`ttl`+`execute` one for `put`) would avoid that, but at the cost of declaring `key`, `region`, and `execute` twice with no shared type — so a hypothetical `CacheClient.Builder.defaultOperation(Consumer<?>)` callback (mirroring `restclient`'s `Builder.defaultRequest(Consumer<RequestHeadersSpec<?>>)`) would have nothing common to be typed against.

So the design is decomposed by *who needs which method*, then recombined:
- `KeySpec<S>` — only `key(...)`. Every verb needs it.
- `OperationSpec<S extends OperationSpec<S>>` — `region(...)` and both `execute(...)` overloads. Every verb needs these too — a namespace prefix and a terminal call are meaningful for a read, a write, or a delete alike.
- `ValueSpec extends OperationSpec<ValueSpec>` — adds `value(...)`/`ttl(...)`. Only `put()` needs these; they're meaningless for `get()`/`evict()` (what would `.ttl(...)` even mean on a read?).

`KeyOperationSpec<S>` and `ValueOperationSpec` are then pure compositions of those three — no new methods declared, just different combinations wired together, so each method contract exists exactly once in the source.

### Why `OperationSpec` has to be self-bounded

`region(...)` and `execute(...)` need to return "whatever richer type the caller is already holding," not a generic supertype — otherwise chaining `.region(...)` on a `ValueOperationSpec` would downgrade to something that's lost `.value(...)`. That's what `S extends OperationSpec<S>` buys: when `ValueSpec extends OperationSpec<ValueSpec>` fixes `S = ValueSpec`, `.region(...)` on a `ValueSpec` is guaranteed by the type system to return `ValueSpec` again, not some `OperationSpec<?>` that's lost the value-related methods. Losing this — say, if `OperationSpec` were declared as a plain (non-self-bounded) `OperationSpec<T>` with `region()` returning a hardcoded `OperationSpec<T>` — would make `.region(...).value(...)` fail to compile even on `put()`, since `OperationSpec` itself doesn't know about `value(...)`.

### Does `ValueSpec` need to extend `OperationSpec`? (yes — verified by breaking it)

It's tempting to read `ValueSpec extends OperationSpec<ValueSpec>` as decorative — just mirroring `restclient`'s `RequestBodySpec extends RequestHeadersSpec<RequestBodySpec>` for consistency. It isn't. Removing the `extends` breaks the package two different ways, confirmed by actually deleting it and running `mvn clean compile` (plain `mvn compile` without `clean` is *not* reliable here — it silently reported success once, because Maven's default incremental compiler doesn't always detect that a change to one interface invalidates already-compiled classes that depend on it; only a clean rebuild forced real recompilation):

**1. The interface declaration itself stops compiling, before any chaining is even involved:**

```
CacheClient.java:[62,70] type argument com.example.fluentapi.cache.CacheClient.ValueSpec
    is not within bounds of type-variable S
```

`KeyOperationSpec<S extends OperationSpec<S>>` requires its type argument to itself satisfy `OperationSpec<S>`. `ValueOperationSpec extends ValueSpec, KeyOperationSpec<ValueSpec>` instantiates that with `S = ValueSpec` — so `ValueSpec` has to extend `OperationSpec<ValueSpec>`, or the bound is violated and `ValueOperationSpec`'s own declaration is ill-formed.

**2. Even setting that aside, the actual demo chain breaks, because `.key(...)` narrows the static type down to bare `ValueSpec`:**

```
FluentApiDemo.java:[394,25] cannot find symbol: method region(String) location: ValueSpec
FluentApiDemo.java:[415,44] cannot find symbol: method execute()      location: ValueSpec
```

`key(String)` is declared once, in `KeySpec<S>`, returning `S`. In the composition `KeyOperationSpec<ValueSpec>`, that `S` is fixed to `ValueSpec` — so `cache.put().key("42")` has static type `ValueSpec`, not `ValueOperationSpec`. Whatever follows in the chain (`.region(...)`, `.execute()`) has to be visible *on `ValueSpec` itself*, which only holds if `ValueSpec` extends `OperationSpec<ValueSpec>`.

So the `extends` is load-bearing on two independent levels: the generic bound needs it just to type-check, and the `.key(...).region(...).value(...).ttl(...).execute()` chain needs it to have anywhere to go once `.key(...)` narrows the type.

### What's shared vs. what's verb-specific — and why that split, specifically

The line drawn between `OperationSpec` (shared) and `ValueSpec` (put-only) mirrors `restclient`'s line between `RequestHeadersSpec` (shared: headers apply to every HTTP verb) and `RequestBodySpec` (post/put-only: a body doesn't make sense on a GET). Here, `region(...)` is a namespacing concern — it's just as meaningful when reading or deleting a key as when writing one, so it belongs on the shared side. `value(...)`/`ttl(...)` describe *what's being written and for how long* — neither has a sensible meaning outside of a write, so they're scoped to `ValueSpec` alone, and therefore unreachable from `get()`/`evict()`'s declared return type.

### Why `execute()` has two overloads

```java
Optional<Object> execute();
<T> Optional<T> execute(Class<T> type);
```

The untyped overload is the honest baseline — the cache stores `Object`, so that's what a raw read returns. The typed overload (`execute(String.class)` in the demo) mirrors `restclient`'s `ResponseSpec.body(Class<T>)`: a convenience that saves the caller an explicit cast, implemented as one line (`execute().map(type::cast)`) built directly on top of the untyped version rather than duplicating any logic.

### Why one `Operation` enum instead of three implementation classes

`DefaultOperationSpec` is parameterized by an `Operation` enum (`GET`, `PUT`, `EVICT`) rather than being three separate classes (`DefaultGetSpec`, `DefaultPutSpec`, `DefaultEvictSpec`). All three verbs share every field (`key`, `region`, `value`, `ttl`) and every setter — the only thing that differs is what `execute()` does with them, which is a natural `switch` inside one method rather than three classes duplicating `key(...)`/`region(...)`/`value(...)`/`ttl(...)`. This is a deliberate departure from `restclient`, where GET/POST/PUT/DELETE genuinely have no behavioral difference at the transport level (they're just an HTTP method string) — here, `execute()` truly does three different things, so the enum-plus-switch keeps that difference localized to exactly one method instead of smearing it across the class hierarchy.

### Why lazy expiry instead of a background sweeper

A real cache could run a scheduled thread that proactively evicts expired entries. This one only checks `isExpired()` when something reads the key (`currentValue(...)`), which is deliberately the simpler of the two legitimate designs real caches use — Caffeine, for instance, offers both, but lazy-on-read is the one that needs no background thread, no shutdown hook, and no extra state, which keeps this package's only moving part the `ConcurrentHashMap` itself.

## What's actually real here

- `store` is a genuine `ConcurrentHashMap<String, CacheEntry>` — not a stand-in for a missing external system.
- `CacheEntry.isExpired()` compares `expiresAt` against `Instant.now()` — a real wall-clock check, not simulated time.
- Expiry is **lazy**, the same technique real caches (Guava, Caffeine) use: an expired entry isn't proactively swept, it's simply removed the next time something reads it past its `expiresAt` (`currentValue(...)` in `DefaultOperationSpec`). The demo proves this by actually sleeping past a 50ms TTL and observing the key really vanish.
- `execute()` (shared by all three verbs) returns the value that existed *before* the operation — for `get()` that's just "the current value if present," for `put()` it's "whatever this call just replaced," for `evict()` it's "whatever this call just removed." One return convention, three genuinely different underlying actions (`switch` on an `Operation` enum inside `DefaultOperationSpec.execute()`).

## A real subtlety of this pattern: call order matters

Building this surfaced something `restclient`'s own demo never has to confront, because its demo happens to already call things in the required order. Consider `get()`, returning `KeyOperationSpec<?>`. The wildcard `?` gets captured to some `CAP#1 extends OperationSpec<CAP#1>` (per `KeyOperationSpec<S extends OperationSpec<S>>`'s own type bound). Calling `.key(...)` first (declared on `KeySpec<S>`, returning `S`) yields back type `CAP#1` — whose only known bound is `OperationSpec<CAP#1>`, which *does* declare `.region(...)` and `.execute()`, so those chain fine afterward.

But flip the order — call `.region(...)` first — and the same capture happens through `OperationSpec<CAP#1>.region(...)`, again returning `CAP#1` bound to `OperationSpec<CAP#1>`. The compiler only knows that bound, not the fuller fact that the concrete object also satisfies `KeySpec`, so `.key(...)` is no longer visible on it. This was a real compiler error hit while writing the demo:

```
cannot find symbol: method key(java.lang.String)
location: interface com.example.fluentapi.cache.CacheClient.OperationSpec<capture#1 of ?>
```

The fix is the same rule `restclient` follows implicitly: **the `KeySpec`-derived call (`key(...)`/`uri(...)`) must be the first call in the chain**, before any call that only exists on the shared `OperationSpec`/`RequestHeadersSpec` side. Every example in `FluentApiDemo.demonstrateCacheClient()` calls `.key(...)` immediately after the verb, before `.region(...)`:

```java
cache.put()                             // -> ValueOperationSpec
        .key("42")                       // -> ValueSpec (narrows here — key() returns S=ValueSpec)
        .region("users")                 // -> ValueSpec
        .value("Ada Lovelace")           // -> ValueSpec
        .ttl(Duration.ofMillis(50))      // -> ValueSpec
        .execute();                      // -> Optional<Object>
```

## Walking the demo

From `FluentApiDemo.demonstrateCacheClient()`:

```java
CacheClient cache = CacheClient.create();                // -> CacheClient

cache.put()                                              // -> ValueOperationSpec
        .key("42")                                        // -> ValueSpec
        .region("users")                                  // -> ValueSpec
        .value("Ada Lovelace")                             // -> ValueSpec
        .ttl(Duration.ofMillis(50))                        // -> ValueSpec
        .execute();                                        // -> Optional<Object>

Optional<String> fetched = cache.get()                    // -> KeyOperationSpec<?>
        .key("42")                                         // -> OperationSpec<?> (captured; no .key() again)
        .region("users")                                   // -> OperationSpec<?> (unchanged)
        .execute(String.class);                            // -> Optional<String>
// -> Optional[Ada Lovelace]

Thread.sleep(60); // really wait past the 50ms TTL

Optional<String> expired = cache.get()                    // -> KeyOperationSpec<?>
        .key("42")                                         // -> OperationSpec<?>
        .region("users")                                   // -> OperationSpec<?>
        .execute(String.class);                            // -> Optional<String>
// -> Optional.empty  (the entry really expired and was really evicted on this read)
```

```mermaid
sequenceDiagram
    participant Demo
    participant Spec as DefaultOperationSpec
    participant Store as ConcurrentHashMap

    Demo->>Spec: put().key("42").region("users").value("Ada Lovelace").ttl(50ms)
    Demo->>Spec: execute()
    Spec->>Store: put("users:42", expiresAt = now + 50ms)
    Spec-->>Demo: Optional.empty()  (nothing there before)

    Demo->>Spec: get().key("42").region("users")
    Demo->>Spec: execute(String.class)
    Spec->>Store: get("users:42")
    Store-->>Spec: entry, not expired
    Spec-->>Demo: Optional[Ada Lovelace]

    Note over Demo: Thread.sleep(60ms) — really waits past the 50ms TTL

    Demo->>Spec: get().key("42").region("users")
    Demo->>Spec: execute(String.class)
    Spec->>Store: get("users:42")
    Store-->>Spec: entry, isExpired() == true
    Spec->>Store: remove("users:42")
    Spec-->>Demo: Optional.empty()
```

The middle `get()` and the final `get()` are the *same call*, textually — the only thing that changed between them is 60 real milliseconds passing. That's the proof this isn't simulated: nothing in the demo code branches on "first call" vs. "second call," the cache just answers differently because the clock actually moved.

A second scenario overwrites a key with no TTL and shows `put()`'s `execute()` reporting the value it replaced; a third calls `evict()` twice on the same key to show the second call returning `Optional.empty()` (nothing left to remove).

## Caveats

- `region(...)` is implemented as a plain string prefix (`region + ":" + key`) — there's no real namespace isolation beyond that, and colliding region/key combinations aren't guarded against.
- There's no size-based eviction (LRU/LFU) — only TTL-based expiry, and only checked lazily on read, so an expired-but-never-read entry stays in memory until something looks it up (or forever, if nothing ever does).
