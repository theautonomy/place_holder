# The `client` Package Explained

The `client` package (`src/main/java/com/example/fluentapi/client/`) is modeled directly on Spring Framework's `JdbcClient`/`DefaultJdbcClient`. Its trick is **terminal fan-out**: a single `StatementSpec` accumulates parameter bindings through chaining, and the *last* call in the chain — not a runtime type check on the input — decides which result-shaped object comes back.

## The three classes

**`DataClient`** — the public facade. `DataClient.create(DataStore)` is the static factory; `sql(String table)` is the sole entry point, returning a `StatementSpec`. It also nests every supporting type (`StatementSpec`, `RowQuerySpec`, `MappedQuerySpec<T>`, `RowMapper<T>`), mirroring how `JdbcClient` nests `StatementSpec`, `ResultQuerySpec`, and `MappedQuerySpec<T>`.

**`StatementSpec`** — `param(name, value)` and `params(map)` return `this` (plain chaining, like a classic builder). But it exposes three *terminal* methods that each return something different:
- `query()` → `RowQuerySpec` (raw `Map<String, Object>` rows)
- `query(RowMapper<T>)` → `MappedQuerySpec<T>` (rows mapped into a caller-supplied type)
- `update(changes)` → a plain `int` (no spec object at all)

All three read the *same* accumulated `params`, just handed to a different consumer depending on which terminal method was called.

**`RowQuerySpec`** and **`MappedQuerySpec<T>`** — each declares one abstract method, `list()`, and gets `single()` and `optional()` for free as **default methods implemented once, on top of `list()`** — a template-method pattern living entirely in the interface. `single()` throws if the row/result count isn't exactly one; `optional()` throws only if there's more than one, otherwise wraps zero-or-one in an `Optional`.

**`DataStore`** — the "database": named tables, each a `List<Map<String, Object>>`. `DefaultDataClient` (package-private, final — same visibility as `DefaultJdbcClient`) filters a table's rows against the bound `params` by equality before handing them to whichever terminal spec was requested.

```mermaid
sequenceDiagram
    participant Caller
    participant Spec as StatementSpec
    participant Row as RowQuerySpec
    participant Mapped as MappedQuerySpec~T~

    Caller->>Spec: sql("customers").param("city", "London")
    Spec-->>Caller: this (StatementSpec, params accumulated)

    alt query()
        Caller->>Spec: query()
        Spec-->>Caller: new RowQuerySpec(matchingRows())
        Caller->>Row: list() / single() / optional()
    else query(rowMapper)
        Caller->>Spec: query(rowMapper)
        Spec-->>Caller: new MappedQuerySpec(matchingRows(), rowMapper)
        Caller->>Mapped: list() / single() / optional()
    else update(changes)
        Caller->>Spec: update(changes)
        Spec-->>Caller: int (rows affected) — no spec object at all
    end
```

All three branches start from the identical `sql(...).param(...)` state — the `alt` block is exactly the fan-out: one accumulated `StatementSpec`, three completely different result shapes depending solely on which terminal method is called last.

## Why the terminal fan-out matters

The `assertion` package narrows based on the *runtime type of the wrapped value* (`asString()` checks `actual instanceof String`-ish). This package narrows based on **what the caller asks for at the end of the chain**, with no type inspection at all — `query()` vs `query(rowMapper)` vs `update(...)` are simply three different methods, each returning its own shape, and the compiler picks the right overload from the argument alone. It's the same "one interface, multiple hidden implementations" idea as the `sql` package's ping-pong, but the fork happens at the *end* of the chain instead of the middle, and nothing ever hands control back to a parent object — the chain just ends in whichever terminal type it ends in.

## Walking the demo

From `FluentApiDemo.demonstrateDataClient()`:

```java
DataClient client = DataClient.create(store);           // -> DataClient

// query() -> RowQuerySpec, raw rows
List<Map<String, Object>> londoners =
        client.sql("customers")                          // -> StatementSpec
                .param("city", "London")                 // StatementSpec (this)
                .query()                                  // -> RowQuerySpec
                .list();                                  // -> List<Map<String, Object>>

// query(RowMapper) -> MappedQuerySpec<Customer>, same StatementSpec shape
Optional<Customer> ada =
        client.sql("customers")                          // -> StatementSpec
                .param("name", "Ada Lovelace")            // StatementSpec (this)
                .query(row -> new Customer((String) row.get("name"), (int) row.get("age"))) // -> MappedQuerySpec<Customer>
                .optional();                              // -> Optional<Customer>

// update(...) -> plain int, no result spec at all
int updated =
        client.sql("customers")                          // -> StatementSpec
                .param("city", "London")                 // StatementSpec (this)
                .update(Map.of("city", "Greater London")); // -> int
```

Each block starts identically (`client.sql("customers").param(...)`), and only the final call determines what comes back.

## Caveats (intentional simplifications vs. the real `JdbcClient`)

- `DataStore` is an in-memory map of tables, not a real database — the `sql(String)` argument is a table name, not an actual SQL statement, and there's no SQL parsing at all.
- Filtering is equality-only (`param("city", "London")` means "row's `city` column equals `London`"); there's no equivalent of positional `?` parameters, operators, or `SqlParameterSource`.
- `update()` takes the new column values directly rather than executing an arbitrary SQL update statement.
- Real `JdbcClient` also supports `RowCallbackHandler`, `ResultSetExtractor`, generated keys, and per-statement fetch size/timeout — all omitted here to keep the fan-out shape the focus.
