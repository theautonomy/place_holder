# The config Package Explained

The `config` package (`src/main/java/com/example/fluentapi/config/`) demonstrates a **nested sub-builder DSL**: one parent builder delegates to independent child builders for each config section, and each child builder has a way back up to the parent.

## The pieces

**`ConfigurationDsl`** — entry point, `configure() -> ConfigurationBuilder`.

**`ConfigurationBuilder`** — the parent/root builder. It holds the three finished sub-configs (`DatabaseConfig`, `CacheConfig`, `LoggingConfig`, all `null` until set) and exposes one method per section — `database()`, `cache()`, `logging()` — each of which returns a **fresh child builder** wired back to `this`:
```java
public DatabaseConfigBuilder database() {
    return new DatabaseConfigBuilder(this);
}
```
Its own `build()` assembles the three (possibly-null) sub-configs into an `AppConfiguration`.

**`DatabaseConfigBuilder`**, **`CacheConfigBuilder`**, **`LoggingConfigBuilder`** — each holds a reference to the parent `ConfigurationBuilder` plus its own section's fields, with plain `withX(...)` setters returning `this`. The key method is **`and()`**: it constructs the finished immutable record (`DatabaseConfig`/`CacheConfig`/`LoggingConfig`), pushes it into the parent via a package-private setter (`parent.setDatabaseConfig(...)`, etc.), and **returns the parent** — that's the "step back up" that lets the chain move on to the next section.

**`AppConfiguration`**, **`DatabaseConfig`**, **`CacheConfig`**, **`LoggingConfig`** — the immutable result. The three section configs are records with custom `toString()`; `AppConfiguration` is a plain class that null-checks each section before printing (since any section is optional).

```mermaid
sequenceDiagram
    participant Caller
    participant Parent as ConfigurationBuilder
    participant DB as DatabaseConfigBuilder

    Caller->>Parent: database()
    Parent-->>Caller: new DatabaseConfigBuilder(this)

    Caller->>DB: withHost(...).withPort(...)
    DB-->>Caller: this (DatabaseConfigBuilder)

    Caller->>DB: and()
    DB->>Parent: setDatabaseConfig(new DatabaseConfig(...))
    DB-->>Caller: return parent (ConfigurationBuilder)

    Caller->>Parent: cache()
    Parent-->>Caller: new CacheConfigBuilder(this)
```

Unlike `sql`'s ping-pong (a fresh clause object per call, immediately bounced back), each section builder here is **descended into and stayed in** for several calls (`withHost`, `withPort`, ...), and only `.and()` climbs back to the parent — a coarser-grained handoff, one per section instead of one per method call.

## The chain

```java
AppConfiguration config = ConfigurationDsl.configure()   // ConfigurationBuilder
    .database()                                            // -> DatabaseConfigBuilder
        .withHost("localhost")                             // DatabaseConfigBuilder
        .withPort(5432)                                    // DatabaseConfigBuilder
        .withName("myapp")                                 // DatabaseConfigBuilder
        .withCredentials("user", "password")               // DatabaseConfigBuilder
        .withConnectionPool(10, 50)                        // DatabaseConfigBuilder
    .and()                                                  // commits DatabaseConfig, -> ConfigurationBuilder
    .cache()                                                // -> CacheConfigBuilder
        .withProvider("redis")                             // CacheConfigBuilder
        .withHost("cache-server")                          // CacheConfigBuilder
        .withTtl(3600)                                      // CacheConfigBuilder
    .and()                                                  // commits CacheConfig, -> ConfigurationBuilder
    .logging()                                              // -> LoggingConfigBuilder
        .withLevel("INFO")                                 // LoggingConfigBuilder
        .withFile("/var/log/app.log")                      // LoggingConfigBuilder
        .withRotation(true)                                // LoggingConfigBuilder
    .build();                                               // commits LoggingConfig AND builds AppConfiguration
```

Each section "descends" into its own builder, then `.and()` climbs back up to the shared parent so the next section can start — a shape you could call a **fluent DSL with checkpoints**, versus the ping-pong pattern in `sql`/`assertion` where the child always returns to the *same* parent object per call rather than accumulating multiple independent sections.

## Things worth noting

- **Sections are optional and unordered.** Nothing stops you from calling `.cache()` before `.database()`, or skipping a section entirely — `ConfigurationBuilder.build()` happily builds an `AppConfiguration` with a `null` section, which `AppConfiguration.toString()` guards against explicitly. There's no compile-time enforcement here, unlike `order`'s first-step narrowing.
- **`LoggingConfigBuilder` is special-cased.** It's the only child builder with a `build()` shortcut (`.build()` commits the section *and* immediately calls `parent.build()`), presumably because it tends to be written last in examples. `DatabaseConfigBuilder`/`CacheConfigBuilder` don't have this — if logging weren't last, you'd write `.and().build()` instead. It's a minor asymmetry rather than a deliberate design rule.
