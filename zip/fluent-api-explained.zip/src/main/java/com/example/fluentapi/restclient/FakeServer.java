package com.example.fluentapi.restclient;

import java.util.HashMap;
import java.util.Map;

/** A tiny in-memory stand-in for a remote HTTP server: routes keyed by method + path. */
public final class FakeServer {
    private final Map<String, Response> routes = new HashMap<>();

    public FakeServer route(String method, String path, int statusCode, Object body) {
        routes.put(key(method, path), new Response(statusCode, body));
        return this;
    }

    Response handle(String method, String path) {
        return routes.getOrDefault(key(method, path), new Response(404, null));
    }

    private static String key(String method, String path) {
        return method + " " + path;
    }

    record Response(int statusCode, Object body) {}
}
