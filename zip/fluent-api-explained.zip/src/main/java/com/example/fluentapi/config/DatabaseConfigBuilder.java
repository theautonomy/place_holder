package com.example.fluentapi.config;

public class DatabaseConfigBuilder {
    private final ConfigurationBuilder parent;
    private String host;
    private int port;
    private String name;
    private String username;
    private String password;
    private int minConnections;
    private int maxConnections;

    public DatabaseConfigBuilder(ConfigurationBuilder parent) {
        this.parent = parent;
    }

    public DatabaseConfigBuilder withHost(String host) {
        this.host = host;
        return this;
    }

    public DatabaseConfigBuilder withPort(int port) {
        this.port = port;
        return this;
    }

    public DatabaseConfigBuilder withName(String name) {
        this.name = name;
        return this;
    }

    public DatabaseConfigBuilder withCredentials(String username, String password) {
        this.username = username;
        this.password = password;
        return this;
    }

    public DatabaseConfigBuilder withConnectionPool(int min, int max) {
        this.minConnections = min;
        this.maxConnections = max;
        return this;
    }

    public ConfigurationBuilder and() {
        parent.setDatabaseConfig(
                new DatabaseConfig(
                        host, port, name, username, password, minConnections, maxConnections));
        return parent;
    }
}
