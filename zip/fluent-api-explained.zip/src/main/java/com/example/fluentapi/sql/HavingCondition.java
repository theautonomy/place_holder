package com.example.fluentapi.sql;

public class HavingCondition {
    private final SqlBuilder builder;
    private final String column;

    public HavingCondition(SqlBuilder builder, String column) {
        this.builder = builder;
        this.column = column;
    }

    public SqlBuilder greaterThan(String value) {
        builder.addHavingCondition(column + " > " + value);
        return builder;
    }
}
