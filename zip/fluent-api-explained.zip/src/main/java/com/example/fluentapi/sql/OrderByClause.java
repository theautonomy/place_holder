package com.example.fluentapi.sql;

public class OrderByClause {
    private final SqlBuilder builder;
    private final String column;

    public OrderByClause(SqlBuilder builder, String column) {
        this.builder = builder;
        this.column = column;
    }

    public SqlBuilder ascending() {
        builder.addOrderBy(column, "ASC");
        return builder;
    }

    public SqlBuilder descending() {
        builder.addOrderBy(column, "DESC");
        return builder;
    }
}
