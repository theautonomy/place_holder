package com.example.fluentapi.assertion;

/** Number-specific assertions */
public class NumberAssert {
    private final Number actual;

    public NumberAssert(Number actual) {
        this.actual = actual;
    }

    public NumberAssert isGreaterThan(Number expected) {
        if (actual.doubleValue() <= expected.doubleValue()) {
            throw new AssertionError("Expected " + actual + " to be greater than " + expected);
        }
        return this;
    }

    public NumberAssert isLessThan(Number expected) {
        if (actual.doubleValue() >= expected.doubleValue()) {
            throw new AssertionError("Expected " + actual + " to be less than " + expected);
        }
        return this;
    }

    public NumberAssert isBetween(Number min, Number max) {
        double value = actual.doubleValue();
        if (value < min.doubleValue() || value > max.doubleValue()) {
            throw new AssertionError(
                    "Expected " + actual + " to be between " + min + " and " + max);
        }
        return this;
    }
}
