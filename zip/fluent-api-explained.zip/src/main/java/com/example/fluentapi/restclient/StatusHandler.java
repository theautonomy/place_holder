package com.example.fluentapi.restclient;

import java.util.function.Consumer;
import java.util.function.Predicate;

/** A predicate paired with the handler to run when it matches a response's status code. */
record StatusHandler(Predicate<Integer> predicate, Consumer<Integer> handler) {}
