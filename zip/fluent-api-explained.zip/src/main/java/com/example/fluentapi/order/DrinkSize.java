package com.example.fluentapi.order;

public enum DrinkSize {
    SMALL,
    MEDIUM,
    LARGE
}
