package com.example.fluentapi.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class OrderBuilder implements CustomerStep, OrderSteps {
    private String customer;
    private final List<OrderItem> items = new ArrayList<>();
    private String currentItemName;
    private int currentQuantity;
    private String deliveryAddress;
    private LocalDateTime deliveryTime;
    private LocalDateTime pickupTime;
    private BigDecimal discount = BigDecimal.ZERO;

    @Override
    public OrderSteps withCustomer(String customerName) {
        this.customer = customerName;
        return this;
    }

    @Override
    public OrderSteps addItem(String itemName, int quantity) {
        this.currentItemName = itemName;
        this.currentQuantity = quantity;
        return this;
    }

    @Override
    public OrderSteps addDrink(String drinkName, DrinkSize size) {
        this.currentItemName = drinkName + " (" + size + ")";
        this.currentQuantity = 1;
        return this;
    }

    @Override
    public OrderSteps withPrice(BigDecimal price) {
        items.add(new OrderItem(currentItemName, currentQuantity, price));
        return this;
    }

    @Override
    public OrderSteps withAddress(String address) {
        this.deliveryAddress = address;
        return this;
    }

    @Override
    public OrderSteps withDeliveryTime(LocalDateTime time) {
        this.deliveryTime = time;
        return this;
    }

    @Override
    public OrderSteps withPickupTime(LocalDateTime time) {
        this.pickupTime = time;
        return this;
    }

    @Override
    public OrderSteps setDelivery() {
        return this;
    }

    @Override
    public OrderSteps setPickup() {
        return this;
    }

    @Override
    public OrderSteps applyDiscount(BigDecimal discount) {
        this.discount = discount;
        return this;
    }

    @Override
    public Order complete() {
        return new Order(customer, items, deliveryAddress, deliveryTime, pickupTime, discount);
    }
}
