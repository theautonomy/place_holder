package com.example.fluentapi.evolution;

/**
 * Version 2 of the tiny fluent client: the same {@code uri(...)} step still exists, but it's no
 * longer required. Watching developers write {@code uri("")} just to satisfy v1's type system was
 * the signal that the base URL alone should be a valid, complete request on its own.
 */
public final class SimpleClientV2 {
    private final String baseUrl;

    private SimpleClientV2(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public static SimpleClientV2 create(String baseUrl) {
        return new SimpleClientV2(baseUrl);
    }

    public Request uri(String path) {
        return new Request(baseUrl + path);
    }

    /** New in v2: skip {@code uri(...)} entirely and request the base URL as-is. */
    public String retrieve() {
        return uri("").retrieve();
    }

    public static final class Request {
        private final String url;

        private Request(String url) {
            this.url = url;
        }

        public String retrieve() {
            return "response from " + url;
        }
    }
}
