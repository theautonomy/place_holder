package com.example.fluentapi.restclient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;

final class DefaultRestClientBuilder implements RestClient.Builder {
    private String baseUrl = "";
    private final Map<String, String> defaultHeaders = new LinkedHashMap<>();
    private final List<StatusHandler> statusHandlers = new ArrayList<>();
    private FakeServer server;

    @Override
    public RestClient.Builder baseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
        return this;
    }

    @Override
    public RestClient.Builder defaultHeader(String name, String value) {
        defaultHeaders.put(name, value);
        return this;
    }

    @Override
    public RestClient.Builder defaultHeaders(Consumer<Map<String, String>> headersConsumer) {
        headersConsumer.accept(defaultHeaders);
        return this;
    }

    @Override
    public RestClient.Builder defaultStatusHandler(
            Predicate<Integer> statusPredicate, Consumer<Integer> handler) {
        statusHandlers.add(new StatusHandler(statusPredicate, handler));
        return this;
    }

    @Override
    public RestClient.Builder apply(Consumer<RestClient.Builder> builderConsumer) {
        builderConsumer.accept(this);
        return this;
    }

    @Override
    public RestClient.Builder server(FakeServer server) {
        this.server = server;
        return this;
    }

    @Override
    public RestClient build() {
        if (server == null) {
            throw new IllegalStateException("No FakeServer configured via Builder.server(...)");
        }
        return new DefaultRestClient(
                server, baseUrl, new LinkedHashMap<>(defaultHeaders), List.copyOf(statusHandlers));
    }
}
