package com.example.fluentapi.email;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EmailBuilder {
    private String from;
    private List<String> to = new ArrayList<>();
    private List<String> cc = new ArrayList<>();
    private List<String> bcc = new ArrayList<>();
    private String subject;
    private String body;
    private Priority priority = Priority.NORMAL;
    private EmailFormat format = EmailFormat.TEXT;
    private List<String> attachments = new ArrayList<>();

    public static EmailBuilder create() {
        return new EmailBuilder();
    }

    public EmailBuilder from(String from) {
        this.from = from;
        return this;
    }

    public EmailBuilder to(String... recipients) {
        this.to.addAll(Arrays.asList(recipients));
        return this;
    }

    public EmailBuilder cc(String... recipients) {
        this.cc.addAll(Arrays.asList(recipients));
        return this;
    }

    public EmailBuilder bcc(String... recipients) {
        this.bcc.addAll(Arrays.asList(recipients));
        return this;
    }

    public EmailBuilder subject(String subject) {
        this.subject = subject;
        return this;
    }

    public EmailBuilder body(String body) {
        this.body = body;
        return this;
    }

    public EmailBuilder withPriority(Priority priority) {
        this.priority = priority;
        return this;
    }

    public EmailBuilder withFormat(EmailFormat format) {
        this.format = format;
        return this;
    }

    public EmailBuilder addAttachment(String attachment) {
        this.attachments.add(attachment);
        return this;
    }

    public Email build() {
        validate();
        return new Email(from, to, cc, bcc, subject, body, priority, format, attachments);
    }

    private void validate() {
        if (from == null || from.trim().isEmpty()) {
            throw new IllegalStateException("From address is required");
        }
        if (to.isEmpty()) {
            throw new IllegalStateException("At least one recipient is required");
        }
        if (subject == null || subject.trim().isEmpty()) {
            throw new IllegalStateException("Subject is required");
        }
    }
}
