package com.example.fluentapi.assertion;

import java.util.Collection;

/** Collection-specific assertions */
public class CollectionAssert {
    private final Collection<?> actual;

    public CollectionAssert(Collection<?> actual) {
        this.actual = actual;
    }

    public CollectionAssert hasSize(int expectedSize) {
        int actualSize = actual != null ? actual.size() : 0;
        if (actualSize != expectedSize) {
            throw new AssertionError("Expected size " + expectedSize + " but was " + actualSize);
        }
        return this;
    }

    public CollectionAssert contains(Object element) {
        if (actual == null || !actual.contains(element)) {
            throw new AssertionError("Expected collection to contain " + element);
        }
        return this;
    }

    public CollectionAssert isEmpty() {
        if (actual == null || !actual.isEmpty()) {
            throw new AssertionError("Expected collection to be empty but was " + actual);
        }
        return this;
    }
}
