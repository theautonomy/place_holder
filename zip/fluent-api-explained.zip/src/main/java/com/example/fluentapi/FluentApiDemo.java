package com.example.fluentapi;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import com.example.fluentapi.assertion.*;
import com.example.fluentapi.cache.*;
import com.example.fluentapi.client.*;
import com.example.fluentapi.config.*;
import com.example.fluentapi.email.*;
import com.example.fluentapi.evolution.*;
import com.example.fluentapi.http.*;
import com.example.fluentapi.order.*;
import com.example.fluentapi.restclient.*;
import com.example.fluentapi.retry.*;
import com.example.fluentapi.sql.*;

/**
 * Comprehensive Fluent API Demonstration in Java
 *
 * <p>This application demonstrates various fluent API patterns including: 1. Order Builder with
 * State Machine (inspired by jOOQ crash course) 2. SQL Query Builder (inspired by jOOQ) 3. Email
 * Builder with validation 4. HTTP Request Builder 5. Configuration DSL
 */
public class FluentApiDemo {

    public static void main(String[] args) {
        System.out.println("=== Fluent API Demonstration ===\n");

        // Original demonstrations
        demonstrateOrderApi();
        demonstrateSqlBuilder();
        demonstrateEmailBuilder();
        demonstrateHttpBuilder();
        demonstrateConfigurationDsl();
        demonstrateDataClient();
        demonstrateRestClient();
        demonstrateRetryPolicy();
        demonstrateCacheClient();
        demonstrateApiEvolution();

        // Advanced demonstrations
        demonstrateAdvancedFluentApi();
        demonstrateMethodChainingVsFluent();

        // Summary and best practices
        printFluentApiBestPractices();
    }

    private static void demonstrateOrderApi() {
        System.out.println("1. ORDER API DEMONSTRATION:");
        System.out.println("-".repeat(30));

        // Fluent order creation following state machine pattern
        Order order =
                OrderApi.startOrder()
                        .withCustomer("John Doe")
                        .addItem("Burger", 2)
                        .withPrice(BigDecimal.valueOf(12.99))
                        .addItem("Fries", 1)
                        .withPrice(BigDecimal.valueOf(4.99))
                        .addDrink("Cola", DrinkSize.LARGE)
                        .withPrice(BigDecimal.valueOf(2.99))
                        .applyDiscount(BigDecimal.valueOf(2.00))
                        .setDelivery()
                        .withAddress("123 Main St")
                        .withDeliveryTime(LocalDateTime.now().plusHours(1))
                        .complete();

        System.out.println(order);
        System.out.println();
    }

    private static void demonstrateSqlBuilder() {
        System.out.println("2. SQL QUERY BUILDER DEMONSTRATION:");
        System.out.println("-".repeat(40));

        // Simple SQL builder with fluent interface
        String query1 =
                SqlBuilder.select("name", "email", "age")
                        .from("users")
                        .where("age")
                        .greaterThan(18)
                        .and("status")
                        .isEqual("active")
                        .orderBy("name")
                        .ascending()
                        .limit(10)
                        .build();

        System.out.println("Query 1: " + query1);

        // Complex query with joins
        String query2 =
                SqlBuilder.select("u.name", "o.total")
                        .from("users u")
                        .innerJoin("orders o")
                        .on("u.id = o.user_id")
                        .where("o.created_date")
                        .greaterThan("2024-01-01")
                        .groupBy("u.name")
                        .having("COUNT(o.id)")
                        .greaterThan("5")
                        .build();

        System.out.println("Query 2: " + query2);
        System.out.println();
    }

    private static void demonstrateEmailBuilder() {
        System.out.println("3. EMAIL BUILDER DEMONSTRATION:");
        System.out.println("-".repeat(35));

        try {
            Email email =
                    EmailBuilder.create()
                            .from("sender@example.com")
                            .to("recipient@example.com")
                            .cc("cc@example.com")
                            .subject("Fluent API Demo")
                            .body("This email was created using a fluent API!")
                            .withPriority(Priority.HIGH)
                            .withFormat(EmailFormat.HTML)
                            .addAttachment("document.pdf")
                            .build();

            System.out.println(email);
        } catch (Exception e) {
            System.out.println("Email validation failed: " + e.getMessage());
        }
        System.out.println();
    }

    private static void demonstrateHttpBuilder() {
        System.out.println("4. HTTP REQUEST BUILDER DEMONSTRATION:");
        System.out.println("-".repeat(45));

        HttpRequest request =
                HttpRequestBuilder.get("https://api.example.com/users")
                        .withHeader("Authorization", "Bearer token123")
                        .withHeader("Content-Type", "application/json")
                        .withQueryParam("page", "1")
                        .withQueryParam("limit", "10")
                        .withTimeout(30)
                        .build();

        System.out.println(request);

        HttpRequest postRequest =
                HttpRequestBuilder.post("https://api.example.com/users")
                        .withJsonBody("{\"name\":\"John\", \"email\":\"john@example.com\"}")
                        .withHeader("Content-Type", "application/json")
                        .build();

        System.out.println(postRequest);
        System.out.println();
    }

    private static void demonstrateConfigurationDsl() {
        System.out.println("5. CONFIGURATION DSL DEMONSTRATION:");
        System.out.println("-".repeat(40));

        AppConfiguration config =
                ConfigurationDsl.configure()
                        .database()
                        .withHost("localhost")
                        .withPort(5432)
                        .withName("myapp")
                        .withCredentials("user", "password")
                        .withConnectionPool(10, 50)
                        .and()
                        .cache()
                        .withProvider("redis")
                        .withHost("cache-server")
                        .withTtl(3600)
                        .and()
                        .logging()
                        .withLevel("INFO")
                        .withFile("/var/log/app.log")
                        .withRotation(true)
                        .build();

        System.out.println(config);
        System.out.println();
    }

    private static void demonstrateDataClient() {
        System.out.println("6. DATA CLIENT DEMONSTRATION:");
        System.out.println("-".repeat(35));

        record Customer(String name, int age) {}

        DataStore store =
                new DataStore()
                        .addTable(
                                "customers",
                                List.of(
                                        Map.<String, Object>of(
                                                "id",
                                                1,
                                                "name",
                                                "Ada Lovelace",
                                                "age",
                                                36,
                                                "city",
                                                "London"),
                                        Map.<String, Object>of(
                                                "id",
                                                2,
                                                "name",
                                                "Alan Turing",
                                                "age",
                                                41,
                                                "city",
                                                "London"),
                                        Map.<String, Object>of(
                                                "id",
                                                3,
                                                "name",
                                                "Grace Hopper",
                                                "age",
                                                85,
                                                "city",
                                                "New York")));

        DataClient client = DataClient.create(store);

        // Terminal fan-out #1: query() -> RowQuerySpec, raw rows
        List<Map<String, Object>> londoners =
                client.sql("customers").param("city", "London").query().list();
        System.out.println("Londoners: " + londoners);

        // Terminal fan-out #2: query(RowMapper) -> MappedQuerySpec<Customer>, same StatementSpec
        // shape
        Optional<Customer> ada =
                client.sql("customers")
                        .param("name", "Ada Lovelace")
                        .query(row -> new Customer((String) row.get("name"), (int) row.get("age")))
                        .optional();
        System.out.println("Ada: " + ada);

        // Terminal fan-out #3: update() -> plain int, no result spec at all
        int updated =
                client.sql("customers")
                        .param("city", "London")
                        .update(Map.of("city", "Greater London"));
        System.out.println("Rows updated: " + updated);

        System.out.println();
    }

    private static void demonstrateRestClient() {
        System.out.println("7. REST CLIENT DEMONSTRATION:");
        System.out.println("-".repeat(35));

        record User(int id, String name) {}

        FakeServer server =
                new FakeServer()
                        .route("GET", "/users/1", 200, new User(1, "Ada Lovelace"))
                        .route("POST", "/users", 201, new User(2, "Alan Turing"));

        // Consumer<Builder>: a reusable "recipe" bundling several builder calls into one unit,
        // the same role RestClient.Builder.apply(Consumer<Builder>) plays in the original
        Consumer<RestClient.Builder> withTracingAndErrorLogging =
                builder ->
                        builder
                                // Consumer<Map<String, String>>: bulk edit on the live headers map,
                                // instead of one defaultHeader(name, value) call per header
                                .defaultHeaders(
                                        headers -> {
                                            headers.put("X-Trace-Id", "trace-999");
                                            headers.put("X-Client", "fluent-api-demo");
                                        })
                                // Predicate<Integer> + Consumer<Integer>: a rule stored now,
                                // evaluated later against a real response status code
                                .defaultStatusHandler(
                                        status -> status >= 400,
                                        status ->
                                                System.out.println(
                                                        "  status handler fired for " + status));

        RestClient client =
                RestClient.builder() // -> Builder
                        .baseUrl("https://api.example.com") // Builder
                        .defaultHeader("Accept", "application/json") // Builder
                        .server(server) // Builder
                        .apply(withTracingAndErrorLogging) // Builder, recipe runs against this
                        .build(); // -> RestClient

        // get() -> RequestHeadersUriSpec<?>: .body(...) isn't visible on this declared type
        User fetched =
                client.get()
                        .uri("/users/1")
                        .header("X-Trace-Id", "abc-123")
                        .retrieve()
                        .body(User.class);
        System.out.println("Fetched: " + fetched);

        // post() -> RequestBodyUriSpec: same chain shape, plus .body(...)
        User created =
                client.post()
                        .uri("/users")
                        .header("Content-Type", "application/json")
                        .body(new User(0, "Alan Turing"))
                        .retrieve()
                        .body(User.class);
        System.out.println("Created: " + created);

        // No route registered -> FakeServer's default 404 -> the defaultStatusHandler above fires
        User missing = client.get().uri("/missing").retrieve().body(User.class);
        System.out.println("Missing: " + missing);

        System.out.println();
    }

    private static void demonstrateRetryPolicy() {
        System.out.println("8. RETRY POLICY DEMONSTRATION:");
        System.out.println("-".repeat(35));

        // Case 1: transient failures, then success -- real Thread.sleep, real backoff, real retries
        AtomicInteger attempts = new AtomicInteger();
        RetryPolicy flaky =
                RetryPolicyBuilder.create()
                        .maxAttempts(5)
                        .initialDelay(Duration.ofMillis(10))
                        .backoffMultiplier(2.0)
                        .retryOn(IOException.class)
                        .onRetry(
                                attempt ->
                                        System.out.println(
                                                "  attempt "
                                                        + attempt.attemptNumber()
                                                        + "/"
                                                        + attempt.maxAttempts()
                                                        + " failed ("
                                                        + attempt.failure().getMessage()
                                                        + "), retrying after "
                                                        + attempt.nextDelay().toMillis()
                                                        + "ms"))
                        .build();

        try {
            String result =
                    flaky.execute(
                            () -> {
                                if (attempts.incrementAndGet() <= 2) {
                                    throw new IOException(
                                            "connection reset (attempt " + attempts.get() + ")");
                                }
                                return "connected on attempt " + attempts.get();
                            });
            System.out.println("Result: " + result);
        } catch (Exception e) {
            System.out.println("Gave up: " + e.getMessage());
        }

        // Case 2: every attempt fails -> retries are exhausted and the last failure propagates
        RetryPolicy alwaysFails =
                RetryPolicyBuilder.create()
                        .maxAttempts(3)
                        .initialDelay(Duration.ofMillis(5))
                        .retryOn(IOException.class)
                        .onRetry(
                                attempt ->
                                        System.out.println(
                                                "  attempt "
                                                        + attempt.attemptNumber()
                                                        + "/"
                                                        + attempt.maxAttempts()
                                                        + " failed, retrying"))
                        .build();

        try {
            alwaysFails.execute(
                    () -> {
                        throw new IOException("service unavailable");
                    });
        } catch (Exception e) {
            System.out.println("Gave up after exhausting retries: " + e.getMessage());
        }

        // Case 3: exception type outside retryOn(...) is not retried at all -- fails on attempt 1
        RetryPolicy scoped =
                RetryPolicyBuilder.create()
                        .maxAttempts(5)
                        .retryOn(IOException.class)
                        .onRetry(attempt -> System.out.println("  (should not print) retrying..."))
                        .build();

        try {
            scoped.execute(
                    () -> {
                        throw new IllegalStateException("not a retryable exception type");
                    });
        } catch (Exception e) {
            System.out.println("Failed immediately, no retries: " + e.getMessage());
        }

        System.out.println();
    }

    private static void demonstrateCacheClient() {
        System.out.println("9. CACHE CLIENT DEMONSTRATION:");
        System.out.println("-".repeat(35));

        CacheClient cache = CacheClient.create();

        // put() -> ValueOperationSpec: key() first (like restclient's .uri() before .header()),
        // then region()/value()/ttl(), all available
        Optional<Object> previous =
                cache.put()
                        .key("42")
                        .region("users")
                        .value("Ada Lovelace")
                        .ttl(Duration.ofMillis(50))
                        .execute();
        System.out.println("Previous value for users:42: " + previous);

        // get() -> KeyOperationSpec<?>: .value(...)/.ttl(...) aren't visible on this declared type
        Optional<String> fetched = cache.get().key("42").region("users").execute(String.class);
        System.out.println("Fetched right away: " + fetched);

        try {
            Thread.sleep(60); // real wait, past the 50ms TTL set above
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        }

        // real lazy expiry: the entry is gone because the clock really moved past its TTL
        Optional<String> expired = cache.get().key("42").region("users").execute(String.class);
        System.out.println("Fetched after TTL expiry: " + expired);

        // put() again reports whatever value it replaced
        cache.put().key("counter").value(1).execute();
        Optional<Object> replaced = cache.put().key("counter").value(2).execute();
        System.out.println("Replaced counter, previous was: " + replaced);

        // evict() -> KeyOperationSpec<?>: removes and returns whatever was stored
        Optional<Object> evicted = cache.evict().key("counter").execute();
        System.out.println("Evicted counter, was: " + evicted);
        System.out.println("Evict again (already gone): " + cache.evict().key("counter").execute());

        System.out.println();
    }

    private static void demonstrateApiEvolution() {
        System.out.println("10. API EVOLUTION FROM REAL USAGE DEMONSTRATION:");
        System.out.println("-".repeat(50));

        // Step 1: what got observed in the wild against v1 (conference demos, GitHub scans, ...)
        List<String> observedV1Usage =
                List.of(
                        "client.uri(\"/users/1\").retrieve()",
                        "client.uri(\"/orders\").retrieve()",
                        "client.uri(\"\").retrieve()",
                        "client.uri(\"\").retrieve()");

        long awkwardCount =
                observedV1Usage.stream().filter(snippet -> snippet.contains("uri(\"\")")).count();
        System.out.println(
                "Observed "
                        + observedV1Usage.size()
                        + " real call sites against v1; "
                        + awkwardCount
                        + " of them pass uri(\"\") just to satisfy the type system.");

        // Step 2: v1 requires uri(...) even when there's nothing to add to the base URL
        SimpleClientV1 v1 = SimpleClientV1.create("https://api.example.com");
        String v1Result =
                v1.uri("").retrieve(); // the awkward workaround itself, exercised for real
        System.out.println("v1 (forced workaround): " + v1Result);

        // Step 3: v2 responds to that friction by making uri(...) optional
        SimpleClientV2 v2 = SimpleClientV2.create("https://api.example.com");
        String v2Result = v2.retrieve(); // no uri(...) call needed at all
        System.out.println("v2 (uri() now optional): " + v2Result);

        System.out.println("Same result, no workaround needed: " + v1Result.equals(v2Result));

        System.out.println();
    }

    private static void demonstrateAdvancedFluentApi() {
        System.out.println("11. ADVANCED FLUENT ASSERTION API:");
        System.out.println("-".repeat(45));

        try {
            // String assertions
            FluentAssert.assertThat("Hello World")
                    .isNotNull()
                    .asString()
                    .contains("World")
                    .startsWith("Hello")
                    .hasLength(11);

            // Number assertions
            FluentAssert.assertThat(42)
                    .isNotNull()
                    .asNumber()
                    .isGreaterThan(0)
                    .isLessThan(100)
                    .isBetween(40, 50);

            // Collection assertions
            List<String> names = Arrays.asList("Alice", "Bob", "Charlie");
            FluentAssert.assertThat(names).isNotNull().asCollection().hasSize(3).contains("Bob");

            System.out.println("All assertions passed!");

        } catch (AssertionError e) {
            System.out.println("Assertion failed: " + e.getMessage());
        }
        System.out.println();
    }

    private static void demonstrateMethodChainingVsFluent() {
        System.out.println("12. METHOD CHAINING vs FLUENT INTERFACE:");
        System.out.println("-".repeat(50));

        // Simple method chaining (like StringBuilder)
        StringBuilder sb =
                new StringBuilder().append("Hello").append(" ").append("World").append("!");
        System.out.println("Method Chaining Result: " + sb.toString());

        // True fluent interface with state transitions and validation
        try {
            Order validOrder =
                    OrderApi.startOrder()
                            .withCustomer("Jane Doe")
                            .addItem("Pizza", 1)
                            .withPrice(BigDecimal.valueOf(15.99))
                            .setDelivery()
                            .withAddress("456 Oak Ave")
                            .withDeliveryTime(LocalDateTime.now().plusMinutes(30))
                            .complete();

            System.out.println("Fluent Interface - Valid Order Created");

        } catch (Exception e) {
            System.out.println("Order creation failed: " + e.getMessage());
        }
        System.out.println();
    }

    private static void printFluentApiBestPractices() {
        System.out.println("13. FLUENT API BEST PRACTICES:");
        System.out.println("-".repeat(35));
        System.out.println("✓ Use interfaces to define state transitions");
        System.out.println("✓ Provide compile-time safety through type system");
        System.out.println("✓ Make invalid states unrepresentable");
        System.out.println("✓ Use method names that read like natural language");
        System.out.println("✓ Validate parameters early (fail-fast principle)");
        System.out.println("✓ Return appropriate types for method chaining");
        System.out.println("✓ Consider using static factory methods as entry points");
        System.out.println("✓ Document the expected flow and provide examples");
        System.out.println("✓ Balance expressiveness with implementation complexity");
        System.out.println("✓ Use fluent APIs for complex domain-specific operations");
        System.out.println("\n=== DEMONSTRATION COMPLETE ===");
    }
}
