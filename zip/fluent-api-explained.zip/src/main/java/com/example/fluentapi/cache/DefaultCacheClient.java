package com.example.fluentapi.cache;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

final class DefaultCacheClient implements CacheClient {

    private final Map<String, CacheEntry> store = new ConcurrentHashMap<>();

    @Override
    public KeyOperationSpec<?> get() {
        return new DefaultOperationSpec(Operation.GET);
    }

    @Override
    public KeyOperationSpec<?> evict() {
        return new DefaultOperationSpec(Operation.EVICT);
    }

    @Override
    public ValueOperationSpec put() {
        return new DefaultOperationSpec(Operation.PUT);
    }

    private enum Operation {
        GET,
        PUT,
        EVICT
    }

    /**
     * The single implementation behind every verb, same idea as {@code restclient}'s {@code
     * DefaultRequestBodyUriSpec}: {@code get()}/{@code evict()} hand out a reference to this same
     * class typed as {@link KeyOperationSpec}, so {@code value(...)}/{@code ttl(...)} don't compile
     * from there.
     */
    private final class DefaultOperationSpec implements ValueOperationSpec {
        private final Operation operation;
        private String key;
        private String region;
        private Object value;
        private Duration ttl;

        DefaultOperationSpec(Operation operation) {
            this.operation = operation;
        }

        @Override
        public ValueOperationSpec key(String key) {
            this.key = key;
            return this;
        }

        @Override
        public ValueOperationSpec region(String region) {
            this.region = region;
            return this;
        }

        @Override
        public ValueOperationSpec value(Object value) {
            this.value = value;
            return this;
        }

        @Override
        public ValueOperationSpec ttl(Duration ttl) {
            this.ttl = ttl;
            return this;
        }

        @Override
        public Optional<Object> execute() {
            if (key == null) {
                throw new IllegalStateException("key(...) must be called before execute()");
            }
            String namespacedKey = region == null ? key : region + ":" + key;
            return switch (operation) {
                case GET -> currentValue(namespacedKey);
                case EVICT -> {
                    Optional<Object> existing = currentValue(namespacedKey);
                    store.remove(namespacedKey);
                    yield existing;
                }
                case PUT -> {
                    Optional<Object> previous = currentValue(namespacedKey);
                    Instant expiresAt = ttl == null ? null : Instant.now().plus(ttl);
                    store.put(namespacedKey, new CacheEntry(value, expiresAt));
                    yield previous;
                }
            };
        }

        @Override
        public <T> Optional<T> execute(Class<T> type) {
            return execute().map(type::cast);
        }

        private Optional<Object> currentValue(String namespacedKey) {
            CacheEntry entry = store.get(namespacedKey);
            if (entry == null) {
                return Optional.empty();
            }
            if (entry.isExpired()) {
                store.remove(namespacedKey); // real lazy expiry, not a simulated one
                return Optional.empty();
            }
            return Optional.of(entry.value());
        }
    }

    private record CacheEntry(Object value, Instant expiresAt) {
        boolean isExpired() {
            return expiresAt != null && Instant.now().isAfter(expiresAt);
        }
    }
}
