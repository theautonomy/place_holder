package com.example.fluentapi.config;

public class AppConfiguration {
    private final DatabaseConfig databaseConfig;
    private final CacheConfig cacheConfig;
    private final LoggingConfig loggingConfig;

    public AppConfiguration(
            DatabaseConfig databaseConfig, CacheConfig cacheConfig, LoggingConfig loggingConfig) {
        this.databaseConfig = databaseConfig;
        this.cacheConfig = cacheConfig;
        this.loggingConfig = loggingConfig;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Application Configuration:\n");
        if (databaseConfig != null) sb.append(databaseConfig).append("\n");
        if (cacheConfig != null) sb.append(cacheConfig).append("\n");
        if (loggingConfig != null) sb.append(loggingConfig);
        return sb.toString();
    }
}
