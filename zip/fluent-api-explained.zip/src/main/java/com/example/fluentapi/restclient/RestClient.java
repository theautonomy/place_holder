package com.example.fluentapi.restclient;

import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * A fluent facade modeled on Spring Framework's {@code RestClient}: verb methods ({@code get()},
 * {@code post()}, ...) return a spec type whose *compile-time* shape depends on which verb was
 * called, even though a single implementation class backs all of them underneath.
 *
 * <p>{@code get()}/{@code delete()} return {@link RequestHeadersUriSpec}, which has no {@code
 * body(...)} method. {@code post()}/{@code put()} return {@link RequestBodyUriSpec}, which adds
 * one. The restriction is enforced entirely by self-bounded generic interfaces (F-bounded
 * polymorphism) and multiple interface inheritance — no runtime type check, no exception thrown for
 * calling the "wrong" method, because that method simply isn't visible on the declared type.
 */
public interface RestClient {

    RequestHeadersUriSpec<?> get();

    RequestHeadersUriSpec<?> delete();

    RequestBodyUriSpec post();

    RequestBodyUriSpec put();

    static Builder builder() {
        return new DefaultRestClientBuilder();
    }

    /** A mutable builder for creating a {@link RestClient}. */
    interface Builder {
        Builder baseUrl(String baseUrl);

        Builder defaultHeader(String name, String value);

        /**
         * Provide a consumer with direct access to the live, mutable default-headers map, so
         * several headers can be added, replaced, or removed in one call instead of one {@link
         * #defaultHeader(String, String)} call per header.
         */
        Builder defaultHeaders(Consumer<Map<String, String>> headersConsumer);

        /**
         * Register a status predicate and a callback to run when a response's status code matches.
         * The predicate isn't tested now — it's stored and evaluated later, once a real response
         * status is available, the same way {@code RestClient}'s real {@code
         * defaultStatusHandler(Predicate, ErrorHandler)} does.
         *
         * <p><strong>Unlike the real {@code ErrorHandler}, {@code handler} cannot abort or
         * transform anything</strong> — it's a plain {@code Consumer}, so it can only observe the
         * matched status code (e.g. log it). {@code retrieve()} and {@code body(...)} proceed
         * normally afterward regardless of what {@code handler} does.
         */
        Builder defaultStatusHandler(Predicate<Integer> statusPredicate, Consumer<Integer> handler);

        /**
         * Apply a pre-packaged bundle of customizations to this builder in one step — a {@code
         * Consumer<Builder>} lets several other {@code Builder} calls be written once and reused,
         * the same role {@code RestClient.Builder.apply(Consumer<Builder>)} plays in the original.
         */
        Builder apply(Consumer<Builder> builderConsumer);

        Builder server(FakeServer server);

        RestClient build();
    }

    /**
     * Contract for specifying the URI of a request.
     *
     * @param <S> a self reference to the spec type to return to after the URI is set
     */
    interface UriSpec<S extends RequestHeadersSpec<?>> {
        S uri(String path);
    }

    /**
     * Contract for specifying request headers leading up to the exchange.
     *
     * @param <S> a self reference to the spec type, so header methods keep returning the same
     *     (possibly body-capable) type they started from
     */
    interface RequestHeadersSpec<S extends RequestHeadersSpec<S>> {
        S header(String name, String value);

        ResponseSpec retrieve();
    }

    /** Contract for specifying request headers and a body leading up to the exchange. */
    interface RequestBodySpec extends RequestHeadersSpec<RequestBodySpec> {
        RequestBodySpec body(Object body);
    }

    /** Contract for specifying the URI and headers of a request that has no body (GET, DELETE). */
    interface RequestHeadersUriSpec<S extends RequestHeadersSpec<S>>
            extends UriSpec<S>, RequestHeadersSpec<S> {}

    /** Contract for specifying the URI, headers, and body of a request (POST, PUT). */
    interface RequestBodyUriSpec extends RequestBodySpec, RequestHeadersUriSpec<RequestBodySpec> {}

    /** Terminal spec for extracting a response body. */
    interface ResponseSpec {
        <T> T body(Class<T> bodyType);

        int statusCode();
    }
}
