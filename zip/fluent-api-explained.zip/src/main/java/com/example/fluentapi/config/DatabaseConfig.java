package com.example.fluentapi.config;

public record DatabaseConfig(
        String host,
        int port,
        String name,
        String username,
        String password,
        int minConnections,
        int maxConnections) {

    @Override
    public String toString() {
        return String.format(
                "Database{host='%s', port=%d, name='%s', pool=%d-%d}",
                host, port, name, minConnections, maxConnections);
    }
}
