package com.example.fluentapi.assertion;

/** Main entry point for fluent assertions */
public class FluentAssert {
    public static <T> AssertThat<T> assertThat(T actual) {
        return new AssertThat<>(actual);
    }
}
