package com.example.fluentapi.email;

public enum Priority {
    LOW,
    NORMAL,
    HIGH
}
