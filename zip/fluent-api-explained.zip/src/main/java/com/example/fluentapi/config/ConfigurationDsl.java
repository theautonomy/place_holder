package com.example.fluentapi.config;

public class ConfigurationDsl {
    public static ConfigurationBuilder configure() {
        return new ConfigurationBuilder();
    }
}
