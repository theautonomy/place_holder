package com.example.fluentapi.retry;

import java.time.Duration;

/** Emitted via {@code onRetry} each time an attempt fails but another attempt will follow. */
public record RetryAttempt(
        int attemptNumber, int maxAttempts, Duration nextDelay, Exception failure) {}
