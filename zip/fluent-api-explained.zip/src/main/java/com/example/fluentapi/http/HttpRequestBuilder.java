package com.example.fluentapi.http;

import java.util.HashMap;
import java.util.Map;

public class HttpRequestBuilder {
    private String method;
    private String url;
    private Map<String, String> headers = new HashMap<>();
    private Map<String, String> queryParams = new HashMap<>();
    private String body;
    private int timeout = 30;

    public static HttpRequestBuilder get(String url) {
        HttpRequestBuilder builder = new HttpRequestBuilder();
        builder.method = "GET";
        builder.url = url;
        return builder;
    }

    public static HttpRequestBuilder post(String url) {
        HttpRequestBuilder builder = new HttpRequestBuilder();
        builder.method = "POST";
        builder.url = url;
        return builder;
    }

    public static HttpRequestBuilder put(String url) {
        HttpRequestBuilder builder = new HttpRequestBuilder();
        builder.method = "PUT";
        builder.url = url;
        return builder;
    }

    public static HttpRequestBuilder delete(String url) {
        HttpRequestBuilder builder = new HttpRequestBuilder();
        builder.method = "DELETE";
        builder.url = url;
        return builder;
    }

    public HttpRequestBuilder withHeader(String name, String value) {
        this.headers.put(name, value);
        return this;
    }

    public HttpRequestBuilder withQueryParam(String name, String value) {
        this.queryParams.put(name, value);
        return this;
    }

    public HttpRequestBuilder withJsonBody(String json) {
        this.body = json;
        return withHeader("Content-Type", "application/json");
    }

    public HttpRequestBuilder withTimeout(int timeoutSeconds) {
        this.timeout = timeoutSeconds;
        return this;
    }

    public HttpRequest build() {
        return new HttpRequest(method, url, headers, queryParams, body, timeout);
    }
}
