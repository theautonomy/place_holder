package com.example.fluentapi.http;

import java.util.HashMap;
import java.util.Map;

public record HttpRequest(
        String method,
        String url,
        Map<String, String> headers,
        Map<String, String> queryParams,
        String body,
        int timeout) {

    /** Compact constructor to ensure defensive copying of mutable maps */
    public HttpRequest {
        headers = new HashMap<>(headers);
        queryParams = new HashMap<>(queryParams);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(method).append(" ").append(url);
        if (!queryParams.isEmpty()) {
            sb.append("?");
            queryParams
                    .entrySet()
                    .forEach(
                            e ->
                                    sb.append(e.getKey())
                                            .append("=")
                                            .append(e.getValue())
                                            .append("&"));
            sb.setLength(sb.length() - 1); // Remove last &
        }
        sb.append("\nHeaders: ").append(headers);
        if (body != null) {
            sb.append("\nBody: ").append(body);
        }
        sb.append("\nTimeout: ").append(timeout).append("s");
        return sb.toString();
    }
}
