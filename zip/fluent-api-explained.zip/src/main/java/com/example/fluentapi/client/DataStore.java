package com.example.fluentapi.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * A tiny in-memory stand-in for a database: named tables, each a list of rows, where a row is just
 * a {@code Map<String, Object>} of column name to value.
 */
public final class DataStore {
    private final Map<String, List<Map<String, Object>>> tables = new HashMap<>();

    public DataStore addTable(String name, List<Map<String, Object>> rows) {
        tables.put(
                name,
                rows.stream()
                        .map(LinkedHashMap::new)
                        .collect(Collectors.toCollection(ArrayList::new)));
        return this;
    }

    List<Map<String, Object>> rowsOf(String table) {
        List<Map<String, Object>> rows = tables.get(table);
        if (rows == null) {
            throw new IllegalArgumentException("No such table: " + table);
        }
        return rows;
    }

    int update(String table, Map<String, Object> where, Map<String, Object> changes) {
        int count = 0;
        for (Map<String, Object> row : rowsOf(table)) {
            if (matches(row, where)) {
                row.putAll(changes);
                count++;
            }
        }
        return count;
    }

    static boolean matches(Map<String, Object> row, Map<String, Object> criteria) {
        for (Map.Entry<String, Object> entry : criteria.entrySet()) {
            if (!Objects.equals(row.get(entry.getKey()), entry.getValue())) {
                return false;
            }
        }
        return true;
    }
}
