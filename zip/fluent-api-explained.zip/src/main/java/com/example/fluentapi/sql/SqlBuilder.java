package com.example.fluentapi.sql;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SqlBuilder {
    private List<String> selectColumns = new ArrayList<>();
    private String fromTable;
    private List<String> joins = new ArrayList<>();
    private List<String> whereConditions = new ArrayList<>();
    private List<String> groupByColumns = new ArrayList<>();
    private List<String> havingConditions = new ArrayList<>();
    private List<String> orderByColumns = new ArrayList<>();
    private Integer limitValue;

    public static SqlBuilder select(String... columns) {
        SqlBuilder builder = new SqlBuilder();
        builder.selectColumns.addAll(Arrays.asList(columns));
        return builder;
    }

    public SqlBuilder from(String table) {
        this.fromTable = table;
        return this;
    }

    public SqlBuilder innerJoin(String table) {
        return join("INNER JOIN", table);
    }

    public SqlBuilder leftJoin(String table) {
        return join("LEFT JOIN", table);
    }

    private SqlBuilder join(String joinType, String table) {
        this.joins.add(joinType + " " + table);
        return this;
    }

    public SqlBuilder on(String condition) {
        if (!joins.isEmpty()) {
            int lastIndex = joins.size() - 1;
            joins.set(lastIndex, joins.get(lastIndex) + " ON " + condition);
        }
        return this;
    }

    public WhereCondition where(String column) {
        return new WhereCondition(this, column, false);
    }

    public WhereCondition and(String column) {
        return new WhereCondition(this, column, true);
    }

    public WhereCondition or(String column) {
        return new WhereCondition(this, column, true, "OR");
    }

    public SqlBuilder groupBy(String... columns) {
        this.groupByColumns.addAll(Arrays.asList(columns));
        return this;
    }

    public HavingCondition having(String column) {
        return new HavingCondition(this, column);
    }

    public OrderByClause orderBy(String column) {
        return new OrderByClause(this, column);
    }

    public SqlBuilder limit(int limit) {
        this.limitValue = limit;
        return this;
    }

    public String build() {
        StringBuilder sql = new StringBuilder();

        // SELECT
        sql.append("SELECT ").append(String.join(", ", selectColumns));

        // FROM
        if (fromTable != null) {
            sql.append(" FROM ").append(fromTable);
        }

        // JOINS
        for (String join : joins) {
            sql.append(" ").append(join);
        }

        // WHERE
        if (!whereConditions.isEmpty()) {
            sql.append(" WHERE ").append(String.join(" ", whereConditions));
        }

        // GROUP BY
        if (!groupByColumns.isEmpty()) {
            sql.append(" GROUP BY ").append(String.join(", ", groupByColumns));
        }

        // HAVING
        if (!havingConditions.isEmpty()) {
            sql.append(" HAVING ").append(String.join(" AND ", havingConditions));
        }

        // ORDER BY
        if (!orderByColumns.isEmpty()) {
            sql.append(" ORDER BY ").append(String.join(", ", orderByColumns));
        }

        // LIMIT
        if (limitValue != null) {
            sql.append(" LIMIT ").append(limitValue);
        }

        return sql.toString();
    }

    void addWhereCondition(String condition, boolean useConnector, String connector) {
        if (useConnector && !whereConditions.isEmpty()) {
            whereConditions.add(connector != null ? connector : "AND");
        }
        whereConditions.add(condition);
    }

    void addHavingCondition(String condition) {
        havingConditions.add(condition);
    }

    void addOrderBy(String column, String direction) {
        orderByColumns.add(column + " " + direction);
    }
}
