package com.example.fluentapi.config;

public record CacheConfig(String provider, String host, int ttl) {

    @Override
    public String toString() {
        return String.format("Cache{provider='%s', host='%s', ttl=%d}", provider, host, ttl);
    }
}
