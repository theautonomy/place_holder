package com.example.fluentapi.retry;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/**
 * Classic single-class builder for {@link RetryPolicy} — every {@code withX}-style setter returns
 * {@code this}.
 */
public final class RetryPolicyBuilder {
    private int maxAttempts = 3;
    private Duration initialDelay = Duration.ofMillis(100);
    private double backoffMultiplier = 2.0;
    private Duration maxDelay = Duration.ofSeconds(10);
    private final List<Class<? extends Exception>> retryableExceptions = new ArrayList<>();
    private Consumer<RetryAttempt> onRetry = attempt -> {};

    private RetryPolicyBuilder() {}

    public static RetryPolicyBuilder create() {
        return new RetryPolicyBuilder();
    }

    public RetryPolicyBuilder maxAttempts(int maxAttempts) {
        if (maxAttempts < 1) {
            throw new IllegalArgumentException("maxAttempts must be at least 1");
        }
        this.maxAttempts = maxAttempts;
        return this;
    }

    public RetryPolicyBuilder initialDelay(Duration initialDelay) {
        this.initialDelay = initialDelay;
        return this;
    }

    public RetryPolicyBuilder backoffMultiplier(double backoffMultiplier) {
        this.backoffMultiplier = backoffMultiplier;
        return this;
    }

    public RetryPolicyBuilder maxDelay(Duration maxDelay) {
        this.maxDelay = maxDelay;
        return this;
    }

    @SafeVarargs
    public final RetryPolicyBuilder retryOn(Class<? extends Exception>... exceptionTypes) {
        retryableExceptions.addAll(Arrays.asList(exceptionTypes));
        return this;
    }

    public RetryPolicyBuilder onRetry(Consumer<RetryAttempt> onRetry) {
        this.onRetry = onRetry;
        return this;
    }

    public RetryPolicy build() {
        return new RetryPolicy(
                maxAttempts,
                initialDelay,
                backoffMultiplier,
                maxDelay,
                retryableExceptions,
                onRetry);
    }
}
