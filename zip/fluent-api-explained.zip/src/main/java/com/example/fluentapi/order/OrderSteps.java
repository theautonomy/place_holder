package com.example.fluentapi.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public interface OrderSteps {
    // Item operations
    OrderSteps addItem(String itemName, int quantity);

    OrderSteps addDrink(String drinkName, DrinkSize size);

    OrderSteps withPrice(BigDecimal price);

    // Delivery/Pickup
    OrderSteps setDelivery();

    OrderSteps setPickup();

    OrderSteps withAddress(String address);

    OrderSteps withDeliveryTime(LocalDateTime time);

    OrderSteps withPickupTime(LocalDateTime time);

    // Discount and completion
    OrderSteps applyDiscount(BigDecimal discount);

    Order complete();
}
