package com.example.fluentapi.restclient;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class DefaultRestClient implements RestClient {

    private final FakeServer server;
    private final String baseUrl;
    private final Map<String, String> defaultHeaders;
    private final List<StatusHandler> statusHandlers;

    DefaultRestClient(
            FakeServer server,
            String baseUrl,
            Map<String, String> defaultHeaders,
            List<StatusHandler> statusHandlers) {
        this.server = server;
        this.baseUrl = baseUrl;
        this.defaultHeaders = defaultHeaders;
        this.statusHandlers = statusHandlers;
    }

    @Override
    public RequestHeadersUriSpec<?> get() {
        return new DefaultRequestBodyUriSpec("GET");
    }

    @Override
    public RequestHeadersUriSpec<?> delete() {
        return new DefaultRequestBodyUriSpec("DELETE");
    }

    @Override
    public RequestBodyUriSpec post() {
        return new DefaultRequestBodyUriSpec("POST");
    }

    @Override
    public RequestBodyUriSpec put() {
        return new DefaultRequestBodyUriSpec("PUT");
    }

    /**
     * The single implementation behind every verb. {@code get()}/{@code delete()} hand out a
     * reference to this same class typed as {@link RequestHeadersUriSpec}, so {@code body(...)}
     * doesn't compile from there — not because it would fail at runtime, but because the declared
     * type simply doesn't expose it.
     */
    private final class DefaultRequestBodyUriSpec implements RequestBodyUriSpec {
        private final String method;
        private String path = "";
        private final Map<String, String> headers = new LinkedHashMap<>(defaultHeaders);
        private Object body;

        DefaultRequestBodyUriSpec(String method) {
            this.method = method;
        }

        @Override
        public RequestBodyUriSpec uri(String path) {
            this.path = path;
            return this;
        }

        @Override
        public RequestBodyUriSpec header(String name, String value) {
            headers.put(name, value);
            return this;
        }

        @Override
        public RequestBodyUriSpec body(Object body) {
            this.body = body;
            return this;
        }

        @Override
        public ResponseSpec retrieve() {
            FakeServer.Response response = server.handle(method, path);
            for (StatusHandler statusHandler : statusHandlers) {
                if (statusHandler.predicate().test(response.statusCode())) {
                    statusHandler.handler().accept(response.statusCode());
                    break;
                }
            }
            return new DefaultResponseSpec(response);
        }
    }

    private static final class DefaultResponseSpec implements ResponseSpec {
        private final FakeServer.Response response;

        DefaultResponseSpec(FakeServer.Response response) {
            this.response = response;
        }

        @Override
        public <T> T body(Class<T> bodyType) {
            return response.body() == null ? null : bodyType.cast(response.body());
        }

        @Override
        public int statusCode() {
            return response.statusCode();
        }
    }
}
