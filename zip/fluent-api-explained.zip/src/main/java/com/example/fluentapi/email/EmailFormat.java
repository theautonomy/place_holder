package com.example.fluentapi.email;

public enum EmailFormat {
    TEXT,
    HTML
}
