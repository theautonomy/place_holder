package com.example.fluentapi.evolution;

/**
 * Version 1 of a tiny fluent client, modeled on the shape of an early {@code WebClient}: {@code
 * uri(...)} is required before any request can be sent, even when the base URL alone is already a
 * complete target. See {@link SimpleClientV2} for the fix that came from watching real usage.
 */
public final class SimpleClientV1 {
    private final String baseUrl;

    private SimpleClientV1(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public static SimpleClientV1 create(String baseUrl) {
        return new SimpleClientV1(baseUrl);
    }

    public Request uri(String path) {
        return new Request(baseUrl + path);
    }

    public static final class Request {
        private final String url;

        private Request(String url) {
            this.url = url;
        }

        public String retrieve() {
            return "response from " + url;
        }
    }
}
