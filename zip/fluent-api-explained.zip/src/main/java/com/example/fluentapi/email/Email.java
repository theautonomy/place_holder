package com.example.fluentapi.email;

import java.util.ArrayList;
import java.util.List;

public record Email(
        String from,
        List<String> to,
        List<String> cc,
        List<String> bcc,
        String subject,
        String body,
        Priority priority,
        EmailFormat format,
        List<String> attachments) {

    /** Compact constructor to ensure defensive copying of mutable lists */
    public Email {
        to = new ArrayList<>(to);
        cc = new ArrayList<>(cc);
        bcc = new ArrayList<>(bcc);
        attachments = new ArrayList<>(attachments);
    }

    @Override
    public String toString() {
        return String.format(
                "Email{from='%s', to=%s, subject='%s', priority=%s, format=%s, attachments=%d}",
                from, to, subject, priority, format, attachments.size());
    }
}
