package com.example.fluentapi.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public record Order(
        String customer,
        List<OrderItem> items,
        String deliveryAddress,
        LocalDateTime deliveryTime,
        LocalDateTime pickupTime,
        BigDecimal discount) {

    /** Compact constructor to ensure defensive copying of mutable list */
    public Order {
        items = new ArrayList<>(items);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Order for: ").append(customer).append("\n");
        sb.append("Items:\n");
        BigDecimal total = BigDecimal.ZERO;
        for (OrderItem item : items) {
            sb.append("  - ").append(item).append("\n");
            total = total.add(item.getTotal());
        }
        total = total.subtract(discount);
        sb.append("Discount: $").append(discount).append("\n");
        sb.append("Total: $").append(total).append("\n");
        if (deliveryAddress != null) {
            sb.append("Delivery to: ").append(deliveryAddress);
            if (deliveryTime != null) {
                sb.append(" at ").append(deliveryTime);
            }
        } else if (pickupTime != null) {
            sb.append("Pickup at: ").append(pickupTime);
        }
        return sb.toString();
    }
}
