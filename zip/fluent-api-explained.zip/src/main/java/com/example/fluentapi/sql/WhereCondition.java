package com.example.fluentapi.sql;

public class WhereCondition {
    private final SqlBuilder builder;
    private final String column;
    private final boolean useConnector;
    private final String connector;

    public WhereCondition(SqlBuilder builder, String column, boolean useConnector) {
        this(builder, column, useConnector, null);
    }

    public WhereCondition(
            SqlBuilder builder, String column, boolean useConnector, String connector) {
        this.builder = builder;
        this.column = column;
        this.useConnector = useConnector;
        this.connector = connector;
    }

    public SqlBuilder isEqual(Object value) {
        return addCondition("= " + formatValue(value));
    }

    public SqlBuilder greaterThan(Object value) {
        return addCondition("> " + formatValue(value));
    }

    public SqlBuilder lessThan(Object value) {
        return addCondition("< " + formatValue(value));
    }

    private SqlBuilder addCondition(String condition) {
        builder.addWhereCondition(column + " " + condition, useConnector, connector);
        return builder;
    }

    private String formatValue(Object value) {
        if (value == null) {
            return "NULL";
        }
        if (value instanceof String) {
            return "'" + value + "'";
        }
        return value.toString();
    }
}
