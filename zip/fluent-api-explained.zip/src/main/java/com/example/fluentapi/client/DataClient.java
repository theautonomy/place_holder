package com.example.fluentapi.client;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * A fluent facade over {@link DataStore}, modeled on Spring Framework's {@code JdbcClient}: a
 * single {@code sql(...)} entry point returns a {@link StatementSpec} that accumulates parameter
 * bindings, and the terminal call ({@code query()}, {@code query(RowMapper)}, or {@code
 * update(...)}) fans out into whichever result-shaped spec matches what was actually asked for.
 */
public interface DataClient {

    StatementSpec sql(String table);

    static DataClient create(DataStore dataStore) {
        return new DefaultDataClient(dataStore);
    }

    /** Accumulates parameter bindings, then hands off to a terminal spec. */
    interface StatementSpec {
        StatementSpec param(String name, Object value);

        StatementSpec params(Map<String, Object> params);

        RowQuerySpec query();

        <T> MappedQuerySpec<T> query(RowMapper<T> rowMapper);

        int update(Map<String, Object> changes);
    }

    /** Terminal spec for queries that return raw rows. */
    interface RowQuerySpec {
        List<Map<String, Object>> list();

        default Map<String, Object> single() {
            List<Map<String, Object>> rows = list();
            if (rows.size() != 1) {
                throw new NoSuchElementException("Expected exactly one row but got " + rows.size());
            }
            return rows.get(0);
        }

        default Optional<Map<String, Object>> optional() {
            List<Map<String, Object>> rows = list();
            if (rows.size() > 1) {
                throw new NoSuchElementException("Expected at most one row but got " + rows.size());
            }
            return rows.isEmpty() ? Optional.empty() : Optional.of(rows.get(0));
        }
    }

    /** Terminal spec for queries mapped into a caller-supplied type. */
    interface MappedQuerySpec<T> {
        List<T> list();

        default T single() {
            List<T> results = list();
            if (results.size() != 1) {
                throw new NoSuchElementException(
                        "Expected exactly one result but got " + results.size());
            }
            return results.get(0);
        }

        default Optional<T> optional() {
            List<T> results = list();
            if (results.size() > 1) {
                throw new NoSuchElementException(
                        "Expected at most one result but got " + results.size());
            }
            return results.isEmpty() ? Optional.empty() : Optional.of(results.get(0));
        }
    }

    @FunctionalInterface
    interface RowMapper<T> {
        T mapRow(Map<String, Object> row);
    }
}
