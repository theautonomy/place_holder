package com.example.fluentapi.client;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

final class DefaultDataClient implements DataClient {

    private final DataStore dataStore;

    DefaultDataClient(DataStore dataStore) {
        this.dataStore = dataStore;
    }

    @Override
    public StatementSpec sql(String table) {
        return new DefaultStatementSpec(table);
    }

    private final class DefaultStatementSpec implements StatementSpec {
        private final String table;
        private final Map<String, Object> params = new LinkedHashMap<>();

        DefaultStatementSpec(String table) {
            this.table = table;
        }

        @Override
        public StatementSpec param(String name, Object value) {
            params.put(name, value);
            return this;
        }

        @Override
        public StatementSpec params(Map<String, Object> params) {
            this.params.putAll(params);
            return this;
        }

        @Override
        public RowQuerySpec query() {
            return new RawRowQuerySpec(matchingRows());
        }

        @Override
        public <T> MappedQuerySpec<T> query(RowMapper<T> rowMapper) {
            return new MappedResultSpec<>(matchingRows(), rowMapper);
        }

        @Override
        public int update(Map<String, Object> changes) {
            return dataStore.update(table, params, changes);
        }

        private List<Map<String, Object>> matchingRows() {
            return dataStore.rowsOf(table).stream()
                    .filter(row -> DataStore.matches(row, params))
                    .collect(Collectors.toList());
        }
    }

    private static final class RawRowQuerySpec implements RowQuerySpec {
        private final List<Map<String, Object>> rows;

        RawRowQuerySpec(List<Map<String, Object>> rows) {
            this.rows = rows;
        }

        @Override
        public List<Map<String, Object>> list() {
            return rows;
        }
    }

    private static final class MappedResultSpec<T> implements MappedQuerySpec<T> {
        private final List<Map<String, Object>> rows;
        private final RowMapper<T> rowMapper;

        MappedResultSpec(List<Map<String, Object>> rows, RowMapper<T> rowMapper) {
            this.rows = rows;
            this.rowMapper = rowMapper;
        }

        @Override
        public List<T> list() {
            return rows.stream().map(rowMapper::mapRow).collect(Collectors.toList());
        }
    }
}
