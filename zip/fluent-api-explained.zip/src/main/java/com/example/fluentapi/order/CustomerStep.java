package com.example.fluentapi.order;

public interface CustomerStep {
    OrderSteps withCustomer(String customerName);
}
