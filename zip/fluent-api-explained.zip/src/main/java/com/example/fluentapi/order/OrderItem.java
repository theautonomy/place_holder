package com.example.fluentapi.order;

import java.math.BigDecimal;

public record OrderItem(String name, int quantity, BigDecimal price) {

    @Override
    public String toString() {
        return String.format("%s x%d @ $%s", name, quantity, price);
    }

    public BigDecimal getTotal() {
        return price.multiply(BigDecimal.valueOf(quantity));
    }
}
