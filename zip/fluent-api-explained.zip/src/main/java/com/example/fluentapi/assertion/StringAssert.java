package com.example.fluentapi.assertion;

/** String-specific assertions */
public class StringAssert {
    private final String actual;

    public StringAssert(String actual) {
        this.actual = actual;
    }

    public StringAssert contains(String substring) {
        if (actual == null || !actual.contains(substring)) {
            throw new AssertionError(
                    "Expected string to contain '" + substring + "' but was '" + actual + "'");
        }
        return this;
    }

    public StringAssert startsWith(String prefix) {
        if (actual == null || !actual.startsWith(prefix)) {
            throw new AssertionError(
                    "Expected string to start with '" + prefix + "' but was '" + actual + "'");
        }
        return this;
    }

    public StringAssert hasLength(int expectedLength) {
        int actualLength = actual != null ? actual.length() : 0;
        if (actualLength != expectedLength) {
            throw new AssertionError(
                    "Expected length " + expectedLength + " but was " + actualLength);
        }
        return this;
    }
}
