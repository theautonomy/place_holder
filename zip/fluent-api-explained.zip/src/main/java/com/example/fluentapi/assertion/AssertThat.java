package com.example.fluentapi.assertion;

import java.util.Collection;
import java.util.Objects;

/** Generic assertion class for any type */
public class AssertThat<T> {
    private final T actual;

    public AssertThat(T actual) {
        this.actual = actual;
    }

    public AssertThat<T> isNotNull() {
        if (actual == null) {
            throw new AssertionError("Expected not null but was null");
        }
        return this;
    }

    public AssertThat<T> isEqualTo(T expected) {
        if (!Objects.equals(actual, expected)) {
            throw new AssertionError("Expected " + expected + " but was " + actual);
        }
        return this;
    }

    public StringAssert asString() {
        return new StringAssert(actual != null ? actual.toString() : null);
    }

    public NumberAssert asNumber() {
        if (actual instanceof Number) {
            return new NumberAssert((Number) actual);
        }
        throw new IllegalStateException("Value is not a number");
    }

    public CollectionAssert asCollection() {
        if (actual instanceof Collection) {
            return new CollectionAssert((Collection<?>) actual);
        }
        throw new IllegalStateException("Value is not a collection");
    }
}
