package com.example.fluentapi.retry;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

/**
 * An immutable retry policy: exponential backoff up to {@code maxDelay}, optionally scoped to
 * specific exception types via {@code retryOn(...)}. Unlike the other packages in this project,
 * this one has no fake backend to simulate — {@link #execute} really sleeps and really retries.
 */
public record RetryPolicy(
        int maxAttempts,
        Duration initialDelay,
        double backoffMultiplier,
        Duration maxDelay,
        List<Class<? extends Exception>> retryableExceptions,
        Consumer<RetryAttempt> onRetry) {

    public RetryPolicy {
        retryableExceptions = List.copyOf(retryableExceptions);
        if (onRetry == null) {
            onRetry = attempt -> {};
        }
    }

    /** Runs {@code action}, retrying on failure according to this policy. */
    public <T> T execute(Callable<T> action) throws Exception {
        Duration delay = initialDelay;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return action.call();
            } catch (Exception failure) {
                if (!isRetryable(failure) || attempt == maxAttempts) {
                    throw failure;
                }
                onRetry.accept(new RetryAttempt(attempt, maxAttempts, delay, failure));
                sleep(delay);
                delay = nextDelay(delay);
            }
        }
        // Unreachable: maxAttempts >= 1, so the loop above always returns or throws.
        throw new IllegalStateException("Unreachable");
    }

    private boolean isRetryable(Exception failure) {
        return retryableExceptions.isEmpty()
                || retryableExceptions.stream().anyMatch(type -> type.isInstance(failure));
    }

    private Duration nextDelay(Duration current) {
        Duration next = Duration.ofMillis((long) (current.toMillis() * backoffMultiplier));
        return next.compareTo(maxDelay) > 0 ? maxDelay : next;
    }

    private static void sleep(Duration duration) {
        try {
            Thread.sleep(duration.toMillis());
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Retry interrupted while waiting to retry", interrupted);
        }
    }
}
