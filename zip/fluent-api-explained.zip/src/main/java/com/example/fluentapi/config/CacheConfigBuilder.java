package com.example.fluentapi.config;

public class CacheConfigBuilder {
    private final ConfigurationBuilder parent;
    private String provider;
    private String host;
    private int ttl;

    public CacheConfigBuilder(ConfigurationBuilder parent) {
        this.parent = parent;
    }

    public CacheConfigBuilder withProvider(String provider) {
        this.provider = provider;
        return this;
    }

    public CacheConfigBuilder withHost(String host) {
        this.host = host;
        return this;
    }

    public CacheConfigBuilder withTtl(int ttl) {
        this.ttl = ttl;
        return this;
    }

    public ConfigurationBuilder and() {
        parent.setCacheConfig(new CacheConfig(provider, host, ttl));
        return parent;
    }
}
