package com.example.fluentapi.config;

public class LoggingConfigBuilder {
    private final ConfigurationBuilder parent;
    private String level;
    private String file;
    private boolean rotation;

    public LoggingConfigBuilder(ConfigurationBuilder parent) {
        this.parent = parent;
    }

    public LoggingConfigBuilder withLevel(String level) {
        this.level = level;
        return this;
    }

    public LoggingConfigBuilder withFile(String file) {
        this.file = file;
        return this;
    }

    public LoggingConfigBuilder withRotation(boolean rotation) {
        this.rotation = rotation;
        return this;
    }

    public ConfigurationBuilder and() {
        parent.setLoggingConfig(new LoggingConfig(level, file, rotation));
        return parent;
    }

    public AppConfiguration build() {
        parent.setLoggingConfig(new LoggingConfig(level, file, rotation));
        return parent.build();
    }
}
