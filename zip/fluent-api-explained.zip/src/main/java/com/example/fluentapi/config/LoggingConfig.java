package com.example.fluentapi.config;

public record LoggingConfig(String level, String file, boolean rotation) {

    @Override
    public String toString() {
        return String.format("Logging{level='%s', file='%s', rotation=%s}", level, file, rotation);
    }
}
