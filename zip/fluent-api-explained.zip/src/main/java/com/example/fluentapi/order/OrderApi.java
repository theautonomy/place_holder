package com.example.fluentapi.order;

public class OrderApi {
    public static CustomerStep startOrder() {
        return new OrderBuilder();
    }
}
