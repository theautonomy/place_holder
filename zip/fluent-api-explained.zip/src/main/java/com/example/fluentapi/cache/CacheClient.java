package com.example.fluentapi.cache;

import java.time.Duration;
import java.util.Optional;

/**
 * A fluent, in-process, real (not simulated) TTL cache, structured after the {@code restclient}
 * package's technique: verb methods return a spec type whose *compile-time* shape depends on which
 * verb was called, even though a single implementation class backs all of them underneath.
 *
 * <p>{@code get()}/{@code evict()} return {@link KeyOperationSpec}, which has no {@code
 * value(...)}/{@code ttl(...)} methods. {@code put()} returns {@link ValueOperationSpec}, which
 * adds both. Unlike {@code restclient}'s {@code FakeServer}, there's no fake backend here — TTL
 * expiry is computed against the real clock and entries are really evicted lazily on read.
 */
public interface CacheClient {

    KeyOperationSpec<?> get();

    KeyOperationSpec<?> evict();

    ValueOperationSpec put();

    static CacheClient create() {
        return new DefaultCacheClient();
    }

    /**
     * Contract for specifying the key of a cache operation.
     *
     * @param <S> a self reference to the spec type to return to after the key is set
     */
    interface KeySpec<S extends OperationSpec<?>> {
        S key(String key);
    }

    /**
     * Contract for specifying cross-cutting options and executing a cache operation.
     *
     * @param <S> a self reference to the spec type, so chained calls keep returning the same
     *     (possibly value-capable) type they started from
     */
    interface OperationSpec<S extends OperationSpec<S>> {
        S region(String region);

        Optional<Object> execute();

        <T> Optional<T> execute(Class<T> type);
    }

    /** Contract for specifying the value (and optional TTL) to store, in addition to options. */
    interface ValueSpec extends OperationSpec<ValueSpec> {
        ValueSpec value(Object value);

        ValueSpec ttl(Duration ttl);
    }

    /** Contract for a key-only operation with no value (GET, EVICT). */
    interface KeyOperationSpec<S extends OperationSpec<S>> extends KeySpec<S>, OperationSpec<S> {}

    /** Contract for a key-and-value operation (PUT). */
    interface ValueOperationSpec extends ValueSpec, KeyOperationSpec<ValueSpec> {}
}
