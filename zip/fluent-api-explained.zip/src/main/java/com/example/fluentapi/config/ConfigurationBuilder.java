package com.example.fluentapi.config;

public class ConfigurationBuilder {
    private DatabaseConfig databaseConfig;
    private CacheConfig cacheConfig;
    private LoggingConfig loggingConfig;

    public DatabaseConfigBuilder database() {
        return new DatabaseConfigBuilder(this);
    }

    public CacheConfigBuilder cache() {
        return new CacheConfigBuilder(this);
    }

    public LoggingConfigBuilder logging() {
        return new LoggingConfigBuilder(this);
    }

    public AppConfiguration build() {
        return new AppConfiguration(databaseConfig, cacheConfig, loggingConfig);
    }

    void setDatabaseConfig(DatabaseConfig config) {
        this.databaseConfig = config;
    }

    void setCacheConfig(CacheConfig config) {
        this.cacheConfig = config;
    }

    void setLoggingConfig(LoggingConfig config) {
        this.loggingConfig = config;
    }
}
