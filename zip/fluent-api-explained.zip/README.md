# Fluent API Explained

A hands-on Java project demonstrating fluent API and builder-pattern design, from simple method chaining to type-safe staged builders that make invalid states unrepresentable at compile time — and beyond that, to packages with real (not simulated) resilience and caching behavior, and even a demo of how an API's ergonomics should evolve from watching real usage.

## What's inside

Eleven packages, each demonstrating a different structural technique for the *same* general idea — chainable method calls that construct an immutable result:

| Package | Technique |
|---|---|
| `http`, `email` | Classic single-class builders — every `withX()` setter returns `this`, a terminal `build()` validates and constructs the result |
| `sql` | A **ping-pong builder** (`SqlBuilder`) — compound clauses (`where`/`having`/`orderBy`) hand off to a small clause object, which hands control back to the parent builder |
| `assertion` | The same ping-pong shape applied to **type narrowing**: `FluentAssert.assertThat(x)` hands off to `StringAssert`/`NumberAssert`/`CollectionAssert` based on runtime type, exposing only type-appropriate methods |
| `config` | A **nested sub-builder DSL** — a root builder delegates to independent per-section child builders, each with a `.and()` to commit back up to the parent |
| `order` | The project's flagship attempt at a **staged state-machine builder** — `OrderApi.startOrder()` only allows `withCustomer()` first, real compile-time enforcement (though only for that one step — see `docs/order-package.md`) |
| `client` | A **terminal fan-out** facade modeled on Spring's `JdbcClient` — one accumulated `StatementSpec`, but `query()`/`query(RowMapper)`/`update()` each return a completely different result shape |
| `restclient` | **Compile-time capability restriction** modeled on Spring's `RestClient` — `get()`/`delete()` can't call `.body(...)`, `post()`/`put()` can, enforced entirely by F-bounded generics and interface composition, not runtime checks |
| `retry` | An original resilience policy with **no fake backend** — real `Thread.sleep`, real exponential backoff, real exception-type inspection |
| `cache` | `restclient`'s capability-restriction technique reapplied to a self-designed, genuinely real in-process TTL cache |
| `evolution` | Not a structural technique — a **process** demo of how an API's ergonomics should evolve from watching real usage, inspired by Arjen Poutsma's blog series (see `docs/poutsma-fluent-api-series.md`) |

The entry point, [`FluentApiDemo`](src/main/java/com/example/fluentapi/FluentApiDemo.java), runs every package in sequence and prints a summary of fluent API best practices.

Each package has a companion write-up in [`docs/`](docs/) with diagrams and a fully-commented walkthrough of what every chained call returns — start there for the design rationale behind a specific technique, not just the code.

## Requirements

- Java 17+
- Maven 3.6+

## Build

```bash
mvn compile
```

## Run

```bash
mvn compile exec:java -Dexec.mainClass="com.example.fluentapi.FluentApiDemo"
```

Or run `FluentApiDemo.main` directly from your IDE.

## Why this exists

Each package illustrates a different flavor of fluent design, roughly in order of what problem it solves:

- **Method chaining** (e.g. `StringBuilder`) — chained calls, no enforced order.
- **Builder pattern** (`http`, `email`) — accumulate parameters fluently, validate and construct on `build()`.
- **Ping-pong handoff** (`sql`, `assertion`) — bounce to a small dedicated object to enforce grammar or narrow a type, then return to the original.
- **Nested sub-builders** (`config`) — a parent builder delegates to independent child builders per section.
- **Staged interfaces** (`order`) — interfaces narrow what's callable next, so the compiler rejects invalid call sequences (though see the caveat in `docs/order-package.md` about how far this one actually goes).
- **Terminal fan-out** (`client`) — one accumulated builder state, but the terminal call determines a completely different result type.
- **F-bounded generics + interface composition** (`restclient`, `cache`) — the return type of each step is restricted so an invalid next call doesn't compile, without any runtime check.
- **Real, unsimulated behavior** (`retry`, `cache`) — some packages don't fake their backend at all; the fluent chain configures logic that genuinely executes (real sleeps, real backoff, real clock-based expiry).
- **Usage-driven evolution** (`evolution`) — not a code trick, a reminder that good fluent API ergonomics often come from watching real usage rather than getting the design right on the first try.

See `FluentApiDemo.demonstrateMethodChainingVsFluent()` for a side-by-side comparison of plain chaining vs. a staged fluent interface.

## Using this as a blueprint

Every package follows the same three-part shape, so copying one as a starting point for a real API is straightforward:

1. **The implementation** — `src/main/java/com/example/fluentapi/<package>/`.
2. **A `demonstrateX()` method** in `FluentApiDemo.java`, exercising every branch of the API.
3. **A doc** in `docs/<package>-package.md` — the design rationale, diagrams, and (for a few packages) the actual compiler errors hit while verifying a design decision, not just an assertion that it's true.

`CLAUDE.md` keeps a running architecture index across all packages if you want the condensed version before diving into a specific doc.
