package com.example.demo;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.stereotype.Component;

@Component
public class AutoConfigurationBeanDefinitionLogger implements BeanDefinitionRegistryPostProcessor {

    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
        // Check if our auto-configured service bean definition was registered
        if (registry.containsBeanDefinition("autoConfiguredService")) {
            BeanDefinition beanDef = registry.getBeanDefinition("autoConfiguredService");
            System.out.println("######## AutoConfiguredService - Bean definition registered: " +
                    "type=" + beanDef.getClass().getSimpleName() +
                    ", configClass=" + beanDef.getBeanClassName() + 
                    ", factoryMethod=" + beanDef.getFactoryMethodName() +
                    ", scope=" + beanDef.getScope() +
                    ", factoryBeanName=" + beanDef.getFactoryBeanName());
        }
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        // This runs after all bean definitions are registered
    }
}