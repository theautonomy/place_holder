package com.example.demo;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "demo.auto")
public class MyAutoConfigurationProperties {

    private boolean enabled = true;
    private String message = "Default auto-configured message";
    private int timeout = 5000;
    private String serviceType = "default";

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    @Override
    public String toString() {
        return "MyAutoConfigurationProperties{" +
                "enabled=" + enabled +
                ", message='" + message + '\'' +
                ", timeout=" + timeout +
                ", serviceType='" + serviceType + '\'' +
                '}';
    }
}