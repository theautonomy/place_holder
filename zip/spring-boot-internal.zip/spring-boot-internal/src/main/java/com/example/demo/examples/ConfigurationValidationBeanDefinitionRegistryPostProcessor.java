package com.example.demo.examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.core.PriorityOrdered;
import org.springframework.stereotype.Component;

/**
 * Real-world example: Configuration Validation Bean Definition Registry Post Processor
 *
 * <p>USE CASE: Validate and modify bean definitions before any beans are instantiated. This is
 * useful for: - Ensuring required configuration beans are present - Adding missing default
 * configuration beans - Validating bean dependencies before instantiation - Modifying bean scopes
 * based on environment - Adding security or audit decorators to sensitive beans
 *
 * <p>SCENARIO: - Validate that security configuration is present in production - Add default
 * implementations for missing required services - Ensure database configuration exists for
 * data-dependent beans - Add monitoring and metrics wrappers to service beans
 */
@Component
public class ConfigurationValidationBeanDefinitionRegistryPostProcessor
        implements BeanDefinitionRegistryPostProcessor, PriorityOrdered {

    private static final List<String> REQUIRED_PRODUCTION_BEANS =
            Arrays.asList(
                    "securityConfiguration", "dataSource", "transactionManager", "cacheManager");

    private static final List<String> MONITORING_TARGET_PATTERNS =
            Arrays.asList(".*Service$", ".*Repository$", ".*Controller$");

    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry)
            throws BeansException {
        System.out.println(
                "### ConfigurationValidationBeanDefinitionRegistryPostProcessor: Validating and enhancing bean definitions ===");

        // Step 1: Validate required beans exist
        validateRequiredBeans(registry);

        // Step 2: Add missing default beans
        addMissingDefaultBeans(registry);

        // Step 3: Enhance service beans with monitoring
        enhanceServiceBeansWithMonitoring(registry);

        // Step 4: Validate and fix bean dependencies
        validateBeanDependencies(registry);

        // Step 5: Adjust bean scopes based on environment
        adjustBeanScopes(registry);

        System.out.println(
                "### ConfigurationValidationBeanDefinitionRegistryPostProcessor registry processing completed ===");
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
            throws BeansException {
        System.out.println(
                "### ConfigurationValidationBeanDefinitionRegistryPostProcessor: Post-processing bean factory ===");

        // Step 1: Validate bean factory configuration
        validateBeanFactoryConfiguration(beanFactory);

        // Step 2: Add custom property resolvers
        addCustomPropertyResolvers(beanFactory);

        // Step 3: Register custom scopes
        registerCustomScopes(beanFactory);

        // Step 4: Add bean factory post-processors for monitoring
        addMonitoringBeanFactoryProcessors(beanFactory);

        System.out.println(
                "### === ConfigurationValidationBeanDefinitionRegistryPostProcessor bean factory processing completed ===");
    }

    private void validateRequiredBeans(BeanDefinitionRegistry registry) {
        System.out.println("###### Validating required beans...");

        boolean isProduction = isProductionEnvironment();
        List<String> missingBeans = new ArrayList<>();

        if (isProduction) {
            for (String requiredBean : REQUIRED_PRODUCTION_BEANS) {
                if (!registry.containsBeanDefinition(requiredBean)) {
                    missingBeans.add(requiredBean);
                }
            }

            if (!missingBeans.isEmpty()) {
                System.out.println("###### WARNING: Missing required production beans: " + missingBeans);
                // In a real application, you might throw an exception here
                // throw new IllegalStateException("Missing required production beans: " +
                // missingBeans);
            }
        }

        System.out.println("###### Required beans validation completed. Missing: " + missingBeans.size());
    }

    private void addMissingDefaultBeans(BeanDefinitionRegistry registry) {
        System.out.println("###### Adding missing default beans...");

        // Add default security configuration if missing
        if (!registry.containsBeanDefinition("securityConfiguration")) {
            GenericBeanDefinition securityBeanDef = new GenericBeanDefinition();
            securityBeanDef.setBeanClass(DefaultSecurityConfiguration.class);
            registry.registerBeanDefinition("securityConfiguration", securityBeanDef);
            System.out.println("###### Added default security configuration");
        }

        // Add default cache manager if missing
        if (!registry.containsBeanDefinition("cacheManager")) {
            GenericBeanDefinition cacheBeanDef = new GenericBeanDefinition();
            cacheBeanDef.setBeanClass(DefaultCacheManager.class);
            registry.registerBeanDefinition("cacheManager", cacheBeanDef);
            System.out.println("###### Added default cache manager");
        }

        // Add default metrics collector if missing
        if (!registry.containsBeanDefinition("metricsCollector")) {
            GenericBeanDefinition metricsBeanDef = new GenericBeanDefinition();
            metricsBeanDef.setBeanClass(DefaultMetricsCollector.class);
            registry.registerBeanDefinition("metricsCollector", metricsBeanDef);
            System.out.println("###### Added default metrics collector");
        }

        // Add default audit logger if missing
        if (!registry.containsBeanDefinition("auditLogger")) {
            GenericBeanDefinition auditBeanDef = new GenericBeanDefinition();
            auditBeanDef.setBeanClass(DefaultAuditLogger.class);
            registry.registerBeanDefinition("auditLogger", auditBeanDef);
            System.out.println("###Added default audit logger");
        }
    }

    private void enhanceServiceBeansWithMonitoring(BeanDefinitionRegistry registry) {
        System.out.println("###Enhancing service beans with monitoring...");

        String[] beanNames = registry.getBeanDefinitionNames();
        int enhancedCount = 0;

        for (String beanName : beanNames) {
            if (shouldAddMonitoring(beanName)) {
                BeanDefinition beanDefinition = registry.getBeanDefinition(beanName);

                // Add monitoring wrapper
                addMonitoringDecorator(beanDefinition, beanName);
                enhancedCount++;
            }
        }

        System.out.println("###Enhanced " + enhancedCount + " beans with monitoring");
    }

    private void validateBeanDependencies(BeanDefinitionRegistry registry) {
        System.out.println("###Validating bean dependencies...");

        String[] beanNames = registry.getBeanDefinitionNames();
        List<String> dependencyIssues = new ArrayList<>();

        for (String beanName : beanNames) {
            BeanDefinition beanDefinition = registry.getBeanDefinition(beanName);

            // Check for circular dependencies (simplified check)
            if (hasCircularDependency(beanName, beanDefinition, registry)) {
                dependencyIssues.add("Potential circular dependency detected in: " + beanName);
            }

            // Check for missing dependencies
            List<String> missingDeps = findMissingDependencies(beanName, beanDefinition, registry);
            if (!missingDeps.isEmpty()) {
                dependencyIssues.add("Missing dependencies for " + beanName + ": " + missingDeps);
            }
        }

        if (!dependencyIssues.isEmpty()) {
            System.out.println("###Dependency validation issues found:");
            dependencyIssues.forEach(System.out::println);
        } else {
            System.out.println("###All bean dependencies validated successfully");
        }
    }

    private void adjustBeanScopes(BeanDefinitionRegistry registry) {
        System.out.println("###Adjusting bean scopes based on environment...");

        boolean isProduction = isProductionEnvironment();
        boolean isIntegrationTest = isIntegrationTestEnvironment();

        String[] beanNames = registry.getBeanDefinitionNames();
        int adjustedCount = 0;

        for (String beanName : beanNames) {
            BeanDefinition beanDefinition = registry.getBeanDefinition(beanName);
            String originalScope = beanDefinition.getScope();
            String newScope =
                    determineOptimalScope(beanName, originalScope, isProduction, isIntegrationTest);

            if (!originalScope.equals(newScope)) {
                beanDefinition.setScope(newScope);
                System.out.println(
                        "Changed scope for " + beanName + ": " + originalScope + " -> " + newScope);
                adjustedCount++;
            }
        }

        System.out.println("###Adjusted scopes for " + adjustedCount + " beans");
    }

    private void validateBeanFactoryConfiguration(ConfigurableListableBeanFactory beanFactory) {
        System.out.println("###Validating bean factory configuration...");

        // Validate thread pool configuration
        int availableProcessors = Runtime.getRuntime().availableProcessors();
        System.out.println("###Available processors: " + availableProcessors);

        // Validate memory configuration
        long maxMemory = Runtime.getRuntime().maxMemory();
        System.out.println("###Max memory: " + (maxMemory / 1024 / 1024) + "MB");

        // Warn about potential configuration issues
        if (isProductionEnvironment() && maxMemory < 1024 * 1024 * 1024) { // Less than 1GB
            System.out.println(
                    "WARNING: Low memory configuration detected in production environment");
        }

        System.out.println("###Bean factory configuration validation completed");
    }

    private void addCustomPropertyResolvers(ConfigurableListableBeanFactory beanFactory) {
        System.out.println("###Adding custom property resolvers...");

        // In a real implementation, you would register these as beans or configure property sources
        // For demo purposes, we'll just log what would be done
        System.out.println("###Would add encrypted property resolver");
        System.out.println("###Would add external config resolver");

        System.out.println("###Custom property resolvers configuration completed");
    }

    private void registerCustomScopes(ConfigurableListableBeanFactory beanFactory) {
        System.out.println("###Registering custom scopes...");

        // Register tenant scope for multi-tenant applications
        beanFactory.registerScope("tenant", new TenantScope());

        // Register request-cached scope for web applications
        beanFactory.registerScope("requestCached", new RequestCachedScope());

        System.out.println("###Custom scopes registered");
    }

    private void addMonitoringBeanFactoryProcessors(ConfigurableListableBeanFactory beanFactory) {
        System.out.println("###Adding monitoring bean factory processors...");

        // This would typically involve registering additional BeanPostProcessors
        // that add monitoring capabilities to beans
        System.out.println("###Monitoring bean factory processors would be added here");
    }

    // Helper methods

    private boolean isProductionEnvironment() {
        return "prod".equals(System.getProperty("spring.profiles.active"))
                || "production".equals(System.getenv("ENVIRONMENT"));
    }

    private boolean isIntegrationTestEnvironment() {
        return "integration-test".equals(System.getProperty("spring.profiles.active"));
    }

    private boolean shouldAddMonitoring(String beanName) {
        return MONITORING_TARGET_PATTERNS.stream().anyMatch(pattern -> beanName.matches(pattern));
    }

    private void addMonitoringDecorator(BeanDefinition beanDefinition, String beanName) {
        // In a real implementation, this would wrap the bean with monitoring capabilities
        System.out.println("###Adding monitoring decorator to: " + beanName);
    }

    private boolean hasCircularDependency(
            String beanName, BeanDefinition beanDefinition, BeanDefinitionRegistry registry) {
        // Simplified circular dependency check
        // Real implementation would be more sophisticated
        return false;
    }

    private List<String> findMissingDependencies(
            String beanName, BeanDefinition beanDefinition, BeanDefinitionRegistry registry) {
        // Check for missing dependencies
        // Real implementation would inspect constructor arguments and property values
        return new ArrayList<>();
    }

    private String determineOptimalScope(
            String beanName,
            String originalScope,
            boolean isProduction,
            boolean isIntegrationTest) {
        // Logic to determine optimal scope based on environment
        if (isIntegrationTest && "singleton".equals(originalScope)) {
            // Use prototype scope in integration tests to avoid state pollution
            return "prototype";
        }

        if (isProduction && beanName.contains("Cache")) {
            // Ensure cache beans are singletons in production
            return "singleton";
        }

        return originalScope.isEmpty() ? "singleton" : originalScope;
    }

    @Override
    public int getOrder() {
        return 0; // High priority
    }

    // Placeholder classes for demonstration
    public static class DefaultSecurityConfiguration {
        public DefaultSecurityConfiguration() {
            System.out.println("###DefaultSecurityConfiguration created");
        }
    }

    public static class DefaultCacheManager {
        public DefaultCacheManager() {
            System.out.println("###DefaultCacheManager created");
        }
    }

    public static class DefaultMetricsCollector {
        public DefaultMetricsCollector() {
            System.out.println("###DefaultMetricsCollector created");
        }
    }

    public static class DefaultAuditLogger {
        public DefaultAuditLogger() {
            System.out.println("###DefaultAuditLogger created");
        }
    }

    public static class EncryptedPropertyResolver {
        public EncryptedPropertyResolver() {
            System.out.println("###EncryptedPropertyResolver created");
        }
    }

    public static class ExternalConfigResolver {
        public ExternalConfigResolver() {
            System.out.println("###ExternalConfigResolver created");
        }
    }

    public static class TenantScope implements org.springframework.beans.factory.config.Scope {
        @Override
        public Object get(
                String name, org.springframework.beans.factory.ObjectFactory<?> objectFactory) {
            return null;
        }

        @Override
        public Object remove(String name) {
            return null;
        }

        @Override
        public void registerDestructionCallback(String name, Runnable callback) {}

        @Override
        public Object resolveContextualObject(String key) {
            return null;
        }

        @Override
        public String getConversationId() {
            return null;
        }
    }

    public static class RequestCachedScope
            implements org.springframework.beans.factory.config.Scope {
        @Override
        public Object get(
                String name, org.springframework.beans.factory.ObjectFactory<?> objectFactory) {
            return null;
        }

        @Override
        public Object remove(String name) {
            return null;
        }

        @Override
        public void registerDestructionCallback(String name, Runnable callback) {}

        @Override
        public Object resolveContextualObject(String key) {
            return null;
        }

        @Override
        public String getConversationId() {
            return null;
        }
    }
}
