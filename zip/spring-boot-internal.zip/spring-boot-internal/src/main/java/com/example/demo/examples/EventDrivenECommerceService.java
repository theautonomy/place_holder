package com.example.demo.examples;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

/**
 * Real-world example: Event-Driven E-Commerce Service
 *
 * <p>USE CASE: Demonstrates how to publish events in a real business service to create a decoupled,
 * event-driven architecture.
 *
 * <p>SCENARIO: - Order management with event publishing - User action auditing - Business workflow
 * orchestration through events - Microservice communication via events
 */
@Service
public class EventDrivenECommerceService {

    private final ApplicationEventPublisher eventPublisher;

    public EventDrivenECommerceService(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    // === ORDER MANAGEMENT METHODS ===

    public String createOrder(String customerId, OrderEvent.ShippingAddress shippingAddress) {
        System.out.println("###=== Creating Order for Customer: " + customerId + " ===");

        String orderId = generateOrderId();

        // Create order items (simplified)
        OrderEvent.OrderItem item1 =
                new OrderEvent.OrderItem("PROD001", "Laptop", 1, new BigDecimal("999.99"));
        OrderEvent.OrderItem item2 =
                new OrderEvent.OrderItem("PROD002", "Mouse", 2, new BigDecimal("29.99"));

        // Calculate total
        BigDecimal total = item1.getTotalPrice().add(item2.getTotalPrice());

        // Create and publish order created event
        OrderEvent orderEvent =
                new OrderEvent(
                        this, // source
                        orderId,
                        customerId,
                        OrderEvent.OrderStatus.PENDING,
                        total,
                        Arrays.asList(item1, item2),
                        "CREDIT_CARD",
                        shippingAddress,
                        OrderEvent.OrderEventType.ORDER_CREATED);

        // Publish the event - this triggers all registered listeners
        eventPublisher.publishEvent(orderEvent);

        // Also publish audit event for order creation
        publishAuditEvent(
                customerId,
                "ORDER_CREATE",
                "order",
                orderId,
                createOrderAuditDetails(orderEvent),
                AuditEvent.AuditLevel.INFO);

        System.out.println("###Order created with ID: " + orderId);
        return orderId;
    }

    public void confirmOrder(String orderId, String customerId) {
        System.out.println("###=== Confirming Order: " + orderId + " ===");

        // Simulate order confirmation logic
        OrderEvent confirmEvent =
                createOrderEvent(
                        orderId,
                        customerId,
                        OrderEvent.OrderStatus.CONFIRMED,
                        OrderEvent.OrderEventType.ORDER_CONFIRMED);

        eventPublisher.publishEvent(confirmEvent);

        publishAuditEvent(
                customerId, "ORDER_CONFIRM", "order", orderId, null, AuditEvent.AuditLevel.INFO);
    }

    public void processPayment(String orderId, String customerId, BigDecimal amount) {
        System.out.println("###=== Processing Payment for Order: " + orderId + " ===");

        try {
            // Simulate payment processing
            boolean paymentSuccess = simulatePaymentProcessing(amount);

            if (paymentSuccess) {
                OrderEvent paymentEvent =
                        createOrderEvent(
                                orderId,
                                customerId,
                                OrderEvent.OrderStatus.PROCESSING,
                                OrderEvent.OrderEventType.PAYMENT_PROCESSED);
                eventPublisher.publishEvent(paymentEvent);

                publishAuditEvent(
                        customerId,
                        "PAYMENT_PROCESS",
                        "payment",
                        orderId,
                        createPaymentAuditDetails(amount, "SUCCESS"),
                        AuditEvent.AuditLevel.INFO);
            } else {
                OrderEvent failureEvent =
                        createOrderEvent(
                                orderId,
                                customerId,
                                OrderEvent.OrderStatus.PENDING,
                                OrderEvent.OrderEventType.PAYMENT_FAILED);
                eventPublisher.publishEvent(failureEvent);

                publishAuditEvent(
                        customerId,
                        "PAYMENT_FAIL",
                        "payment",
                        orderId,
                        createPaymentAuditDetails(amount, "FAILED"),
                        AuditEvent.AuditLevel.WARNING);
            }

        } catch (Exception e) {
            System.err.println("###Payment processing error: " + e.getMessage());

            OrderEvent errorEvent =
                    createOrderEvent(
                            orderId,
                            customerId,
                            OrderEvent.OrderStatus.PENDING,
                            OrderEvent.OrderEventType.PAYMENT_FAILED);
            eventPublisher.publishEvent(errorEvent);

            publishAuditEvent(
                    customerId,
                    "PAYMENT_ERROR",
                    "payment",
                    orderId,
                    createErrorAuditDetails(e),
                    AuditEvent.AuditLevel.CRITICAL);
        }
    }

    public void shipOrder(String orderId, String customerId, String trackingNumber) {
        System.out.println(
                "=== Shipping Order: " + orderId + " (Tracking: " + trackingNumber + ") ===");

        OrderEvent shipEvent =
                createOrderEvent(
                        orderId,
                        customerId,
                        OrderEvent.OrderStatus.SHIPPED,
                        OrderEvent.OrderEventType.ORDER_SHIPPED);

        eventPublisher.publishEvent(shipEvent);

        Map<String, Object> shipmentDetails = new HashMap<>();
        shipmentDetails.put("tracking_number", trackingNumber);
        shipmentDetails.put("carrier", "UPS");
        shipmentDetails.put("estimated_delivery", "2024-01-15");

        publishAuditEvent(
                customerId,
                "ORDER_SHIP",
                "order",
                orderId,
                shipmentDetails,
                AuditEvent.AuditLevel.INFO);
    }

    public void deliverOrder(String orderId, String customerId) {
        System.out.println("###=== Delivering Order: " + orderId + " ===");

        OrderEvent deliveryEvent =
                createOrderEvent(
                        orderId,
                        customerId,
                        OrderEvent.OrderStatus.DELIVERED,
                        OrderEvent.OrderEventType.ORDER_DELIVERED);

        eventPublisher.publishEvent(deliveryEvent);

        publishAuditEvent(
                customerId, "ORDER_DELIVER", "order", orderId, null, AuditEvent.AuditLevel.INFO);
    }

    public void cancelOrder(String orderId, String customerId, String reason) {
        System.out.println("###=== Cancelling Order: " + orderId + " (Reason: " + reason + ") ===");

        OrderEvent cancelEvent =
                createOrderEvent(
                        orderId,
                        customerId,
                        OrderEvent.OrderStatus.CANCELLED,
                        OrderEvent.OrderEventType.ORDER_CANCELLED);

        eventPublisher.publishEvent(cancelEvent);

        Map<String, Object> cancelDetails = new HashMap<>();
        cancelDetails.put("cancellation_reason", reason);
        cancelDetails.put("cancelled_by", "CUSTOMER");

        publishAuditEvent(
                customerId,
                "ORDER_CANCEL",
                "order",
                orderId,
                cancelDetails,
                AuditEvent.AuditLevel.WARNING);
    }

    // === USER ACTION METHODS ===

    public void recordUserLogin(String userId, String clientIp, String userAgent) {
        System.out.println("###=== Recording User Login: " + userId + " ===");

        Map<String, Object> loginDetails = new HashMap<>();
        loginDetails.put("login_time", java.time.LocalDateTime.now());
        loginDetails.put("session_id", generateSessionId());

        publishAuditEvent(
                userId,
                "USER_LOGIN",
                "user_session",
                userId,
                loginDetails,
                clientIp,
                userAgent,
                AuditEvent.AuditLevel.INFO);
    }

    public void recordUserLogout(String userId, String sessionId) {
        System.out.println("###=== Recording User Logout: " + userId + " ===");

        Map<String, Object> logoutDetails = new HashMap<>();
        logoutDetails.put("logout_time", java.time.LocalDateTime.now());
        logoutDetails.put("session_id", sessionId);
        logoutDetails.put("session_duration_minutes", 45); // Example

        publishAuditEvent(
                userId,
                "USER_LOGOUT",
                "user_session",
                sessionId,
                logoutDetails,
                AuditEvent.AuditLevel.INFO);
    }

    public void recordSensitiveAction(String userId, String action, String resourceId) {
        System.out.println("###=== Recording Sensitive Action: " + action + " by " + userId + " ===");

        Map<String, Object> actionDetails = new HashMap<>();
        actionDetails.put("action_time", java.time.LocalDateTime.now());
        actionDetails.put("requires_approval", true);
        actionDetails.put("risk_level", "HIGH");

        publishAuditEvent(
                userId,
                action,
                "sensitive_resource",
                resourceId,
                actionDetails,
                "192.168.1.100",
                "Admin-Tool/1.0",
                AuditEvent.AuditLevel.CRITICAL);
    }

    // === ADMINISTRATIVE METHODS ===

    public void processRefund(
            String orderId, String customerId, BigDecimal refundAmount, String reason) {
        System.out.println("###=== Processing Refund for Order: " + orderId + " ===");

        OrderEvent refundEvent =
                createOrderEvent(
                        orderId,
                        customerId,
                        OrderEvent.OrderStatus.REFUNDED,
                        OrderEvent.OrderEventType.REFUND_PROCESSED);

        eventPublisher.publishEvent(refundEvent);

        Map<String, Object> refundDetails = new HashMap<>();
        refundDetails.put("refund_amount", refundAmount);
        refundDetails.put("refund_reason", reason);
        refundDetails.put("refund_method", "ORIGINAL_PAYMENT_METHOD");

        publishAuditEvent(
                customerId,
                "REFUND_PROCESS",
                "refund",
                orderId,
                refundDetails,
                AuditEvent.AuditLevel.INFO);
    }

    public void updateInventory(String productId, int quantityChange, String reason) {
        System.out.println("###=== Updating Inventory for Product: " + productId + " ===");

        Map<String, Object> inventoryDetails = new HashMap<>();
        inventoryDetails.put("product_id", productId);
        inventoryDetails.put("quantity_change", quantityChange);
        inventoryDetails.put("reason", reason);
        inventoryDetails.put("previous_quantity", 100); // Example
        inventoryDetails.put("new_quantity", 100 + quantityChange);

        publishAuditEvent(
                "SYSTEM",
                "INVENTORY_UPDATE",
                "product",
                productId,
                inventoryDetails,
                AuditEvent.AuditLevel.INFO);
    }

    // === HELPER METHODS ===

    private void publishAuditEvent(
            String userId,
            String action,
            String resourceType,
            String resourceId,
            Map<String, Object> details,
            AuditEvent.AuditLevel level) {
        publishAuditEvent(
                userId,
                action,
                resourceType,
                resourceId,
                details,
                "127.0.0.1",
                "Spring-App/1.0",
                level);
    }

    private void publishAuditEvent(
            String userId,
            String action,
            String resourceType,
            String resourceId,
            Map<String, Object> details,
            String clientIp,
            String userAgent,
            AuditEvent.AuditLevel level) {

        AuditEvent auditEvent =
                new AuditEvent(
                        this, // source
                        userId,
                        action,
                        resourceType,
                        resourceId,
                        details,
                        clientIp,
                        userAgent,
                        level);

        eventPublisher.publishEvent(auditEvent);
    }

    private OrderEvent createOrderEvent(
            String orderId,
            String customerId,
            OrderEvent.OrderStatus status,
            OrderEvent.OrderEventType eventType) {
        // Create simplified order event (in real app, would fetch full order data)
        return new OrderEvent(
                this,
                orderId,
                customerId,
                status,
                new BigDecimal("1059.97"), // Example total
                Arrays.asList(
                        new OrderEvent.OrderItem("PROD001", "Laptop", 1, new BigDecimal("999.99")),
                        new OrderEvent.OrderItem("PROD002", "Mouse", 2, new BigDecimal("29.99"))),
                "CREDIT_CARD",
                new OrderEvent.ShippingAddress("123 Main St", "Anytown", "CA", "90210", "USA"),
                eventType);
    }

    private Map<String, Object> createOrderAuditDetails(OrderEvent orderEvent) {
        Map<String, Object> details = new HashMap<>();
        details.put("order_total", orderEvent.getTotalAmount());
        details.put("item_count", orderEvent.getItems().size());
        details.put("payment_method", orderEvent.getPaymentMethod());
        details.put("shipping_city", orderEvent.getShippingAddress().getCity());
        return details;
    }

    private Map<String, Object> createPaymentAuditDetails(BigDecimal amount, String status) {
        Map<String, Object> details = new HashMap<>();
        details.put("payment_amount", amount);
        details.put("payment_status", status);
        details.put("processor", "Stripe");
        details.put("currency", "USD");
        return details;
    }

    private Map<String, Object> createErrorAuditDetails(Exception e) {
        Map<String, Object> details = new HashMap<>();
        details.put("error_message", e.getMessage());
        details.put("error_type", e.getClass().getSimpleName());
        details.put("stack_trace", Arrays.toString(e.getStackTrace()));
        return details;
    }

    private boolean simulatePaymentProcessing(BigDecimal amount) {
        // Simulate payment processing with 90% success rate
        return Math.random() > 0.1;
    }

    private String generateOrderId() {
        return "ORD-" + System.currentTimeMillis();
    }

    private String generateSessionId() {
        return "SESSION-" + System.currentTimeMillis();
    }

    // === DEMO METHODS FOR TESTING ===

    public void demonstrateEventDrivenWorkflow() {
        System.out.println("###\n======== EVENT-DRIVEN WORKFLOW DEMONSTRATION ========\n");

        String customerId = "CUST-12345";
        OrderEvent.ShippingAddress address =
                new OrderEvent.ShippingAddress(
                        "123 Demo Street", "Demo City", "CA", "90210", "USA");

        // 1. Customer logs in
        recordUserLogin(customerId, "192.168.1.50", "Mozilla/5.0 Chrome/91.0");

        // 2. Create order
        String orderId = createOrder(customerId, address);

        // 3. Confirm order
        confirmOrder(orderId, customerId);

        // 4. Process payment
        processPayment(orderId, customerId, new BigDecimal("1059.97"));

        // 5. Ship order
        shipOrder(orderId, customerId, "1Z999AA1234567890");

        // 6. Deliver order
        deliverOrder(orderId, customerId);

        // 7. Update inventory (due to sale)
        updateInventory("PROD001", -1, "SOLD");
        updateInventory("PROD002", -2, "SOLD");

        // 8. Customer logs out
        recordUserLogout(customerId, "SESSION-" + System.currentTimeMillis());

        System.out.println("###\n======== WORKFLOW DEMONSTRATION COMPLETED ========\n");
    }

    public void demonstrateErrorScenarios() {
        System.out.println("###\n======== ERROR SCENARIOS DEMONSTRATION ========\n");

        String customerId = "CUST-ERROR-TEST";
        OrderEvent.ShippingAddress address =
                new OrderEvent.ShippingAddress(
                        "456 Error Street", "Error City", "TX", "75001", "USA");

        // 1. Create order
        String orderId = createOrder(customerId, address);

        // 2. Simulate payment failure
        try {
            throw new RuntimeException("Credit card declined");
        } catch (Exception e) {
            processPayment(orderId, customerId, new BigDecimal("2500.00"));
        }

        // 3. Cancel order due to payment issues
        cancelOrder(orderId, customerId, "Payment processing failed");

        // 4. Admin performs sensitive action
        recordSensitiveAction("ADMIN-001", "DELETE_CUSTOMER_DATA", customerId);

        System.out.println("###\n======== ERROR SCENARIOS DEMONSTRATION COMPLETED ========\n");
    }
}
