package com.example.demo;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class FirstEventListenerComponent {

    private final ApplicationEventPublisher eventPublisher;

    public FirstEventListenerComponent(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
        System.out.println("###### FirstEventListenerComponent created");

        // Publish a custom event during initialization
        publishCustomEvent("Component initialized successfully!");
    }

    @EventListener
    public void handleCustomEvent(FirstCustomEvent event) {
        System.out.println("###### @EventListener - handling FirstCustomEvent");
        System.out.println("###### Message: " + event.getMessage());
        System.out.println("###### Timestamp: " + event.getTimestamp());
        System.out.println("###### Source: " + event.getSource().getClass().getSimpleName());
    }

    public void publishCustomEvent(String message) {
        FirstCustomEvent event = new FirstCustomEvent(this, message);
        eventPublisher.publishEvent(event);
    }
}
