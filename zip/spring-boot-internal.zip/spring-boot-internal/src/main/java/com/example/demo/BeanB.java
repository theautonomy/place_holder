package com.example.demo;

public class BeanB {
    public BeanB() {
        System.out.println("###### run BeanB constructor " + this.hashCode());
    }
}
