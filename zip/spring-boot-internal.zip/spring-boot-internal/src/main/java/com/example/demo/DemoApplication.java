package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

// The import can be here or in Config.java
// @Import({FirstImportSelector.class, FirstDeferredImportSelector.class,
// FirstImportBeanDefinitionRegistrar.class})
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication springApplication = new SpringApplication(DemoApplication.class);

        // Custom banner
        springApplication.setBanner(new FirstCustomBanner());

        // Why? https://github.com/spring-projects/spring-boot/issues/27945
        springApplication.addListeners(new FirstApplicationEventListener());

        // https://stackoverflow.com/questions/35217354/how-to-add-custom-applicationcontextinitializer-to-a-spring-boot-application
        // Ways to add ApplicationContextInitializer
        // 1. define the following in application.properties
        // context.initializer.classes=com.example.demo.FirstInitializer
        // As of 3.4, this way no longer works

        // 2. Register them in META-INF/spring.factories

        // 3. springApplication.addInitializers(new FirstApplicationContextInitializer());

        // 4. new SpringApplicationBuilder(YourApp.class)
        //      .initializers(YourInitializer.class);
        //      .run(args);
        springApplication.run();
    }
}
