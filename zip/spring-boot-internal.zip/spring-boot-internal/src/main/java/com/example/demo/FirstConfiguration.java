package com.example.demo;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(FirstConfigurationProperties.class)
public class FirstConfiguration {

    private final FirstConfigurationProperties properties;

    public FirstConfiguration(FirstConfigurationProperties properties) {
        this.properties = properties;
        System.out.println("###### FirstConfiguration itself is initialized");
    }

    @Bean
    @ConditionalOnMissingBean
    public FirstAutoConfigurationBean firstAutoConfigurationBean() {
        System.out.println("###### FirstAutoConfigurationBean to be created");
        return new FirstAutoConfigurationBean(properties.getMessage());
    }
}
