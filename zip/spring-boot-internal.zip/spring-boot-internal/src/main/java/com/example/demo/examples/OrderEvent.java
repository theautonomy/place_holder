package com.example.demo.examples;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.context.ApplicationEvent;

/**
 * Real-world example: Order Event
 *
 * <p>Custom event for order lifecycle management in an e-commerce system.
 */
public class OrderEvent extends ApplicationEvent {

    private final String orderId;
    private final String customerId;
    private final OrderStatus status;
    private final BigDecimal totalAmount;
    private final List<OrderItem> items;
    private final String paymentMethod;
    private final ShippingAddress shippingAddress;
    private final LocalDateTime orderDate;
    private final OrderEventType eventType;

    public OrderEvent(
            Object source,
            String orderId,
            String customerId,
            OrderStatus status,
            BigDecimal totalAmount,
            List<OrderItem> items,
            String paymentMethod,
            ShippingAddress shippingAddress,
            OrderEventType eventType) {
        super(source);
        this.orderId = orderId;
        this.customerId = customerId;
        this.status = status;
        this.totalAmount = totalAmount;
        this.items = items;
        this.paymentMethod = paymentMethod;
        this.shippingAddress = shippingAddress;
        this.eventType = eventType;
        this.orderDate = LocalDateTime.now();
    }

    // Getters
    public String getOrderId() {
        return orderId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public ShippingAddress getShippingAddress() {
        return shippingAddress;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public OrderEventType getEventType() {
        return eventType;
    }

    public enum OrderStatus {
        PENDING,
        CONFIRMED,
        PROCESSING,
        SHIPPED,
        DELIVERED,
        CANCELLED,
        REFUNDED
    }

    public enum OrderEventType {
        ORDER_CREATED,
        ORDER_CONFIRMED,
        ORDER_CANCELLED,
        ORDER_SHIPPED,
        ORDER_DELIVERED,
        PAYMENT_PROCESSED,
        PAYMENT_FAILED,
        REFUND_PROCESSED
    }

    public static class OrderItem {
        private final String productId;
        private final String productName;
        private final int quantity;
        private final BigDecimal unitPrice;

        public OrderItem(String productId, String productName, int quantity, BigDecimal unitPrice) {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
        }

        public String getProductId() {
            return productId;
        }

        public String getProductName() {
            return productName;
        }

        public int getQuantity() {
            return quantity;
        }

        public BigDecimal getUnitPrice() {
            return unitPrice;
        }

        public BigDecimal getTotalPrice() {
            return unitPrice.multiply(BigDecimal.valueOf(quantity));
        }
    }

    public static class ShippingAddress {
        private final String street;
        private final String city;
        private final String state;
        private final String zipCode;
        private final String country;

        public ShippingAddress(
                String street, String city, String state, String zipCode, String country) {
            this.street = street;
            this.city = city;
            this.state = state;
            this.zipCode = zipCode;
            this.country = country;
        }

        public String getStreet() {
            return street;
        }

        public String getCity() {
            return city;
        }

        public String getState() {
            return state;
        }

        public String getZipCode() {
            return zipCode;
        }

        public String getCountry() {
            return country;
        }
    }

    @Override
    public String toString() {
        return "OrderEvent{"
                + "orderId='"
                + orderId
                + '\''
                + ", customerId='"
                + customerId
                + '\''
                + ", status="
                + status
                + ", totalAmount="
                + totalAmount
                + ", eventType="
                + eventType
                + ", orderDate="
                + orderDate
                + '}';
    }
}
