package com.example.demo.examples;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertySource;

/**
 * Real-world example: Database Configuration Environment Post Processor
 *
 * <p>USE CASE: Loading database configuration from external systems or setting database URLs based
 * on environment before any beans are created.
 *
 * <p>SCENARIO: - In dev environment: use local H2 database - In staging: use staging PostgreSQL
 * with specific credentials - In prod: use production PostgreSQL from environment variables - Load
 * additional config from external config server
 */
public class DatabaseEnvironmentPostProcessor implements EnvironmentPostProcessor {

    @Override
    public void postProcessEnvironment(
            ConfigurableEnvironment environment, SpringApplication application) {
        System.out.println(
                "=== DatabaseEnvironmentPostProcessor: Loading database configuration ===");

        // Get active profiles
        String[] activeProfiles = environment.getActiveProfiles();
        String profile = activeProfiles.length > 0 ? activeProfiles[0] : "default";

        System.out.println("###Active profile: " + profile);

        // Create database configuration based on profile
        Map<String, Object> databaseConfig = new HashMap<>();

        switch (profile.toLowerCase()) {
            case "dev":
                configureDevelopmentDatabase(databaseConfig);
                break;
            case "staging":
                configureStagingDatabase(databaseConfig, environment);
                break;
            case "prod":
                configureProductionDatabase(databaseConfig, environment);
                break;
            default:
                configureDefaultDatabase(databaseConfig);
        }

        // Add external configuration (simulated)
        loadExternalConfiguration(databaseConfig, environment);

        // Create and add property source
        PropertySource<Map<String, Object>> databasePropertySource =
                new MapPropertySource("database-config", databaseConfig);

        // Add with high precedence (before application.properties)
        environment.getPropertySources().addFirst(databasePropertySource);

        System.out.println("###Database configuration loaded: " + databaseConfig);
        System.out.println("###=== DatabaseEnvironmentPostProcessor completed ===");
    }

    private void configureDevelopmentDatabase(Map<String, Object> config) {
        config.put("spring.datasource.url", "jdbc:h2:mem:devdb");
        config.put("spring.datasource.username", "sa");
        config.put("spring.datasource.password", "");
        config.put("spring.datasource.driver-class-name", "org.h2.Driver");
        config.put("spring.jpa.hibernate.ddl-auto", "create-drop");
        config.put("app.database.pool.max-size", "5");
        config.put("logging.level.org.hibernate.SQL", "DEBUG");
    }

    private void configureStagingDatabase(
            Map<String, Object> config, ConfigurableEnvironment environment) {
        // In real scenario, these might come from AWS Parameter Store, HashiCorp Vault, etc.
        config.put("spring.datasource.url", "jdbc:postgresql://staging-db:5432/stagingdb");
        config.put("spring.datasource.username", "staging_user");
        config.put("spring.datasource.password", getSecurePassword(environment, "staging"));
        config.put("spring.datasource.driver-class-name", "org.postgresql.Driver");
        config.put("spring.jpa.hibernate.ddl-auto", "validate");
        config.put("app.database.pool.max-size", "20");
        config.put("app.database.connection-timeout", "30000");
    }

    private void configureProductionDatabase(
            Map<String, Object> config, ConfigurableEnvironment environment) {
        // Production settings from environment variables
        String dbUrl =
                environment.getProperty("DATABASE_URL", "jdbc:postgresql://localhost:5432/proddb");
        String dbUser = environment.getProperty("DATABASE_USER", "prod_user");
        String dbPassword = environment.getProperty("DATABASE_PASSWORD", "");

        config.put("spring.datasource.url", dbUrl);
        config.put("spring.datasource.username", dbUser);
        config.put("spring.datasource.password", dbPassword);
        config.put("spring.datasource.driver-class-name", "org.postgresql.Driver");
        config.put("spring.jpa.hibernate.ddl-auto", "none");
        config.put("app.database.pool.max-size", "50");
        config.put("app.database.connection-timeout", "5000");
        config.put("app.database.read-only-replicas", "true");
    }

    private void configureDefaultDatabase(Map<String, Object> config) {
        config.put("spring.datasource.url", "jdbc:h2:mem:testdb");
        config.put("spring.datasource.username", "sa");
        config.put("spring.datasource.password", "");
        config.put("spring.datasource.driver-class-name", "org.h2.Driver");
        config.put("app.database.pool.max-size", "10");
    }

    private void loadExternalConfiguration(
            Map<String, Object> config, ConfigurableEnvironment environment) {
        // Simulate loading from external configuration service
        // In real world: Spring Cloud Config, Consul, etc.

        String configServerUrl = environment.getProperty("config.server.url");
        if (configServerUrl != null) {
            System.out.println("###Loading configuration from external server: " + configServerUrl);
            // Simulate external config loading
            config.put("app.feature.advanced-caching", "true");
            config.put("app.monitoring.metrics-enabled", "true");
            config.put("app.security.jwt.expiration", "3600");
        }
    }

    private String getSecurePassword(ConfigurableEnvironment environment, String env) {
        // In real scenario: integrate with HashiCorp Vault, AWS Secrets Manager, etc.
        String vaultUrl = environment.getProperty("vault.url");
        if (vaultUrl != null) {
            System.out.println("###Fetching password from vault for environment: " + env);
            return "vault-retrieved-password-" + env;
        }
        return "default-" + env + "-password";
    }
}
