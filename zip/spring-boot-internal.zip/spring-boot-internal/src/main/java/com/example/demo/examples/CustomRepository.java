package com.example.demo.examples;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to mark interfaces as custom repositories that should be automatically discovered and
 * registered by the RepositoryBeanDefinitionRegistrar.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface CustomRepository {

    /**
     * The name of the repository bean. If not specified, the name will be generated from the
     * interface name.
     */
    String value() default "";

    /** Query timeout in seconds for repository operations. */
    int queryTimeout() default 30;

    /** Whether to enable caching for this repository. */
    boolean enableCaching() default false;

    /** Whether to enable metrics collection for this repository. */
    boolean enableMetrics() default true;
}
