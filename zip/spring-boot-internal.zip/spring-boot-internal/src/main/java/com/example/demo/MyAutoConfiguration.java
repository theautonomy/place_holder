package com.example.demo;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import jakarta.annotation.PostConstruct;

@AutoConfiguration
@ConditionalOnClass(name = "java.lang.String") // Always true since String is always available
@ConditionalOnProperty(name = "demo.auto.enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(MyAutoConfigurationProperties.class)
public class MyAutoConfiguration {

    public MyAutoConfiguration() {
        System.out.println("######## MyAutoConfiguration - Class loaded and bean definitions being registered");
    }

    @Bean
    @ConditionalOnMissingBean(AutoConfiguredService.class)
    public AutoConfiguredService autoConfiguredService(MyAutoConfigurationProperties properties) {
        System.out.println("######## MyAutoConfiguration - Creating AutoConfiguredService bean with properties: " + properties);
        return new AutoConfiguredService(properties.getMessage(), properties.getTimeout(), properties.getServiceType());
    }

    public static class AutoConfiguredService {
        private final String message;
        private final int timeout;
        private final String serviceType;

        public AutoConfiguredService(String message, int timeout, String serviceType) {
            this.message = message;
            this.timeout = timeout;
            this.serviceType = serviceType;
        }

        @PostConstruct
        public void init() {
            System.out.println("######## AutoConfiguredService - Bean initialization completed (PostConstruct)");
        }

        public String getMessage() {
            return message;
        }

        public int getTimeout() {
            return timeout;
        }

        public String getServiceType() {
            return serviceType;
        }

        @Override
        public String toString() {
            return "AutoConfiguredService{" +
                    "message='" + message + '\'' +
                    ", timeout=" + timeout +
                    ", serviceType='" + serviceType + '\'' +
                    '}';
        }
    }
}