package com.example.demo.examples;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;

import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * Real-world example: Comprehensive Event Listener
 *
 * <p>USE CASE: Handles multiple types of business events in an enterprise application,
 * demonstrating different event handling patterns including synchronous, asynchronous, conditional,
 * and bulk processing.
 *
 * <p>SCENARIO: - Audit event logging for compliance - Order processing workflow management -
 * Real-time notifications - Analytics and reporting - Inventory management - Customer communication
 * - Fraud detection
 */
@Component
public class ComprehensiveEventListener {

    private final AuditLogger auditLogger;
    private final EmailNotificationService emailService;
    private final SlackNotificationService slackService;
    private final AnalyticsService analyticsService;
    private final InventoryService inventoryService;
    private final FraudDetectionService fraudDetectionService;
    private final CustomerService customerService;
    private final ReportingService reportingService;

    public ComprehensiveEventListener() {
        this.auditLogger = new AuditLogger();
        this.emailService = new EmailNotificationService();
        this.slackService = new SlackNotificationService();
        this.analyticsService = new AnalyticsService();
        this.inventoryService = new InventoryService();
        this.fraudDetectionService = new FraudDetectionService();
        this.customerService = new CustomerService();
        this.reportingService = new ReportingService();
    }

    // === AUDIT EVENT HANDLING ===

    @EventListener
    public void handleAuditEvent(AuditEvent event) {
        System.out.println("###### Processing Audit Event ===");
        System.out.println("###### User: " + event.getUserId() + " performed: " + event.getAction());

        // Log to audit database
        auditLogger.logAuditEvent(event);

        // Handle different audit levels
        switch (event.getLevel()) {
            case CRITICAL:
                handleCriticalAuditEvent(event);
                break;
            case WARNING:
                handleWarningAuditEvent(event);
                break;
            case INFO:
                handleInfoAuditEvent(event);
                break;
        }
    }

    private void handleCriticalAuditEvent(AuditEvent event) {
        System.out.println("###### CRITICAL AUDIT EVENT: " + event);

        // Immediate notification to security team
        slackService.sendSecurityAlert(
                "Critical audit event: " + event.getAction() + " by user " + event.getUserId());

        // Email notification
        emailService.sendSecurityAlert(event);

        // Log to security monitoring system
        auditLogger.logSecurityIncident(event);
    }

    private void handleWarningAuditEvent(AuditEvent event) {
        System.out.println("###### WARNING AUDIT EVENT: " + event);

        // Check for suspicious patterns
        if (fraudDetectionService.isSuspiciousActivity(event)) {
            slackService.sendSecurityAlert("Suspicious activity detected: " + event);
        }
    }

    private void handleInfoAuditEvent(AuditEvent event) {
        System.out.println("###### INFO AUDIT EVENT: " + event);

        // Just regular logging and analytics
        analyticsService.recordUserActivity(event);
    }

    // === ORDER EVENT HANDLING ===

    @EventListener
    public void handleOrderEvent(OrderEvent event) {
        System.out.println("###### Processing Order Event ===");
        System.out.println("###Order: " + event.getOrderId() + " - Event: " + event.getEventType());

        // Handle different order event types
        switch (event.getEventType()) {
            case ORDER_CREATED:
                handleOrderCreated(event);
                break;
            case ORDER_CONFIRMED:
                handleOrderConfirmed(event);
                break;
            case ORDER_SHIPPED:
                handleOrderShippedSync(event);
                break;
            case ORDER_DELIVERED:
                handleOrderDelivered(event);
                break;
            case ORDER_CANCELLED:
                handleOrderCancelled(event);
                break;
            case PAYMENT_PROCESSED:
                handlePaymentProcessed(event);
                break;
            case PAYMENT_FAILED:
                handlePaymentFailed(event);
                break;
            case REFUND_PROCESSED:
                handleRefundProcessed(event);
                break;
        }
    }

    private void handleOrderCreated(OrderEvent event) {
        System.out.println("###### Processing new order creation: " + event.getOrderId());

        // Synchronous operations (must complete before continuing)
        inventoryService.reserveItems(event.getItems());
        fraudDetectionService.checkOrderForFraud(event);
        auditLogger.logOrderCreation(event);

        // Asynchronous operations (can happen in background)
        CompletableFuture.runAsync(
                () -> {
                    customerService.sendOrderConfirmationEmail(event);
                    analyticsService.recordOrderCreation(event);
                    reportingService.updateOrderMetrics(event);
                });
    }

    private void handleOrderConfirmed(OrderEvent event) {
        System.out.println("###### Processing order confirmation: " + event.getOrderId());

        // Start fulfillment process
        inventoryService.allocateItems(event.getItems());

        // Customer notifications
        customerService.sendOrderConfirmationEmail(event);
        customerService.sendSMSNotification(
                event.getCustomerId(), "Your order " + event.getOrderId() + " has been confirmed!");

        // Internal notifications
        slackService.sendOrderNotification(
                "Order confirmed: " + event.getOrderId() + " - Amount: $" + event.getTotalAmount());
    }

    private void handleOrderShippedSync(OrderEvent event) {
        System.out.println("###### Processing order shipment: " + event.getOrderId());

        // Customer notification
        customerService.sendTrackingInformation(event);

        // Analytics (async version exists below)
        analyticsService.updateShippingMetrics(event);
    }

    @Async
    @EventListener
    public void handleOrderShippedAsync(OrderEvent event) {
        if (event.getEventType() == OrderEvent.OrderEventType.ORDER_SHIPPED) {
            System.out.println("###### Async processing order shipment: " + event.getOrderId());

            // These operations can take time, so run asynchronously
            customerService.sendTrackingInformation(event);
            analyticsService.updateShippingMetrics(event);
            reportingService.generateShippingReport(event);
        }
    }

    private void handleOrderDelivered(OrderEvent event) {
        System.out.println("###### Processing order delivery: " + event.getOrderId());

        // Customer follow-up
        customerService.sendDeliveryConfirmation(event);
        customerService.requestReview(event.getCustomerId(), event.getOrderId());

        // Analytics
        analyticsService.recordSuccessfulDelivery(event);

        // Update customer loyalty points
        customerService.awardLoyaltyPoints(event.getCustomerId(), event.getTotalAmount());
    }

    private void handleOrderCancelled(OrderEvent event) {
        System.out.println("###### Processing order cancellation: " + event.getOrderId());

        // Release reserved inventory
        inventoryService.releaseReservedItems(event.getItems());

        // Process refund if payment was already made
        if (event.getStatus() == OrderEvent.OrderStatus.CANCELLED) {
            // Trigger refund process (this would publish another event)
            System.out.println("###### Initiating refund for cancelled order: " + event.getOrderId());
        }

        // Customer notification
        customerService.sendCancellationNotification(event);

        // Analytics
        analyticsService.recordOrderCancellation(event);
    }

    private void handlePaymentProcessed(OrderEvent event) {
        System.out.println("###### Processing payment confirmation: " + event.getOrderId());

        // Send receipt
        customerService.sendPaymentReceipt(event);

        // Update accounting system
        reportingService.recordRevenue(event);

        // Fraud monitoring
        fraudDetectionService.analyzePaymentPattern(event);
    }

    private void handlePaymentFailed(OrderEvent event) {
        System.out.println("###### Processing payment failure: " + event.getOrderId());

        // Customer notification with retry options
        customerService.sendPaymentFailureNotification(event);

        // Internal alert
        slackService.sendPaymentFailureAlert("Payment failed for order: " + event.getOrderId());

        // Analytics
        analyticsService.recordPaymentFailure(event);
    }

    private void handleRefundProcessed(OrderEvent event) {
        System.out.println("###### Processing refund: " + event.getOrderId());

        // Customer notification
        customerService.sendRefundConfirmation(event);

        // Accounting update
        reportingService.recordRefund(event);

        // Customer service follow-up
        customerService.scheduleFollowUpCall(event.getCustomerId());
    }

    // === CONDITIONAL EVENT HANDLING ===

    @EventListener(
            condition = "#event.totalAmount.compareTo(T(java.math.BigDecimal).valueOf(1000)) >= 0")
    public void handleHighValueOrder(OrderEvent event) {
        if (event.getEventType() == OrderEvent.OrderEventType.ORDER_CREATED) {
            System.out.println("###### Processing High-Value Order (>= $1000) ===");

            // Special handling for high-value orders
            fraudDetectionService.performEnhancedFraudCheck(event);
            customerService.assignVIPSupport(event.getCustomerId());
            slackService.sendHighValueOrderAlert(event);

            // Expedited processing
            inventoryService.prioritizeOrder(event.getOrderId());
        }
    }

    @EventListener(
            condition =
                    "#event.level == T(com.example.demo.examples.AuditEvent.AuditLevel).CRITICAL "
                            + "&& #event.action.contains('DELETE')")
    public void handleCriticalDeleteActions(AuditEvent event) {
        System.out.println("###### Processing Critical Delete Action ===");

        // Immediate backup creation
        auditLogger.createEmergencyBackup(event);

        // Real-time notification to all administrators
        slackService.sendEmergencyAlert(
                "CRITICAL: Delete action performed by "
                        + event.getUserId()
                        + " on "
                        + event.getResourceType());

        // Lock the affected resource temporarily
        auditLogger.temporarilyLockResource(event.getResourceType(), event.getResourceId());
    }

    // === BULK/BATCH EVENT PROCESSING ===

    @Async
    @EventListener
    public void handleBulkAnalytics(OrderEvent event) {
        System.out.println("###### Processing Analytics (Async) ===");

        // This runs asynchronously to not block the main flow
        try {
            // Simulate complex analytics processing
            Thread.sleep(100); // Simulate processing time

            analyticsService.updateCustomerProfile(event.getCustomerId(), event);
            analyticsService.updateProductMetrics(event.getItems());
            analyticsService.updateGeographicMetrics(event.getShippingAddress());
            analyticsService.updatePaymentMethodMetrics(event.getPaymentMethod());

            System.out.println("###### Analytics processing completed for order: " + event.getOrderId());

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("###### Analytics processing interrupted for order: " + event.getOrderId());
        }
    }

    // Supporting service classes (simplified implementations)

    private static class AuditLogger {
        void logAuditEvent(AuditEvent event) {
            System.out.println(
                    "AUDIT LOG: "
                            + event.getEventTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                            + " - "
                            + event);
        }

        void logSecurityIncident(AuditEvent event) {
            System.out.println("###### SECURITY INCIDENT LOGGED: " + event);
        }

        void logOrderCreation(OrderEvent event) {
            System.out.println("###### ORDER AUDIT: Order created - " + event.getOrderId());
        }

        void createEmergencyBackup(AuditEvent event) {
            System.out.println("###### EMERGENCY BACKUP: Creating backup for " + event.getResourceType());
        }

        void temporarilyLockResource(String resourceType, String resourceId) {
            System.out.println("###### RESOURCE LOCKED: " + resourceType + ":" + resourceId);
        }
    }

    private static class EmailNotificationService {
        void sendSecurityAlert(AuditEvent event) {
            System.out.println("###### EMAIL: Security alert sent for " + event.getAction());
        }
    }

    private static class SlackNotificationService {
        void sendSecurityAlert(String message) {
            System.out.println("###### SLACK SECURITY: " + message);
        }

        void sendOrderNotification(String message) {
            System.out.println("###### SLACK ORDER: " + message);
        }

        void sendHighValueOrderAlert(OrderEvent event) {
            System.out.println(
                    "### SLACK HIGH VALUE: Order "
                            + event.getOrderId()
                            + " - $"
                            + event.getTotalAmount());
        }

        void sendPaymentFailureAlert(String message) {
            System.out.println("###### SLACK PAYMENT FAILURE: " + message);
        }

        void sendEmergencyAlert(String message) {
            System.out.println("###### SLACK EMERGENCY: " + message);
        }
    }

    private static class AnalyticsService {
        void recordUserActivity(AuditEvent event) {
            System.out.println("###### ANALYTICS: User activity recorded for " + event.getUserId());
        }

        void recordOrderCreation(OrderEvent event) {
            System.out.println("###### ANALYTICS: Order creation recorded");
        }

        void updateShippingMetrics(OrderEvent event) {
            System.out.println("###### ANALYTICS: Shipping metrics updated");
        }

        void recordSuccessfulDelivery(OrderEvent event) {
            System.out.println("###### ANALYTICS: Delivery success recorded");
        }

        void recordOrderCancellation(OrderEvent event) {
            System.out.println("###### ANALYTICS: Cancellation recorded");
        }

        void recordPaymentFailure(OrderEvent event) {
            System.out.println("###### ANALYTICS: Payment failure recorded");
        }

        void updateCustomerProfile(String customerId, OrderEvent event) {
            System.out.println("###### ANALYTICS: Customer profile updated for " + customerId);
        }

        void updateProductMetrics(java.util.List<OrderEvent.OrderItem> items) {
            System.out.println("###### ANALYTICS: Product metrics updated for " + items.size() + " items");
        }

        void updateGeographicMetrics(OrderEvent.ShippingAddress address) {
            System.out.println("###### ANALYTICS: Geographic metrics updated for " + address.getCity());
        }

        void updatePaymentMethodMetrics(String paymentMethod) {
            System.out.println("###### ANALYTICS: Payment method metrics updated for " + paymentMethod);
        }
    }

    private static class InventoryService {
        void reserveItems(java.util.List<OrderEvent.OrderItem> items) {
            System.out.println("###### INVENTORY: Reserved " + items.size() + " items");
        }

        void allocateItems(java.util.List<OrderEvent.OrderItem> items) {
            System.out.println("###### INVENTORY: Allocated " + items.size() + " items");
        }

        void releaseReservedItems(java.util.List<OrderEvent.OrderItem> items) {
            System.out.println("###### INVENTORY: Released " + items.size() + " reserved items");
        }

        void prioritizeOrder(String orderId) {
            System.out.println("###### INVENTORY: Order " + orderId + " prioritized");
        }
    }

    private static class FraudDetectionService {
        boolean isSuspiciousActivity(AuditEvent event) {
            System.out.println("###### FRAUD CHECK: Checking audit event for suspicious activity");
            return false; // Simplified
        }

        void checkOrderForFraud(OrderEvent event) {
            System.out.println("###### FRAUD CHECK: Basic fraud check for order " + event.getOrderId());
        }

        void performEnhancedFraudCheck(OrderEvent event) {
            System.out.println(
                    "### FRAUD CHECK: Enhanced fraud check for high-value order " + event.getOrderId());
        }

        void analyzePaymentPattern(OrderEvent event) {
            System.out.println(
                    "### FRAUD CHECK: Analyzing payment pattern for " + event.getCustomerId());
        }
    }

    private static class CustomerService {
        void sendOrderConfirmationEmail(OrderEvent event) {
            System.out.println(
                    "### CUSTOMER: Order confirmation sent to customer " + event.getCustomerId());
        }

        void sendSMSNotification(String customerId, String message) {
            System.out.println("###### CUSTOMER SMS: " + message + " (to " + customerId + ")");
        }

        void sendTrackingInformation(OrderEvent event) {
            System.out.println("###### CUSTOMER: Tracking info sent for order " + event.getOrderId());
        }

        void sendDeliveryConfirmation(OrderEvent event) {
            System.out.println("###### CUSTOMER: Delivery confirmation sent for " + event.getOrderId());
        }

        void requestReview(String customerId, String orderId) {
            System.out.println("###### CUSTOMER: Review request sent to " + customerId);
        }

        void awardLoyaltyPoints(String customerId, BigDecimal amount) {
            System.out.println("###### CUSTOMER: Loyalty points awarded to " + customerId);
        }

        void sendCancellationNotification(OrderEvent event) {
            System.out.println(
                    "### CUSTOMER: Cancellation notification sent for " + event.getOrderId());
        }

        void sendPaymentReceipt(OrderEvent event) {
            System.out.println("###### CUSTOMER: Payment receipt sent for " + event.getOrderId());
        }

        void sendPaymentFailureNotification(OrderEvent event) {
            System.out.println(
                    "### CUSTOMER: Payment failure notification sent for " + event.getOrderId());
        }

        void sendRefundConfirmation(OrderEvent event) {
            System.out.println("###### CUSTOMER: Refund confirmation sent for " + event.getOrderId());
        }

        void assignVIPSupport(String customerId) {
            System.out.println("###### CUSTOMER: VIP support assigned to " + customerId);
        }

        void scheduleFollowUpCall(String customerId) {
            System.out.println("###### CUSTOMER: Follow-up call scheduled for " + customerId);
        }
    }

    private static class ReportingService {
        void updateOrderMetrics(OrderEvent event) {
            System.out.println("###### REPORTING: Order metrics updated");
        }

        void generateShippingReport(OrderEvent event) {
            System.out.println("###### REPORTING: Shipping report generated");
        }

        void recordRevenue(OrderEvent event) {
            System.out.println("###### REPORTING: Revenue recorded - $" + event.getTotalAmount());
        }

        void recordRefund(OrderEvent event) {
            System.out.println("###### REPORTING: Refund recorded - $" + event.getTotalAmount());
        }
    }
}
