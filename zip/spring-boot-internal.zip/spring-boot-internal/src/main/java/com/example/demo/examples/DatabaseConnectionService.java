package com.example.demo.examples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

/**
 * Real-world example: Database Connection Service with Complete Lifecycle
 *
 * <p>USE CASE: A service that manages database connections with proper initialization, health
 * monitoring, and cleanup. Demonstrates the complete bean lifecycle: - Constructor injection
 * - @PostConstruct initialization - InitializingBean callback - Health monitoring during runtime
 * - @PreDestroy cleanup
 *
 * <p>SCENARIO: - Initialize database connection pool - Validate database connectivity - Set up
 * health monitoring - Handle connection failures gracefully - Clean shutdown with connection
 * cleanup
 */
@Service
public class DatabaseConnectionService implements InitializingBean {

    private Connection primaryConnection;
    private Connection readOnlyConnection;
    private ScheduledExecutorService healthCheckExecutor;
    private DatabaseHealthMonitor healthMonitor;
    private boolean initialized = false;

    // Database configuration (would typically be injected via @ConfigurationProperties)
    private final String primaryDbUrl = "jdbc:h2:mem:primarydb;DB_CLOSE_DELAY=-1";
    private final String readOnlyDbUrl = "jdbc:h2:mem:readonlydb;DB_CLOSE_DELAY=-1";
    private final String username = "sa";
    private final String password = "";

    public DatabaseConnectionService() {
        System.out.println("###=== DatabaseConnectionService: Constructor called ===");
        this.healthMonitor = new DatabaseHealthMonitor();
        System.out.println("###DatabaseConnectionService basic setup completed");
    }

    @PostConstruct
    public void initializeConnections() {
        System.out.println(
                "=== DatabaseConnectionService: @PostConstruct - Initializing database connections ===");

        try {
            // Step 1: Load database driver
            Class.forName("org.h2.Driver");
            System.out.println("###Database driver loaded successfully");

            // Step 2: Establish primary database connection
            primaryConnection = DriverManager.getConnection(primaryDbUrl, username, password);
            System.out.println("###Primary database connection established");

            // Step 3: Establish read-only connection
            readOnlyConnection = DriverManager.getConnection(readOnlyDbUrl, username, password);
            readOnlyConnection.setReadOnly(true);
            System.out.println("###Read-only database connection established");

            // Step 4: Initialize database schema (simplified)
            initializeDatabase();

            // Step 5: Set up connection monitoring
            setupConnectionMonitoring();

            System.out.println("###@PostConstruct initialization completed successfully");

        } catch (Exception e) {
            System.err.println("###Failed to initialize database connections: " + e.getMessage());
            e.printStackTrace();
            // In production, you might want to fail fast here
            throw new RuntimeException("Database initialization failed", e);
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println(
                "=== DatabaseConnectionService: InitializingBean.afterPropertiesSet() ===");

        // Additional initialization that requires all dependencies to be set
        validateConnections();
        setupHealthChecking();
        registerMetrics();

        this.initialized = true;
        System.out.println("###DatabaseConnectionService fully initialized and ready for use");
    }

    private void initializeDatabase() throws SQLException {
        System.out.println("###Initializing database schema...");

        // Create tables (simplified example)
        String createUsersTable =
                "CREATE TABLE IF NOT EXISTS users ("
                        + "id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                        + "username VARCHAR(255) NOT NULL, "
                        + "email VARCHAR(255) NOT NULL, "
                        + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";

        String createAuditTable =
                "CREATE TABLE IF NOT EXISTS audit_log ("
                        + "id BIGINT AUTO_INCREMENT PRIMARY KEY, "
                        + "user_id BIGINT, "
                        + "action VARCHAR(255), "
                        + "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";

        primaryConnection.createStatement().execute(createUsersTable);
        primaryConnection.createStatement().execute(createAuditTable);

        // Insert sample data
        String insertUser =
                "INSERT INTO users (username, email) VALUES ('admin', 'admin@example.com')";
        primaryConnection.createStatement().execute(insertUser);

        System.out.println("###Database schema initialized successfully");
    }

    private void setupConnectionMonitoring() {
        System.out.println("###Setting up connection monitoring...");

        // Monitor connection state every 30 seconds
        healthCheckExecutor =
                Executors.newSingleThreadScheduledExecutor(
                        r -> {
                            Thread t = new Thread(r, "DatabaseHealthChecker");
                            t.setDaemon(true);
                            return t;
                        });

        System.out.println("###Connection monitoring setup completed");
    }

    private void validateConnections() throws Exception {
        System.out.println("###Validating database connections...");

        // Validate primary connection
        if (!primaryConnection.isValid(5)) {
            throw new Exception("Primary database connection is not valid");
        }

        // Validate read-only connection
        if (!readOnlyConnection.isValid(5)) {
            throw new Exception("Read-only database connection is not valid");
        }

        // Test basic queries
        String testQuery = "SELECT 1";
        primaryConnection.createStatement().executeQuery(testQuery);
        readOnlyConnection.createStatement().executeQuery(testQuery);

        System.out.println("###All database connections validated successfully");
    }

    private void setupHealthChecking() {
        System.out.println("###Setting up health checking...");

        // Schedule periodic health checks
        healthCheckExecutor.scheduleWithFixedDelay(
                () -> {
                    try {
                        healthMonitor.performHealthCheck(primaryConnection, readOnlyConnection);
                    } catch (Exception e) {
                        System.err.println("###Health check failed: " + e.getMessage());
                        handleConnectionFailure();
                    }
                },
                30,
                30,
                TimeUnit.SECONDS);

        System.out.println("###Health checking scheduled successfully");
    }

    private void registerMetrics() {
        System.out.println("###Registering database metrics...");

        // In real implementation, this would register with Micrometer/Prometheus
        healthMonitor.registerMetrics();

        System.out.println("###Database metrics registered");
    }

    private void handleConnectionFailure() {
        System.out.println("###Handling connection failure - attempting to reconnect...");

        try {
            // Attempt to reconnect
            if (primaryConnection == null
                    || primaryConnection.isClosed()
                    || !primaryConnection.isValid(1)) {
                primaryConnection = DriverManager.getConnection(primaryDbUrl, username, password);
                System.out.println("###Primary connection restored");
            }

            if (readOnlyConnection == null
                    || readOnlyConnection.isClosed()
                    || !readOnlyConnection.isValid(1)) {
                readOnlyConnection = DriverManager.getConnection(readOnlyDbUrl, username, password);
                readOnlyConnection.setReadOnly(true);
                System.out.println("###Read-only connection restored");
            }

        } catch (SQLException e) {
            System.err.println("###Failed to restore connections: " + e.getMessage());
            // In production, trigger alerts here
        }
    }

    // Business methods that use the connections

    public void executeQuery(String sql) throws SQLException {
        if (!initialized) {
            throw new IllegalStateException("DatabaseConnectionService not yet initialized");
        }

        System.out.println("###Executing query: " + sql);
        primaryConnection.createStatement().executeQuery(sql);
    }

    public void executeReadOnlyQuery(String sql) throws SQLException {
        if (!initialized) {
            throw new IllegalStateException("DatabaseConnectionService not yet initialized");
        }

        System.out.println("###Executing read-only query: " + sql);
        readOnlyConnection.createStatement().executeQuery(sql);
    }

    public boolean isHealthy() {
        try {
            return primaryConnection != null
                    && primaryConnection.isValid(1)
                    && readOnlyConnection != null
                    && readOnlyConnection.isValid(1);
        } catch (SQLException e) {
            return false;
        }
    }

    @PreDestroy
    public void cleanup() {
        System.out.println(
                "=== DatabaseConnectionService: @PreDestroy - Cleaning up resources ===");

        // Step 1: Stop health checking
        if (healthCheckExecutor != null && !healthCheckExecutor.isShutdown()) {
            healthCheckExecutor.shutdown();
            try {
                if (!healthCheckExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    healthCheckExecutor.shutdownNow();
                }
                System.out.println("###Health check executor shut down successfully");
            } catch (InterruptedException e) {
                healthCheckExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        // Step 2: Close database connections
        closeConnection(primaryConnection, "Primary");
        closeConnection(readOnlyConnection, "Read-only");

        // Step 3: Unregister metrics
        if (healthMonitor != null) {
            healthMonitor.unregisterMetrics();
        }

        this.initialized = false;
        System.out.println("###DatabaseConnectionService cleanup completed");
    }

    private void closeConnection(Connection connection, String name) {
        if (connection != null) {
            try {
                if (!connection.isClosed()) {
                    connection.close();
                    System.out.println(name + " database connection closed successfully");
                }
            } catch (SQLException e) {
                System.err.println(
                        "Error closing " + name.toLowerCase() + " connection: " + e.getMessage());
            }
        }
    }

    // Supporting class for health monitoring
    private static class DatabaseHealthMonitor {
        public void performHealthCheck(Connection primary, Connection readOnly)
                throws SQLException {
            // Check primary connection
            if (!primary.isValid(5)) {
                throw new SQLException("Primary connection health check failed");
            }

            // Check read-only connection
            if (!readOnly.isValid(5)) {
                throw new SQLException("Read-only connection health check failed");
            }

            // Perform test queries
            primary.createStatement().executeQuery("SELECT 1");
            readOnly.createStatement().executeQuery("SELECT 1");

            System.out.println("###Database health check passed");
        }

        public void registerMetrics() {
            System.out.println("###Database metrics registered with monitoring system");
        }

        public void unregisterMetrics() {
            System.out.println("###Database metrics unregistered from monitoring system");
        }
    }
}
