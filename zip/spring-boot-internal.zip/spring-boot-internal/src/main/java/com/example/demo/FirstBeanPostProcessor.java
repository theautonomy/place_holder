package com.example.demo;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

@Component
public class FirstBeanPostProcessor implements BeanPostProcessor {

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName)
            throws BeansException {
        if (bean instanceof BeanA) {
            System.out.println(
                    "### run FirstBeanPostProcessor postProcessBeforeInitialization for BeanA "
                            + bean.hashCode());
        }
        if (bean instanceof BeanB) {
            System.out.println(
                    "### run FirstBeanPostProcessor postProcessBeforeInitialization for BeanB "
                            + bean.hashCode());
        }

        if (bean instanceof BeanC) {
            System.out.println(
                    "run FirstBeanPostProcessor postProcessBeforeInitialization for BeanC "
                            + bean.hashCode());
        }

        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName)
            throws BeansException {
        if (bean instanceof BeanA) {
            System.out.println(
                    "run FirstBeanPostProcessor postProcessAfterInitialization for BeanA "
                            + bean.hashCode());
        }
        if (bean instanceof BeanB) {
            System.out.println(
                    "run FirstBeanPostProcessor postProcessAfterInitialization for BeanB "
                            + bean.hashCode());
        }
        if (bean instanceof BeanC) {
            System.out.println(
                    "run FirstBeanPostProcessor postProcessAfterInitialization for BeanC "
                            + bean.hashCode());
        }

        return bean;
    }
}
