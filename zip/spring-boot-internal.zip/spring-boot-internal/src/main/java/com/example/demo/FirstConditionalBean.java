package com.example.demo;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(
        name = "demo.conditional.enabled",
        havingValue = "true",
        matchIfMissing = false)
public class FirstConditionalBean {

    public FirstConditionalBean() {
        System.out.println("###FirstConditionalBean created - conditional bean registration works!");
    }

    public void doSomething() {
        System.out.println("###FirstConditionalBean is doing something...");
    }
}
