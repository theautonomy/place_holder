# Spring Boot Extension Points and Components Guide

This document provides a comprehensive guide to Spring Boot's extension points and components, organized by their execution order during application startup. Each component is explained with its functionality, use cases, and implementation examples.

## Table of Contents

1. [Phase 1: Environment Preparation](#phase-1-environment-preparation)
2. [Phase 2: Context Initialization](#phase-2-context-initialization)
3. [Phase 3: Configuration Processing](#phase-3-configuration-processing)
4. [Phase 4: Bean Factory Processing](#phase-4-bean-factory-processing)
5. [Phase 5: Bean Instantiation & Processing](#phase-5-bean-instantiation--processing)
6. [Phase 6: Post-Startup Execution](#phase-6-post-startup-execution)
7. [Phase 7: Event System & Custom Components](#phase-7-event-system--custom-components)
8. [Complete Execution Order Summary](#complete-execution-order-summary)
9. [Frequently Asked Questions](#frequently-asked-questions)

## Phase 1: Environment Preparation

### 1. EnvironmentPostProcessor (Execution Order: #1)

**What it does:** Customizes the Environment object before the application context is refreshed.

**When it runs:** Very early in the Spring Boot startup process, before ApplicationContext creation.

**Use cases:**
- Set profiles programmatically based on environment variables
- Add custom property sources (databases, remote configs, etc.)
- Validate environment properties before startup
- Transform or decrypt configuration values

**When to use:**
- Need to modify environment before any beans are created
- Loading configuration from external sources
- Setting up profiles based on runtime conditions
- Environment-specific property transformations

**Implementation example:**
```java
@Component
public class MyFirstEnvironmentPostProcessor implements EnvironmentPostProcessor {
    @Override
    public void postProcessEnvironment(ConfigurableEnvironment environment,
                                     SpringApplication application) {
        // Add custom property sources, set profiles, etc.
    }
}
```

**Registration:** Must be registered in `META-INF/spring.factories`

---

### 2. Early ApplicationListener Events (Execution Order: #2)

**What it does:** Handles early application lifecycle events during environment preparation.

**Key Events in this phase:**
- `ApplicationStartingEvent` - Very first event, before any processing
- `ApplicationEnvironmentPreparedEvent` - Environment is ready but context not created

**When it runs:** During the earliest phases of application startup.

**Use cases:**
- Very early logging setup
- Environment validation
- Early monitoring/metrics initialization
- Custom startup banners or messages

**When to use:**
- Need to react to the very beginning of application startup
- Early validation or setup that must happen before context creation
- Monitoring or observability setup

**Implementation example:**
```java
public class EarlyApplicationEventListener implements ApplicationListener<ApplicationEvent> {
    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        if (event instanceof ApplicationStartingEvent) {
            // Very early startup logic
        } else if (event instanceof ApplicationEnvironmentPreparedEvent) {
            // Environment is ready
        }
    }
}
```

---

## Phase 2: Context Initialization

### 3. ApplicationContextInitializer (Execution Order: #3)

**What it does:** Initializes the ApplicationContext before beans are loaded.

**When it runs:** After Environment is prepared but before bean definitions are loaded.

**Use cases:**
- Set active profiles programmatically
- Add custom property sources to the context
- Register custom bean definition readers
- Configure the application context programmatically

**When to use:**
- Need to modify context configuration before beans are processed
- Dynamic profile activation based on runtime conditions
- Adding custom property sources that need context access
- Context-level customizations

**Implementation example:**
```java
public class FirstApplicationContextInitializer
    implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        // Configure the context before bean definitions are loaded
    }
}
```

**Registration methods:**
1. `META-INF/spring.factories`
2. `springApplication.addInitializers()`
3. `SpringApplicationBuilder.initializers()`

---

### 4. Context Initialization ApplicationListener Events (Execution Order: #4)

**Key Events in this phase:**
- `ApplicationContextInitializedEvent` - Context initialized but not loaded
- `ApplicationPreparedEvent` - Context loaded but not refreshed

**When it runs:** After context is initialized and prepared.

**Use cases:**
- Context validation
- Pre-refresh setup
- Configuration validation

---

## Phase 3: Configuration Processing

**Overview:** This phase processes all `@Configuration` classes and their `@Bean` methods to register bean definitions in the application context. Regular `@Configuration` classes are processed first, followed by auto-configuration classes.

### 5. @Configuration Classes and @Bean Definition Registration (Execution Order: #5)

**What it does:** Processes `@Configuration` classes and registers bean definitions for `@Bean` methods. Note that this only registers the bean definitions - actual bean creation happens later in Phase 5.

**When it runs:** During the configuration processing phase, after ApplicationPreparedEvent but before ImportSelector.

**Important Distinction:**
- **@Bean Definition Registration**: Happens in Phase 3 (this section) - visible in logs as "Registering bean definition for @Bean method..."
- **@Bean Method Execution**: Happens later in Phase 5 during bean instantiation - when actual objects are created

**Execution characteristics:**
- Runs after context initialization is complete  
- Processes before ImportSelector/DeferredImportSelector
- Bean definitions are registered but beans are NOT instantiated yet
- Logs show "Registering bean definition for @Bean method..." messages

**Use cases:**
- Defining application beans declaratively
- Creating conditional beans based on properties or classpath
- Configuring third-party library beans
- Setting up application infrastructure components

**When to use:**
- Need to create beans with complex initialization logic
- Configuring beans that require method-level customization
- Creating conditional configurations
- Defining application infrastructure

**Implementation example:**
```java
@Configuration
public class AppConfiguration {
    
    @Bean
    public DatabaseService databaseService(@Value("${db.url}") String dbUrl) {
        return new DatabaseService(dbUrl);
    }
    
    @Bean
    @ConditionalOnProperty("feature.cache.enabled")
    public CacheManager cacheManager() {
        return new RedisCacheManager();
    }
}
```

**Actual execution in logs:**
```
Phase 3: o.s.c.a.ConfigurationClassBeanDefinitionReader - Registering bean definition for @Bean method com.example.demo.Config.beanAFromConfig()
Phase 5: run Config for BeanA via @Bean 2021601975  # <-- Actual @Bean method execution
```

---

### 6. ImportSelector (Execution Order: #6)


**What it does:** Programmatically selects which @Configuration classes to import.

**When it runs:** During @Configuration class processing, early in the context refresh.

**Use cases:**
- Conditional configuration loading
- Dynamic @Configuration selection based on classpath
- Building @Enable* annotations
- Framework-level configuration selection

**When to use:**
- Need to conditionally import configurations
- Building reusable configuration modules
- Creating @Enable* style annotations
- Dynamic configuration based on environment

**Implementation example:**
```java
public class FirstImportSelector implements ImportSelector {
    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        // Return class names to import based on conditions
        return new String[]{"com.example.ConditionalConfig"};
    }
}
```

---

### 7. DeferredImportSelector (Execution Order: #7)

**What it does:** Like ImportSelector, but processed after all other @Configuration classes.

**When it runs:** After all regular @Configuration processing is complete.

**Use cases:**
- Auto-configuration (Spring Boot's primary use)
- Override configurations that need to run last
- Complex conditional imports that depend on other configurations

**When to use:**
- Need to import configurations that should override others
- Building auto-configuration modules
- Complex conditional logic that needs full context
- Framework-level configuration that should be processed last

**Implementation example:**
```java
public class FirstDeferredImportSelector implements DeferredImportSelector {
    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        // Return configurations to import after all others
        return new String[]{"com.example.AutoConfiguration"};
    }
}
```

---

### 8. ImportBeanDefinitionRegistrar (Execution Order: #8)

**What it does:** Registers additional bean definitions programmatically.

**When it runs:** During @Configuration class processing, alongside ImportSelector.

**Use cases:**
- Dynamic bean registration based on annotations
- Scanning and registering beans from specific packages
- Creating proxy beans
- Framework integration (like @EnableJpaRepositories)

**When to use:**
- Need to register beans dynamically at configuration time
- Building scanning-based frameworks
- Creating proxy or factory beans programmatically
- Custom bean registration logic

**Implementation example:**
```java
public class FirstImportBeanDefinitionRegistrar implements ImportBeanDefinitionRegistrar {
    @Override
    public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata,
                                      BeanDefinitionRegistry registry) {
        // Register additional bean definitions
    }
}
```

---

## Phase 4: Bean Factory Processing

### 9. BeanDefinitionRegistryPostProcessor (Execution Order: #9)

**What it does:** Modifies bean definitions before any beans are instantiated.

**When it runs:** After all bean definitions are loaded, before instantiation.

**Methods execution order:**
1. `postProcessBeanDefinitionRegistry()` - First method called
2. `postProcessBeanFactory()` - Called after registry processing

**Use cases:**
- Modify existing bean definitions
- Add additional bean definitions programmatically
- Implement custom scopes
- Bean definition validation

**When to use:**
- Need to modify bean definitions before instantiation
- Adding beans that weren't defined in configuration
- Implementing custom bean processing logic
- Framework-level bean definition manipulation

**Implementation example:**
```java
@Component
public class FirstBeanDefinitionRegistryPostProcessor
    implements BeanDefinitionRegistryPostProcessor {

    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
        // Modify or add bean definitions - RUNS FIRST
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
        // Process the bean factory - RUNS SECOND
    }
}
```

---

### 10. BeanFactoryPostProcessor (Execution Order: #10)

**What it does:** Customizes the bean factory after bean definitions are loaded.

**When it runs:** After BeanDefinitionRegistryPostProcessor, before bean instantiation.

**Use cases:**
- Modify bean factory configuration
- Add custom property resolution
- Register custom scopes
- Bean factory-level customizations

**When to use:**
- Need to customize the bean factory itself
- Implementing custom property resolution
- Adding framework-level bean factory features
- Custom scope registration

**Implementation example:**
```java
@Component
public class FirstBeanFactoryPostProcessor implements BeanFactoryPostProcessor {
    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
        // Customize the bean factory
    }
}
```

---

## Phase 5: Bean Instantiation & Processing

**Overview:** This phase creates actual bean instances from the bean definitions registered in earlier phases. This is where @Bean methods are actually executed to create objects.

### 11. @Bean Method Execution (During Bean Instantiation)

**What it does:** Executes the actual @Bean methods to create bean instances. This is when the method code runs and objects are created.

**When it runs:** During bean instantiation in Phase 5, not during @Configuration processing in Phase 3.

**Key Points:**
- @Bean definitions were registered in Phase 3
- @Bean method execution happens here in Phase 5 when beans are actually needed
- Methods run in the order determined by Spring's dependency resolution
- Each @Bean method execution is logged with custom messages from the method

**Execution order with other Phase 5 components:**
- Bean constructor called first
- @Bean method executes (if creating bean via @Bean)
- BeanPostProcessor.postProcessBeforeInitialization()
- @PostConstruct methods
- InitializingBean.afterPropertiesSet()
- BeanPostProcessor.postProcessAfterInitialization()

**Actual execution in logs:**
```
Line 1290: run Config for BeanA via @Bean 2021601975
Line 1311: run Config for BeanB via @Bean 1992630936  
Line 1324: FirstAutoConfigurationBean Created
```

---

### 12. BeanPostProcessor (Execution Order: #12-14)

**What it does:** Processes bean instances before and after initialization.

**When it runs:** During bean instantiation, around initialization methods.

**Execution flow for each bean:**
1. Bean constructor
2. Dependency injection  
3. @Bean method execution (if applicable) (#11)
4. `BeanPostProcessor.postProcessBeforeInitialization()` (#12)
5. `@PostConstruct` methods (#13)
6. `InitializingBean.afterPropertiesSet()` (#14)
7. `BeanPostProcessor.postProcessAfterInitialization()` (#15)

**Use cases:**
- Implementing AOP proxies
- Custom validation
- Dependency injection customization
- Bean modification or wrapping

**When to use:**
- Need to modify or wrap bean instances
- Implementing cross-cutting concerns
- Custom initialization logic
- AOP proxy creation

**Implementation example:**
```java
@Component
public class FirstBeanPostProcessor implements BeanPostProcessor {
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) {
        // Process before @PostConstruct, InitializingBean.afterPropertiesSet()
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) {
        // Process after initialization - common for creating proxies
        return bean;
    }
}
```

---

### 13. @PostConstruct (Execution Order: #13)

**What it does:** Executes custom initialization logic after dependency injection.

**When it runs:** After dependency injection, during bean initialization phase.

**Use cases:**
- Custom initialization logic
- Validation after dependency injection
- Setting up resources
- Complex object initialization

**When to use:**
- Need custom initialization after dependencies are set
- Validation of injected dependencies
- Resource setup that requires dependencies
- Simple initialization logic per bean

**Implementation example:**
```java
@Component
public class MyBean {
    @PostConstruct
    public void initialize() {
        // Custom initialization logic
    }
}
```

---

### 14. InitializingBean.afterPropertiesSet() (Execution Order: #14)

**What it does:** Executes initialization logic after all properties are set.

**When it runs:** After `@PostConstruct`, during bean initialization.

**Use cases:**
- Complex initialization logic
- Validation that requires multiple dependencies
- Resource setup
- Framework-level initialization

**When to use:**
- Need more control than `@PostConstruct`
- Complex initialization requiring multiple steps
- Framework or library integration
- When you need to throw checked exceptions during initialization

**Implementation example:**
```java
@Component
public class FirstInitializingBean implements InitializingBean {
    @Override
    public void afterPropertiesSet() throws Exception {
        // Complex initialization logic with exception handling
    }
}
```

---

### 15. SmartInitializingSingleton (Execution Order: #15)

**What it does:** Callback after all singleton beans are fully initialized.

**When it runs:** After all singletons are instantiated and initialized, before ApplicationStartedEvent.

**Use cases:**
- Global initialization that requires all beans to be ready
- Starting background services
- System-wide validation
- Final setup steps

**When to use:**
- Need to ensure all beans are ready before executing logic
- Global initialization tasks
- Starting services that depend on multiple beans
- System-wide validation or setup

**Implementation example:**
```java
@Component
public class FirstSmartInitializingSingleton implements SmartInitializingSingleton {
    @Override
    public void afterSingletonsInstantiated() {
        // All singletons are ready
    }
}
```

---

## Phase 6: Post-Startup Execution

### 16. ApplicationStartedEvent (Execution Order: #16)

**What it does:** Signals that the application context has been refreshed and is ready.

**When it runs:** After context refresh, before CommandLineRunner/ApplicationRunner.

**Use cases:**
- Post-startup monitoring setup
- Health check registration
- Metrics initialization
- Service registration

---

### 17. CommandLineRunner & ApplicationRunner (Execution Order: #17)

**What it does:** Executes code after the application has started.

**When it runs:** After the application context is refreshed and SmartInitializingSingleton callbacks.

**Execution order between the two:**
- Both run after ApplicationStartedEvent 
- Multiple runners are executed based on `@Order` annotation or `Ordered` interface
- If no order is specified, execution order is not guaranteed

**Difference:**
- `CommandLineRunner`: Receives raw String[] args
- `ApplicationRunner`: Receives parsed ApplicationArguments

**Use cases:**
- Database initialization or migration
- Cache warming
- Starting background processes
- Validating external dependencies
- Loading initial data

**When to use:**
- Need to execute code after full application startup
- Initialization that requires all beans to be ready
- One-time startup tasks
- Command-line argument processing

**Implementation example:**
```java
@Component
public class FirstApplicationRunner implements ApplicationRunner {
    @Override
    public void run(ApplicationArguments args) throws Exception {
        // Startup logic here
    }
}

@Component
public class FirstCommandRunner implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        // Startup logic here
    }
}
```

**Note:** In the actual execution logs, only ApplicationRunner execution may be visible, as CommandLineRunner execution depends on whether any CommandLineRunner beans are registered and executed.

---

### 18. ApplicationReadyEvent (Execution Order: #18)

**What it does:** Signals that the application is fully started and ready to service requests.

**When it runs:** After all CommandLineRunner and ApplicationRunner have completed.

**Use cases:**
- Final health check confirmations
- Service ready notifications
- External system notifications
- Load balancer registration

---

## Phase 7: Event System & Custom Components

### 19. @ConfigurationProperties (Used throughout phases)

**What it does:** Binds external configuration properties to Java objects with type safety.

**When it runs:** During bean creation when the configuration bean is needed.

**Use cases:**
- Type-safe configuration binding
- Validation of configuration properties
- Complex nested configuration objects
- IDE autocomplete for configuration

**When to use:**
- Need type-safe access to configuration properties
- Complex configuration with nested objects
- Want validation of configuration values
- Building reusable configuration modules

**Implementation example:**
```java
@ConfigurationProperties(prefix = "demo.first")
public class FirstConfigurationProperties {
    private String message = "Default message";
    private boolean enabled = true;
    private int timeout = 5000;

    // getters and setters
}
```

**Activation:**
```java
@Configuration
@EnableConfigurationProperties(FirstConfigurationProperties.class)
public class MyConfiguration {
    // Configuration beans
}
```

---

### 20. @Conditional Annotations (Used throughout configuration phase)

**What it does:** Conditionally registers beans based on various conditions.

**When it runs:** During configuration processing, affects which beans get registered.

**Common annotations:**
- `@ConditionalOnProperty` - Based on property values
- `@ConditionalOnClass` - Based on classpath presence
- `@ConditionalOnMissingBean` - When bean is not already defined
- `@ConditionalOnBean` - When specific bean exists
- `@ConditionalOnExpression` - Based on SpEL expressions

**Use cases:**
- Environment-specific bean registration
- Feature toggles
- Auto-configuration
- Optional dependency handling

**When to use:**
- Need to conditionally create beans
- Building auto-configuration modules
- Feature toggles or A/B testing
- Environment-specific configurations

**Implementation examples:**
```java
@Component
@ConditionalOnProperty(name = "feature.enabled", havingValue = "true")
public class ConditionalBean {
    // Only created when property is true
}

@Configuration
public class ConditionalConfig {
    @Bean
    @ConditionalOnMissingBean
    public ServiceBean serviceBean() {
        return new ServiceBean();
    }
}
```

**Custom conditions:**
```java
public class CustomCondition implements Condition {
    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        // Custom logic to determine if condition matches
        return true;
    }
}

@Bean
@Conditional(CustomCondition.class)
public MyBean conditionalBean() {
    return new MyBean();
}
```

**Important limitations:**
- Custom conditions **cannot directly use other Spring beans** as they are evaluated during the bean definition phase, before beans are instantiated
- However, you can access bean definitions or check bean existence through `ConditionContext`:
  ```java
  // Check if a bean definition exists
  context.getRegistry().containsBeanDefinition("myBean")
  
  // Access bean factory (risky - beans may not be ready yet)
  context.getBeanFactory().getBean(SomeBean.class)
  ```

---

### 21. @EventListener and Custom Events (Runtime - Throughout application lifecycle)

**What it does:** Provides a more flexible event handling mechanism than ApplicationListener.

**When it runs:** Throughout the application lifecycle - can be used at runtime for component communication.

**Use cases:**
- Decoupled communication between components
- Audit logging
- Cache invalidation
- Workflow orchestration
- Async processing triggers

**When to use:**
- Need decoupled component communication
- Building event-driven architectures
- Implementing observer patterns
- Cross-cutting concerns like auditing

**Implementation example:**
```java
// Custom event
public class FirstCustomEvent extends ApplicationEvent {
    private final String message;

    public FirstCustomEvent(Object source, String message) {
        super(source);
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}

// Event listener
@Component
public class EventHandler {
    @EventListener
    public void handleCustomEvent(FirstCustomEvent event) {
        // Handle the event
    }

    @EventListener
    @Async  // Can be async
    public void handleAsync(FirstCustomEvent event) {
        // Async event handling
    }
}

// Event publisher
@Component
public class EventPublisher {
    private final ApplicationEventPublisher eventPublisher;

    public void publishEvent(String message) {
        eventPublisher.publishEvent(new FirstCustomEvent(this, message));
    }
}
```

---

### 22. Custom Auto-Configuration (Processed during DeferredImportSelector phase)

**What it does:** Provides automatic configuration of beans based on classpath and properties.

**When it runs:** During the DeferredImportSelector phase, processed after regular configurations.

**Use cases:**
- Framework integration
- Starter modules
- Default configurations
- Convention over configuration

**When to use:**
- Building Spring Boot starters
- Providing default configurations for libraries
- Framework integration modules
- Convention-based configurations

**Implementation example:**
```java
@Configuration
@ConditionalOnClass(SomeLibraryClass.class)
@EnableConfigurationProperties(MyProperties.class)
public class MyAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public SomeService someService(MyProperties properties) {
        return new SomeService(properties);
    }
}
```

**Registration in `META-INF/spring.factories`:**
```properties
org.springframework.boot.autoconfigure.EnableAutoConfiguration=\
com.example.MyAutoConfiguration
```

---

### 23. Custom Banner (Execution Order: Before application startup)

**What it does:** Customizes the startup banner displayed when the application starts.

**Use cases:**
- Branding
- Version information display
- Custom startup messages
- Environment indicators

**When to use:**
- Want to customize application branding
- Display important startup information
- Differentiate between environments visually
- Add personality to your application

**Implementation example:**
```java
public class CustomBanner implements Banner {
    @Override
    public void printBanner(Environment environment, Class<?> sourceClass, PrintStream out) {
        out.println("###My Custom Application Banner");
        out.println("###Version: " + getClass().getPackage().getImplementationVersion());
    }
}

// Usage
public static void main(String[] args) {
    SpringApplication app = new SpringApplication(Application.class);
    app.setBanner(new CustomBanner());
    app.run(args);
}
```

---

## Complete Execution Order Summary

Here's the complete execution order of Spring Boot components during application startup:

**Note:** This sequence has been verified against actual console output from a Spring Boot application startup. Components that don't produce explicit logging (like @Configuration/@Bean processing) occur at their documented phases but may not be visible in console output.

### Phase 1: Environment Preparation
1. **Custom Banner** - Display custom startup banner
2. **EnvironmentPostProcessor** - Environment customization
3. **ApplicationListener** (ApplicationStartingEvent, ApplicationEnvironmentPreparedEvent)

### Phase 2: Context Initialization
4. **ApplicationContextInitializer** - Context setup
5. **ApplicationListener** (ApplicationContextInitializedEvent, ApplicationPreparedEvent)

### Phase 3: Configuration Processing
5. **@Configuration Classes and @Bean Definition Registration** - Process configuration classes and register bean definitions
6. **ImportSelector** - Configuration import (regular)
7. **DeferredImportSelector** - Configuration import (deferred, including auto-configuration)
8. **ImportBeanDefinitionRegistrar** - Dynamic bean registration

### Phase 4: Bean Factory Processing
9. **BeanDefinitionRegistryPostProcessor.postProcessBeanDefinitionRegistry()** - Bean definition modification
10. **BeanDefinitionRegistryPostProcessor.postProcessBeanFactory()** - Bean factory processing
11. **BeanFactoryPostProcessor** - Bean factory customization

### Phase 5: Bean Instantiation & Processing (Per Bean)
12. **Bean Constructor** - Bean instantiation
13. **Dependency Injection** - Property/field injection
14. **@Bean Method Execution** - Actual @Bean method calls to create objects (if applicable)
15. **BeanPostProcessor.postProcessBeforeInitialization()** - Pre-initialization processing
16. **@PostConstruct** - Post-construct methods
17. **InitializingBean.afterPropertiesSet()** - Initialization callback
18. **BeanPostProcessor.postProcessAfterInitialization()** - Post-initialization processing

### Phase 6: Post-Instantiation Callbacks
19. **SmartInitializingSingleton.afterSingletonsInstantiated()** - After all singletons ready

### Phase 7: Application Ready
20. **ApplicationListener** (ApplicationStartedEvent)
21. **CommandLineRunner** / **ApplicationRunner** - Post-startup execution
22. **ApplicationListener** (ApplicationReadyEvent)

### Runtime Components (Throughout Lifecycle)
- **@EventListener** and **Custom Events** - Event-driven communication
- **@Conditional** annotations - Evaluated during configuration phase
- **@ConfigurationProperties** - Bound when configuration beans are created

---

## Best Practices

### 1. Choose the Right Extension Point
- Use **EnvironmentPostProcessor** for environment-level changes
- Use **ApplicationContextInitializer** for context-level changes
- Use **BeanPostProcessor** for bean-level modifications
- Use **@EventListener** for decoupled communication

### 2. Consider Performance
- Earlier extension points have broader impact
- Avoid heavy processing in early lifecycle phases
- Use conditional annotations to avoid unnecessary bean creation

### 3. Error Handling
- Early lifecycle components can prevent application startup
- Implement proper error handling and logging
- Consider graceful degradation for optional features

### 4. Testing
- Test extension points in isolation
- Use Spring Boot test annotations for integration testing
- Mock external dependencies appropriately

### 5. Documentation
- Document custom extension points clearly
- Provide examples and use cases
- Consider creating Spring Boot starters for reusable components

---

## Frequently Asked Questions

### Q: Can Spring custom conditions use other Spring beans?

**A:** No. Spring's `Condition` interface is evaluated during the bean definition phase, before beans are instantiated. Custom conditions **cannot directly use other Spring beans** because:

1. Condition runs during bean definition registration phase
2. Only application context structure exists (bean definitions, environment, registry)  
3. Bean factory exists but is mostly empty - calling `getBeanFactory().getBean()` will likely fail

**What you CAN access through `ConditionContext`:**
- `getRegistry()` - Bean definition registry (what beans will be created)
- `getBeanFactory()` - Bean factory (mostly empty at this point)
- `getEnvironment()` - Environment properties and profiles
- `getResourceLoader()` - For loading resources

Conditions must rely on static information like system properties, environment variables, classpath presence, or bean definitions - not actual bean instances.

### Q: When does Spring Boot auto-configuration happen?

**A:** Spring Boot auto-configuration happens during the **DeferredImportSelector phase** in **Phase 3: Configuration Processing**, which is **after regular `@Configuration` classes** are processed.

**Execution timing:**
1. Regular `@Configuration` classes are processed first
2. Then `DeferredImportSelector` runs (including auto-configuration)
3. Auto-configuration classes are loaded from `META-INF/spring.factories`
4. They are processed based on their conditions (`@ConditionalOnClass`, `@ConditionalOnMissingBean`, etc.)

### Q: Does auto-configuration happen after `@Component` beans?

**A:** No, auto-configuration happens **before** `@Component` beans are instantiated. Here's the order:

1. **Phase 3: Configuration Processing**
   - `@Configuration` classes processed (bean definitions registered)
   - Auto-configuration runs (via `DeferredImportSelector`)
   - Component scanning happens (finds `@Component`, `@Service`, etc. and registers their bean definitions)

2. **Phase 5: Bean Instantiation**
   - All bean definitions (from `@Configuration`, auto-configuration, and `@Component`) are instantiated

So auto-configuration sees the **bean definitions** for `@Component` classes but not the actual instantiated beans.

### Q: When are beans created by auto-configuration actually initialized?

**A:** Auto-configuration in Phase 3 only **registers bean definitions** - it tells Spring "these beans should be created". The actual **bean instantiation** (calling constructors, running `@Bean` methods, dependency injection) happens later in Phase 5.

**Timeline:**
- **Phase 3**: Auto-configuration runs and registers bean definitions (`MyAutoConfiguration.someService()` method is NOT called yet)
- **Phase 5**: Spring instantiates all beans, including those from auto-configuration (`MyAutoConfiguration.someService()` method is NOW called and the actual bean object is created)

This is why auto-configuration can use `@ConditionalOnMissingBean` - it can see what bean definitions exist, but no beans are actually created yet, so there's no circular dependency issues.

### Q: How is the sequence processed when both `@Configuration` and auto-configuration define the same bean type?

**A:** When you have a `@Configuration` class that configures a bean (e.g., BeanA) via `@Bean` annotation, and an auto-configuration that will configure the same BeanA if missing, here's the exact sequence:

**Phase 3: Configuration Processing**

1. **Regular `@Configuration` classes processed first**
   - Your `@Configuration` class is processed
   - `@Bean` method for BeanA is registered as a bean definition
   - BeanA definition now exists in the registry

2. **Auto-configuration runs second (via DeferredImportSelector)**
   - Auto-configuration class is processed
   - Sees `@ConditionalOnMissingBean(BeanA.class)` 
   - Checks registry: `context.getRegistry().containsBeanDefinition("beanA")` returns `true`
   - Condition evaluates to `false` - auto-configuration BeanA is **NOT registered**

**Phase 5: Bean Instantiation**
3. **Only your user-defined BeanA gets instantiated**
   - Auto-configuration BeanA was never registered, so only your bean exists

This is exactly why auto-configuration runs after regular `@Configuration` - it allows `@ConditionalOnMissingBean` to work correctly by letting user configurations take precedence over defaults. The key insight: Both check for "missing bean" by looking at **bean definitions** (not instances), since no beans are instantiated yet in Phase 3.

### Q: Why does getBeanClassName() return null for @Bean methods in auto-configuration?

**A:** For `@Bean` methods in auto-configuration, Spring uses `ConfigurationClassBeanDefinition` which stores factory information differently than regular component beans:

- **getBeanClassName()**: Returns `null` because the actual class is determined at runtime when the factory method executes
- **getFactoryMethodName()**: Returns the `@Bean` method name (e.g., `autoConfiguredService`)
- **getFactoryBeanName()**: Returns the configuration bean instance name that contains the factory method

For `@Bean` methods, Spring doesn't store the target class name in the bean definition because:
1. The bean definition only knows about the **factory** (configuration class + method name) that will produce the bean
2. The actual class is determined when the factory method runs during bean instantiation
3. Spring uses `ConfigurationClassBeanDefinition` instead of `GenericBeanDefinition` for configuration-based beans

To get complete information about `@Bean` method registrations, check:
```java
BeanDefinition beanDef = registry.getBeanDefinition("beanName");
System.out.println("Type: " + beanDef.getClass().getSimpleName());
System.out.println("Factory method: " + beanDef.getFactoryMethodName());
System.out.println("Factory bean: " + beanDef.getFactoryBeanName());
```

---

This guide provides a comprehensive overview of Spring Boot's extension points. Each component serves specific use cases and fits into the application lifecycle at different points. Understanding when and how to use each component will help you build more robust and maintainable Spring Boot applications.
