@NullMarked
package demo.stackoverflow;

import org.jspecify.annotations.NullMarked;