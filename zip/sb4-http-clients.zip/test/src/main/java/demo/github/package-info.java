@NullMarked
package demo.github;

import org.jspecify.annotations.NullMarked;