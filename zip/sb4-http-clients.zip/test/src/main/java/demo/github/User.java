package demo.github;

public record User(String login, int id, String name) {
}
