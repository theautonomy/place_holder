@NullMarked
package demo;

import org.jspecify.annotations.NullMarked;