package com.sivalabs.springblog.domain.models;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER,
}
