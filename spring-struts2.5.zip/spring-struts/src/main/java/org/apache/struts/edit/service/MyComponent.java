package org.apache.struts.edit.service;

import org.springframework.stereotype.Component;

@Component
public class MyComponent {

    public String greeting() {
        return "hello world from my component";
    }
}
