package org.apache.struts.edit.service;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Utility class for retrieving Spring beans from the application context. This class implements
 * ApplicationContextAware to get access to the Spring context.
 */
@Component
public class SpringBeanUtil implements ApplicationContextAware {

    private static ApplicationContext applicationContext;

    /**
     * Set the ApplicationContext that this object runs in. This method is called by Spring
     * framework automatically.
     *
     * @param applicationContext the ApplicationContext object to be used by this object
     * @throws BeansException if thrown by application context methods
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        SpringBeanUtil.applicationContext = applicationContext;
    }

    /**
     * Get the application context.
     *
     * @return the application context
     */
    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    /**
     * Get a bean by its name.
     *
     * @param beanName the name of the bean
     * @return the bean instance
     * @throws BeansException if the bean could not be obtained
     */
    public static Object getBean(String beanName) throws BeansException {
        checkApplicationContext();
        return applicationContext.getBean(beanName);
    }

    /**
     * Get a bean by its type.
     *
     * @param beanClass the class type of the bean
     * @param <T> the type of the bean
     * @return the bean instance
     * @throws BeansException if the bean could not be obtained
     */
    public static <T> T getBean(Class<T> beanClass) throws BeansException {
        checkApplicationContext();
        return applicationContext.getBean(beanClass);
    }

    /**
     * Get a bean by its name and type.
     *
     * @param beanName the name of the bean
     * @param beanClass the class type of the bean
     * @param <T> the type of the bean
     * @return the bean instance
     * @throws BeansException if the bean could not be obtained
     */
    public static <T> T getBean(String beanName, Class<T> beanClass) throws BeansException {
        checkApplicationContext();
        return applicationContext.getBean(beanName, beanClass);
    }

    /**
     * Check if a bean with the given name exists.
     *
     * @param beanName the name of the bean
     * @return true if the bean exists, false otherwise
     */
    public static boolean containsBean(String beanName) {
        checkApplicationContext();
        return applicationContext.containsBean(beanName);
    }

    /**
     * Check if a bean of the given type exists.
     *
     * @param beanClass the class type of the bean
     * @return true if the bean exists, false otherwise
     */
    public static boolean containsBean(Class<?> beanClass) {
        checkApplicationContext();
        String[] beanNames = applicationContext.getBeanNamesForType(beanClass);
        return beanNames.length > 0;
    }

    /**
     * Get all bean names for the given type.
     *
     * @param beanClass the class type of the beans
     * @return array of bean names
     */
    public static String[] getBeanNamesForType(Class<?> beanClass) {
        checkApplicationContext();
        return applicationContext.getBeanNamesForType(beanClass);
    }

    /**
     * Get the type of the bean with the given name.
     *
     * @param beanName the name of the bean
     * @return the type of the bean, or null if not determinable
     */
    public static Class<?> getType(String beanName) {
        checkApplicationContext();
        return applicationContext.getType(beanName);
    }

    /**
     * Check if the application context is available.
     *
     * @throws IllegalStateException if the application context is not available
     */
    private static void checkApplicationContext() {
        if (applicationContext == null) {
            throw new IllegalStateException(
                    "ApplicationContext is not available. "
                            + "Make sure SpringBeanUtil is registered as a Spring component.");
        }
    }
}
