package com.attyuttam.dynamicdatasourcerouting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicDatasourceRoutingApplicationTests {

    @Test
    void contextLoads() {}
}
