package com.weili.datasource;

import org.junit.jupiter.api.Test;

// @SpringBootTest
class DynamicDatasourceRoutingApplicationTests {

    @Test
    void contextLoads() {}
}
