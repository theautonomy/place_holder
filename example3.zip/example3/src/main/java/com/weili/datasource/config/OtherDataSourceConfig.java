package com.weili.datasource.config;

import javax.sql.DataSource;

import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class OtherDataSourceConfig {

    private final RoutingDataSource routingDataSource;

    // You can further configure as below for transaction manager

    @Bean
    @Primary
    public DataSource dataSource() {
        return routingDataSource;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(
            EntityManagerFactoryBuilder builder) {
        return builder.dataSource(dataSource())
                .packages("com.weili.datasource")
                // .properties(properties)
                .build();
    }

    // Do this if the method name is not "transactionManager"
    // @Bean("transactionManager")

    // transaction manager for JPA
    @Bean
    @Primary
    public JpaTransactionManager transactionManager(
            LocalContainerEntityManagerFactoryBean entityManagerFactoryBean) {
        return new JpaTransactionManager(entityManagerFactoryBean.getObject());
    }

    // transaction manager for JDBCTemplate
    @Bean
    public DataSourceTransactionManager dataSourceTransactionManager(DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource());
    }
}
