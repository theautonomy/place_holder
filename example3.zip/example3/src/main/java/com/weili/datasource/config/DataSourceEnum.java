package com.weili.datasource.config;

public enum DataSourceEnum {
    DATASOURCE_ONE,
    DATASOURCE_TWO,
    DATASOURCE_THREE
}
