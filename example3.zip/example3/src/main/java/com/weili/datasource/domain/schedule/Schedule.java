package com.weili.datasource.domain.schedule;

import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "schedule")
public class Schedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "scheduleId")
    private int scheduleId;

    @Column(name = "name")
    private String name;

    @Column(name = "contact")
    private String contact;

    public String toString() {
        return scheduleId + "--" + name + "--" + contact;
    }
}
