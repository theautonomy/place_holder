package com.weili.datasource.domain;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.weili.datasource.config.DataSourceContextHolder;
import com.weili.datasource.config.DataSourceEnum;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmployeeService {
    private final EmployeeRepository employeeRepository;
    private final DataSourceContextHolder dataSourceContextHolder;

    public List<Employee> getAllEmployeeDetails() {
        try {
            return employeeRepository.findAll();
        } catch (RuntimeException ex) {
            throw new EmployeeDetailsNotFoundException(
                    "Could not find all employee details " + ex.getMessage());
        }
    }

    // The following annotation causes unexpected behavior
    // even though the transaction is read only.

    // Any transaction can NOT cross data sources
    // @Transactional(readOnly = true)
    public void listRecordsFromBoth() {
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        getAllEmployeeDetails().stream().forEach(System.out::println);
        DataSourceContextHolder.clearBranchContext();

        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_TWO);
        getAllEmployeeDetails().stream().forEach(System.out::println);
        DataSourceContextHolder.clearBranchContext();
    }

    @Transactional
    // default transaction level is read-write
    // same as: @Transactional(readOnly = false)
    public void save(Employee employee) {
        employeeRepository.save(employee);
    }

    // The following annotation causes unexpected behavior
    // as we are trying to cross data sources
    //
    // @Transactional(readOnly = false)
    public void saveToBothDatasources() {
        DataSourceContextHolder.clearBranchContext();
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        Employee e1 = new Employee();
        e1.setEmployeeName("Employee1 in Datasource 1");
        e1.setEmployeeRole("ADMIN");
        employeeRepository.save(e1);
        DataSourceContextHolder.clearBranchContext();

        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_TWO);
        System.out.println("\n\nSelect all records from source two");
        System.out.println("---------------------");
        getAllEmployeeDetails().stream().forEach(System.out::println);

        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_TWO);
        Employee e2 = new Employee();
        e2.setEmployeeName("Employee1 in Datasource 2");
        e2.setEmployeeRole("LEAD");
        employeeRepository.save(e2);
        DataSourceContextHolder.clearBranchContext();
    }

    // The following annotation works as long as we stay on one data source
    @Transactional(readOnly = false)
    public void saveToOneDatasource() {

        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        System.out.println("\n\nSelect all records from source one");
        System.out.println("---------------------");
        getAllEmployeeDetails().stream().forEach(System.out::println);

        DataSourceContextHolder.clearBranchContext();
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        Employee e1 = new Employee();
        e1.setEmployeeName("Employee1 in Datasource 1");
        e1.setEmployeeRole("ADMIN");
        employeeRepository.save(e1);

        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        System.out.println("\n\nSelect all records from source one");
        System.out.println("---------------------");
        getAllEmployeeDetails().stream().forEach(System.out::println);

        DataSourceContextHolder.clearBranchContext();
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        Employee e2 = new Employee();
        e2.setEmployeeName("Employee1 in Datasource 1");
        e2.setEmployeeRole("ADMIN");
        employeeRepository.save(e2);

        DataSourceContextHolder.clearBranchContext();
    }

    // The following annotation works as long as we stay on one data source
    @Transactional(readOnly = false)
    public void saveToOneDatasourceRollback() {
        DataSourceContextHolder.clearBranchContext();
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        Employee e1 = new Employee();
        e1.setEmployeeName("Employee1 in Datasource 1");
        e1.setEmployeeRole("ADMIN");
        employeeRepository.save(e1);

        // These 2 lines are not needed as we are not switching to a different data source anyway
        // It won't introduce unexpected behavior though
        DataSourceContextHolder.clearBranchContext();
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);

        // this insert fails during to primary key violation
        // the previous insert rolls back as well
        Employee e2 = new Employee();
        e1.setEmployeeId(1);
        e2.setEmployeeName("Employee1 in Datasource 2");
        e2.setEmployeeRole("ADMIN");
        employeeRepository.save(e2);

        DataSourceContextHolder.clearBranchContext();
    }
}
