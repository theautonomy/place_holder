package com.weili.datasource.config;

public class DataSourceContextHolder {
    private static ThreadLocal<DataSources> threadLocal = new ThreadLocal<>();

    public static void setBranchContext(DataSources dataSource) {
        threadLocal.set(dataSource);
    }

    public static DataSources getBranchContext() {
        return threadLocal.get();
    }

    public static void clearBranchContext() {
        threadLocal.remove();
    }
}
