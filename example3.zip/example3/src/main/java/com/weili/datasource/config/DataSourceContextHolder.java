package com.weili.datasource.config;

public class DataSourceContextHolder {
    private static ThreadLocal<String> threadLocal = new ThreadLocal<>();

    public static void setBranchContext(String dataSourceName) {
        threadLocal.set(dataSourceName);
    }

    public static String getBranchContext() {
        return threadLocal.get();
    }

    public static void clearBranchContext() {
        threadLocal.remove();
    }
}
