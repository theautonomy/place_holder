package com.weili.datasource.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

@Component
public class DataSourceRouting extends AbstractRoutingDataSource {
    private DataSourceContextHolder dataSourceContextHolder;

    public DataSourceRouting(
            DataSourceContextHolder dataSourceContextHolder,
            Map<DataSourceEnum, DataSource> datasources) {
        this.dataSourceContextHolder = dataSourceContextHolder;

        Map<Object, Object> dataSourceMap = new HashMap<>();
        datasources.entrySet().stream()
                .forEach(entry -> dataSourceMap.put(entry.getKey(), entry.getValue()));

        this.setTargetDataSources(dataSourceMap);
        this.setDefaultTargetDataSource(dataSourceMap.get(DataSourceEnum.DATASOURCE_ONE));
    }

    @Override
    protected Object determineCurrentLookupKey() {
        return dataSourceContextHolder.getBranchContext();
    }
}
