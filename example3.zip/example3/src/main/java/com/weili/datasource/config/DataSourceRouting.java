package com.weili.datasource.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

@Component
public class DataSourceRouting extends AbstractRoutingDataSource {

    public DataSourceRouting(Map<DataSources, DataSource> datasources) {
        Map<Object, Object> dataSourceMap = new HashMap<>();
        datasources.entrySet().stream()
                .forEach(entry -> dataSourceMap.put(entry.getKey(), entry.getValue()));

        this.setTargetDataSources(dataSourceMap);
        this.setDefaultTargetDataSource(dataSourceMap.get(DataSources.DATASOURCE_ONE));
    }

    @Override
    protected Object determineCurrentLookupKey() {
        return DataSourceContextHolder.getBranchContext();
    }
}
