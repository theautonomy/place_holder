package com.weili.datasource.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.util.StringUtils;

@ConfigurationProperties(prefix = "default.datasource")
public record DefaultDataSourceName(String name) {
    public DefaultDataSourceName {
        if (!StringUtils.hasText(name)) {
            throw new RuntimeException("Default data source needs to be set");
        }
    }
}
