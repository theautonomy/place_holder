package com.weili.datasource.domain;

public class EmployeeDetailsNotFoundException extends RuntimeException {
    public EmployeeDetailsNotFoundException(String message) {
        super(message);
    }
}
