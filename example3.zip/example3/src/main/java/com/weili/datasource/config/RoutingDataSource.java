package com.weili.datasource.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

@Component
public class RoutingDataSource extends AbstractRoutingDataSource {

    public RoutingDataSource(
            Map<String, DataSource> datasources,
            @Value("${default.datasource:none}") String default_datasource) {
        Map<Object, Object> dataSourceMap = new HashMap<>();
        datasources.entrySet().stream()
                .forEach(entry -> dataSourceMap.put(entry.getKey(), entry.getValue()));
        this.setTargetDataSources(dataSourceMap);
        if (datasources.containsKey(default_datasource.toUpperCase())) {
            this.setDefaultTargetDataSource(dataSourceMap.get(default_datasource.toUpperCase()));
        } else {
            this.setDefaultTargetDataSource(dataSourceMap.get("DATASOURCE_ONE"));
        }
    }

    @Override
    protected Object determineCurrentLookupKey() {
        return DataSourceContextHolder.getBranchContext();
    }
}
