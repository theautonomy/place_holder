package com.weili.datasource.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.stereotype.Component;

@Component
public class RoutingDataSource extends AbstractRoutingDataSource {

    public RoutingDataSource(
            Map<String, DataSource> datasources, DefaultDataSourceName defaultDataSourceName) {
        Map<Object, Object> dataSourceMap = new HashMap<>();
        datasources.entrySet().stream()
                .forEach(entry -> dataSourceMap.put(entry.getKey(), entry.getValue()));
        this.setTargetDataSources(dataSourceMap);
        if (datasources.containsKey(defaultDataSourceName.name().toUpperCase())) {
            this.setDefaultTargetDataSource(
                    dataSourceMap.get(defaultDataSourceName.name().toUpperCase()));
        } else {
            throw new RuntimeException("Default data source name is not right");
        }
    }

    @Override
    protected Object determineCurrentLookupKey() {
        return DataSourceContextHolder.getBranchContext();
    }
}
