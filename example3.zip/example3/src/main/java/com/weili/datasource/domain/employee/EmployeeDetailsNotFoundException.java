package com.weili.datasource.domain.employee;

public class EmployeeDetailsNotFoundException extends RuntimeException {
    public EmployeeDetailsNotFoundException(String message) {
        super(message);
    }
}
