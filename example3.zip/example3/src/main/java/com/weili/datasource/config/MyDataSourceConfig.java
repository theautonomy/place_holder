package com.weili.datasource.config;

import java.util.Map;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyDataSourceConfig {

    @ConfigurationProperties(prefix = "spring.datasource")
    private static record HikariConfigs(Map<String, HikariConfig> hikari) {
        HikariConfigs {
            hikari = Map.copyOf(hikari);
        }
    }

    @Bean
    Map<DataSourceEnum, DataSource> datasources(HikariConfigs hikariConfigs) {
        return Map.copyOf(
                hikariConfigs.hikari().entrySet().stream()
                        .collect(
                                Collectors.toUnmodifiableMap(
                                        entry ->
                                                DataSourceEnum.valueOf(
                                                        entry.getKey().toUpperCase()),
                                        entry -> new HikariDataSource(entry.getValue()))));
    }
}
