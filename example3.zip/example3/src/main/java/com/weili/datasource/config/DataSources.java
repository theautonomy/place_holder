package com.weili.datasource.config;

public enum DataSources {
    DATASOURCE_ONE,
    DATASOURCE_TWO,
    DATASOURCE_THREE
}
