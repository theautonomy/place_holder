package com.weili.datasource;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.weili.datasource.config.DataSourceContextHolder;
import com.weili.datasource.config.DataSourceEnum;
import com.weili.datasource.domain.Employee;
import com.weili.datasource.domain.EmployeeService;

@Component
public class MyCommandLineRunner implements CommandLineRunner {

    private final DataSourceContextHolder dataSourceContextHolder;
    private final EmployeeService employeeService;

    public MyCommandLineRunner(
            DataSourceContextHolder dataSourceContextHolder, EmployeeService employeeService) {
        this.dataSourceContextHolder = dataSourceContextHolder;
        this.employeeService = employeeService;
    }

    @Override
    public void run(String... args) throws Exception {

        // switch to use data source one
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_ONE);
        System.out.println("\n\nSelect all records from source one");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        System.out.println("\n\nInsert to data source one");
        System.out.println("---------------------");
        Employee e1 = new Employee();
        e1.setEmployeeName("Employee1 in Datasource 1");
        e1.setEmployeeRole("ADMIN");
        employeeService.save(e1);

        System.out.println("\n\nSelect all records from source one");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        DataSourceContextHolder.clearBranchContext();

        // switch to use data source two
        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_TWO);
        System.out.println("\n\nSelect all records from source two");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        System.out.println("\n\nInsert to data source two");
        System.out.println("---------------------");
        Employee e2 = new Employee();
        e2.setEmployeeName("Employee2 in Datasource 2");
        e2.setEmployeeRole("LEAD");
        employeeService.save(e2);

        System.out.println("\n\nSelect all records from source two");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        DataSourceContextHolder.clearBranchContext();

        dataSourceContextHolder.setBranchContext(DataSourceEnum.DATASOURCE_THREE);
        System.out.println("\n\nSelect all records from source three");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        System.out.println("\n\nInsert to data source three");
        System.out.println("---------------------");
        Employee e3 = new Employee();
        e3.setEmployeeName("Employee3 in Datasource 3");
        e3.setEmployeeRole("RUNNER");
        employeeService.save(e3);

        System.out.println("\n\nSelect all records from source three");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        DataSourceContextHolder.clearBranchContext();

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();

        System.out.println("\n\nInsert records to one data source");
        System.out.println("---------------------");
        employeeService.saveToOneDatasource();

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();

        System.out.println(
                "\n\nFail to insert records to one data source - rollback in both data sources");
        System.out.println("---------------------");
        try {
            employeeService.saveToOneDatasourceRollback();
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();

        System.out.println("\n\nInsert to two data sources");
        System.out.println("---------------------");
        employeeService.saveToBothDatasources();

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();
    }
}
