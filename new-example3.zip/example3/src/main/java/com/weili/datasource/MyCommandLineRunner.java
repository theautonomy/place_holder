package com.weili.datasource;

import com.weili.datasource.config.DataSourceContextHolder;
import com.weili.datasource.config.DataSourceName;
import com.weili.datasource.domain.Employee;
import com.weili.datasource.domain.EmployeeService;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MyCommandLineRunner implements CommandLineRunner {

    private final EmployeeService employeeService;

    public MyCommandLineRunner(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public void run(String... args) throws Exception {
        // switch to use data source one
        DataSourceContextHolder.setBranchContext(new DataSourceName("DATASOURCE_ONE"));
        System.out.println("\n\nSelect all records from source one");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        System.out.println("\n\nInsert one record to data source one");
        System.out.println("---------------------");
        Employee e1 = new Employee();
        e1.setEmployeeName("Employee1 in Datasource 1");
        e1.setEmployeeRole("ADMIN");
        employeeService.save(e1);

        System.out.println("\n\nSelect all records from source one");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        // switch to use data source two
        DataSourceContextHolder.setBranchContext(new DataSourceName("DATASOURCE_TWO"));
        System.out.println("\n\nSelect all records from source two");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        System.out.println("\n\nInsert to one data source two");
        System.out.println("---------------------");
        Employee e2 = new Employee();
        e2.setEmployeeName("Employee2 in Datasource 2");
        e2.setEmployeeRole("LEAD");
        employeeService.save(e2);

        System.out.println("\n\nSelect all records from source two");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        DataSourceContextHolder.setBranchContext(new DataSourceName("DATASOURCE_THREE"));
        System.out.println("\n\nSelect all records from source three");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        System.out.println("\n\nInsert one record to data source three");
        System.out.println("---------------------");
        Employee e3 = new Employee();
        e3.setEmployeeName("Employee3 in Datasource 3");
        e3.setEmployeeRole("RUNNER");
        employeeService.save(e3);

        System.out.println("\n\nSelect all records from source three");
        System.out.println("---------------------");
        employeeService.getAllEmployeeDetails().stream().forEach(System.out::println);

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();

        System.out.println("\n\nInsert two records to one data source");
        System.out.println("---------------------");
        employeeService.insertToDatasourceOne();

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();

        System.out.println(
                "\n\nFail to insert records to one data source - rollback in both data sources");
        System.out.println("---------------------");
        try {
            employeeService.insertToDatasourceOneFailAndRollback();
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();

        System.out.println("\n\nInsert one record to two data sources");
        System.out.println("---------------------");
        employeeService.insertToBothDatasources();

        System.out.println("\n\nSelect records from both data sources");
        System.out.println("---------------------");
        employeeService.listRecordsFromBoth();
    }
}
