package com.weili.datasource.config;

public record DataSourceName(String name) {}
