package com.weili.datasource.config;

public class DataSourceContextHolder {
    private static ThreadLocal<DataSourceName> threadLocal = new ThreadLocal<>();

    public static void setBranchContext(DataSourceName dataSourceName) {
        threadLocal.set(dataSourceName);
    }

    public static DataSourceName getBranchContext() {
        return threadLocal.get();
    }

    public static void clearBranchContext() {
        threadLocal.remove();
    }
}
