---
name: wiki-ingest
description: Ingest source files into the wiki (LLM wiki pattern). Usage: /wiki-ingest [path]
---

# Wiki Ingest Skill

Ingest source code into the wiki following the LLM wiki pattern (Karpathy).
Source code is the immutable source of truth. The wiki is the LLM-maintained artifact.

## Arguments

Parse `$ARGUMENTS` — optional: one or more file paths, directories, or glob patterns to ingest.
If empty, ingest the entire project root (see Step 1 for exclusions). Do not ask the user for a path.

---

## Step 0 — Locate the wiki

Check in order: `wiki/`, `obsidian/`, `docs/wiki/`.
If none exist, ask the user.
If a `SCHEMA.md` exists inside the wiki directory, read it first and follow its conventions over the defaults below.

---

## Step 1 — Determine source scope

If `$ARGUMENTS` is provided, use those paths.

Otherwise, ingest the **project root** and exclude:
- The wiki directory itself (whichever of `wiki/`, `obsidian/`, `docs/wiki/` was found in Step 0)
- `.git/`, `.claude/`, `.idea/`, `.vscode/`, `node_modules/`, `target/`, `build/`, `dist/`, `out/`
- Binary and generated files: `*.class`, `*.jar`, `*.png`, `*.jpg`, `*.svg`, `*.json` (unless it is a config file like `pom.xml`, `package.json`, `application.properties`)
- Lock files: `*.lock`, `package-lock.json`, `yarn.lock`

---

## Step 2 — Read the source

Read every file in the resolved scope. For each file understand:
- What entities are defined (classes, functions, interfaces, modules)
- What each entity does and **why** it exists
- Non-obvious behavior: caching, lazy init, defensive copies, workarounds, gotchas
- Dependencies on other parts of the codebase (imports, injected services, config)
- Public contracts (API surface, return types, thrown exceptions)
- Operational requirements: env vars, external services, one-time setup steps

---

## Step 3 — Check existing wiki

Read `index.md` (or `Index.md`) in the wiki root to understand what pages already exist.
Identify which existing pages are related to what you just read.

---

## Step 4 — Identify diagram opportunities

Before writing any page, scan the source for patterns that are clearer as Mermaid than prose.
Add a Mermaid diagram to the page whenever any of the following applies:

| Pattern in source | Diagram type |
|---|---|
| Request travels through 2+ components or systems | `sequenceDiagram` |
| Startup / initialization sequence with multiple steps | `sequenceDiagram` |
| Branching decision logic (if/else chains, routing) | `flowchart` |
| State transitions (lifecycle, status fields, enums) | `stateDiagram-v2` |
| Class / module relationships (inheritance, composition) | `classDiagram` |
| Component / service architecture overview | `flowchart` |
| Data pipeline (transform → store → query) | `flowchart` |

When in doubt, prefer a diagram over an ASCII equivalent or a prose description.
A page may contain more than one diagram if the subject warrants it.

---

## Step 5 — Create or update entity pages

For each significant entity (class, service, controller, module, integration, data model):
- If no page exists → create `<wiki>/<Category>/<EntityName>.md`
- If a page exists → update it; do not delete existing content unless it is wrong

Use `[[WikiLinks]]` for all cross-references. Keep pages dense and factual, not tutorial-style.

**Choose the page format based on the source type:**

### HTTP controller
```
---
tags: [feature]
source: <path>
last-updated: <YYYY-MM-DD>
---
# ControllerName

One-sentence purpose.

## Endpoints

| Method | Path | Auth | Response | Description |
|--------|------|------|----------|-------------|
| GET    | /foo | public | HTML | ... |
| POST   | /foo | login | JSON | ... |

## Request / response models
Field tables or links to [[DomainRecords]].

## Sequence diagram (if non-trivial flow)
```mermaid
sequenceDiagram
...
```

## Notes
Non-obvious behavior, gotchas, edge cases.
```

### Service / business logic
```
---
tags: [feature|architecture]
source: <path>
last-updated: <YYYY-MM-DD>
---
# ServiceName

One-sentence purpose.

## Responsibilities
- ...

## State & caching
Describe any in-memory state, caching strategy, and eviction (or lack thereof).

## Key methods
| Method | Signature | Notes |
|--------|-----------|-------|
| ...    | ...       | ...   |

## Dependencies
- [[OtherService]] — why it is used

## Operational notes
Steps a developer must know: how to reset state, regenerate data, trigger reloads.
```

### Configuration / properties file
```
---
tags: [configuration]
source: <path>
last-updated: <YYYY-MM-DD>
---
# Configuration

## Required environment variables
| Variable | Purpose | Example |
|----------|---------|---------|
| ...      | ...     | ...     |

## Key properties
| Property | Env var override | Default | Purpose |
|----------|-----------------|---------|---------|
| ...      | ...             | ...     | ...     |

## Notes
Anything non-obvious about profiles, precedence, or runtime behavior.
```

### Data record / DTO / domain object
```
---
tags: [data-models]
source: <path>
last-updated: <YYYY-MM-DD>
---
# RecordName

One-sentence purpose. Note the source (external API, form binding, internal).

## Fields
| Field | Type | Notes |
|-------|------|-------|
| ...   | ...  | ...   |

## Example (for external API payloads)
```json
{ ... }
```

## Used by
- [[Controller]] — context
```

### External API integration
```
---
tags: [integrations]
source: <path>
last-updated: <YYYY-MM-DD>
---
# ExternalApiName

What the API provides and why this app uses it.

## Endpoints used
| Method | URL | Purpose |
|--------|-----|---------|
| ...    | ... | ...     |

## Error handling
How the app handles failures (timeouts, 4xx, 5xx).

## Gotchas
Rate limits, time-limited URLs, auth requirements, known quirks.
```

### Frontend / JS module
```
---
tags: [architecture]
source: <path>
last-updated: <YYYY-MM-DD>
---
# ModuleName

One-sentence purpose.

## Features
Bulleted list of user-facing capabilities.

## Key interactions
HTMX patterns, fetch calls, event listeners, localStorage usage.

## Flowchart (if non-trivial state or transitions)
```mermaid
flowchart ...
```
```

### Architecture / concept page
```
---
tags: [architecture]
source: <path(s)>
last-updated: <YYYY-MM-DD>
---
# ConceptName

One-sentence summary.

## Diagram
```mermaid
...
```

## Narrative
Prose explaining what the diagram shows and why the design is this way.

## Operational notes
How to configure, regenerate, or change this part of the system.
```

---

Default categories (adapt to project's SCHEMA.md if present):
- `Features/` — user-facing feature groups (often one controller + its service)
- `Architecture/` — cross-cutting concerns, data flow, infrastructure
- `Security/` — auth, CSRF, credentials
- `Data Models/` — DTOs, records, domain objects
- `Configuration/` — config classes, properties files
- `Integrations/` — external APIs, databases, third-party clients

---

## Step 6 — Capture operational knowledge

For every page, ask: *what does a developer need to know to operate or change this?*
If the answer is non-trivial, add an **Operational notes** section covering:
- Required environment variables or secrets
- One-time setup steps (e.g. regenerating embeddings, seeding a database)
- Resources that expire or must be refreshed
- How to add, remove, or change configuration (users, credentials, feature flags)
- Known failure modes and how to recover

This is the knowledge most likely to be lost without the wiki.

---

## Step 7 — Update cross-references

For each page created or updated, open the most closely related existing pages and add a `[[link]]` where a reader of that page would benefit from knowing about this one. Do not rewrite existing content — only add the reference. Aim for bidirectional links: if A links to B, check whether B should link back to A.

---

## Step 8 — Update index.md

For each new or updated page, ensure `index.md` has an entry:
```
- [[PageName]] — one-line summary
```
Organised by category. Add the category heading if it doesn't exist.

---

## Step 9 — Append to log.md

Append one entry to `log.md`:
```
## [YYYY-MM-DD] ingest | <what was ingested, one line>
Files: <list of source files processed>
Pages created: <list>
Pages updated: <list>
```
