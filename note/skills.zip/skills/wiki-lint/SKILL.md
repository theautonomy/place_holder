---
name: wiki-lint
description: Health-check the wiki and report issues. Usage: /wiki-lint [--fix] [--full]
---

# Wiki Lint Skill

Health-check the LLM-maintained wiki (Karpathy pattern) and report structural issues. Optionally auto-fix simple ones.

## Arguments

Parse `$ARGUMENTS` for optional flags:
- `--fix` — auto-fix simple issues (missing index entries, log entry)
- `--full` — also check source freshness (requires `source:` frontmatter on pages)

---

## Step 0 — Locate the wiki

Check in order: `wiki/`, `obsidian/`, `docs/wiki/`.
If none found, tell the user and stop.
Read `SCHEMA.md` inside the wiki root if present — its conventions override the defaults below.

---

## Step 1 — Collect all pages

List every `.md` file in the wiki directory recursively.
Exclude: `index.md` (or `Index.md`), `log.md`, `SCHEMA.md`.

Read `index.md` (or `Index.md`) to get the expected page list and understand the category structure.

---

## Step 2 — Check each issue type

Work through all checks before reporting. Collect every finding.

### Orphan pages
Pages that exist on disk but:
- have no entry in `index.md`, AND
- are not the target of any `[[link]]` in any other page.

### Missing index entries
Pages on disk that have no corresponding entry in `index.md`.

### Broken wikilinks
`[[Target]]` or `[[Target|Alias]]` references in any page where no file matching `Target.md` exists anywhere in the wiki directory tree.
- Strip the `#anchor` fragment when checking (e.g. `[[Page#Section]]` checks for `Page.md`).
- Backslash-escaped pipes `[[Target\|Alias]]` count the same as `[[Target|Alias]]`.

### Stub pages
Pages with fewer than 5 lines of real content (excluding YAML frontmatter lines and blank lines).

### Missing source references
Pages whose YAML frontmatter has no `source:` field. Without it, source-drift detection (`--full`) cannot work.

### Source drift (`--full` only)
For pages that do have a `source:` frontmatter field:
- Read the source file and get its last-modified timestamp.
- Compare to the page's `last-updated:` frontmatter field.
- Flag as potentially stale if the source was modified after `last-updated`.

### Concepts mentioned but no page
Scan all `[[Links]]` across all pages. Any link target that has no matching `.md` file anywhere in the wiki is a concept referenced but never written up. (Broken wikilinks and missing concept pages are the same check — report them together.)

---

## Step 3 — Report

Print the full report in this format. Always show every section even if count is 0.

```
## Wiki Lint Report — YYYY-MM-DD

### Orphan pages (N)
- wiki/Category/Page.md

### Missing index entries (N)
- wiki/Category/Page.md

### Broken wikilinks / Missing concept pages (N)
- [[Target]] — referenced in [[SourcePage]]

### Stale pages (N)  ← only with --full
- [[Page]] — source modified YYYY-MM-DD, wiki last-updated YYYY-MM-DD

### Stub pages (N)
- [[Page]] — N lines of content

### Missing source references (N)
- wiki/Category/Page.md
```

End the report with a one-line overall health summary, e.g.:
> **Overall health: good.** Zero broken links, no orphans, no stubs. 24 pages lack `source:` frontmatter — staleness detection unavailable until added.

---

## Step 4 — Fix (only if `--fix` was passed)

Auto-fix **simple structural issues only**, without asking:

1. **Missing index entries** — add entries for known pages under the appropriate category heading in `index.md`. Use the page's `#` heading as the link text.
2. **Log entry** — append to `log.md` (create it if absent):
   ```
   ## [YYYY-MM-DD] lint | fixed N issues
   Fixed: <comma-separated list of what was fixed>
   ```

Do **not** invent content for:
- Stub pages
- Missing concept pages
- Source references

For these, list them under **"Recommended next ingests"** and stop:
```
## Recommended next ingests
- [[MissingConcept]] — referenced in [[Page]] but has no wiki page yet
- [[StubPage]] — only 2 lines; needs fuller content
```
