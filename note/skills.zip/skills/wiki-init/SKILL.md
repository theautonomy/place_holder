---
name: wiki-init
description: Bootstrap a new wiki for a codebase from scratch. Usage: /wiki-init [wiki-dir]
---

# Wiki Init Skill

Bootstrap a new wiki for a codebase from scratch, following the LLM wiki pattern.
Run this once at the start of a new project. It scans the source, creates the wiki structure,
and produces an initial index, schema, and high-level overview page.

## Arguments

Parse `$ARGUMENTS` — optional path to the wiki directory to create (default: `wiki/`).
If the directory already contains files, confirm with the user before proceeding.

---

## Step 1 — Understand the project

Without reading every file yet, get a broad picture:
- Read `README.md` or `README.adoc` if present
- Look at the top-level directory structure
- Identify the language, framework, and major modules (e.g. `src/main/java/...` packages, `src/` subdirs, `packages/`, etc.)
- Identify any existing docs (`docs/`, `*.md` at root)

---

## Step 2 — Propose wiki structure

Based on Step 1, propose a category structure for the wiki. Default suggestion:
```
wiki/
  SCHEMA.md       ← conventions and workflow for this project
  index.md        ← catalogue of all pages
  log.md          ← append-only operation log
  Overview.md     ← high-level project summary
  <Category>/     ← one directory per major category
    ...
```
Ask the user to confirm or adjust the category list before continuing.

---

## Step 3 — Create SCHEMA.md

Write `<wiki>/SCHEMA.md` documenting:
- Wiki directory path
- Category list and what belongs in each
- Page frontmatter conventions (`tags`, `source`, `last-updated`)
- Wikilink format (`[[PageName]]`)
- Log entry format
- Any project-specific conventions (e.g. naming patterns, what NOT to document)

This file is the contract between future wiki-* skills and this project.

---

## Step 4 — Create Overview.md

Write `<wiki>/Overview.md`:
- What the project does (1-2 paragraphs)
- Tech stack (language, framework, key libraries)
- High-level architecture — express as a Mermaid `flowchart` or `sequenceDiagram` showing how major modules relate and how requests flow. Fall back to prose only if the architecture cannot be meaningfully diagrammed.
- Entry points (main class, API base URL, etc.)
- Required environment variables / secrets needed to run the app
- Links to the top-level category pages once they exist

---

## Step 5 — Create index.md and log.md

`index.md` — start with just the Overview entry:
```
# Wiki Index

## Overview
- [[Overview]] — high-level project summary

## <Category>
(pages will be added here as ingested)
```

`log.md` — first entry:
```
## [YYYY-MM-DD] init | wiki initialised
Source root: <path>
Categories: <list>
```

---

## Step 6 — Recommend first ingests

Based on the project structure, suggest 3-5 specific files or directories to ingest first with `/wiki-ingest` — typically the main entry point, the core domain model, and the most central service or module. Print these as ready-to-run commands:
```
/wiki-ingest src/main/java/com/example/service/CoreService.java
/wiki-ingest src/main/java/com/example/model/
```
