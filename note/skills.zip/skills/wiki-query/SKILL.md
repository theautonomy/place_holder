---
name: wiki-query
description: Answer questions using the wiki as the primary knowledge source. Usage: /wiki-query <question>
---

# Wiki Query Skill

Answer a question using the wiki as the primary knowledge source.
The wiki is the compiled, interlinked knowledge base — prefer it over re-reading raw source.

## Arguments

Parse `$ARGUMENTS` — the question to answer. If empty, ask the user.

---

## Step 0 — Locate the wiki

Check in order: `wiki/`, `obsidian/`, `docs/wiki/`.
If a `SCHEMA.md` exists, read it for conventions.

---

## Step 1 — Read the index

Read `index.md` in the wiki root. Identify every page that could be relevant to the question.

---

## Step 2 — Read relevant pages

Read the pages identified in Step 1. Follow `[[WikiLinks]]` to additional pages if they seem relevant. Stop when you have enough to give a complete answer.

---

## Step 3 — Answer

Give a direct, specific answer. Cite wiki pages inline: "as described in [[PageName]]".
If the answer requires looking at source code that the wiki doesn't cover yet, say so and read the source file directly.

---

## Step 4 — Offer to file the answer

If the answer is non-trivial (more than a one-liner) and would be useful to future queries, ask:
"Should I file this as a wiki page?"
If yes, create `<wiki>/Concepts/<SlugFromQuestion>.md` or the most appropriate category, update `index.md`, and append to `log.md`:
```
## [YYYY-MM-DD] query | <question summary>
Filed: [[PageName]]
```
